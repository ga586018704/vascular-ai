VASCULAR.AI - Deployment Package
================================

Quick Start:
1. Copy .env.example to .env and fill in your values
2. Run: docker compose up -d
3. Access: http://your-server-ip

Files:
- docker-compose.yml - Main configuration
- nginx.conf - Nginx reverse proxy config
- .env.example - Environment variables template

Commands:
- Start: docker compose up -d
- Stop: docker compose down
- Logs: docker compose logs -f
- Status: docker compose ps
