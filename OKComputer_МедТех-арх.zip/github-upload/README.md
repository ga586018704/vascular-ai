# VASCULAR.AI Platform

AI-powered platform for vascular medicine - CT angiography analysis, vessel segmentation, pathology classification, and treatment recommendations.

## Quick Start

### 1. Clone and Setup

```bash
git clone https://github.com/YOUR_USERNAME/vascular-ai.git
cd vascular-ai

# Create environment file
cp .env.example .env

# Edit .env and add your API keys
nano .env
```

### 2. Start Services

```bash
docker compose up -d
```

### 3. Access Platform

- **Web App:** http://localhost
- **API Docs:** http://localhost/docs
- **Health Check:** http://localhost/health

## Requirements

- Docker & Docker Compose
- 4GB RAM minimum
- OpenAI API Key (optional, for AI features)
- Anthropic API Key (optional, for AI features)

## Features

- DICOM upload and processing
- CT angiography analysis
- Vessel segmentation
- Pathology classification (314+ conditions)
- AI agents for different pathologies
- Risk calculators (VSGNE, Wells, GAS)
- Laboratory tests integration
- PDF report generation

## Commands

```bash
# Start
docker compose up -d

# Stop
docker compose down

# View logs
docker compose logs -f

# Restart
docker compose restart

# Update
docker compose pull
docker compose up -d
```

## License

Proprietary - VASCULAR.AI
