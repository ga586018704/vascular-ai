import { useState, useEffect } from 'react'
import { ThemeProvider, createTheme } from '@mui/material/styles'
import CssBaseline from '@mui/material/CssBaseline'
import { Box, Typography, Container, AppBar, Toolbar, Button } from '@mui/material'
import { MedicalServices as MedicalIcon } from '@mui/icons-material'

const theme = createTheme({
  palette: {
    mode: 'light',
    primary: {
      main: '#1976d2',
    },
    secondary: {
      main: '#dc004e',
    },
  },
})

function App() {
  const [health, setHealth] = useState<any>(null)

  useEffect(() => {
    fetch('/health')
      .then(res => res.json())
      .then(data => setHealth(data))
      .catch(err => console.error(err))
  }, [])

  return (
    <ThemeProvider theme={theme}>
      <CssBaseline />
      <AppBar position="static">
        <Toolbar>
          <MedicalIcon sx={{ mr: 2 }} />
          <Typography variant="h6" component="div" sx={{ flexGrow: 1 }}>
            VASCULAR.AI
          </Typography>
          <Button color="inherit">Login</Button>
        </Toolbar>
      </AppBar>
      <Container maxWidth="lg" sx={{ mt: 4 }}>
        <Box sx={{ textAlign: 'center', py: 8 }}>
          <MedicalIcon sx={{ fontSize: 80, color: 'primary.main', mb: 2 }} />
          <Typography variant="h2" component="h1" gutterBottom>
            VASCULAR.AI
          </Typography>
          <Typography variant="h5" color="text.secondary" paragraph>
            AI-Powered Vascular Medicine Platform
          </Typography>
          {health && (
            <Typography variant="body1" color="success.main" sx={{ mt: 2 }}>
              API Status: {health.status}
            </Typography>
          )}
        </Box>
      </Container>
    </ThemeProvider>
  )
}

export default App
