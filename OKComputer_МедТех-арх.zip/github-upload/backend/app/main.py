"""
VASCULAR.AI - Main FastAPI Application
"""
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse
from contextlib import asynccontextmanager

app = FastAPI(
    title="VASCULAR.AI API",
    description="AI-powered vascular medicine platform",
    version="1.0.0"
)

# CORS middleware
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

@app.get("/")
async def root():
    """Root endpoint"""
    return {
        "name": "VASCULAR.AI API",
        "version": "1.0.0",
        "status": "running"
    }

@app.get("/health")
async def health_check():
    """Health check endpoint"""
    return {
        "status": "healthy",
        "service": "VASCULAR.AI API",
        "version": "1.0.0"
    }

@app.get("/docs")
async def docs_info():
    """API documentation info"""
    return {
        "swagger_ui": "/docs",
        "redoc": "/redoc",
        "openapi": "/openapi.json"
    }
