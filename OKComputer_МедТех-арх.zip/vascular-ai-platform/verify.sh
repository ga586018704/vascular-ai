#!/bin/bash

# VASCULAR.AI Installation Verification Script
# This script verifies that all required components are properly installed

set -e

# Colors
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m'

echo -e "${BLUE}╔════════════════════════════════════════════════════════╗${NC}"
echo -e "${BLUE}║     VASCULAR.AI Installation Verification              ║${NC}"
echo -e "${BLUE}╚════════════════════════════════════════════════════════╝${NC}"
echo ""

# Counters
CHECKS_PASSED=0
CHECKS_FAILED=0
WARNINGS=0

check_pass() {
    echo -e "${GREEN}✓${NC} $1"
    ((CHECKS_PASSED++))
}

check_fail() {
    echo -e "${RED}✗${NC} $1"
    ((CHECKS_FAILED++))
}

check_warn() {
    echo -e "${YELLOW}⚠${NC} $1"
    ((WARNINGS++))
}

# Check Python
echo -e "${BLUE}Checking Python...${NC}"
if command -v python3 &> /dev/null; then
    PYTHON_VERSION=$(python3 --version 2>&1 | awk '{print $2}')
    if [[ "$PYTHON_VERSION" =~ ^3\.(11|12) ]]; then
        check_pass "Python $PYTHON_VERSION installed"
    else
        check_warn "Python $PYTHON_VERSION installed (3.11+ recommended)"
    fi
else
    check_fail "Python 3 not found"
fi

# Check pip
echo -e "${BLUE}Checking pip...${NC}"
if command -v pip3 &> /dev/null; then
    check_pass "pip3 installed"
else
    check_fail "pip3 not found"
fi

# Check Node.js
echo -e "${BLUE}Checking Node.js...${NC}"
if command -v node &> /dev/null; then
    NODE_VERSION=$(node --version | sed 's/v//')
    if [[ "$NODE_VERSION" =~ ^20\. ]]; then
        check_pass "Node.js $NODE_VERSION installed"
    else
        check_warn "Node.js $NODE_VERSION installed (20+ recommended)"
    fi
else
    check_fail "Node.js not found"
fi

# Check npm
echo -e "${BLUE}Checking npm...${NC}"
if command -v npm &> /dev/null; then
    check_pass "npm installed"
else
    check_fail "npm not found"
fi

# Check Docker
echo -e "${BLUE}Checking Docker...${NC}"
if command -v docker &> /dev/null; then
    DOCKER_VERSION=$(docker --version | awk '{print $3}' | sed 's/,//')
    check_pass "Docker $DOCKER_VERSION installed"
else
    check_warn "Docker not found (optional, for containerized deployment)"
fi

# Check Docker Compose
echo -e "${BLUE}Checking Docker Compose...${NC}"
if command -v docker-compose &> /dev/null; then
    check_pass "Docker Compose installed"
else
    check_warn "Docker Compose not found (optional, for containerized deployment)"
fi

# Check backend files
echo ""
echo -e "${BLUE}Checking Backend Files...${NC}"
if [ -d "backend" ]; then
    check_pass "Backend directory exists"
    
    if [ -f "backend/requirements.txt" ]; then
        check_pass "requirements.txt exists"
    else
        check_fail "requirements.txt not found"
    fi
    
    if [ -f "backend/app/main.py" ]; then
        check_pass "main.py exists"
    else
        check_fail "main.py not found"
    fi
    
    if [ -f "backend/Dockerfile" ]; then
        check_pass "Backend Dockerfile exists"
    else
        check_fail "Backend Dockerfile not found"
    fi
else
    check_fail "Backend directory not found"
fi

# Check frontend files
echo ""
echo -e "${BLUE}Checking Frontend Files...${NC}"
if [ -d "frontend" ]; then
    check_pass "Frontend directory exists"
    
    if [ -f "frontend/package.json" ]; then
        check_pass "package.json exists"
    else
        check_warn "package.json not found (will be created on npm init)"
    fi
    
    if [ -f "frontend/Dockerfile" ]; then
        check_pass "Frontend Dockerfile exists"
    else
        check_fail "Frontend Dockerfile not found"
    fi
    
    if [ -f "frontend/nginx.conf" ]; then
        check_pass "nginx.conf exists"
    else
        check_fail "nginx.conf not found"
    fi
else
    check_fail "Frontend directory not found"
fi

# Check configuration files
echo ""
echo -e "${BLUE}Checking Configuration Files...${NC}"
if [ -f "docker-compose.yml" ]; then
    check_pass "docker-compose.yml exists"
else
    check_fail "docker-compose.yml not found"
fi

if [ -f "Makefile" ]; then
    check_pass "Makefile exists"
else
    check_fail "Makefile not found"
fi

if [ -f "start.sh" ]; then
    check_pass "start.sh exists"
else
    check_fail "start.sh not found"
fi

if [ -f "README.md" ]; then
    check_pass "README.md exists"
else
    check_warn "README.md not found"
fi

# Check AI Agents
echo ""
echo -e "${BLUE}Checking AI Agents...${NC}"
AGENTS=("vascular_agent" "phlebology_agent" "neurovascular_agent" "endovascular_agent" "pediatric_agent" "trauma_agent")
for agent in "${AGENTS[@]}"; do
    if [ -f "backend/app/agents/${agent}.py" ]; then
        check_pass "${agent}.py exists"
    else
        check_fail "${agent}.py not found"
    fi
done

# Summary
echo ""
echo -e "${BLUE}╔════════════════════════════════════════════════════════╗${NC}"
echo -e "${BLUE}║                    Summary                             ║${NC}"
echo -e "${BLUE}╚════════════════════════════════════════════════════════╝${NC}"
echo ""
echo -e "Checks Passed: ${GREEN}$CHECKS_PASSED${NC}"
echo -e "Checks Failed: ${RED}$CHECKS_FAILED${NC}"
echo -e "Warnings: ${YELLOW}$WARNINGS${NC}"
echo ""

if [ $CHECKS_FAILED -eq 0 ]; then
    echo -e "${GREEN}✓ All critical checks passed!${NC}"
    echo ""
    echo -e "${BLUE}Next steps:${NC}"
    echo "  1. Run: ${YELLOW}./start.sh${NC} or ${YELLOW}make dev${NC}"
    echo "  2. Open http://localhost:5173 in your browser"
    echo "  3. API docs available at http://localhost:8000/docs"
    echo ""
    exit 0
else
    echo -e "${RED}✗ Some checks failed. Please fix the issues above.${NC}"
    echo ""
    echo -e "${BLUE}Troubleshooting:${NC}"
    echo "  - Install missing dependencies"
    echo "  - Check file permissions"
    echo "  - Review README.md for setup instructions"
    echo ""
    exit 1
fi
