# VASCULAR.AI - Руководство по развёртыванию на сервере

## 🎯 Быстрый старт (5 минут)

### Шаг 1: Аренда сервера (Hetzner)

1. Перейди на [hetzner.com](https://www.hetzner.com/cloud)
2. Зарегистрируйся и подтверди email
3. Создай проект → "Add Server"
4. Выбери конфигурацию:
   - **Location:** Германия (Nuremberg) или Финляндия
   - **Image:** Ubuntu 22.04
   - **Type:** CX21 (2 vCPU, 4 GB RAM, 40 GB SSD) — **€6.21/мес**
   - **Networking:** IPv4 + IPv6
   - **SSH Key:** Добавь свой публичный ключ
   - **Name:** `vascular-ai`

5. Нажми "Create & Buy Now"

### Шаг 2: Подключение к серверу

```bash
# На твоём компьютере
ssh root@YOUR_SERVER_IP
```

### Шаг 3: Запуск установки

```bash
# На сервере выполни:
curl -fsSL https://raw.githubusercontent.com/YOUR_REPO/main/scripts/deploy.sh | bash -s -- --full
```

**Или вручную:**

```bash
# 1. Скачай скрипт
wget https://raw.githubusercontent.com/YOUR_REPO/main/scripts/deploy.sh -O deploy.sh
chmod +x deploy.sh

# 2. Запусти установку
./deploy.sh --full
```

### Шаг 4: Настройка API ключей

```bash
# Отредактируй файл с секретами
nano /opt/vascular-ai/.env
```

Добавь свои ключи:
```bash
OPENAI_API_KEY=sk-your-key-here
ANTHROPIC_API_KEY=sk-ant-your-key-here
```

Сохрани (Ctrl+O, Enter, Ctrl+X) и перезапусти:
```bash
cd /opt/vascular-ai
docker compose -f docker-compose.prod.yml restart api
```

### Готово! 🎉

Открой в браузере: `http://YOUR_SERVER_IP`

---

## 📋 Подробная инструкция

### 1. Подготовка

#### Требования к серверу

| Компонент | Минимум | Рекомендуется |
|-----------|---------|---------------|
| CPU | 2 ядра | 4 ядра |
| RAM | 4 GB | 8 GB |
| Disk | 40 GB SSD | 80 GB SSD |
| OS | Ubuntu 20.04+ | Ubuntu 22.04 LTS |

**Рекомендуемые провайдеры:**
- **Hetzner** (Германия) — от €6/мес — [hetzner.com](https://www.hetzner.com/cloud)
- **DigitalOcean** — от $6/мес — [digitalocean.com](https://www.digitalocean.com)
- **AWS Lightsail** — от $5/мес — [aws.amazon.com/lightsail](https://aws.amazon.com/lightsail)

#### Генерация SSH ключа

Если у тебя нет SSH ключа:

```bash
# На твоём компьютере (Mac/Linux)
ssh-keygen -t ed25519 -C "your-email@example.com"
cat ~/.ssh/id_ed25519.pub

# Windows (PowerShell)
ssh-keygen -t ed25519 -C "your-email@example.com"
Get-Content $env:USERPROFILE\.ssh\id_ed25519.pub
```

Скопируй вывод и добавь в Hetzner при создании сервера.

---

### 2. Установка

#### Подключение

```bash
ssh root@YOUR_SERVER_IP
```

#### Автоматическая установка

```bash
# Скачай и запусти скрипт
curl -fsSL https://raw.githubusercontent.com/YOUR_REPO/main/scripts/deploy.sh -o deploy.sh
chmod +x deploy.sh
./deploy.sh --full
```

#### Ручная установка (если скрипт не работает)

```bash
# 1. Обнови систему
apt update && apt upgrade -y

# 2. Установи Docker
curl -fsSL https://get.docker.com | sh
systemctl enable docker
systemctl start docker

# 3. Установи Docker Compose
apt install -y docker-compose-plugin

# 4. Создай директорию проекта
mkdir -p /opt/vascular-ai
cd /opt/vascular-ai

# 5. Скопируй файлы проекта (или git clone)
# git clone https://github.com/YOUR_REPO.git .

# 6. Создай .env файл
POSTGRES_PASSWORD=$(openssl rand -base64 32)
SECRET_KEY=$(openssl rand -hex 64)

cat > .env << EOF
POSTGRES_DB=vascular_ai
POSTGRES_USER=vascular
POSTGRES_PASSWORD=$POSTGRES_PASSWORD
SECRET_KEY=$SECRET_KEY
OPENAI_API_KEY=
ANTHROPIC_API_KEY=
GRAFANA_USER=admin
GRAFANA_PASSWORD=$(openssl rand -base64 16)
EOF

chmod 600 .env

# 7. Запусти
docker compose -f docker-compose.prod.yml up -d --build
```

---

### 3. Настройка домена и SSL

#### Привязка домена

1. Купи домен (например, на [reg.ru](https://www.reg.ru) или [namecheap.com](https://www.namecheap.com))
2. В DNS настройках добавь A-запись:
   - **Name:** `@` (или `vascular` для поддомена)
   - **Value:** IP твоего сервера
   - **TTL:** 3600

#### Установка SSL (Let's Encrypt)

```bash
# На сервере
cd /opt/vascular-ai

# Установи certbot
apt install -y certbot

# Получи сертификат (замени your-domain.com на свой домен)
certbot certonly --standalone -d your-domain.com --agree-tos -m your-email@example.com

# Обнови nginx конфиг
sed -i 's/# server {/server {/' nginx/nginx.conf
sed -i 's/#     listen 443/    listen 443/' nginx/nginx.conf
sed -i 's/#     ssl_certificate/    ssl_certificate/' nginx/nginx.conf
sed -i 's/your-domain.com/your-domain.com/g' nginx/nginx.conf

# Перезапусти
docker compose -f docker-compose.prod.yml restart nginx
```

---

### 4. Управление платформой

#### Просмотр статуса

```bash
cd /opt/vascular-ai

# Статус контейнеров
docker compose -f docker-compose.prod.yml ps

# Использование ресурсов
docker stats

# Логи
docker compose -f docker-compose.prod.yml logs -f

# Логи конкретного сервиса
docker compose -f docker-compose.prod.yml logs -f api
```

#### Перезапуск

```bash
cd /opt/vascular-ai

# Перезапуск всего
docker compose -f docker-compose.prod.yml restart

# Перезапуск одного сервиса
docker compose -f docker-compose.prod.yml restart api
```

#### Обновление

```bash
cd /opt/vascular-ai

# Скачай обновления
git pull

# Пересобери и перезапусти
docker compose -f docker-compose.prod.yml down
docker compose -f docker-compose.prod.yml up -d --build
```

#### Резервное копирование

```bash
cd /opt/vascular-ai

# Бэкап базы данных
docker compose -f docker-compose.prod.yml exec -T db pg_dump -U vascular vascular_ai > backup_$(date +%Y%m%d_%H%M%S).sql

# Бэкап загруженных файлов
tar -czf uploads_backup_$(date +%Y%m%d).tar.gz uploads/

# Автоматический бэкап (добавь в crontab)
crontab -e
# Добавь строку:
# 0 2 * * * cd /opt/vascular-ai && docker compose -f docker-compose.prod.yml exec -T db pg_dump -U vascular vascular_ai > /backups/vascular_ai_$(date +\%Y\%m\%d).sql
```

---

### 5. Доступ к сервисам

| Сервис | URL | Логин/Пароль |
|--------|-----|--------------|
| Веб-приложение | `http://YOUR_IP` или `https://your-domain.com` | - |
| API Docs | `http://YOUR_IP/docs` | - |
| Health Check | `http://YOUR_IP/health` | - |
| Grafana | `http://YOUR_IP/grafana` | admin / из .env |
| Prometheus | `http://YOUR_IP:9090` | - |

---

### 6. Устранение неполадок

#### Проблема: "Connection refused"

```bash
# Проверь статус контейнеров
docker compose -f docker-compose.prod.yml ps

# Перезапусти
docker compose -f docker-compose.prod.yml restart
```

#### Проблема: "502 Bad Gateway"

```bash
# Проверь логи API
docker compose -f docker-compose.prod.yml logs api

# Проверь, что API запустился
curl http://localhost:8000/health
```

#### Проблема: "Database connection failed"

```bash
# Проверь базу данных
docker compose -f docker-compose.prod.yml logs db

# Перезапусти базу
docker compose -f docker-compose.prod.yml restart db

# Подожди 10 секунд и перезапусти API
docker compose -f docker-compose.prod.yml restart api
```

#### Проблема: "Out of memory"

```bash
# Добавь swap (если RAM < 4GB)
fallocate -l 4G /swapfile
chmod 600 /swapfile
mkswap /swapfile
swapon /swapfile
echo '/swapfile none swap sw 0 0' >> /etc/fstab
```

#### Полный сброс (осторожно!)

```bash
cd /opt/vascular-ai

# Останови всё
docker compose -f docker-compose.prod.yml down

# Удали данные (⚠️ ВСЕ ДАННЫЕ БУДУТ УДАЛЕНЫ!)
docker volume rm vascular-ai_postgres_data vascular-ai_redis_data

# Перезапусти
docker compose -f docker-compose.prod.yml up -d
```

---

### 7. Безопасность

#### Фаервол (UFW)

```bash
# Установи UFW
apt install -y ufw

# Разреши SSH, HTTP, HTTPS
ufw allow 22/tcp
ufw allow 80/tcp
ufw allow 443/tcp

# Включи фаервол
ufw enable

# Проверь статус
ufw status
```

#### Автоматические обновления

```bash
apt install -y unattended-upgrades
```

#### Fail2ban (защита от брутфорса)

```bash
apt install -y fail2ban
systemctl enable fail2ban
systemctl start fail2ban
```

---

### 8. Мониторинг

#### Настройка алертов (Grafana)

1. Открой `http://YOUR_IP/grafana`
2. Войди (admin / пароль из .env)
3. Configuration → Alerting → Notification channels
4. Добавь Email или Telegram
5. Создай алерты на:
   - CPU > 80%
   - RAM > 90%
   - Disk > 85%
   - API недоступен

---

## 💰 Стоимость

| Провайдер | Конфигурация | Цена/мес |
|-----------|--------------|----------|
| Hetzner CX21 | 2 vCPU, 4 GB, 40 GB | €6.21 |
| Hetzner CPX21 | 4 vCPU, 8 GB, 80 GB | €11.69 |
| DigitalOcean | 2 vCPU, 4 GB, 80 GB | $24 |
| AWS Lightsail | 2 vCPU, 4 GB, 80 GB | $20 |

**Дополнительно:**
- Домен: ~$10/год
- SSL: бесплатно (Let's Encrypt)

---

## 📞 Поддержка

Если что-то не работает:

1. Проверь логи: `docker compose logs -f`
2. Проверь статус: `docker compose ps`
3. Перезапусти: `docker compose restart`

Или пиши мне — помогу разобраться! 🚀
