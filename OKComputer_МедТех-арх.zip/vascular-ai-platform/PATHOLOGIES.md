# VASCULAR.AI - Comprehensive Vascular Pathology Reference

This document provides a complete reference of all vascular pathologies supported by VASCULAR.AI.

## 📊 Statistics

- **Total Pathologies**: 300+
- **Categories**: 10
- **Severity Levels**: 7
- **Acuity Levels**: 5
- **Clinical Significance Levels**: 6

## 🏥 Pathology Categories

### 1. Degenerative (50+ pathologies)
Age-related and degenerative changes affecting blood vessels.

**Key Pathologies:**
- Atherosclerosis (diffuse, focal, calcified, soft, mixed)
- Plaque (fibrous, fibrofatty, calcified, soft, vulnerable, stable, ulcerated)
- Calcification (intimal, medial, circumferential, spotty, heavy)
- Arterial tortuosity, kinking, coiling
- Vascular ectasia, arteriomegaly

### 2. Inflammatory (30+ pathologies)
Inflammatory and autoimmune conditions affecting vessels.

**Key Pathologies:**
- Vasculitis (large, medium, small vessel)
- Takayasu Arteritis
- Giant Cell Arteritis
- Polyarteritis Nodosa
- Kawasaki Disease
- Behcet Disease
- Buerger Disease (Thromboangiitis Obliterans)
- Granulomatosis with Polyangiitis (Wegener)
- Churg-Strauss Syndrome
- Microscopic Polyangiitis
- Henoch-Schonlein Purpura
- Cryoglobulinemic Vasculitis

### 3. Infectious (20+ pathologies)
Infectious and septic conditions affecting vessels.

**Key Pathologies:**
- Mycotic Aneurysm
- Infectious Vasculitis (syphilitic, tuberculous, fungal)
- Periaortitis (idiopathic, IgG4-related, infectious)
- Graft Infections (staph, strep, gram-negative, fungal, mycotic)
- Sepsis, Endocarditis

### 4. Traumatic (15+ pathologies)
Traumatic injuries to blood vessels.

**Key Pathologies:**
- Traumatic Aneurysm
- Pseudoaneurysm
- Vascular Laceration
- Vascular Contusion
- Vascular Avulsion
- Post-traumatic Thrombosis
- Traumatic Dissection
- Traumatic AVF

### 5. Congenital (40+ pathologies)
Congenital anomalies and genetic conditions.

**Key Pathologies:**
- Arteriovenous Malformation (AVM) - high flow, low flow, nidus, diffuse, cirsoid
- Arteriovenous Fistula (AVF) - congenital
- Hemangioma (capillary, cavernous, venous)
- Lymphangioma (microcystic, macrocystic)
- Marfan Syndrome
- Ehlers-Danlos Syndrome (all types, including Type IV - vascular)
- Loeys-Dietz Syndrome (Type I, Type II)
- Turner Syndrome
- Polycystic Kidney Disease
- Arterial Tortuosity, Coiling

### 6. Iatrogenic (40+ pathologies)
Treatment-related complications.

**Key Pathologies:**
- In-stent Restenosis (focal, diffuse, occlusive)
- Stent Fracture, Migration
- Endoleak (Type I, II, III, IV, V)
- Bypass Graft Stenosis/Occlusion
- Graft Anastomotic Stenosis
- Intimal Hyperplasia
- Graft Degeneration, Infection, Pseudoaneurysm, Seroma
- Post-endarterectomy Restenosis
- Patch Stenosis, Patch Aneurysm
- Dialysis Access AVF complications
- Post-radiation Stenosis

### 7. Systemic (20+ pathologies)
Systemic diseases affecting vessels.

**Key Pathologies:**
- Fibromuscular Dysplasia (FMD) - multifocal, focal, medial, intimal, adventitial
- Connective tissue disorders with vascular involvement

### 8. Neoplastic (10+ pathologies)
Tumors and neoplasms of vascular origin.

**Key Pathologies:**
- Angiosarcoma
- Hemangiopericytoma
- Glomus Tumor
- Epithelioid Hemangioendothelioma
- Tumor Invasion into vessels
- Tumor Compression of vessels
- Tumor Thrombus

### 9. Functional (15+ pathologies)
Functional disorders without structural changes.

**Key Pathologies:**
- Vasospasm (reversible, fixed)
- Raynaud Phenomenon/Disease/Syndrome
- Livedo Reticularis, Livedo Racemosa
- Erythromelalgia
- Acrocyanosis
- Vasomotor Instability
- Postural Hypotension
- Neurocardiogenic Syncope

### 10. Idiopathic (5+ pathologies)
Conditions of unknown etiology.

## 🔬 Detailed Pathology Classifications

### Aneurysmal Diseases (20+ types)

#### By Morphology:
- **Saccular Aneurysm**: Berry-like outpouching with neck
- **Fusiform Aneurysm**: Spindle-shaped dilation
- **Dissecting Aneurysm**: Resulting from arterial dissection
- **Pseudoaneurysm**: Contained rupture

#### By Etiology:
- **Mycotic Aneurysm**: Infectious origin
- **Traumatic Aneurysm**: Post-traumatic
- **Inflammatory Aneurysm**: Associated with inflammation

#### By Status:
- **Ruptured Aneurysm**: With active bleeding
- **Leaking Aneurysm**: Contained leak
- **Thrombosed Aneurysm**: With mural thrombus
- **Calcified Aneurysm**: With wall calcification

### Occlusive Diseases (30+ types)

#### Stenosis Types:
- **Calcified Stenosis**: With calcium deposits
- **Soft Plaque Stenosis**: Lipid-rich plaque
- **Ulcerated Stenosis**: With surface ulceration
- **Eccentric Stenosis**: Asymmetric narrowing
- **Concentric Stenosis**: Symmetric narrowing
- **Long-segment Stenosis**: >2cm length
- **Tandem Stenosis**: Multiple sequential lesions
- **Recurrent Stenosis**: After intervention
- **Post-radiation Stenosis**: Following radiation therapy

#### Occlusion Types:
- **Chronic Total Occlusion (CTO)**: >3 months
- **Subacute Occlusion**: 2 weeks - 3 months
- **Acute Occlusion**: <2 weeks
- **Occlusion Stump**: Remnant after occlusion

### Thrombotic Diseases (20+ types)

#### By Age:
- **Acute Thrombosis**: <14 days
- **Subacute Thrombosis**: 14-28 days
- **Chronic Thrombosis**: >28 days
- **Organized Thrombus**: Fully organized
- **Fresh Thrombus**: Acute formation

#### By Characteristics:
- **Propagating Thrombus**: Extending proximally/distally
- **Mural Thrombus**: Attached to wall
- **Obstructive Thrombus**: Causing occlusion
- **Parietal Thrombus**: Wall-adherent
- **Calcified Thrombus**: With calcification

### Dissections (15+ types)

#### Stanford Classification:
- **Type A**: Involves ascending aorta
- **Type B**: Does not involve ascending aorta

#### DeBakey Classification:
- **Type I**: Ascending + descending aorta
- **Type II**: Ascending only
- **Type IIIa**: Descending (distal to left subclavian)
- **Type IIIb**: Descending + abdominal

#### Complications:
- **Complicated Dissection**: With malperfusion, rupture, tamponade
- **Uncomplicated Dissection**: Without complications
- **Malperfusion Syndrome**: End-organ ischemia

### Atherosclerotic Diseases (25+ types)

#### Plaque Types:
- **Fibrous Plaque**: Collagen-rich
- **Fibrofatty Plaque**: Mixed composition
- **Calcified Plaque**: Mineralized
- **Soft Plaque**: Lipid-rich
- **Vulnerable Plaque**: Prone to rupture
- **Stable Plaque**: Low rupture risk
- **Ulcerated Plaque**: Surface defect
- **Eroded Plaque**: Endothelial erosion

#### Special Forms:
- **Intraplaque Hemorrhage**: Bleeding into plaque
- **Lipid-rich Necrotic Core**: Large lipid pool
- **Thin-cap Fibroatheroma (TCFA)**: Vulnerable plaque

### Venous Diseases (30+ types)

#### Varicose Veins:
- **Primary Varicose Veins**: Idiopathic
- **Secondary Varicose Veins**: Post-thrombotic
- **Recurrent Varicose Veins**: After treatment

#### Venous Insufficiency:
- **Primary CVI**: Valve failure
- **Secondary CVI**: Post-thrombotic
- **Congenital CVI**: Developmental

#### Deep Vein Thrombosis:
- **Proximal DVT**: Above knee
- **Distal DVT**: Below knee
- **Phlegmasia**: Severe form

#### Compression Syndromes:
- **May-Thurner Syndrome**: Iliac vein compression
- **Nutcracker Syndrome**: Renal vein compression
- **Pelvic Congestion Syndrome**: Ovarian vein reflux

### Vasospastic Disorders (15+ types)

- **Raynaud Phenomenon**: Color changes with cold/stress
- **Raynaud Disease**: Primary, idiopathic
- **Raynaud Syndrome**: Secondary to other conditions
- **Livedo Reticularis**: Mottled skin discoloration
- **Livedo Racemosa**: Irregular livedo (pathologic)
- **Erythromelalgia**: Burning pain with redness
- **Acrocyanosis**: Persistent cyanosis of extremities

### Post-interventional Complications (40+ types)

#### Stent-related:
- **In-stent Restenosis**: Neointimal hyperplasia
  - Focal ISR
  - Diffuse ISR
  - Occlusive ISR
- **Stent Fracture**: Mechanical failure
- **Stent Migration**: Displacement

#### Endoleaks (EVAR complications):
- **Type I**: Attachment site leak
- **Type II**: Branch vessel retrograde flow
- **Type III**: Graft defect/modular disconnect
- **Type IV**: Graft porosity
- **Type V**: Endotension (expansion without visible leak)

#### Bypass Graft Complications:
- **Graft Stenosis**: Narrowing
- **Graft Occlusion**: Complete blockage
- **Anastomotic Stenosis**: At connection sites
- **Body Stenosis**: Within graft
- **Intimal Hyperplasia**: Neointimal thickening
- **Graft Degeneration**: Material breakdown
- **Graft Infection**: Septic complications
- **Graft Pseudoaneurysm**: False aneurysm at anastomosis
- **Graft Seroma**: Fluid collection

## 📈 Severity Classification

### Severity Levels:
1. **Normal**: No pathology
2. **Minimal**: Minimal changes, no clinical significance
3. **Mild**: Mild pathology, monitoring required
4. **Moderate**: Moderate pathology, may need treatment
5. **Severe**: Severe pathology, treatment indicated
6. **Critical**: Critical, urgent treatment required
7. **Extreme**: Extreme, life-threatening emergency

### Clinical Significance:
1. **Incidental**: Found by chance, no action needed
2. **Monitor**: Requires periodic monitoring
3. **Elective Treatment**: Planned treatment indicated
4. **Urgent Treatment**: Prompt treatment needed
5. **Emergency Treatment**: Immediate intervention required
6. **Life-threatening**: Critical, immediate action essential

## 🔍 API Endpoints

### Get All Pathology Types
```
GET /api/pathologies/types
```
Returns complete list of all pathology types with descriptions.

### Get Pathology Categories
```
GET /api/pathologies/categories
```
Returns all pathology categories.

### Get Pathologies by Category
```
GET /api/pathologies/by-category/{category}
```
Returns pathologies filtered by category.

### Search Pathologies
```
GET /api/pathologies/search?query={search_term}
```
Search pathologies by name or description.

### Get Severity Levels
```
GET /api/pathologies/severities
```
Returns all severity classification levels.

### Get Acuity Levels
```
GET /api/pathologies/acuity
```
Returns all acuity classification levels.

### Get Clinical Significance Levels
```
GET /api/pathologies/significance
```
Returns all clinical significance levels.

### Get Statistics
```
GET /api/pathologies/stats
```
Returns statistics about available pathologies.

## 🌐 Multilingual Support

All pathologies include:
- **English name and description**
- **Russian name and description** (name_ru, description_ru)
- Easy to extend to other languages

## 📚 References

1. Society for Vascular Surgery (SVS) Guidelines
2. European Society for Vascular Surgery (ESVS) Guidelines
3. ACC/AHA Guidelines for Peripheral Arterial Disease
4. ESC Guidelines on Cardiovascular Diseases
5. UpToDate Vascular Medicine
6. Rutherford's Vascular Surgery Textbook
7. Cronenwett and Johnston's Decision Making in Vascular Surgery

---

**VASCULAR.AI v2.0.0** - Complete vascular pathology classification system
