import React, { useEffect, useRef, useState, useCallback } from 'react';
import { 
  Box, 
  Paper, 
  Typography, 
  Slider, 
  IconButton, 
  Tooltip,
  Divider,
  FormControl,
  InputLabel,
  Select,
  MenuItem,
  Chip,
  Stack
} from '@mui/material';
import {
  ZoomIn,
  ZoomOut,
  RotateLeft,
  RotateRight,
  Flip,
  Straighten,
  Layers,
  PlayArrow,
  Pause,
  VolumeUp,
  CropFree,
  ThreeDRotation,
  Visibility,
  VisibilityOff
} from '@mui/icons-material';

interface DicomViewer3DProps {
  studyId?: string;
  seriesId?: string;
  dicomUrl?: string;
}

interface ViewportState {
  zoom: number;
  rotation: number;
  flipHorizontal: boolean;
  flipVertical: boolean;
  windowWidth: number;
  windowCenter: number;
  sliceIndex: number;
  totalSlices: number;
  isPlaying: boolean;
  playSpeed: number;
}

const DicomViewer3D: React.FC<DicomViewer3DProps> = ({ 
  studyId, 
  seriesId,
  dicomUrl 
}) => {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const containerRef = useRef<HTMLDivElement>(null);
  const [viewport, setViewport] = useState<ViewportState>({
    zoom: 1,
    rotation: 0,
    flipHorizontal: false,
    flipVertical: false,
    windowWidth: 400,
    windowCenter: 40,
    sliceIndex: 0,
    totalSlices: 100,
    isPlaying: false,
    playSpeed: 100
  });
  
  const [viewMode, setViewMode] = useState<'axial' | 'sagittal' | 'coronal' | '3d'>('axial');
  const [tools, setTools] = useState({
    measurement: false,
    roi: false,
    annotation: false,
    windowing: false
  });
  const [show3D, setShow3D] = useState(false);
  const [isLoading, setIsLoading] = useState(true);
  
  // Simulated DICOM data loading
  useEffect(() => {
    const loadDicomData = async () => {
      setIsLoading(true);
      // Simulate API call to load DICOM data
      await new Promise(resolve => setTimeout(resolve, 1500));
      setIsLoading(false);
    };
    
    if (studyId || dicomUrl) {
      loadDicomData();
    }
  }, [studyId, dicomUrl]);
  
  // Cine playback
  useEffect(() => {
    let interval: NodeJS.Timeout;
    
    if (viewport.isPlaying) {
      interval = setInterval(() => {
        setViewport(prev => ({
          ...prev,
          sliceIndex: (prev.sliceIndex + 1) % prev.totalSlices
        }));
      }, viewport.playSpeed);
    }
    
    return () => clearInterval(interval);
  }, [viewport.isPlaying, viewport.playSpeed, viewport.totalSlices]);
  
  // Render DICOM slice
  const renderSlice = useCallback(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    
    const ctx = canvas.getContext('2d');
    if (!ctx) return;
    
    // Clear canvas
    ctx.fillStyle = '#000';
    ctx.fillRect(0, 0, canvas.width, canvas.height);
    
    // Apply transformations
    ctx.save();
    ctx.translate(canvas.width / 2, canvas.height / 2);
    ctx.scale(viewport.zoom, viewport.zoom);
    ctx.rotate((viewport.rotation * Math.PI) / 180);
    ctx.scale(
      viewport.flipHorizontal ? -1 : 1,
      viewport.flipVertical ? -1 : 1
    );
    
    // Draw simulated DICOM image
    const gradient = ctx.createLinearGradient(-200, -200, 200, 200);
    gradient.addColorStop(0, `rgb(${viewport.windowCenter - viewport.windowWidth/2}, ${viewport.windowCenter - viewport.windowWidth/2}, ${viewport.windowCenter - viewport.windowWidth/2})`);
    gradient.addColorStop(0.5, `rgb(${viewport.windowCenter}, ${viewport.windowCenter}, ${viewport.windowCenter})`);
    gradient.addColorStop(1, `rgb(${viewport.windowCenter + viewport.windowWidth/2}, ${viewport.windowCenter + viewport.windowWidth/2}, ${viewport.windowCenter + viewport.windowWidth/2})`);
    
    ctx.fillStyle = gradient;
    ctx.fillRect(-200, -200, 400, 400);
    
    // Draw crosshairs
    ctx.strokeStyle = 'rgba(255, 255, 0, 0.5)';
    ctx.lineWidth = 1;
    ctx.beginPath();
    ctx.moveTo(-200, 0);
    ctx.lineTo(200, 0);
    ctx.moveTo(0, -200);
    ctx.lineTo(0, 200);
    ctx.stroke();
    
    // Draw slice info
    ctx.restore();
    ctx.fillStyle = '#0f0';
    ctx.font = '14px monospace';
    ctx.fillText(`Slice: ${viewport.sliceIndex + 1}/${viewport.totalSlices}`, 10, 20);
    ctx.fillText(`WW: ${viewport.windowWidth} WC: ${viewport.windowCenter}`, 10, 40);
    ctx.fillText(`Zoom: ${(viewport.zoom * 100).toFixed(0)}%`, 10, 60);
    ctx.fillText(`View: ${viewMode.toUpperCase()}`, 10, 80);
    
  }, [viewport, viewMode]);
  
  useEffect(() => {
    renderSlice();
  }, [renderSlice]);
  
  // Toolbar handlers
  const handleZoomIn = () => setViewport(prev => ({ ...prev, zoom: Math.min(prev.zoom * 1.2, 5) }));
  const handleZoomOut = () => setViewport(prev => ({ ...prev, zoom: Math.max(prev.zoom / 1.2, 0.2) }));
  const handleRotateLeft = () => setViewport(prev => ({ ...prev, rotation: prev.rotation - 90 }));
  const handleRotateRight = () => setViewport(prev => ({ ...prev, rotation: prev.rotation + 90 }));
  const handleFlipHorizontal = () => setViewport(prev => ({ ...prev, flipHorizontal: !prev.flipHorizontal }));
  const handleFlipVertical = () => setViewport(prev => ({ ...prev, flipVertical: !prev.flipVertical }));
  const handlePlayPause = () => setViewport(prev => ({ ...prev, isPlaying: !prev.isPlaying }));
  
  const handleSliceChange = (_: Event, value: number | number[]) => {
    setViewport(prev => ({ ...prev, sliceIndex: value as number }));
  };
  
  const handleWindowWidthChange = (_: Event, value: number | number[]) => {
    setViewport(prev => ({ ...prev, windowWidth: value as number }));
  };
  
  const handleWindowCenterChange = (_: Event, value: number | number[]) => {
    setViewport(prev => ({ ...prev, windowCenter: value as number }));
  };
  
  const windowPresets = [
    { name: 'Soft Tissue', ww: 400, wc: 40 },
    { name: 'Lung', ww: 1500, wc: -600 },
    { name: 'Bone', ww: 2000, wc: 400 },
    { name: 'Brain', ww: 80, wc: 40 },
    { name: 'Vascular', ww: 600, wc: 200 }
  ];
  
  return (
    <Box sx={{ height: '100%', display: 'flex', flexDirection: 'column' }}>
      {/* Toolbar */}
      <Paper sx={{ p: 1, display: 'flex', alignItems: 'center', gap: 1, flexWrap: 'wrap' }}>
        {/* View Mode */}
        <FormControl size="small" sx={{ minWidth: 120 }}>
          <InputLabel>View Mode</InputLabel>
          <Select
            value={viewMode}
            label="View Mode"
            onChange={(e) => setViewMode(e.target.value as any)}
          >
            <MenuItem value="axial">Axial</MenuItem>
            <MenuItem value="sagittal">Sagittal</MenuItem>
            <MenuItem value="coronal">Coronal</MenuItem>
            <MenuItem value="3d">3D Volume</MenuItem>
          </Select>
        </FormControl>
        
        <Divider orientation="vertical" flexItem />
        
        {/* Zoom Controls */}
        <Tooltip title="Zoom In">
          <IconButton onClick={handleZoomIn} size="small">
            <ZoomIn />
          </IconButton>
        </Tooltip>
        <Tooltip title="Zoom Out">
          <IconButton onClick={handleZoomOut} size="small">
            <ZoomOut />
          </IconButton>
        </Tooltip>
        
        <Divider orientation="vertical" flexItem />
        
        {/* Rotation */}
        <Tooltip title="Rotate Left">
          <IconButton onClick={handleRotateLeft} size="small">
            <RotateLeft />
          </IconButton>
        </Tooltip>
        <Tooltip title="Rotate Right">
          <IconButton onClick={handleRotateRight} size="small">
            <RotateRight />
          </IconButton>
        </Tooltip>
        
        <Divider orientation="vertical" flexItem />
        
        {/* Flip */}
        <Tooltip title="Flip Horizontal">
          <IconButton onClick={handleFlipHorizontal} size="small">
            <Flip sx={{ transform: 'rotate(90deg)' }} />
          </IconButton>
        </Tooltip>
        <Tooltip title="Flip Vertical">
          <IconButton onClick={handleFlipVertical} size="small">
            <Flip />
          </IconButton>
        </Tooltip>
        
        <Divider orientation="vertical" flexItem />
        
        {/* Tools */}
        <Tooltip title="Measurement Tool">
          <IconButton 
            onClick={() => setTools(prev => ({ ...prev, measurement: !prev.measurement }))}
            color={tools.measurement ? 'primary' : 'default'}
            size="small"
          >
            <Straighten />
          </IconButton>
        </Tooltip>
        <Tooltip title="Window/Level">
          <IconButton 
            onClick={() => setTools(prev => ({ ...prev, windowing: !prev.windowing }))}
            color={tools.windowing ? 'primary' : 'default'}
            size="small"
          >
            <Layers />
          </IconButton>
        </Tooltip>
        <Tooltip title="3D View">
          <IconButton 
            onClick={() => setShow3D(!show3D)}
            color={show3D ? 'primary' : 'default'}
            size="small"
          >
            <ThreeDRotation />
          </IconButton>
        </Tooltip>
        
        <Divider orientation="vertical" flexItem />
        
        {/* Cine Controls */}
        <Tooltip title={viewport.isPlaying ? 'Pause' : 'Play'}>
          <IconButton onClick={handlePlayPause} size="small" color="primary">
            {viewport.isPlaying ? <Pause /> : <PlayArrow />}
          </IconButton>
        </Tooltip>
      </Paper>
      
      {/* Main Viewer */}
      <Box 
        ref={containerRef}
        sx={{ 
          flex: 1, 
          display: 'flex', 
          gap: 1, 
          p: 1,
          overflow: 'hidden'
        }}
      >
        {/* 2D Slice View */}
        <Paper 
          sx={{ 
            flex: show3D ? 1 : 2, 
            display: 'flex', 
            flexDirection: 'column',
            position: 'relative',
            bgcolor: '#000'
          }}
        >
          <canvas
            ref={canvasRef}
            width={800}
            height={600}
            style={{
              width: '100%',
              height: '100%',
              objectFit: 'contain',
              cursor: tools.measurement ? 'crosshair' : 'default'
            }}
          />
          
          {isLoading && (
            <Box sx={{
              position: 'absolute',
              top: 0,
              left: 0,
              right: 0,
              bottom: 0,
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              bgcolor: 'rgba(0,0,0,0.8)'
            }}>
              <Typography variant="h6" color="primary">
                Loading DICOM...
              </Typography>
            </Box>
          )}
        </Paper>
        
        {/* 3D Volume View */}
        {show3D && (
          <Paper 
            sx={{ 
              flex: 1, 
              display: 'flex', 
              flexDirection: 'column',
              bgcolor: '#000',
              position: 'relative'
            }}
          >
            <Box sx={{ 
              flex: 1, 
              display: 'flex', 
              alignItems: 'center', 
              justifyContent: 'center',
              flexDirection: 'column',
              gap: 2
            }}>
              <ThreeDRotation sx={{ fontSize: 80, color: 'primary.main', opacity: 0.5 }} />
              <Typography variant="h6" color="text.secondary">
                3D Volume Rendering
              </Typography>
              <Typography variant="body2" color="text.secondary">
                Volume rendering with ray casting
              </Typography>
              <Chip 
                label="WebGL 2.0 Required" 
                color="primary" 
                variant="outlined"
                size="small"
              />
            </Box>
          </Paper>
        )}
      </Box>
      
      {/* Controls Panel */}
      <Paper sx={{ p: 2 }}>
        {/* Slice Navigation */}
        <Box sx={{ mb: 2 }}>
          <Typography variant="subtitle2" gutterBottom>
            Slice Navigation
          </Typography>
          <Box sx={{ display: 'flex', alignItems: 'center', gap: 2 }}>
            <Typography variant="body2" sx={{ minWidth: 60 }}>
              {viewport.sliceIndex + 1} / {viewport.totalSlices}
            </Typography>
            <Slider
              value={viewport.sliceIndex}
              onChange={handleSliceChange}
              min={0}
              max={viewport.totalSlices - 1}
              sx={{ flex: 1 }}
            />
          </Box>
        </Box>
        
        {/* Window/Level Controls */}
        {tools.windowing && (
          <Box sx={{ mb: 2 }}>
            <Typography variant="subtitle2" gutterBottom>
              Window/Level
            </Typography>
            <Stack direction="row" spacing={2} sx={{ mb: 1 }}>
              {windowPresets.map((preset) => (
                <Chip
                  key={preset.name}
                  label={preset.name}
                  size="small"
                  onClick={() => setViewport(prev => ({ 
                    ...prev, 
                    windowWidth: preset.ww, 
                    windowCenter: preset.wc 
                  }))}
                  color={viewport.windowWidth === preset.ww ? 'primary' : 'default'}
                  variant={viewport.windowWidth === preset.ww ? 'filled' : 'outlined'}
                />
              ))}
            </Stack>
            <Box sx={{ display: 'flex', gap: 2 }}>
              <Box sx={{ flex: 1 }}>
                <Typography variant="caption">Window Width</Typography>
                <Slider
                  value={viewport.windowWidth}
                  onChange={handleWindowWidthChange}
                  min={1}
                  max={4000}
                />
              </Box>
              <Box sx={{ flex: 1 }}>
                <Typography variant="caption">Window Center</Typography>
                <Slider
                  value={viewport.windowCenter}
                  onChange={handleWindowCenterChange}
                  min={-1000}
                  max={1000}
                />
              </Box>
            </Box>
          </Box>
        )}
        
        {/* Study Info */}
        <Box sx={{ display: 'flex', gap: 2, flexWrap: 'wrap' }}>
          <Chip 
            label={`Study: ${studyId || 'N/A'}`} 
            size="small" 
            variant="outlined"
          />
          <Chip 
            label={`Series: ${seriesId || 'N/A'}`} 
            size="small" 
            variant="outlined"
          />
          <Chip 
            label={`Modality: CT`} 
            size="small" 
            color="primary"
            variant="outlined"
          />
          <Chip 
            label={`Matrix: 512x512`} 
            size="small" 
            variant="outlined"
          />
        </Box>
      </Paper>
    </Box>
  );
};

export default DicomViewer3D;
