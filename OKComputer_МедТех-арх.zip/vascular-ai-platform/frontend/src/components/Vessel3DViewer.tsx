import React, { useEffect, useRef, useState, useCallback } from 'react';
import * as THREE from 'three';
import { OrbitControls } from 'three/examples/jsm/controls/OrbitControls';
import { Box, Typography, Slider, IconButton, Tooltip, Chip, Paper } from '@mui/material';
import {
  ZoomIn, ZoomOut, RotateLeft, RotateRight,
  Visibility, VisibilityOff, CameraAlt, Save,
  PlayArrow, Pause, Settings, Straighten
} from '@mui/icons-material';

interface Vessel3DViewerProps {
  vesselData: {
    segmentationMask: number[][][];
    centerline: number[][];
    vesselType: string;
    measurements: {
      diameter_mm: number;
      length_mm: number;
      volume_ml: number;
    };
    pathologies?: Array<{
      type: string;
      location: number[];
      severity: string;
    }>;
  };
  width?: number | string;
  height?: number | string;
}

const Vessel3DViewer: React.FC<Vessel3DViewerProps> = ({
  vesselData,
  width = '100%',
  height = '600px'
}) => {
  const containerRef = useRef<HTMLDivElement>(null);
  const sceneRef = useRef<THREE.Scene | null>(null);
  const cameraRef = useRef<THREE.PerspectiveCamera | null>(null);
  const rendererRef = useRef<THREE.WebGLRenderer | null>(null);
  const controlsRef = useRef<OrbitControls | null>(null);
  const vesselMeshRef = useRef<THREE.Mesh | null>(null);
  const centerlineRef = useRef<THREE.Line | null>(null);
  const pathologyMarkersRef = useRef<THREE.Group | null>(null);
  const animationRef = useRef<number | null>(null);

  const [isLoading, setIsLoading] = useState(true);
  const [opacity, setOpacity] = useState(0.8);
  const [showCenterline, setShowCenterline] = useState(true);
  const [showPathologies, setShowPathologies] = useState(true);
  const [isRotating, setIsRotating] = useState(false);
  const [measurementMode, setMeasurementMode] = useState(false);
  const [selectedPoint, setSelectedPoint] = useState<THREE.Vector3 | null>(null);

  // Initialize Three.js scene
  useEffect(() => {
    if (!containerRef.current) return;

    // Scene setup
    const scene = new THREE.Scene();
    scene.background = new THREE.Color(0x0a0e17);
    sceneRef.current = scene;

    // Camera setup
    const camera = new THREE.PerspectiveCamera(
      45,
      containerRef.current.clientWidth / containerRef.current.clientHeight,
      0.1,
      1000
    );
    camera.position.set(50, 50, 100);
    cameraRef.current = camera;

    // Renderer setup
    const renderer = new THREE.WebGLRenderer({
      antialias: true,
      alpha: true,
      preserveDrawingBuffer: true
    });
    renderer.setSize(containerRef.current.clientWidth, containerRef.current.clientHeight);
    renderer.setPixelRatio(window.devicePixelRatio);
    renderer.shadowMap.enabled = true;
    renderer.shadowMap.type = THREE.PCFSoftShadowMap;
    containerRef.current.appendChild(renderer.domElement);
    rendererRef.current = renderer;

    // Controls
    const controls = new OrbitControls(camera, renderer.domElement);
    controls.enableDamping = true;
    controls.dampingFactor = 0.05;
    controls.minDistance = 10;
    controls.maxDistance = 500;
    controlsRef.current = controls;

    // Lighting
    const ambientLight = new THREE.AmbientLight(0xffffff, 0.4);
    scene.add(ambientLight);

    const directionalLight = new THREE.DirectionalLight(0xffffff, 0.8);
    directionalLight.position.set(50, 50, 50);
    directionalLight.castShadow = true;
    scene.add(directionalLight);

    const pointLight = new THREE.PointLight(0x4fc3f7, 0.5);
    pointLight.position.set(-50, 50, 50);
    scene.add(pointLight);

    // Grid helper
    const gridHelper = new THREE.GridHelper(200, 20, 0x333333, 0x222222);
    scene.add(gridHelper);

    // Axes helper
    const axesHelper = new THREE.AxesHelper(50);
    scene.add(axesHelper);

    // Create vessel from data
    createVesselFromData();

    // Animation loop
    const animate = () => {
      animationRef.current = requestAnimationFrame(animate);
      controls.update();
      renderer.render(scene, camera);
    };
    animate();

    setIsLoading(false);

    // Cleanup
    return () => {
      if (animationRef.current) {
        cancelAnimationFrame(animationRef.current);
      }
      renderer.dispose();
      if (containerRef.current && renderer.domElement) {
        containerRef.current.removeChild(renderer.domElement);
      }
    };
  }, []);

  // Create vessel mesh from segmentation data
  const createVesselFromData = useCallback(() => {
    if (!sceneRef.current || !vesselData) return;

    // Generate vessel geometry from centerline and diameter
    const { centerline, measurements } = vesselData;
    
    if (!centerline || centerline.length < 2) return;

    // Create tube geometry along centerline
    const curve = new THREE.CatmullRomCurve3(
      centerline.map((point: number[]) => 
        new THREE.Vector3(point[0], point[1], point[2])
      )
    );

    const tubeGeometry = new THREE.TubeGeometry(
      curve,
      centerline.length * 2,
      measurements.diameter_mm / 2,
      16,
      false
    );

    // Vessel material with realistic appearance
    const vesselMaterial = new THREE.MeshPhysicalMaterial({
      color: 0xff1744,
      metalness: 0.1,
      roughness: 0.3,
      transparent: true,
      opacity: opacity,
      side: THREE.DoubleSide,
      clearcoat: 0.5,
      clearcoatRoughness: 0.1,
    });

    const vesselMesh = new THREE.Mesh(tubeGeometry, vesselMaterial);
    vesselMesh.castShadow = true;
    vesselMesh.receiveShadow = true;
    sceneRef.current.add(vesselMesh);
    vesselMeshRef.current = vesselMesh;

    // Create centerline
    if (showCenterline) {
      const centerlineGeometry = new THREE.BufferGeometry().setFromPoints(
        curve.getPoints(centerline.length * 2)
      );
      const centerlineMaterial = new THREE.LineBasicMaterial({
        color: 0x00ff00,
        linewidth: 2
      });
      const centerlineLine = new THREE.Line(centerlineGeometry, centerlineMaterial);
      sceneRef.current.add(centerlineLine);
      centerlineRef.current = centerlineLine;
    }

    // Create pathology markers
    if (showPathologies && vesselData.pathologies) {
      const pathologyGroup = new THREE.Group();
      
      vesselData.pathologies.forEach((pathology, index) => {
        const markerGeometry = new THREE.SphereGeometry(3, 16, 16);
        const markerMaterial = new THREE.MeshBasicMaterial({
          color: pathology.severity === 'critical' ? 0xff0000 :
                 pathology.severity === 'severe' ? 0xff6600 :
                 pathology.severity === 'moderate' ? 0xffcc00 : 0xffff00,
          transparent: true,
          opacity: 0.8
        });
        const marker = new THREE.Mesh(markerGeometry, markerMaterial);
        marker.position.set(
          pathology.location[0],
          pathology.location[1],
          pathology.location[2]
        );
        
        // Add pulsing animation
        marker.userData = { originalScale: 1, pulseSpeed: 2 + index * 0.5 };
        pathologyGroup.add(marker);

        // Add label
        const sprite = createTextSprite(pathology.type);
        sprite.position.copy(marker.position);
        sprite.position.y += 5;
        pathologyGroup.add(sprite);
      });

      sceneRef.current.add(pathologyGroup);
      pathologyMarkersRef.current = pathologyGroup;
    }

    // Center camera on vessel
    const box = new THREE.Box3().setFromObject(vesselMesh);
    const center = box.getCenter(new THREE.Vector3());
    const size = box.getSize(new THREE.Vector3());
    const maxDim = Math.max(size.x, size.y, size.z);
    
    if (cameraRef.current && controlsRef.current) {
      cameraRef.current.position.set(
        center.x + maxDim,
        center.y + maxDim,
        center.z + maxDim * 2
      );
      controlsRef.current.target.copy(center);
      controlsRef.current.update();
    }
  }, [vesselData, opacity, showCenterline, showPathologies]);

  // Create text sprite for labels
  const createTextSprite = (text: string): THREE.Sprite => {
    const canvas = document.createElement('canvas');
    const context = canvas.getContext('2d')!;
    canvas.width = 256;
    canvas.height = 64;
    
    context.fillStyle = 'rgba(0, 0, 0, 0.7)';
    context.fillRect(0, 0, canvas.width, canvas.height);
    
    context.font = 'bold 24px Arial';
    context.fillStyle = 'white';
    context.textAlign = 'center';
    context.fillText(text, canvas.width / 2, canvas.height / 2 + 8);
    
    const texture = new THREE.CanvasTexture(canvas);
    const material = new THREE.SpriteMaterial({ map: texture });
    const sprite = new THREE.Sprite(material);
    sprite.scale.set(20, 5, 1);
    
    return sprite;
  };

  // Update vessel opacity
  useEffect(() => {
    if (vesselMeshRef.current) {
      (vesselMeshRef.current.material as THREE.MeshPhysicalMaterial).opacity = opacity;
    }
  }, [opacity]);

  // Toggle centerline visibility
  useEffect(() => {
    if (centerlineRef.current) {
      centerlineRef.current.visible = showCenterline;
    }
  }, [showCenterline]);

  // Toggle pathology markers
  useEffect(() => {
    if (pathologyMarkersRef.current) {
      pathologyMarkersRef.current.visible = showPathologies;
    }
  }, [showPathologies]);

  // Auto-rotation
  useEffect(() => {
    if (!controlsRef.current) return;
    controlsRef.current.autoRotate = isRotating;
    controlsRef.current.autoRotateSpeed = 2.0;
  }, [isRotating]);

  // Handle window resize
  useEffect(() => {
    const handleResize = () => {
      if (!containerRef.current || !cameraRef.current || !rendererRef.current) return;
      
      const width = containerRef.current.clientWidth;
      const height = containerRef.current.clientHeight;
      
      cameraRef.current.aspect = width / height;
      cameraRef.current.updateProjectionMatrix();
      rendererRef.current.setSize(width, height);
    };

    window.addEventListener('resize', handleResize);
    return () => window.removeEventListener('resize', handleResize);
  }, []);

  // Screenshot functionality
  const takeScreenshot = () => {
    if (!rendererRef.current) return;
    
    const dataURL = rendererRef.current.domElement.toDataURL('image/png');
    const link = document.createElement('a');
    link.download = `vessel-3d-${Date.now()}.png`;
    link.href = dataURL;
    link.click();
  };

  // Reset view
  const resetView = () => {
    if (!cameraRef.current || !controlsRef.current) return;
    
    cameraRef.current.position.set(50, 50, 100);
    controlsRef.current.target.set(0, 0, 0);
    controlsRef.current.update();
  };

  return (
    <Paper elevation={3} sx={{ overflow: 'hidden', borderRadius: 2 }}>
      {/* Header */}
      <Box sx={{ p: 2, bgcolor: 'background.paper', borderBottom: 1, borderColor: 'divider' }}>
        <Box display="flex" justifyContent="space-between" alignItems="center">
          <Typography variant="h6" fontWeight="600">
            3D Vessel Visualization
          </Typography>
          <Box display="flex" gap={1}>
            <Chip 
              label={vesselData?.vesselType || 'Unknown'} 
              color="primary" 
              size="small" 
            />
            <Chip 
              label={`${vesselData?.measurements?.diameter_mm?.toFixed(1)}mm`}
              variant="outlined"
              size="small"
            />
          </Box>
        </Box>
      </Box>

      {/* 3D Viewer */}
      <Box sx={{ position: 'relative', width, height }}>
        <div ref={containerRef} style={{ width: '100%', height: '100%' }} />
        
        {isLoading && (
          <Box
            sx={{
              position: 'absolute',
              top: 0,
              left: 0,
              right: 0,
              bottom: 0,
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              bgcolor: 'rgba(0,0,0,0.5)'
            }}
          >
            <Typography>Loading 3D Model...</Typography>
          </Box>
        )}

        {/* Controls Overlay */}
        <Box
          sx={{
            position: 'absolute',
            top: 16,
            right: 16,
            display: 'flex',
            flexDirection: 'column',
            gap: 1,
            bgcolor: 'rgba(0,0,0,0.7)',
            p: 1,
            borderRadius: 2
          }}
        >
          <Tooltip title="Reset View">
            <IconButton onClick={resetView} size="small" sx={{ color: 'white' }}>
              <RotateLeft />
            </IconButton>
          </Tooltip>
          <Tooltip title={isRotating ? 'Stop Rotation' : 'Auto Rotate'}>
            <IconButton 
              onClick={() => setIsRotating(!isRotating)} 
              size="small"
              sx={{ color: isRotating ? '#4fc3f7' : 'white' }}
            >
              {isRotating ? <Pause /> : <PlayArrow />}
            </IconButton>
          </Tooltip>
          <Tooltip title="Take Screenshot">
            <IconButton onClick={takeScreenshot} size="small" sx={{ color: 'white' }}>
              <CameraAlt />
            </IconButton>
          </Tooltip>
        </Box>
      </Box>

      {/* Bottom Controls */}
      <Box sx={{ p: 2, bgcolor: 'background.paper', borderTop: 1, borderColor: 'divider' }}>
        <Box display="flex" gap={3} alignItems="center" flexWrap="wrap">
          {/* Opacity Control */}
          <Box flex={1} minWidth={200}>
            <Typography variant="caption" color="text.secondary">
              Opacity
            </Typography>
            <Slider
              value={opacity}
              onChange={(_, value) => setOpacity(value as number)}
              min={0.1}
              max={1}
              step={0.1}
              valueLabelDisplay="auto"
            />
          </Box>

          {/* Toggle Buttons */}
          <Box display="flex" gap={1}>
            <Tooltip title="Toggle Centerline">
              <IconButton
                onClick={() => setShowCenterline(!showCenterline)}
                color={showCenterline ? 'primary' : 'default'}
              >
                {showCenterline ? <Visibility /> : <VisibilityOff />}
              </IconButton>
            </Tooltip>
            <Tooltip title="Toggle Pathologies">
              <IconButton
                onClick={() => setShowPathologies(!showPathologies)}
                color={showPathologies ? 'primary' : 'default'}
              >
                {showPathologies ? <Visibility /> : <VisibilityOff />}
              </IconButton>
            </Tooltip>
            <Tooltip title="Measurement Mode">
              <IconButton
                onClick={() => setMeasurementMode(!measurementMode)}
                color={measurementMode ? 'primary' : 'default'}
              >
                <Straighten />
              </IconButton>
            </Tooltip>
          </Box>
        </Box>

        {/* Measurements Display */}
        <Box mt={2} display="flex" gap={2} flexWrap="wrap">
          <Chip 
            label={`Length: ${vesselData?.measurements?.length_mm?.toFixed(1)} mm`}
            variant="outlined"
            size="small"
          />
          <Chip 
            label={`Volume: ${vesselData?.measurements?.volume_ml?.toFixed(2)} ml`}
            variant="outlined"
            size="small"
          />
          <Chip 
            label={`Points: ${vesselData?.centerline?.length || 0}`}
            variant="outlined"
            size="small"
          />
        </Box>
      </Box>
    </Paper>
  );
};

export default Vessel3DViewer;
