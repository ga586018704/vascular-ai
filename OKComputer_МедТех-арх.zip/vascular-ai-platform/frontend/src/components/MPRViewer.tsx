import React, { useEffect, useRef, useState, useCallback } from 'react';
import {
  Box,
  Paper,
  Typography,
  Grid,
  Slider,
  IconButton,
  Tooltip,
  Chip,
  Divider,
  ToggleButtonGroup,
  ToggleButton,
  FormControl,
  InputLabel,
  Select,
  MenuItem
} from '@mui/material';
import {
  ZoomIn, ZoomOut, PanTool, Straighten,
  RotateLeft, RotateRight, Flip, Layers,
  Visibility, VisibilityOff, Settings,
  PlayArrow, Pause, RestartAlt,
  Crop, AspectRatio, ThreeDRotation
} from '@mui/icons-material';

interface MPRViewerProps {
  volumeData: {
    data: number[][][];
    dimensions: [number, number, number];
    spacing: [number, number, number];
    origin: [number, number, number];
  };
  segmentations?: {
    vesselMasks: { [key: string]: number[][][] };
    pathologyMasks?: { [key: string]: number[][][] };
  };
}

type ViewPlane = 'axial' | 'sagittal' | 'coronal' | '3d';

interface ViewState {
  sliceIndex: number;
  zoom: number;
  pan: { x: number; y: number };
  windowWidth: number;
  windowCenter: number;
  rotation: number;
}

const MPRViewer: React.FC<MPRViewerProps> = ({ volumeData, segmentations }) => {
  const canvasRefs = {
    axial: useRef<HTMLCanvasElement>(null),
    sagittal: useRef<HTMLCanvasElement>(null),
    coronal: useRef<HTMLCanvasElement>(null),
    volume3d: useRef<HTMLCanvasElement>(null)
  };

  const [activePlane, setActivePlane] = useState<ViewPlane>('axial');
  const [linkedViews, setLinkedViews] = useState(true);
  const [showSegmentations, setShowSegmentations] = useState(true);
  const [showCrosshairs, setShowCrosshairs] = useState(true);
  const [isPlaying, setIsPlaying] = useState(false);
  const [playbackSpeed, setPlaybackSpeed] = useState(100);

  const [viewStates, setViewStates] = useState<Record<ViewPlane, ViewState>>({
    axial: {
      sliceIndex: Math.floor(volumeData.dimensions[2] / 2),
      zoom: 1,
      pan: { x: 0, y: 0 },
      windowWidth: 400,
      windowCenter: 40
    },
    sagittal: {
      sliceIndex: Math.floor(volumeData.dimensions[0] / 2),
      zoom: 1,
      pan: { x: 0, y: 0 },
      windowWidth: 400,
      windowCenter: 40
    },
    coronal: {
      sliceIndex: Math.floor(volumeData.dimensions[1] / 2),
      zoom: 1,
      pan: { x: 0, y: 0 },
      windowWidth: 400,
      windowCenter: 40
    },
    '3d': {
      sliceIndex: 0,
      zoom: 1,
      pan: { x: 0, y: 0 },
      windowWidth: 400,
      windowCenter: 40
    }
  });

  const [crosshairPosition, setCrosshairPosition] = useState({
    x: Math.floor(volumeData.dimensions[0] / 2),
    y: Math.floor(volumeData.dimensions[1] / 2),
    z: Math.floor(volumeData.dimensions[2] / 2)
  });

  // Apply window/level to pixel value
  const applyWindowLevel = (value: number, windowWidth: number, windowCenter: number): number => {
    const minVal = windowCenter - windowWidth / 2;
    const maxVal = windowCenter + windowWidth / 2;
    
    if (value <= minVal) return 0;
    if (value >= maxVal) return 255;
    
    return ((value - minVal) / windowWidth) * 255;
  };

  // Render axial slice
  const renderAxial = useCallback(() => {
    const canvas = canvasRefs.axial.current;
    if (!canvas) return;

    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const state = viewStates.axial;
    const sliceZ = state.sliceIndex;
    const [width, height] = [volumeData.dimensions[0], volumeData.dimensions[1]];

    canvas.width = width;
    canvas.height = height;

    const imageData = ctx.createImageData(width, height);
    const data = imageData.data;

    // Render slice
    for (let y = 0; y < height; y++) {
      for (let x = 0; x < width; x++) {
        const value = volumeData.data[x][y][sliceZ] || 0;
        const pixelValue = applyWindowLevel(value, state.windowWidth, state.windowCenter);
        
        const idx = (y * width + x) * 4;
        data[idx] = pixelValue;     // R
        data[idx + 1] = pixelValue; // G
        data[idx + 2] = pixelValue; // B
        data[idx + 3] = 255;        // A
      }
    }

    // Overlay segmentations
    if (showSegmentations && segmentations) {
      Object.entries(segmentations.vesselMasks).forEach(([name, mask]) => {
        const color = getVesselColor(name);
        for (let y = 0; y < height; y++) {
          for (let x = 0; x < width; x++) {
            if (mask[x]?.[y]?.[sliceZ]) {
              const idx = (y * width + x) * 4;
              data[idx] = color.r;
              data[idx + 1] = color.g;
              data[idx + 2] = color.b;
              data[idx + 3] = 180; // Semi-transparent
            }
          }
        }
      });
    }

    ctx.putImageData(imageData, 0, 0);

    // Draw crosshairs
    if (showCrosshairs) {
      ctx.strokeStyle = '#00ff00';
      ctx.lineWidth = 1;
      ctx.setLineDash([5, 5]);
      
      // Vertical line
      ctx.beginPath();
      ctx.moveTo(crosshairPosition.x, 0);
      ctx.lineTo(crosshairPosition.x, height);
      ctx.stroke();
      
      // Horizontal line
      ctx.beginPath();
      ctx.moveTo(0, crosshairPosition.y);
      ctx.lineTo(width, crosshairPosition.y);
      ctx.stroke();
      
      ctx.setLineDash([]);
    }
  }, [volumeData, viewStates.axial, crosshairPosition, showSegmentations, showCrosshairs]);

  // Render sagittal slice
  const renderSagittal = useCallback(() => {
    const canvas = canvasRefs.sagittal.current;
    if (!canvas) return;

    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const state = viewStates.sagittal;
    const sliceX = state.sliceIndex;
    const [height, depth] = [volumeData.dimensions[1], volumeData.dimensions[2]];

    canvas.width = depth;
    canvas.height = height;

    const imageData = ctx.createImageData(depth, height);
    const data = imageData.data;

    for (let z = 0; z < depth; z++) {
      for (let y = 0; y < height; y++) {
        const value = volumeData.data[sliceX]?.[y]?.[z] || 0;
        const pixelValue = applyWindowLevel(value, state.windowWidth, state.windowCenter);
        
        const idx = (y * depth + z) * 4;
        data[idx] = pixelValue;
        data[idx + 1] = pixelValue;
        data[idx + 2] = pixelValue;
        data[idx + 3] = 255;
      }
    }

    ctx.putImageData(imageData, 0, 0);

    // Draw crosshairs
    if (showCrosshairs) {
      ctx.strokeStyle = '#00ff00';
      ctx.lineWidth = 1;
      ctx.setLineDash([5, 5]);
      
      ctx.beginPath();
      ctx.moveTo(crosshairPosition.z, 0);
      ctx.lineTo(crosshairPosition.z, height);
      ctx.stroke();
      
      ctx.beginPath();
      ctx.moveTo(0, crosshairPosition.y);
      ctx.lineTo(depth, crosshairPosition.y);
      ctx.stroke();
      
      ctx.setLineDash([]);
    }
  }, [volumeData, viewStates.sagittal, crosshairPosition, showCrosshairs]);

  // Render coronal slice
  const renderCoronal = useCallback(() => {
    const canvas = canvasRefs.coronal.current;
    if (!canvas) return;

    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const state = viewStates.coronal;
    const sliceY = state.sliceIndex;
    const [width, depth] = [volumeData.dimensions[0], volumeData.dimensions[2]];

    canvas.width = width;
    canvas.height = depth;

    const imageData = ctx.createImageData(width, depth);
    const data = imageData.data;

    for (let z = 0; z < depth; z++) {
      for (let x = 0; x < width; x++) {
        const value = volumeData.data[x]?.[sliceY]?.[z] || 0;
        const pixelValue = applyWindowLevel(value, state.windowWidth, state.windowCenter);
        
        const idx = (z * width + x) * 4;
        data[idx] = pixelValue;
        data[idx + 1] = pixelValue;
        data[idx + 2] = pixelValue;
        data[idx + 3] = 255;
      }
    }

    ctx.putImageData(imageData, 0, 0);

    // Draw crosshairs
    if (showCrosshairs) {
      ctx.strokeStyle = '#00ff00';
      ctx.lineWidth = 1;
      ctx.setLineDash([5, 5]);
      
      ctx.beginPath();
      ctx.moveTo(crosshairPosition.x, 0);
      ctx.lineTo(crosshairPosition.x, depth);
      ctx.stroke();
      
      ctx.beginPath();
      ctx.moveTo(0, crosshairPosition.z);
      ctx.lineTo(width, crosshairPosition.z);
      ctx.stroke();
      
      ctx.setLineDash([]);
    }
  }, [volumeData, viewStates.coronal, crosshairPosition, showCrosshairs]);

  // Get color for vessel type
  const getVesselColor = (vesselName: string): { r: number; g: number; b: number } => {
    const colors: { [key: string]: { r: number; g: number; b: number } } = {
      aorta: { r: 255, g: 0, b: 0 },
      carotid: { r: 0, g: 255, b: 0 },
      femoral: { r: 0, g: 0, b: 255 },
      renal: { r: 255, g: 255, b: 0 },
      iliac: { r: 255, g: 0, b: 255 },
      default: { r: 128, g: 128, b: 128 }
    };
    
    for (const [key, color] of Object.entries(colors)) {
      if (vesselName.toLowerCase().includes(key)) return color;
    }
    return colors.default;
  };

  // Update view when state changes
  useEffect(() => {
    renderAxial();
  }, [renderAxial]);

  useEffect(() => {
    renderSagittal();
  }, [renderSagittal]);

  useEffect(() => {
    renderCoronal();
  }, [renderCoronal]);

  // Handle slice change
  const handleSliceChange = (plane: ViewPlane, value: number) => {
    setViewStates(prev => ({
      ...prev,
      [plane]: { ...prev[plane], sliceIndex: value }
    }));

    // Update crosshair position
    if (linkedViews) {
      if (plane === 'axial') {
        setCrosshairPosition(prev => ({ ...prev, z: value }));
      } else if (plane === 'sagittal') {
        setCrosshairPosition(prev => ({ ...prev, x: value }));
      } else if (plane === 'coronal') {
        setCrosshairPosition(prev => ({ ...prev, y: value }));
      }
    }
  };

  // Handle canvas click to update crosshair
  const handleCanvasClick = (plane: ViewPlane, event: React.MouseEvent<HTMLCanvasElement>) => {
    const canvas = event.currentTarget;
    const rect = canvas.getBoundingClientRect();
    const x = Math.floor((event.clientX - rect.left) * (canvas.width / rect.width));
    const y = Math.floor((event.clientY - rect.top) * (canvas.height / rect.height));

    if (plane === 'axial') {
      setCrosshairPosition(prev => ({ ...prev, x, y }));
    } else if (plane === 'sagittal') {
      setCrosshairPosition(prev => ({ ...prev, z: x, y }));
    } else if (plane === 'coronal') {
      setCrosshairPosition(prev => ({ ...prev, x, z: y }));
    }
  };

  // Playback controls
  useEffect(() => {
    if (!isPlaying) return;

    const interval = setInterval(() => {
      setViewStates(prev => {
        const currentPlane = activePlane === '3d' ? 'axial' : activePlane;
        const maxSlice = volumeData.dimensions[currentPlane === 'axial' ? 2 : currentPlane === 'sagittal' ? 0 : 1];
        const nextSlice = (prev[currentPlane].sliceIndex + 1) % maxSlice;
        
        return {
          ...prev,
          [currentPlane]: { ...prev[currentPlane], sliceIndex: nextSlice }
        };
      });
    }, playbackSpeed);

    return () => clearInterval(interval);
  }, [isPlaying, playbackSpeed, activePlane, volumeData.dimensions]);

  const ViewPanel = ({ plane, title }: { plane: ViewPlane; title: string }) => (
    <Paper sx={{ p: 1, height: '100%', display: 'flex', flexDirection: 'column' }}>
      <Box display="flex" justifyContent="space-between" alignItems="center" mb={1}>
        <Typography variant="subtitle2" fontWeight="600">
          {title}
        </Typography>
        <Chip
          label={`${viewStates[plane].sliceIndex + 1} / ${
            plane === 'axial' ? volumeData.dimensions[2] :
            plane === 'sagittal' ? volumeData.dimensions[0] :
            volumeData.dimensions[1]
          }`}
          size="small"
          variant="outlined"
        />
      </Box>
      
      <Box sx={{ flex: 1, bgcolor: 'black', overflow: 'hidden', position: 'relative' }}>
        <canvas
          ref={canvasRefs[plane]}
          onClick={(e) => handleCanvasClick(plane, e)}
          style={{
            width: '100%',
            height: '100%',
            objectFit: 'contain',
            cursor: 'crosshair'
          }}
        />
      </Box>
      
      <Box mt={1}>
        <Slider
          value={viewStates[plane].sliceIndex}
          onChange={(_, value) => handleSliceChange(plane, value as number)}
          min={0}
          max={
            plane === 'axial' ? volumeData.dimensions[2] - 1 :
            plane === 'sagittal' ? volumeData.dimensions[0] - 1 :
            volumeData.dimensions[1] - 1
          }
          size="small"
        />
      </Box>
    </Paper>
  );

  return (
    <Box sx={{ height: '100%', display: 'flex', flexDirection: 'column' }}>
      {/* Toolbar */}
      <Paper sx={{ p: 1, mb: 1 }}>
        <Box display="flex" justifyContent="space-between" alignItems="center" flexWrap="wrap" gap={1}>
          <Box display="flex" gap={1} alignItems="center">
            <ToggleButtonGroup
              value={activePlane}
              exclusive
              onChange={(_, value) => value && setActivePlane(value)}
              size="small"
            >
              <ToggleButton value="axial">
                <AspectRatio sx={{ mr: 0.5 }} />
                Аксиальный
              </ToggleButton>
              <ToggleButton value="sagittal">
                <Crop sx={{ mr: 0.5 }} />
                Сагиттальный
              </ToggleButton>
              <ToggleButton value="coronal">
                <Flip sx={{ mr: 0.5 }} />
                Фронтальный
              </ToggleButton>
              <ToggleButton value="3d">
                <ThreeDRotation sx={{ mr: 0.5 }} />
                3D
              </ToggleButton>
            </ToggleButtonGroup>
            
            <Divider orientation="vertical" flexItem />
            
            <Tooltip title={linkedViews ? 'Синхронизация включена' : 'Синхронизация выключена'}>
              <IconButton
                onClick={() => setLinkedViews(!linkedViews)}
                color={linkedViews ? 'primary' : 'default'}
                size="small"
              >
                <Layers />
              </IconButton>
            </Tooltip>
            
            <Tooltip title={showSegmentations ? 'Сегментация видна' : 'Сегментация скрыта'}>
              <IconButton
                onClick={() => setShowSegmentations(!showSegmentations)}
                color={showSegmentations ? 'primary' : 'default'}
                size="small"
              >
                {showSegmentations ? <Visibility /> : <VisibilityOff />}
              </IconButton>
            </Tooltip>
            
            <Tooltip title={showCrosshairs ? 'Перекрестие видно' : 'Перекрестие скрыто'}>
              <IconButton
                onClick={() => setShowCrosshairs(!showCrosshairs)}
                color={showCrosshairs ? 'primary' : 'default'}
                size="small"
              >
                <Straighten />
              </IconButton>
            </Tooltip>
          </Box>
          
          <Box display="flex" gap={1} alignItems="center">
            <IconButton
              onClick={() => setIsPlaying(!isPlaying)}
              color={isPlaying ? 'primary' : 'default'}
              size="small"
            >
              {isPlaying ? <Pause /> : <PlayArrow />}
            </IconButton>
            
            <FormControl size="small" sx={{ minWidth: 80 }}>
              <InputLabel>Скорость</InputLabel>
              <Select
                value={playbackSpeed}
                onChange={(e) => setPlaybackSpeed(e.target.value as number)}
                label="Скорость"
              >
                <MenuItem value={200}>0.5x</MenuItem>
                <MenuItem value={100}>1x</MenuItem>
                <MenuItem value={50}>2x</MenuItem>
                <MenuItem value={25}>4x</MenuItem>
              </Select>
            </FormControl>
            
            <IconButton size="small">
              <Settings />
            </IconButton>
          </Box>
        </Box>
      </Paper>

      {/* Viewports */}
      <Grid container spacing={1} sx={{ flex: 1 }}>
        <Grid item xs={4}>
          <ViewPanel plane="axial" title="Аксиальный" />
        </Grid>
        <Grid item xs={4}>
          <ViewPanel plane="sagittal" title="Сагиттальный" />
        </Grid>
        <Grid item xs={4}>
          <ViewPanel plane="coronal" title="Фронтальный" />
        </Grid>
      </Grid>

      {/* Window/Level Controls */}
      <Paper sx={{ p: 1, mt: 1 }}>
        <Box display="flex" gap={3} alignItems="center">
          <Box flex={1}>
            <Typography variant="caption" color="text.secondary">
              Window Width (Контраст)
            </Typography>
            <Slider
              value={viewStates[activePlane === '3d' ? 'axial' : activePlane].windowWidth}
              onChange={(_, value) => {
                const plane = activePlane === '3d' ? 'axial' : activePlane;
                setViewStates(prev => ({
                  ...prev,
                  [plane]: { ...prev[plane], windowWidth: value as number }
                }));
              }}
              min={1}
              max={2000}
              valueLabelDisplay="auto"
            />
          </Box>
          
          <Box flex={1}>
            <Typography variant="caption" color="text.secondary">
              Window Center (Яркость)
            </Typography>
            <Slider
              value={viewStates[activePlane === '3d' ? 'axial' : activePlane].windowCenter}
              onChange={(_, value) => {
                const plane = activePlane === '3d' ? 'axial' : activePlane;
                setViewStates(prev => ({
                  ...prev,
                  [plane]: { ...prev[plane], windowCenter: value as number }
                }));
              }}
              min={-1000}
              max={1000}
              valueLabelDisplay="auto"
            />
          </Box>
          
          <Box>
            <Chip
              label={`WW: ${viewStates[activePlane === '3d' ? 'axial' : activePlane].windowWidth}`}
              size="small"
              variant="outlined"
            />
            <Chip
              label={`WC: ${viewStates[activePlane === '3d' ? 'axial' : activePlane].windowCenter}`}
              size="small"
              variant="outlined"
              sx={{ ml: 0.5 }}
            />
          </Box>
        </Box>
      </Paper>
    </Box>
  );
};

export default MPRViewer;
