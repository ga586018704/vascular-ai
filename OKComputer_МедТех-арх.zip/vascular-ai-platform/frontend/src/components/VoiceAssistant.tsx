import React, { useState, useEffect, useRef, useCallback } from 'react';
import {
  Box,
  Paper,
  Typography,
  IconButton,
  Chip,
  TextField,
  List,
  ListItem,
  ListItemText,
  ListItemAvatar,
  Avatar,
  Fade,
  Grow,
  Divider,
  Tooltip,
  Badge
} from '@mui/material';
import {
  Mic,
  MicOff,
  Send,
  SmartToy,
  Person,
  VolumeUp,
  VolumeOff,
  MoreVert,
  AutoAwesome,
  Psychology,
  Science,
  Assessment,
  Description
} from '@mui/icons-material';

interface Message {
  id: string;
  role: 'user' | 'assistant' | 'system';
  content: string;
  timestamp: Date;
  type?: 'text' | 'analysis' | 'report' | 'command';
  metadata?: any;
}

interface VoiceAssistantProps {
  patientId?: string;
  studyId?: string;
  onCommand?: (command: string, params: any) => void;
  onGenerateReport?: () => void;
}

const VoiceAssistant: React.FC<VoiceAssistantProps> = ({
  patientId,
  studyId,
  onCommand,
  onGenerateReport
}) => {
  const [isOpen, setIsOpen] = useState(false);
  const [isListening, setIsListening] = useState(false);
  const [isSpeaking, setIsSpeaking] = useState(false);
  const [messages, setMessages] = useState<Message[]>([
    {
      id: 'welcome',
      role: 'assistant',
      content: 'Здравствуйте! Я ваш AI-ассистент по сосудистой хирургии. Я могу помочь с анализом КТ-ангиографии, генерацией отчетов и ответами на медицинские вопросы.',
      timestamp: new Date(),
      type: 'text'
    }
  ]);
  const [inputText, setInputText] = useState('');
  const [isProcessing, setIsProcessing] = useState(false);
  const [speechEnabled, setSpeechEnabled] = useState(true);
  const [suggestions, setSuggestions] = useState<string[]>([]);
  
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const recognitionRef = useRef<SpeechRecognition | null>(null);
  const synthesisRef = useRef<SpeechSynthesis | null>(null);

  // Initialize speech recognition
  useEffect(() => {
    if ('SpeechRecognition' in window || 'webkitSpeechRecognition' in window) {
      const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
      recognitionRef.current = new SpeechRecognition();
      recognitionRef.current.continuous = false;
      recognitionRef.current.interimResults = true;
      recognitionRef.current.lang = 'ru-RU';
      
      recognitionRef.current.onresult = (event: SpeechRecognitionEvent) => {
        const transcript = event.results[0][0].transcript;
        setInputText(transcript);
        
        if (event.results[0].isFinal) {
          handleSendMessage(transcript);
        }
      };
      
      recognitionRef.current.onerror = (event: SpeechRecognitionErrorEvent) => {
        console.error('Speech recognition error:', event.error);
        setIsListening(false);
      };
      
      recognitionRef.current.onend = () => {
        setIsListening(false);
      };
    }
    
    // Initialize speech synthesis
    if ('speechSynthesis' in window) {
      synthesisRef.current = window.speechSynthesis;
    }
    
    return () => {
      if (recognitionRef.current) {
        recognitionRef.current.stop();
      }
      if (synthesisRef.current) {
        synthesisRef.current.cancel();
      }
    };
  }, []);

  // Auto-scroll to bottom
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  // Toggle voice recognition
  const toggleListening = () => {
    if (!recognitionRef.current) {
      addMessage('system', 'Голосовое управление не поддерживается в этом браузере');
      return;
    }
    
    if (isListening) {
      recognitionRef.current.stop();
      setIsListening(false);
    } else {
      recognitionRef.current.start();
      setIsListening(true);
    }
  };

  // Speak text
  const speak = (text: string) => {
    if (!speechEnabled || !synthesisRef.current) return;
    
    synthesisRef.current.cancel();
    
    const utterance = new SpeechSynthesisUtterance(text);
    utterance.lang = 'ru-RU';
    utterance.rate = 1.0;
    utterance.pitch = 1.0;
    
    utterance.onstart = () => setIsSpeaking(true);
    utterance.onend = () => setIsSpeaking(false);
    utterance.onerror = () => setIsSpeaking(false);
    
    synthesisRef.current.speak(utterance);
  };

  // Add message to chat
  const addMessage = (role: Message['role'], content: string, type: Message['type'] = 'text', metadata?: any) => {
    const newMessage: Message = {
      id: Date.now().toString(),
      role,
      content,
      timestamp: new Date(),
      type,
      metadata
    };
    
    setMessages(prev => [...prev, newMessage]);
    
    if (role === 'assistant' && speechEnabled) {
      speak(content);
    }
  };

  // Process user message
  const processMessage = async (text: string) => {
    setIsProcessing(true);
    
    // Command detection
    const commands = detectCommand(text);
    
    if (commands.length > 0) {
      for (const command of commands) {
        await executeCommand(command);
      }
      setIsProcessing(false);
      return;
    }
    
    // Medical query processing
    try {
      const response = await fetch('/api/agents/assistant', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          query: text,
          patient_id: patientId,
          study_id: studyId,
          context: getConversationContext()
        })
      });
      
      const data = await response.json();
      
      if (data.response) {
        addMessage('assistant', data.response, data.type || 'text', data.metadata);
        
        // Update suggestions
        if (data.suggestions) {
          setSuggestions(data.suggestions);
        }
      }
    } catch (error) {
      addMessage('assistant', 'Извините, произошла ошибка при обработке запроса. Пожалуйста, попробуйте еще раз.');
    }
    
    setIsProcessing(false);
  };

  // Detect commands in text
  const detectCommand = (text: string): string[] => {
    const commands: string[] = [];
    const lowerText = text.toLowerCase();
    
    // Report generation commands
    if (lowerText.includes('отчет') || lowerText.includes('заключение') || 
        lowerText.includes('сформируй') || lowerText.includes('создай отчет')) {
      commands.push('generate_report');
    }
    
    // Analysis commands
    if (lowerText.includes('анализ') || lowerText.includes('проанализируй') ||
        lowerText.includes('что показывает')) {
      commands.push('analyze_study');
    }
    
    // Measurement commands
    if (lowerText.includes('измерь') || lowerText.includes('диаметр') ||
        lowerText.includes('размер')) {
      commands.push('show_measurements');
    }
    
    // 3D view commands
    if (lowerText.includes('3d') || lowerText.includes('трехмерный') ||
        lowerText.includes('объемный')) {
      commands.push('show_3d');
    }
    
    // Comparison commands
    if (lowerText.includes('сравни') || lowerText.includes('сравнение') ||
        lowerText.includes('динамика')) {
      commands.push('compare_studies');
    }
    
    // Pathology commands
    if (lowerText.includes('патология') || lowerText.includes('аневризм') ||
        lowerText.includes('стеноз') || lowerText.includes('тромб')) {
      commands.push('show_pathologies');
    }
    
    // Export commands
    if (lowerText.includes('экспорт') || lowerText.includes('сохрани') ||
        lowerText.includes('скачай')) {
      commands.push('export_data');
    }
    
    return commands;
  };

  // Execute detected command
  const executeCommand = async (command: string) => {
    switch (command) {
      case 'generate_report':
        addMessage('assistant', 'Генерирую медицинский отчет...', 'command');
        onGenerateReport?.();
        break;
        
      case 'analyze_study':
        addMessage('assistant', 'Анализирую КТ-ангиографию...', 'command');
        onCommand?.('analyze', { patient_id: patientId, study_id: studyId });
        break;
        
      case 'show_measurements':
        addMessage('assistant', 'Показываю измерения сосудов...', 'command');
        onCommand?.('show_measurements', {});
        break;
        
      case 'show_3d':
        addMessage('assistant', 'Открываю 3D визуализацию...', 'command');
        onCommand?.('show_3d', {});
        break;
        
      case 'compare_studies':
        addMessage('assistant', 'Открываю сравнение исследований...', 'command');
        onCommand?.('compare', { patient_id: patientId });
        break;
        
      case 'show_pathologies':
        addMessage('assistant', 'Показываю обнаруженные патологии...', 'command');
        onCommand?.('show_pathologies', {});
        break;
        
      case 'export_data':
        addMessage('assistant', 'Подготавливаю данные для экспорта...', 'command');
        onCommand?.('export', { format: 'pdf' });
        break;
        
      default:
        addMessage('assistant', `Выполняю команду: ${command}`);
    }
  };

  // Get conversation context for AI
  const getConversationContext = () => {
    return messages
      .slice(-5)
      .map(m => `${m.role}: ${m.content}`)
      .join('\n');
  };

  // Handle send message
  const handleSendMessage = (text: string = inputText) => {
    if (!text.trim()) return;
    
    addMessage('user', text);
    setInputText('');
    processMessage(text);
  };

  // Quick action buttons
  const quickActions = [
    { label: 'Сгенерировать отчет', icon: <Description />, command: 'generate_report' },
    { label: 'Анализ патологий', icon: <Science />, command: 'show_pathologies' },
    { label: '3D визуализация', icon: <Psychology />, command: 'show_3d' },
    { label: 'Сравнить исследования', icon: <Assessment />, command: 'compare_studies' },
  ];

  if (!isOpen) {
    return (
      <Box
        sx={{
          position: 'fixed',
          bottom: 24,
          right: 24,
          zIndex: 1000
        }}
      >
        <Badge
          color="error"
          variant="dot"
          invisible={!isListening}
        >
          <IconButton
            onClick={() => setIsOpen(true)}
            sx={{
              width: 64,
              height: 64,
              bgcolor: 'primary.main',
              color: 'white',
              boxShadow: '0 4px 20px rgba(0,0,0,0.3)',
              '&:hover': {
                bgcolor: 'primary.dark',
                transform: 'scale(1.1)'
              },
              transition: 'all 0.3s ease'
            }}
          >
            <SmartToy sx={{ fontSize: 32 }} />
          </IconButton>
        </Badge>
      </Box>
    );
  }

  return (
    <Grow in={isOpen}>
      <Paper
        elevation={8}
        sx={{
          position: 'fixed',
          bottom: 24,
          right: 24,
          width: 420,
          height: 600,
          display: 'flex',
          flexDirection: 'column',
          borderRadius: 3,
          overflow: 'hidden',
          zIndex: 1000
        }}
      >
        {/* Header */}
        <Box
          sx={{
            p: 2,
            bgcolor: 'primary.main',
            color: 'white',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'space-between'
          }}
        >
          <Box display="flex" alignItems="center" gap={1}>
            <Avatar sx={{ bgcolor: 'white', color: 'primary.main' }}>
              <SmartToy />
            </Avatar>
            <Box>
              <Typography variant="subtitle1" fontWeight="600">
                VASCULAR AI Assistant
              </Typography>
              <Typography variant="caption" sx={{ opacity: 0.8 }}>
                {isProcessing ? 'Обработка...' : 'Готов к работе'}
              </Typography>
            </Box>
          </Box>
          
          <Box display="flex" gap={1}>
            <Tooltip title={speechEnabled ? 'Выключить голос' : 'Включить голос'}>
              <IconButton
                size="small"
                onClick={() => setSpeechEnabled(!speechEnabled)}
                sx={{ color: 'white' }}
              >
                {speechEnabled ? <VolumeUp /> : <VolumeOff />}
              </IconButton>
            </Tooltip>
            <IconButton
              size="small"
              onClick={() => setIsOpen(false)}
              sx={{ color: 'white' }}
            >
              <MoreVert />
            </IconButton>
          </Box>
        </Box>

        {/* Quick Actions */}
        <Box sx={{ p: 1, bgcolor: 'background.paper', borderBottom: 1, borderColor: 'divider' }}>
          <Box display="flex" gap={1} flexWrap="wrap">
            {quickActions.map((action) => (
              <Chip
                key={action.command}
                icon={action.icon}
                label={action.label}
                onClick={() => executeCommand(action.command)}
                size="small"
                color="primary"
                variant="outlined"
                sx={{ cursor: 'pointer' }}
              />
            ))}
          </Box>
        </Box>

        {/* Messages */}
        <Box sx={{ flex: 1, overflow: 'auto', p: 2, bgcolor: 'background.default' }}>
          <List>
            {messages.map((message) => (
              <Fade key={message.id} in>
                <ListItem
                  alignItems="flex-start"
                  sx={{
                    flexDirection: message.role === 'user' ? 'row-reverse' : 'row',
                    mb: 1
                  }}
                >
                  <ListItemAvatar>
                    <Avatar
                      sx={{
                        bgcolor: message.role === 'assistant' ? 'primary.main' : 
                                  message.role === 'system' ? 'warning.main' : 'secondary.main'
                      }}
                    >
                      {message.role === 'assistant' ? <SmartToy /> : 
                       message.role === 'system' ? <AutoAwesome /> : <Person />}
                    </Avatar>
                  </ListItemAvatar>
                  
                  <Paper
                    sx={{
                      p: 1.5,
                      maxWidth: '75%',
                      bgcolor: message.role === 'user' ? 'primary.main' : 'background.paper',
                      color: message.role === 'user' ? 'white' : 'text.primary',
                      borderRadius: 2
                    }}
                  >
                    <Typography variant="body2">
                      {message.content}
                    </Typography>
                    
                    {message.type === 'analysis' && message.metadata && (
                      <Box mt={1}>
                        <Chip
                          size="small"
                          label={`Уверенность: ${(message.metadata.confidence * 100).toFixed(0)}%`}
                          color="success"
                          variant="outlined"
                        />
                      </Box>
                    )}
                    
                    <Typography variant="caption" sx={{ opacity: 0.6, mt: 0.5, display: 'block' }}>
                      {message.timestamp.toLocaleTimeString()}
                    </Typography>
                  </Paper>
                </ListItem>
              </Fade>
            ))}
            <div ref={messagesEndRef} />
          </List>
        </Box>

        {/* Suggestions */}
        {suggestions.length > 0 && (
          <Box sx={{ p: 1, bgcolor: 'background.paper', borderTop: 1, borderColor: 'divider' }}>
            <Typography variant="caption" color="text.secondary">
              Предложения:
            </Typography>
            <Box display="flex" gap={1} mt={0.5} flexWrap="wrap">
              {suggestions.map((suggestion, index) => (
                <Chip
                  key={index}
                  label={suggestion}
                  size="small"
                  onClick={() => handleSendMessage(suggestion)}
                  sx={{ cursor: 'pointer' }}
                />
              ))}
            </Box>
          </Box>
        )}

        {/* Input */}
        <Box sx={{ p: 2, bgcolor: 'background.paper', borderTop: 1, borderColor: 'divider' }}>
          <Box display="flex" gap={1} alignItems="center">
            <Tooltip title={isListening ? 'Остановить' : 'Голосовой ввод'}>
              <IconButton
                onClick={toggleListening}
                color={isListening ? 'error' : 'default'}
                sx={{
                  animation: isListening ? 'pulse 1.5s infinite' : 'none',
                  '@keyframes pulse': {
                    '0%': { transform: 'scale(1)' },
                    '50%': { transform: 'scale(1.1)' },
                    '100%': { transform: 'scale(1)' }
                  }
                }}
              >
                {isListening ? <Mic /> : <MicOff />}
              </IconButton>
            </Tooltip>
            
            <TextField
              fullWidth
              size="small"
              placeholder="Введите сообщение или используйте голос..."
              value={inputText}
              onChange={(e) => setInputText(e.target.value)}
              onKeyPress={(e) => e.key === 'Enter' && handleSendMessage()}
              disabled={isProcessing}
            />
            
            <IconButton
              onClick={() => handleSendMessage()}
              disabled={!inputText.trim() || isProcessing}
              color="primary"
            >
              <Send />
            </IconButton>
          </Box>
        </Box>
      </Paper>
    </Grow>
  );
};

export default VoiceAssistant;
