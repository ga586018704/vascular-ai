"""
Pathology Reference Guide Page
Searchable reference for vascular pathologies
"""
import React, { useState, useEffect } from 'react';
import {
  Box,
  Card,
  CardContent,
  Typography,
  TextField,
  Grid,
  Chip,
  List,
  ListItem,
  ListItemButton,
  ListItemText,
  Divider,
  Accordion,
  AccordionSummary,
  AccordionDetails,
  Button,
  Tabs,
  Tab,
  Paper,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  Alert,
  CircularProgress,
  IconButton,
  Tooltip,
} from '@mui/material';
import {
  Search as SearchIcon,
  ExpandMore as ExpandMoreIcon,
  Bookmark as BookmarkIcon,
  BookmarkBorder as BookmarkBorderIcon,
  LocalHospital as HospitalIcon,
  Warning as WarningIcon,
  Science as ScienceIcon,
  ArrowForward as ArrowForwardIcon,
} from '@mui/icons-material';
import { useNavigate } from 'react-router-dom';
import { api } from '../services/api';

interface PathologySearchResult {
  code: string;
  name: string;
  name_ru?: string;
  category: string;
  severity: string;
  description: string;
}

interface PathologyDetail {
  code: string;
  name: string;
  name_ru?: string;
  category: string;
  severity: string;
  description: string;
  description_ru?: string;
  anatomy: string[];
  anatomy_ru?: string[];
  symptoms: string[];
  symptoms_ru?: string[];
  signs: string[];
  signs_ru?: string[];
  surgical_indications: string[];
  surgical_indications_ru?: string[];
  surgical_techniques: string[];
  surgical_techniques_ru?: string[];
  complications: string[];
  complications_ru?: string[];
  prognosis?: string;
  prognosis_ru?: string;
  icd10_codes: string[];
  risk_factors: string[];
  risk_factors_ru?: string[];
  treatment_options?: Record<string, any>;
  treatment_options_ru?: Record<string, any>;
  related_conditions: string[];
  synonyms: string[];
}

interface Category {
  key: string;
  name: string;
  name_ru: string;
  count: number;
  icon: string;
}

const getSeverityColor = (severity: string) => {
  switch (severity) {
    case 'critical': return 'error';
    case 'severe': return 'error';
    case 'moderate': return 'warning';
    case 'mild': return 'success';
    default: return 'default';
  }
};

const getCategoryColor = (category: string) => {
  const colors: Record<string, string> = {
    arterial: '#e53935',
    venous: '#1e88e5',
    lymphatic: '#43a047',
    malformation: '#8e24aa',
    tumor: '#fb8c00',
    inflammatory: '#f4511e',
    trauma: '#6d4c41',
    complication: '#546e7a',
  };
  return colors[category] || '#757575';
};

const PathologyGuide: React.FC = () => {
  const navigate = useNavigate();
  const [searchQuery, setSearchQuery] = useState('');
  const [searchResults, setSearchResults] = useState<PathologySearchResult[]>([]);
  const [selectedPathology, setSelectedPathology] = useState<PathologyDetail | null>(null);
  const [categories, setCategories] = useState<Category[]>([]);
  const [activeTab, setActiveTab] = useState(0);
  const [loading, setLoading] = useState(false);
  const [bookmarks, setBookmarks] = useState<string[]>([]);
  const [emergencies, setEmergencies] = useState<any[]>([]);

  useEffect(() => {
    fetchCategories();
    fetchEmergencies();
    
    // Load bookmarks from localStorage
    const saved = localStorage.getItem('pathology_bookmarks');
    if (saved) {
      setBookmarks(JSON.parse(saved));
    }
  }, []);

  const fetchCategories = async () => {
    try {
      const res = await api.get('/pathology-guide/categories');
      setCategories(res.data);
    } catch (err) {
      console.error('Failed to load categories');
    }
  };

  const fetchEmergencies = async () => {
    try {
      const res = await api.get('/pathology-guide/quick-reference/surgical-emergencies');
      setEmergencies(res.data);
    } catch (err) {
      console.error('Failed to load emergencies');
    }
  };

  const handleSearch = async () => {
    if (searchQuery.length < 2) return;
    
    setLoading(true);
    try {
      const res = await api.get(`/pathology-guide/search?query=${encodeURIComponent(searchQuery)}`);
      setSearchResults(res.data);
    } catch (err) {
      console.error('Search failed');
    } finally {
      setLoading(false);
    }
  };

  const handleSelectPathology = async (code: string) => {
    setLoading(true);
    try {
      const res = await api.get(`/pathology-guide/${code}`);
      setSelectedPathology(res.data);
      setActiveTab(1); // Switch to detail tab
    } catch (err) {
      console.error('Failed to load pathology details');
    } finally {
      setLoading(false);
    }
  };

  const toggleBookmark = (code: string) => {
    const newBookmarks = bookmarks.includes(code)
      ? bookmarks.filter(b => b !== code)
      : [...bookmarks, code];
    
    setBookmarks(newBookmarks);
    localStorage.setItem('pathology_bookmarks', JSON.stringify(newBookmarks));
  };

  const renderSearchTab = () => (
    <Box>
      <Box sx={{ display: 'flex', gap: 2, mb: 3 }}>
        <TextField
          fullWidth
          placeholder="Поиск патологии (название, код, симптомы)..."
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
          onKeyPress={(e) => e.key === 'Enter' && handleSearch()}
          InputProps={{
            endAdornment: <SearchIcon color="action" />,
          }}
        />
        <Button
          variant="contained"
          onClick={handleSearch}
          disabled={searchQuery.length < 2}
        >
          Найти
        </Button>
      </Box>

      {loading && (
        <Box display="flex" justifyContent="center" py={4}>
          <CircularProgress />
        </Box>
      )}

      {/* Quick Categories */}
      {!searchResults.length && !loading && (
        <Box>
          <Typography variant="h6" gutterBottom>
            Категории
          </Typography>
          <Grid container spacing={2} sx={{ mb: 4 }}>
            {categories.map((cat) => (
              <Grid item xs={12} sm={6} md={3} key={cat.key}>
                <Card
                  sx={{
                    cursor: 'pointer',
                    borderLeft: `4px solid ${getCategoryColor(cat.key)}`,
                    '&:hover': { boxShadow: 4 },
                  }}
                  onClick={() => navigate(`/pathology-guide/by-category/${cat.key}`)}
                >
                  <CardContent>
                    <Typography variant="h6">{cat.name_ru}</Typography>
                    <Typography variant="body2" color="text.secondary">
                      {cat.count} патологий
                    </Typography>
                  </CardContent>
                </Card>
              </Grid>
            ))}
          </Grid>

          {/* Surgical Emergencies */}
          <Typography variant="h6" gutterBottom sx={{ mt: 4 }}>
            <WarningIcon sx={{ mr: 1, color: 'error.main', verticalAlign: 'middle' }} />
            Хирургические экстренные состояния
          </Typography>
          <TableContainer component={Paper}>
            <Table>
              <TableHead>
                <TableRow>
                  <TableCell>Заболевание</TableCell>
                  <TableCell>Клиническая картина</TableCell>
                  <TableCell>Немедленные действия</TableCell>
                  <TableCell>Летальность</TableCell>
                </TableRow>
              </TableHead>
              <TableBody>
                {emergencies.map((emergency, idx) => (
                  <TableRow key={idx}>
                    <TableCell>
                      <Typography fontWeight="medium">
                        {emergency.name_ru || emergency.name}
                      </Typography>
                    </TableCell>
                    <TableCell>
                      {emergency.presentation?.slice(0, 2).join(', ')}
                    </TableCell>
                    <TableCell>{emergency.immediate_action}</TableCell>
                    <TableCell>
                      <Chip
                        label={emergency.mortality}
                        color="error"
                        size="small"
                      />
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </TableContainer>
        </Box>
      )}

      {/* Search Results */}
      {searchResults.length > 0 && (
        <List>
          {searchResults.map((result) => (
            <React.Fragment key={result.code}>
              <ListItem
                secondaryAction={
                  <IconButton
                    edge="end"
                    onClick={() => toggleBookmark(result.code)}
                  >
                    {bookmarks.includes(result.code) ? (
                      <BookmarkIcon color="primary" />
                    ) : (
                      <BookmarkBorderIcon />
                    )}
                  </IconButton>
                }
              >
                <ListItemButton onClick={() => handleSelectPathology(result.code)}>
                  <ListItemText
                    primary={
                      <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
                        <Typography variant="subtitle1" fontWeight="medium">
                          {result.name_ru || result.name}
                        </Typography>
                        <Chip
                          label={result.code}
                          size="small"
                          variant="outlined"
                        />
                        <Chip
                          label={result.severity}
                          color={getSeverityColor(result.severity) as any}
                          size="small"
                        />
                      </Box>
                    }
                    secondary={result.description}
                  />
                </ListItemButton>
              </ListItem>
              <Divider />
            </React.Fragment>
          ))}
        </List>
      )}
    </Box>
  );

  const renderDetailTab = () => {
    if (!selectedPathology) {
      return (
        <Alert severity="info">
          Выберите патологию из результатов поиска
        </Alert>
      );
    }

    const p = selectedPathology;

    return (
      <Box>
        {/* Header */}
        <Box sx={{ mb: 3 }}>
          <Box sx={{ display: 'flex', alignItems: 'center', gap: 2, mb: 2 }}>
            <Typography variant="h4">
              {p.name_ru || p.name}
            </Typography>
            <IconButton onClick={() => toggleBookmark(p.code)}>
              {bookmarks.includes(p.code) ? (
                <BookmarkIcon color="primary" fontSize="large" />
              ) : (
                <BookmarkBorderIcon fontSize="large" />
              )}
            </IconButton>
          </Box>
          
          <Box sx={{ display: 'flex', gap: 1, flexWrap: 'wrap' }}>
            <Chip label={p.code} color="primary" />
            <Chip label={p.category} variant="outlined" />
            <Chip
              label={p.severity}
              color={getSeverityColor(p.severity) as any}
            />
            {p.icd10_codes?.map((code) => (
              <Chip key={code} label={`ICD-10: ${code}`} size="small" />
            ))}
          </Box>
        </Box>

        {/* Description */}
        <Card sx={{ mb: 3 }}>
          <CardContent>
            <Typography variant="h6" gutterBottom>
              Описание
            </Typography>
            <Typography variant="body1">
              {p.description_ru || p.description}
            </Typography>
          </CardContent>
        </Card>

        {/* Anatomy */}
        {p.anatomy_ru?.length > 0 && (
          <Accordion defaultExpanded>
            <AccordionSummary expandIcon={<ExpandMoreIcon />}>
              <Typography variant="h6">Анатомия</Typography>
            </AccordionSummary>
            <AccordionDetails>
              <Box sx={{ display: 'flex', gap: 1, flexWrap: 'wrap' }}>
                {p.anatomy_ru.map((item, idx) => (
                  <Chip key={idx} label={item} variant="outlined" />
                ))}
              </Box>
            </AccordionDetails>
          </Accordion>
        )}

        {/* Clinical Features */}
        <Accordion defaultExpanded>
          <AccordionSummary expandIcon={<ExpandMoreIcon />}>
            <Typography variant="h6">Клиническая картина</Typography>
          </AccordionSummary>
          <AccordionDetails>
            <Grid container spacing={3}>
              <Grid item xs={12} md={6}>
                <Typography variant="subtitle2" gutterBottom>
                  Симптомы:
                </Typography>
                <ul>
                  {(p.symptoms_ru || p.symptoms).map((s, idx) => (
                    <li key={idx}><Typography variant="body2">{s}</Typography></li>
                  ))}
                </ul>
              </Grid>
              <Grid item xs={12} md={6}>
                <Typography variant="subtitle2" gutterBottom>
                  Объективные признаки:
                </Typography>
                <ul>
                  {(p.signs_ru || p.signs).map((s, idx) => (
                    <li key={idx}><Typography variant="body2">{s}</Typography></li>
                  ))}
                </ul>
              </Grid>
            </Grid>
          </AccordionDetails>
        </Accordion>

        {/* Surgical Indications */}
        {(p.surgical_indications_ru || p.surgical_indications)?.length > 0 && (
          <Accordion>
            <AccordionSummary expandIcon={<ExpandMoreIcon />}>
              <Typography variant="h6">
                <HospitalIcon sx={{ mr: 1, verticalAlign: 'middle' }} />
                Хирургические показания
              </Typography>
            </AccordionSummary>
            <AccordionDetails>
              <ul>
                {(p.surgical_indications_ru || p.surgical_indications).map((item, idx) => (
                  <li key={idx}><Typography variant="body2">{item}</Typography></li>
                ))}
              </ul>
            </AccordionDetails>
          </Accordion>
        )}

        {/* Surgical Techniques */}
        {(p.surgical_techniques_ru || p.surgical_techniques)?.length > 0 && (
          <Accordion>
            <AccordionSummary expandIcon={<ExpandMoreIcon />}>
              <Typography variant="h6">Оперативные техники</Typography>
            </AccordionSummary>
            <AccordionDetails>
              <ul>
                {(p.surgical_techniques_ru || p.surgical_techniques).map((item, idx) => (
                  <li key={idx}><Typography variant="body2">{item}</Typography></li>
                ))}
              </ul>
            </AccordionDetails>
          </Accordion>
        )}

        {/* Complications */}
        {(p.complications_ru || p.complications)?.length > 0 && (
          <Accordion>
            <AccordionSummary expandIcon={<ExpandMoreIcon />}>
              <Typography variant="h6" color="error">
                <WarningIcon sx={{ mr: 1, verticalAlign: 'middle' }} />
                Возможные осложнения
              </Typography>
            </AccordionSummary>
            <AccordionDetails>
              <ul>
                {(p.complications_ru || p.complications).map((item, idx) => (
                  <li key={idx}><Typography variant="body2">{item}</Typography></li>
                ))}
              </ul>
            </AccordionDetails>
          </Accordion>
        )}

        {/* Risk Factors */}
        {(p.risk_factors_ru || p.risk_factors)?.length > 0 && (
          <Accordion>
            <AccordionSummary expandIcon={<ExpandMoreIcon />}>
              <Typography variant="h6">Факторы риска</Typography>
            </AccordionSummary>
            <AccordionDetails>
              <Box sx={{ display: 'flex', gap: 1, flexWrap: 'wrap' }}>
                {(p.risk_factors_ru || p.risk_factors).map((item, idx) => (
                  <Chip key={idx} label={item} color="warning" variant="outlined" />
                ))}
              </Box>
            </AccordionDetails>
          </Accordion>
        )}

        {/* Prognosis */}
        {(p.prognosis_ru || p.prognosis) && (
          <Card sx={{ mt: 3, bgcolor: 'success.light' }}>
            <CardContent>
              <Typography variant="h6" gutterBottom>
                Прогноз
              </Typography>
              <Typography variant="body1">
                {p.prognosis_ru || p.prognosis}
              </Typography>
            </CardContent>
          </Card>
        )}

        {/* Related Conditions */}
        {p.related_conditions?.length > 0 && (
          <Box sx={{ mt: 3 }}>
            <Typography variant="h6" gutterBottom>
              Связанные заболевания
            </Typography>
            <Box sx={{ display: 'flex', gap: 1, flexWrap: 'wrap' }}>
              {p.related_conditions.map((code) => (
                <Button
                  key={code}
                  variant="outlined"
                  size="small"
                  endIcon={<ArrowForwardIcon />}
                  onClick={() => handleSelectPathology(code)}
                >
                  {code}
                </Button>
              ))}
            </Box>
          </Box>
        )}
      </Box>
    );
  };

  const renderBookmarksTab = () => (
    <Box>
      <Typography variant="h6" gutterBottom>
        Избранные патологии
      </Typography>
      {bookmarks.length === 0 ? (
        <Alert severity="info">
          Нет сохранённых патологий. Добавляйте в избранное нажатием на звёздочку.
        </Alert>
      ) : (
        <List>
          {bookmarks.map((code) => (
            <ListItem key={code}>
              <ListItemButton onClick={() => handleSelectPathology(code)}>
                <ListItemText primary={code} />
              </ListItemButton>
              <IconButton onClick={() => toggleBookmark(code)}>
                <BookmarkIcon color="primary" />
              </IconButton>
            </ListItem>
          ))}
        </List>
      )}
    </Box>
  );

  return (
    <Box p={3}>
      <Typography variant="h4" gutterBottom>
        <ScienceIcon sx={{ mr: 1, verticalAlign: 'middle' }} />
        Справочник патологий
      </Typography>

      <Tabs
        value={activeTab}
        onChange={(_, value) => setActiveTab(value)}
        sx={{ mb: 3 }}
      >
        <Tab label="Поиск" />
        <Tab label="Детали" disabled={!selectedPathology} />
        <Tab label={`Избранное (${bookmarks.length})`} />
      </Tabs>

      {activeTab === 0 && renderSearchTab()}
      {activeTab === 1 && renderDetailTab()}
      {activeTab === 2 && renderBookmarksTab()}
    </Box>
  );
};

export default PathologyGuide;
