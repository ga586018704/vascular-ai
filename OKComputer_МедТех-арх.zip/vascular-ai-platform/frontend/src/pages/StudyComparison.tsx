import React, { useState, useEffect } from 'react';
import {
  Box,
  Typography,
  Paper,
  Grid,
  Card,
  CardContent,
  FormControl,
  InputLabel,
  Select,
  MenuItem,
  Button,
  Chip,
  Alert,
  Divider,
  LinearProgress,
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableRow,
  Tooltip,
  IconButton,
  ToggleButtonGroup,
  ToggleButton,
} from '@mui/material';
import {
  CompareArrows as CompareIcon,
  TrendingUp as TrendingUpIcon,
  TrendingDown as TrendingDownIcon,
  TrendingFlat as TrendingFlatIcon,
  Download as DownloadIcon,
  Print as PrintIcon,
  CalendarToday as CalendarIcon,
  Visibility as VisibilityIcon,
} from '@mui/icons-material';
import { useToast } from '../contexts/ToastContext';
import { api } from '../services/api';
import { Line } from 'react-chartjs-2';
import {
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  Title,
  Tooltip as ChartTooltip,
  Legend,
} from 'chart.js';

ChartJS.register(
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  Title,
  ChartTooltip,
  Legend
);

interface Study {
  id: string;
  patient_id: string;
  patient_name: string;
  study_date: string;
  modality: string;
  description: string;
  findings: Finding[];
  measurements: Measurement[];
  status: string;
}

interface Finding {
  id: string;
  type: string;
  location: string;
  severity: string;
  description: string;
  vessel_name: string;
}

interface Measurement {
  vessel_name: string;
  diameter_mm: number;
  length_mm: number;
  volume_ml: number;
}

interface ComparisonResult {
  baseline_study: Study;
  followup_study: Study;
  interval_days: number;
  diameter_changes: DiameterChange[];
  new_findings: Finding[];
  resolved_findings: Finding[];
  progression_summary: string;
  recommendations: string[];
}

interface DiameterChange {
  vessel_name: string;
  baseline_diameter: number;
  followup_diameter: number;
  change_mm: number;
  change_percent: number;
  annual_growth_rate: number;
  significance: 'stable' | 'mild_progression' | 'significant_progression' | 'regression';
}

const StudyComparison: React.FC = () => {
  const { showSuccess, showError } = useToast();
  const [patients, setPatients] = useState<any[]>([]);
  const [selectedPatient, setSelectedPatient] = useState<string>('');
  const [patientStudies, setPatientStudies] = useState<Study[]>([]);
  const [baselineStudy, setBaselineStudy] = useState<string>('');
  const [followupStudy, setFollowupStudy] = useState<string>('');
  const [loading, setLoading] = useState(false);
  const [comparison, setComparison] = useState<ComparisonResult | null>(null);
  const [viewMode, setViewMode] = useState<'side-by-side' | 'overlay' | 'timeline'>('side-by-side');

  // Load patients on mount
  useEffect(() => {
    loadPatients();
  }, []);

  // Load studies when patient selected
  useEffect(() => {
    if (selectedPatient) {
      loadPatientStudies(selectedPatient);
    }
  }, [selectedPatient]);

  const loadPatients = async () => {
    try {
      const response = await api.get('/patients');
      setPatients(response.data);
    } catch (error) {
      showError('Failed to load patients');
    }
  };

  const loadPatientStudies = async (patientId: string) => {
    try {
      const response = await api.get(`/patients/${patientId}/studies`);
      // Sort by date descending
      const sorted = response.data.sort((a: Study, b: Study) => 
        new Date(b.study_date).getTime() - new Date(a.study_date).getTime()
      );
      setPatientStudies(sorted);
      // Auto-select most recent as followup, second most as baseline
      if (sorted.length >= 2) {
        setFollowupStudy(sorted[0].id);
        setBaselineStudy(sorted[1].id);
      }
    } catch (error) {
      showError('Failed to load patient studies');
    }
  };

  const handleCompare = async () => {
    if (!baselineStudy || !followupStudy) {
      showError('Please select both studies');
      return;
    }

    if (baselineStudy === followupStudy) {
      showError('Cannot compare the same study');
      return;
    }

    setLoading(true);
    try {
      const response = await api.post('/studies/compare', {
        baseline_study_id: baselineStudy,
        followup_study_id: followupStudy,
      });
      setComparison(response.data);
      showSuccess('Comparison completed');
    } catch (error) {
      showError('Failed to compare studies');
    } finally {
      setLoading(false);
    }
  };

  const handleExport = () => {
    if (!comparison) return;
    
    const report = {
      patient: patients.find(p => p.id === selectedPatient),
      comparison,
      generated_at: new Date().toISOString(),
    };
    
    const blob = new Blob([JSON.stringify(report, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `comparison-${comparison.baseline_study.patient_id}-${Date.now()}.json`;
    a.click();
    URL.revokeObjectURL(url);
    
    showSuccess('Comparison exported');
  };

  const handlePrint = () => {
    window.print();
  };

  const getSignificanceColor = (significance: string) => {
    switch (significance) {
      case 'stable':
        return 'success';
      case 'mild_progression':
        return 'warning';
      case 'significant_progression':
        return 'error';
      case 'regression':
        return 'info';
      default:
        return 'default';
    }
  };

  const getSignificanceLabel = (significance: string) => {
    switch (significance) {
      case 'stable':
        return 'Stable';
      case 'mild_progression':
        return 'Mild Progression';
      case 'significant_progression':
        return 'Significant Progression';
      case 'regression':
        return 'Regression';
      default:
        return significance;
    }
  };

  const getTrendIcon = (change: number) => {
    if (change > 2) return <TrendingUpIcon color="error" />;
    if (change < -2) return <TrendingDownIcon color="success" />;
    return <TrendingFlatIcon color="info" />;
  };

  // Prepare chart data for diameter trends
  const chartData = comparison ? {
    labels: comparison.diameter_changes.map(d => d.vessel_name),
    datasets: [
      {
        label: 'Baseline (mm)',
        data: comparison.diameter_changes.map(d => d.baseline_diameter),
        borderColor: 'rgb(25, 118, 210)',
        backgroundColor: 'rgba(25, 118, 210, 0.5)',
      },
      {
        label: 'Follow-up (mm)',
        data: comparison.diameter_changes.map(d => d.followup_diameter),
        borderColor: 'rgb(220, 0, 78)',
        backgroundColor: 'rgba(220, 0, 78, 0.5)',
      },
    ],
  } : null;

  return (
    <Box sx={{ p: 3 }}>
      <Typography variant="h4" gutterBottom fontWeight="600">
        Study Comparison
      </Typography>
      <Typography variant="body1" color="text.secondary" gutterBottom>
        Compare CT angiography studies to track disease progression over time
      </Typography>

      {/* Selection Panel */}
      <Paper sx={{ p: 3, mt: 3, mb: 3 }}>
        <Grid container spacing={3} alignItems="center">
          <Grid item xs={12} md={3}>
            <FormControl fullWidth>
              <InputLabel>Patient</InputLabel>
              <Select
                value={selectedPatient}
                onChange={(e) => setSelectedPatient(e.target.value)}
                label="Patient"
              >
                {patients.map((patient) => (
                  <MenuItem key={patient.id} value={patient.id}>
                    {patient.last_name}, {patient.first_name} ({patient.mrn})
                  </MenuItem>
                ))}
              </Select>
            </FormControl>
          </Grid>

          <Grid item xs={12} md={3}>
            <FormControl fullWidth disabled={!selectedPatient || patientStudies.length < 2}>
              <InputLabel>Baseline Study</InputLabel>
              <Select
                value={baselineStudy}
                onChange={(e) => setBaselineStudy(e.target.value)}
                label="Baseline Study"
              >
                {patientStudies.map((study) => (
                  <MenuItem key={study.id} value={study.id}>
                    {new Date(study.study_date).toLocaleDateString()} - {study.description}
                  </MenuItem>
                ))}
              </Select>
            </FormControl>
          </Grid>

          <Grid item xs={12} md={3}>
            <FormControl fullWidth disabled={!selectedPatient || patientStudies.length < 2}>
              <InputLabel>Follow-up Study</InputLabel>
              <Select
                value={followupStudy}
                onChange={(e) => setFollowupStudy(e.target.value)}
                label="Follow-up Study"
              >
                {patientStudies.map((study) => (
                  <MenuItem key={study.id} value={study.id}>
                    {new Date(study.study_date).toLocaleDateString()} - {study.description}
                  </MenuItem>
                ))}
              </Select>
            </FormControl>
          </Grid>

          <Grid item xs={12} md={3}>
            <Button
              variant="contained"
              fullWidth
              startIcon={<CompareIcon />}
              onClick={handleCompare}
              disabled={!baselineStudy || !followupStudy || loading}
              size="large"
            >
              {loading ? 'Comparing...' : 'Compare Studies'}
            </Button>
          </Grid>
        </Grid>

        {loading && <LinearProgress sx={{ mt: 2 }} />}
      </Paper>

      {/* Comparison Results */}
      {comparison && (
        <>
          {/* Summary Card */}
          <Paper sx={{ p: 3, mb: 3 }}>
            <Box display="flex" justifyContent="space-between" alignItems="center" mb={2}>
              <Typography variant="h6">Comparison Summary</Typography>
              <Box>
                <ToggleButtonGroup
                  value={viewMode}
                  exclusive
                  onChange={(_, value) => value && setViewMode(value)}
                  size="small"
                >
                  <ToggleButton value="side-by-side">Side by Side</ToggleButton>
                  <ToggleButton value="overlay">Overlay</ToggleButton>
                  <ToggleButton value="timeline">Timeline</ToggleButton>
                </ToggleButtonGroup>
                <Button
                  startIcon={<DownloadIcon />}
                  onClick={handleExport}
                  sx={{ ml: 1 }}
                >
                  Export
                </Button>
                <Button
                  startIcon={<PrintIcon />}
                  onClick={handlePrint}
                  sx={{ ml: 1 }}
                >
                  Print
                </Button>
              </Box>
            </Box>

            <Grid container spacing={3}>
              <Grid item xs={12} md={3}>
                <Card>
                  <CardContent>
                    <Typography color="text.secondary" gutterBottom>
                      Interval
                    </Typography>
                    <Typography variant="h4">
                      {comparison.interval_days} days
                    </Typography>
                    <Typography variant="body2" color="text.secondary">
                      {Math.round(comparison.interval_days / 30.44)} months
                    </Typography>
                  </CardContent>
                </Card>
              </Grid>

              <Grid item xs={12} md={3}>
                <Card>
                  <CardContent>
                    <Typography color="text.secondary" gutterBottom>
                      New Findings
                    </Typography>
                    <Typography variant="h4" color={comparison.new_findings.length > 0 ? 'error' : 'success'}>
                      {comparison.new_findings.length}
                    </Typography>
                    <Typography variant="body2" color="text.secondary">
                      since baseline
                    </Typography>
                  </CardContent>
                </Card>
              </Grid>

              <Grid item xs={12} md={3}>
                <Card>
                  <CardContent>
                    <Typography color="text.secondary" gutterBottom>
                      Resolved Findings
                    </Typography>
                    <Typography variant="h4" color="success.main">
                      {comparison.resolved_findings.length}
                    </Typography>
                    <Typography variant="body2" color="text.secondary">
                      since baseline
                    </Typography>
                  </CardContent>
                </Card>
              </Grid>

              <Grid item xs={12} md={3}>
                <Card>
                  <CardContent>
                    <Typography color="text.secondary" gutterBottom>
                      Progression
                    </Typography>
                    <Typography variant="h6">
                      {comparison.progression_summary}
                    </Typography>
                  </CardContent>
                </Card>
              </Grid>
            </Grid>
          </Paper>

          {/* Diameter Changes */}
          <Paper sx={{ p: 3, mb: 3 }}>
            <Typography variant="h6" gutterBottom>
              Vessel Diameter Changes
            </Typography>

            {/* Chart */}
            {chartData && (
              <Box sx={{ height: 300, mb: 3 }}>
                <Line
                  data={chartData}
                  options={{
                    responsive: true,
                    maintainAspectRatio: false,
                    plugins: {
                      legend: { position: 'top' },
                      title: { display: false },
                    },
                    scales: {
                      y: {
                        beginAtZero: true,
                        title: { display: true, text: 'Diameter (mm)' },
                      },
                    },
                  }}
                />
              </Box>
            )}

            <Table>
              <TableHead>
                <TableRow>
                  <TableCell>Vessel</TableCell>
                  <TableCell align="right">Baseline (mm)</TableCell>
                  <TableCell align="right">Follow-up (mm)</TableCell>
                  <TableCell align="right">Change (mm)</TableCell>
                  <TableCell align="right">Change (%)</TableCell>
                  <TableCell align="right">Annual Growth</TableCell>
                  <TableCell>Status</TableCell>
                </TableRow>
              </TableHead>
              <TableBody>
                {comparison.diameter_changes.map((change, index) => (
                  <TableRow key={index}>
                    <TableCell>{change.vessel_name}</TableCell>
                    <TableCell align="right">{change.baseline_diameter.toFixed(1)}</TableCell>
                    <TableCell align="right">{change.followup_diameter.toFixed(1)}</TableCell>
                    <TableCell align="right">
                      <Box display="flex" alignItems="center" justifyContent="flex-end" gap={1}>
                        {getTrendIcon(change.change_mm)}
                        {change.change_mm > 0 ? '+' : ''}{change.change_mm.toFixed(1)}
                      </Box>
                    </TableCell>
                    <TableCell align="right">
                      {change.change_percent > 0 ? '+' : ''}{change.change_percent.toFixed(1)}%
                    </TableCell>
                    <TableCell align="right">
                      {change.annual_growth_rate > 0 ? '+' : ''}{change.annual_growth_rate.toFixed(1)} mm/year
                    </TableCell>
                    <TableCell>
                      <Chip
                        label={getSignificanceLabel(change.significance)}
                        color={getSignificanceColor(change.significance) as any}
                        size="small"
                      />
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </Paper>

          {/* New Findings */}
          {comparison.new_findings.length > 0 && (
            <Paper sx={{ p: 3, mb: 3 }}>
              <Typography variant="h6" gutterBottom color="error">
                New Findings
              </Typography>
              <Alert severity="warning" sx={{ mb: 2 }}>
                {comparison.new_findings.length} new finding(s) detected since baseline study
              </Alert>
              <Grid container spacing={2}>
                {comparison.new_findings.map((finding, index) => (
                  <Grid item xs={12} md={6} key={index}>
                    <Card variant="outlined">
                      <CardContent>
                        <Box display="flex" justifyContent="space-between" alignItems="start">
                          <Box>
                            <Typography variant="subtitle1" fontWeight="600">
                              {finding.type}
                            </Typography>
                            <Typography variant="body2" color="text.secondary">
                              {finding.vessel_name} - {finding.location}
                            </Typography>
                            <Typography variant="body2" sx={{ mt: 1 }}>
                              {finding.description}
                            </Typography>
                          </Box>
                          <Chip
                            label={finding.severity}
                            color={finding.severity === 'critical' ? 'error' : finding.severity === 'severe' ? 'warning' : 'info'}
                            size="small"
                          />
                        </Box>
                      </CardContent>
                    </Card>
                  </Grid>
                ))}
              </Grid>
            </Paper>
          )}

          {/* Resolved Findings */}
          {comparison.resolved_findings.length > 0 && (
            <Paper sx={{ p: 3, mb: 3 }}>
              <Typography variant="h6" gutterBottom color="success.main">
                Resolved Findings
              </Typography>
              <Alert severity="success" sx={{ mb: 2 }}>
                {comparison.resolved_findings.length} finding(s) have resolved or improved
              </Alert>
              <Grid container spacing={2}>
                {comparison.resolved_findings.map((finding, index) => (
                  <Grid item xs={12} md={6} key={index}>
                    <Card variant="outlined">
                      <CardContent>
                        <Typography variant="subtitle1" fontWeight="600">
                          {finding.type}
                        </Typography>
                        <Typography variant="body2" color="text.secondary">
                          {finding.vessel_name} - {finding.location}
                        </Typography>
                      </CardContent>
                    </Card>
                  </Grid>
                ))}
              </Grid>
            </Paper>
          )}

          {/* Recommendations */}
          <Paper sx={{ p: 3 }}>
            <Typography variant="h6" gutterBottom>
              Clinical Recommendations
            </Typography>
            <Box component="ul" sx={{ pl: 2 }}>
              {comparison.recommendations.map((rec, index) => (
                <Typography component="li" key={index} sx={{ mb: 1 }}>
                  {rec}
                </Typography>
              ))}
            </Box>
          </Paper>
        </>
      )}
    </Box>
  );
};

export default StudyComparison;
