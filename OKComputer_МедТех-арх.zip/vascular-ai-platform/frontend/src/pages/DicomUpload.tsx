import React, { useCallback, useState } from 'react';
import {
  Box,
  Typography,
  Paper,
  Button,
  List,
  ListItem,
  ListItemIcon,
  ListItemText,
  Alert,
  CircularProgress,
  TextField,
  Chip,
} from '@mui/material';
import {
  CloudUpload,
  CheckCircle,
  Description,
  Delete,
} from '@mui/icons-material';
import { useDropzone } from 'react-dropzone';
import { dicomApi } from '../services/api';

const DicomUpload: React.FC = () => {
  const [files, setFiles] = useState<File[]>([]);
  const [patientMrn, setPatientMrn] = useState('');
  const [studyDescription, setStudyDescription] = useState('');
  const [uploading, setUploading] = useState(false);
  const [result, setResult] = useState<any>(null);
  const [error, setError] = useState<string | null>(null);

  const onDrop = useCallback((acceptedFiles: File[]) => {
    setFiles((prev) => [...prev, ...acceptedFiles]);
    setError(null);
  }, []);

  const { getRootProps, getInputProps, isDragActive } = useDropzone({
    onDrop,
    accept: {
      'application/dicom': ['.dcm', '.dicom'],
      'application/zip': ['.zip'],
    },
    multiple: true,
  });

  const removeFile = (index: number) => {
    setFiles((prev) => prev.filter((_, i) => i !== index));
  };

  const handleUpload = async () => {
    if (files.length === 0) {
      setError('Please select at least one file');
      return;
    }

    setUploading(true);
    setError(null);

    try {
      const formData = new FormData();
      files.forEach((file) => formData.append('files', file));
      if (patientMrn) formData.append('patient_mrn', patientMrn);
      if (studyDescription) formData.append('study_description', studyDescription);

      const response = await dicomApi.upload(formData);
      setResult(response.data);
      setFiles([]);
    } catch (err: any) {
      setError(err.response?.data?.detail || 'Upload failed');
    } finally {
      setUploading(false);
    }
  };

  const formatFileSize = (bytes: number) => {
    if (bytes < 1024) return bytes + ' B';
    if (bytes < 1024 * 1024) return (bytes / 1024).toFixed(2) + ' KB';
    return (bytes / (1024 * 1024)).toFixed(2) + ' MB';
  };

  return (
    <Box>
      <Typography variant="h4" gutterBottom fontWeight="bold">
        DICOM Upload
      </Typography>
      <Typography variant="body1" color="text.secondary" paragraph>
        Upload CT angiography DICOM files for analysis and storage.
      </Typography>

      {result && (
        <Alert severity="success" sx={{ mb: 3 }}>
          Upload successful! Study ID: {result.study_id}
        </Alert>
      )}

      {error && (
        <Alert severity="error" sx={{ mb: 3 }}>
          {error}
        </Alert>
      )}

      <Paper sx={{ p: 3, mb: 3 }}>
        <TextField
          fullWidth
          label="Patient MRN (optional)"
          value={patientMrn}
          onChange={(e) => setPatientMrn(e.target.value)}
          sx={{ mb: 2 }}
        />
        <TextField
          fullWidth
          label="Study Description (optional)"
          value={studyDescription}
          onChange={(e) => setStudyDescription(e.target.value)}
        />
      </Paper>

      <Paper
        {...getRootProps()}
        sx={{
          p: 4,
          textAlign: 'center',
          border: '2px dashed',
          borderColor: isDragActive ? 'primary.main' : 'grey.300',
          bgcolor: isDragActive ? 'primary.50' : 'background.paper',
          cursor: 'pointer',
          transition: 'all 0.2s',
          mb: 3,
        }}
      >
        <input {...getInputProps()} />
        <CloudUpload sx={{ fontSize: 64, color: 'primary.main', mb: 2 }} />
        <Typography variant="h6" gutterBottom>
          {isDragActive ? 'Drop files here' : 'Drag & drop DICOM files'}
        </Typography>
        <Typography variant="body2" color="text.secondary">
          or click to browse. Supported: DCM, DICOM, ZIP
        </Typography>
      </Paper>

      {files.length > 0 && (
        <Paper sx={{ p: 3, mb: 3 }}>
          <Typography variant="h6" gutterBottom>
            Selected Files ({files.length})
          </Typography>
          <List dense>
            {files.map((file, index) => (
              <ListItem
                key={index}
                secondaryAction={
                  <Button
                    size="small"
                    color="error"
                    startIcon={<Delete />}
                    onClick={() => removeFile(index)}
                  >
                    Remove
                  </Button>
                }
              >
                <ListItemIcon>
                  <Description color="primary" />
                </ListItemIcon>
                <ListItemText
                  primary={file.name}
                  secondary={formatFileSize(file.size)}
                />
              </ListItem>
            ))}
          </List>
          <Box sx={{ mt: 2, display: 'flex', gap: 2 }}>
            <Button
              variant="contained"
              onClick={handleUpload}
              disabled={uploading}
              startIcon={uploading ? <CircularProgress size={20} /> : <CloudUpload />}
            >
              {uploading ? 'Uploading...' : 'Upload Files'}
            </Button>
            <Button variant="outlined" onClick={() => setFiles([])}>
              Clear All
            </Button>
          </Box>
        </Paper>
      )}
    </Box>
  );
};

export default DicomUpload;
