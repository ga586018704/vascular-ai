import React, { useState } from 'react';
import {
  Box,
  Typography,
  Grid,
  Card,
  CardContent,
  TextField,
  Button,
  Paper,
  Alert,
  Chip,
  FormControlLabel,
  Checkbox,
  Divider,
  Tabs,
  Tab,
} from '@mui/material';
import { Calculate, TrendingUp, Warning } from '@mui/icons-material';
import { calculatorsApi } from '../services/api';

interface CalculatorResult {
  score: number;
  risk_category?: string;
  mortality_risk?: string;
  probability?: string;
  recommendation?: string;
  interpretation?: string;
  aaa_risk_10yr?: string;
}

const RiskCalculators: React.FC = () => {
  const [activeTab, setActiveTab] = useState(0);
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState<CalculatorResult | null>(null);
  const [error, setError] = useState<string | null>(null);

  // VSGNE form state
  const [vsgneData, setVsgneData] = useState({
    age: 65,
    cad: false,
    chf: false,
    copd: false,
    diabetes: false,
    creatinine: 1.0,
    urgent_procedure: false,
  });

  // Wells form state
  const [wellsData, setWellsData] = useState({
    active_cancer: false,
    bedridden_recently: false,
    calf_swelling: false,
    collateral_veins: false,
    entire_leg_swollen: false,
    localized_tenderness: false,
    pitting_edema: false,
    paralysis_paresis: false,
    previous_dvt: false,
    alternative_diagnosis_less_likely: false,
  });

  // GAS form state
  const [gasData, setGasData] = useState({
    age: 65,
    gender: 'M',
    bmi: 25,
    hypertension: false,
    diabetes: false,
    smoking: false,
    family_history: false,
  });

  const handleCalculateVSGNE = async () => {
    setLoading(true);
    setError(null);
    try {
      const response = await calculatorsApi.calculateVSGNE(vsgneData);
      setResult(response.data);
    } catch (err: any) {
      setError(err.response?.data?.detail || 'Calculation failed');
    } finally {
      setLoading(false);
    }
  };

  const handleCalculateWells = async () => {
    setLoading(true);
    setError(null);
    try {
      const response = await calculatorsApi.calculateWells(wellsData);
      setResult(response.data);
    } catch (err: any) {
      setError(err.response?.data?.detail || 'Calculation failed');
    } finally {
      setLoading(false);
    }
  };

  const handleCalculateGAS = async () => {
    setLoading(true);
    setError(null);
    try {
      const response = await calculatorsApi.calculateGAS(gasData);
      setResult(response.data);
    } catch (err: any) {
      setError(err.response?.data?.detail || 'Calculation failed');
    } finally {
      setLoading(false);
    }
  };

  const getRiskColor = (category?: string) => {
    if (!category) return 'default';
    if (category.toLowerCase().includes('low')) return 'success';
    if (category.toLowerCase().includes('moderate')) return 'warning';
    if (category.toLowerCase().includes('high')) return 'error';
    return 'default';
  };

  const renderVSGNE = () => (
    <Grid container spacing={3}>
      <Grid item xs={12} md={6}>
        <TextField
          fullWidth
          label="Age"
          type="number"
          value={vsgneData.age}
          onChange={(e) => setVsgneData({ ...vsgneData, age: parseInt(e.target.value) })}
          sx={{ mb: 2 }}
        />
        <TextField
          fullWidth
          label="Creatinine (mg/dL)"
          type="number"
          step="0.1"
          value={vsgneData.creatinine}
          onChange={(e) =>
            setVsgneData({ ...vsgneData, creatinine: parseFloat(e.target.value) })
          }
          sx={{ mb: 2 }}
        />
        <Grid container spacing={2}>
          {[
            { key: 'cad', label: 'Coronary Artery Disease' },
            { key: 'chf', label: 'CHF' },
            { key: 'copd', label: 'COPD' },
            { key: 'diabetes', label: 'Diabetes' },
            { key: 'urgent_procedure', label: 'Urgent Procedure' },
          ].map((item) => (
            <Grid item xs={12} sm={6} key={item.key}>
              <FormControlLabel
                control={
                  <Checkbox
                    checked={vsgneData[item.key as keyof typeof vsgneData] as boolean}
                    onChange={(e) =>
                      setVsgneData({ ...vsgneData, [item.key]: e.target.checked })
                    }
                  />
                }
                label={item.label}
              />
            </Grid>
          ))}
        </Grid>
        <Button
          variant="contained"
          onClick={handleCalculateVSGNE}
          disabled={loading}
          startIcon={<Calculate />}
          sx={{ mt: 2 }}
        >
          Calculate VSGNE Score
        </Button>
      </Grid>
      <Grid item xs={12} md={6}>
        {result && activeTab === 0 && (
          <Paper sx={{ p: 3, bgcolor: 'grey.50' }}>
            <Typography variant="h4" align="center" gutterBottom>
              {result.score}
            </Typography>
            <Typography variant="subtitle1" align="center" gutterBottom>
              VSGNE Score
            </Typography>
            <Divider sx={{ my: 2 }} />
            <Box sx={{ textAlign: 'center' }}>
              <Chip
                label={result.risk_category}
                color={getRiskColor(result.risk_category)}
                size="medium"
                sx={{ mb: 1 }}
              />
              <Typography variant="body2" color="text.secondary">
                30-day mortality: {result.mortality_risk}
              </Typography>
            </Box>
            <Alert severity="info" sx={{ mt: 2 }}>
              {result.interpretation}
            </Alert>
          </Paper>
        )}
      </Grid>
    </Grid>
  );

  const renderWells = () => (
    <Grid container spacing={3}>
      <Grid item xs={12} md={6}>
        <Grid container spacing={2}>
          {[
            { key: 'active_cancer', label: 'Active Cancer' },
            { key: 'bedridden_recently', label: 'Bedridden Recently' },
            { key: 'calf_swelling', label: 'Calf Swelling' },
            { key: 'collateral_veins', label: 'Collateral Veins' },
            { key: 'entire_leg_swollen', label: 'Entire Leg Swollen' },
            { key: 'localized_tenderness', label: 'Localized Tenderness' },
            { key: 'pitting_edema', label: 'Pitting Edema' },
            { key: 'paralysis_paresis', label: 'Paralysis/Paresis' },
            { key: 'previous_dvt', label: 'Previous DVT' },
            { key: 'alternative_diagnosis_less_likely', label: 'Alternative Dx Less Likely' },
          ].map((item) => (
            <Grid item xs={12} sm={6} key={item.key}>
              <FormControlLabel
                control={
                  <Checkbox
                    checked={wellsData[item.key as keyof typeof wellsData] as boolean}
                    onChange={(e) =>
                      setWellsData({ ...wellsData, [item.key]: e.target.checked })
                    }
                  />
                }
                label={item.label}
              />
            </Grid>
          ))}
        </Grid>
        <Button
          variant="contained"
          onClick={handleCalculateWells}
          disabled={loading}
          startIcon={<Calculate />}
          sx={{ mt: 2 }}
        >
          Calculate Wells Score
        </Button>
      </Grid>
      <Grid item xs={12} md={6}>
        {result && activeTab === 1 && (
          <Paper sx={{ p: 3, bgcolor: 'grey.50' }}>
            <Typography variant="h4" align="center" gutterBottom>
              {result.score}
            </Typography>
            <Typography variant="subtitle1" align="center" gutterBottom>
              Wells Score
            </Typography>
            <Divider sx={{ my: 2 }} />
            <Box sx={{ textAlign: 'center' }}>
              <Chip
                label={result.probability}
                color={getRiskColor(result.probability)}
                size="medium"
                sx={{ mb: 1 }}
              />
            </Box>
            <Alert severity="info" sx={{ mt: 2 }}>
              {result.recommendation}
            </Alert>
          </Paper>
        )}
      </Grid>
    </Grid>
  );

  const renderGAS = () => (
    <Grid container spacing={3}>
      <Grid item xs={12} md={6}>
        <TextField
          fullWidth
          label="Age"
          type="number"
          value={gasData.age}
          onChange={(e) => setGasData({ ...gasData, age: parseInt(e.target.value) })}
          sx={{ mb: 2 }}
        />
        <TextField
          fullWidth
          label="BMI"
          type="number"
          value={gasData.bmi}
          onChange={(e) => setGasData({ ...gasData, bmi: parseFloat(e.target.value) })}
          sx={{ mb: 2 }}
        />
        <Grid container spacing={2}>
          {[
            { key: 'hypertension', label: 'Hypertension' },
            { key: 'diabetes', label: 'Diabetes' },
            { key: 'smoking', label: 'Smoking' },
            { key: 'family_history', label: 'Family History of AAA' },
          ].map((item) => (
            <Grid item xs={12} sm={6} key={item.key}>
              <FormControlLabel
                control={
                  <Checkbox
                    checked={gasData[item.key as keyof typeof gasData] as boolean}
                    onChange={(e) =>
                      setGasData({ ...gasData, [item.key]: e.target.checked })
                    }
                  />
                }
                label={item.label}
              />
            </Grid>
          ))}
        </Grid>
        <Button
          variant="contained"
          onClick={handleCalculateGAS}
          disabled={loading}
          startIcon={<Calculate />}
          sx={{ mt: 2 }}
        >
          Calculate GAS Score
        </Button>
      </Grid>
      <Grid item xs={12} md={6}>
        {result && activeTab === 2 && (
          <Paper sx={{ p: 3, bgcolor: 'grey.50' }}>
            <Typography variant="h4" align="center" gutterBottom>
              {result.score}
            </Typography>
            <Typography variant="subtitle1" align="center" gutterBottom>
              GAS Score
            </Typography>
            <Divider sx={{ my: 2 }} />
            <Box sx={{ textAlign: 'center' }}>
              <Chip
                label={result.risk_category}
                color={getRiskColor(result.risk_category)}
                size="medium"
                sx={{ mb: 1 }}
              />
              <Typography variant="body2" color="text.secondary">
                10-year AAA risk: {result.aaa_risk_10yr}
              </Typography>
            </Box>
          </Paper>
        )}
      </Grid>
    </Grid>
  );

  return (
    <Box>
      <Typography variant="h4" gutterBottom fontWeight="bold">
        <Calculate sx={{ mr: 1, verticalAlign: 'middle' }} />
        Risk Calculators
      </Typography>
      <Typography variant="body1" color="text.secondary" paragraph>
        Calculate medical risk scores for surgical planning and patient assessment.
      </Typography>

      {error && (
        <Alert severity="error" sx={{ mb: 3 }}>
          {error}
        </Alert>
      )}

      <Paper sx={{ mb: 3 }}>
        <Tabs
          value={activeTab}
          onChange={(_, newValue) => {
            setActiveTab(newValue);
            setResult(null);
          }}
          variant="scrollable"
          scrollButtons="auto"
        >
          <Tab label="VSGNE Score" />
          <Tab label="Wells Score (DVT)" />
          <Tab label="Global Aortic Score" />
        </Tabs>
      </Paper>

      <Paper sx={{ p: 3 }}>
        {activeTab === 0 && renderVSGNE()}
        {activeTab === 1 && renderWells()}
        {activeTab === 2 && renderGAS()}
      </Paper>
    </Box>
  );
};

export default RiskCalculators;
