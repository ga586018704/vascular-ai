import React, { useEffect, useState } from 'react';
import {
  Box,
  Grid,
  Card,
  CardContent,
  Typography,
  Button,
  List,
  ListItem,
  ListItemText,
  Chip,
  CircularProgress,
} from '@mui/material';
import {
  People,
  Assessment,
  TrendingUp,
  Storage,
  CloudUpload,
  Psychology,
  Calculate,
  ArrowForward,
} from '@mui/icons-material';
import { useNavigate } from 'react-router-dom';
import { analyticsApi, dicomApi, reportsApi } from '../services/api';

interface DashboardStats {
  total_patients: number;
  total_studies: number;
  total_reports: number;
  today_studies: number;
  today_reports: number;
}

const Dashboard: React.FC = () => {
  const navigate = useNavigate();
  const [stats, setStats] = useState<DashboardStats | null>(null);
  const [loading, setLoading] = useState(true);
  const [recentStudies, setRecentStudies] = useState<any[]>([]);
  const [recentReports, setRecentReports] = useState<any[]>([]);

  useEffect(() => {
    loadDashboardData();
  }, []);

  const loadDashboardData = async () => {
    try {
      const [statsRes, studiesRes, reportsRes] = await Promise.all([
        analyticsApi.getDashboard(),
        dicomApi.getStudies({ limit: 5 }),
        reportsApi.getReports({ limit: 5 }),
      ]);
      setStats(statsRes.data);
      setRecentStudies(studiesRes.data);
      setRecentReports(reportsRes.data);
    } catch (error) {
      console.error('Failed to load dashboard data:', error);
    } finally {
      setLoading(false);
    }
  };

  const quickActions = [
    {
      title: 'Upload DICOM',
      description: 'Upload new CT angiography study',
      icon: <CloudUpload />,
      path: '/dicom/upload',
      color: '#1976d2',
    },
    {
      title: 'CT Angiography',
      description: 'Analyze vessel pathologies',
      icon: <Assessment />,
      path: '/angiography',
      color: '#2e7d32',
    },
    {
      title: 'AI Agents',
      description: 'Get AI-powered analysis',
      icon: <Psychology />,
      path: '/agents',
      color: '#ed6c02',
    },
    {
      title: 'Risk Calculators',
      description: 'Calculate surgical risk scores',
      icon: <Calculate />,
      path: '/calculators',
      color: '#9c27b0',
    },
  ];

  if (loading) {
    return (
      <Box display="flex" justifyContent="center" alignItems="center" minHeight="60vh">
        <CircularProgress />
      </Box>
    );
  }

  return (
    <Box>
      <Typography variant="h4" gutterBottom fontWeight="bold">
        Dashboard
      </Typography>

      {/* Stats Cards */}
      <Grid container spacing={3} sx={{ mb: 4 }}>
        <Grid item xs={12} sm={6} md={3}>
          <Card>
            <CardContent>
              <Box display="flex" alignItems="center" justifyContent="space-between">
                <Box>
                  <Typography color="textSecondary" gutterBottom variant="overline">
                    Total Patients
                  </Typography>
                  <Typography variant="h4" fontWeight="bold">
                    {stats?.total_patients || 0}
                  </Typography>
                </Box>
                <People sx={{ color: '#1976d2', fontSize: 40 }} />
              </Box>
            </CardContent>
          </Card>
        </Grid>
        <Grid item xs={12} sm={6} md={3}>
          <Card>
            <CardContent>
              <Box display="flex" alignItems="center" justifyContent="space-between">
                <Box>
                  <Typography color="textSecondary" gutterBottom variant="overline">
                    Total Studies
                  </Typography>
                  <Typography variant="h4" fontWeight="bold">
                    {stats?.total_studies || 0}
                  </Typography>
                  <Typography variant="caption" color="textSecondary">
                    +{stats?.today_studies || 0} today
                  </Typography>
                </Box>
                <Storage sx={{ color: '#2e7d32', fontSize: 40 }} />
              </Box>
            </CardContent>
          </Card>
        </Grid>
        <Grid item xs={12} sm={6} md={3}>
          <Card>
            <CardContent>
              <Box display="flex" alignItems="center" justifyContent="space-between">
                <Box>
                  <Typography color="textSecondary" gutterBottom variant="overline">
                    Total Reports
                  </Typography>
                  <Typography variant="h4" fontWeight="bold">
                    {stats?.total_reports || 0}
                  </Typography>
                  <Typography variant="caption" color="textSecondary">
                    +{stats?.today_reports || 0} today
                  </Typography>
                </Box>
                <TrendingUp sx={{ color: '#ed6c02', fontSize: 40 }} />
              </Box>
            </CardContent>
          </Card>
        </Grid>
        <Grid item xs={12} sm={6} md={3}>
          <Card>
            <CardContent>
              <Box display="flex" alignItems="center" justifyContent="space-between">
                <Box>
                  <Typography color="textSecondary" gutterBottom variant="overline">
                    Active Users
                  </Typography>
                  <Typography variant="h4" fontWeight="bold">
                    {stats?.total_users || 1}
                  </Typography>
                </Box>
                <People sx={{ color: '#9c27b0', fontSize: 40 }} />
              </Box>
            </CardContent>
          </Card>
        </Grid>
      </Grid>

      {/* Quick Actions */}
      <Typography variant="h6" gutterBottom>
        Quick Actions
      </Typography>
      <Grid container spacing={3} sx={{ mb: 4 }}>
        {quickActions.map((action) => (
          <Grid item xs={12} sm={6} md={3} key={action.title}>
            <Card
              sx={{
                cursor: 'pointer',
                transition: 'transform 0.2s',
                '&:hover': { transform: 'translateY(-4px)' },
              }}
              onClick={() => navigate(action.path)}
            >
              <CardContent>
                <Box display="flex" alignItems="center" gap={2}>
                  <Box
                    sx={{
                      p: 1.5,
                      borderRadius: 2,
                      bgcolor: `${action.color}20`,
                      color: action.color,
                    }}
                  >
                    {action.icon}
                  </Box>
                  <Box>
                    <Typography variant="subtitle1" fontWeight="medium">
                      {action.title}
                    </Typography>
                    <Typography variant="caption" color="textSecondary">
                      {action.description}
                    </Typography>
                  </Box>
                </Box>
              </CardContent>
            </Card>
          </Grid>
        ))}
      </Grid>

      {/* Recent Activity */}
      <Grid container spacing={3}>
        <Grid item xs={12} md={6}>
          <Card>
            <CardContent>
              <Box display="flex" justifyContent="space-between" alignItems="center" mb={2}>
                <Typography variant="h6">Recent Studies</Typography>
                <Button
                  size="small"
                  endIcon={<ArrowForward />}
                  onClick={() => navigate('/dicom/upload')}
                >
                  View All
                </Button>
              </Box>
              <List dense>
                {recentStudies.map((study) => (
                  <ListItem key={study.study_instance_uid} divider>
                    <ListItemText
                      primary={study.study_description || 'Unknown Study'}
                      secondary={
                        <Box>
                          <Typography variant="caption" display="block">
                            {study.patient_name || 'Unknown Patient'}
                          </Typography>
                          <Chip
                            label={study.status}
                            size="small"
                            color={
                              study.status === 'completed'
                                ? 'success'
                                : study.status === 'processing'
                                ? 'warning'
                                : 'default'
                            }
                            sx={{ mt: 0.5 }}
                          />
                        </Box>
                      }
                    />
                  </ListItem>
                ))}
              </List>
            </CardContent>
          </Card>
        </Grid>
        <Grid item xs={12} md={6}>
          <Card>
            <CardContent>
              <Box display="flex" justifyContent="space-between" alignItems="center" mb={2}>
                <Typography variant="h6">Recent Reports</Typography>
                <Button
                  size="small"
                  endIcon={<ArrowForward />}
                  onClick={() => navigate('/reports')}
                >
                  View All
                </Button>
              </Box>
              <List dense>
                {recentReports.map((report) => (
                  <ListItem key={report.report_id} divider>
                    <ListItemText
                      primary={report.title}
                      secondary={
                        <Box>
                          <Typography variant="caption" display="block">
                            {report.patient_name || 'Unknown Patient'} • {report.author_name}
                          </Typography>
                          <Chip
                            label={report.status}
                            size="small"
                            color={
                              report.status === 'finalized'
                                ? 'success'
                                : report.status === 'draft'
                                ? 'default'
                                : 'warning'
                            }
                            sx={{ mt: 0.5 }}
                          />
                        </Box>
                      }
                    />
                  </ListItem>
                ))}
              </List>
            </CardContent>
          </Card>
        </Grid>
      </Grid>
    </Box>
  );
};

export default Dashboard;
