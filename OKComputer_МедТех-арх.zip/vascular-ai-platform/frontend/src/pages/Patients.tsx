import React, { useState, useEffect } from 'react';
import {
  Box,
  Typography,
  Button,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  TextField,
  Grid,
  Chip,
  IconButton,
  Tooltip,
  Fab,
} from '@mui/material';
import {
  Add,
  Edit,
  Delete,
  Visibility,
  People,
} from '@mui/icons-material';
import { api } from '../services/api';
import { useToast } from '../contexts/ToastContext';
import DataTable from '../components/DataTable';
import ConfirmDialog from '../components/ConfirmDialog';
import LoadingScreen from '../components/LoadingScreen';

interface Patient {
  id: number;
  mrn: string;
  full_name: string;
  date_of_birth: string;
  age: number;
  gender: string;
  phone?: string;
  email?: string;
  created_at: string;
}

interface PatientFormData {
  mrn: string;
  first_name: string;
  last_name: string;
  middle_name: string;
  date_of_birth: string;
  gender: string;
  phone: string;
  email: string;
  address: string;
}

const Patients: React.FC = () => {
  const { showSuccess, showError } = useToast();
  const [patients, setPatients] = useState<Patient[]>([]);
  const [loading, setLoading] = useState(true);
  const [dialogOpen, setDialogOpen] = useState(false);
  const [editingPatient, setEditingPatient] = useState<Patient | null>(null);
  const [deleteDialogOpen, setDeleteDialogOpen] = useState(false);
  const [patientToDelete, setPatientToDelete] = useState<Patient | null>(null);
  const [formData, setFormData] = useState<PatientFormData>({
    mrn: '',
    first_name: '',
    last_name: '',
    middle_name: '',
    date_of_birth: '',
    gender: 'M',
    phone: '',
    email: '',
    address: '',
  });

  useEffect(() => {
    loadPatients();
  }, []);

  const loadPatients = async () => {
    try {
      setLoading(true);
      // TODO: Replace with actual API endpoint when available
      // const response = await api.get('/patients');
      // setPatients(response.data);
      
      // Mock data for now
      setPatients([
        {
          id: 1,
          mrn: 'MRN001',
          full_name: 'Ivanov Ivan Ivanovich',
          date_of_birth: '1965-03-15',
          age: 59,
          gender: 'M',
          phone: '+7 (999) 123-45-67',
          email: 'ivanov@example.com',
          created_at: '2024-01-15T10:30:00Z',
        },
        {
          id: 2,
          mrn: 'MRN002',
          full_name: 'Petrova Maria Sergeevna',
          date_of_birth: '1972-08-22',
          age: 52,
          gender: 'F',
          phone: '+7 (999) 987-65-43',
          email: 'petrova@example.com',
          created_at: '2024-01-16T14:20:00Z',
        },
      ]);
    } catch (error) {
      showError('Failed to load patients');
    } finally {
      setLoading(false);
    }
  };

  const handleOpenDialog = (patient?: Patient) => {
    if (patient) {
      setEditingPatient(patient);
      const nameParts = patient.full_name.split(' ');
      setFormData({
        mrn: patient.mrn,
        first_name: nameParts[1] || '',
        last_name: nameParts[0] || '',
        middle_name: nameParts[2] || '',
        date_of_birth: patient.date_of_birth,
        gender: patient.gender,
        phone: patient.phone || '',
        email: patient.email || '',
        address: '',
      });
    } else {
      setEditingPatient(null);
      setFormData({
        mrn: '',
        first_name: '',
        last_name: '',
        middle_name: '',
        date_of_birth: '',
        gender: 'M',
        phone: '',
        email: '',
        address: '',
      });
    }
    setDialogOpen(true);
  };

  const handleCloseDialog = () => {
    setDialogOpen(false);
    setEditingPatient(null);
  };

  const handleSubmit = async () => {
    try {
      if (editingPatient) {
        // await api.put(`/patients/${editingPatient.id}`, formData);
        showSuccess('Patient updated successfully');
      } else {
        // await api.post('/patients', formData);
        showSuccess('Patient created successfully');
      }
      handleCloseDialog();
      loadPatients();
    } catch (error) {
      showError('Failed to save patient');
    }
  };

  const handleDeleteClick = (patient: Patient) => {
    setPatientToDelete(patient);
    setDeleteDialogOpen(true);
  };

  const handleConfirmDelete = async () => {
    if (!patientToDelete) return;
    
    try {
      // await api.delete(`/patients/${patientToDelete.id}`);
      showSuccess('Patient deleted successfully');
      loadPatients();
    } catch (error) {
      showError('Failed to delete patient');
    } finally {
      setDeleteDialogOpen(false);
      setPatientToDelete(null);
    }
  };

  const columns = [
    { key: 'mrn', header: 'MRN', width: 100 },
    { key: 'full_name', header: 'Name', sortable: true },
    {
      key: 'age',
      header: 'Age',
      width: 80,
      sortable: true,
      render: (patient: Patient) => `${patient.age} years`,
    },
    {
      key: 'gender',
      header: 'Gender',
      width: 100,
      render: (patient: Patient) => (
        <Chip
          label={patient.gender === 'M' ? 'Male' : 'Female'}
          size="small"
          color={patient.gender === 'M' ? 'primary' : 'secondary'}
        />
      ),
    },
    { key: 'phone', header: 'Phone', width: 150 },
    { key: 'email', header: 'Email' },
    {
      key: 'actions',
      header: 'Actions',
      width: 150,
      render: (patient: Patient) => (
        <Box>
          <Tooltip title="View">
            <IconButton size="small" color="primary">
              <Visibility />
            </IconButton>
          </Tooltip>
          <Tooltip title="Edit">
            <IconButton
              size="small"
              color="info"
              onClick={() => handleOpenDialog(patient)}
            >
              <Edit />
            </IconButton>
          </Tooltip>
          <Tooltip title="Delete">
            <IconButton
              size="small"
              color="error"
              onClick={() => handleDeleteClick(patient)}
            >
              <Delete />
            </IconButton>
          </Tooltip>
        </Box>
      ),
    },
  ];

  if (loading) {
    return <LoadingScreen message="Loading patients..." />;
  }

  return (
    <Box>
      <Box display="flex" justifyContent="space-between" alignItems="center" mb={3}>
        <Typography variant="h4" fontWeight="bold">
          <People sx={{ mr: 1, verticalAlign: 'middle' }} />
          Patients
        </Typography>
        <Button
          variant="contained"
          startIcon={<Add />}
          onClick={() => handleOpenDialog()}
        >
          Add Patient
        </Button>
      </Box>

      <DataTable
        columns={columns}
        data={patients}
        keyExtractor={(patient) => patient.id}
        searchable
        searchFields={['mrn', 'full_name', 'email']}
        pagination
      />

      {/* Add/Edit Dialog */}
      <Dialog
        open={dialogOpen}
        onClose={handleCloseDialog}
        maxWidth="md"
        fullWidth
      >
        <DialogTitle>
          {editingPatient ? 'Edit Patient' : 'Add New Patient'}
        </DialogTitle>
        <DialogContent>
          <Grid container spacing={2} sx={{ mt: 1 }}>
            <Grid item xs={12} md={4}>
              <TextField
                fullWidth
                label="MRN"
                value={formData.mrn}
                onChange={(e) =>
                  setFormData({ ...formData, mrn: e.target.value })
                }
                required
              />
            </Grid>
            <Grid item xs={12} md={4}>
              <TextField
                fullWidth
                label="Last Name"
                value={formData.last_name}
                onChange={(e) =>
                  setFormData({ ...formData, last_name: e.target.value })
                }
                required
              />
            </Grid>
            <Grid item xs={12} md={4}>
              <TextField
                fullWidth
                label="First Name"
                value={formData.first_name}
                onChange={(e) =>
                  setFormData({ ...formData, first_name: e.target.value })
                }
                required
              />
            </Grid>
            <Grid item xs={12} md={4}>
              <TextField
                fullWidth
                label="Middle Name"
                value={formData.middle_name}
                onChange={(e) =>
                  setFormData({ ...formData, middle_name: e.target.value })
                }
              />
            </Grid>
            <Grid item xs={12} md={4}>
              <TextField
                fullWidth
                label="Date of Birth"
                type="date"
                value={formData.date_of_birth}
                onChange={(e) =>
                  setFormData({ ...formData, date_of_birth: e.target.value })
                }
                InputLabelProps={{ shrink: true }}
                required
              />
            </Grid>
            <Grid item xs={12} md={4}>
              <TextField
                fullWidth
                select
                label="Gender"
                value={formData.gender}
                onChange={(e) =>
                  setFormData({ ...formData, gender: e.target.value })
                }
                SelectProps={{ native: true }}
                required
              >
                <option value="M">Male</option>
                <option value="F">Female</option>
                <option value="O">Other</option>
              </TextField>
            </Grid>
            <Grid item xs={12} md={6}>
              <TextField
                fullWidth
                label="Phone"
                value={formData.phone}
                onChange={(e) =>
                  setFormData({ ...formData, phone: e.target.value })
                }
              />
            </Grid>
            <Grid item xs={12} md={6}>
              <TextField
                fullWidth
                label="Email"
                type="email"
                value={formData.email}
                onChange={(e) =>
                  setFormData({ ...formData, email: e.target.value })
                }
              />
            </Grid>
            <Grid item xs={12}>
              <TextField
                fullWidth
                label="Address"
                multiline
                rows={2}
                value={formData.address}
                onChange={(e) =>
                  setFormData({ ...formData, address: e.target.value })
                }
              />
            </Grid>
          </Grid>
        </DialogContent>
        <DialogActions>
          <Button onClick={handleCloseDialog}>Cancel</Button>
          <Button onClick={handleSubmit} variant="contained">
            {editingPatient ? 'Update' : 'Create'}
          </Button>
        </DialogActions>
      </Dialog>

      {/* Delete Confirmation */}
      <ConfirmDialog
        open={deleteDialogOpen}
        title="Delete Patient"
        message={`Are you sure you want to delete patient "${patientToDelete?.full_name}"? This action cannot be undone.`}
        confirmText="Delete"
        severity="error"
        onConfirm={handleConfirmDelete}
        onCancel={() => {
          setDeleteDialogOpen(false);
          setPatientToDelete(null);
        }}
      />
    </Box>
  );
};

export default Patients;
