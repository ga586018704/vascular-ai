import React, { useState, useEffect } from 'react';
import {
  Box,
  Grid,
  Card,
  CardContent,
  Typography,
  Paper,
  Tabs,
  Tab,
  FormControl,
  InputLabel,
  Select,
  MenuItem,
  CircularProgress,
  Alert,
  Chip,
} from '@mui/material';
import {
  LineChart,
  Line,
  BarChart,
  Bar,
  PieChart,
  Pie,
  Cell,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
  AreaChart,
  Area,
} from 'recharts';
import {
  TrendingUp,
  People,
  Assessment,
  Storage,
  Speed,
  Memory,
  DiscFull,
  CheckCircle,
  Warning,
  Error,
} from '@mui/icons-material';
import { useAuth } from '../contexts/AuthContext';
import { api } from '../services/api';

interface DashboardStats {
  total_patients: number;
  total_studies: number;
  total_reports: number;
  total_users: number;
  today_studies: number;
  today_reports: number;
  weekly_studies: number;
  weekly_reports: number;
}

interface SystemHealth {
  status: string;
  issues: string[];
  cpu: {
    percent: number;
    count: number;
  };
  memory: {
    total_gb: number;
    available_gb: number;
    percent: number;
  };
  disk: {
    total_gb: number;
    free_gb: number;
    percent: number;
  };
}

interface ActivityMetrics {
  actions_by_type: Record<string, number>;
  daily_activity: Array<{ date: string; count: number }>;
  top_users: Array<{ username: string; actions: number }>;
}

const COLORS = ['#0088FE', '#00C49F', '#FFBB28', '#FF8042', '#8884D8', '#82CA9D'];

const StatCard: React.FC<{
  title: string;
  value: number | string;
  subtitle?: string;
  icon: React.ReactNode;
  color: string;
}> = ({ title, value, subtitle, icon, color }) => (
  <Card sx={{ height: '100%' }}>
    <CardContent>
      <Box display="flex" alignItems="center" justifyContent="space-between">
        <Box>
          <Typography color="textSecondary" gutterBottom variant="overline">
            {title}
          </Typography>
          <Typography variant="h4" component="div" sx={{ fontWeight: 'bold' }}>
            {value}
          </Typography>
          {subtitle && (
            <Typography variant="caption" color="textSecondary">
              {subtitle}
            </Typography>
          )}
        </Box>
        <Box
          sx={{
            backgroundColor: `${color}20`,
            borderRadius: '50%',
            p: 1.5,
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
          }}
        >
          {React.cloneElement(icon as React.ReactElement, { sx: { color, fontSize: 32 } })}
        </Box>
      </Box>
    </CardContent>
  </Card>
);

const Analytics: React.FC = () => {
  const { user } = useAuth();
  const [activeTab, setActiveTab] = useState(0);
  const [timeRange, setTimeRange] = useState(30);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  
  const [dashboardStats, setDashboardStats] = useState<DashboardStats | null>(null);
  const [systemHealth, setSystemHealth] = useState<SystemHealth | null>(null);
  const [activityMetrics, setActivityMetrics] = useState<ActivityMetrics | null>(null);

  const isAdmin = user?.role === 'admin';

  useEffect(() => {
    fetchData();
  }, [timeRange]);

  const fetchData = async () => {
    setLoading(true);
    setError(null);
    
    try {
      // Fetch dashboard stats
      const statsRes = await api.get('/analytics/dashboard');
      setDashboardStats(statsRes.data);
      
      // Fetch activity metrics
      const activityRes = await api.get(`/analytics/activity?days=${timeRange}`);
      setActivityMetrics(activityRes.data);
      
      // Fetch system health (admin only)
      if (isAdmin) {
        try {
          const healthRes = await api.get('/analytics/system-health');
          setSystemHealth(healthRes.data);
        } catch (e) {
          // System health might fail for non-admin, that's ok
        }
      }
    } catch (err: any) {
      setError(err.response?.data?.detail || 'Failed to load analytics data');
    } finally {
      setLoading(false);
    }
  };

  const handleTabChange = (event: React.SyntheticEvent, newValue: number) => {
    setActiveTab(newValue);
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'healthy':
        return <CheckCircle sx={{ color: 'success.main' }} />;
      case 'warning':
        return <Warning sx={{ color: 'warning.main' }} />;
      case 'critical':
        return <Error sx={{ color: 'error.main' }} />;
      default:
        return <CheckCircle sx={{ color: 'success.main' }} />;
    }
  };

  if (loading) {
    return (
      <Box display="flex" justifyContent="center" alignItems="center" minHeight="60vh">
        <CircularProgress />
      </Box>
    );
  }

  return (
    <Box>
      <Box display="flex" justifyContent="space-between" alignItems="center" mb={3}>
        <Typography variant="h4" component="h1" sx={{ fontWeight: 'bold' }}>
          Analytics Dashboard
        </Typography>
        <FormControl sx={{ minWidth: 150 }}>
          <InputLabel>Time Range</InputLabel>
          <Select
            value={timeRange}
            label="Time Range"
            onChange={(e) => setTimeRange(Number(e.target.value))}
          >
            <MenuItem value={7}>Last 7 days</MenuItem>
            <MenuItem value={30}>Last 30 days</MenuItem>
            <MenuItem value={90}>Last 90 days</MenuItem>
            <MenuItem value={365}>Last year</MenuItem>
          </Select>
        </FormControl>
      </Box>

      {error && (
        <Alert severity="error" sx={{ mb: 3 }}>
          {error}
        </Alert>
      )}

      <Tabs value={activeTab} onChange={handleTabChange} sx={{ mb: 3 }}>
        <Tab label="Overview" />
        <Tab label="Activity" />
        {isAdmin && <Tab label="System Health" />}
      </Tabs>

      {activeTab === 0 && dashboardStats && (
        <>
          <Grid container spacing={3} mb={4}>
            <Grid item xs={12} sm={6} md={3}>
              <StatCard
                title="Total Patients"
                value={dashboardStats.total_patients}
                icon={<People />}
                color="#1976d2"
              />
            </Grid>
            <Grid item xs={12} sm={6} md={3}>
              <StatCard
                title="Total Studies"
                value={dashboardStats.total_studies}
                subtitle={`+${dashboardStats.today_studies} today`}
                icon={<Assessment />}
                color="#2e7d32"
              />
            </Grid>
            <Grid item xs={12} sm={6} md={3}>
              <StatCard
                title="Total Reports"
                value={dashboardStats.total_reports}
                subtitle={`+${dashboardStats.today_reports} today`}
                icon={<TrendingUp />}
                color="#ed6c02"
              />
            </Grid>
            <Grid item xs={12} sm={6} md={3}>
              <StatCard
                title="Total Users"
                value={dashboardStats.total_users}
                icon={<Storage />}
                color="#9c27b0"
              />
            </Grid>
          </Grid>

          <Grid container spacing={3}>
            <Grid item xs={12} md={8}>
              <Paper sx={{ p: 3 }}>
                <Typography variant="h6" gutterBottom>
                  Activity Over Time
                </Typography>
                <ResponsiveContainer width="100%" height={300}>
                  <AreaChart data={activityMetrics?.daily_activity || []}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis
                      dataKey="date"
                      tickFormatter={(value) => new Date(value).toLocaleDateString()}
                    />
                    <YAxis />
                    <Tooltip
                      labelFormatter={(value) => new Date(value).toLocaleDateString()}
                    />
                    <Area
                      type="monotone"
                      dataKey="count"
                      stroke="#1976d2"
                      fill="#1976d220"
                      name="Actions"
                    />
                  </AreaChart>
                </ResponsiveContainer>
              </Paper>
            </Grid>
            <Grid item xs={12} md={4}>
              <Paper sx={{ p: 3 }}>
                <Typography variant="h6" gutterBottom>
                  Actions by Type
                </Typography>
                <ResponsiveContainer width="100%" height={300}>
                  <PieChart>
                    <Pie
                      data={Object.entries(activityMetrics?.actions_by_type || {}).map(
                        ([name, value]) => ({ name, value })
                      )}
                      cx="50%"
                      cy="50%"
                      labelLine={false}
                      label={({ name, percent }) =>
                        `${name}: ${(percent * 100).toFixed(0)}%`
                      }
                      outerRadius={80}
                      fill="#8884d8"
                      dataKey="value"
                    >
                      {Object.entries(activityMetrics?.actions_by_type || {}).map(
                        (entry, index) => (
                          <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                        )
                      )}
                    </Pie>
                    <Tooltip />
                  </PieChart>
                </ResponsiveContainer>
              </Paper>
            </Grid>
          </Grid>
        </>
      )}

      {activeTab === 1 && activityMetrics && (
        <Grid container spacing={3}>
          <Grid item xs={12} md={6}>
            <Paper sx={{ p: 3 }}>
              <Typography variant="h6" gutterBottom>
                Daily Activity
              </Typography>
              <ResponsiveContainer width="100%" height={300}>
                <BarChart data={activityMetrics.daily_activity}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis
                    dataKey="date"
                    tickFormatter={(value) => new Date(value).toLocaleDateString()}
                  />
                  <YAxis />
                  <Tooltip
                    labelFormatter={(value) => new Date(value).toLocaleDateString()}
                  />
                  <Bar dataKey="count" fill="#1976d2" name="Actions" />
                </BarChart>
              </ResponsiveContainer>
            </Paper>
          </Grid>
          <Grid item xs={12} md={6}>
            <Paper sx={{ p: 3 }}>
              <Typography variant="h6" gutterBottom>
                Top Users
              </Typography>
              <ResponsiveContainer width="100%" height={300}>
                <BarChart
                  data={activityMetrics.top_users}
                  layout="vertical"
                  margin={{ left: 60 }}
                >
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis type="number" />
                  <YAxis dataKey="username" type="category" width={100} />
                  <Tooltip />
                  <Bar dataKey="actions" fill="#2e7d32" name="Actions" />
                </BarChart>
              </ResponsiveContainer>
            </Paper>
          </Grid>
        </Grid>
      )}

      {activeTab === 2 && systemHealth && isAdmin && (
        <Grid container spacing={3}>
          <Grid item xs={12}>
            <Paper sx={{ p: 3 }}>
              <Box display="flex" alignItems="center" gap={2} mb={3}>
                {getStatusIcon(systemHealth.status)}
                <Typography variant="h5">
                  System Status:{' '}
                  <Chip
                    label={systemHealth.status.toUpperCase()}
                    color={
                      systemHealth.status === 'healthy'
                        ? 'success'
                        : systemHealth.status === 'warning'
                        ? 'warning'
                        : 'error'
                    }
                  />
                </Typography>
              </Box>
              
              {systemHealth.issues.length > 0 && (
                <Alert severity="warning" sx={{ mb: 3 }}>
                  <Typography variant="subtitle2">Issues Detected:</Typography>
                  <ul>
                    {systemHealth.issues.map((issue, idx) => (
                      <li key={idx}>{issue}</li>
                    ))}
                  </ul>
                </Alert>
              )}

              <Grid container spacing={3}>
                <Grid item xs={12} md={4}>
                  <Card>
                    <CardContent>
                      <Box display="flex" alignItems="center" gap={2} mb={2}>
                        <Speed color="primary" />
                        <Typography variant="h6">CPU</Typography>
                      </Box>
                      <Typography variant="h4" gutterBottom>
                        {systemHealth.cpu.percent.toFixed(1)}%
                      </Typography>
                      <Typography color="textSecondary">
                        {systemHealth.cpu.count} cores
                      </Typography>
                      <Box mt={2}>
                        <Box
                          sx={{
                            width: '100%',
                            height: 8,
                            backgroundColor: '#e0e0e0',
                            borderRadius: 4,
                          }}
                        >
                          <Box
                            sx={{
                              width: `${systemHealth.cpu.percent}%`,
                              height: '100%',
                              backgroundColor:
                                systemHealth.cpu.percent > 80
                                  ? '#d32f2f'
                                  : systemHealth.cpu.percent > 60
                                  ? '#ed6c02'
                                  : '#2e7d32',
                              borderRadius: 4,
                              transition: 'width 0.3s',
                            }}
                          />
                        </Box>
                      </Box>
                    </CardContent>
                  </Card>
                </Grid>
                
                <Grid item xs={12} md={4}>
                  <Card>
                    <CardContent>
                      <Box display="flex" alignItems="center" gap={2} mb={2}>
                        <Memory color="primary" />
                        <Typography variant="h6">Memory</Typography>
                      </Box>
                      <Typography variant="h4" gutterBottom>
                        {systemHealth.memory.percent.toFixed(1)}%
                      </Typography>
                      <Typography color="textSecondary">
                        {systemHealth.memory.used_gb.toFixed(1)} /{' '}
                        {systemHealth.memory.total_gb.toFixed(1)} GB
                      </Typography>
                      <Box mt={2}>
                        <Box
                          sx={{
                            width: '100%',
                            height: 8,
                            backgroundColor: '#e0e0e0',
                            borderRadius: 4,
                          }}
                        >
                          <Box
                            sx={{
                              width: `${systemHealth.memory.percent}%`,
                              height: '100%',
                              backgroundColor:
                                systemHealth.memory.percent > 80
                                  ? '#d32f2f'
                                  : systemHealth.memory.percent > 60
                                  ? '#ed6c02'
                                  : '#2e7d32',
                              borderRadius: 4,
                              transition: 'width 0.3s',
                            }}
                          />
                        </Box>
                      </Box>
                    </CardContent>
                  </Card>
                </Grid>
                
                <Grid item xs={12} md={4}>
                  <Card>
                    <CardContent>
                      <Box display="flex" alignItems="center" gap={2} mb={2}>
                        <DiscFull color="primary" />
                        <Typography variant="h6">Disk</Typography>
                      </Box>
                      <Typography variant="h4" gutterBottom>
                        {systemHealth.disk.percent.toFixed(1)}%
                      </Typography>
                      <Typography color="textSecondary">
                        {systemHealth.disk.used_gb.toFixed(1)} /{' '}
                        {systemHealth.disk.total_gb.toFixed(1)} GB
                      </Typography>
                      <Box mt={2}>
                        <Box
                          sx={{
                            width: '100%',
                            height: 8,
                            backgroundColor: '#e0e0e0',
                            borderRadius: 4,
                          }}
                        >
                          <Box
                            sx={{
                              width: `${systemHealth.disk.percent}%`,
                              height: '100%',
                              backgroundColor:
                                systemHealth.disk.percent > 80
                                  ? '#d32f2f'
                                  : systemHealth.disk.percent > 60
                                  ? '#ed6c02'
                                  : '#2e7d32',
                              borderRadius: 4,
                              transition: 'width 0.3s',
                            }}
                          />
                        </Box>
                      </Box>
                    </CardContent>
                  </Card>
                </Grid>
              </Grid>
            </Paper>
          </Grid>
        </Grid>
      )}
    </Box>
  );
};

export default Analytics;
