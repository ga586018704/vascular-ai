import React, { useState, useCallback } from 'react';
import {
  Box,
  Typography,
  Paper,
  Button,
  Stepper,
  Step,
  StepLabel,
  Grid,
  Card,
  CardContent,
  Chip,
  Alert,
  AlertTitle,
  Divider,
  List,
  ListItem,
  ListItemIcon,
  ListItemText,
  CircularProgress,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  TextField,
  FormControlLabel,
  Checkbox,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  Accordion,
  AccordionSummary,
  AccordionDetails,
} from '@mui/material';
import {
  CloudUpload,
  CheckCircle,
  Warning,
  Error,
  ExpandMore,
  LocalHospital,
  Assessment,
  Visibility,
  ArrowForward,
  Science,
  TrendingUp,
  Info,
} from '@mui/icons-material';
import { useDropzone } from 'react-dropzone';
import { api } from '../services/api';

interface PathologyFinding {
  pathology_type: string;
  vessel_name: string;
  severity: string;
  degree_percent?: number;
  sac_diameter_mm?: number;
  rupture_risk?: string;
  surgical_priority: string;
  confidence: number;
}

interface VesselResult {
  vessel_type: string;
  vessel_name: string;
  side?: string;
  measurements: {
    proximal_diameter_mm: number;
    distal_diameter_mm: number;
    minimal_diameter_mm: number;
    maximal_diameter_mm: number;
    length_mm: number;
  };
  pathologies: PathologyFinding[];
}

interface TreatmentOption {
  approach: string;
  procedure_name: string;
  description: string;
  indications: string[];
  contraindications: string[];
  advantages: string[];
  disadvantages: string[];
  technical_success_rate: number;
  mortality_30day: number;
  major_complication_rate: number;
}

interface TreatmentRecommendation {
  pathology_type: string;
  vessel_name: string;
  priority: string;
  recommended_approach: string;
  clinical_summary: string;
  anatomical_description: string;
  pathophysiology: string;
  decision_rationale: string;
  evidence_level: string;
  primary_option: TreatmentOption;
  required_tests: string[];
  procedure_specific_risks: string[];
}

interface AnalysisResult {
  study_id: string;
  patient_id: string;
  image_quality: string;
  total_vessels: number;
  total_pathologies: number;
  critical_findings: string[];
  vessels: VesselResult[];
  treatment_recommendations: TreatmentRecommendation[];
  executive_summary: string;
  urgent_actions: string[];
}

const steps = ['Upload DICOM', 'Patient Data', 'Analysis', 'Results'];

const Angiography: React.FC = () => {
  const [activeStep, setActiveStep] = useState(0);
  const [files, setFiles] = useState<File[]>([]);
  const [analyzing, setAnalyzing] = useState(false);
  const [result, setResult] = useState<AnalysisResult | null>(null);
  const [error, setError] = useState<string | null>(null);
  
  // Patient factors
  const [patientFactors, setPatientFactors] = useState({
    age: 65,
    gender: 'M',
    hypertension: false,
    diabetes: false,
    coronary_artery_disease: false,
    prior_mi: false,
    chf: false,
    copd: false,
    on_anticoagulation: false,
    on_antiplatelet: false,
    prior_vascular_surgery: false,
    asa_class: 2,
  });

  const onDrop = useCallback((acceptedFiles: File[]) => {
    setFiles(acceptedFiles);
    setError(null);
  }, []);

  const { getRootProps, getInputProps, isDragActive } = useDropzone({
    onDrop,
    accept: {
      'application/dicom': ['.dcm', '.dicom'],
      'application/zip': ['.zip'],
    },
    multiple: true,
  });

  const handleNext = async () => {
    if (activeStep === 0 && files.length === 0) {
      setError('Please upload at least one DICOM file');
      return;
    }

    if (activeStep === 2) {
      await analyzeAngiography();
      return;
    }

    setActiveStep((prev) => prev + 1);
  };

  const handleBack = () => {
    setActiveStep((prev) => prev - 1);
  };

  const analyzeAngiography = async () => {
    setAnalyzing(true);
    setError(null);

    try {
      const formData = new FormData();
      files.forEach((file) => formData.append('files', file));
      formData.append('patient_factors', JSON.stringify(patientFactors));

      const response = await api.post('/angiography/analyze', formData, {
        headers: { 'Content-Type': 'multipart/form-data' },
      });

      setResult(response.data);
      setActiveStep(3);
    } catch (err: any) {
      setError(err.response?.data?.detail || 'Analysis failed');
    } finally {
      setAnalyzing(false);
    }
  };

  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case 'emergency':
        return 'error';
      case 'urgent':
        return 'warning';
      case 'elective':
        return 'info';
      default:
        return 'default';
    }
  };

  const getSeverityColor = (severity: string) => {
    switch (severity) {
      case 'critical':
      case 'severe':
        return 'error';
      case 'moderate':
        return 'warning';
      case 'mild':
        return 'success';
      default:
        return 'default';
    }
  };

  const renderUploadStep = () => (
    <Box>
      <Paper
        {...getRootProps()}
        sx={{
          p: 4,
          textAlign: 'center',
          border: '2px dashed',
          borderColor: isDragActive ? 'primary.main' : 'grey.300',
          bgcolor: isDragActive ? 'primary.50' : 'background.paper',
          cursor: 'pointer',
          transition: 'all 0.2s',
        }}
      >
        <input {...getInputProps()} />
        <CloudUpload sx={{ fontSize: 64, color: 'primary.main', mb: 2 }} />
        <Typography variant="h6" gutterBottom>
          {isDragActive ? 'Drop DICOM files here' : 'Drag & drop CT Angiography DICOM files'}
        </Typography>
        <Typography variant="body2" color="text.secondary">
          or click to browse. Supported formats: DCM, DICOM, ZIP
        </Typography>
      </Paper>

      {files.length > 0 && (
        <Box mt={3}>
          <Typography variant="subtitle2" gutterBottom>
            Selected files ({files.length}):
          </Typography>
          <List dense>
            {files.map((file, index) => (
              <ListItem key={index}>
                <ListItemIcon>
                  <CheckCircle color="success" fontSize="small" />
                </ListItemIcon>
                <ListItemText
                  primary={file.name}
                  secondary={`${(file.size / 1024 / 1024).toFixed(2)} MB`}
                />
              </ListItem>
            ))}
          </List>
        </Box>
      )}
    </Box>
  );

  const renderPatientDataStep = () => (
    <Grid container spacing={3}>
      <Grid item xs={12} md={6}>
        <TextField
          fullWidth
          label="Age"
          type="number"
          value={patientFactors.age}
          onChange={(e) =>
            setPatientFactors({ ...patientFactors, age: parseInt(e.target.value) })
          }
        />
      </Grid>
      <Grid item xs={12} md={6}>
        <TextField
          fullWidth
          label="ASA Class"
          type="number"
          inputProps={{ min: 1, max: 5 }}
          value={patientFactors.asa_class}
          onChange={(e) =>
            setPatientFactors({ ...patientFactors, asa_class: parseInt(e.target.value) })
          }
          helperText="1-5 (American Society of Anesthesiologists)"
        />
      </Grid>
      <Grid item xs={12}>
        <Typography variant="subtitle2" gutterBottom>
          Comorbidities
        </Typography>
        <Grid container spacing={2}>
          {[
            { key: 'hypertension', label: 'Hypertension' },
            { key: 'diabetes', label: 'Diabetes' },
            { key: 'coronary_artery_disease', label: 'Coronary Artery Disease' },
            { key: 'prior_mi', label: 'Prior MI' },
            { key: 'chf', label: 'CHF' },
            { key: 'copd', label: 'COPD' },
            { key: 'on_anticoagulation', label: 'On Anticoagulation' },
            { key: 'on_antiplatelet', label: 'On Antiplatelet' },
            { key: 'prior_vascular_surgery', label: 'Prior Vascular Surgery' },
          ].map((item) => (
            <Grid item xs={12} sm={6} md={4} key={item.key}>
              <FormControlLabel
                control={
                  <Checkbox
                    checked={patientFactors[item.key as keyof typeof patientFactors] as boolean}
                    onChange={(e) =>
                      setPatientFactors({
                        ...patientFactors,
                        [item.key]: e.target.checked,
                      })
                    }
                  />
                }
                label={item.label}
              />
            </Grid>
          ))}
        </Grid>
      </Grid>
    </Grid>
  );

  const renderAnalysisStep = () => (
    <Box textAlign="center" py={4}>
      <CircularProgress size={80} thickness={4} />
      <Typography variant="h5" sx={{ mt: 3 }}>
        Analyzing CT Angiography...
      </Typography>
      <Typography variant="body1" color="text.secondary" sx={{ mt: 1 }}>
        This may take a few minutes depending on the number of slices
      </Typography>
      <Box sx={{ mt: 3, maxWidth: 400, mx: 'auto' }}>
        <Alert severity="info">
          Processing steps:
          <List dense>
            <ListItem>
              <ListItemIcon><CheckCircle color="success" fontSize="small" /></ListItemIcon>
              <ListItemText primary="Loading DICOM files" />
            </ListItem>
            <ListItem>
              <ListItemIcon><CircularProgress size={16} /></ListItemIcon>
              <ListItemText primary="Segmenting vessels" />
            </ListItem>
            <ListItem>
              <ListItemText primary="Detecting pathologies" sx={{ pl: 4 }} />
            </ListItem>
            <ListItem>
              <ListItemText primary="Generating treatment plan" sx={{ pl: 4 }} />
            </ListItem>
          </List>
        </Alert>
      </Box>
    </Box>
  );

  const renderResultsStep = () => {
    if (!result) return null;

    return (
      <Box>
        {/* Executive Summary */}
        <Paper sx={{ p: 3, mb: 3, bgcolor: 'primary.50' }}>
          <Typography variant="h5" gutterBottom sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
            <Assessment color="primary" />
            Executive Summary
          </Typography>
          <Typography variant="body1" sx={{ whiteSpace: 'pre-line' }}>
            {result.executive_summary}
          </Typography>
        </Paper>

        {/* Critical Findings */}
        {result.critical_findings.length > 0 && (
          <Alert severity="error" sx={{ mb: 3 }}>
            <AlertTitle>Critical Findings</AlertTitle>
            <List dense>
              {result.critical_findings.map((finding, idx) => (
                <ListItem key={idx}>
                  <ListItemIcon>
                    <Warning color="error" />
                  </ListItemIcon>
                  <ListItemText primary={finding} />
                </ListItem>
              ))}
            </List>
          </Alert>
        )}

        {/* Urgent Actions */}
        {result.urgent_actions.length > 0 && (
          <Alert severity="warning" sx={{ mb: 3 }}>
            <AlertTitle>Urgent Actions Required</AlertTitle>
            <List dense>
              {result.urgent_actions.map((action, idx) => (
                <ListItem key={idx}>
                  <ListItemIcon>
                    <ArrowForward color="warning" />
                  </ListItemIcon>
                  <ListItemText primary={action} />
                </ListItem>
              ))}
            </List>
          </Alert>
        )}

        {/* Vessels Table */}
        <Paper sx={{ mb: 3 }}>
          <Box sx={{ p: 2, bgcolor: 'grey.100' }}>
            <Typography variant="h6">
              Segmented Vessels ({result.total_vessels})
            </Typography>
          </Box>
          <TableContainer>
            <Table>
              <TableHead>
                <TableRow>
                  <TableCell>Vessel</TableCell>
                  <TableCell>Diameter (mm)</TableCell>
                  <TableCell>Pathologies</TableCell>
                  <TableCell>Status</TableCell>
                </TableRow>
              </TableHead>
              <TableBody>
                {result.vessels.map((vessel, idx) => (
                  <TableRow key={idx}>
                    <TableCell>
                      <Typography variant="subtitle2">{vessel.vessel_name}</Typography>
                      <Typography variant="caption" color="text.secondary">
                        {vessel.vessel_type}
                      </Typography>
                    </TableCell>
                    <TableCell>
                      {vessel.measurements.maximal_diameter_mm.toFixed(1)} mm
                      <br />
                      <Typography variant="caption" color="text.secondary">
                        min: {vessel.measurements.minimal_diameter_mm.toFixed(1)} mm
                      </Typography>
                    </TableCell>
                    <TableCell>
                      {vessel.pathologies.length > 0 ? (
                        vessel.pathologies.map((p, pidx) => (
                          <Chip
                            key={pidx}
                            label={p.pathology_type}
                            color={getSeverityColor(p.severity)}
                            size="small"
                            sx={{ mr: 0.5, mb: 0.5 }}
                          />
                        ))
                      ) : (
                        <Chip label="Normal" color="success" size="small" />
                      )}
                    </TableCell>
                    <TableCell>
                      {vessel.pathologies.length > 0 ? (
                        <Chip
                          label={vessel.pathologies[0].surgical_priority}
                          color={getPriorityColor(vessel.pathologies[0].surgical_priority)}
                          size="small"
                        />
                      ) : (
                        <Chip label="Normal" color="success" size="small" />
                      )}
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </TableContainer>
        </Paper>

        {/* Treatment Recommendations */}
        <Typography variant="h5" gutterBottom sx={{ mt: 4 }}>
          <LocalHospital sx={{ mr: 1, verticalAlign: 'middle' }} />
          Treatment Recommendations
        </Typography>

        {result.treatment_recommendations.map((rec, idx) => (
          <Accordion key={idx} defaultExpanded={idx === 0} sx={{ mb: 1 }}>
            <AccordionSummary expandIcon={<ExpandMore />}>
              <Box sx={{ display: 'flex', alignItems: 'center', gap: 2, width: '100%' }}>
                <Typography variant="subtitle1" sx={{ flex: 1 }}>
                  {rec.vessel_name} - {rec.pathology_type}
                </Typography>
                <Chip
                  label={rec.priority}
                  color={getPriorityColor(rec.priority)}
                  size="small"
                />
                <Chip
                  label={rec.recommended_approach}
                  variant="outlined"
                  size="small"
                />
              </Box>
            </AccordionSummary>
            <AccordionDetails>
              <Grid container spacing={3}>
                <Grid item xs={12}>
                  <Typography variant="h6" gutterBottom>
                    Clinical Summary
                  </Typography>
                  <Paper sx={{ p: 2, bgcolor: 'grey.50' }}>
                    <Typography variant="body2" sx={{ whiteSpace: 'pre-line' }}>
                      {rec.clinical_summary}
                    </Typography>
                  </Paper>
                </Grid>

                <Grid item xs={12} md={6}>
                  <Typography variant="subtitle2" gutterBottom>
                    Anatomical Description
                  </Typography>
                  <Typography variant="body2" color="text.secondary">
                    {rec.anatomical_description}
                  </Typography>
                </Grid>

                <Grid item xs={12} md={6}>
                  <Typography variant="subtitle2" gutterBottom>
                    Pathophysiology
                  </Typography>
                  <Typography variant="body2" color="text.secondary">
                    {rec.pathophysiology}
                  </Typography>
                </Grid>

                <Grid item xs={12}>
                  <Divider sx={{ my: 2 }} />
                  <Typography variant="h6" gutterBottom>
                    Recommended Procedure: {rec.primary_option.procedure_name}
                  </Typography>
                  <Typography variant="body2" paragraph>
                    {rec.primary_option.description}
                  </Typography>
                  
                  <Grid container spacing={2}>
                    <Grid item xs={12} sm={6} md={3}>
                      <Card variant="outlined">
                        <CardContent sx={{ textAlign: 'center' }}>
                          <Typography variant="h4" color="success.main">
                            {rec.primary_option.technical_success_rate}%
                          </Typography>
                          <Typography variant="caption">Success Rate</Typography>
                        </CardContent>
                      </Card>
                    </Grid>
                    <Grid item xs={12} sm={6} md={3}>
                      <Card variant="outlined">
                        <CardContent sx={{ textAlign: 'center' }}>
                          <Typography variant="h4" color="error.main">
                            {rec.primary_option.mortality_30day}%
                          </Typography>
                          <Typography variant="caption">30-day Mortality</Typography>
                        </CardContent>
                      </Card>
                    </Grid>
                    <Grid item xs={12} sm={6} md={3}>
                      <Card variant="outlined">
                        <CardContent sx={{ textAlign: 'center' }}>
                          <Typography variant="h4" color="warning.main">
                            {rec.primary_option.major_complication_rate}%
                          </Typography>
                          <Typography variant="caption">Complications</Typography>
                        </CardContent>
                      </Card>
                    </Grid>
                    <Grid item xs={12} sm={6} md={3}>
                      <Card variant="outlined">
                        <CardContent sx={{ textAlign: 'center' }}>
                          <Typography variant="h4" color="info.main">
                            {rec.primary_option.hospital_stay_days}
                          </Typography>
                          <Typography variant="caption">Days in Hospital</Typography>
                        </CardContent>
                      </Card>
                    </Grid>
                  </Grid>
                </Grid>

                <Grid item xs={12} md={6}>
                  <Typography variant="subtitle2" gutterBottom>
                    Indications
                  </Typography>
                  <List dense>
                    {rec.primary_option.indications.map((item, i) => (
                      <ListItem key={i}>
                        <ListItemIcon>
                          <CheckCircle color="success" fontSize="small" />
                        </ListItemIcon>
                        <ListItemText primary={item} />
                      </ListItem>
                    ))}
                  </List>
                </Grid>

                <Grid item xs={12} md={6}>
                  <Typography variant="subtitle2" gutterBottom>
                    Contraindications
                  </Typography>
                  <List dense>
                    {rec.primary_option.contraindications.map((item, i) => (
                      <ListItem key={i}>
                        <ListItemIcon>
                          <Error color="error" fontSize="small" />
                        </ListItemIcon>
                        <ListItemText primary={item} />
                      </ListItem>
                    ))}
                  </List>
                </Grid>

                <Grid item xs={12}>
                  <Alert severity="info">
                    <AlertTitle>Preoperative Workup Required</AlertTitle>
                    <Box component="ul" sx={{ pl: 2, m: 0 }}>
                      {rec.required_tests.map((test, i) => (
                        <li key={i}>{test}</li>
                      ))}
                    </Box>
                  </Alert>
                </Grid>

                <Grid item xs={12}>
                  <Alert severity="warning">
                    <AlertTitle>Procedure-Specific Risks</AlertTitle>
                    <Box component="ul" sx={{ pl: 2, m: 0 }}>
                      {rec.procedure_specific_risks.map((risk, i) => (
                        <li key={i}>{risk}</li>
                      ))}
                    </Box>
                  </Alert>
                </Grid>

                <Grid item xs={12}>
                  <Typography variant="subtitle2" gutterBottom>
                    Decision Rationale
                  </Typography>
                  <Typography variant="body2" sx={{ whiteSpace: 'pre-line' }}>
                    {rec.decision_rationale}
                  </Typography>
                  <Box sx={{ mt: 1 }}>
                    <Chip
                      label={`Evidence Level: ${rec.evidence_level}`}
                      size="small"
                      variant="outlined"
                    />
                  </Box>
                </Grid>
              </Grid>
            </AccordionDetails>
          </Accordion>
        ))}
      </Box>
    );
  };

  return (
    <Box>
      <Typography variant="h4" gutterBottom sx={{ fontWeight: 'bold' }}>
        <Science sx={{ mr: 1, verticalAlign: 'middle' }} />
        CT Angiography Analysis
      </Typography>
      <Typography variant="body1" color="text.secondary" paragraph>
        Upload CT angiography DICOM files for automated vessel segmentation, 
        pathology detection, and evidence-based treatment recommendations.
      </Typography>

      <Stepper activeStep={activeStep} sx={{ mb: 4 }}>
        {steps.map((label) => (
          <Step key={label}>
            <StepLabel>{label}</StepLabel>
          </Step>
        ))}
      </Stepper>

      {error && (
        <Alert severity="error" sx={{ mb: 3 }}>
          {error}
        </Alert>
      )}

      <Paper sx={{ p: 3 }}>
        {activeStep === 0 && renderUploadStep()}
        {activeStep === 1 && renderPatientDataStep()}
        {activeStep === 2 && renderAnalysisStep()}
        {activeStep === 3 && renderResultsStep()}
      </Paper>

      <Box sx={{ display: 'flex', justifyContent: 'space-between', mt: 3 }}>
        <Button
          variant="outlined"
          onClick={handleBack}
          disabled={activeStep === 0 || analyzing}
        >
          Back
        </Button>
        {activeStep < 3 && (
          <Button
            variant="contained"
            onClick={handleNext}
            disabled={analyzing}
            startIcon={analyzing ? <CircularProgress size={20} /> : <ArrowForward />}
          >
            {activeStep === 2 ? 'Analyzing...' : 'Next'}
          </Button>
        )}
        {activeStep === 3 && (
          <Button
            variant="contained"
            onClick={() => {
              setActiveStep(0);
              setFiles([]);
              setResult(null);
            }}
          >
            New Analysis
          </Button>
        )}
      </Box>
    </Box>
  );
};

export default Angiography;
