import React, { useState } from 'react';
import {
  Box,
  Typography,
  Paper,
  Grid,
  List,
  ListItem,
  ListItemText,
  ListItemButton,
  Divider,
  Chip,
  IconButton,
  Tooltip,
  Tabs,
  Tab,
  Button
} from '@mui/material';
import {
  FolderOpen,
  Visibility,
  Download,
  Share,
  Delete,
  Refresh,
  ViewInAr,
  Image as ImageIcon
} from '@mui/icons-material';
import DicomViewer3D from '../components/DicomViewer3D';

interface TabPanelProps {
  children?: React.ReactNode;
  index: number;
  value: number;
}

function TabPanel(props: TabPanelProps) {
  const { children, value, index, ...other } = props;
  return (
    <div
      role="tabpanel"
      hidden={value !== index}
      id={`viewer-tabpanel-${index}`}
      aria-labelledby={`viewer-tab-${index}`}
      {...other}
      style={{ height: '100%' }}
    >
      {value === index && <Box sx={{ height: '100%' }}>{children}</Box>}
    </div>
  );
}

// Mock DICOM studies data
const mockStudies = [
  {
    id: 'STU001',
    patientName: 'John Doe',
    patientId: 'PID001',
    studyDate: '2024-01-15',
    modality: 'CT',
    description: 'CTA Abdomen/Pelvis',
    series: 3,
    instances: 450
  },
  {
    id: 'STU002',
    patientName: 'Jane Smith',
    patientId: 'PID002',
    studyDate: '2024-01-14',
    modality: 'MR',
    description: 'MRA Brain',
    series: 2,
    instances: 180
  },
  {
    id: 'STU003',
    patientName: 'Robert Johnson',
    patientId: 'PID003',
    studyDate: '2024-01-13',
    modality: 'US',
    description: 'Duplex Lower Extremity',
    series: 4,
    instances: 120
  }
];

const DicomViewer: React.FC = () => {
  const [selectedStudy, setSelectedStudy] = useState<string | null>(null);
  const [tabValue, setTabValue] = useState(0);
  const [viewMode, setViewMode] = useState<'2d' | '3d'>('2d');

  const handleStudySelect = (studyId: string) => {
    setSelectedStudy(studyId);
  };

  const handleTabChange = (_: React.SyntheticEvent, newValue: number) => {
    setTabValue(newValue);
  };

  const handleViewModeChange = (mode: '2d' | '3d') => {
    setViewMode(mode);
  };

  return (
    <Box sx={{ height: 'calc(100vh - 64px)', display: 'flex', flexDirection: 'column' }}>
      {/* Header */}
      <Paper sx={{ p: 2, borderRadius: 0 }}>
        <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
          <Typography variant="h5" component="h1">
            DICOM Viewer
          </Typography>
          <Box sx={{ display: 'flex', gap: 1 }}>
            <Button
              variant="outlined"
              startIcon={<FolderOpen />}
              size="small"
            >
              Open Study
            </Button>
            <Button
              variant="outlined"
              startIcon={<Refresh />}
              size="small"
            >
              Refresh
            </Button>
          </Box>
        </Box>
      </Paper>

      {/* Main Content */}
      <Box sx={{ flex: 1, display: 'flex', overflow: 'hidden' }}>
        {/* Study List Sidebar */}
        <Paper 
          sx={{ 
            width: 320, 
            borderRadius: 0,
            display: 'flex',
            flexDirection: 'column'
          }}
        >
          <Box sx={{ p: 2, borderBottom: 1, borderColor: 'divider' }}>
            <Typography variant="subtitle1" fontWeight="medium">
              Studies
            </Typography>
            <Typography variant="caption" color="text.secondary">
              {mockStudies.length} studies available
            </Typography>
          </Box>
          
          <List sx={{ flex: 1, overflow: 'auto' }}>
            {mockStudies.map((study) => (
              <React.Fragment key={study.id}>
                <ListItem disablePadding>
                  <ListItemButton
                    selected={selectedStudy === study.id}
                    onClick={() => handleStudySelect(study.id)}
                  >
                    <ListItemText
                      primary={
                        <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
                          <Typography variant="body2" fontWeight="medium">
                            {study.patientName}
                          </Typography>
                          <Chip 
                            label={study.modality} 
                            size="small" 
                            color="primary"
                            sx={{ height: 20, fontSize: '0.7rem' }}
                          />
                        </Box>
                      }
                      secondary={
                        <Box sx={{ mt: 0.5 }}>
                          <Typography variant="caption" display="block">
                            {study.description}
                          </Typography>
                          <Typography variant="caption" color="text.secondary">
                            {study.studyDate} • {study.series} series • {study.instances} images
                          </Typography>
                        </Box>
                      }
                    />
                  </ListItemButton>
                </ListItem>
                <Divider />
              </React.Fragment>
            ))}
          </List>
        </Paper>

        {/* Viewer Area */}
        <Box sx={{ flex: 1, display: 'flex', flexDirection: 'column', p: 1 }}>
          {selectedStudy ? (
            <>
              {/* Study Info Bar */}
              <Paper sx={{ p: 1, mb: 1, display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                <Box sx={{ display: 'flex', alignItems: 'center', gap: 2 }}>
                  <Typography variant="subtitle2">
                    {mockStudies.find(s => s.id === selectedStudy)?.patientName}
                  </Typography>
                  <Chip 
                    label={mockStudies.find(s => s.id === selectedStudy)?.modality} 
                    size="small" 
                    color="primary"
                  />
                  <Typography variant="caption" color="text.secondary">
                    {mockStudies.find(s => s.id === selectedStudy)?.description}
                  </Typography>
                </Box>
                <Box sx={{ display: 'flex', gap: 0.5 }}>
                  <Tooltip title="2D View">
                    <IconButton 
                      size="small"
                      color={viewMode === '2d' ? 'primary' : 'default'}
                      onClick={() => handleViewModeChange('2d')}
                    >
                      <ImageIcon />
                    </IconButton>
                  </Tooltip>
                  <Tooltip title="3D View">
                    <IconButton 
                      size="small"
                      color={viewMode === '3d' ? 'primary' : 'default'}
                      onClick={() => handleViewModeChange('3d')}
                    >
                      <ViewInAr />
                    </IconButton>
                  </Tooltip>
                  <Divider orientation="vertical" flexItem sx={{ mx: 0.5 }} />
                  <Tooltip title="Download">
                    <IconButton size="small">
                      <Download />
                    </IconButton>
                  </Tooltip>
                  <Tooltip title="Share">
                    <IconButton size="small">
                      <Share />
                    </IconButton>
                  </Tooltip>
                  <Tooltip title="Delete">
                    <IconButton size="small" color="error">
                      <Delete />
                    </IconButton>
                  </Tooltip>
                </Box>
              </Paper>

              {/* Viewer Tabs */}
              <Paper sx={{ flex: 1, display: 'flex', flexDirection: 'column, overflow: ' }}>
                <Tabs value={tabValue} onChange={handleTabChange} sx={{ borderBottom: 1, borderColor: 'divider' }}>
                  <Tab label="Axial" />
                  <Tab label="Sagittal" />
                  <Tab label="Coronal" />
                  <Tab label="3D Volume" />
                </Tabs>
                
                <Box sx={{ flex: 1, overflow: 'hidden' }}>
                  <TabPanel value={tabValue} index={0}>
                    <DicomViewer3D studyId={selectedStudy} />
                  </TabPanel>
                  <TabPanel value={tabValue} index={1}>
                    <DicomViewer3D studyId={selectedStudy} />
                  </TabPanel>
                  <TabPanel value={tabValue} index={2}>
                    <DicomViewer3D studyId={selectedStudy} />
                  </TabPanel>
                  <TabPanel value={tabValue} index={3}>
                    <DicomViewer3D studyId={selectedStudy} />
                  </TabPanel>
                </Box>
              </Paper>
            </>
          ) : (
            <Paper 
              sx={{ 
                flex: 1, 
                display: 'flex', 
                flexDirection: 'column',
                alignItems: 'center', 
                justifyContent: 'center',
                gap: 2
              }}
            >
              <FolderOpen sx={{ fontSize: 64, color: 'text.secondary', opacity: 0.5 }} />
              <Typography variant="h6" color="text.secondary">
                Select a study to view
              </Typography>
              <Typography variant="body2" color="text.secondary">
                Choose a study from the list on the left
              </Typography>
            </Paper>
          )}
        </Box>
      </Box>
    </Box>
  );
};

export default DicomViewer;
