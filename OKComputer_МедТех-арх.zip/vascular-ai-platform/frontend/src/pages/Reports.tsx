import React, { useState } from 'react';
import {
  Box,
  Typography,
  Paper,
  Grid,
  Card,
  CardContent,
  Button,
  List,
  ListItem,
  ListItemText,
  ListItemIcon,
  Chip,
  IconButton,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  TextField,
  FormControl,
  InputLabel,
  Select,
  MenuItem,
  Divider,
  Tooltip
} from '@mui/material';
import {
  Description,
  PictureAsPdf,
  Download,
  Share,
  Delete,
  Add,
  Visibility,
  Assessment,
  LocalHospital,
  TrendingUp
} from '@mui/icons-material';

interface Report {
  id: string;
  title: string;
  type: string;
  patientName: string;
  patientId: string;
  createdAt: string;
  status: 'draft' | 'final' | 'archived';
  size: string;
}

const mockReports: Report[] = [
  {
    id: 'RPT001',
    title: 'Vascular Analysis Report',
    type: 'analysis',
    patientName: 'John Doe',
    patientId: 'PID001',
    createdAt: '2024-01-15',
    status: 'final',
    size: '2.4 MB'
  },
  {
    id: 'RPT002',
    title: 'Study Summary - CTA Abdomen',
    type: 'study',
    patientName: 'Jane Smith',
    patientId: 'PID002',
    createdAt: '2024-01-14',
    status: 'draft',
    size: '1.8 MB'
  },
  {
    id: 'RPT003',
    title: 'Risk Assessment Report',
    type: 'risk',
    patientName: 'Robert Johnson',
    patientId: 'PID003',
    createdAt: '2024-01-13',
    status: 'final',
    size: '1.2 MB'
  }
];

const reportTemplates = [
  { id: 'vascular_analysis', name: 'Vascular Analysis Report', icon: <Assessment /> },
  { id: 'study_summary', name: 'Study Summary Report', icon: <Description /> },
  { id: 'risk_assessment', name: 'Risk Assessment Report', icon: <TrendingUp /> },
  { id: 'consultation', name: 'Consultation Report', icon: <LocalHospital /> }
];

const Reports: React.FC = () => {
  const [reports, setReports] = useState<Report[]>(mockReports);
  const [openDialog, setOpenDialog] = useState(false);
  const [selectedTemplate, setSelectedTemplate] = useState('');
  const [newReport, setNewReport] = useState({
    patientName: '',
    patientId: '',
    title: ''
  });

  const handleCreateReport = () => {
    const template = reportTemplates.find(t => t.id === selectedTemplate);
    const report: Report = {
      id: `RPT${String(reports.length + 1).padStart(3, '0')}`,
      title: newReport.title || template?.name || 'New Report',
      type: selectedTemplate,
      patientName: newReport.patientName,
      patientId: newReport.patientId,
      createdAt: new Date().toISOString().split('T')[0],
      status: 'draft',
      size: '0 KB'
    };
    setReports([report, ...reports]);
    setOpenDialog(false);
    setNewReport({ patientName: '', patientId: '', title: '' });
    setSelectedTemplate('');
  };

  const handleDeleteReport = (id: string) => {
    setReports(reports.filter(r => r.id !== id));
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'final': return 'success';
      case 'draft': return 'warning';
      case 'archived': return 'default';
      default: return 'default';
    }
  };

  const getTypeIcon = (type: string) => {
    switch (type) {
      case 'analysis': return <Assessment color="primary" />;
      case 'study': return <Description color="info" />;
      case 'risk': return <TrendingUp color="warning" />;
      default: return <Description />;
    }
  };

  return (
    <Box sx={{ p: 3 }}>
      <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mb: 3 }}>
        <Typography variant="h4" fontWeight="bold">
          Reports
        </Typography>
        <Button
          variant="contained"
          startIcon={<Add />}
          onClick={() => setOpenDialog(true)}
        >
          Create Report
        </Button>
      </Box>

      {/* Stats Cards */}
      <Grid container spacing={3} sx={{ mb: 3 }}>
        <Grid item xs={12} sm={6} md={3}>
          <Card>
            <CardContent>
              <Typography color="text.secondary" variant="overline">
                Total Reports
              </Typography>
              <Typography variant="h3" fontWeight="bold">
                {reports.length}
              </Typography>
            </CardContent>
          </Card>
        </Grid>
        <Grid item xs={12} sm={6} md={3}>
          <Card>
            <CardContent>
              <Typography color="text.secondary" variant="overline">
                Finalized
              </Typography>
              <Typography variant="h3" fontWeight="bold" color="success.main">
                {reports.filter(r => r.status === 'final').length}
              </Typography>
            </CardContent>
          </Card>
        </Grid>
        <Grid item xs={12} sm={6} md={3}>
          <Card>
            <CardContent>
              <Typography color="text.secondary" variant="overline">
                Drafts
              </Typography>
              <Typography variant="h3" fontWeight="bold" color="warning.main">
                {reports.filter(r => r.status === 'draft').length}
              </Typography>
            </CardContent>
          </Card>
        </Grid>
        <Grid item xs={12} sm={6} md={3}>
          <Card>
            <CardContent>
              <Typography color="text.secondary" variant="overline">
                This Month
              </Typography>
              <Typography variant="h3" fontWeight="bold" color="primary.main">
                {reports.length}
              </Typography>
            </CardContent>
          </Card>
        </Grid>
      </Grid>

      {/* Reports List */}
      <Paper>
        <Box sx={{ p: 2, borderBottom: 1, borderColor: 'divider' }}>
          <Typography variant="h6">Recent Reports</Typography>
        </Box>
        <List>
          {reports.map((report, index) => (
            <React.Fragment key={report.id}>
              <ListItem
                secondaryAction={
                  <Box>
                    <Tooltip title="View">
                      <IconButton edge="end" sx={{ mr: 1 }}>
                        <Visibility />
                      </IconButton>
                    </Tooltip>
                    <Tooltip title="Download PDF">
                      <IconButton edge="end" sx={{ mr: 1 }}>
                        <Download />
                      </IconButton>
                    </Tooltip>
                    <Tooltip title="Share">
                      <IconButton edge="end" sx={{ mr: 1 }}>
                        <Share />
                      </IconButton>
                    </Tooltip>
                    <Tooltip title="Delete">
                      <IconButton 
                        edge="end" 
                        color="error"
                        onClick={() => handleDeleteReport(report.id)}
                      >
                        <Delete />
                      </IconButton>
                    </Tooltip>
                  </Box>
                }
              >
                <ListItemIcon>
                  {getTypeIcon(report.type)}
                </ListItemIcon>
                <ListItemText
                  primary={
                    <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
                      <Typography variant="subtitle1" fontWeight="medium">
                        {report.title}
                      </Typography>
                      <Chip
                        label={report.status}
                        size="small"
                        color={getStatusColor(report.status) as any}
                      />
                    </Box>
                  }
                  secondary={
                    <Box sx={{ mt: 0.5 }}>
                      <Typography variant="body2" component="span">
                        {report.patientName} ({report.patientId})
                      </Typography>
                      <Typography variant="caption" color="text.secondary" sx={{ ml: 2 }}>
                        Created: {report.createdAt} • Size: {report.size}
                      </Typography>
                    </Box>
                  }
                />
              </ListItem>
              {index < reports.length - 1 && <Divider />}
            </React.Fragment>
          ))}
        </List>
      </Paper>

      {/* Create Report Dialog */}
      <Dialog open={openDialog} onClose={() => setOpenDialog(false)} maxWidth="sm" fullWidth>
        <DialogTitle>Create New Report</DialogTitle>
        <DialogContent>
          <Grid container spacing={2} sx={{ mt: 1 }}>
            <Grid item xs={12}>
              <FormControl fullWidth>
                <InputLabel>Report Template</InputLabel>
                <Select
                  value={selectedTemplate}
                  label="Report Template"
                  onChange={(e) => setSelectedTemplate(e.target.value)}
                >
                  {reportTemplates.map((template) => (
                    <MenuItem key={template.id} value={template.id}>
                      <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
                        {template.icon}
                        {template.name}
                      </Box>
                    </MenuItem>
                  ))}
                </Select>
              </FormControl>
            </Grid>
            <Grid item xs={12}>
              <TextField
                fullWidth
                label="Report Title"
                value={newReport.title}
                onChange={(e) => setNewReport({ ...newReport, title: e.target.value })}
                placeholder="Enter report title"
              />
            </Grid>
            <Grid item xs={12} sm={6}>
              <TextField
                fullWidth
                label="Patient Name"
                value={newReport.patientName}
                onChange={(e) => setNewReport({ ...newReport, patientName: e.target.value })}
              />
            </Grid>
            <Grid item xs={12} sm={6}>
              <TextField
                fullWidth
                label="Patient ID"
                value={newReport.patientId}
                onChange={(e) => setNewReport({ ...newReport, patientId: e.target.value })}
              />
            </Grid>
          </Grid>
        </DialogContent>
        <DialogActions>
          <Button onClick={() => setOpenDialog(false)}>Cancel</Button>
          <Button
            variant="contained"
            onClick={handleCreateReport}
            disabled={!selectedTemplate || !newReport.patientName}
          >
            Create
          </Button>
        </DialogActions>
      </Dialog>
    </Box>
  );
};

export default Reports;
