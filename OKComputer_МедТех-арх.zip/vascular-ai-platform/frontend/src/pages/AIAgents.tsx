import React, { useState, useEffect } from 'react';
import {
  Box,
  Typography,
  Grid,
  Card,
  CardContent,
  Button,
  TextField,
  Paper,
  Alert,
  Chip,
  CircularProgress,
  List,
  ListItem,
  ListItemIcon,
  ListItemText,
  Divider,
} from '@mui/material';
import {
  Psychology,
  Send,
  CheckCircle,
  Warning,
  Info,
  ArrowForward,
} from '@mui/icons-material';
import { agentsApi } from '../services/api';

interface Agent {
  id: string;
  name: string;
  description: string;
  capabilities: string[];
}

interface AgentResult {
  agent_type: string;
  response: string;
  findings?: any[];
  recommendations?: string[];
  confidence: number;
  processing_time_ms: number;
}

const AIAgents: React.FC = () => {
  const [agents, setAgents] = useState<Agent[]>([]);
  const [selectedAgent, setSelectedAgent] = useState<string>('');
  const [query, setQuery] = useState('');
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState<AgentResult | null>(null);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    loadAgents();
  }, []);

  const loadAgents = async () => {
    try {
      const response = await agentsApi.getAgents();
      setAgents(response.data);
    } catch (err) {
      console.error('Failed to load agents:', err);
    }
  };

  const handleAnalyze = async () => {
    if (!selectedAgent || !query) {
      setError('Please select an agent and enter a query');
      return;
    }

    setLoading(true);
    setError(null);
    setResult(null);

    try {
      const response = await agentsApi.analyze({
        agent_type: selectedAgent,
        query,
      });
      setResult(response.data);
    } catch (err: any) {
      setError(err.response?.data?.detail || 'Analysis failed');
    } finally {
      setLoading(false);
    }
  };

  return (
    <Box>
      <Typography variant="h4" gutterBottom fontWeight="bold">
        <Psychology sx={{ mr: 1, verticalAlign: 'middle' }} />
        AI Agents
      </Typography>
      <Typography variant="body1" color="text.secondary" paragraph>
        Select an AI agent to analyze vascular pathologies and get treatment recommendations.
      </Typography>

      {error && (
        <Alert severity="error" sx={{ mb: 3 }}>
          {error}
        </Alert>
      )}

      {/* Agent Selection */}
      <Typography variant="h6" gutterBottom>
        Select Agent
      </Typography>
      <Grid container spacing={3} sx={{ mb: 4 }}>
        {agents.map((agent) => (
          <Grid item xs={12} sm={6} md={4} key={agent.id}>
            <Card
              sx={{
                cursor: 'pointer',
                border: selectedAgent === agent.id ? 2 : 0,
                borderColor: 'primary.main',
                transition: 'all 0.2s',
                '&:hover': { transform: 'translateY(-4px)' },
              }}
              onClick={() => setSelectedAgent(agent.id)}
            >
              <CardContent>
                <Typography variant="h6" gutterBottom>
                  {agent.name}
                </Typography>
                <Typography variant="body2" color="text.secondary" paragraph>
                  {agent.description}
                </Typography>
                <Box sx={{ mt: 1 }}>
                  {agent.capabilities.slice(0, 3).map((cap, idx) => (
                    <Chip
                      key={idx}
                      label={cap}
                      size="small"
                      variant="outlined"
                      sx={{ mr: 0.5, mb: 0.5 }}
                    />
                  ))}
                </Box>
              </CardContent>
            </Card>
          </Grid>
        ))}
      </Grid>

      {/* Query Input */}
      {selectedAgent && (
        <Paper sx={{ p: 3, mb: 3 }}>
          <Typography variant="h6" gutterBottom>
            Analysis Query
          </Typography>
          <TextField
            fullWidth
            multiline
            rows={4}
            placeholder="Enter your query or paste study findings..."
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            sx={{ mb: 2 }}
          />
          <Button
            variant="contained"
            onClick={handleAnalyze}
            disabled={loading}
            startIcon={loading ? <CircularProgress size={20} /> : <Send />}
          >
            {loading ? 'Analyzing...' : 'Analyze'}
          </Button>
        </Paper>
      )}

      {/* Results */}
      {result && (
        <Paper sx={{ p: 3 }}>
          <Box display="flex" justifyContent="space-between" alignItems="center" mb={2}>
            <Typography variant="h6">Analysis Results</Typography>
            <Box>
              <Chip
                label={`Confidence: ${(result.confidence * 100).toFixed(0)}%`}
                color="success"
                size="small"
                sx={{ mr: 1 }}
              />
              <Chip
                label={`${result.processing_time_ms}ms`}
                variant="outlined"
                size="small"
              />
            </Box>
          </Box>

          <Divider sx={{ my: 2 }} />

          <Typography
            variant="body1"
            sx={{
              whiteSpace: 'pre-line',
              bgcolor: 'grey.50',
              p: 2,
              borderRadius: 1,
              mb: 3,
            }}
          >
            {result.response}
          </Typography>

          {result.findings && result.findings.length > 0 && (
            <>
              <Typography variant="subtitle1" gutterBottom>
                <Warning sx={{ mr: 1, verticalAlign: 'middle', color: 'warning.main' }} />
                Findings
              </Typography>
              <List dense>
                {result.findings.map((finding, idx) => (
                  <ListItem key={idx}>
                    <ListItemIcon>
                      <Info color="info" fontSize="small" />
                    </ListItemIcon>
                    <ListItemText
                      primary={`${finding.type} - ${finding.location || finding.vessel}`}
                      secondary={finding.degree ? `Degree: ${finding.degree}%` : undefined}
                    />
                  </ListItem>
                ))}
              </List>
            </>
          )}

          {result.recommendations && result.recommendations.length > 0 && (
            <>
              <Typography variant="subtitle1" gutterBottom sx={{ mt: 2 }}>
                <CheckCircle sx={{ mr: 1, verticalAlign: 'middle', color: 'success.main' }} />
                Recommendations
              </Typography>
              <List dense>
                {result.recommendations.map((rec, idx) => (
                  <ListItem key={idx}>
                    <ListItemIcon>
                      <ArrowForward fontSize="small" />
                    </ListItemIcon>
                    <ListItemText primary={rec} />
                  </ListItem>
                ))}
              </List>
            </>
          )}
        </Paper>
      )}
    </Box>
  );
};

export default AIAgents;
