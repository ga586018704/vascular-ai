"""
Laboratory Tests Page
Display and manage patient lab results
"""
import React, { useState, useEffect } from 'react';
import {
  Box,
  Card,
  CardContent,
  Typography,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  Paper,
  Chip,
  IconButton,
  Button,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  TextField,
  MenuItem,
  Grid,
  FormControl,
  InputLabel,
  Select,
  Alert,
  CircularProgress,
  Tabs,
  Tab,
  Tooltip,
  Autocomplete,
} from '@mui/material';
import {
  Add as AddIcon,
  Delete as DeleteIcon,
  TrendingUp as TrendingUpIcon,
  Warning as WarningIcon,
  Science as ScienceIcon,
} from '@mui/icons-material';
import { useParams } from 'react-router-dom';
import { api } from '../services/api';
import { Line } from 'react-chartjs-2';
import {
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  Title,
  Tooltip as ChartTooltip,
  Legend,
} from 'chart.js';

ChartJS.register(
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  Title,
  ChartTooltip,
  Legend
);

interface LabTestReference {
  id: number;
  test_code: string;
  test_name: string;
  test_name_ru?: string;
  category: string;
  ref_min?: number;
  ref_max?: number;
  ref_unit: string;
  critical_low?: number;
  critical_high?: number;
}

interface LabResult {
  id: number;
  test: LabTestReference;
  value: number;
  value_text?: string;
  unit: string;
  status: 'normal' | 'low' | 'high' | 'critical';
  is_critical: boolean;
  tested_at: string;
  result_at?: string;
  lab_name?: string;
  notes?: string;
}

interface LabTrend {
  test_reference_id: number;
  test_name: string;
  test_name_ru?: string;
  unit: string;
  ref_min?: number;
  ref_max?: number;
  data: { date: string; value: number; status: string }[];
}

const getStatusColor = (status: string) => {
  switch (status) {
    case 'normal': return 'success';
    case 'low': return 'warning';
    case 'high': return 'warning';
    case 'critical': return 'error';
    default: return 'default';
  }
};

const getStatusLabel = (status: string) => {
  switch (status) {
    case 'normal': return 'Норма';
    case 'low': return 'Ниже нормы';
    case 'high': return 'Выше нормы';
    case 'critical': return 'Критическое';
    default: return status;
  }
};

const LaboratoryTests: React.FC = () => {
  const { patientId } = useParams<{ patientId: string }>();
  const [activeTab, setActiveTab] = useState(0);
  const [results, setResults] = useState<LabResult[]>([]);
  const [references, setReferences] = useState<LabTestReference[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [openDialog, setOpenDialog] = useState(false);
  const [selectedTrend, setSelectedTrend] = useState<LabTrend | null>(null);
  const [trendDialogOpen, setTrendDialogOpen] = useState(false);
  
  // Filters
  const [categoryFilter, setCategoryFilter] = useState('');
  const [statusFilter, setStatusFilter] = useState('');
  const [criticalOnly, setCriticalOnly] = useState(false);

  // New result form
  const [newResult, setNewResult] = useState({
    test_reference_id: '',
    value: '',
    unit: '',
    tested_at: new Date().toISOString().slice(0, 16),
    lab_name: '',
    notes: '',
  });

  useEffect(() => {
    fetchData();
  }, [patientId]);

  const fetchData = async () => {
    try {
      setLoading(true);
      
      // Fetch lab results
      const resultsRes = await api.get(`/lab-tests/results?patient_id=${patientId}&limit=100`);
      setResults(resultsRes.data.items);
      
      // Fetch test references
      const refsRes = await api.get('/lab-tests/references');
      setReferences(refsRes.data.items);
      
      setError(null);
    } catch (err: any) {
      setError(err.response?.data?.detail || 'Failed to load lab data');
    } finally {
      setLoading(false);
    }
  };

  const handleAddResult = async () => {
    try {
      await api.post('/lab-tests/results', {
        patient_id: parseInt(patientId!),
        test_reference_id: parseInt(newResult.test_reference_id),
        value: parseFloat(newResult.value),
        unit: newResult.unit,
        tested_at: new Date(newResult.tested_at).toISOString(),
        lab_name: newResult.lab_name,
        notes: newResult.notes,
      });
      
      setOpenDialog(false);
      fetchData();
      
      // Reset form
      setNewResult({
        test_reference_id: '',
        value: '',
        unit: '',
        tested_at: new Date().toISOString().slice(0, 16),
        lab_name: '',
        notes: '',
      });
    } catch (err: any) {
      setError(err.response?.data?.detail || 'Failed to add result');
    }
  };

  const handleDeleteResult = async (id: number) => {
    if (!window.confirm('Удалить этот результат?')) return;
    
    try {
      await api.delete(`/lab-tests/results/${id}`);
      fetchData();
    } catch (err: any) {
      setError(err.response?.data?.detail || 'Failed to delete result');
    }
  };

  const handleViewTrend = async (testCode: string) => {
    try {
      const res = await api.get(`/lab-tests/trends/${patientId}/${testCode}?months=12`);
      setSelectedTrend(res.data);
      setTrendDialogOpen(true);
    } catch (err: any) {
      setError(err.response?.data?.detail || 'Failed to load trend');
    }
  };

  const filteredResults = results.filter(result => {
    if (categoryFilter && result.test.category !== categoryFilter) return false;
    if (statusFilter && result.status !== statusFilter) return false;
    if (criticalOnly && !result.is_critical) return false;
    return true;
  });

  const categories = [...new Set(references.map(r => r.category))];

  // Group results by category
  const groupedResults = filteredResults.reduce((acc, result) => {
    const cat = result.test.category;
    if (!acc[cat]) acc[cat] = [];
    acc[cat].push(result);
    return acc;
  }, {} as Record<string, LabResult[]>);

  const renderTrendChart = () => {
    if (!selectedTrend || selectedTrend.data.length === 0) return null;

    const data = {
      labels: selectedTrend.data.map(d => new Date(d.date).toLocaleDateString()),
      datasets: [
        {
          label: `${selectedTrend.test_name_ru || selectedTrend.test_name} (${selectedTrend.unit})`,
          data: selectedTrend.data.map(d => d.value),
          borderColor: 'rgb(75, 192, 192)',
          backgroundColor: 'rgba(75, 192, 192, 0.2)',
          tension: 0.1,
        },
      ],
    };

    const options = {
      responsive: true,
      plugins: {
        legend: { position: 'top' as const },
        title: { display: true, text: 'Динамика показателя' },
      },
      scales: {
        y: {
          min: selectedTrend.ref_min ? selectedTrend.ref_min * 0.8 : undefined,
          max: selectedTrend.ref_max ? selectedTrend.ref_max * 1.2 : undefined,
        },
      },
    };

    return <Line data={data} options={options} />;
  };

  if (loading) {
    return (
      <Box display="flex" justifyContent="center" alignItems="center" minHeight="400px">
        <CircularProgress />
      </Box>
    );
  }

  return (
    <Box p={3}>
      <Typography variant="h4" gutterBottom>
        <ScienceIcon sx={{ mr: 1, verticalAlign: 'middle' }} />
        Лабораторные анализы
      </Typography>

      {error && (
        <Alert severity="error" sx={{ mb: 2 }}>
          {error}
        </Alert>
      )}

      {/* Critical Values Alert */}
      {results.some(r => r.is_critical) && (
        <Alert severity="error" sx={{ mb: 2 }} icon={<WarningIcon />}>
          <Typography variant="subtitle1" fontWeight="bold">
            Внимание! Обнаружены критически важные значения
          </Typography>
          <Typography variant="body2">
            {results.filter(r => r.is_critical).map(r => 
              `${r.test.test_name_ru || r.test.test_name}: ${r.value} ${r.unit}`
            ).join(', ')}
          </Typography>
        </Alert>
      )}

      {/* Filters */}
      <Card sx={{ mb: 3 }}>
        <CardContent>
          <Grid container spacing={2} alignItems="center">
            <Grid item xs={12} md={3}>
              <FormControl fullWidth size="small">
                <InputLabel>Категория</InputLabel>
                <Select
                  value={categoryFilter}
                  onChange={(e) => setCategoryFilter(e.target.value)}
                  label="Категория"
                >
                  <MenuItem value="">Все</MenuItem>
                  {categories.map(cat => (
                    <MenuItem key={cat} value={cat}>{cat}</MenuItem>
                  ))}
                </Select>
              </FormControl>
            </Grid>
            <Grid item xs={12} md={3}>
              <FormControl fullWidth size="small">
                <InputLabel>Статус</InputLabel>
                <Select
                  value={statusFilter}
                  onChange={(e) => setStatusFilter(e.target.value)}
                  label="Статус"
                >
                  <MenuItem value="">Все</MenuItem>
                  <MenuItem value="normal">Норма</MenuItem>
                  <MenuItem value="low">Ниже нормы</MenuItem>
                  <MenuItem value="high">Выше нормы</MenuItem>
                  <MenuItem value="critical">Критическое</MenuItem>
                </Select>
              </FormControl>
            </Grid>
            <Grid item xs={12} md={3}>
              <FormControl fullWidth size="small">
                <InputLabel>Только критические</InputLabel>
                <Select
                  value={criticalOnly ? 'yes' : ''}
                  onChange={(e) => setCriticalOnly(e.target.value === 'yes')}
                  label="Только критические"
                >
                  <MenuItem value="">Нет</MenuItem>
                  <MenuItem value="yes">Да</MenuItem>
                </Select>
              </FormControl>
            </Grid>
            <Grid item xs={12} md={3}>
              <Button
                variant="contained"
                startIcon={<AddIcon />}
                onClick={() => setOpenDialog(true)}
                fullWidth
              >
                Добавить результат
              </Button>
            </Grid>
          </Grid>
        </CardContent>
      </Card>

      {/* Results by Category */}
      <Tabs
        value={activeTab}
        onChange={(_, value) => setActiveTab(value)}
        sx={{ mb: 2 }}
      >
        <Tab label="Все результаты" />
        <Tab label="По категориям" />
        <Tab label="Панели" />
      </Tabs>

      {activeTab === 0 && (
        <TableContainer component={Paper}>
          <Table>
            <TableHead>
              <TableRow>
                <TableCell>Дата</TableCell>
                <TableCell>Анализ</TableCell>
                <TableCell>Значение</TableCell>
                <TableCell>Норма</TableCell>
                <TableCell>Статус</TableCell>
                <TableCell>Лаборатория</TableCell>
                <TableCell>Действия</TableCell>
              </TableRow>
            </TableHead>
            <TableBody>
              {filteredResults.map((result) => (
                <TableRow key={result.id}>
                  <TableCell>
                    {new Date(result.tested_at).toLocaleDateString()}
                  </TableCell>
                  <TableCell>
                    <Typography variant="body2" fontWeight="medium">
                      {result.test.test_name_ru || result.test.test_name}
                    </Typography>
                    <Typography variant="caption" color="text.secondary">
                      {result.test.test_code}
                    </Typography>
                  </TableCell>
                  <TableCell>
                    <Typography variant="body1" fontWeight="bold">
                      {result.value} {result.unit}
                    </Typography>
                  </TableCell>
                  <TableCell>
                    {result.test.ref_min !== undefined && result.test.ref_max !== undefined ? (
                      <Typography variant="body2" color="text.secondary">
                        {result.test.ref_min} - {result.test.ref_max} {result.test.ref_unit}
                      </Typography>
                    ) : (
                      <Typography variant="body2" color="text.secondary">
                        Н/Д
                      </Typography>
                    )}
                  </TableCell>
                  <TableCell>
                    <Chip
                      label={getStatusLabel(result.status)}
                      color={getStatusColor(result.status) as any}
                      size="small"
                    />
                  </TableCell>
                  <TableCell>{result.lab_name || '-'}</TableCell>
                  <TableCell>
                    <Tooltip title="Тренд">
                      <IconButton
                        size="small"
                        onClick={() => handleViewTrend(result.test.test_code)}
                      >
                        <TrendingUpIcon />
                      </IconButton>
                    </Tooltip>
                    <Tooltip title="Удалить">
                      <IconButton
                        size="small"
                        color="error"
                        onClick={() => handleDeleteResult(result.id)}
                      >
                        <DeleteIcon />
                      </IconButton>
                    </Tooltip>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </TableContainer>
      )}

      {activeTab === 1 && (
        Object.entries(groupedResults).map(([category, catResults]) => (
          <Card key={category} sx={{ mb: 2 }}>
            <CardContent>
              <Typography variant="h6" gutterBottom>
                {category}
              </Typography>
              <TableContainer>
                <Table size="small">
                  <TableBody>
                    {catResults.map((result) => (
                      <TableRow key={result.id}>
                        <TableCell>{result.test.test_name_ru || result.test.test_name}</TableCell>
                        <TableCell>
                          <Typography fontWeight="bold">
                            {result.value} {result.unit}
                          </Typography>
                        </TableCell>
                        <TableCell>
                          <Chip
                            label={getStatusLabel(result.status)}
                            color={getStatusColor(result.status) as any}
                            size="small"
                          />
                        </TableCell>
                        <TableCell>
                          {new Date(result.tested_at).toLocaleDateString()}
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </TableContainer>
            </CardContent>
          </Card>
        ))
      )}

      {activeTab === 2 && (
        <Grid container spacing={2}>
          <Grid item xs={12} md={4}>
            <Card>
              <CardContent>
                <Typography variant="h6" gutterBottom>
                  Предоперационный скрининг
                </Typography>
                <Typography variant="body2" color="text.secondary" paragraph>
                  Стандартный набор анализов перед сосудистой операцией
                </Typography>
                <Button
                  variant="outlined"
                  fullWidth
                  onClick={() => api.get('/lab-tests/panels/preoperative')}
                >
                  Просмотреть панель
                </Button>
              </CardContent>
            </Card>
          </Grid>
          <Grid item xs={12} md={4}>
            <Card>
              <CardContent>
                <Typography variant="h6" gutterBottom>
                  Коагулограмма
                </Typography>
                <Typography variant="body2" color="text.secondary" paragraph>
                  Тесты свёртываемости крови
                </Typography>
                <Button
                  variant="outlined"
                  fullWidth
                  onClick={() => api.get('/lab-tests/panels/coagulation')}
                >
                  Просмотреть панель
                </Button>
              </CardContent>
            </Card>
          </Grid>
          <Grid item xs={12} md={4}>
            <Card>
              <CardContent>
                <Typography variant="h6" gutterBottom>
                  Липидный профиль
                </Typography>
                <Typography variant="body2" color="text.secondary" paragraph>
                  Оценка сердечно-сосудистого риска
                </Typography>
                <Button
                  variant="outlined"
                  fullWidth
                  onClick={() => api.get('/lab-tests/panels/lipid')}
                >
                  Просмотреть панель
                </Button>
              </CardContent>
            </Card>
          </Grid>
        </Grid>
      )}

      {/* Add Result Dialog */}
      <Dialog open={openDialog} onClose={() => setOpenDialog(false)} maxWidth="md" fullWidth>
        <DialogTitle>Добавить результат анализа</DialogTitle>
        <DialogContent>
          <Grid container spacing={2} sx={{ mt: 1 }}>
            <Grid item xs={12}>
              <Autocomplete
                options={references}
                getOptionLabel={(option) => `${option.test_code} - ${option.test_name_ru || option.test_name}`}
                onChange={(_, value) => {
                  if (value) {
                    setNewResult({
                      ...newResult,
                      test_reference_id: value.id.toString(),
                      unit: value.ref_unit,
                    });
                  }
                }}
                renderInput={(params) => (
                  <TextField {...params} label="Анализ" fullWidth required />
                )}
              />
            </Grid>
            <Grid item xs={12} md={6}>
              <TextField
                label="Значение"
                type="number"
                value={newResult.value}
                onChange={(e) => setNewResult({ ...newResult, value: e.target.value })}
                fullWidth
                required
              />
            </Grid>
            <Grid item xs={12} md={6}>
              <TextField
                label="Единицы"
                value={newResult.unit}
                onChange={(e) => setNewResult({ ...newResult, unit: e.target.value })}
                fullWidth
                required
              />
            </Grid>
            <Grid item xs={12} md={6}>
              <TextField
                label="Дата взятия"
                type="datetime-local"
                value={newResult.tested_at}
                onChange={(e) => setNewResult({ ...newResult, tested_at: e.target.value })}
                fullWidth
                required
                InputLabelProps={{ shrink: true }}
              />
            </Grid>
            <Grid item xs={12} md={6}>
              <TextField
                label="Лаборатория"
                value={newResult.lab_name}
                onChange={(e) => setNewResult({ ...newResult, lab_name: e.target.value })}
                fullWidth
              />
            </Grid>
            <Grid item xs={12}>
              <TextField
                label="Примечания"
                value={newResult.notes}
                onChange={(e) => setNewResult({ ...newResult, notes: e.target.value })}
                fullWidth
                multiline
                rows={2}
              />
            </Grid>
          </Grid>
        </DialogContent>
        <DialogActions>
          <Button onClick={() => setOpenDialog(false)}>Отмена</Button>
          <Button onClick={handleAddResult} variant="contained">
            Сохранить
          </Button>
        </DialogActions>
      </Dialog>

      {/* Trend Dialog */}
      <Dialog
        open={trendDialogOpen}
        onClose={() => setTrendDialogOpen(false)}
        maxWidth="lg"
        fullWidth
      >
        <DialogTitle>
          Динамика: {selectedTrend?.test_name_ru || selectedTrend?.test_name}
        </DialogTitle>
        <DialogContent>
          <Box sx={{ height: 400 }}>
            {renderTrendChart()}
          </Box>
          {selectedTrend && (
            <Box mt={2}>
              <Typography variant="body2" color="text.secondary">
                Референсные значения: {selectedTrend.ref_min} - {selectedTrend.ref_max} {selectedTrend.unit}
              </Typography>
              <Typography variant="body2" color="text.secondary">
                Всего измерений: {selectedTrend.data.length}
              </Typography>
            </Box>
          )}
        </DialogContent>
        <DialogActions>
          <Button onClick={() => setTrendDialogOpen(false)}>Закрыть</Button>
        </DialogActions>
      </Dialog>
    </Box>
  );
};

export default LaboratoryTests;
