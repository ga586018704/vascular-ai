import axios from 'axios';

const API_URL = import.meta.env.VITE_API_URL || 'http://localhost:8000';

export const api = axios.create({
  baseURL: `${API_URL}/api`,
  headers: {
    'Content-Type': 'application/json',
  },
});

// Add auth token to requests
api.interceptors.request.use((config) => {
  const token = localStorage.getItem('token');
  if (token) {
    config.headers.Authorization = `Bearer ${token}`;
  }
  return config;
});

// Handle auth errors
api.interceptors.response.use(
  (response) => response,
  (error) => {
    if (error.response?.status === 401) {
      localStorage.removeItem('token');
      window.location.href = '/login';
    }
    return Promise.reject(error);
  }
);

// Auth API
export const authApi = {
  login: (username: string, password: string) =>
    api.post('/auth/login', new URLSearchParams({ username, password }), {
      headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
    }),
  register: (data: {
    username: string;
    email: string;
    password: string;
    full_name: string;
  }) => api.post('/auth/register', data),
  getMe: () => api.get('/auth/me'),
  logout: () => api.post('/auth/logout'),
};

// DICOM API
export const dicomApi = {
  upload: (formData: FormData) =>
    api.post('/dicom/upload', formData, {
      headers: { 'Content-Type': 'multipart/form-data' },
    }),
  getStudies: (params?: { skip?: number; limit?: number; status?: string }) =>
    api.get('/dicom/studies', { params }),
  getStudy: (studyId: string) => api.get(`/dicom/studies/${studyId}`),
  deleteStudy: (studyId: string) => api.delete(`/dicom/studies/${studyId}`),
};

// Angiography API
export const angiographyApi = {
  analyze: (formData: FormData) =>
    api.post('/angiography/analyze', formData, {
      headers: { 'Content-Type': 'multipart/form-data' },
    }),
  getVessels: () => api.get('/angiography/vessels'),
  getPathologies: () => api.get('/angiography/pathologies'),
};

// AI Agents API
export const agentsApi = {
  getAgents: () => api.get('/agents/'),
  analyze: (data: {
    agent_type: string;
    query: string;
    context?: Record<string, unknown>;
    patient_data?: Record<string, unknown>;
  }) => api.post('/agents/analyze', data),
};

// Risk Calculators API
export const calculatorsApi = {
  getCalculators: () => api.get('/calculators/'),
  calculateVSGNE: (data: {
    age: number;
    cad?: boolean;
    chf?: boolean;
    copd?: boolean;
    diabetes?: boolean;
    creatinine: number;
    urgent_procedure?: boolean;
  }) => api.post('/calculators/vsgne', data),
  calculateWells: (data: {
    active_cancer?: boolean;
    bedridden_recently?: boolean;
    calf_swelling?: boolean;
    collateral_veins?: boolean;
    entire_leg_swollen?: boolean;
    localized_tenderness?: boolean;
    pitting_edema?: boolean;
    paralysis_paresis?: boolean;
    previous_dvt?: boolean;
    alternative_diagnosis_less_likely?: boolean;
  }) => api.post('/calculators/wells-dvt', data),
  calculateGAS: (data: {
    age: number;
    gender: string;
    bmi: number;
    hypertension?: boolean;
    diabetes?: boolean;
    smoking?: boolean;
    family_history?: boolean;
  }) => api.post('/calculators/gas', data),
};

// Reports API
export const reportsApi = {
  getReports: (params?: { skip?: number; limit?: number; status?: string }) =>
    api.get('/reports/', { params }),
  getReport: (reportId: string) => api.get(`/reports/${reportId}`),
  createReport: (data: {
    title: string;
    report_type: string;
    content: string;
    findings?: string;
    impression?: string;
    recommendations?: string;
    patient_id: number;
    study_id?: number;
  }) => api.post('/reports/', data),
  updateReport: (reportId: string, data: Record<string, unknown>) =>
    api.put(`/reports/${reportId}`, data),
  deleteReport: (reportId: string) => api.delete(`/reports/${reportId}`),
};

// Analytics API
export const analyticsApi = {
  getDashboard: () => api.get('/analytics/dashboard'),
  getActivity: (days?: number) =>
    api.get('/analytics/activity', { params: { days } }),
  getSystemHealth: () => api.get('/analytics/system-health'),
  getUserActivity: (userId: number, days?: number) =>
    api.get(`/analytics/user-activity/${userId}`, { params: { days } }),
  getTimeSeries: (
    metric: string,
    params: { start_date: string; end_date: string; interval?: string }
  ) => api.get(`/analytics/timeseries/${metric}`, { params }),
};
