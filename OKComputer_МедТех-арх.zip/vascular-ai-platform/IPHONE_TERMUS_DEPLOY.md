# 📱 Развёртывание VASCULAR.AI через iPhone + Termius

## Быстрый старт (10 минут)

---

## Шаг 1: Установи Termius (1 мин)

1. Открой **App Store**
2. Найди **"Termius"**
3. Установи (бесплатно)

---

## Шаг 2: Арендуй сервер в Hetzner (3 мин)

### В Safari:

1. Перейди на **console.hetzner.cloud**
2. Зарегистрируйся (email + пароль)
3. Подтверди email
4. Добавь карту (Visa/Mastercard)

### Создай сервер:

1. Нажми **"Add Server"**
2. Настройки:
   - **Location:** Nuremberg
   - **Image:** Ubuntu 22.04
   - **Type:** CX21 (€6.21/мес)
   - **SSH Keys:** Пропусти
   - **Name:** `vascular-ai`
3. Нажми **"Create & Buy"**

### Скопируй IP адрес

Нажми на IP (например `78.46.123.45`) и скопируй

---

## Шаг 3: Подключись через Termius (2 мин)

### В приложении Termius:

1. Нажми **"+"** (внизу справа)
2. Выбери **"New Host"**
3. Заполни:
   ```
   Alias: Vascular AI
   Hostname: ТВОЙ_IP (вставь скопированный)
   Username: root
   Password: (оставь пустым)
   ```
4. Нажми **"Save"**
5. Нажми на созданный хост
6. Введи пароль (пришёл на email от Hetzner)

---

## Шаг 4: Установи платформу (4 мин)

### В Termius вставь эту команду:

**Длинное нажатие** на экране → **Paste**

```bash
curl -fsSL https://raw.githubusercontent.com/vascular-ai/deploy/main/install.sh | bash
```

Жди пока установится (5-10 минут)

---

## Шаг 5: Добавь API ключи (2 мин)

### В Termius:

```bash
nano /opt/vascular-ai/.env
```

### В открывшемся редакторе:

Найди строки:
```
OPENAI_API_KEY=
ANTHROPIC_API_KEY=
```

Добавь свои ключи:
```
OPENAI_API_KEY=sk-your-key-here
ANTHROPIC_API_KEY=sk-ant-your-key-here
```

### Сохрани:

На виртуальной клавиатуре Termius:
1. Нажми **Ctrl+O**
2. Нажми **Enter**
3. Нажми **Ctrl+X**

### Перезапусти:

```bash
cd /opt/vascular-ai && docker compose -f docker-compose.prod.yml restart api
```

---

## ✅ Готово!

Открой в Safari:
- **Веб:** `http://ТВОЙ_IP`
- **API:** `http://ТВОЙ_IP/docs`

---

## 📋 Полезные команды (копируй в Termius)

### Проверить статус:
```bash
cd /opt/vascular-ai && docker compose ps
```

### Посмотреть логи:
```bash
cd /opt/vascular-ai && docker compose logs -f
```

### Перезапустить:
```bash
cd /opt/vascular-ai && docker compose restart
```

### Остановить:
```bash
cd /opt/vascular-ai && docker compose down
```

### Запустить снова:
```bash
cd /opt/vascular-ai && docker compose up -d
```

---

## 💰 Стоимость

- Сервер Hetzner CX21: **€6.21/мес** (~$6.80)
- Termius: **Бесплатно**
- Всего: **~$7/мес**

---

## ❓ Проблемы?

### Не подключается к серверу?
- Подожди 2-3 минуты после создания
- Проверь правильность IP

### Ошибка при установке?
```bash
cd /opt/vascular-ai && docker compose down
curl -fsSL https://raw.githubusercontent.com/vascular-ai/deploy/main/install.sh | bash
```

### Забыл пароль?
В Hetzner Console → Servers → vascular-ai → **Reset Root Password**

---

## 🎉 Поздравляю!

Твоя VASCULAR.AI платформа запущена!

Пиши мне если нужна помощь 🚀
