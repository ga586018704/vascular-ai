# VASCULAR.AI - Быстрый старт 🚀

## Развёртывание за 10 минут

### 1. Подготовь файлы (на твоём компьютере)

```bash
cd /mnt/okcomputer/output/vascular-ai-platform

# Запусти подготовку
./scripts/prepare-for-deploy.sh
```

Это создаст архив `vascular-ai-deploy-YYYYMMDD.tar.gz`

---

### 2. Арендуй сервер (Hetzner)

1. Перейди на [console.hetzner.cloud](https://console.hetzner.cloud/)
2. Создай проект → "Add Server"
3. Настройки:
   - **Location:** Nuremberg (или ближайший к тебе)
   - **Image:** Ubuntu 22.04
   - **Type:** CX21 (2 vCPU, 4 GB RAM, 40 GB) — **€6.21/мес**
   - **SSH Key:** Добавь свой ключ
4. Нажми "Create & Buy"

**Скопируй IP адрес сервера** (например, `78.46.123.45`)

---

### 3. Загрузи и запусти (одна команда!)

```bash
# Замени YOUR_SERVER_IP на реальный IP
export SERVER_IP=YOUR_SERVER_IP

# 1. Загрузи архив на сервер
scp vascular-ai-deploy-*.tar.gz root@$SERVER_IP:/tmp/

# 2. Подключись и разверни
ssh root@$SERVER_IP << 'REMOTE_COMMANDS'
  # Установи Docker
  curl -fsSL https://get.docker.com | sh
  
  # Создай директорию и распакуй
  mkdir -p /opt/vascular-ai
  tar -xzf /tmp/vascular-ai-deploy-*.tar.gz -C /opt/vascular-ai/
  
  # Запусти
  cd /opt/vascular-ai
  
  # Создай .env с секретами
  POSTGRES_PASSWORD=$(openssl rand -base64 32)
  SECRET_KEY=$(openssl rand -hex 64)
  
  cat > .env << EOF
POSTGRES_DB=vascular_ai
POSTGRES_USER=vascular
POSTGRES_PASSWORD=$POSTGRES_PASSWORD
SECRET_KEY=$SECRET_KEY
OPENAI_API_KEY=
ANTHROPIC_API_KEY=
GRAFANA_USER=admin
GRAFANA_PASSWORD=$(openssl rand -base64 16)
EOF
  
  # Запусти платформу
  docker compose -f docker-compose.prod.yml up -d --build
  
  echo "======================================"
  echo "Platform deployed!"
  echo "Website: http://$(curl -s ifconfig.me)"
  echo "API Docs: http://$(curl -s ifconfig.me)/docs"
  echo "======================================"
REMOTE_COMMANDS
```

---

### 4. Добавь API ключи

```bash
ssh root@$SERVER_IP

# Отредактируй .env
nano /opt/vascular-ai/.env
```

Добавь:
```bash
OPENAI_API_KEY=sk-your-key-here
ANTHROPIC_API_KEY=sk-ant-your-key-here
```

Сохрани (Ctrl+O, Enter, Ctrl+X) и перезапусти:
```bash
cd /opt/vascular-ai
docker compose -f docker-compose.prod.yml restart api
```

---

### 5. Готово! 🎉

Открой в браузере: `http://YOUR_SERVER_IP`

---

## Управление

```bash
# Подключись к серверу
ssh root@YOUR_SERVER_IP

cd /opt/vascular-ai

# Статус
docker compose -f docker-compose.prod.yml ps

# Логи
docker compose -f docker-compose.prod.yml logs -f

# Перезапуск
docker compose -f docker-compose.prod.yml restart

# Остановка
docker compose -f docker-compose.prod.yml down

# Обновление
docker compose -f docker-compose.prod.yml pull
docker compose -f docker-compose.prod.yml up -d
```

---

## Добавить домен + SSL

```bash
ssh root@YOUR_SERVER_IP

# Установи certbot
apt install -y certbot

# Получи сертификат (замени your-domain.com)
certbot certonly --standalone -d your-domain.com --agree-tos -m your@email.com

# Обнови nginx
sed -i 's/# server {/server {/' /opt/vascular-ai/nginx/nginx.conf
sed -i 's/#     listen 443/    listen 443/' /opt/vascular-ai/nginx/nginx.conf
sed -i 's/#     ssl_certificate/    ssl_certificate/' /opt/vascular-ai/nginx/nginx.conf
sed -i 's/your-domain.com/your-domain.com/g' /opt/vascular-ai/nginx/nginx.conf

# Перезапусти
cd /opt/vascular-ai
docker compose -f docker-compose.prod.yml restart nginx
```

---

## 💰 Стоимость

| Компонент | Цена |
|-----------|------|
| Сервер Hetzner CX21 | €6.21/мес (~$6.80) |
| Домен (опционально) | ~$10/год |
| SSL сертификат | Бесплатно (Let's Encrypt) |
| **Итого** | **~$7/мес** |

---

## ❓ Проблемы?

```bash
# Проверь статус
ssh root@YOUR_SERVER_IP "docker ps"

# Посмотри логи
ssh root@YOUR_SERVER_IP "cd /opt/vascular-ai && docker compose logs -f"

# Перезапусти всё
ssh root@YOUR_SERVER_IP "cd /opt/vascular-ai && docker compose restart"
```

Пиши мне — помогу! 🚀
