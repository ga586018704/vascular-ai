#!/bin/bash

# VASCULAR.AI Startup Script
# Usage: ./start.sh [backend|frontend|all|docker]

set -e

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Function to print colored output
print_status() {
    echo -e "${BLUE}[INFO]${NC} $1"
}

print_success() {
    echo -e "${GREEN}[SUCCESS]${NC} $1"
}

print_warning() {
    echo -e "${YELLOW}[WARNING]${NC} $1"
}

print_error() {
    echo -e "${RED}[ERROR]${NC} $1"
}

# Function to check if command exists
command_exists() {
    command -v "$1" >/dev/null 2>&1
}

# Function to start backend
start_backend() {
    print_status "Starting VASCULAR.AI Backend..."
    
    cd backend
    
    # Check if virtual environment exists
    if [ ! -d "venv" ]; then
        print_status "Creating virtual environment..."
        python3 -m venv venv
    fi
    
    # Activate virtual environment
    source venv/bin/activate
    
    # Install dependencies
    print_status "Installing backend dependencies..."
    pip install -q -r requirements.txt
    
    # Check if .env exists
    if [ ! -f ".env" ]; then
        print_warning ".env file not found, copying from .env.example"
        cp .env.example .env
    fi
    
    # Start the server
    print_success "Starting backend server on http://localhost:8000"
    uvicorn app.main:app --reload --host 0.0.0.0 --port 8000
}

# Function to start frontend
start_frontend() {
    print_status "Starting VASCULAR.AI Frontend..."
    
    cd frontend
    
    # Check if node_modules exists
    if [ ! -d "node_modules" ]; then
        print_status "Installing frontend dependencies..."
        npm install
    fi
    
    # Check if .env exists
    if [ ! -f ".env" ]; then
        print_warning ".env file not found, copying from .env.example"
        cp .env.example .env
    fi
    
    # Start the development server
    print_success "Starting frontend server on http://localhost:5173"
    npm run dev
}

# Function to start with Docker
start_docker() {
    print_status "Starting VASCULAR.AI with Docker..."
    
    # Check if Docker is installed
    if ! command_exists docker; then
        print_error "Docker is not installed. Please install Docker first."
        exit 1
    fi
    
    if ! command_exists docker-compose; then
        print_error "Docker Compose is not installed. Please install Docker Compose first."
        exit 1
    fi
    
    # Start services
    print_status "Building and starting Docker containers..."
    docker-compose up --build -d
    
    print_success "VASCULAR.AI is running!"
    print_status "Backend: http://localhost:8000"
    print_status "Frontend: http://localhost:3000"
    print_status "API Docs: http://localhost:8000/docs"
}

# Function to run tests
run_tests() {
    print_status "Running tests..."
    
    # Backend tests
    print_status "Running backend tests..."
    cd backend
    source venv/bin/activate 2>/dev/null || true
    pytest -v
    cd ..
    
    # Frontend tests
    print_status "Running frontend tests..."
    cd frontend
    npm run test -- --watchAll=false
    cd ..
    
    print_success "All tests completed!"
}

# Function to show help
show_help() {
    echo "VASCULAR.AI Startup Script"
    echo ""
    echo "Usage: ./start.sh [command]"
    echo ""
    echo "Commands:"
    echo "  backend   Start only the backend server"
    echo "  frontend  Start only the frontend server"
    echo "  all       Start both backend and frontend (default)"
    echo "  docker    Start using Docker Compose"
    echo "  test      Run all tests"
    echo "  help      Show this help message"
    echo ""
    echo "Examples:"
    echo "  ./start.sh              # Start both backend and frontend"
    echo "  ./start.sh backend      # Start only backend"
    echo "  ./start.sh docker       # Start with Docker"
    echo "  ./start.sh test         # Run tests"
}

# Main script logic
case "${1:-all}" in
    backend)
        start_backend
        ;;
    frontend)
        start_frontend
        ;;
    all)
        # Start backend in background
        start_backend &
        BACKEND_PID=$!
        
        # Wait a moment for backend to start
        sleep 3
        
        # Start frontend
        start_frontend
        
        # Kill backend when frontend exits
        kill $BACKEND_PID 2>/dev/null || true
        ;;
    docker)
        start_docker
        ;;
    test)
        run_tests
        ;;
    help|--help|-h)
        show_help
        ;;
    *)
        print_error "Unknown command: $1"
        show_help
        exit 1
        ;;
esac
