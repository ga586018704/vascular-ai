"""
Add laboratory tests tables

Revision ID: 004
Revises: 003
Create Date: 2024-01-20 00:00:00.000000

"""
from typing import Sequence, Union

from alembic import op
import sqlalchemy as sa
from sqlalchemy.dialects import postgresql

# revision identifiers, used by Alembic.
revision: str = '004'
down_revision: Union[str, None] = '003'
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    """Create lab test tables"""
    
    # Create lab_test_references table
    op.create_table(
        'lab_test_references',
        sa.Column('id', sa.Integer(), nullable=False),
        sa.Column('test_code', sa.String(50), nullable=False),
        sa.Column('test_name', sa.String(200), nullable=False),
        sa.Column('test_name_ru', sa.String(200), nullable=True),
        sa.Column('category', sa.Enum(
            'COAGULATION', 'LIPID', 'BIOCHEMISTRY', 'CBC', 
            'INFLAMMATION', 'CARDIAC', 'KIDNEY', 'DIABETES', 
            'THYROID', 'TUMOR', 'OTHER',
            name='labtestcategory'
        ), nullable=False),
        sa.Column('ref_min', sa.Float(), nullable=True),
        sa.Column('ref_max', sa.Float(), nullable=True),
        sa.Column('ref_unit', sa.String(50), nullable=False),
        sa.Column('critical_low', sa.Float(), nullable=True),
        sa.Column('critical_high', sa.Float(), nullable=True),
        sa.Column('clinical_significance', sa.Text(), nullable=True),
        sa.Column('vascular_relevance', sa.Text(), nullable=True),
        sa.Column('source', sa.String(200), nullable=True),
        sa.Column('created_at', sa.DateTime(), nullable=True),
        sa.Column('updated_at', sa.DateTime(), nullable=True),
        sa.PrimaryKeyConstraint('id'),
        sa.UniqueConstraint('test_code')
    )
    op.create_index('ix_lab_test_references_code', 'lab_test_references', ['test_code'])
    op.create_index('ix_lab_test_references_category', 'lab_test_references', ['category'])
    
    # Create patient_lab_results table
    op.create_table(
        'patient_lab_results',
        sa.Column('id', sa.Integer(), nullable=False),
        sa.Column('patient_id', sa.Integer(), nullable=False),
        sa.Column('test_reference_id', sa.Integer(), nullable=False),
        sa.Column('value', sa.Float(), nullable=False),
        sa.Column('value_text', sa.String(500), nullable=True),
        sa.Column('unit', sa.String(50), nullable=False),
        sa.Column('tested_at', sa.DateTime(), nullable=False),
        sa.Column('result_at', sa.DateTime(), nullable=True),
        sa.Column('lab_name', sa.String(200), nullable=True),
        sa.Column('notes', sa.Text(), nullable=True),
        sa.Column('created_at', sa.DateTime(), nullable=True),
        sa.Column('updated_at', sa.DateTime(), nullable=True),
        sa.Column('created_by_id', sa.Integer(), nullable=True),
        sa.ForeignKeyConstraint(['patient_id'], ['patients.id']),
        sa.ForeignKeyConstraint(['test_reference_id'], ['lab_test_references.id']),
        sa.PrimaryKeyConstraint('id')
    )
    op.create_index('ix_patient_lab_results_patient', 'patient_lab_results', ['patient_id'])
    op.create_index('ix_patient_lab_results_test', 'patient_lab_results', ['test_reference_id'])
    op.create_index('ix_patient_lab_results_patient_date', 'patient_lab_results', ['patient_id', 'tested_at'])
    op.create_index('ix_patient_lab_results_test_date', 'patient_lab_results', ['test_reference_id', 'tested_at'])


def downgrade() -> None:
    """Drop lab test tables"""
    op.drop_index('ix_patient_lab_results_test_date', table_name='patient_lab_results')
    op.drop_index('ix_patient_lab_results_patient_date', table_name='patient_lab_results')
    op.drop_index('ix_patient_lab_results_test', table_name='patient_lab_results')
    op.drop_index('ix_patient_lab_results_patient', table_name='patient_lab_results')
    op.drop_table('patient_lab_results')
    
    op.drop_index('ix_lab_test_references_category', table_name='lab_test_references')
    op.drop_index('ix_lab_test_references_code', table_name='lab_test_references')
    op.drop_table('lab_test_references')
    
    # Drop enum type
    op.execute('DROP TYPE IF EXISTS labtestcategory')
