"""
Add soft delete columns

Revision ID: 003
Revises: 002
Create Date: 2024-01-15 00:00:00.000000

"""
from typing import Sequence, Union

from alembic import op
import sqlalchemy as sa
from sqlalchemy.dialects import postgresql

# revision identifiers, used by Alembic.
revision: str = '003'
down_revision: Union[str, None] = '002'
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    """Add soft delete columns to all main tables"""
    
    # Add soft delete columns to patients table
    op.add_column('patients', sa.Column('deleted_at', sa.DateTime(), nullable=True))
    op.add_column('patients', sa.Column('created_by_id', sa.Integer(), nullable=True))
    op.add_column('patients', sa.Column('updated_by_id', sa.Integer(), nullable=True))
    op.create_index('ix_patients_deleted_at', 'patients', ['deleted_at'])
    
    # Add soft delete columns to studies table
    op.add_column('studies', sa.Column('deleted_at', sa.DateTime(), nullable=True))
    op.add_column('studies', sa.Column('created_by_id', sa.Integer(), nullable=True))
    op.add_column('studies', sa.Column('updated_by_id', sa.Integer(), nullable=True))
    op.create_index('ix_studies_deleted_at', 'studies', ['deleted_at'])
    
    # Add soft delete columns to dicom_files table
    op.add_column('dicom_files', sa.Column('deleted_at', sa.DateTime(), nullable=True))
    op.add_column('dicom_files', sa.Column('created_by_id', sa.Integer(), nullable=True))
    op.add_column('dicom_files', sa.Column('updated_by_id', sa.Integer(), nullable=True))
    op.create_index('ix_dicom_files_deleted_at', 'dicom_files', ['deleted_at'])
    
    # Add soft delete columns to reports table
    op.add_column('reports', sa.Column('deleted_at', sa.DateTime(), nullable=True))
    op.add_column('reports', sa.Column('created_by_id', sa.Integer(), nullable=True))
    op.add_column('reports', sa.Column('updated_by_id', sa.Integer(), nullable=True))
    op.create_index('ix_reports_deleted_at', 'reports', ['deleted_at'])
    
    # Add soft delete columns to ai_analyses table
    op.add_column('ai_analyses', sa.Column('deleted_at', sa.DateTime(), nullable=True))
    op.add_column('ai_analyses', sa.Column('created_by_id', sa.Integer(), nullable=True))
    op.add_column('ai_analyses', sa.Column('updated_by_id', sa.Integer(), nullable=True))
    op.create_index('ix_ai_analyses_deleted_at', 'ai_analyses', ['deleted_at'])
    
    # Add soft delete columns to risk_calculations table
    op.add_column('risk_calculations', sa.Column('deleted_at', sa.DateTime(), nullable=True))
    op.add_column('risk_calculations', sa.Column('created_by_id', sa.Integer(), nullable=True))
    op.add_column('risk_calculations', sa.Column('updated_by_id', sa.Integer(), nullable=True))
    op.create_index('ix_risk_calculations_deleted_at', 'risk_calculations', ['deleted_at'])
    
    # Add soft delete columns to audit_logs table (for completeness)
    op.add_column('audit_logs', sa.Column('deleted_at', sa.DateTime(), nullable=True))
    op.create_index('ix_audit_logs_deleted_at', 'audit_logs', ['deleted_at'])
    
    # Create partial indexes for active records (where deleted_at is NULL)
    # This optimizes queries that only look at non-deleted records
    op.execute("""
        CREATE INDEX ix_patients_active ON patients (id) 
        WHERE deleted_at IS NULL
    """)
    op.execute("""
        CREATE INDEX ix_studies_active ON studies (patient_id, created_at) 
        WHERE deleted_at IS NULL
    """)
    op.execute("""
        CREATE INDEX ix_dicom_files_active ON dicom_files (study_id) 
        WHERE deleted_at IS NULL
    """)
    op.execute("""
        CREATE INDEX ix_reports_active ON reports (patient_id, created_at) 
        WHERE deleted_at IS NULL
    """)


def downgrade() -> None:
    """Remove soft delete columns"""
    
    # Drop partial indexes
    op.drop_index('ix_reports_active', table_name='reports')
    op.drop_index('ix_dicom_files_active', table_name='dicom_files')
    op.drop_index('ix_studies_active', table_name='studies')
    op.drop_index('ix_patients_active', table_name='patients')
    
    # Drop audit_logs columns
    op.drop_index('ix_audit_logs_deleted_at', table_name='audit_logs')
    op.drop_column('audit_logs', 'deleted_at')
    
    # Drop risk_calculations columns
    op.drop_index('ix_risk_calculations_deleted_at', table_name='risk_calculations')
    op.drop_column('risk_calculations', 'updated_by_id')
    op.drop_column('risk_calculations', 'created_by_id')
    op.drop_column('risk_calculations', 'deleted_at')
    
    # Drop ai_analyses columns
    op.drop_index('ix_ai_analyses_deleted_at', table_name='ai_analyses')
    op.drop_column('ai_analyses', 'updated_by_id')
    op.drop_column('ai_analyses', 'created_by_id')
    op.drop_column('ai_analyses', 'deleted_at')
    
    # Drop reports columns
    op.drop_index('ix_reports_deleted_at', table_name='reports')
    op.drop_column('reports', 'updated_by_id')
    op.drop_column('reports', 'created_by_id')
    op.drop_column('reports', 'deleted_at')
    
    # Drop dicom_files columns
    op.drop_index('ix_dicom_files_deleted_at', table_name='dicom_files')
    op.drop_column('dicom_files', 'updated_by_id')
    op.drop_column('dicom_files', 'created_by_id')
    op.drop_column('dicom_files', 'deleted_at')
    
    # Drop studies columns
    op.drop_index('ix_studies_deleted_at', table_name='studies')
    op.drop_column('studies', 'updated_by_id')
    op.drop_column('studies', 'created_by_id')
    op.drop_column('studies', 'deleted_at')
    
    # Drop patients columns
    op.drop_index('ix_patients_deleted_at', table_name='patients')
    op.drop_column('patients', 'updated_by_id')
    op.drop_column('patients', 'created_by_id')
    op.drop_column('patients', 'deleted_at')
