"""
CT Angiography Background Processing Tasks
"""
import json
import os
from typing import Dict, Any, List
from celery import shared_task
import pydicom
import logging

from app.core.dicom_processor import process_ct_angiography
from app.services.treatment_service import generate_treatment_plan

logger = logging.getLogger(__name__)


@shared_task(bind=True, max_retries=2, time_limit=1800)
def process_angiography_async(
    self,
    dicom_files: List[str],
    patient_factors: str,
    user_id: int
) -> Dict[str, Any]:
    """
    Process CT angiography asynchronously
    
    Args:
        dicom_files: List of paths to DICOM files
        patient_factors: JSON string of patient factors
        user_id: ID of requesting user
        
    Returns:
        Complete analysis results
    """
    try:
        logger.info(f"Starting angiography processing for user {user_id}")
        
        # Parse patient factors
        factors = json.loads(patient_factors)
        
        # Read DICOM files
        dicom_datasets = []
        for file_path in dicom_files:
            try:
                ds = pydicom.dcmread(file_path)
                dicom_datasets.append(ds)
            except Exception as e:
                logger.error(f"Failed to read DICOM {file_path}: {e}")
                continue
        
        if not dicom_datasets:
            raise ValueError("No valid DICOM files found")
        
        logger.info(f"Loaded {len(dicom_datasets)} DICOM files")
        
        # Update progress
        self.update_state(
            state='PROGRESS',
            meta={'current': 20, 'total': 100, 'status': 'Processing DICOM files...'}
        )
        
        # Process angiography
        study = process_ct_angiography(dicom_datasets)
        
        self.update_state(
            state='PROGRESS',
            meta={'current': 60, 'total': 100, 'status': 'Generating treatment plan...'}
        )
        
        # Generate treatment plan
        treatment_plan = generate_treatment_plan(study, factors)
        
        self.update_state(
            state='PROGRESS',
            meta={'current': 90, 'total': 100, 'status': 'Finalizing results...'}
        )
        
        # Cleanup temp files
        for file_path in dicom_files:
            try:
                os.remove(file_path)
            except:
                pass
        
        # Try to remove temp directory
        try:
            temp_dir = os.path.dirname(dicom_files[0])
            os.rmdir(temp_dir)
        except:
            pass
        
        result = {
            "status": "completed",
            "study_id": study.study_id,
            "patient_id": study.patient_id,
            "vessels_found": len(study.vessels),
            "pathologies_found": sum(len(v.pathologies) for v in study.vessels),
            "critical_findings": study.critical_findings,
            "treatment_plan": treatment_plan,
        }
        
        logger.info(f"Angiography processing completed for study {study.study_id}")
        
        return result
        
    except Exception as exc:
        logger.error(f"Angiography processing failed: {exc}")
        
        # Cleanup on failure
        for file_path in dicom_files:
            try:
                os.remove(file_path)
            except:
                pass
        
        self.retry(exc=exc, countdown=60)


@shared_task
def cleanup_old_angiography_studies(days: int = 30) -> Dict[str, Any]:
    """
    Clean up old angiography studies from storage
    """
    logger.info(f"Cleaning up angiography studies older than {days} days")
    
    # TODO: Implement cleanup of processed studies
    
    return {
        "status": "success",
        "cleaned_studies": 0,
        "run_at": "completed"
    }
