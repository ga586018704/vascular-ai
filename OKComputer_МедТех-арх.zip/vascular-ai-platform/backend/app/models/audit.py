"""
Audit Log Model for HIPAA Compliance
Tracks all user actions for compliance and security
"""
from datetime import datetime
from sqlalchemy import Column, Integer, String, DateTime, Text, Index
from app.db.base import Base


class AuditLog(Base):
    """Audit log entry for tracking all system actions"""
    __tablename__ = "audit_logs"
    
    id = Column(Integer, primary_key=True, index=True)
    timestamp = Column(DateTime, default=datetime.utcnow, nullable=False)
    user_id = Column(Integer, nullable=True)  # Null for anonymous actions
    username = Column(String(100), nullable=True)
    action = Column(String(50), nullable=False)  # CREATE, READ, UPDATE, DELETE, LOGIN, etc.
    resource_type = Column(String(50), nullable=False)  # patient, study, report, etc.
    resource_id = Column(String(100), nullable=True)
    ip_address = Column(String(45), nullable=True)  # IPv6 compatible
    user_agent = Column(String(500), nullable=True)
    details = Column(Text, nullable=True)  # JSON string with additional details
    success = Column(Integer, default=1)  # 1 = success, 0 = failure
    error_message = Column(Text, nullable=True)
    session_id = Column(String(100), nullable=True)
    
    # Indexes for efficient querying
    __table_args__ = (
        Index('idx_audit_timestamp', 'timestamp'),
        Index('idx_audit_user', 'user_id', 'timestamp'),
        Index('idx_audit_action', 'action', 'timestamp'),
        Index('idx_audit_resource', 'resource_type', 'resource_id'),
    )
    
    def __repr__(self):
        return f"<AuditLog {self.action} {self.resource_type} by {self.username}>"


class DataAccessLog(Base):
    """Specific log for PHI (Protected Health Information) access"""
    __tablename__ = "data_access_logs"
    
    id = Column(Integer, primary_key=True, index=True)
    timestamp = Column(DateTime, default=datetime.utcnow, nullable=False)
    user_id = Column(Integer, nullable=False)
    username = Column(String(100), nullable=False)
    patient_id = Column(String(100), nullable=False)
    patient_name = Column(String(200), nullable=True)  # Encrypted
    access_type = Column(String(50), nullable=False)  # VIEW, DOWNLOAD, EXPORT, etc.
    data_types = Column(String(500), nullable=True)  # JSON array of accessed data types
    justification = Column(Text, nullable=True)  # Reason for access
    emergency_access = Column(Integer, default=0)  # 1 = emergency override
    ip_address = Column(String(45), nullable=True)
    session_id = Column(String(100), nullable=True)
    
    __table_args__ = (
        Index('idx_access_patient', 'patient_id', 'timestamp'),
        Index('idx_access_user', 'user_id', 'timestamp'),
    )
