"""
Study/DICOM Study Model
"""
from datetime import datetime
from sqlalchemy import Column, Integer, String, DateTime, Text, ForeignKey, Enum, Float
from sqlalchemy.orm import relationship
import enum
from app.db.base import Base


class StudyStatus(str, enum.Enum):
    PENDING = "pending"
    PROCESSING = "processing"
    COMPLETED = "completed"
    ERROR = "error"
    ARCHIVED = "archived"


class Modality(str, enum.Enum):
    CT = "CT"
    MRI = "MR"
    XA = "XA"  # X-ray Angiography
    US = "US"  # Ultrasound
    DX = "DX"  # Digital X-ray
    RF = "RF"  # Radiofluoroscopy


class Study(Base):
    """DICOM study model"""
    __tablename__ = "studies"
    
    id = Column(Integer, primary_key=True, index=True)
    
    # DICOM identifiers
    study_instance_uid = Column(String(100), unique=True, nullable=False, index=True)
    accession_number = Column(String(50), nullable=True)
    
    # Study info
    study_date = Column(DateTime, nullable=True)
    study_description = Column(String(255), nullable=True)
    modality = Column(Enum(Modality), nullable=False)
    body_part = Column(String(50), nullable=True)
    
    # Status
    status = Column(Enum(StudyStatus), default=StudyStatus.PENDING)
    status_message = Column(Text, nullable=True)
    
    # File info
    file_path = Column(String(500), nullable=True)
    file_count = Column(Integer, default=0)
    total_size_bytes = Column(Integer, default=0)
    
    # Analysis results
    analysis_results = Column(Text, nullable=True)  # JSON
    findings = Column(Text, nullable=True)
    
    # Relationships
    patient_id = Column(Integer, ForeignKey("patients.id"), nullable=False)
    patient = relationship("Patient", back_populates="studies")
    
    uploaded_by = Column(Integer, ForeignKey("users.id"), nullable=True)
    uploaded_by_user = relationship("User", back_populates="studies")
    
    reports = relationship("Report", back_populates="study")
    
    # Timestamps
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    processed_at = Column(DateTime, nullable=True)
    deleted_at = Column(DateTime, nullable=True, index=True)  # Soft delete
    
    # Audit
    created_by_id = Column(Integer, nullable=True)
    updated_by_id = Column(Integer, nullable=True)
    
    # Relationships
    findings = relationship("StudyFinding", back_populates="study")
    measurements = relationship("StudyMeasurement", back_populates="study")
    
    def __repr__(self):
        return f"<Study {self.study_instance_uid}>"
    
    def to_dict(self):
        return {
            "id": self.id,
            "study_instance_uid": self.study_instance_uid,
            "accession_number": self.accession_number,
            "study_date": self.study_date.isoformat() if self.study_date else None,
            "study_description": self.study_description,
            "modality": self.modality.value if self.modality else None,
            "body_part": self.body_part,
            "status": self.status.value if self.status else None,
            "patient": self.patient.to_dict() if self.patient else None,
            "file_count": self.file_count,
            "created_at": self.created_at.isoformat() if self.created_at else None,
        }
