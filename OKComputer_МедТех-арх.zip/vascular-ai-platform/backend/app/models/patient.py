"""
Patient Model
"""
from datetime import datetime, date
from sqlalchemy import Column, Integer, String, Date, DateTime, Text, Boolean, Enum
from sqlalchemy.orm import relationship
import enum
from app.db.base import Base


class Gender(str, enum.Enum):
    MALE = "M"
    FEMALE = "F"
    OTHER = "O"


class Patient(Base):
    """Patient demographic model"""
    __tablename__ = "patients"
    
    id = Column(Integer, primary_key=True, index=True)
    
    # Identifiers
    mrn = Column(String(50), unique=True, nullable=False, index=True)  # Medical Record Number
    
    # Demographics
    first_name = Column(String(50), nullable=False)
    last_name = Column(String(50), nullable=False)
    middle_name = Column(String(50), nullable=True)
    date_of_birth = Column(Date, nullable=False)
    gender = Column(Enum(Gender), nullable=False)
    
    # Contact
    phone = Column(String(20), nullable=True)
    email = Column(String(100), nullable=True)
    address = Column(Text, nullable=True)
    emergency_contact_name = Column(String(100), nullable=True)
    emergency_contact_phone = Column(String(20), nullable=True)
    
    # Medical history
    allergies = Column(Text, nullable=True)
    medications = Column(Text, nullable=True)
    medical_history = Column(Text, nullable=True)
    
    # Timestamps
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    deleted_at = Column(DateTime, nullable=True, index=True)  # Soft delete
    
    # Audit
    created_by_id = Column(Integer, nullable=True)
    updated_by_id = Column(Integer, nullable=True)
    
    # Relationships
    studies = relationship(
        "Study",
        back_populates="patient",
        primaryjoin="and_(Patient.id == Study.patient_id, Study.deleted_at.is_(None))"
    )
    reports = relationship("Report", back_populates="patient")
    lab_results = relationship(
        "PatientLabResult",
        back_populates="patient",
        order_by="desc(PatientLabResult.tested_at)"
    )
    
    @property
    def full_name(self):
        if self.middle_name:
            return f"{self.last_name} {self.first_name} {self.middle_name}"
        return f"{self.last_name} {self.first_name}"
    
    @property
    def age(self):
        if not self.date_of_birth:
            return None
        today = date.today()
        return today.year - self.date_of_birth.year - (
            (today.month, today.day) < (self.date_of_birth.month, self.date_of_birth.day)
        )
    
    def __repr__(self):
        return f"<Patient {self.mrn}: {self.full_name}>"
    
    def to_dict(self):
        return {
            "id": self.id,
            "mrn": self.mrn,
            "full_name": self.full_name,
            "date_of_birth": self.date_of_birth.isoformat() if self.date_of_birth else None,
            "age": self.age,
            "gender": self.gender.value if self.gender else None,
            "phone": self.phone,
            "email": self.email,
            "created_at": self.created_at.isoformat() if self.created_at else None,
        }
