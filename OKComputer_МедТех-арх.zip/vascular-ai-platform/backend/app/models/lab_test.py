"""
Laboratory Tests Model
Blood analysis, biomarkers for vascular patients
"""
from datetime import datetime
from sqlalchemy import Column, Integer, String, Float, DateTime, Text, ForeignKey, Enum, Index
from sqlalchemy.orm import relationship
import enum

from app.db.base import Base


class LabTestCategory(str, enum.Enum):
    """Categories of laboratory tests"""
    COAGULATION = "coagulation"  # Свёртываемость
    LIPID = "lipid"  # Липидный профиль
    BIOCHEMISTRY = "biochemistry"  # Биохимия
    CBC = "cbc"  # Общий анализ крови
    INFLAMMATION = "inflammation"  # Маркеры воспаления
    CARDIAC = "cardiac"  # Кардиомаркеры
    KIDNEY = "kidney"  # Почечные пробы
    DIABETES = "diabetes"  # Глюкоза, HbA1c
    THYROID = "thyroid"  # Щитовидная железа
    TUMOR = "tumor"  # Онкомаркеры
    OTHER = "other"


class LabTestReference(Base):
    """Reference ranges for lab tests"""
    __tablename__ = "lab_test_references"
    
    id = Column(Integer, primary_key=True, index=True)
    test_code = Column(String(50), unique=True, nullable=False, index=True)
    test_name = Column(String(200), nullable=False)
    test_name_ru = Column(String(200), nullable=True)
    category = Column(Enum(LabTestCategory), default=LabTestCategory.OTHER)
    
    # Reference ranges (adult)
    ref_min = Column(Float, nullable=True)  # Минимум нормы
    ref_max = Column(Float, nullable=True)  # Максимум нормы
    ref_unit = Column(String(50), nullable=False)  # Единицы измерения
    
    # Critical values
    critical_low = Column(Float, nullable=True)  # Критически низкое
    critical_high = Column(Float, nullable=True)  # Критически высокое
    
    # Clinical significance for vascular surgery
    clinical_significance = Column(Text, nullable=True)
    vascular_relevance = Column(Text, nullable=True)  # Значение для сосудистой хирургии
    
    # Source
    source = Column(String(200), nullable=True)  # Источник норм
    
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    def is_critical(self, value: float) -> bool:
        """Check if value is in critical range"""
        if self.critical_low is not None and value < self.critical_low:
            return True
        if self.critical_high is not None and value > self.critical_high:
            return True
        return False
    
    def get_status(self, value: float) -> str:
        """Get status of the value"""
        if self.is_critical(value):
            return "critical"
        if self.ref_min is not None and value < self.ref_min:
            return "low"
        if self.ref_max is not None and value > self.ref_max:
            return "high"
        return "normal"
    
    def to_dict(self):
        return {
            "id": self.id,
            "test_code": self.test_code,
            "test_name": self.test_name,
            "test_name_ru": self.test_name_ru,
            "category": self.category.value,
            "ref_min": self.ref_min,
            "ref_max": self.ref_max,
            "ref_unit": self.ref_unit,
            "critical_low": self.critical_low,
            "critical_high": self.critical_high,
            "clinical_significance": self.clinical_significance,
            "vascular_relevance": self.vascular_relevance,
        }


class PatientLabResult(Base):
    """Patient's laboratory test results"""
    __tablename__ = "patient_lab_results"
    
    id = Column(Integer, primary_key=True, index=True)
    patient_id = Column(Integer, ForeignKey("patients.id"), nullable=False, index=True)
    test_reference_id = Column(Integer, ForeignKey("lab_test_references.id"), nullable=False)
    
    # Result
    value = Column(Float, nullable=False)
    value_text = Column(String(500), nullable=True)  # For non-numeric results
    unit = Column(String(50), nullable=False)
    
    # Metadata
    tested_at = Column(DateTime, nullable=False)  # Дата взятия анализа
    result_at = Column(DateTime, nullable=True)  # Дата получения результата
    lab_name = Column(String(200), nullable=True)  # Название лаборатории
    
    # Notes
    notes = Column(Text, nullable=True)
    
    # Timestamps
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    created_by_id = Column(Integer, nullable=True)
    
    # Relationships
    patient = relationship("Patient", back_populates="lab_results")
    test_reference = relationship("LabTestReference")
    
    def get_status(self) -> str:
        """Get status based on reference range"""
        if self.test_reference:
            return self.test_reference.get_status(self.value)
        return "unknown"
    
    def is_critical(self) -> bool:
        """Check if result is critical"""
        if self.test_reference:
            return self.test_reference.is_critical(self.value)
        return False
    
    def to_dict(self):
        return {
            "id": self.id,
            "patient_id": self.patient_id,
            "test": self.test_reference.to_dict() if self.test_reference else None,
            "value": self.value,
            "value_text": self.value_text,
            "unit": self.unit,
            "status": self.get_status(),
            "is_critical": self.is_critical(),
            "tested_at": self.tested_at.isoformat() if self.tested_at else None,
            "result_at": self.result_at.isoformat() if self.result_at else None,
            "lab_name": self.lab_name,
            "notes": self.notes,
        }


# Indexes for performance
Index('ix_lab_results_patient_date', PatientLabResult.patient_id, PatientLabResult.tested_at)
Index('ix_lab_results_test_date', PatientLabResult.test_reference_id, PatientLabResult.tested_at)
