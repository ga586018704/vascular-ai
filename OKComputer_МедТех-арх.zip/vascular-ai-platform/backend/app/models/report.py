"""
Report Model
"""
from datetime import datetime
from sqlalchemy import Column, Integer, String, DateTime, Text, ForeignKey, Enum
from sqlalchemy.orm import relationship
import enum
from app.db.base import Base


class ReportStatus(str, enum.Enum):
    DRAFT = "draft"
    PENDING_REVIEW = "pending_review"
    APPROVED = "approved"
    FINALIZED = "finalized"
    AMENDED = "amended"


class ReportType(str, enum.Enum):
    ANGIOGRAPHY = "angiography"
    ULTRASOUND = "ultrasound"
    CONSULTATION = "consultation"
    FOLLOW_UP = "follow_up"
    EMERGENCY = "emergency"


class Report(Base):
    """Medical report model"""
    __tablename__ = "reports"
    
    id = Column(Integer, primary_key=True, index=True)
    
    # Report identifiers
    report_id = Column(String(50), unique=True, nullable=False, index=True)
    
    # Content
    report_type = Column(Enum(ReportType), default=ReportType.ANGIOGRAPHY)
    title = Column(String(200), nullable=False)
    content = Column(Text, nullable=False)
    findings = Column(Text, nullable=True)
    impression = Column(Text, nullable=True)
    recommendations = Column(Text, nullable=True)
    
    # Status
    status = Column(Enum(ReportStatus), default=ReportStatus.DRAFT)
    
    # PDF file
    pdf_path = Column(String(500), nullable=True)
    
    # Relationships
    patient_id = Column(Integer, ForeignKey("patients.id"), nullable=False)
    patient = relationship("Patient", back_populates="reports")
    
    study_id = Column(Integer, ForeignKey("studies.id"), nullable=True)
    study = relationship("Study", back_populates="reports")
    
    author_id = Column(Integer, ForeignKey("users.id"), nullable=False)
    author = relationship("User", back_populates="reports")
    
    reviewer_id = Column(Integer, ForeignKey("users.id"), nullable=True)
    
    # Timestamps
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    finalized_at = Column(DateTime, nullable=True)
    
    def __repr__(self):
        return f"<Report {self.report_id}>"
    
    def to_dict(self):
        return {
            "id": self.id,
            "report_id": self.report_id,
            "report_type": self.report_type.value if self.report_type else None,
            "title": self.title,
            "status": self.status.value if self.status else None,
            "patient": self.patient.to_dict() if self.patient else None,
            "author": self.author.to_dict() if self.author else None,
            "created_at": self.created_at.isoformat() if self.created_at else None,
        }
