"""
Laboratory Tests Schemas
"""
from datetime import datetime
from typing import List, Optional
from pydantic import BaseModel, Field, ConfigDict

from app.models.lab_test import LabTestCategory


# ============== Lab Test Reference Schemas ==============

class LabTestReferenceBase(BaseModel):
    """Base schema for lab test reference"""
    test_code: str = Field(..., description="Unique test code (e.g., 'PT', 'INR')")
    test_name: str = Field(..., description="Test name in English")
    test_name_ru: Optional[str] = Field(None, description="Test name in Russian")
    category: LabTestCategory = Field(default=LabTestCategory.OTHER)
    ref_min: Optional[float] = Field(None, description="Reference range minimum")
    ref_max: Optional[float] = Field(None, description="Reference range maximum")
    ref_unit: str = Field(..., description="Unit of measurement")
    critical_low: Optional[float] = Field(None, description="Critical low value")
    critical_high: Optional[float] = Field(None, description="Critical high value")
    clinical_significance: Optional[str] = Field(None, description="Clinical significance")
    vascular_relevance: Optional[str] = Field(None, description="Relevance to vascular surgery")


class LabTestReferenceCreate(LabTestReferenceBase):
    """Schema for creating lab test reference"""
    pass


class LabTestReferenceUpdate(BaseModel):
    """Schema for updating lab test reference"""
    test_name: Optional[str] = None
    test_name_ru: Optional[str] = None
    category: Optional[LabTestCategory] = None
    ref_min: Optional[float] = None
    ref_max: Optional[float] = None
    ref_unit: Optional[str] = None
    critical_low: Optional[float] = None
    critical_high: Optional[float] = None
    clinical_significance: Optional[str] = None
    vascular_relevance: Optional[str] = None


class LabTestReferenceResponse(LabTestReferenceBase):
    """Schema for lab test reference response"""
    model_config = ConfigDict(from_attributes=True)
    
    id: int
    created_at: datetime
    updated_at: datetime


class LabTestReferenceList(BaseModel):
    """Schema for list of lab test references"""
    items: List[LabTestReferenceResponse]
    total: int


# ============== Patient Lab Result Schemas ==============

class PatientLabResultBase(BaseModel):
    """Base schema for patient lab result"""
    test_reference_id: int = Field(..., description="ID of the test reference")
    value: float = Field(..., description="Numeric result value")
    value_text: Optional[str] = Field(None, description="Text result (if non-numeric)")
    unit: str = Field(..., description="Unit of measurement")
    tested_at: datetime = Field(..., description="Date/time of sample collection")
    result_at: Optional[datetime] = Field(None, description="Date/time of result")
    lab_name: Optional[str] = Field(None, description="Laboratory name")
    notes: Optional[str] = Field(None, description="Additional notes")


class PatientLabResultCreate(PatientLabResultBase):
    """Schema for creating patient lab result"""
    patient_id: int


class PatientLabResultUpdate(BaseModel):
    """Schema for updating patient lab result"""
    value: Optional[float] = None
    value_text: Optional[str] = None
    unit: Optional[str] = None
    tested_at: Optional[datetime] = None
    result_at: Optional[datetime] = None
    lab_name: Optional[str] = None
    notes: Optional[str] = None


class PatientLabResultResponse(BaseModel):
    """Schema for patient lab result response"""
    model_config = ConfigDict(from_attributes=True)
    
    id: int
    patient_id: int
    test: Optional[LabTestReferenceResponse] = None
    value: float
    value_text: Optional[str] = None
    unit: str
    status: str = Field(..., description="normal, low, high, or critical")
    is_critical: bool
    tested_at: datetime
    result_at: Optional[datetime] = None
    lab_name: Optional[str] = None
    notes: Optional[str] = None
    created_at: datetime


class PatientLabResultList(BaseModel):
    """Schema for list of patient lab results"""
    items: List[PatientLabResultResponse]
    total: int


# ============== Lab Panel Schemas ==============

class LabPanelItem(BaseModel):
    """Item in a lab panel"""
    test_reference_id: int
    test_name: str
    is_required: bool = True


class LabPanelBase(BaseModel):
    """Base schema for lab panel (preset group of tests)"""
    name: str
    description: Optional[str] = None
    category: str  # e.g., "preoperative", "screening", "followup"
    tests: List[int] = Field(..., description="List of test reference IDs")


class LabPanelCreate(LabPanelBase):
    pass


class LabPanelResponse(LabPanelBase):
    """Schema for lab panel response"""
    model_config = ConfigDict(from_attributes=True)
    
    id: int
    created_at: datetime


# ============== Lab Result Analysis Schemas ==============

class LabResultAnalysis(BaseModel):
    """AI analysis of lab results"""
    patient_id: int
    summary: str = Field(..., description="Summary of lab results")
    abnormal_results: List[dict] = Field(default_factory=list)
    critical_results: List[dict] = Field(default_factory=list)
    surgical_risk_assessment: Optional[str] = None
    recommendations: List[str] = Field(default_factory=list)
    additional_tests_needed: List[str] = Field(default_factory=list)


class LabTrendPoint(BaseModel):
    """Single point in lab trend"""
    date: datetime
    value: float
    status: str


class LabTrendResponse(BaseModel):
    """Trend of a lab value over time"""
    test_reference_id: int
    test_name: str
    test_name_ru: Optional[str]
    unit: str
    ref_min: Optional[float]
    ref_max: Optional[float]
    data: List[LabTrendPoint]


# ============== Request/Filter Schemas ==============

class LabResultFilter(BaseModel):
    """Filter for lab results"""
    patient_id: Optional[int] = None
    category: Optional[LabTestCategory] = None
    test_code: Optional[str] = None
    date_from: Optional[datetime] = None
    date_to: Optional[datetime] = None
    status: Optional[str] = None  # normal, low, high, critical
    show_critical_only: bool = False


class BulkLabResultCreate(BaseModel):
    """Create multiple lab results at once"""
    patient_id: int
    results: List[PatientLabResultBase]
    tested_at: datetime
    lab_name: Optional[str] = None
