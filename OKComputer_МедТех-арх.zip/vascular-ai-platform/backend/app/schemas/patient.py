"""
Patient Schemas
Pydantic models for patient data validation
"""
from datetime import date, datetime
from typing import Optional, List
from pydantic import BaseModel, Field, ConfigDict


class PatientBase(BaseModel):
    """Base patient schema"""
    first_name: str = Field(..., min_length=1, max_length=100)
    last_name: str = Field(..., min_length=1, max_length=100)
    date_of_birth: Optional[date] = None
    gender: Optional[str] = Field(None, pattern="^(M|F|O|U)$")
    mrn: str = Field(..., min_length=1, max_length=50, description="Medical Record Number")
    phone: Optional[str] = Field(None, max_length=20)
    email: Optional[str] = Field(None, max_length=100)
    address: Optional[str] = None
    city: Optional[str] = Field(None, max_length=100)
    postal_code: Optional[str] = Field(None, max_length=20)
    country: Optional[str] = Field(None, max_length=100)
    
    # Risk factors
    smoking_status: Optional[str] = None
    diabetes: bool = False
    hypertension: bool = False
    hyperlipidemia: bool = False
    family_history: Optional[str] = None
    allergies: Optional[str] = None
    medications: Optional[str] = None


class PatientCreate(PatientBase):
    """Schema for creating a patient"""
    pass


class PatientUpdate(BaseModel):
    """Schema for updating a patient (all fields optional)"""
    first_name: Optional[str] = Field(None, min_length=1, max_length=100)
    last_name: Optional[str] = Field(None, min_length=1, max_length=100)
    date_of_birth: Optional[date] = None
    gender: Optional[str] = Field(None, pattern="^(M|F|O|U)$")
    phone: Optional[str] = Field(None, max_length=20)
    email: Optional[str] = Field(None, max_length=100)
    address: Optional[str] = None
    city: Optional[str] = Field(None, max_length=100)
    postal_code: Optional[str] = Field(None, max_length=20)
    country: Optional[str] = Field(None, max_length=100)
    smoking_status: Optional[str] = None
    diabetes: Optional[bool] = None
    hypertension: Optional[bool] = None
    hyperlipidemia: Optional[bool] = None
    family_history: Optional[str] = None
    allergies: Optional[str] = None
    medications: Optional[str] = None


class PatientResponse(PatientBase):
    """Schema for patient response"""
    model_config = ConfigDict(from_attributes=True)
    
    id: int
    created_at: datetime
    updated_at: datetime
    deleted_at: Optional[datetime] = None
    created_by_id: Optional[int] = None
    updated_by_id: Optional[int] = None
    
    # Computed fields
    full_name: str = Field("", description="Full name (computed)")
    age: Optional[int] = Field(None, description="Age in years (computed)")
    study_count: int = Field(0, description="Number of studies")
    
    def model_post_init(self, __context):
        """Compute derived fields"""
        self.full_name = f"{self.last_name}, {self.first_name}"
        if self.date_of_birth:
            today = date.today()
            self.age = today.year - self.date_of_birth.year
            if (today.month, today.day) < (self.date_of_birth.month, self.date_of_birth.day):
                self.age -= 1


class PatientListResponse(BaseModel):
    """Schema for paginated patient list"""
    items: List[PatientResponse]
    total: int
    page: int
    page_size: int
    total_pages: int
    has_next: bool
    has_prev: bool


class PatientMinimalResponse(BaseModel):
    """Minimal patient info for dropdowns"""
    model_config = ConfigDict(from_attributes=True)
    
    id: int
    mrn: str
    full_name: str
    date_of_birth: Optional[date]
    gender: Optional[str]
