"""
AI Agents Schemas
Pydantic models for AI agent interactions
"""

from typing import Dict, List, Optional, Any
from pydantic import BaseModel, Field


class AgentCapability(BaseModel):
    """Agent capability schema"""
    name: str = Field(..., description="Capability name")
    description: str = Field(..., description="Capability description")
    parameters: List[str] = Field(default=[], description="Required parameters")


class AgentInfo(BaseModel):
    """Agent information schema"""
    agent_id: str = Field(..., description="Unique agent identifier")
    name: str = Field(..., description="Agent display name")
    description: str = Field(..., description="Agent description")
    specialty: str = Field(..., description="Medical specialty")
    capabilities: List[AgentCapability] = Field(default=[], description="Agent capabilities")


class AgentQuery(BaseModel):
    """Agent query schema"""
    query: str = Field(..., description="Analysis query text", min_length=5)
    patient_context: Optional[Dict[str, Any]] = Field(None, description="Patient context data")
    use_llm: bool = Field(True, description="Use LLM enhancement")
    provider: str = Field("openai", description="LLM provider (openai/anthropic)")


class AgentAnalysis(BaseModel):
    """Agent analysis result schema"""
    agent_id: str = Field(..., description="Agent identifier")
    agent_name: str = Field(..., description="Agent name")
    findings: List[str] = Field(default=[], description="Analysis findings")
    recommendations: List[str] = Field(default=[], description="Clinical recommendations")
    confidence_score: float = Field(..., ge=0, le=100, description="Confidence score (0-100)")
    warnings: Optional[List[str]] = Field(None, description="Warning messages")
    suggested_tests: Optional[List[str]] = Field(None, description="Suggested diagnostic tests")
    follow_up: Optional[str] = Field(None, description="Follow-up recommendations")


class BatchAnalysisRequest(BaseModel):
    """Batch analysis request schema"""
    query: str = Field(..., description="Analysis query")
    agent_ids: List[str] = Field(..., description="List of agent IDs to use")
    patient_context: Optional[Dict[str, Any]] = Field(None, description="Patient context")


class BatchAnalysisResponse(BaseModel):
    """Batch analysis response schema"""
    results: Dict[str, AgentAnalysis] = Field(..., description="Analysis results by agent")
    errors: Optional[Dict[str, str]] = Field(None, description="Errors by agent")
    total_agents: int = Field(..., description="Total agents requested")
    successful: int = Field(..., description="Successful analyses")
    failed: int = Field(..., description="Failed analyses")


class LLMAnalysisRequest(BaseModel):
    """LLM analysis request schema"""
    query: str = Field(..., description="Medical query")
    specialty: Optional[str] = Field(None, description="Medical specialty context")
    patient_context: Optional[Dict[str, Any]] = Field(None, description="Patient context")
    provider: str = Field("openai", description="LLM provider")


class LLMAnalysisResponse(BaseModel):
    """LLM analysis response schema"""
    analysis: str = Field(..., description="LLM analysis result")
    provider: str = Field(..., description="Provider used")
    tokens_used: Optional[int] = Field(None, description="Tokens consumed")
    confidence: Optional[str] = Field(None, description="Confidence level")


class AgentComparisonRequest(BaseModel):
    """Agent comparison request schema"""
    query: str = Field(..., description="Medical case query")
    agent_ids: List[str] = Field(..., description="Agents to compare")
    patient_context: Optional[Dict[str, Any]] = Field(None, description="Patient context")


class AgentComparisonResponse(BaseModel):
    """Agent comparison response schema"""
    comparisons: Dict[str, AgentAnalysis] = Field(..., description="Results by agent")
    consensus_findings: List[str] = Field(default=[], description="Findings agreed by all agents")
    conflicting_points: Optional[List[Dict]] = Field(None, description="Points of disagreement")
    recommended_agent: str = Field(..., description="Most appropriate agent")
