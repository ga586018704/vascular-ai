"""
Pydantic schemas for study comparison
"""
from pydantic import BaseModel
from typing import List, Dict, Any, Optional
from datetime import datetime


class StudyComparisonRequest(BaseModel):
    baseline_study_id: str
    followup_study_id: str


class FindingSchema(BaseModel):
    id: str
    type: str
    location: str
    severity: str
    description: str
    vessel_name: str


class MeasurementSchema(BaseModel):
    vessel_name: str
    diameter_mm: float
    length_mm: float
    volume_ml: float


class StudySchema(BaseModel):
    id: str
    patient_id: str
    patient_name: str
    study_date: str
    modality: str
    description: str
    findings: List[FindingSchema]
    measurements: List[MeasurementSchema]
    status: str


class DiameterChange(BaseModel):
    vessel_name: str
    baseline_diameter: float
    followup_diameter: float
    change_mm: float
    change_percent: float
    annual_growth_rate: float
    significance: str  # stable, mild_progression, significant_progression, regression


class FindingComparison(BaseModel):
    id: str
    type: str
    location: str
    severity: str
    description: str
    vessel_name: str
    previous_severity: Optional[str] = None


class ProgressionSummary(BaseModel):
    summary: str
    risk_level: str  # low, moderate, high
    significant_vessel_changes: int
    mild_vessel_changes: int
    new_findings: int
    progressed_findings: int


class StudyComparisonResponse(BaseModel):
    baseline_study: StudySchema
    followup_study: StudySchema
    interval_days: int
    diameter_changes: List[DiameterChange]
    new_findings: List[FindingSchema]
    resolved_findings: List[FindingSchema]
    progressed_findings: List[FindingComparison]
    stable_findings: List[FindingSchema]
    progression_summary: str
    progression_risk: str
    recommendations: List[str]
