"""
Pathology Schemas
"""
from typing import List, Optional, Dict, Any
from pydantic import BaseModel, Field, ConfigDict


class PathologySearchResult(BaseModel):
    """Search result for pathology lookup"""
    code: str = Field(..., description="Unique pathology code")
    name: str = Field(..., description="Pathology name")
    name_ru: Optional[str] = Field(None, description="Pathology name in Russian")
    category: str = Field(..., description="Category (arterial, venous, etc.)")
    severity: str = Field(..., description="Severity level")
    description: str = Field(..., description="Brief description")


class PathologyDetailResponse(BaseModel):
    """Detailed pathology information"""
    # Basic info
    code: str
    name: str
    name_ru: Optional[str] = None
    category: str
    severity: str
    
    # Descriptions
    description: str
    description_ru: Optional[str] = None
    
    # Anatomy
    anatomy: List[str] = Field(default_factory=list)
    anatomy_ru: Optional[List[str]] = None
    
    # Classification
    classification: Dict[str, Any] = Field(default_factory=dict)
    
    # Clinical features
    symptoms: List[str] = Field(default_factory=list)
    symptoms_ru: Optional[List[str]] = None
    signs: List[str] = Field(default_factory=list)
    signs_ru: Optional[List[str]] = None
    
    # Diagnostics
    diagnostic_criteria: List[str] = Field(default_factory=list)
    imaging_findings: Dict[str, Any] = Field(default_factory=dict)
    
    # Treatment
    treatment_options: Dict[str, Any] = Field(default_factory=dict)
    treatment_options_ru: Optional[Dict[str, Any]] = None
    
    # Surgical
    surgical_indications: List[str] = Field(default_factory=list)
    surgical_indications_ru: Optional[List[str]] = None
    surgical_techniques: List[str] = Field(default_factory=list)
    surgical_techniques_ru: Optional[List[str]] = None
    
    # Complications
    complications: List[str] = Field(default_factory=list)
    complications_ru: Optional[List[str]] = None
    
    # Prognosis
    prognosis: Optional[str] = None
    prognosis_ru: Optional[str] = None
    
    # Follow-up
    follow_up: Dict[str, Any] = Field(default_factory=dict)
    
    # References
    references: List[str] = Field(default_factory=list)
    
    # Related
    related_conditions: List[str] = Field(default_factory=list)
    synonyms: List[str] = Field(default_factory=list)
    
    # ICD codes
    icd10_codes: List[str] = Field(default_factory=list)
    
    # Risk factors
    risk_factors: List[str] = Field(default_factory=list)
    risk_factors_ru: Optional[List[str]] = None


class PathologyCategory(BaseModel):
    """Pathology category information"""
    key: str
    name: str
    name_ru: str
    count: int
    icon: str


class PathologyFilterRequest(BaseModel):
    """Request to filter pathologies"""
    category: Optional[str] = None
    severity: Optional[str] = None
    search: Optional[str] = None
    has_surgical_treatment: Optional[bool] = None
    icd10_code: Optional[str] = None


class SurgicalEmergency(BaseModel):
    """Vascular surgical emergency"""
    code: str
    name: str
    name_ru: Optional[str]
    category: str
    presentation: List[str]
    immediate_action: str
    mortality: str


class PreoperativeCondition(BaseModel):
    """Condition requiring preoperative workup"""
    code: str
    name: str
    name_ru: Optional[str]
    preop_workup: List[str]
    surgical_threshold: str


class PathologyWithLabCorrelation(BaseModel):
    """Pathology with relevant lab tests"""
    pathology_code: str
    pathology_name: str
    relevant_labs: List[str] = Field(..., description="List of relevant lab test codes")
    lab_findings: Dict[str, str] = Field(..., description="Expected lab findings")
    preop_required_labs: List[str] = Field(default_factory=list)
