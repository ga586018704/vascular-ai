"""
Analytics Schemas
"""
from datetime import datetime
from typing import Dict, List, Optional, Any
from pydantic import BaseModel


class DashboardStats(BaseModel):
    """Main dashboard statistics"""
    total_patients: int
    total_studies: int
    total_reports: int
    total_users: int
    today_studies: int
    today_reports: int
    weekly_studies: int
    weekly_reports: int
    updated_at: datetime


class ActivityMetrics(BaseModel):
    """User activity metrics"""
    period_days: int
    total_actions: int
    actions_by_type: Dict[str, int]
    daily_activity: List[Dict[str, Any]]
    top_users: List[Dict[str, Any]]


class CPUInfo(BaseModel):
    """CPU information"""
    percent: float
    count: int
    frequency_mhz: Optional[float] = None


class MemoryInfo(BaseModel):
    """Memory information"""
    total_gb: float
    available_gb: float
    percent: float
    used_gb: float


class DiskInfo(BaseModel):
    """Disk information"""
    total_gb: float
    free_gb: float
    percent: float
    used_gb: float


class SystemHealth(BaseModel):
    """System health status"""
    status: str  # healthy, warning, critical
    issues: List[str]
    cpu: CPUInfo
    memory: MemoryInfo
    disk: DiskInfo
    timestamp: datetime


class UserActivity(BaseModel):
    """Activity for a specific user"""
    user_id: int
    username: str
    period_days: int
    total_actions: int
    activity_by_type: Dict[str, int]
    recent_actions: List[Dict[str, Any]]


class TimeSeriesData(BaseModel):
    """Time series data for charts"""
    metric: str
    interval: str
    start_date: datetime
    end_date: datetime
    data: List[Dict[str, Any]]


class ReportMetrics(BaseModel):
    """Report generation metrics"""
    period_days: int
    total_reports: int
    reports_by_type: Dict[str, int]
    reports_by_status: Dict[str, int]
    average_generation_time_seconds: Optional[float]


class AuditSummary(BaseModel):
    """Audit log summary"""
    period_start: datetime
    period_end: datetime
    total_actions: int
    actions_by_type: Dict[str, int]
    failed_actions: int
    phi_access_count: int
