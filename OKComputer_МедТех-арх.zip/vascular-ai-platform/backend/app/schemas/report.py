"""
Report Schemas
Pydantic models for report generation
"""

from typing import Dict, List, Optional
from pydantic import BaseModel, Field


class Finding(BaseModel):
    """Finding schema"""
    title: str = Field(..., description="Finding title")
    description: str = Field(..., description="Finding description")
    severity: Optional[str] = Field(None, description="Severity level (low, medium, high)")
    location: Optional[str] = Field(None, description="Anatomical location")


class Recommendation(BaseModel):
    """Recommendation schema"""
    priority: str = Field(..., description="Priority level (low, medium, high, urgent)")
    description: str = Field(..., description="Recommendation description")
    rationale: Optional[str] = Field(None, description="Clinical rationale")


class AnalysisReportRequest(BaseModel):
    """Analysis report request schema"""
    patient_name: str = Field(..., description="Patient full name")
    patient_id: str = Field(..., description="Patient identifier")
    analysis_type: str = Field(..., description="Type of analysis performed")
    findings: List[Finding] = Field(default=[], description="List of findings")
    recommendations: List[Recommendation] = Field(default=[], description="List of recommendations")
    confidence_score: float = Field(..., ge=0, le=100, description="AI confidence score (0-100)")
    analyzed_by: str = Field(..., description="Name of AI agent or physician")
    additional_notes: Optional[str] = Field(None, description="Additional notes")


class SeriesInfo(BaseModel):
    """Series information schema"""
    series_number: int = Field(..., description="Series number")
    description: str = Field(..., description="Series description")
    modality: str = Field(..., description="Modality (CT, MRI, US, etc.)")
    instances: int = Field(..., description="Number of instances")


class StudySummaryRequest(BaseModel):
    """Study summary request schema"""
    study_id: str = Field(..., description="Study identifier")
    study_type: str = Field(..., description="Type of study")
    patient_info: Dict[str, str] = Field(..., description="Patient information")
    series_info: List[SeriesInfo] = Field(default=[], description="List of series information")
    key_findings: List[str] = Field(default=[], description="Key findings")
    clinical_impression: str = Field(..., description="Clinical impression")
    physician_name: Optional[str] = Field(None, description="Referring physician")


class ReportGenerated(BaseModel):
    """Report generated response schema"""
    success: bool = Field(..., description="Whether report was generated successfully")
    filename: str = Field(..., description="Generated filename")
    download_url: Optional[str] = Field(None, description="Download URL")
    generated_at: str = Field(..., description="Generation timestamp")
    file_size: Optional[int] = Field(None, description="File size in bytes")


class ReportTemplate(BaseModel):
    """Report template schema"""
    id: str = Field(..., description="Template ID")
    name: str = Field(..., description="Template name")
    description: str = Field(..., description="Template description")
    sections: List[str] = Field(default=[], description="Template sections")
