"""
Study Schemas
Pydantic models for study data validation
"""
from datetime import date, datetime
from typing import Optional, List
from pydantic import BaseModel, Field, ConfigDict

from app.models.study import StudyStatus, Modality


class StudyBase(BaseModel):
    """Base study schema"""
    patient_id: int = Field(..., description="Patient ID")
    study_instance_uid: str = Field(..., max_length=100)
    accession_number: Optional[str] = Field(None, max_length=50)
    study_date: Optional[date] = None
    study_time: Optional[str] = Field(None, max_length=20)
    modality: Modality = Field(default=Modality.CT)
    study_description: Optional[str] = None
    series_count: int = Field(default=1, ge=0)
    instance_count: int = Field(default=0, ge=0)
    body_part: Optional[str] = Field(None, max_length=100)
    storage_path: Optional[str] = None


class StudyCreate(StudyBase):
    """Schema for creating a study"""
    pass


class StudyUpdate(BaseModel):
    """Schema for updating a study (all fields optional)"""
    accession_number: Optional[str] = Field(None, max_length=50)
    study_date: Optional[date] = None
    study_time: Optional[str] = Field(None, max_length=20)
    modality: Optional[Modality] = None
    study_description: Optional[str] = None
    series_count: Optional[int] = Field(None, ge=0)
    instance_count: Optional[int] = Field(None, ge=0)
    body_part: Optional[str] = Field(None, max_length=100)
    status: Optional[StudyStatus] = None


class StudyFindingResponse(BaseModel):
    """Schema for study finding"""
    model_config = ConfigDict(from_attributes=True)
    
    id: int
    finding_type: str
    vessel_name: str
    location: str
    severity: str
    description: str
    confidence: float


class StudyMeasurementResponse(BaseModel):
    """Schema for study measurement"""
    model_config = ConfigDict(from_attributes=True)
    
    id: int
    vessel_name: str
    diameter_mm: float
    length_mm: Optional[float] = None
    volume_ml: Optional[float] = None


class StudyResponse(StudyBase):
    """Schema for study response"""
    model_config = ConfigDict(from_attributes=True)
    
    id: int
    status: StudyStatus
    created_at: datetime
    updated_at: datetime
    processed_at: Optional[datetime] = None
    deleted_at: Optional[datetime] = None
    created_by_id: Optional[int] = None
    updated_by_id: Optional[int] = None
    
    # Related data
    patient: Optional[dict] = None
    findings: List[StudyFindingResponse] = []
    measurements: List[StudyMeasurementResponse] = []
    
    # Computed fields
    status_label: str = Field("", description="Human-readable status")
    modality_label: str = Field("", description="Human-readable modality")
    
    def model_post_init(self, __context):
        """Compute derived fields"""
        status_labels = {
            StudyStatus.PENDING: "Pending",
            StudyStatus.PROCESSING: "Processing",
            StudyStatus.COMPLETED: "Completed",
            StudyStatus.FAILED: "Failed",
            StudyStatus.ARCHIVED: "Archived",
        }
        self.status_label = status_labels.get(self.status, str(self.status))
        
        modality_labels = {
            Modality.CT: "CT",
            Modality.MR: "MRI",
            Modality.XA: "X-Ray Angiography",
            Modality.US: "Ultrasound",
            Modality.PT: "PET",
            Modality.NM: "Nuclear Medicine",
        }
        self.modality_label = modality_labels.get(self.modality, str(self.modality))


class StudyListResponse(BaseModel):
    """Schema for paginated study list"""
    items: List[StudyResponse]
    total: int
    page: int
    page_size: int
    total_pages: int
    has_next: bool
    has_prev: bool


class StudyMinimalResponse(BaseModel):
    """Minimal study info for dropdowns"""
    model_config = ConfigDict(from_attributes=True)
    
    id: int
    study_instance_uid: str
    study_date: Optional[date]
    modality: str
    study_description: Optional[str]
    status: str
