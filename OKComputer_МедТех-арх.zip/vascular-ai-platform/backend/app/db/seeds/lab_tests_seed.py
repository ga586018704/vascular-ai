"""
Laboratory Tests Seed Data
Reference ranges for vascular surgery patients
"""

LAB_TEST_REFERENCES = [
    # ========== COAGULATION (Свёртываемость) ==========
    {
        "test_code": "PT",
        "test_name": "Prothrombin Time",
        "test_name_ru": "Протромбиновое время",
        "category": "coagulation",
        "ref_min": 11.0,
        "ref_max": 16.0,
        "ref_unit": "seconds",
        "critical_high": 25.0,
        "clinical_significance": "Measures extrinsic pathway of coagulation",
        "vascular_relevance": "Critical for preoperative assessment. Prolonged PT increases bleeding risk."
    },
    {
        "test_code": "INR",
        "test_name": "International Normalized Ratio",
        "test_name_ru": "МНО (Международное нормализованное отношение)",
        "category": "coagulation",
        "ref_min": 0.85,
        "ref_max": 1.15,
        "ref_unit": "ratio",
        "critical_low": 0.5,
        "critical_high": 5.0,
        "clinical_significance": "Standardized measure of blood clotting",
        "vascular_relevance": "Target 2.0-3.0 for warfarin therapy. >3.0: high bleeding risk for surgery. <1.5: thrombosis risk."
    },
    {
        "test_code": "APTT",
        "test_name": "Activated Partial Thromboplastin Time",
        "test_name_ru": "АЧТВ (Активированное частичное тромбопластиновое время)",
        "category": "coagulation",
        "ref_min": 25.0,
        "ref_max": 35.0,
        "ref_unit": "seconds",
        "critical_high": 70.0,
        "clinical_significance": "Measures intrinsic pathway of coagulation",
        "vascular_relevance": "Monitors heparin therapy. Prolonged APTT increases bleeding risk."
    },
    {
        "test_code": "FIBRINOGEN",
        "test_name": "Fibrinogen",
        "test_name_ru": "Фибриноген",
        "category": "coagulation",
        "ref_min": 2.0,
        "ref_max": 4.0,
        "ref_unit": "g/L",
        "critical_low": 1.0,
        "critical_high": 10.0,
        "clinical_significance": "Acute phase reactant, essential for clot formation",
        "vascular_relevance": "Low fibrinogen: bleeding risk. High: inflammation, thrombosis risk."
    },
    {
        "test_code": "D_DIMER",
        "test_name": "D-Dimer",
        "test_name_ru": "D-Димер",
        "category": "coagulation",
        "ref_min": 0.0,
        "ref_max": 0.5,
        "ref_unit": "mg/L FEU",
        "critical_high": 5.0,
        "clinical_significance": "Fibrin degradation product",
        "vascular_relevance": "Elevated in DVT, PE, DIC. Used to rule out thrombosis."
    },
    {
        "test_code": "PLT",
        "test_name": "Platelet Count",
        "test_name_ru": "Тромбоциты",
        "category": "coagulation",
        "ref_min": 150.0,
        "ref_max": 400.0,
        "ref_unit": "x10^9/L",
        "critical_low": 50.0,
        "critical_high": 1000.0,
        "clinical_significance": "Essential for primary hemostasis",
        "vascular_relevance": "<50: high bleeding risk. >1000: thrombosis risk."
    },
    
    # ========== CBC (Общий анализ крови) ==========
    {
        "test_code": "HGB",
        "test_name": "Hemoglobin",
        "test_name_ru": "Гемоглобин",
        "category": "cbc",
        "ref_min": 120.0,
        "ref_max": 160.0,
        "ref_unit": "g/L",
        "critical_low": 70.0,
        "critical_high": 200.0,
        "clinical_significance": "Oxygen carrying capacity",
        "vascular_relevance": "<100: consider transfusion before surgery. <80: mandatory transfusion."
    },
    {
        "test_code": "WBC",
        "test_name": "White Blood Cell Count",
        "test_name_ru": "Лейкоциты",
        "category": "cbc",
        "ref_min": 4.0,
        "ref_max": 10.0,
        "ref_unit": "x10^9/L",
        "critical_low": 2.0,
        "critical_high": 30.0,
        "clinical_significance": "Immune system status",
        "vascular_relevance": "Elevated: infection, inflammation. May delay elective surgery."
    },
    {
        "test_code": "RBC",
        "test_name": "Red Blood Cell Count",
        "test_name_ru": "Эритроциты",
        "category": "cbc",
        "ref_min": 4.0,
        "ref_max": 5.5,
        "ref_unit": "x10^12/L",
        "clinical_significance": "Red blood cell count",
        "vascular_relevance": "Part of anemia assessment"
    },
    {
        "test_code": "HCT",
        "test_name": "Hematocrit",
        "test_name_ru": "Гематокрит",
        "category": "cbc",
        "ref_min": 0.36,
        "ref_max": 0.46,
        "ref_unit": "L/L",
        "critical_low": 0.20,
        "clinical_significance": "Percentage of blood volume occupied by RBCs",
        "vascular_relevance": "Low: anemia. High: dehydration, polycythemia."
    },
    
    # ========== LIPID PROFILE ==========
    {
        "test_code": "CHOLESTEROL",
        "test_name": "Total Cholesterol",
        "test_name_ru": "Холестерин общий",
        "category": "lipid",
        "ref_min": 0.0,
        "ref_max": 5.2,
        "ref_unit": "mmol/L",
        "critical_high": 10.0,
        "clinical_significance": "Cardiovascular risk marker",
        "vascular_relevance": "Major risk factor for atherosclerosis. Target <5.0 for vascular patients."
    },
    {
        "test_code": "LDL",
        "test_name": "LDL Cholesterol",
        "test_name_ru": "ЛПНП (холестерин липопротеидов низкой плотности)",
        "category": "lipid",
        "ref_min": 0.0,
        "ref_max": 3.0,
        "ref_unit": "mmol/L",
        "clinical_significance": "Bad cholesterol",
        "vascular_relevance": "Primary target for statin therapy. Target <1.8 for high-risk patients."
    },
    {
        "test_code": "HDL",
        "test_name": "HDL Cholesterol",
        "test_name_ru": "ЛПВП (холестерин липопротеидов высокой плотности)",
        "category": "lipid",
        "ref_min": 1.0,
        "ref_max": 2.5,
        "ref_unit": "mmol/L",
        "clinical_significance": "Good cholesterol",
        "vascular_relevance": "Protective factor. Low HDL increases cardiovascular risk."
    },
    {
        "test_code": "TRIGLYCERIDES",
        "test_name": "Triglycerides",
        "test_name_ru": "Триглицериды",
        "category": "lipid",
        "ref_min": 0.0,
        "ref_max": 1.7,
        "ref_unit": "mmol/L",
        "critical_high": 11.0,
        "clinical_significance": "Blood fat levels",
        "vascular_relevance": "Elevated: pancreatitis risk, metabolic syndrome."
    },
    {
        "test_code": "NON_HDL",
        "test_name": "Non-HDL Cholesterol",
        "test_name_ru": "Нем ЛПВП холестерин",
        "category": "lipid",
        "ref_min": 0.0,
        "ref_max": 3.8,
        "ref_unit": "mmol/L",
        "clinical_significance": "Total minus HDL cholesterol",
        "vascular_relevance": "Better predictor than LDL alone for vascular patients."
    },
    
    # ========== KIDNEY FUNCTION ==========
    {
        "test_code": "CREATININE",
        "test_name": "Creatinine",
        "test_name_ru": "Креатинин",
        "category": "kidney",
        "ref_min": 62.0,
        "ref_max": 115.0,
        "ref_unit": "μmol/L",
        "critical_high": 500.0,
        "clinical_significance": "Kidney function marker",
        "vascular_relevance": "Elevated: CKD, contrast nephropathy risk. Calculate eGFR before angiography."
    },
    {
        "test_code": "UREA",
        "test_name": "Urea (BUN)",
        "test_name_ru": "Мочевина",
        "category": "kidney",
        "ref_min": 2.5,
        "ref_max": 8.3,
        "ref_unit": "mmol/L",
        "critical_high": 30.0,
        "clinical_significance": "Nitrogen waste product",
        "vascular_relevance": "Elevated in dehydration, CKD. Affected by protein intake."
    },
    {
        "test_code": "eGFR",
        "test_name": "eGFR (estimated GFR)",
        "test_name_ru": "СКФ (скорость клубочковой фильтрации)",
        "category": "kidney",
        "ref_min": 90.0,
        "ref_max": 120.0,
        "ref_unit": "mL/min/1.73m2",
        "critical_low": 15.0,
        "clinical_significance": "Kidney filtration rate",
        "vascular_relevance": "<60: CKD. <30: high contrast risk. <15: dialysis consideration."
    },
    
    # ========== LIVER FUNCTION ==========
    {
        "test_code": "ALT",
        "test_name": "Alanine Aminotransferase",
        "test_name_ru": "АЛТ (аланинаминотрансфераза)",
        "category": "biochemistry",
        "ref_min": 0.0,
        "ref_max": 41.0,
        "ref_unit": "U/L",
        "critical_high": 300.0,
        "clinical_significance": "Liver enzyme",
        "vascular_relevance": "Elevated: liver damage, statin side effects."
    },
    {
        "test_code": "AST",
        "test_name": "Aspartate Aminotransferase",
        "test_name_ru": "АСТ (аспартатаминотрансфераза)",
        "category": "biochemistry",
        "ref_min": 0.0,
        "ref_max": 40.0,
        "ref_unit": "U/L",
        "critical_high": 300.0,
        "clinical_significance": "Liver/heart enzyme",
        "vascular_relevance": "Elevated: liver damage, MI, muscle injury."
    },
    {
        "test_code": "BILIRUBIN_TOTAL",
        "test_name": "Total Bilirubin",
        "test_name_ru": "Билирубин общий",
        "category": "biochemistry",
        "ref_min": 3.0,
        "ref_max": 21.0,
        "ref_unit": "μmol/L",
        "critical_high": 100.0,
        "clinical_significance": "Bile pigment",
        "vascular_relevance": "Elevated: liver disease, hemolysis."
    },
    {
        "test_code": "ALP",
        "test_name": "Alkaline Phosphatase",
        "test_name_ru": "ЩФ (щелочная фосфатаза)",
        "category": "biochemistry",
        "ref_min": 40.0,
        "ref_max": 150.0,
        "ref_unit": "U/L",
        "clinical_significance": "Liver/bone enzyme",
        "vascular_relevance": "Elevated: biliary obstruction, bone disease."
    },
    
    # ========== DIABETES ==========
    {
        "test_code": "GLUCOSE",
        "test_name": "Glucose (Fasting)",
        "test_name_ru": "Глюкоза (натощак)",
        "category": "diabetes",
        "ref_min": 3.9,
        "ref_max": 6.1,
        "ref_unit": "mmol/L",
        "critical_low": 2.2,
        "critical_high": 22.2,
        "clinical_significance": "Blood sugar level",
        "vascular_relevance": ">11.1: postpone elective surgery. Poor control increases infection risk."
    },
    {
        "test_code": "HbA1c",
        "test_name": "Hemoglobin A1c",
        "test_name_ru": "Гликированный гемоглобин",
        "category": "diabetes",
        "ref_min": 0.0,
        "ref_max": 6.5,
        "ref_unit": "%",
        "critical_high": 15.0,
        "clinical_significance": "3-month glucose average",
        "vascular_relevance": "Target <7% for vascular patients. >9%: poor control, high complication risk."
    },
    
    # ========== INFLAMMATION ==========
    {
        "test_code": "CRP",
        "test_name": "C-Reactive Protein",
        "test_name_ru": "С-реактивный белок",
        "category": "inflammation",
        "ref_min": 0.0,
        "ref_max": 5.0,
        "ref_unit": "mg/L",
        "critical_high": 100.0,
        "clinical_significance": "Acute phase reactant",
        "vascular_relevance": "Elevated: infection, inflammation, cardiovascular risk."
    },
    {
        "test_code": "ESR",
        "test_name": "Erythrocyte Sedimentation Rate",
        "test_name_ru": "СОЭ (скорость оседания эритроцитов)",
        "category": "inflammation",
        "ref_min": 0.0,
        "ref_max": 15.0,
        "ref_unit": "mm/hour",
        "critical_high": 100.0,
        "clinical_significance": "Non-specific inflammation marker",
        "vascular_relevance": "Elevated in infection, inflammation, autoimmune disease."
    },
    {
        "test_code": "PROCALCITONIN",
        "test_name": "Procalcitonin",
        "test_name_ru": "Прокальцитонин",
        "category": "inflammation",
        "ref_min": 0.0,
        "ref_max": 0.05,
        "ref_unit": "ng/mL",
        "critical_high": 10.0,
        "clinical_significance": "Bacterial infection marker",
        "vascular_relevance": ">0.5: bacterial infection likely. >2: sepsis risk."
    },
    
    # ========== CARDIAC MARKERS ==========
    {
        "test_code": "TROPONIN_I",
        "test_name": "Troponin I",
        "test_name_ru": "Тропонин I",
        "category": "cardiac",
        "ref_min": 0.0,
        "ref_max": 0.04,
        "ref_unit": "ng/mL",
        "critical_high": 0.5,
        "clinical_significance": "Cardiac muscle damage marker",
        "vascular_relevance": "Elevated: MI, myocardial injury. Contraindication for elective surgery."
    },
    {
        "test_code": "TROPONIN_T",
        "test_name": "Troponin T",
        "test_name_ru": "Тропонин T",
        "category": "cardiac",
        "ref_min": 0.0,
        "ref_max": 0.01,
        "ref_unit": "ng/mL",
        "critical_high": 0.1,
        "clinical_significance": "Cardiac muscle damage marker",
        "vascular_relevance": "Elevated: MI, myocardial injury."
    },
    {
        "test_code": "BNP",
        "test_name": "BNP",
        "test_name_ru": "БНП (мозговой натрийуретический пептид)",
        "category": "cardiac",
        "ref_min": 0.0,
        "ref_max": 100.0,
        "ref_unit": "pg/mL",
        "critical_high": 900.0,
        "clinical_significance": "Heart failure marker",
        "vascular_relevance": "Elevated: heart failure. >400: severe HF, high surgical risk."
    },
    
    # ========== ELECTROLYTES ==========
    {
        "test_code": "SODIUM",
        "test_name": "Sodium",
        "test_name_ru": "Натрий",
        "category": "biochemistry",
        "ref_min": 136.0,
        "ref_max": 145.0,
        "ref_unit": "mmol/L",
        "critical_low": 120.0,
        "critical_high": 160.0,
        "clinical_significance": "Major extracellular cation",
        "vascular_relevance": "Critical for fluid balance. Abnormal: arrhythmia risk."
    },
    {
        "test_code": "POTASSIUM",
        "test_name": "Potassium",
        "test_name_ru": "Калий",
        "category": "biochemistry",
        "ref_min": 3.5,
        "ref_max": 5.1,
        "ref_unit": "mmol/L",
        "critical_low": 2.5,
        "critical_high": 6.5,
        "clinical_significance": "Major intracellular cation",
        "vascular_relevance": "Critical for cardiac function. Abnormal: life-threatening arrhythmias."
    },
    {
        "test_code": "CHLORIDE",
        "test_name": "Chloride",
        "test_name_ru": "Хлор",
        "category": "biochemistry",
        "ref_min": 98.0,
        "ref_max": 107.0,
        "ref_unit": "mmol/L",
        "critical_low": 80.0,
        "critical_high": 120.0,
        "clinical_significance": "Major extracellular anion",
        "vascular_relevance": "Part of acid-base balance assessment."
    },
]


async def seed_lab_test_references(db_session):
    """Seed lab test references into database"""
    from app.models.lab_test import LabTestReference
    from sqlalchemy import select
    
    for test_data in LAB_TEST_REFERENCES:
        # Check if already exists
        result = await db_session.execute(
            select(LabTestReference).where(
                LabTestReference.test_code == test_data["test_code"]
            )
        )
        if not result.scalar_one_or_none():
            test_ref = LabTestReference(**test_data)
            db_session.add(test_ref)
    
    await db_session.commit()
    print(f"Seeded {len(LAB_TEST_REFERENCES)} lab test references")
