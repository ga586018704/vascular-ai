"""
Database Session Management
Production-ready async database session with PostgreSQL support
"""
from sqlalchemy.ext.asyncio import (
    create_async_engine,
    AsyncSession,
    async_sessionmaker,
    AsyncEngine
)
from sqlalchemy.orm import sessionmaker
from sqlalchemy.pool import NullPool
from typing import AsyncGenerator
import logging

from app.core.config import get_settings

logger = logging.getLogger(__name__)

# Global engine instance
_engine: AsyncEngine | None = None
_async_session_maker: async_sessionmaker | None = None


def get_engine() -> AsyncEngine:
    """Get or create database engine with proper configuration"""
    global _engine
    
    if _engine is None:
        settings = get_settings()
        
        # Configure engine based on database type
        is_sqlite = "sqlite" in settings.DATABASE_URL.lower()
        
        if is_sqlite:
            # SQLite configuration (development only)
            logger.warning("Using SQLite - NOT recommended for production")
            _engine = create_async_engine(
                settings.DATABASE_URL,
                echo=settings.DEBUG,
                poolclass=NullPool,  # SQLite doesn't support connection pooling
                future=True
            )
        else:
            # PostgreSQL configuration (production)
            logger.info("Using PostgreSQL with connection pooling")
            _engine = create_async_engine(
                settings.DATABASE_URL,
                echo=settings.DEBUG,
                pool_size=settings.DATABASE_POOL_SIZE,
                max_overflow=settings.DATABASE_MAX_OVERFLOW,
                pool_timeout=settings.DATABASE_POOL_TIMEOUT,
                pool_recycle=settings.DATABASE_POOL_RECYCLE,
                pool_pre_ping=True,  # Verify connections before use
                future=True
            )
    
    return _engine


def get_session_maker() -> async_sessionmaker:
    """Get or create session maker"""
    global _async_session_maker
    
    if _async_session_maker is None:
        engine = get_engine()
        
        _async_session_maker = async_sessionmaker(
            engine,
            class_=AsyncSession,
            expire_on_commit=False,  # Better performance
            autoflush=False,  # Manual flush control
            autocommit=False  # Explicit transaction control
        )
    
    return _async_session_maker


async def get_db() -> AsyncGenerator[AsyncSession, None]:
    """
    Dependency for getting database session.
    Handles session lifecycle and rollback on errors.
    """
    session_maker = get_session_maker()
    async with session_maker() as session:
        try:
            yield session
            await session.commit()
        except Exception as e:
            await session.rollback()
            logger.error(f"Database session error: {e}")
            raise
        finally:
            await session.close()


async def get_db_session() -> AsyncSession:
    """
    Get a database session for use outside of FastAPI dependencies.
    Remember to close the session when done!
    """
    session_maker = get_session_maker()
    return session_maker()


async def close_db_connections():
    """Close all database connections - call on shutdown"""
    global _engine, _async_session_maker
    
    if _engine is not None:
        logger.info("Closing database connections...")
        await _engine.dispose()
        _engine = None
        _async_session_maker = None
        logger.info("Database connections closed")


async def test_connection() -> bool:
    """Test database connectivity"""
    try:
        engine = get_engine()
        from sqlalchemy import text
        async with engine.connect() as conn:
            result = await conn.execute(text("SELECT 1"))
            await result.fetchone()
            logger.info("Database connection test: SUCCESS")
            return True
    except Exception as e:
        logger.error(f"Database connection test: FAILED - {e}")
        return False


# Backward compatibility
SessionLocal = get_session_maker
