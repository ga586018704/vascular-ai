"""
Patients API Endpoints
CRUD operations for patient management with pagination
"""
from typing import List, Optional
from fastapi import APIRouter, Depends, HTTPException, Query, status
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, func, and_, or_
from sqlalchemy.orm import selectinload

from app.db.session import get_db
from app.core.security import get_current_active_user
from app.models.user import User
from app.models.patient import Patient
from app.schemas.patient import PatientCreate, PatientUpdate, PatientResponse, PatientListResponse

router = APIRouter()


@router.get("", response_model=PatientListResponse)
async def list_patients(
    page: int = Query(1, ge=1, description="Page number"),
    page_size: int = Query(20, ge=1, le=100, description="Items per page"),
    search: Optional[str] = Query(None, description="Search by name or MRN"),
    sort_by: str = Query("created_at", description="Sort field"),
    sort_order: str = Query("desc", description="Sort order: asc or desc"),
    include_deleted: bool = Query(False, description="Include soft-deleted patients"),
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_active_user)
):
    """
    List patients with pagination and filtering.
    
    - **page**: Page number (1-indexed)
    - **page_size**: Number of items per page (max 100)
    - **search**: Search by patient name or MRN
    - **sort_by**: Field to sort by (created_at, last_name, first_name, mrn)
    - **sort_order**: Sort direction (asc, desc)
    """
    # Build base query
    query = select(Patient)
    
    # Exclude soft-deleted by default
    if not include_deleted:
        query = query.where(Patient.deleted_at.is_(None))
    
    # Apply search filter
    if search:
        search_filter = or_(
            Patient.first_name.ilike(f"%{search}%"),
            Patient.last_name.ilike(f"%{search}%"),
            Patient.mrn.ilike(f"%{search}%")
        )
        query = query.where(search_filter)
    
    # Get total count
    count_query = select(func.count(Patient.id))
    if not include_deleted:
        count_query = count_query.where(Patient.deleted_at.is_(None))
    if search:
        count_query = count_query.where(search_filter)
    
    total_result = await db.execute(count_query)
    total = total_result.scalar()
    
    # Apply sorting
    sort_field = getattr(Patient, sort_by, Patient.created_at)
    if sort_order.lower() == "desc":
        query = query.order_by(sort_field.desc())
    else:
        query = query.order_by(sort_field.asc())
    
    # Apply pagination
    offset = (page - 1) * page_size
    query = query.offset(offset).limit(page_size)
    
    # Execute query
    result = await db.execute(query)
    patients = result.scalars().all()
    
    # Calculate pagination info
    total_pages = (total + page_size - 1) // page_size
    has_next = page < total_pages
    has_prev = page > 1
    
    return PatientListResponse(
        items=patients,
        total=total,
        page=page,
        page_size=page_size,
        total_pages=total_pages,
        has_next=has_next,
        has_prev=has_prev
    )


@router.post("", response_model=PatientResponse, status_code=status.HTTP_201_CREATED)
async def create_patient(
    patient_data: PatientCreate,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_active_user)
):
    """Create a new patient"""
    # Check for duplicate MRN
    existing = await db.execute(
        select(Patient).where(Patient.mrn == patient_data.mrn)
    )
    if existing.scalar_one_or_none():
        raise HTTPException(
            status_code=status.HTTP_409_CONFLICT,
            detail=f"Patient with MRN {patient_data.mrn} already exists"
        )
    
    patient = Patient(
        **patient_data.model_dump(),
        created_by_id=current_user.id
    )
    
    db.add(patient)
    await db.commit()
    await db.refresh(patient)
    
    return patient


@router.get("/{patient_id}", response_model=PatientResponse)
async def get_patient(
    patient_id: str,
    include_deleted: bool = False,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_active_user)
):
    """Get patient by ID"""
    query = select(Patient).where(Patient.id == patient_id)
    
    if not include_deleted:
        query = query.where(Patient.deleted_at.is_(None))
    
    # Load related studies
    query = query.options(selectinload(Patient.studies))
    
    result = await db.execute(query)
    patient = result.scalar_one_or_none()
    
    if not patient:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Patient not found"
        )
    
    return patient


@router.put("/{patient_id}", response_model=PatientResponse)
async def update_patient(
    patient_id: str,
    patient_data: PatientUpdate,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_active_user)
):
    """Update patient information"""
    result = await db.execute(
        select(Patient).where(
            and_(
                Patient.id == patient_id,
                Patient.deleted_at.is_(None)
            )
        )
    )
    patient = result.scalar_one_or_none()
    
    if not patient:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Patient not found"
        )
    
    # Update fields
    update_data = patient_data.model_dump(exclude_unset=True)
    for field, value in update_data.items():
        setattr(patient, field, value)
    
    patient.updated_by_id = current_user.id
    
    await db.commit()
    await db.refresh(patient)
    
    return patient


@router.delete("/{patient_id}", status_code=status.HTTP_204_NO_CONTENT)
async def delete_patient(
    patient_id: str,
    hard_delete: bool = Query(False, description="Permanently delete patient"),
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_active_user)
):
    """
    Delete patient (soft delete by default).
    
    - **hard_delete**: If true, permanently deletes the patient and all associated data
    """
    result = await db.execute(
        select(Patient).where(
            and_(
                Patient.id == patient_id,
                Patient.deleted_at.is_(None)
            )
        )
    )
    patient = result.scalar_one_or_none()
    
    if not patient:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Patient not found"
        )
    
    if hard_delete:
        # Permanent deletion - requires admin role
        if current_user.role != "admin":
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail="Only administrators can permanently delete patients"
            )
        await db.delete(patient)
    else:
        # Soft delete
        from datetime import datetime
        patient.deleted_at = datetime.utcnow()
        patient.updated_by_id = current_user.id
    
    await db.commit()
    
    return None


@router.post("/{patient_id}/restore", response_model=PatientResponse)
async def restore_patient(
    patient_id: str,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_active_user)
):
    """Restore a soft-deleted patient"""
    result = await db.execute(
        select(Patient).where(Patient.id == patient_id)
    )
    patient = result.scalar_one_or_none()
    
    if not patient:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Patient not found"
        )
    
    if patient.deleted_at is None:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Patient is not deleted"
        )
    
    patient.deleted_at = None
    patient.updated_by_id = current_user.id
    
    await db.commit()
    await db.refresh(patient)
    
    return patient


@router.get("/{patient_id}/studies")
async def get_patient_studies(
    patient_id: str,
    page: int = Query(1, ge=1),
    page_size: int = Query(20, ge=1, le=100),
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_active_user)
):
    """Get all studies for a patient"""
    from app.models.study import Study
    
    # Check patient exists
    patient_result = await db.execute(
        select(Patient).where(
            and_(
                Patient.id == patient_id,
                Patient.deleted_at.is_(None)
            )
        )
    )
    if not patient_result.scalar_one_or_none():
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Patient not found"
        )
    
    # Get studies with pagination
    query = (
        select(Study)
        .where(Study.patient_id == patient_id)
        .where(Study.deleted_at.is_(None))
        .order_by(Study.study_date.desc())
    )
    
    # Get total count
    count_result = await db.execute(
        select(func.count(Study.id)).where(Study.patient_id == patient_id)
    )
    total = count_result.scalar()
    
    # Apply pagination
    offset = (page - 1) * page_size
    query = query.offset(offset).limit(page_size)
    
    result = await db.execute(query)
    studies = result.scalars().all()
    
    return {
        "items": studies,
        "total": total,
        "page": page,
        "page_size": page_size,
        "total_pages": (total + page_size - 1) // page_size
    }
