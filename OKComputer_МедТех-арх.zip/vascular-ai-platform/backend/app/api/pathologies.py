"""
Pathology API Endpoints
Get comprehensive list of vascular pathologies
"""
from fastapi import APIRouter, Depends
from typing import List, Dict, Any

from app.core.security import get_current_user
from app.models.user import User
from app.core.pathology_types import (
    PathologyType, PathologyCategory, PathologySeverity,
    PathologyAcuity, ClinicalSignificance,
    get_pathology_description, get_pathologies_by_category
)

router = APIRouter()


@router.get("/types", response_model=List[Dict[str, Any]])
async def get_all_pathology_types(
    current_user: User = Depends(get_current_user),
):
    """
    Get all vascular pathology types with descriptions
    """
    pathologies = []
    
    for pathology_type in PathologyType:
        desc = get_pathology_description(pathology_type)
        pathologies.append({
            "code": pathology_type.value,
            "name": desc["name"],
            "name_ru": desc["name_ru"],
            "description": desc["description"],
            "description_ru": desc["description_ru"],
        })
    
    return pathologies


@router.get("/categories", response_model=List[Dict[str, Any]])
async def get_pathology_categories(
    current_user: User = Depends(get_current_user),
):
    """
    Get pathology categories
    """
    categories = []
    
    for category in PathologyCategory:
        category_names = {
            PathologyCategory.DEGENERATIVE: {
                "name": "Degenerative",
                "name_ru": "Дегенеративные",
                "description": "Age-related and degenerative changes"
            },
            PathologyCategory.INFLAMMATORY: {
                "name": "Inflammatory",
                "name_ru": "Воспалительные",
                "description": "Inflammatory and autoimmune conditions"
            },
            PathologyCategory.INFECTIOUS: {
                "name": "Infectious",
                "name_ru": "Инфекционные",
                "description": "Infectious and septic conditions"
            },
            PathologyCategory.TRAUMATIC: {
                "name": "Traumatic",
                "name_ru": "Травматические",
                "description": "Traumatic injuries"
            },
            PathologyCategory.CONGENITAL: {
                "name": "Congenital",
                "name_ru": "Врожденные",
                "description": "Congenital anomalies"
            },
            PathologyCategory.NEOPLASTIC: {
                "name": "Neoplastic",
                "name_ru": "Опухолевые",
                "description": "Tumors and neoplasms"
            },
            PathologyCategory.IATROGENIC: {
                "name": "Iatrogenic",
                "name_ru": "Ятрогенные",
                "description": "Treatment-related complications"
            },
            PathologyCategory.SYSTEMIC: {
                "name": "Systemic",
                "name_ru": "Системные",
                "description": "Systemic diseases affecting vessels"
            },
            PathologyCategory.FUNCTIONAL: {
                "name": "Functional",
                "name_ru": "Функциональные",
                "description": "Functional disorders"
            },
            PathologyCategory.IDIOPATHIC: {
                "name": "Idiopathic",
                "name_ru": "Идиопатические",
                "description": "Unknown etiology"
            },
        }
        
        info = category_names.get(category, {})
        categories.append({
            "code": category.value,
            "name": info.get("name", category.value),
            "name_ru": info.get("name_ru", category.value),
            "description": info.get("description", ""),
        })
    
    return categories


@router.get("/by-category/{category}", response_model=List[Dict[str, Any]])
async def get_pathologies_by_category_endpoint(
    category: str,
    current_user: User = Depends(get_current_user),
):
    """
    Get pathologies by category
    """
    try:
        cat = PathologyCategory(category)
    except ValueError:
        return []
    
    pathologies = get_pathologies_by_category(cat)
    
    result = []
    for p in pathologies:
        desc = get_pathology_description(p)
        result.append({
            "code": p.value,
            "name": desc["name"],
            "name_ru": desc["name_ru"],
            "description": desc["description"],
            "description_ru": desc["description_ru"],
        })
    
    return result


@router.get("/severities", response_model=List[Dict[str, str]])
async def get_severity_levels(
    current_user: User = Depends(get_current_user),
):
    """
    Get pathology severity levels
    """
    severities = []
    
    for severity in PathologySeverity:
        severity_names = {
            PathologySeverity.NORMAL: {"name": "Normal", "name_ru": "Норма"},
            PathologySeverity.MINIMAL: {"name": "Minimal", "name_ru": "Минимальные"},
            PathologySeverity.MILD: {"name": "Mild", "name_ru": "Легкие"},
            PathologySeverity.MODERATE: {"name": "Moderate", "name_ru": "Умеренные"},
            PathologySeverity.SEVERE: {"name": "Severe", "name_ru": "Тяжелые"},
            PathologySeverity.CRITICAL: {"name": "Critical", "name_ru": "Критические"},
            PathologySeverity.EXTREME: {"name": "Extreme", "name_ru": "Экстремальные"},
        }
        
        info = severity_names.get(severity, {})
        severities.append({
            "code": severity.value,
            "name": info.get("name", severity.value),
            "name_ru": info.get("name_ru", severity.value),
        })
    
    return severities


@router.get("/acuity", response_model=List[Dict[str, str]])
async def get_acuity_levels(
    current_user: User = Depends(get_current_user),
):
    """
    Get pathology acuity levels
    """
    acuities = []
    
    for acuity in PathologyAcuity:
        acuity_names = {
            PathologyAcuity.HYPERACUTE: {"name": "Hyperacute", "name_ru": "Гиперострое"},
            PathologyAcuity.ACUTE: {"name": "Acute", "name_ru": "Острое"},
            PathologyAcuity.SUBACUTE: {"name": "Subacute", "name_ru": "Подострое"},
            PathologyAcuity.CHRONIC: {"name": "Chronic", "name_ru": "Хроническое"},
            PathologyAcuity.RECURRENT: {"name": "Recurrent", "name_ru": "Рецидивирующее"},
        }
        
        info = acuity_names.get(acuity, {})
        acuities.append({
            "code": acuity.value,
            "name": info.get("name", acuity.value),
            "name_ru": info.get("name_ru", acuity.value),
        })
    
    return acuities


@router.get("/significance", response_model=List[Dict[str, str]])
async def get_clinical_significance_levels(
    current_user: User = Depends(get_current_user),
):
    """
    Get clinical significance levels
    """
    significances = []
    
    for sig in ClinicalSignificance:
        sig_names = {
            ClinicalSignificance.INCIDENTAL: {"name": "Incidental", "name_ru": "Случайная находка"},
            ClinicalSignificance.MONITOR: {"name": "Monitor", "name_ru": "Наблюдение"},
            ClinicalSignificance.TREATMENT_ELECTIVE: {"name": "Elective Treatment", "name_ru": "Плановое лечение"},
            ClinicalSignificance.TREATMENT_URGENT: {"name": "Urgent Treatment", "name_ru": "Срочное лечение"},
            ClinicalSignificance.TREATMENT_EMERGENCY: {"name": "Emergency Treatment", "name_ru": "Экстренное лечение"},
            ClinicalSignificance.LIFE_THREATENING: {"name": "Life-threatening", "name_ru": "Угрожающее жизни"},
        }
        
        info = sig_names.get(sig, {})
        significances.append({
            "code": sig.value,
            "name": info.get("name", sig.value),
            "name_ru": info.get("name_ru", sig.value),
        })
    
    return significances


@router.get("/search", response_model=List[Dict[str, Any]])
async def search_pathologies(
    query: str,
    current_user: User = Depends(get_current_user),
):
    """
    Search pathologies by name or description
    """
    results = []
    query_lower = query.lower()
    
    for pathology_type in PathologyType:
        desc = get_pathology_description(pathology_type)
        
        # Search in all fields
        searchable_text = f"{desc['name']} {desc['name_ru']} {desc['description']} {desc['description_ru']}".lower()
        
        if query_lower in searchable_text:
            results.append({
                "code": pathology_type.value,
                "name": desc["name"],
                "name_ru": desc["name_ru"],
                "description": desc["description"],
                "description_ru": desc["description_ru"],
            })
    
    return results


@router.get("/stats")
async def get_pathology_statistics(
    current_user: User = Depends(get_current_user),
):
    """
    Get statistics about available pathologies
    """
    total = len(PathologyType)
    
    by_category = {}
    for category in PathologyCategory:
        count = len(get_pathologies_by_category(category))
        by_category[category.value] = count
    
    return {
        "total_pathologies": total,
        "by_category": by_category,
        "categories_count": len(PathologyCategory),
        "severity_levels": len(PathologySeverity),
        "acuity_levels": len(PathologyAcuity),
        "significance_levels": len(ClinicalSignificance),
    }
