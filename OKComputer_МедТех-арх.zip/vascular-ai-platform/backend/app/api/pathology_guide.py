"""
Pathology Reference Guide API
Extended reference with search, filters, and clinical details
"""
from typing import List, Optional

from fastapi import APIRouter, Depends, HTTPException, Query
from sqlalchemy import func, or_, and_
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.future import select

from app.api.dependencies import get_current_active_user, get_db
from app.core.logging import get_logger
from app.models.user import User
from app.schemas.pathology import PathologyDetailResponse, PathologySearchResult

logger = get_logger(__name__)
router = APIRouter()

# Import pathology data from existing module
from app.core.pathology_types import (
    ARTERIAL_PATHOLOGIES, VENOUS_PATHOLOGIES, 
    LYMPHATIC_PATHOLOGIES, VASCULAR_MALFORMATIONS,
    VASCULAR_TUMORS, VASCULAR_INFLAMMATORY,
    VASCULAR_TRAUMA, VASCULAR_COMPLICATIONS
)


# Combine all pathologies
ALL_PATHOLOGIES = {
    **ARTERIAL_PATHOLOGIES,
    **VENOUS_PATHOLOGIES,
    **LYMPHATIC_PATHOLOGIES,
    **VASCULAR_MALFORMATIONS,
    **VASCULAR_TUMORS,
    **VASCULAR_INFLAMMATORY,
    **VASCULAR_TRAUMA,
    **VASCULAR_COMPLICATIONS,
}


# Category mapping
CATEGORY_MAP = {
    "arterial": ARTERIAL_PATHOLOGIES,
    "venous": VENOUS_PATHOLOGIES,
    "lymphatic": LYMPHATIC_PATHOLOGIES,
    "malformation": VASCULAR_MALFORMATIONS,
    "tumor": VASCULAR_TUMORS,
    "inflammatory": VASCULAR_INFLAMMATORY,
    "trauma": VASCULAR_TRAUMA,
    "complication": VASCULAR_COMPLICATIONS,
}


@router.get("/search", response_model=List[PathologySearchResult])
async def search_pathologies(
    query: str = Query(..., min_length=2, description="Search query"),
    category: Optional[str] = Query(None, description="Filter by category"),
    limit: int = Query(20, ge=1, le=100),
    current_user: User = Depends(get_current_active_user)
):
    """
    Search pathologies by name, code, or description.
    
    Supports Russian and English search terms.
    """
    results = []
    query_lower = query.lower()
    
    source_dicts = [CATEGORY_MAP[category]] if category and category in CATEGORY_MAP else CATEGORY_MAP.values()
    
    for source in source_dicts:
        for code, data in source.items():
            # Search in name, description, synonyms
            searchable_text = f"{data.get('name', '')} {data.get('name_ru', '')} {code}"
            searchable_text += f" {data.get('description', '')} {data.get('description_ru', '')}"
            
            synonyms = data.get('synonyms', [])
            if synonyms:
                searchable_text += ' '.join(synonyms)
            
            if query_lower in searchable_text.lower():
                results.append(PathologySearchResult(
                    code=code,
                    name=data.get('name', code),
                    name_ru=data.get('name_ru'),
                    category=data.get('category', 'unknown'),
                    severity=data.get('severity', 'unknown'),
                    description=data.get('description', '')[:200] + '...' if len(data.get('description', '')) > 200 else data.get('description', '')
                ))
    
    # Sort by relevance (exact match first)
    results.sort(key=lambda x: (
        0 if query_lower in x.name.lower() else 1,
        0 if query_lower in (x.name_ru or '').lower() else 1,
        x.name
    ))
    
    return results[:limit]


@router.get("/categories")
async def get_categories(
    current_user: User = Depends(get_current_active_user)
):
    """Get all pathology categories with counts"""
    categories = []
    
    for cat_key, cat_data in CATEGORY_MAP.items():
        categories.append({
            "key": cat_key,
            "name": cat_key.capitalize(),
            "name_ru": _get_category_name_ru(cat_key),
            "count": len(cat_data),
            "icon": _get_category_icon(cat_key)
        })
    
    return categories


def _get_category_name_ru(category: str) -> str:
    """Get Russian category name"""
    names = {
        "arterial": "Артериальные заболевания",
        "venous": "Венозные заболевания",
        "lymphatic": "Лимфатические заболевания",
        "malformation": "Сосудистые мальформации",
        "tumor": "Сосудистые опухоли",
        "inflammatory": "Воспалительные заболевания",
        "trauma": "Травмы сосудов",
        "complication": "Осложнения",
    }
    return names.get(category, category)


def _get_category_icon(category: str) -> str:
    """Get icon for category"""
    icons = {
        "arterial": "Heart",
        "venous": "Droplet",
        "lymphatic": "Activity",
        "malformation": "GitBranch",
        "tumor": "Circle",
        "inflammatory": "Flame",
        "trauma": "AlertTriangle",
        "complication": "AlertOctagon",
    }
    return icons.get(category, "FileText")


@router.get("/by-category/{category}", response_model=List[PathologySearchResult])
async def get_pathologies_by_category(
    category: str,
    severity: Optional[str] = Query(None, description="Filter by severity"),
    current_user: User = Depends(get_current_active_user)
):
    """Get all pathologies in a category"""
    if category not in CATEGORY_MAP:
        raise HTTPException(status_code=404, detail=f"Category '{category}' not found")
    
    source = CATEGORY_MAP[category]
    results = []
    
    for code, data in source.items():
        if severity and data.get('severity') != severity:
            continue
            
        results.append(PathologySearchResult(
            code=code,
            name=data.get('name', code),
            name_ru=data.get('name_ru'),
            category=data.get('category', category),
            severity=data.get('severity', 'unknown'),
            description=data.get('description', '')[:150] + '...' if len(data.get('description', '')) > 150 else data.get('description', '')
        ))
    
    return sorted(results, key=lambda x: x.name)


@router.get("/{pathology_code}", response_model=PathologyDetailResponse)
async def get_pathology_detail(
    pathology_code: str,
    current_user: User = Depends(get_current_active_user)
):
    """
    Get detailed information about a specific pathology.
    
    Includes anatomy, classification, treatment options, and surgical considerations.
    """
    # Search in all categories
    data = None
    category = None
    
    for cat_key, cat_data in CATEGORY_MAP.items():
        if pathology_code in cat_data:
            data = cat_data[pathology_code]
            category = cat_key
            break
    
    if not data:
        raise HTTPException(status_code=404, detail=f"Pathology '{pathology_code}' not found")
    
    # Build detailed response
    return PathologyDetailResponse(
        code=pathology_code,
        name=data.get('name', pathology_code),
        name_ru=data.get('name_ru'),
        category=category,
        severity=data.get('severity', 'unknown'),
        
        # Descriptions
        description=data.get('description', ''),
        description_ru=data.get('description_ru', ''),
        
        # Anatomy
        anatomy=data.get('anatomy', []),
        anatomy_ru=data.get('anatomy_ru', []),
        
        # Classification
        classification=data.get('classification', {}),
        
        # Clinical features
        symptoms=data.get('symptoms', []),
        symptoms_ru=data.get('symptoms_ru', []),
        signs=data.get('signs', []),
        signs_ru=data.get('signs_ru', []),
        
        # Diagnostics
        diagnostic_criteria=data.get('diagnostic_criteria', []),
        imaging_findings=data.get('imaging_findings', {}),
        
        # Treatment
        treatment_options=data.get('treatment_options', {}),
        treatment_options_ru=data.get('treatment_options_ru', {}),
        
        # Surgical
        surgical_indications=data.get('surgical_indications', []),
        surgical_indications_ru=data.get('surgical_indications_ru', []),
        surgical_techniques=data.get('surgical_techniques', []),
        surgical_techniques_ru=data.get('surgical_techniques_ru', []),
        
        # Complications
        complications=data.get('complications', []),
        complications_ru=data.get('complications_ru', []),
        
        # Prognosis
        prognosis=data.get('prognosis', ''),
        prognosis_ru=data.get('prognosis_ru', ''),
        
        # Follow-up
        follow_up=data.get('follow_up', {}),
        
        # References
        references=data.get('references', []),
        
        # Related
        related_conditions=data.get('related_conditions', []),
        synonyms=data.get('synonyms', []),
        
        # ICD codes
        icd10_codes=data.get('icd10_codes', []),
        
        # Risk factors
        risk_factors=data.get('risk_factors', []),
        risk_factors_ru=data.get('risk_factors_ru', []),
    )


@router.get("/by-icd/{icd_code}")
async def get_pathology_by_icd(
    icd_code: str,
    current_user: User = Depends(get_current_active_user)
):
    """Find pathology by ICD-10 code"""
    results = []
    
    for cat_key, cat_data in CATEGORY_MAP.items():
        for code, data in cat_data.items():
            icd_codes = data.get('icd10_codes', [])
            if icd_code.upper() in [c.upper() for c in icd_codes]:
                results.append(PathologySearchResult(
                    code=code,
                    name=data.get('name', code),
                    name_ru=data.get('name_ru'),
                    category=data.get('category', cat_key),
                    severity=data.get('severity', 'unknown'),
                    description=data.get('description', '')[:200] + '...' if len(data.get('description', '')) > 200 else data.get('description', '')
                ))
    
    return results


@router.get("/related/{pathology_code}")
async def get_related_pathologies(
    pathology_code: str,
    current_user: User = Depends(get_current_active_user)
):
    """Get related pathologies for a given condition"""
    # Find the pathology
    data = None
    
    for cat_data in CATEGORY_MAP.values():
        if pathology_code in cat_data:
            data = cat_data[pathology_code]
            break
    
    if not data:
        raise HTTPException(status_code=404, detail=f"Pathology '{pathology_code}' not found")
    
    related_codes = data.get('related_conditions', [])
    results = []
    
    for related_code in related_codes:
        for cat_data in CATEGORY_MAP.values():
            if related_code in cat_data:
                related_data = cat_data[related_code]
                results.append(PathologySearchResult(
                    code=related_code,
                    name=related_data.get('name', related_code),
                    name_ru=related_data.get('name_ru'),
                    category=related_data.get('category', 'unknown'),
                    severity=related_data.get('severity', 'unknown'),
                    description=related_data.get('description', '')[:150] + '...' if len(related_data.get('description', '')) > 150 else related_data.get('description', '')
                ))
                break
    
    return results


@router.get("/quick-reference/surgical-emergencies")
async def get_surgical_emergencies(
    current_user: User = Depends(get_current_active_user)
):
    """Quick reference for vascular surgical emergencies"""
    emergencies = []
    
    emergency_codes = [
        # Arterial
        "RAAA", "AAA_RUPTURE",  # Ruptured AAA
        "AAD", "AORTIC_DISSECTION",  # Aortic dissection
        "ACUTE_MESENTERIC_ISCHEMIA",
        "ACUTE_LIMB_ISCHEMIA",
        "TRAUMATIC_AORTIC_INJURY",
        # Venous
        "PE_MASSIVE",  # Massive PE
        "DVT_PHLEGMASIA",
    ]
    
    for code in emergency_codes:
        for cat_data in CATEGORY_MAP.values():
            if code in cat_data:
                data = cat_data[code]
                emergencies.append({
                    "code": code,
                    "name": data.get('name', code),
                    "name_ru": data.get('name_ru'),
                    "category": data.get('category', 'unknown'),
                    "presentation": data.get('symptoms_ru', data.get('symptoms', []))[:3],
                    "immediate_action": data.get('immediate_action', 'Emergency surgical consultation'),
                    "mortality": data.get('mortality', 'High without immediate treatment'),
                })
                break
    
    return emergencies


@router.get("/quick-reference/common-preop")
async def get_common_preoperative_conditions(
    current_user: User = Depends(get_current_active_user)
):
    """Common conditions requiring preoperative assessment"""
    conditions = [
        {
            "code": "CAROTID_STENOSIS",
            "name": "Carotid Artery Stenosis",
            "name_ru": "Стеноз сонной артерии",
            "preop_workup": ["CTA/MRA neck", "Neurology consult", "Cardiac risk assessment"],
            "surgical_threshold": ">70% symptomatic, >80% asymptomatic",
        },
        {
            "code": "AAA",
            "name": "Abdominal Aortic Aneurysm",
            "name_ru": "Аневризма брюшной аорты",
            "preop_workup": ["CTA aorta", "Cardiac echo", "Pulmonary function"],
            "surgical_threshold": ">5.5 cm men, >5.0 cm women",
        },
        {
            "code": "PAD_CLAUDICATION",
            "name": "Peripheral Artery Disease",
            "name_ru": "Облитерирующий атеросклероз",
            "preop_workup": ["ABI", "CTA runoff", "Medical optimization"],
            "surgical_threshold": "Failed medical therapy, lifestyle limiting",
        },
        {
            "code": "VARICOSE_VEINS",
            "name": "Varicose Veins",
            "name_ru": "Варикозная болезнь",
            "preop_workup": ["Duplex ultrasound", "CEAP classification"],
            "surgical_threshold": "C2-C6 with symptoms",
        },
    ]
    
    return conditions
