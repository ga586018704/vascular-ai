"""
Prometheus Metrics Endpoint
"""
from fastapi import APIRouter, Depends, HTTPException
from fastapi.responses import PlainTextResponse
from prometheus_client import (
    Counter,
    Histogram,
    Gauge,
    Info,
    generate_latest,
    CONTENT_TYPE_LATEST,
)
from app.core.security import check_admin_role
from app.models.user import User

router = APIRouter()

# Define metrics
REQUEST_COUNT = Counter(
    'vascular_ai_requests_total',
    'Total requests',
    ['method', 'endpoint', 'status']
)

REQUEST_DURATION = Histogram(
    'vascular_ai_request_duration_seconds',
    'Request duration in seconds',
    ['method', 'endpoint']
)

ACTIVE_USERS = Gauge(
    'vascular_ai_active_users',
    'Number of active users'
)

STUDIES_TOTAL = Gauge(
    'vascular_ai_studies_total',
    'Total number of studies'
)

REPORTS_TOTAL = Gauge(
    'vascular_ai_reports_total',
    'Total number of reports'
)

AI_ANALYSIS_DURATION = Histogram(
    'vascular_ai_analysis_duration_seconds',
    'AI analysis duration in seconds',
    ['agent_type']
)

AI_ANALYSIS_COUNT = Counter(
    'vascular_ai_analysis_total',
    'Total AI analyses performed',
    ['agent_type', 'status']
)

DB_CONNECTIONS = Gauge(
    'vascular_ai_db_connections',
    'Database connection pool status',
    ['state']
)

CACHE_HITS = Counter(
    'vascular_ai_cache_hits_total',
    'Total cache hits',
    ['cache_name']
)

CACHE_MISSES = Counter(
    'vascular_ai_cache_misses_total',
    'Total cache misses',
    ['cache_name']
)

APP_INFO = Info(
    'vascular_ai',
    'Application information'
)

# Set app info
APP_INFO.info({
    'version': '1.0.0',
    'name': 'VASCULAR.AI',
    'environment': 'production'
})


@router.get("/metrics", response_class=PlainTextResponse)
async def metrics(
    current_user: User = Depends(check_admin_role)
):
    """
    Prometheus metrics endpoint
    Accessible only by admin users
    """
    return PlainTextResponse(
        content=generate_latest(),
        media_type=CONTENT_TYPE_LATEST
    )


@router.get("/health")
async def health_check():
    """Basic health check endpoint (public)"""
    return {
        "status": "healthy",
        "timestamp": datetime.utcnow().isoformat()
    }


@router.get("/ready")
async def readiness_check():
    """Readiness probe for Kubernetes"""
    # Check database connection
    try:
        from app.db.session import AsyncSessionLocal
        async with AsyncSessionLocal() as db:
            await db.execute("SELECT 1")
        return {"status": "ready"}
    except Exception as e:
        raise HTTPException(status_code=503, detail=f"Not ready: {str(e)}")


# Metrics helpers
def record_request(method: str, endpoint: str, status: int, duration: float):
    """Record request metrics"""
    REQUEST_COUNT.labels(method=method, endpoint=endpoint, status=status).inc()
    REQUEST_DURATION.labels(method=method, endpoint=endpoint).observe(duration)


def record_ai_analysis(agent_type: str, duration: float, success: bool):
    """Record AI analysis metrics"""
    AI_ANALYSIS_DURATION.labels(agent_type=agent_type).observe(duration)
    AI_ANALYSIS_COUNT.labels(
        agent_type=agent_type,
        status="success" if success else "failure"
    ).inc()


def update_studies_count(count: int):
    """Update studies gauge"""
    STUDIES_TOTAL.set(count)


def update_reports_count(count: int):
    """Update reports gauge"""
    REPORTS_TOTAL.set(count)


def record_cache_hit(cache_name: str):
    """Record cache hit"""
    CACHE_HITS.labels(cache_name=cache_name).inc()


def record_cache_miss(cache_name: str):
    """Record cache miss"""
    CACHE_MISSES.labels(cache_name=cache_name).inc()


from datetime import datetime
