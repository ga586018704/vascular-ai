"""
DICOM Upload and Management API
Production-ready DICOM upload with validation and security
"""
import os
import uuid
import shutil
from datetime import datetime
from typing import List, Optional
from fastapi import APIRouter, Depends, HTTPException, UploadFile, File, Form, BackgroundTasks, status
from pydantic import BaseModel
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select

from app.db.session import get_db
from app.core.security import get_current_active_user
from app.core.config import get_settings
from app.core.dicom_validator import validate_dicom_file, DICOMValidationError
from app.models.user import User
from app.models.study import Study, StudyStatus, Modality
from app.models.patient import Patient
from app.tasks.dicom_tasks import process_dicom_upload

router = APIRouter()
settings = get_settings()


# Schemas
class DicomUploadResponse(BaseModel):
    study_id: str
    status: str
    message: str
    file_count: int


class StudyResponse(BaseModel):
    id: int
    study_instance_uid: str
    study_description: Optional[str]
    modality: str
    status: str
    patient_name: Optional[str]
    created_at: str


class StudyDetailResponse(BaseModel):
    id: int
    study_instance_uid: str
    accession_number: Optional[str]
    study_date: Optional[str]
    study_description: Optional[str]
    modality: str
    body_part: Optional[str]
    status: str
    file_count: int
    total_size_mb: float
    patient: dict
    findings: Optional[str]
    created_at: str


# Routes
@router.post("/upload", response_model=DicomUploadResponse)
async def upload_dicom(
    background_tasks: BackgroundTasks,
    files: List[UploadFile] = File(..., description="DICOM files to upload"),
    patient_mrn: Optional[str] = Form(None, description="Patient Medical Record Number"),
    study_description: Optional[str] = Form(None, description="Study description"),
    validate: bool = Form(True, description="Validate DICOM files before upload"),
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_active_user)
):
    """
    Upload DICOM files with automatic validation.
    
    - Validates DICOM file format and structure
    - Checks file size limits
    - Extracts metadata from DICOM headers
    - Queues files for background processing
    """
    if not files:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="No files uploaded"
        )
    
    # Check total upload size
    total_upload_size = sum(file.size or 0 for file in files)
    if total_upload_size > settings.DICOM_MAX_TOTAL_SIZE:
        raise HTTPException(
            status_code=status.HTTP_413_REQUEST_ENTITY_TOO_LARGE,
            detail=f"Total upload size {total_upload_size} bytes exceeds maximum {settings.DICOM_MAX_TOTAL_SIZE} bytes"
        )
    
    # Generate study UID
    study_uid = str(uuid.uuid4())
    
    # Create storage directory
    storage_path = f"./storage/dicom/{study_uid}"
    os.makedirs(storage_path, exist_ok=True)
    
    # Save and validate files
    saved_files = []
    valid_files = []
    invalid_files = []
    total_size = 0
    
    try:
        for file in files:
            # Check file extension
            file_ext = os.path.splitext(file.filename)[1].lower()
            if file_ext not in settings.ALLOWED_EXTENSIONS:
                invalid_files.append({
                    "filename": file.filename,
                    "error": f"Invalid file extension. Allowed: {', '.join(settings.ALLOWED_EXTENSIONS)}"
                })
                continue
            
            file_path = os.path.join(storage_path, file.filename)
            content = await file.read()
            
            # Save file
            with open(file_path, "wb") as f:
                f.write(content)
                total_size += len(content)
            
            saved_files.append(file_path)
            
            # Validate DICOM if requested
            if validate:
                is_valid, validation_info = await validate_dicom_file(file_path)
                if not is_valid:
                    invalid_files.append({
                        "filename": file.filename,
                        "error": validation_info.get("error", {}).get("message", "Validation failed"),
                        "details": validation_info.get("error", {}).get("details", {})
                    })
                    # Remove invalid file
                    os.remove(file_path)
                    saved_files.remove(file_path)
                    continue
                
                valid_files.append({
                    "filename": file.filename,
                    "metadata": validation_info.get("metadata", {})
                })
            else:
                valid_files.append({"filename": file.filename})
        
        # Find or create patient
        patient_id = None
        if patient_mrn:
            result = await db.execute(select(Patient).where(Patient.mrn == patient_mrn))
            patient = result.scalar_one_or_none()
            if patient:
                patient_id = patient.id
        
        # Create study record
        new_study = Study(
            study_instance_uid=study_uid,
            study_description=study_description,
            modality=Modality.CT,
            status=StudyStatus.PENDING,
            file_path=storage_path,
            file_count=len(files),
            total_size_bytes=total_size,
            patient_id=patient_id,
            uploaded_by=current_user.id,
        )
        
        db.add(new_study)
        await db.commit()
        await db.refresh(new_study)
        
        # Check if any files passed validation
        if not valid_files:
            # Cleanup on error
            shutil.rmtree(storage_path, ignore_errors=True)
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail={
                    "message": "No valid DICOM files found",
                    "invalid_files": invalid_files
                }
            )
        
        # Queue background processing
        background_tasks.add_task(
            process_dicom_upload.delay,
            storage_path,
            study_uid,
            current_user.id
        )
        
        return DicomUploadResponse(
            study_id=study_uid,
            status="queued",
            message=f"Uploading {len(valid_files)} valid DICOM files",
            file_count=len(valid_files),
            total_size_mb=round(total_size / (1024 * 1024), 2),
            invalid_files=invalid_files if invalid_files else None
        )
        
    except HTTPException:
        raise
    except Exception as e:
        # Cleanup on error
        shutil.rmtree(storage_path, ignore_errors=True)
        logger.error(f"DICOM upload failed: {e}", exc_info=True)
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Upload failed: {str(e)}"
        )


@router.get("/studies", response_model=List[StudyResponse])
async def list_studies(
    skip: int = 0,
    limit: int = 20,
    status: Optional[str] = None,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_active_user)
):
    """List all studies"""
    query = select(Study).order_by(Study.created_at.desc())
    
    if status:
        query = query.where(Study.status == status)
    
    query = query.offset(skip).limit(limit)
    result = await db.execute(query)
    studies = result.scalars().all()
    
    return [
        StudyResponse(
            id=s.id,
            study_instance_uid=s.study_instance_uid,
            study_description=s.study_description,
            modality=s.modality.value if s.modality else "Unknown",
            status=s.status.value if s.status else "Unknown",
            patient_name=s.patient.full_name if s.patient else None,
            created_at=s.created_at.isoformat() if s.created_at else "",
        )
        for s in studies
    ]


@router.get("/studies/{study_id}", response_model=StudyDetailResponse)
async def get_study(
    study_id: str,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_active_user)
):
    """Get study details"""
    result = await db.execute(select(Study).where(Study.study_instance_uid == study_id))
    study = result.scalar_one_or_none()
    
    if not study:
        raise HTTPException(status_code=404, detail="Study not found")
    
    return StudyDetailResponse(
        id=study.id,
        study_instance_uid=study.study_instance_uid,
        accession_number=study.accession_number,
        study_date=study.study_date.isoformat() if study.study_date else None,
        study_description=study.study_description,
        modality=study.modality.value if study.modality else "Unknown",
        body_part=study.body_part,
        status=study.status.value if study.status else "Unknown",
        file_count=study.file_count,
        total_size_mb=round(study.total_size_bytes / (1024 * 1024), 2),
        patient=study.patient.to_dict() if study.patient else None,
        findings=study.findings,
        created_at=study.created_at.isoformat() if study.created_at else "",
    )


@router.delete("/studies/{study_id}")
async def delete_study(
    study_id: str,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_active_user)
):
    """Delete a study"""
    result = await db.execute(select(Study).where(Study.study_instance_uid == study_id))
    study = result.scalar_one_or_none()
    
    if not study:
        raise HTTPException(status_code=404, detail="Study not found")
    
    # Delete files
    if study.file_path and os.path.exists(study.file_path):
        shutil.rmtree(study.file_path, ignore_errors=True)
    
    # Delete from database
    await db.delete(study)
    await db.commit()
    
    return {"message": "Study deleted successfully"}
