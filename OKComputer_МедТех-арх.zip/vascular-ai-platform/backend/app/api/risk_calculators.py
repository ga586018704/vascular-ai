"""
Risk Calculators API
Medical risk scores for vascular surgery
"""
from typing import Optional
from fastapi import APIRouter, Depends
from pydantic import BaseModel
from app.core.security import get_current_active_user
from app.models.user import User

router = APIRouter()


# VSGNE Risk Score
class VSGNERequest(BaseModel):
    age: int
    cad: bool = False  # Coronary artery disease
    chf: bool = False  # Congestive heart failure
    copd: bool = False  # COPD
    diabetes: bool = False
    creatinine: float  # mg/dL
    urgent_procedure: bool = False


class VSGNEResponse(BaseModel):
    score: int
    risk_category: str
    mortality_risk: str
    interpretation: str


# Wells Score for DVT/PE
class WellsRequest(BaseModel):
    active_cancer: bool = False
    bedridden_recently: bool = False
    calf_swelling: bool = False
    collateral_veins: bool = False
    entire_leg_swollen: bool = False
    localized_tenderness: bool = False
    pitting_edema: bool = False
    paralysis_paresis: bool = False
    previous_dvt: bool = False
    alternative_diagnosis_less_likely: bool = False


class WellsResponse(BaseModel):
    score: int
    probability: str
    recommendation: str


# GAS Score (Global Aortic Score)
class GASRequest(BaseModel):
    age: int
    gender: str  # M/F
    bmi: float
    hypertension: bool = False
    diabetes: bool = False
    smoking: bool = False
    family_history: bool = False


class GASResponse(BaseModel):
    score: float
    risk_category: str
    aaa_risk_10yr: str


@router.post("/vsgne", response_model=VSGNEResponse)
async def calculate_vsgne(
    data: VSGNERequest,
    current_user: User = Depends(get_current_active_user)
):
    """
    Calculate VSGNE (Vascular Study Group of New England) Risk Score
    Predicts mortality after vascular surgery
    """
    score = 0
    
    # Age
    if data.age >= 80:
        score += 4
    elif data.age >= 70:
        score += 3
    elif data.age >= 60:
        score += 2
    
    # Comorbidities
    if data.cad:
        score += 2
    if data.chf:
        score += 3
    if data.copd:
        score += 2
    if data.diabetes:
        score += 1
    
    # Creatinine
    if data.creatinine >= 2.0:
        score += 3
    elif data.creatinine >= 1.5:
        score += 2
    
    # Urgency
    if data.urgent_procedure:
        score += 3
    
    # Risk category
    if score <= 3:
        risk_category = "Low Risk"
        mortality_risk = "< 1%"
    elif score <= 6:
        risk_category = "Moderate Risk"
        mortality_risk = "1-5%"
    elif score <= 9:
        risk_category = "High Risk"
        mortality_risk = "5-15%"
    else:
        risk_category = "Very High Risk"
        mortality_risk = "> 15%"
    
    return VSGNEResponse(
        score=score,
        risk_category=risk_category,
        mortality_risk=mortality_risk,
        interpretation=f"VSGNE Score: {score} - {risk_category}. Predicted 30-day mortality: {mortality_risk}"
    )


@router.post("/wells-dvt", response_model=WellsResponse)
async def calculate_wells_dvt(
    data: WellsRequest,
    current_user: User = Depends(get_current_active_user)
):
    """
    Calculate Wells Score for Deep Vein Thrombosis
    """
    score = 0
    
    if data.active_cancer:
        score += 1
    if data.bedridden_recently:
        score += 1
    if data.calf_swelling:
        score += 1
    if data.collateral_veins:
        score += 1
    if data.entire_leg_swollen:
        score += 1
    if data.localized_tenderness:
        score += 1
    if data.pitting_edema:
        score += 1
    if data.paralysis_paresis:
        score += 1
    if data.previous_dvt:
        score += 1
    if data.alternative_diagnosis_less_likely:
        score += 1
    
    # Interpretation
    if score <= 0:
        probability = "Low probability (< 5%)"
        recommendation = "D-dimer testing. If negative, DVT unlikely."
    elif score <= 2:
        probability = "Moderate probability (17-25%)"
        recommendation = "Ultrasound imaging recommended."
    else:
        probability = "High probability (53-75%)"
        recommendation = "Immediate ultrasound imaging. Consider anticoagulation if delayed."
    
    return WellsResponse(
        score=score,
        probability=probability,
        recommendation=recommendation
    )


@router.post("/gas", response_model=GASResponse)
async def calculate_gas(
    data: GASRequest,
    current_user: User = Depends(get_current_active_user)
):
    """
    Calculate GAS (Global Aortic Score)
    Predicts 10-year risk of AAA
    """
    score = 0.0
    
    # Age
    score += (data.age - 50) * 0.1
    
    # Gender
    if data.gender.upper() == "M":
        score += 2.0
    
    # BMI
    if data.bmi >= 30:
        score += 1.0
    
    # Risk factors
    if data.hypertension:
        score += 1.5
    if data.diabetes:
        score -= 0.5  # Protective
    if data.smoking:
        score += 2.0
    if data.family_history:
        score += 2.0
    
    # Risk category
    if score < 3:
        risk_category = "Low Risk"
        aaa_risk = "< 2%"
    elif score < 6:
        risk_category = "Moderate Risk"
        aaa_risk = "2-5%"
    elif score < 9:
        risk_category = "High Risk"
        aaa_risk = "5-10%"
    else:
        risk_category = "Very High Risk"
        aaa_risk = "> 10%"
    
    return GASResponse(
        score=round(score, 1),
        risk_category=risk_category,
        aaa_risk_10yr=aaa_risk
    )


@router.get("/")
async def list_calculators(
    current_user: User = Depends(get_current_active_user)
):
    """List available risk calculators"""
    return {
        "calculators": [
            {
                "id": "vsgne",
                "name": "VSGNE Risk Score",
                "description": "Predicts mortality after vascular surgery",
                "url": "/api/calculators/vsgne"
            },
            {
                "id": "wells-dvt",
                "name": "Wells Score (DVT)",
                "description": "Assesses probability of deep vein thrombosis",
                "url": "/api/calculators/wells-dvt"
            },
            {
                "id": "gas",
                "name": "Global Aortic Score",
                "description": "Predicts 10-year risk of abdominal aortic aneurysm",
                "url": "/api/calculators/gas"
            }
        ]
    }
