"""
CT Angiography Analysis API
Main endpoint for vascular surgery decision support
"""
import os
import tempfile
import shutil
from typing import List, Optional
from fastapi import APIRouter, Depends, HTTPException, UploadFile, File, Form, BackgroundTasks
from fastapi.responses import JSONResponse
from pydantic import BaseModel
from sqlalchemy.ext.asyncio import AsyncSession
import pydicom
import numpy as np

from app.db.session import get_db
from app.core.security import get_current_active_user
from app.models.user import User
from app.core.dicom_processor import (
    process_ct_angiography,
    CTAngiographyStudy,
    PathologyType,
    VesselType,
)
from app.services.treatment_service import (
    generate_treatment_plan,
    TreatmentRecommendation,
    TreatmentOption,
    TreatmentApproach,
    TreatmentPriority,
)
from app.tasks.angiography_tasks import process_angiography_async

router = APIRouter()


# Request/Response Models
class PatientFactors(BaseModel):
    """Patient-specific factors for treatment planning"""
    age: int
    gender: str  # M, F
    weight_kg: Optional[float] = None
    height_cm: Optional[float] = None
    
    # Comorbidities
    hypertension: bool = False
    diabetes: bool = False
    coronary_artery_disease: bool = False
    prior_mi: bool = False
    chf: bool = False
    copd: bool = False
    ckd_stage: Optional[int] = None
    prior_stroke: bool = False
    
    # Medications
    on_anticoagulation: bool = False
    on_antiplatelet: bool = False
    
    # Surgical history
    prior_vascular_surgery: bool = False
    prior_cardiac_surgery: bool = False
    
    # Functional status
    asa_class: int = 2  # 1-5
    ecog_performance_status: int = 0  # 0-4
    
    # Symptoms
    claudication: bool = False
    rest_pain: bool = False
    tissue_loss: bool = False
    acute_ischemia: bool = False


class VesselMeasurementResponse(BaseModel):
    """Vessel measurement response"""
    proximal_diameter_mm: float
    distal_diameter_mm: float
    minimal_diameter_mm: float
    maximal_diameter_mm: float
    length_mm: float
    volume_ml: float


class PathologyFindingResponse(BaseModel):
    """Pathology finding response"""
    pathology_type: str
    vessel_type: str
    vessel_name: str
    location: str
    severity: str
    degree_percent: Optional[float] = None
    length_mm: Optional[float] = None
    morphology: Optional[str] = None
    calcification: Optional[str] = None
    thrombus: Optional[bool] = None
    surgical_priority: str
    confidence: float
    
    # Aneurysm-specific
    aneurysm_type: Optional[str] = None
    sac_diameter_mm: Optional[float] = None
    rupture_risk: Optional[str] = None
    
    # Stenosis-specific
    tasc_classification: Optional[str] = None
    reference_diameter_mm: Optional[float] = None


class SegmentedVesselResponse(BaseModel):
    """Segmented vessel response"""
    vessel_type: str
    vessel_name: str
    side: Optional[str]
    measurements: VesselMeasurementResponse
    pathologies: List[PathologyFindingResponse]
    runoff_status: Optional[str]


class TreatmentOptionResponse(BaseModel):
    """Treatment option response"""
    approach: str
    procedure_name: str
    description: str
    indications: List[str]
    contraindications: List[str]
    advantages: List[str]
    disadvantages: List[str]
    anesthesia: str
    expected_duration_minutes: int
    hospital_stay_days: int
    technical_success_rate: float
    mortality_30day: float
    major_complication_rate: float


class TreatmentRecommendationResponse(BaseModel):
    """Treatment recommendation response"""
    pathology_type: str
    vessel_name: str
    priority: str
    recommended_approach: str
    alternative_approaches: List[str]
    
    # Primary option
    primary_option: TreatmentOptionResponse
    alternative_options: List[TreatmentOptionResponse]
    
    # Clinical information
    clinical_summary: str
    anatomical_description: str
    pathophysiology: str
    decision_rationale: str
    evidence_level: str
    guideline_reference: str
    
    # Workup
    required_tests: List[str]
    optional_tests: List[str]
    consultations: List[str]
    
    # Risks
    procedure_specific_risks: List[str]
    risk_mitigation: List[str]
    
    # Follow-up
    surveillance_protocol: str
    follow_up_schedule: List[str]


class AngiographyAnalysisResponse(BaseModel):
    """Complete angiography analysis response"""
    study_id: str
    patient_id: str
    analysis_date: str
    image_quality: str
    contrast_quality: str
    
    # Segmentation results
    vessels: List[SegmentedVesselResponse]
    total_vessels: int
    
    # Pathology summary
    total_pathologies: int
    critical_findings: List[str]
    
    # Treatment recommendations
    treatment_recommendations: List[TreatmentRecommendationResponse]
    
    # Summary
    executive_summary: str
    urgent_actions: List[str]


class AngiographyUploadResponse(BaseModel):
    """Upload response with task ID"""
    task_id: str
    status: str
    message: str
    estimated_completion_seconds: int


@router.post("/upload", response_model=AngiographyUploadResponse)
async def upload_angiography(
    background_tasks: BackgroundTasks,
    files: List[UploadFile] = File(...),
    patient_factors: str = Form(...),  # JSON string
    current_user: User = Depends(get_current_active_user)
):
    """
    Upload CT angiography DICOM files for analysis
    
    Files are processed asynchronously. Use the returned task_id to check status.
    """
    if len(files) == 0:
        raise HTTPException(status_code=400, detail="No files uploaded")
    
    # Validate DICOM files
    dicom_files = []
    temp_dir = tempfile.mkdtemp()
    
    try:
        for file in files:
            # Save to temp
            temp_path = os.path.join(temp_dir, file.filename)
            with open(temp_path, "wb") as f:
                content = await file.read()
                f.write(content)
            
            # Validate as DICOM
            try:
                ds = pydicom.dcmread(temp_path)
                dicom_files.append(temp_path)
            except Exception as e:
                raise HTTPException(status_code=400, detail=f"Invalid DICOM file: {file.filename}")
        
        # Queue async processing
        task = process_angiography_async.delay(
            dicom_files=dicom_files,
            patient_factors=patient_factors,
            user_id=current_user.id
        )
        
        return AngiographyUploadResponse(
            task_id=task.id,
            status="queued",
            message=f"Processing {len(dicom_files)} DICOM files",
            estimated_completion_seconds=len(dicom_files) * 5
        )
        
    except Exception as e:
        shutil.rmtree(temp_dir, ignore_errors=True)
        raise HTTPException(status_code=500, detail=f"Upload failed: {str(e)}")


@router.post("/analyze", response_model=AngiographyAnalysisResponse)
async def analyze_angiography(
    files: List[UploadFile] = File(...),
    patient_factors: PatientFactors = Depends(),
    current_user: User = Depends(get_current_active_user)
):
    """
    Synchronous CT angiography analysis
    
    Analyzes uploaded DICOM files and returns complete vascular assessment
    with treatment recommendations in vascular surgery language.
    """
    if len(files) == 0:
        raise HTTPException(status_code=400, detail="No files uploaded")
    
    # Read DICOM files
    dicom_datasets = []
    for file in files:
        try:
            content = await file.read()
            ds = pydicom.dcmread(content)
            dicom_datasets.append(ds)
        except Exception as e:
            raise HTTPException(status_code=400, detail=f"Invalid DICOM: {file.filename}")
    
    # Process angiography
    try:
        study = process_ct_angiography(dicom_datasets)
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Processing failed: {str(e)}")
    
    # Generate treatment plan
    patient_dict = patient_factors.dict()
    treatment_plan = generate_treatment_plan(study, patient_dict)
    
    # Build response
    return _build_analysis_response(study, treatment_plan)


@router.get("/vessels", response_model=List[dict])
async def get_vessel_types(
    current_user: User = Depends(get_current_active_user)
):
    """Get list of supported vessel types with anatomical nomenclature"""
    vessels = []
    
    vessel_info = {
        VesselType.AORTA_ASCENDENS: {
            "latin": "Aorta ascendens",
            "russian": "Восходящая аорта",
            "location": "Mediastinum anterior",
            "segments": ["Root", "Tubular portion"]
        },
        VesselType.AORTA_ARCH: {
            "latin": "Arcus aortae",
            "russian": "Дуга аорты",
            "location": "Mediastinum superior",
            "segments": ["Proximal", "Distal"]
        },
        VesselType.AORTA_DESCENDENS: {
            "latin": "Aorta descendens",
            "russian": "Нисходящая аорта",
            "location": "Mediastinum posterior",
            "segments": ["Thoracic", "Abdominal"]
        },
        VesselType.AORTA_ABDOMINALIS: {
            "latin": "Aorta abdominalis",
            "russian": "Брюшная аорта",
            "location": "Retroperitoneum",
            "segments": ["Suprarenal", "Infrarenal", "Bifurcation"]
        },
        VesselType.A_CAROTIS_COMMUNIS: {
            "latin": "Arteria carotis communis",
            "russian": "Общая сонная артерия",
            "location": "Neck",
            "segments": ["Proximal", "Distal"]
        },
        VesselType.A_CAROTIS_INTERNA: {
            "latin": "Arteria carotis interna",
            "russian": "Внутренняя сонная артерия",
            "location": "Neck/Skull base",
            "segments": ["Cervical", "Petrous", "Cavernous", "Cerebral"]
        },
        VesselType.A_ILIACA_COMMUNIS: {
            "latin": "Arteria iliaca communis",
            "russian": "Общая подвздошная артерия",
            "location": "Pelvis",
            "segments": ["Proximal", "Distal"]
        },
        VesselType.A_ILIACA_EXTERNA: {
            "latin": "Arteria iliaca externa",
            "russian": "Наружная подвздошная артерия",
            "location": "Pelvis",
            "segments": ["Proximal", "Distal"]
        },
        VesselType.A_FEMORALIS: {
            "latin": "Arteria femoralis",
            "russian": "Бедренная артерия",
            "location": "Thigh",
            "segments": ["Common", "Superficial", "Deep"]
        },
        VesselType.A_POPLITEA: {
            "latin": "Arteria poplitea",
            "russian": "Подколенная артерия",
            "location": "Popliteal fossa",
            "segments": ["Above knee", "Below knee"]
        },
        VesselType.A_RENALIS: {
            "latin": "Arteria renalis",
            "russian": "Почечная артерия",
            "location": "Retroperitoneum",
            "segments": ["Main", "Segmental"]
        },
        VesselType.A_MESENTERICA_SUP: {
            "latin": "Arteria mesenterica superior",
            "russian": "Верхняя брыжеечная артерия",
            "location": "Retroperitoneum",
            "segments": ["Main", "Branches"]
        },
    }
    
    for vessel_type, info in vessel_info.items():
        vessels.append({
            "code": vessel_type.value,
            "latin": info["latin"],
            "russian": info["russian"],
            "location": info["location"],
            "segments": info["segments"]
        })
    
    return vessels


@router.get("/pathologies", response_model=List[dict])
async def get_pathology_types(
    current_user: User = Depends(get_current_active_user)
):
    """Get list of detectable pathology types"""
    pathologies = []
    
    pathology_info = {
        PathologyType.ANEURYSM: {
            "name": "Aneurysm",
            "russian": "Аневризма",
            "description": "Localized dilation >50% of normal diameter",
            "subtypes": ["Saccular", "Fusiform", "Dissecting", "Mycotic"]
        },
        PathologyType.STENOSIS: {
            "name": "Stenosis",
            "russian": "Стеноз",
            "description": "Narrowing of vessel lumen",
            "grades": ["Mild (<50%)", "Moderate (50-70%)", "Severe (70-99%)"]
        },
        PathologyType.OCCLUSION: {
            "name": "Occlusion",
            "russian": "Окклюзия",
            "description": "Complete blockage of vessel",
            "types": ["Acute", "Chronic"]
        },
        PathologyType.THROMBOSIS: {
            "name": "Thrombosis",
            "russian": "Тромбоз",
            "description": "Intraluminal thrombus formation",
            "locations": ["Intraluminal", "Mural"]
        },
        PathologyType.DISSECTION: {
            "name": "Dissection",
            "russian": "Диссекция",
            "description": "Intimal tear with false lumen",
            "classifications": ["Type A", "Type B (Stanford)"]
        },
        PathologyType.AVM: {
            "name": "Arteriovenous Malformation",
            "russian": "Артериовенозная мальформация",
            "description": "Direct artery-to-vein connection",
            "types": ["Congenital", "Acquired"]
        },
    }
    
    for path_type, info in pathology_info.items():
        pathologies.append({
            "code": path_type.value,
            "name": info["name"],
            "russian": info["russian"],
            "description": info["description"],
            "details": {k: v for k, v in info.items() if k not in ["name", "russian", "description"]}
        })
    
    return pathologies


def _build_analysis_response(study: CTAngiographyStudy, treatment_plan: dict) -> AngiographyAnalysisResponse:
    """Build API response from analysis results"""
    
    vessels = []
    for v in study.vessels:
        pathologies = []
        for p in v.pathologies:
            path_response = PathologyFindingResponse(
                pathology_type=p.pathology_type.value,
                vessel_type=p.vessel_type.value,
                vessel_name=v.vessel_name,
                location=p.location,
                severity=p.severity,
                degree_percent=getattr(p, 'degree_percent', None),
                length_mm=p.length_mm,
                morphology=p.morphology,
                calcification=p.calcification,
                thrombus=p.thrombus,
                surgical_priority=p.surgical_priority,
                confidence=p.confidence,
            )
            
            # Add aneurysm-specific fields
            if isinstance(p, AneurysmFinding):
                path_response.aneurysm_type = p.aneurysm_type.value
                path_response.sac_diameter_mm = p.sac_diameter_mm
                path_response.rupture_risk = p.rupture_risk
            
            # Add stenosis-specific fields
            if isinstance(p, StenosisFinding):
                path_response.tasc_classification = p.tasc_classification
                path_response.reference_diameter_mm = p.reference_diameter_mm
            
            pathologies.append(path_response)
        
        vessels.append(SegmentedVesselResponse(
            vessel_type=v.vessel_type.value,
            vessel_name=v.vessel_name,
            side=v.side,
            measurements=VesselMeasurementResponse(
                proximal_diameter_mm=v.measurements.proximal_diameter_mm,
                distal_diameter_mm=v.measurements.distal_diameter_mm,
                minimal_diameter_mm=v.measurements.minimal_diameter_mm,
                maximal_diameter_mm=v.measurements.maximal_diameter_mm,
                length_mm=v.measurements.length_mm,
                volume_ml=v.measurements.volume_ml,
            ),
            pathologies=pathologies,
            runoff_status=v.runoff_status,
        ))
    
    # Build treatment recommendations
    recommendations = []
    for rec in treatment_plan.get("recommendations", []):
        
        def convert_option(opt):
            return TreatmentOptionResponse(
                approach=opt.approach.value,
                procedure_name=opt.procedure_name,
                description=opt.description,
                indications=opt.indications,
                contraindications=opt.contraindications,
                advantages=opt.advantages,
                disadvantages=opt.disadvantages,
                anesthesia=opt.anesthesia,
                expected_duration_minutes=opt.expected_duration_minutes,
                hospital_stay_days=opt.hospital_stay_days,
                technical_success_rate=opt.technical_success_rate,
                mortality_30day=opt.mortality_30day,
                major_complication_rate=opt.major_complication_rate,
            )
        
        recommendations.append(TreatmentRecommendationResponse(
            pathology_type=rec.pathology.pathology_type.value,
            vessel_name=rec.pathology.vessel_type.value,
            priority=rec.priority.value,
            recommended_approach=rec.recommended_approach.value,
            alternative_approaches=[a.value for a in rec.alternative_approaches],
            primary_option=convert_option(rec.primary_option),
            alternative_options=[convert_option(o) for o in rec.alternative_options],
            clinical_summary=rec.clinical_summary,
            anatomical_description=rec.anatomical_description,
            pathophysiology=rec.pathophysiology,
            decision_rationale=rec.decision_rationale,
            evidence_level=rec.evidence_level,
            guideline_reference=rec.guideline_reference,
            required_tests=rec.required_tests,
            optional_tests=rec.optional_tests,
            consultations=rec.consultations,
            procedure_specific_risks=rec.procedure_specific_risks,
            risk_mitigation=rec.risk_mitigation,
            surveillance_protocol=rec.surveillance_protocol,
            follow_up_schedule=rec.follow_up_schedule,
        ))
    
    # Generate executive summary
    executive_summary = _generate_executive_summary(study, treatment_plan)
    
    # Get urgent actions
    urgent_actions = [
        f"{rec.pathology.vessel_type.value}: {rec.pathology.pathology_type.value} - {rec.priority.value}"
        for rec in treatment_plan.get("recommendations", [])
        if rec.priority in [TreatmentPriority.EMERGENCY, TreatmentPriority.URGENT]
    ]
    
    return AngiographyAnalysisResponse(
        study_id=study.study_id,
        patient_id=study.patient_id,
        analysis_date=study.acquisition_date,
        image_quality=study.image_quality,
        contrast_quality=study.contrast_quality,
        vessels=vessels,
        total_vessels=len(vessels),
        total_pathologies=sum(len(v.pathologies) for v in study.vessels),
        critical_findings=study.critical_findings,
        treatment_recommendations=recommendations,
        executive_summary=executive_summary,
        urgent_actions=urgent_actions,
    )


def _generate_executive_summary(study: CTAngiographyStudy, treatment_plan: dict) -> str:
    """Generate executive summary in surgeon's language"""
    
    lines = [
        "ЗАКЛЮЧЕНИЕ ПО КТ-АНГИОГРАФИИ",
        "=" * 50,
        "",
    ]
    
    # Image quality
    lines.append(f"Качество изображения: {study.image_quality}")
    lines.append(f"Качество контрастирования: {study.contrast_quality}")
    lines.append("")
    
    # Vessel summary
    lines.append(f"Сегментировано сосудов: {len(study.vessels)}")
    lines.append("")
    
    # Pathology summary
    total_pathologies = sum(len(v.pathologies) for v in study.vessels)
    if total_pathologies == 0:
        lines.append("ПАТОЛОГИЯ НЕ ВЫЯВЛЕНА")
        lines.append("Все магистральные сосуды проходимы, без значимого стеноза или аневризматического расширения.")
    else:
        lines.append(f"ВЫЯВЛЕНО ПАТОЛОГИЙ: {total_pathologies}")
        lines.append("")
        
        for vessel in study.vessels:
            for p in vessel.pathologies:
                lines.append(f"• {vessel.vessel_name}: {p.pathology_type.value}")
                if hasattr(p, 'degree_percent') and p.degree_percent:
                    lines.append(f"  Степень: {p.degree_percent:.0f}%")
                if hasattr(p, 'sac_diameter_mm') and p.sac_diameter_mm:
                    lines.append(f"  Диаметр: {p.sac_diameter_mm:.1f} мм")
                lines.append(f"  Приоритет: {p.surgical_priority}")
                lines.append("")
    
    # Critical findings
    if study.critical_findings:
        lines.append("КРИТИЧЕСКИЕ НАХОДКИ:")
        for finding in study.critical_findings:
            lines.append(f"⚠️  {finding}")
        lines.append("")
    
    # Recommendations
    lines.append("РЕКОМЕНДАЦИИ:")
    lines.append(treatment_plan.get("summary", "Нет специфических рекомендаций"))
    
    return "\n".join(lines)
