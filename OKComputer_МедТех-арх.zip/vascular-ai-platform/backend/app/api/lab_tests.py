"""
Laboratory Tests API Endpoints
"""
from datetime import datetime, timedelta
from typing import List, Optional

from fastapi import APIRouter, Depends, HTTPException, Query, status
from sqlalchemy import func, and_, or_
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.future import select

from app.api.dependencies import get_current_active_user, get_current_doctor_user, get_db
from app.core.logging import get_logger
from app.models.lab_test import LabTestReference, PatientLabResult, LabTestCategory
from app.models.patient import Patient
from app.models.user import User
from app.schemas.lab_test import (
    LabTestReferenceCreate, LabTestReferenceResponse, LabTestReferenceList,
    PatientLabResultCreate, PatientLabResultResponse, PatientLabResultList,
    PatientLabResultUpdate, LabResultFilter, BulkLabResultCreate,
    LabTrendResponse, LabTrendPoint, LabResultAnalysis
)

logger = get_logger(__name__)
router = APIRouter()


# ============== Lab Test References ==============

@router.get("/references", response_model=LabTestReferenceList)
async def list_lab_references(
    category: Optional[LabTestCategory] = Query(None, description="Filter by category"),
    search: Optional[str] = Query(None, description="Search by name or code"),
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_active_user)
):
    """
    List all available laboratory test references.
    
    Returns reference ranges, units, and clinical significance for each test.
    """
    query = select(LabTestReference)
    
    if category:
        query = query.where(LabTestReference.category == category)
    
    if search:
        search_filter = or_(
            LabTestReference.test_code.ilike(f"%{search}%"),
            LabTestReference.test_name.ilike(f"%{search}%"),
            LabTestReference.test_name_ru.ilike(f"%{search}%")
        )
        query = query.where(search_filter)
    
    query = query.order_by(LabTestReference.category, LabTestReference.test_name)
    
    result = await db.execute(query)
    references = result.scalars().all()
    
    return LabTestReferenceList(
        items=[LabTestReferenceResponse.model_validate(r) for r in references],
        total=len(references)
    )


@router.get("/references/{reference_id}", response_model=LabTestReferenceResponse)
async def get_lab_reference(
    reference_id: int,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_active_user)
):
    """Get single lab test reference by ID"""
    result = await db.execute(
        select(LabTestReference).where(LabTestReference.id == reference_id)
    )
    reference = result.scalar_one_or_none()
    
    if not reference:
        raise HTTPException(status_code=404, detail="Lab test reference not found")
    
    return LabTestReferenceResponse.model_validate(reference)


@router.get("/references/by-code/{test_code}", response_model=LabTestReferenceResponse)
async def get_lab_reference_by_code(
    test_code: str,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_active_user)
):
    """Get lab test reference by code (e.g., 'INR', 'PT')"""
    result = await db.execute(
        select(LabTestReference).where(LabTestReference.test_code == test_code.upper())
    )
    reference = result.scalar_one_or_none()
    
    if not reference:
        raise HTTPException(status_code=404, detail=f"Lab test with code '{test_code}' not found")
    
    return LabTestReferenceResponse.model_validate(reference)


@router.post("/references", response_model=LabTestReferenceResponse, status_code=201)
async def create_lab_reference(
    data: LabTestReferenceCreate,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_doctor_user)
):
    """Create new lab test reference (admin/doctor only)"""
    # Check if code already exists
    existing = await db.execute(
        select(LabTestReference).where(LabTestReference.test_code == data.test_code)
    )
    if existing.scalar_one_or_none():
        raise HTTPException(
            status_code=400, 
            detail=f"Lab test with code '{data.test_code}' already exists"
        )
    
    reference = LabTestReference(**data.model_dump())
    db.add(reference)
    await db.commit()
    await db.refresh(reference)
    
    logger.info(f"Created lab reference: {data.test_code}", extra={"user_id": current_user.id})
    
    return LabTestReferenceResponse.model_validate(reference)


# ============== Patient Lab Results ==============

@router.get("/results", response_model=PatientLabResultList)
async def list_patient_lab_results(
    patient_id: int = Query(..., description="Patient ID"),
    category: Optional[LabTestCategory] = Query(None, description="Filter by test category"),
    test_code: Optional[str] = Query(None, description="Filter by test code"),
    date_from: Optional[datetime] = Query(None, description="From date"),
    date_to: Optional[datetime] = Query(None, description="To date"),
    status: Optional[str] = Query(None, description="Filter by status: normal, low, high, critical"),
    critical_only: bool = Query(False, description="Show only critical results"),
    limit: int = Query(100, ge=1, le=500),
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_active_user)
):
    """
    List laboratory results for a patient.
    
    Supports filtering by category, date range, and result status.
    """
    # Build query
    query = select(PatientLabResult).where(
        PatientLabResult.patient_id == patient_id
    ).order_by(PatientLabResult.tested_at.desc())
    
    # Join with reference for filtering
    if category or test_code or status or critical_only:
        query = query.join(LabTestReference)
    
    if category:
        query = query.where(LabTestReference.category == category)
    
    if test_code:
        query = query.where(LabTestReference.test_code == test_code.upper())
    
    if date_from:
        query = query.where(PatientLabResult.tested_at >= date_from)
    
    if date_to:
        query = query.where(PatientLabResult.tested_at <= date_to)
    
    query = query.limit(limit)
    
    result = await db.execute(query)
    lab_results = result.scalars().all()
    
    # Filter by status if requested
    if status or critical_only:
        filtered_results = []
        for lr in lab_results:
            result_status = lr.get_status()
            if critical_only and lr.is_critical():
                filtered_results.append(lr)
            elif status and result_status == status:
                filtered_results.append(lr)
            elif not status and not critical_only:
                filtered_results.append(lr)
        lab_results = filtered_results
    
    return PatientLabResultList(
        items=[PatientLabResultResponse.model_validate(r) for r in lab_results],
        total=len(lab_results)
    )


@router.post("/results", response_model=PatientLabResultResponse, status_code=201)
async def create_lab_result(
    data: PatientLabResultCreate,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_doctor_user)
):
    """Add a single lab result for a patient"""
    # Verify patient exists
    patient = await db.execute(
        select(Patient).where(Patient.id == data.patient_id)
    )
    if not patient.scalar_one_or_none():
        raise HTTPException(status_code=404, detail="Patient not found")
    
    # Verify test reference exists
    ref = await db.execute(
        select(LabTestReference).where(LabTestReference.id == data.test_reference_id)
    )
    test_ref = ref.scalar_one_or_none()
    if not test_ref:
        raise HTTPException(status_code=404, detail="Lab test reference not found")
    
    # Create result
    result = PatientLabResult(
        patient_id=data.patient_id,
        test_reference_id=data.test_reference_id,
        value=data.value,
        value_text=data.value_text,
        unit=data.unit if data.unit else test_ref.ref_unit,
        tested_at=data.tested_at,
        result_at=data.result_at or datetime.utcnow(),
        lab_name=data.lab_name,
        notes=data.notes,
        created_by_id=current_user.id
    )
    
    db.add(result)
    await db.commit()
    await db.refresh(result)
    
    # Log critical values
    if result.is_critical():
        logger.warning(
            f"Critical lab value recorded: {test_ref.test_code}={data.value} "
            f"for patient {data.patient_id}",
            extra={"patient_id": data.patient_id, "test_code": test_ref.test_code, "value": data.value}
        )
    
    return PatientLabResultResponse.model_validate(result)


@router.post("/results/bulk", response_model=List[PatientLabResultResponse], status_code=201)
async def create_bulk_lab_results(
    data: BulkLabResultCreate,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_doctor_user)
):
    """Add multiple lab results at once (e.g., from a lab panel)"""
    # Verify patient exists
    patient = await db.execute(
        select(Patient).where(Patient.id == data.patient_id)
    )
    if not patient.scalar_one_or_none():
        raise HTTPException(status_code=404, detail="Patient not found")
    
    created_results = []
    
    for result_data in data.results:
        # Get test reference for unit
        ref = await db.execute(
            select(LabTestReference).where(
                LabTestReference.id == result_data.test_reference_id
            )
        )
        test_ref = ref.scalar_one_or_none()
        
        result = PatientLabResult(
            patient_id=data.patient_id,
            test_reference_id=result_data.test_reference_id,
            value=result_data.value,
            value_text=result_data.value_text,
            unit=result_data.unit if result_data.unit else (test_ref.ref_unit if test_ref else ""),
            tested_at=data.tested_at,
            result_at=datetime.utcnow(),
            lab_name=data.lab_name,
            notes=result_data.notes,
            created_by_id=current_user.id
        )
        
        db.add(result)
        created_results.append(result)
    
    await db.commit()
    
    # Refresh all results
    for result in created_results:
        await db.refresh(result)
    
    logger.info(
        f"Created {len(created_results)} lab results for patient {data.patient_id}",
        extra={"user_id": current_user.id, "patient_id": data.patient_id, "count": len(created_results)}
    )
    
    return [PatientLabResultResponse.model_validate(r) for r in created_results]


@router.get("/results/{result_id}", response_model=PatientLabResultResponse)
async def get_lab_result(
    result_id: int,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_active_user)
):
    """Get single lab result by ID"""
    result = await db.execute(
        select(PatientLabResult).where(PatientLabResult.id == result_id)
    )
    lab_result = result.scalar_one_or_none()
    
    if not lab_result:
        raise HTTPException(status_code=404, detail="Lab result not found")
    
    return PatientLabResultResponse.model_validate(lab_result)


@router.delete("/results/{result_id}", status_code=204)
async def delete_lab_result(
    result_id: int,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_doctor_user)
):
    """Delete a lab result"""
    result = await db.execute(
        select(PatientLabResult).where(PatientLabResult.id == result_id)
    )
    lab_result = result.scalar_one_or_none()
    
    if not lab_result:
        raise HTTPException(status_code=404, detail="Lab result not found")
    
    await db.delete(lab_result)
    await db.commit()
    
    logger.info(f"Deleted lab result {result_id}", extra={"user_id": current_user.id})


# ============== Lab Trends ==============

@router.get("/trends/{patient_id}/{test_code}", response_model=LabTrendResponse)
async def get_lab_trend(
    patient_id: int,
    test_code: str,
    months: int = Query(12, ge=1, le=60, description="Number of months to look back"),
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_active_user)
):
    """
    Get trend of a specific lab value over time.
    
    Useful for tracking changes in INR, creatinine, HbA1c, etc.
    """
    # Get test reference
    ref_result = await db.execute(
        select(LabTestReference).where(LabTestReference.test_code == test_code.upper())
    )
    test_ref = ref_result.scalar_one_or_none()
    
    if not test_ref:
        raise HTTPException(status_code=404, detail=f"Test code '{test_code}' not found")
    
    # Get results
    from_date = datetime.utcnow() - timedelta(days=30*months)
    
    results = await db.execute(
        select(PatientLabResult)
        .join(LabTestReference)
        .where(
            PatientLabResult.patient_id == patient_id,
            LabTestReference.test_code == test_code.upper(),
            PatientLabResult.tested_at >= from_date
        )
        .order_by(PatientLabResult.tested_at.asc())
    )
    
    lab_results = results.scalars().all()
    
    trend_data = [
        LabTrendPoint(
            date=lr.tested_at,
            value=lr.value,
            status=lr.get_status()
        )
        for lr in lab_results
    ]
    
    return LabTrendResponse(
        test_reference_id=test_ref.id,
        test_name=test_ref.test_name,
        test_name_ru=test_ref.test_name_ru,
        unit=test_ref.ref_unit,
        ref_min=test_ref.ref_min,
        ref_max=test_ref.ref_max,
        data=trend_data
    )


# ============== Lab Analysis ==============

@router.get("/analysis/{patient_id}", response_model=LabResultAnalysis)
async def analyze_lab_results(
    patient_id: int,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_active_user)
):
    """
    AI analysis of patient's lab results.
    
    Returns summary, abnormal values, and clinical recommendations.
    """
    # Get recent results (last 30 days)
    from_date = datetime.utcnow() - timedelta(days=30)
    
    results = await db.execute(
        select(PatientLabResult)
        .where(
            PatientLabResult.patient_id == patient_id,
            PatientLabResult.tested_at >= from_date
        )
        .order_by(PatientLabResult.tested_at.desc())
    )
    
    lab_results = results.scalars().all()
    
    if not lab_results:
        return LabResultAnalysis(
            patient_id=patient_id,
            summary="Нет данных за последние 30 дней",
            abnormal_results=[],
            critical_results=[],
            recommendations=["Рекомендуется выполнить лабораторное обследование"]
        )
    
    # Analyze results
    abnormal = []
    critical = []
    
    for lr in lab_results:
        result_dict = {
            "test_code": lr.test_reference.test_code if lr.test_reference else "Unknown",
            "test_name": lr.test_reference.test_name if lr.test_reference else "Unknown",
            "value": lr.value,
            "unit": lr.unit,
            "status": lr.get_status(),
            "date": lr.tested_at.isoformat()
        }
        
        if lr.is_critical():
            critical.append(result_dict)
        elif lr.get_status() in ["low", "high"]:
            abnormal.append(result_dict)
    
    # Generate summary
    summary_parts = []
    if critical:
        summary_parts.append(f"Обнаружено {len(critical)} критически важных значений")
    if abnormal:
        summary_parts.append(f"{len(abnormal)} отклонений от нормы")
    
    if not summary_parts:
        summary = "Все показатели в пределах нормы"
    else:
        summary = ". ".join(summary_parts)
    
    # Generate recommendations
    recommendations = []
    additional_tests = []
    surgical_risk = None
    
    # Check for specific conditions
    inr_results = [lr for lr in lab_results if lr.test_reference and lr.test_reference.test_code == "INR"]
    if inr_results:
        latest_inr = inr_results[0]
        if latest_inr.value > 3.0:
            recommendations.append("INR повышен: коррекция перед операцией")
            surgical_risk = "Высокий риск кровотечения (INR > 3.0)"
        elif latest_inr.value < 1.5:
            recommendations.append("INR снижен: возможен риск тромбоза")
    
    creatinine_results = [lr for lr in lab_results if lr.test_reference and lr.test_reference.test_code == "CREATININE"]
    if creatinine_results:
        latest_cr = creatinine_results[0]
        if latest_cr.value > 133:  # μmol/L
            recommendations.append("Повышен креатинин: требуется консультация нефролога")
            additional_tests.append("Скорость клубочковой фильтрации (eGFR)")
            if not surgical_risk:
                surgical_risk = "Повышенный риск ППН (почечная недостаточность)"
    
    hemoglobin_results = [lr for lr in lab_results if lr.test_reference and lr.test_reference.test_code == "HGB"]
    if hemoglobin_results:
        latest_hgb = hemoglobin_results[0]
        if latest_hgb.value < 100:  # g/L
            recommendations.append("Анемия: рассмотреть трансфузию перед операцией")
            additional_tests.append("Ферритин, сывороточное железо")
    
    glucose_results = [lr for lr in lab_results if lr.test_reference and lr.test_reference.test_code == "GLUCOSE"]
    if glucose_results:
        latest_glucose = glucose_results[0]
        if latest_glucose.value > 11.1:  # mmol/L
            recommendations.append("Гипергликемия: коррекция перед операцией")
    
    if not recommendations:
        recommendations.append("Специфических рекомендаций не требуется")
    
    return LabResultAnalysis(
        patient_id=patient_id,
        summary=summary,
        abnormal_results=abnormal,
        critical_results=critical,
        surgical_risk_assessment=surgical_risk,
        recommendations=recommendations,
        additional_tests_needed=additional_tests
    )


# ============== Predefined Panels ==============

@router.get("/panels/preoperative")
async def get_preoperative_panel(
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_active_user)
):
    """Get recommended preoperative lab panel for vascular surgery"""
    # Standard preoperative tests for vascular surgery
    test_codes = [
        "CBC", "HGB", "WBC", "PLT",  # Общий анализ крови
        "PT", "INR", "APTT", "FIBRINOGEN",  # Коагулограмма
        "GLUCOSE", "HbA1c",  # Глюкоза
        "CREATININE", "UREA",  # Почки
        "ALT", "AST", "BILIRUBIN_TOTAL",  # Печень
        "SODIUM", "POTASSIUM", "CHLORIDE",  # Электролиты
        "CRP",  # Воспаление
    ]
    
    results = await db.execute(
        select(LabTestReference).where(
            LabTestReference.test_code.in_(test_codes)
        )
    )
    
    tests = results.scalars().all()
    
    return {
        "name": "Preoperative Vascular Surgery Panel",
        "name_ru": "Предоперационный скрининг (сосудистая хирургия)",
        "description": "Standard laboratory tests before vascular surgery",
        "tests": [LabTestReferenceResponse.model_validate(t) for t in tests],
        "total_tests": len(tests)
    }


@router.get("/panels/coagulation")
async def get_coagulation_panel(
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_active_user)
):
    """Get coagulation panel for anticoagulation monitoring"""
    test_codes = ["PT", "INR", "APTT", "FIBRINOGEN", "D_DIMER", "PLT"]
    
    results = await db.execute(
        select(LabTestReference).where(
            LabTestReference.test_code.in_(test_codes)
        )
    )
    
    tests = results.scalars().all()
    
    return {
        "name": "Coagulation Panel",
        "name_ru": "Коагулограмма",
        "description": "Tests for bleeding and clotting disorders",
        "tests": [LabTestReferenceResponse.model_validate(t) for t in tests],
        "total_tests": len(tests)
    }


@router.get("/panels/lipid")
async def get_lipid_panel(
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_active_user)
):
    """Get lipid panel for atherosclerosis assessment"""
    test_codes = ["CHOLESTEROL", "LDL", "HDL", "TRIGLYCERIDES", "NON_HDL"]
    
    results = await db.execute(
        select(LabTestReference).where(
            LabTestReference.test_code.in_(test_codes)
        )
    )
    
    tests = results.scalars().all()
    
    return {
        "name": "Lipid Panel",
        "name_ru": "Липидный профиль",
        "description": "Cardiovascular risk assessment",
        "tests": [LabTestReferenceResponse.model_validate(t) for t in tests],
        "total_tests": len(tests)
    }
