"""
Studies API Endpoints
CRUD operations for medical studies with pagination
"""
from typing import List, Optional
from datetime import date
from fastapi import APIRouter, Depends, HTTPException, Query, status
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, func, and_, or_
from sqlalchemy.orm import selectinload

from app.db.session import get_db
from app.core.security import get_current_active_user
from app.models.user import User
from app.models.study import Study, StudyStatus
from app.schemas.study import StudyCreate, StudyUpdate, StudyResponse, StudyListResponse

router = APIRouter()


@router.get("", response_model=StudyListResponse)
async def list_studies(
    page: int = Query(1, ge=1, description="Page number"),
    page_size: int = Query(20, ge=1, le=100, description="Items per page"),
    patient_id: Optional[str] = Query(None, description="Filter by patient ID"),
    modality: Optional[str] = Query(None, description="Filter by modality (CT, MR, etc.)"),
    status: Optional[StudyStatus] = Query(None, description="Filter by status"),
    date_from: Optional[date] = Query(None, description="Filter from date (YYYY-MM-DD)"),
    date_to: Optional[date] = Query(None, description="Filter to date (YYYY-MM-DD)"),
    search: Optional[str] = Query(None, description="Search in description"),
    sort_by: str = Query("study_date", description="Sort field"),
    sort_order: str = Query("desc", description="Sort order: asc or desc"),
    include_deleted: bool = Query(False, description="Include soft-deleted studies"),
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_active_user)
):
    """
    List studies with pagination and filtering.
    
    - **page**: Page number (1-indexed)
    - **page_size**: Number of items per page (max 100)
    - **patient_id**: Filter by patient
    - **modality**: Filter by imaging modality
    - **status**: Filter by processing status
    - **date_from/date_to**: Date range filter
    - **search**: Search in study description
    """
    # Build base query
    query = select(Study)
    
    # Exclude soft-deleted by default
    if not include_deleted:
        query = query.where(Study.deleted_at.is_(None))
    
    # Apply filters
    filters = []
    
    if patient_id:
        filters.append(Study.patient_id == patient_id)
    
    if modality:
        filters.append(Study.modality == modality)
    
    if status:
        filters.append(Study.status == status)
    
    if date_from:
        filters.append(Study.study_date >= date_from)
    
    if date_to:
        filters.append(Study.study_date <= date_to)
    
    if search:
        filters.append(Study.description.ilike(f"%{search}%"))
    
    if filters:
        query = query.where(and_(*filters))
    
    # Get total count
    count_query = select(func.count(Study.id))
    if not include_deleted:
        count_query = count_query.where(Study.deleted_at.is_(None))
    if filters:
        count_query = count_query.where(and_(*filters))
    
    total_result = await db.execute(count_query)
    total = total_result.scalar()
    
    # Apply sorting
    sort_field = getattr(Study, sort_by, Study.study_date)
    if sort_order.lower() == "desc":
        query = query.order_by(sort_field.desc())
    else:
        query = query.order_by(sort_field.asc())
    
    # Apply pagination
    offset = (page - 1) * page_size
    query = query.offset(offset).limit(page_size)
    
    # Load related data
    query = query.options(selectinload(Study.patient))
    
    # Execute query
    result = await db.execute(query)
    studies = result.scalars().all()
    
    # Calculate pagination info
    total_pages = (total + page_size - 1) // page_size
    
    return StudyListResponse(
        items=studies,
        total=total,
        page=page,
        page_size=page_size,
        total_pages=total_pages,
        has_next=page < total_pages,
        has_prev=page > 1
    )


@router.post("", response_model=StudyResponse, status_code=status.HTTP_201_CREATED)
async def create_study(
    study_data: StudyCreate,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_active_user)
):
    """Create a new study"""
    # Verify patient exists
    from app.models.patient import Patient
    patient_result = await db.execute(
        select(Patient).where(
            and_(
                Patient.id == study_data.patient_id,
                Patient.deleted_at.is_(None)
            )
        )
    )
    if not patient_result.scalar_one_or_none():
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Patient not found"
        )
    
    study = Study(
        **study_data.model_dump(),
        created_by_id=current_user.id,
        status=StudyStatus.PENDING
    )
    
    db.add(study)
    await db.commit()
    await db.refresh(study)
    
    return study


@router.get("/{study_id}", response_model=StudyResponse)
async def get_study(
    study_id: str,
    include_deleted: bool = False,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_active_user)
):
    """Get study by ID with full details"""
    query = select(Study).where(Study.id == study_id)
    
    if not include_deleted:
        query = query.where(Study.deleted_at.is_(None))
    
    # Load related data
    query = query.options(
        selectinload(Study.patient),
        selectinload(Study.findings),
        selectinload(Study.measurements)
    )
    
    result = await db.execute(query)
    study = result.scalar_one_or_none()
    
    if not study:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Study not found"
        )
    
    return study


@router.put("/{study_id}", response_model=StudyResponse)
async def update_study(
    study_id: str,
    study_data: StudyUpdate,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_active_user)
):
    """Update study information"""
    result = await db.execute(
        select(Study).where(
            and_(
                Study.id == study_id,
                Study.deleted_at.is_(None)
            )
        )
    )
    study = result.scalar_one_or_none()
    
    if not study:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Study not found"
        )
    
    # Update fields
    update_data = study_data.model_dump(exclude_unset=True)
    for field, value in update_data.items():
        setattr(study, field, value)
    
    study.updated_by_id = current_user.id
    
    await db.commit()
    await db.refresh(study)
    
    return study


@router.delete("/{study_id}", status_code=status.HTTP_204_NO_CONTENT)
async def delete_study(
    study_id: str,
    hard_delete: bool = Query(False, description="Permanently delete study"),
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_active_user)
):
    """
    Delete study (soft delete by default).
    
    - **hard_delete**: If true, permanently deletes the study and all associated data
    """
    result = await db.execute(
        select(Study).where(
            and_(
                Study.id == study_id,
                Study.deleted_at.is_(None)
            )
        )
    )
    study = result.scalar_one_or_none()
    
    if not study:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Study not found"
        )
    
    if hard_delete:
        # Permanent deletion - requires admin role
        if current_user.role != "admin":
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail="Only administrators can permanently delete studies"
            )
        await db.delete(study)
    else:
        # Soft delete
        from datetime import datetime
        study.deleted_at = datetime.utcnow()
        study.updated_by_id = current_user.id
    
    await db.commit()
    
    return None


@router.post("/{study_id}/restore", response_model=StudyResponse)
async def restore_study(
    study_id: str,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_active_user)
):
    """Restore a soft-deleted study"""
    result = await db.execute(
        select(Study).where(Study.id == study_id)
    )
    study = result.scalar_one_or_none()
    
    if not study:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Study not found"
        )
    
    if study.deleted_at is None:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Study is not deleted"
        )
    
    study.deleted_at = None
    study.updated_by_id = current_user.id
    
    await db.commit()
    await db.refresh(study)
    
    return study


@router.get("/{study_id}/findings")
async def get_study_findings(
    study_id: str,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_active_user)
):
    """Get all findings for a study"""
    from app.models.study import StudyFinding
    
    # Verify study exists
    study_result = await db.execute(
        select(Study).where(
            and_(
                Study.id == study_id,
                Study.deleted_at.is_(None)
            )
        )
    )
    if not study_result.scalar_one_or_none():
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Study not found"
        )
    
    # Get findings
    result = await db.execute(
        select(StudyFinding)
        .where(StudyFinding.study_id == study_id)
        .order_by(StudyFinding.severity.desc())
    )
    findings = result.scalars().all()
    
    return {"findings": findings, "count": len(findings)}


@router.get("/{study_id}/measurements")
async def get_study_measurements(
    study_id: str,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_active_user)
):
    """Get all measurements for a study"""
    from app.models.study import StudyMeasurement
    
    # Verify study exists
    study_result = await db.execute(
        select(Study).where(
            and_(
                Study.id == study_id,
                Study.deleted_at.is_(None)
            )
        )
    )
    if not study_result.scalar_one_or_none():
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Study not found"
        )
    
    # Get measurements
    result = await db.execute(
        select(StudyMeasurement)
        .where(StudyMeasurement.study_id == study_id)
    )
    measurements = result.scalars().all()
    
    return {"measurements": measurements, "count": len(measurements)}
