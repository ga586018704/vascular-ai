"""
Integration API Endpoints
FHIR, HL7, PACS integration endpoints
"""
from fastapi import APIRouter, Depends, HTTPException, status, BackgroundTasks
from typing import List, Dict, Optional, Any
from pydantic import BaseModel
import logging

from app.core.security import get_current_user
from app.models.user import User
from app.services.fhir_service import (
    FHIRService, FHIRConfig, create_fhir_service_from_config,
    HL7Service
)
from app.services.pacs_service import (
    PACSService, PACSConfig, DICOMQuery
)

logger = logging.getLogger(__name__)

router = APIRouter()


# === FHIR INTEGRATION ===

class FHIRConfigRequest(BaseModel):
    base_url: str
    auth_type: str = "oauth2"
    client_id: Optional[str] = None
    client_secret: Optional[str] = None
    access_token: Optional[str] = None


class FHIRPatientRequest(BaseModel):
    mrn: str
    first_name: str
    last_name: str
    date_of_birth: str
    gender: str
    phone: Optional[str] = None
    email: Optional[str] = None
    address: Optional[str] = None


class FHIRObservationRequest(BaseModel):
    patient_id: str
    observation_type: str
    value: float
    unit: str
    code: str
    body_site: Optional[str] = None


@router.post("/fhir/test-connection")
async def test_fhir_connection(
    config: FHIRConfigRequest,
    current_user: User = Depends(get_current_user),
):
    """Test FHIR server connection"""
    try:
        fhir_config = FHIRConfig(
            base_url=config.base_url,
            auth_type=config.auth_type,
            client_id=config.client_id,
            client_secret=config.client_secret,
            access_token=config.access_token
        )
        
        service = FHIRService(fhir_config)
        
        # Try to get server metadata
        import requests
        response = requests.get(
            f"{config.base_url}/metadata",
            headers={"Accept": "application/fhir+json"}
        )
        
        if response.status_code == 200:
            metadata = response.json()
            return {
                "success": True,
                "fhir_version": metadata.get("fhirVersion", "Unknown"),
                "software": metadata.get("software", {}),
                "resources": [r.get("type") for r in metadata.get("rest", [{}])[0].get("resource", [])]
            }
        else:
            return {
                "success": False,
                "error": f"Server returned status {response.status_code}"
            }
            
    except Exception as e:
        return {
            "success": False,
            "error": str(e)
        }


@router.post("/fhir/patients")
async def create_fhir_patient(
    config: FHIRConfigRequest,
    patient: FHIRPatientRequest,
    current_user: User = Depends(get_current_user),
):
    """Create patient in FHIR server"""
    try:
        service = create_fhir_service_from_config(config.dict())
        result = service.create_patient(patient.dict())
        return {
            "success": True,
            "patient_id": result.get("id"),
            "resource": result
        }
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"FHIR operation failed: {str(e)}"
        )


@router.get("/fhir/patients/{patient_id}")
async def get_fhir_patient(
    config: FHIRConfigRequest,
    patient_id: str,
    current_user: User = Depends(get_current_user),
):
    """Get patient from FHIR server"""
    try:
        service = create_fhir_service_from_config(config.dict())
        patient = service.get_patient(patient_id)
        return patient
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"FHIR operation failed: {str(e)}"
        )


@router.post("/fhir/observations")
async def create_fhir_observation(
    config: FHIRConfigRequest,
    observation: FHIRObservationRequest,
    current_user: User = Depends(get_current_user),
):
    """Create observation in FHIR server"""
    try:
        service = create_fhir_service_from_config(config.dict())
        
        # Create vascular measurement observation
        measurement = {
            "vessel_name": observation.body_site or "Unknown",
            "diameter_mm": observation.value
        }
        
        result = service.create_vascular_measurement(
            observation.patient_id,
            "",  # study_id
            measurement
        )
        
        return {
            "success": True,
            "observation_id": result.get("id"),
            "resource": result
        }
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"FHIR operation failed: {str(e)}"
        )


# === HL7 INTEGRATION ===

class HL7MessageRequest(BaseModel):
    message_type: str
    patient_data: Dict[str, Any]
    observations: Optional[List[Dict]] = None


@router.post("/hl7/create-oru")
async def create_hl7_oru(
    request: HL7MessageRequest,
    current_user: User = Depends(get_current_user),
):
    """Create HL7 ORU (Observation Result) message"""
    try:
        service = HL7Service()
        message = service.create_oru_message(
            request.patient_data,
            request.observations or []
        )
        return {
            "success": True,
            "message": message,
            "message_type": "ORU^R01"
        }
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"HL7 creation failed: {str(e)}"
        )


@router.post("/hl7/parse")
async def parse_hl7_message(
    message: str,
    current_user: User = Depends(get_current_user),
):
    """Parse HL7 message"""
    try:
        service = HL7Service()
        parsed = service.parse_message(message)
        return {
            "success": True,
            "parsed": parsed
        }
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"HL7 parsing failed: {str(e)}"
        )


# === PACS INTEGRATION ===

class PACSConfigRequest(BaseModel):
    host: str
    port: int = 11112
    ae_title: str = "VASCULAR_AI"
    called_ae_title: str = "PACS"
    wado_url: Optional[str] = None
    wado_auth_token: Optional[str] = None


class PACSQueryRequest(BaseModel):
    patient_id: Optional[str] = None
    patient_name: Optional[str] = None
    study_date_from: Optional[str] = None
    study_date_to: Optional[str] = None
    study_instance_uid: Optional[str] = None
    accession_number: Optional[str] = None
    modality: Optional[str] = "CT"


@router.post("/pacs/test-connection")
async def test_pacs_connection(
    config: PACSConfigRequest,
    current_user: User = Depends(get_current_user),
):
    """Test PACS server connection using C-ECHO"""
    try:
        pacs_config = PACSConfig(
            host=config.host,
            port=config.port,
            ae_title=config.ae_title,
            called_ae_title=config.called_ae_title,
            wado_url=config.wado_url,
            wado_auth_token=config.wado_auth_token
        )
        
        service = PACSService(pacs_config)
        is_connected = await service.verify_connection()
        
        return {
            "success": is_connected,
            "message": "C-ECHO successful" if is_connected else "C-ECHO failed"
        }
    except Exception as e:
        return {
            "success": False,
            "error": str(e)
        }


@router.post("/pacs/search-patients")
async def search_pacs_patients(
    config: PACSConfigRequest,
    query: PACSQueryRequest,
    current_user: User = Depends(get_current_user),
):
    """Search patients in PACS using C-FIND"""
    try:
        pacs_config = PACSConfig(
            host=config.host,
            port=config.port,
            ae_title=config.ae_title,
            called_ae_title=config.called_ae_title
        )
        
        service = PACSService(pacs_config)
        
        dicom_query = DICOMQuery(
            patient_id=query.patient_id,
            patient_name=query.patient_name
        )
        
        patients = await service.find_patients(dicom_query)
        
        return {
            "success": True,
            "count": len(patients),
            "patients": patients
        }
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"PACS query failed: {str(e)}"
        )


@router.post("/pacs/search-studies")
async def search_pacs_studies(
    config: PACSConfigRequest,
    query: PACSQueryRequest,
    current_user: User = Depends(get_current_user),
):
    """Search studies in PACS using C-FIND"""
    try:
        pacs_config = PACSConfig(
            host=config.host,
            port=config.port,
            ae_title=config.ae_title,
            called_ae_title=config.called_ae_title
        )
        
        service = PACSService(pacs_config)
        
        dicom_query = DICOMQuery(
            patient_id=query.patient_id,
            study_instance_uid=query.study_instance_uid,
            accession_number=query.accession_number,
            study_date_from=query.study_date_from,
            study_date_to=query.study_date_to,
            modality=query.modality
        )
        
        studies = await service.find_studies(dicom_query)
        
        return {
            "success": True,
            "count": len(studies),
            "studies": studies
        }
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"PACS query failed: {str(e)}"
        )


@router.post("/pacs/retrieve-study")
async def retrieve_pacs_study(
    config: PACSConfigRequest,
    study_uid: str,
    output_dir: str = "/tmp/dicom",
    background_tasks: BackgroundTasks = None,
    current_user: User = Depends(get_current_user),
):
    """Retrieve study from PACS using C-GET or WADO-RS"""
    try:
        pacs_config = PACSConfig(
            host=config.host,
            port=config.port,
            ae_title=config.ae_title,
            called_ae_title=config.called_ae_title,
            wado_url=config.wado_url,
            wado_auth_token=config.wado_auth_token
        )
        
        service = PACSService(pacs_config)
        
        # Get study metadata first
        series_list = await service.find_series(study_uid)
        
        # Retrieve study
        if config.wado_url:
            file_paths = await service.wado_retrieve_study(study_uid, output_dir)
        else:
            instances = await service.get_study(study_uid)
            file_paths = []
            import os
            os.makedirs(output_dir, exist_ok=True)
            for i, instance in enumerate(instances):
                filepath = f"{output_dir}/instance_{i}.dcm"
                instance.save_as(filepath)
                file_paths.append(filepath)
        
        return {
            "success": True,
            "study_uid": study_uid,
            "series_count": len(series_list),
            "files_retrieved": len(file_paths),
            "file_paths": file_paths
        }
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"PACS retrieve failed: {str(e)}"
        )


@router.post("/pacs/move-study")
async def move_pacs_study(
    config: PACSConfigRequest,
    study_uid: str,
    destination_ae: str,
    current_user: User = Depends(get_current_user),
):
    """Move study to destination AE using C-MOVE"""
    try:
        pacs_config = PACSConfig(
            host=config.host,
            port=config.port,
            ae_title=config.ae_title,
            called_ae_title=config.called_ae_title
        )
        
        service = PACSService(pacs_config)
        result = await service.move_study(study_uid, destination_ae)
        
        return result
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"PACS move failed: {str(e)}"
        )


@router.post("/pacs/qido-search")
async def qido_search_studies(
    config: PACSConfigRequest,
    query_params: Dict[str, str],
    current_user: User = Depends(get_current_user),
):
    """Search studies using QIDO-RS (DICOMweb)"""
    try:
        if not config.wado_url:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="WADO URL not configured"
            )
        
        pacs_config = PACSConfig(
            host=config.host,
            port=config.port,
            ae_title=config.ae_title,
            called_ae_title=config.called_ae_title,
            wado_url=config.wado_url,
            wado_auth_token=config.wado_auth_token
        )
        
        service = PACSService(pacs_config)
        results = await service.qido_search_studies(query_params)
        
        return {
            "success": True,
            "count": len(results),
            "results": results
        }
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"QIDO search failed: {str(e)}"
        )


# === INTEGRATION STATUS ===

@router.get("/status")
async def get_integration_status(
    current_user: User = Depends(get_current_user),
):
    """Get integration module status"""
    return {
        "fhir": {
            "supported_versions": ["R4"],
            "supported_resources": [
                "Patient", "Observation", "ImagingStudy",
                "DiagnosticReport", "DocumentReference"
            ],
            "auth_methods": ["OAuth2", "Bearer", "Basic"]
        },
        "hl7": {
            "supported_versions": ["v2.x"],
            "supported_messages": ["ADT", "ORU", "ORM", "MDM"]
        },
        "pacs": {
            "supported_protocols": [
                "DICOM DIMSE (C-FIND, C-MOVE, C-GET)",
                "DICOMweb (WADO-RS, QIDO-RS, STOW-RS)"
            ],
            "transfer_syntaxes": [
                "Implicit VR Little Endian",
                "Explicit VR Little Endian",
                "JPEG Baseline"
            ]
        }
    }
