"""
Reports API
"""
from datetime import datetime
from typing import List, Optional
from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select

from app.db.session import get_db
from app.core.security import get_current_active_user
from app.models.user import User
from app.models.report import Report, ReportStatus, ReportType
from app.models.patient import Patient
from app.models.study import Study

router = APIRouter()


# Schemas
class ReportCreate(BaseModel):
    title: str
    report_type: ReportType = ReportType.ANGIOGRAPHY
    content: str
    findings: Optional[str] = None
    impression: Optional[str] = None
    recommendations: Optional[str] = None
    patient_id: int
    study_id: Optional[int] = None


class ReportUpdate(BaseModel):
    title: Optional[str] = None
    content: Optional[str] = None
    findings: Optional[str] = None
    impression: Optional[str] = None
    recommendations: Optional[str] = None
    status: Optional[ReportStatus] = None


class ReportResponse(BaseModel):
    id: int
    report_id: str
    report_type: str
    title: str
    status: str
    patient_name: Optional[str]
    author_name: Optional[str]
    created_at: str


class ReportDetailResponse(BaseModel):
    id: int
    report_id: str
    report_type: str
    title: str
    content: str
    findings: Optional[str]
    impression: Optional[str]
    recommendations: Optional[str]
    status: str
    patient: dict
    author: dict
    created_at: str
    updated_at: str


# Routes
@router.post("/", response_model=ReportResponse, status_code=201)
async def create_report(
    report_data: ReportCreate,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_active_user)
):
    """Create a new report"""
    # Verify patient exists
    result = await db.execute(select(Patient).where(Patient.id == report_data.patient_id))
    patient = result.scalar_one_or_none()
    if not patient:
        raise HTTPException(status_code=404, detail="Patient not found")
    
    # Verify study exists if provided
    if report_data.study_id:
        result = await db.execute(select(Study).where(Study.id == report_data.study_id))
        study = result.scalar_one_or_none()
        if not study:
            raise HTTPException(status_code=404, detail="Study not found")
    
    # Generate report ID
    report_id = f"RPT-{datetime.utcnow().strftime('%Y%m%d')}-{datetime.utcnow().timestamp():.0f}"
    
    new_report = Report(
        report_id=report_id,
        report_type=report_data.report_type,
        title=report_data.title,
        content=report_data.content,
        findings=report_data.findings,
        impression=report_data.impression,
        recommendations=report_data.recommendations,
        status=ReportStatus.DRAFT,
        patient_id=report_data.patient_id,
        study_id=report_data.study_id,
        author_id=current_user.id,
    )
    
    db.add(new_report)
    await db.commit()
    await db.refresh(new_report)
    
    return ReportResponse(
        id=new_report.id,
        report_id=new_report.report_id,
        report_type=new_report.report_type.value,
        title=new_report.title,
        status=new_report.status.value,
        patient_name=patient.full_name,
        author_name=current_user.full_name,
        created_at=new_report.created_at.isoformat(),
    )


@router.get("/", response_model=List[ReportResponse])
async def list_reports(
    skip: int = 0,
    limit: int = 20,
    status: Optional[str] = None,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_active_user)
):
    """List reports"""
    query = select(Report).order_by(Report.created_at.desc())
    
    if status:
        query = query.where(Report.status == status)
    
    query = query.offset(skip).limit(limit)
    result = await db.execute(query)
    reports = result.scalars().all()
    
    return [
        ReportResponse(
            id=r.id,
            report_id=r.report_id,
            report_type=r.report_type.value if r.report_type else "Unknown",
            title=r.title,
            status=r.status.value if r.status else "Unknown",
            patient_name=r.patient.full_name if r.patient else None,
            author_name=r.author.full_name if r.author else None,
            created_at=r.created_at.isoformat() if r.created_at else "",
        )
        for r in reports
    ]


@router.get("/{report_id}", response_model=ReportDetailResponse)
async def get_report(
    report_id: str,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_active_user)
):
    """Get report details"""
    result = await db.execute(select(Report).where(Report.report_id == report_id))
    report = result.scalar_one_or_none()
    
    if not report:
        raise HTTPException(status_code=404, detail="Report not found")
    
    return ReportDetailResponse(
        id=report.id,
        report_id=report.report_id,
        report_type=report.report_type.value if report.report_type else "Unknown",
        title=report.title,
        content=report.content,
        findings=report.findings,
        impression=report.impression,
        recommendations=report.recommendations,
        status=report.status.value if report.status else "Unknown",
        patient=report.patient.to_dict() if report.patient else None,
        author=report.author.to_dict() if report.author else None,
        created_at=report.created_at.isoformat() if report.created_at else "",
        updated_at=report.updated_at.isoformat() if report.updated_at else "",
    )


@router.put("/{report_id}", response_model=ReportDetailResponse)
async def update_report(
    report_id: str,
    report_data: ReportUpdate,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_active_user)
):
    """Update a report"""
    result = await db.execute(select(Report).where(Report.report_id == report_id))
    report = result.scalar_one_or_none()
    
    if not report:
        raise HTTPException(status_code=404, detail="Report not found")
    
    # Update fields
    if report_data.title:
        report.title = report_data.title
    if report_data.content:
        report.content = report_data.content
    if report_data.findings:
        report.findings = report_data.findings
    if report_data.impression:
        report.impression = report_data.impression
    if report_data.recommendations:
        report.recommendations = report_data.recommendations
    if report_data.status:
        report.status = report_data.status
        if report_data.status == ReportStatus.FINALIZED:
            report.finalized_at = datetime.utcnow()
    
    await db.commit()
    await db.refresh(report)
    
    return ReportDetailResponse(
        id=report.id,
        report_id=report.report_id,
        report_type=report.report_type.value if report.report_type else "Unknown",
        title=report.title,
        content=report.content,
        findings=report.findings,
        impression=report.impression,
        recommendations=report.recommendations,
        status=report.status.value if report.status else "Unknown",
        patient=report.patient.to_dict() if report.patient else None,
        author=report.author.to_dict() if report.author else None,
        created_at=report.created_at.isoformat() if report.created_at else "",
        updated_at=report.updated_at.isoformat() if report.updated_at else "",
    )


@router.delete("/{report_id}")
async def delete_report(
    report_id: str,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_active_user)
):
    """Delete a report"""
    result = await db.execute(select(Report).where(Report.report_id == report_id))
    report = result.scalar_one_or_none()
    
    if not report:
        raise HTTPException(status_code=404, detail="Report not found")
    
    await db.delete(report)
    await db.commit()
    
    return {"message": "Report deleted successfully"}
