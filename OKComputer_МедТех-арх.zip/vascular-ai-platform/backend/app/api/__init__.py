"""
API Routes
"""
from app.api import auth, dicom, ai_agents, risk_calculators, websocket, reports, analytics, metrics, angiography

__all__ = [
    "auth",
    "dicom",
    "ai_agents",
    "risk_calculators",
    "websocket",
    "reports",
    "analytics",
    "metrics",
    "angiography",
]
