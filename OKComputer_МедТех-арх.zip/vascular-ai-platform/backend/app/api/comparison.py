"""
Study Comparison API Endpoints
Compare CT angiography studies over time to track disease progression
"""
from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, and_
from typing import List, Dict, Any, Optional
from datetime import datetime
import numpy as np

from app.db.session import get_db
from app.core.security import get_current_user
from app.models.user import User
from app.models.patient import Patient
from app.models.study import Study, StudyFinding, StudyMeasurement
from app.schemas.comparison import (
    StudyComparisonRequest,
    StudyComparisonResponse,
    DiameterChange,
    FindingComparison,
    ProgressionSummary,
)

router = APIRouter()


@router.post("/compare", response_model=StudyComparisonResponse)
async def compare_studies(
    request: StudyComparisonRequest,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    """
    Compare two studies for the same patient to track disease progression
    """
    # Fetch both studies
    baseline_result = await db.execute(
        select(Study).where(Study.id == request.baseline_study_id)
    )
    baseline_study = baseline_result.scalar_one_or_none()
    
    followup_result = await db.execute(
        select(Study).where(Study.id == request.followup_study_id)
    )
    followup_study = followup_result.scalar_one_or_none()
    
    if not baseline_study or not followup_study:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="One or both studies not found"
        )
    
    # Verify same patient
    if baseline_study.patient_id != followup_study.patient_id:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Studies must belong to the same patient"
        )
    
    # Calculate interval
    baseline_date = datetime.fromisoformat(baseline_study.study_date)
    followup_date = datetime.fromisoformat(followup_study.study_date)
    interval_days = (followup_date - baseline_date).days
    
    if interval_days <= 0:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Follow-up study must be after baseline study"
        )
    
    # Fetch findings for both studies
    baseline_findings_result = await db.execute(
        select(StudyFinding).where(StudyFinding.study_id == baseline_study.id)
    )
    baseline_findings = baseline_findings_result.scalars().all()
    
    followup_findings_result = await db.execute(
        select(StudyFinding).where(StudyFinding.study_id == followup_study.id)
    )
    followup_findings = followup_findings_result.scalars().all()
    
    # Fetch measurements for both studies
    baseline_measurements_result = await db.execute(
        select(StudyMeasurement).where(StudyMeasurement.study_id == baseline_study.id)
    )
    baseline_measurements = baseline_measurements_result.scalars().all()
    
    followup_measurements_result = await db.execute(
        select(StudyMeasurement).where(StudyMeasurement.study_id == followup_study.id)
    )
    followup_measurements = followup_measurements_result.scalars().all()
    
    # Compare diameter changes
    diameter_changes = compare_measurements(
        baseline_measurements,
        followup_measurements,
        interval_days
    )
    
    # Compare findings
    finding_comparison = compare_findings(
        baseline_findings,
        followup_findings
    )
    
    # Generate progression summary
    progression = analyze_progression(
        diameter_changes,
        finding_comparison,
        interval_days
    )
    
    # Generate recommendations
    recommendations = generate_recommendations(
        diameter_changes,
        finding_comparison,
        progression
    )
    
    return StudyComparisonResponse(
        baseline_study={
            "id": baseline_study.id,
            "patient_id": baseline_study.patient_id,
            "patient_name": f"{baseline_study.patient.last_name}, {baseline_study.patient.first_name}" if baseline_study.patient else "Unknown",
            "study_date": baseline_study.study_date,
            "modality": baseline_study.modality,
            "description": baseline_study.description,
            "findings": [
                {
                    "id": f.id,
                    "type": f.finding_type,
                    "location": f.location,
                    "severity": f.severity,
                    "description": f.description,
                    "vessel_name": f.vessel_name,
                }
                for f in baseline_findings
            ],
            "measurements": [
                {
                    "vessel_name": m.vessel_name,
                    "diameter_mm": m.diameter_mm,
                    "length_mm": m.length_mm or 0,
                    "volume_ml": m.volume_ml or 0,
                }
                for m in baseline_measurements
            ],
            "status": baseline_study.status,
        },
        followup_study={
            "id": followup_study.id,
            "patient_id": followup_study.patient_id,
            "patient_name": f"{followup_study.patient.last_name}, {followup_study.patient.first_name}" if followup_study.patient else "Unknown",
            "study_date": followup_study.study_date,
            "modality": followup_study.modality,
            "description": followup_study.description,
            "findings": [
                {
                    "id": f.id,
                    "type": f.finding_type,
                    "location": f.location,
                    "severity": f.severity,
                    "description": f.description,
                    "vessel_name": f.vessel_name,
                }
                for f in followup_findings
            ],
            "measurements": [
                {
                    "vessel_name": m.vessel_name,
                    "diameter_mm": m.diameter_mm,
                    "length_mm": m.length_mm or 0,
                    "volume_ml": m.volume_ml or 0,
                }
                for m in followup_measurements
            ],
            "status": followup_study.status,
        },
        interval_days=interval_days,
        diameter_changes=diameter_changes,
        new_findings=finding_comparison["new"],
        resolved_findings=finding_comparison["resolved"],
        progressed_findings=finding_comparison["progressed"],
        stable_findings=finding_comparison["stable"],
        progression_summary=progression["summary"],
        progression_risk=progression["risk_level"],
        recommendations=recommendations,
    )


def compare_measurements(
    baseline: List[StudyMeasurement],
    followup: List[StudyMeasurement],
    interval_days: int
) -> List[DiameterChange]:
    """Compare vessel measurements between studies"""
    changes = []
    
    # Create lookup by vessel name
    baseline_by_vessel = {m.vessel_name: m for m in baseline}
    followup_by_vessel = {m.vessel_name: m for m in followup}
    
    # Compare common vessels
    all_vessels = set(baseline_by_vessel.keys()) | set(followup_by_vessel.keys())
    
    for vessel_name in all_vessels:
        baseline_m = baseline_by_vessel.get(vessel_name)
        followup_m = followup_by_vessel.get(vessel_name)
        
        if baseline_m and followup_m:
            baseline_d = baseline_m.diameter_mm
            followup_d = followup_m.diameter_mm
            change_mm = followup_d - baseline_d
            change_percent = (change_mm / baseline_d * 100) if baseline_d > 0 else 0
            
            # Calculate annual growth rate
            years = interval_days / 365.25
            annual_growth = change_mm / years if years > 0 else 0
            
            # Determine significance
            if abs(change_mm) < 2:
                significance = "stable"
            elif change_mm > 5:
                significance = "significant_progression"
            elif change_mm > 2:
                significance = "mild_progression"
            else:
                significance = "regression"
            
            changes.append(DiameterChange(
                vessel_name=vessel_name,
                baseline_diameter=baseline_d,
                followup_diameter=followup_d,
                change_mm=change_mm,
                change_percent=change_percent,
                annual_growth_rate=annual_growth,
                significance=significance,
            ))
    
    return changes


def compare_findings(
    baseline: List[StudyFinding],
    followup: List[StudyFinding]
) -> Dict[str, List[Dict]]:
    """Compare findings between studies"""
    result = {
        "new": [],
        "resolved": [],
        "progressed": [],
        "stable": [],
    }
    
    # Create lookup by finding type and location
    baseline_by_key = {(f.finding_type, f.location): f for f in baseline}
    followup_by_key = {(f.finding_type, f.location): f for f in followup}
    
    # Find new findings
    for key, finding in followup_by_key.items():
        if key not in baseline_by_key:
            result["new"].append({
                "id": finding.id,
                "type": finding.finding_type,
                "location": finding.location,
                "severity": finding.severity,
                "description": finding.description,
                "vessel_name": finding.vessel_name,
            })
    
    # Find resolved findings
    for key, finding in baseline_by_key.items():
        if key not in followup_by_key:
            result["resolved"].append({
                "id": finding.id,
                "type": finding.finding_type,
                "location": finding.location,
                "severity": finding.severity,
                "description": finding.description,
                "vessel_name": finding.vessel_name,
            })
    
    # Find progressed/stable findings
    for key, baseline_f in baseline_by_key.items():
        if key in followup_by_key:
            followup_f = followup_by_key[key]
            severity_order = ["mild", "moderate", "severe", "critical"]
            
            baseline_idx = severity_order.index(baseline_f.severity) if baseline_f.severity in severity_order else -1
            followup_idx = severity_order.index(followup_f.severity) if followup_f.severity in severity_order else -1
            
            if followup_idx > baseline_idx:
                result["progressed"].append({
                    "id": followup_f.id,
                    "type": followup_f.finding_type,
                    "location": followup_f.location,
                    "severity": followup_f.severity,
                    "description": followup_f.description,
                    "vessel_name": followup_f.vessel_name,
                    "previous_severity": baseline_f.severity,
                })
            else:
                result["stable"].append({
                    "id": followup_f.id,
                    "type": followup_f.finding_type,
                    "location": followup_f.location,
                    "severity": followup_f.severity,
                    "description": followup_f.description,
                    "vessel_name": followup_f.vessel_name,
                })
    
    return result


def analyze_progression(
    diameter_changes: List[DiameterChange],
    finding_comparison: Dict,
    interval_days: int
) -> Dict[str, Any]:
    """Analyze overall disease progression"""
    
    # Count significant changes
    significant_progressions = sum(1 for d in diameter_changes if d.significance == "significant_progression")
    mild_progressions = sum(1 for d in diameter_changes if d.significance == "mild_progression")
    new_findings = len(finding_comparison["new"])
    progressed_findings = len(finding_comparison["progressed"])
    
    # Determine risk level
    if significant_progressions > 0 or new_findings > 0:
        risk_level = "high"
        summary = f"Significant disease progression detected with {significant_progressions} vessel(s) showing significant growth and {new_findings} new finding(s)"
    elif mild_progressions > 0 or progressed_findings > 0:
        risk_level = "moderate"
        summary = f"Mild disease progression with {mild_progressions} vessel(s) showing mild growth and {progressed_findings} progressed finding(s)"
    else:
        risk_level = "low"
        summary = "Disease appears stable with no significant changes"
    
    return {
        "summary": summary,
        "risk_level": risk_level,
        "significant_vessel_changes": significant_progressions,
        "mild_vessel_changes": mild_progressions,
        "new_findings": new_findings,
        "progressed_findings": progressed_findings,
    }


def generate_recommendations(
    diameter_changes: List[DiameterChange],
    finding_comparison: Dict,
    progression: Dict[str, Any]
) -> List[str]:
    """Generate clinical recommendations based on comparison"""
    recommendations = []
    
    # Aneurysm recommendations
    aneurysm_changes = [d for d in diameter_changes if "aneurysm" in d.vessel_name.lower()]
    for change in aneurysm_changes:
        if change.significance == "significant_progression":
            if change.followup_diameter >= 55:
                recommendations.append(
                    f"URGENT: {change.vessel_name} aneurysm has grown to {change.followup_diameter:.1f}mm "
                    f"({change.change_mm:+.1f}mm). Consider surgical intervention."
                )
            else:
                recommendations.append(
                    f"{change.vessel_name} aneurysm shows significant growth ({change.change_mm:+.1f}mm). "
                    f"Shorten follow-up interval to 3-6 months."
                )
        elif change.significance == "mild_progression":
            recommendations.append(
                f"{change.vessel_name} aneurysm shows mild growth. Continue surveillance with 6-12 month follow-up."
            )
    
    # Stenosis recommendations
    stenosis_changes = [d for d in diameter_changes if "stenosis" in d.vessel_name.lower()]
    for change in stenosis_changes:
        if change.change_percent > 10:
            recommendations.append(
                f"{change.vessel_name} stenosis has progressed by {change.change_percent:.1f}%. "
                f"Consider revascularization evaluation."
            )
    
    # New findings
    for finding in finding_comparison["new"]:
        if finding["severity"] in ["severe", "critical"]:
            recommendations.append(
                f"URGENT: New {finding['severity']} {finding['type']} detected in {finding['vessel_name']}. "
                f"Immediate clinical correlation recommended."
            )
        else:
            recommendations.append(
                f"New {finding['type']} detected in {finding['vessel_name']}. "
                f"Correlate with clinical symptoms."
            )
    
    # General recommendations
    if progression["risk_level"] == "low":
        recommendations.append("Continue routine surveillance as per standard protocol.")
    elif progression["risk_level"] == "moderate":
        recommendations.append("Consider shortening follow-up interval due to mild progression.")
    else:
        recommendations.append("Urgent clinical review recommended due to significant disease progression.")
    
    return recommendations


@router.get("/patients/{patient_id}/studies")
async def get_patient_studies(
    patient_id: str,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    """Get all studies for a patient"""
    result = await db.execute(
        select(Study).where(Study.patient_id == patient_id).order_by(Study.study_date.desc())
    )
    studies = result.scalars().all()
    
    return [
        {
            "id": s.id,
            "patient_id": s.patient_id,
            "patient_name": f"{s.patient.last_name}, {s.patient.first_name}" if s.patient else "Unknown",
            "study_date": s.study_date,
            "modality": s.modality,
            "description": s.description,
            "status": s.status,
        }
        for s in studies
    ]
