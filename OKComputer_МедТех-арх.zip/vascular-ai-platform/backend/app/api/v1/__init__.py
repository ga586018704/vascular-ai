"""
API Version 1
All v1 endpoints are defined here
"""
from fastapi import APIRouter

from app.api import (
    auth,
    dicom,
    ai_agents,
    risk_calculators,
    reports,
    analytics,
    angiography,
    comparison,
    pathologies,
    integration,
    patients,
    studies,
    users,
    lab_tests,
    pathology_guide,
)

# Create v1 router
api_v1_router = APIRouter()

# Include all v1 endpoints with proper prefixes
api_v1_router.include_router(auth.router, prefix="/auth", tags=["Authentication"])
api_v1_router.include_router(users.router, prefix="/users", tags=["Users"])
api_v1_router.include_router(patients.router, prefix="/patients", tags=["Patients"])
api_v1_router.include_router(studies.router, prefix="/studies", tags=["Studies"])
api_v1_router.include_router(dicom.router, prefix="/dicom", tags=["DICOM"])
api_v1_router.include_router(angiography.router, prefix="/angiography", tags=["CT Angiography"])
api_v1_router.include_router(comparison.router, prefix="/comparisons", tags=["Study Comparison"])
api_v1_router.include_router(pathologies.router, prefix="/pathologies", tags=["Pathologies"])
api_v1_router.include_router(ai_agents.router, prefix="/agents", tags=["AI Agents"])
api_v1_router.include_router(risk_calculators.router, prefix="/calculators", tags=["Risk Calculators"])
api_v1_router.include_router(lab_tests.router, prefix="/lab-tests", tags=["Laboratory Tests"])
api_v1_router.include_router(pathology_guide.router, prefix="/pathology-guide", tags=["Pathology Guide"])
api_v1_router.include_router(reports.router, prefix="/reports", tags=["Reports"])
api_v1_router.include_router(analytics.router, prefix="/analytics", tags=["Analytics"])
api_v1_router.include_router(integration.router, prefix="/integration", tags=["Integration"])
