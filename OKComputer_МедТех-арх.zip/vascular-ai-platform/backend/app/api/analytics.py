"""
Analytics API Endpoints
"""
from datetime import datetime, timedelta
from typing import Optional
from fastapi import APIRouter, Depends, HTTPException, Query
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, func, and_
from app.db.session import get_db
from app.core.security import get_current_active_user, check_admin_role
from app.models.user import User
from app.models.patient import Patient
from app.models.study import Study
from app.models.report import Report
from app.models.audit import AuditLog, DataAccessLog
from app.schemas.analytics import (
    DashboardStats,
    ActivityMetrics,
    SystemHealth,
    UserActivity,
    TimeSeriesData,
    ReportMetrics,
)
from app.core.cache import cache, cached

router = APIRouter()


@router.get("/dashboard", response_model=DashboardStats)
async def get_dashboard_stats(
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_active_user)
):
    """Get main dashboard statistics"""
    
    # Try cache first
    cache_key = "analytics:dashboard"
    cached_data = await cache.get(cache_key)
    if cached_data:
        return DashboardStats(**cached_data)
    
    # Total counts
    patients_count = await db.execute(select(func.count(Patient.id)))
    studies_count = await db.execute(select(func.count(Study.id)))
    reports_count = await db.execute(select(func.count(Report.id)))
    users_count = await db.execute(select(func.count(User.id)))
    
    # Today's activity
    today = datetime.utcnow().date()
    today_start = datetime.combine(today, datetime.min.time())
    
    today_studies = await db.execute(
        select(func.count(Study.id)).where(Study.created_at >= today_start)
    )
    
    today_reports = await db.execute(
        select(func.count(Report.id)).where(Report.created_at >= today_start)
    )
    
    # Recent activity (last 7 days)
    week_ago = datetime.utcnow() - timedelta(days=7)
    
    weekly_studies = await db.execute(
        select(func.count(Study.id)).where(Study.created_at >= week_ago)
    )
    
    weekly_reports = await db.execute(
        select(func.count(Report.id)).where(Report.created_at >= week_ago)
    )
    
    stats = DashboardStats(
        total_patients=patients_count.scalar(),
        total_studies=studies_count.scalar(),
        total_reports=reports_count.scalar(),
        total_users=users_count.scalar(),
        today_studies=today_studies.scalar(),
        today_reports=today_reports.scalar(),
        weekly_studies=weekly_studies.scalar(),
        weekly_reports=weekly_reports.scalar(),
        updated_at=datetime.utcnow()
    )
    
    # Cache for 5 minutes
    await cache.set(cache_key, stats.dict(), expire=300)
    
    return stats


@router.get("/activity", response_model=ActivityMetrics)
async def get_activity_metrics(
    days: int = Query(default=30, ge=1, le=365),
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_active_user)
):
    """Get user activity metrics"""
    
    start_date = datetime.utcnow() - timedelta(days=days)
    
    # Actions by type
    actions_query = await db.execute(
        select(AuditLog.action, func.count(AuditLog.id))
        .where(AuditLog.timestamp >= start_date)
        .group_by(AuditLog.action)
    )
    actions_by_type = dict(actions_query.all())
    
    # Daily activity
    daily_query = await db.execute(
        select(
            func.date(AuditLog.timestamp),
            func.count(AuditLog.id)
        )
        .where(AuditLog.timestamp >= start_date)
        .group_by(func.date(AuditLog.timestamp))
        .order_by(func.date(AuditLog.timestamp))
    )
    daily_activity = [
        {"date": str(date), "count": count}
        for date, count in daily_query.all()
    ]
    
    # Most active users
    active_users_query = await db.execute(
        select(AuditLog.username, func.count(AuditLog.id))
        .where(and_(
            AuditLog.timestamp >= start_date,
            AuditLog.username.isnot(None)
        ))
        .group_by(AuditLog.username)
        .order_by(func.count(AuditLog.id).desc())
        .limit(10)
    )
    top_users = [
        {"username": username, "actions": count}
        for username, count in active_users_query.all()
    ]
    
    return ActivityMetrics(
        period_days=days,
        total_actions=sum(actions_by_type.values()),
        actions_by_type=actions_by_type,
        daily_activity=daily_activity,
        top_users=top_users
    )


@router.get("/system-health", response_model=SystemHealth)
async def get_system_health(
    current_user: User = Depends(check_admin_role)
):
    """Get system health metrics (admin only)"""
    
    import psutil
    
    # CPU
    cpu_percent = psutil.cpu_percent(interval=1)
    cpu_count = psutil.cpu_count()
    
    # Memory
    memory = psutil.virtual_memory()
    
    # Disk
    disk = psutil.disk_usage('/')
    
    # Determine status
    status = "healthy"
    issues = []
    
    if cpu_percent > 80:
        status = "warning"
        issues.append(f"High CPU usage: {cpu_percent}%")
    
    if memory.percent > 80:
        status = "warning"
        issues.append(f"High memory usage: {memory.percent}%")
    
    if disk.percent > 80:
        status = "warning"
        issues.append(f"Low disk space: {disk.percent}% used")
    
    return SystemHealth(
        status=status,
        issues=issues,
        cpu={
            "percent": cpu_percent,
            "count": cpu_count,
            "frequency_mhz": psutil.cpu_freq().current if psutil.cpu_freq() else None
        },
        memory={
            "total_gb": round(memory.total / (1024**3), 2),
            "available_gb": round(memory.available / (1024**3), 2),
            "percent": memory.percent,
            "used_gb": round(memory.used / (1024**3), 2)
        },
        disk={
            "total_gb": round(disk.total / (1024**3), 2),
            "free_gb": round(disk.free / (1024**3), 2),
            "percent": disk.percent,
            "used_gb": round(disk.used / (1024**3), 2)
        },
        timestamp=datetime.utcnow()
    )


@router.get("/user-activity/{user_id}", response_model=UserActivity)
async def get_user_activity(
    user_id: int,
    days: int = Query(default=30, ge=1, le=365),
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_active_user)
):
    """Get activity for a specific user"""
    
    # Users can only view their own activity unless admin
    if current_user.id != user_id and current_user.role != "admin":
        raise HTTPException(status_code=403, detail="Not authorized")
    
    start_date = datetime.utcnow() - timedelta(days=days)
    
    # Get user
    user = await db.execute(select(User).where(User.id == user_id))
    user = user.scalar_one_or_none()
    
    if not user:
        raise HTTPException(status_code=404, detail="User not found")
    
    # Activity counts
    activity_query = await db.execute(
        select(AuditLog.action, func.count(AuditLog.id))
        .where(and_(
            AuditLog.user_id == user_id,
            AuditLog.timestamp >= start_date
        ))
        .group_by(AuditLog.action)
    )
    activity_counts = dict(activity_query.all())
    
    # Recent actions
    recent_query = await db.execute(
        select(AuditLog)
        .where(and_(
            AuditLog.user_id == user_id,
            AuditLog.timestamp >= start_date
        ))
        .order_by(AuditLog.timestamp.desc())
        .limit(50)
    )
    recent_actions = recent_query.scalars().all()
    
    return UserActivity(
        user_id=user_id,
        username=user.username,
        period_days=days,
        total_actions=sum(activity_counts.values()),
        activity_by_type=activity_counts,
        recent_actions=[
            {
                "timestamp": action.timestamp,
                "action": action.action,
                "resource_type": action.resource_type,
                "resource_id": action.resource_id,
                "success": action.success == 1
            }
            for action in recent_actions
        ]
    )


@router.get("/timeseries/{metric}", response_model=TimeSeriesData)
async def get_time_series_data(
    metric: str,
    start_date: datetime = Query(...),
    end_date: datetime = Query(...),
    interval: str = Query(default="day", regex="^(hour|day|week|month)$"),
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_active_user)
):
    """Get time series data for charts"""
    
    if metric == "studies":
        data = await _get_studies_timeseries(db, start_date, end_date, interval)
    elif metric == "reports":
        data = await _get_reports_timeseries(db, start_date, end_date, interval)
    elif metric == "users":
        data = await _get_users_timeseries(db, start_date, end_date, interval)
    else:
        raise HTTPException(status_code=400, detail=f"Unknown metric: {metric}")
    
    return TimeSeriesData(
        metric=metric,
        interval=interval,
        start_date=start_date,
        end_date=end_date,
        data=data
    )


async def _get_studies_timeseries(db, start_date, end_date, interval):
    """Get studies time series data"""
    
    if interval == "day":
        group_by = func.date(Study.created_at)
    elif interval == "week":
        group_by = func.strftime('%Y-%W', Study.created_at)
    elif interval == "month":
        group_by = func.strftime('%Y-%m', Study.created_at)
    else:  # hour
        group_by = func.strftime('%Y-%m-%d %H', Study.created_at)
    
    query = await db.execute(
        select(group_by, func.count(Study.id))
        .where(and_(
            Study.created_at >= start_date,
            Study.created_at <= end_date
        ))
        .group_by(group_by)
        .order_by(group_by)
    )
    
    return [{"timestamp": str(ts), "value": count} for ts, count in query.all()]


async def _get_reports_timeseries(db, start_date, end_date, interval):
    """Get reports time series data"""
    
    if interval == "day":
        group_by = func.date(Report.created_at)
    elif interval == "week":
        group_by = func.strftime('%Y-%W', Report.created_at)
    elif interval == "month":
        group_by = func.strftime('%Y-%m', Report.created_at)
    else:
        group_by = func.strftime('%Y-%m-%d %H', Report.created_at)
    
    query = await db.execute(
        select(group_by, func.count(Report.id))
        .where(and_(
            Report.created_at >= start_date,
            Report.created_at <= end_date
        ))
        .group_by(group_by)
        .order_by(group_by)
    )
    
    return [{"timestamp": str(ts), "value": count} for ts, count in query.all()]


async def _get_users_timeseries(db, start_date, end_date, interval):
    """Get users time series data"""
    
    if interval == "day":
        group_by = func.date(User.created_at)
    elif interval == "week":
        group_by = func.strftime('%Y-%W', User.created_at)
    elif interval == "month":
        group_by = func.strftime('%Y-%m', User.created_at)
    else:
        group_by = func.strftime('%Y-%m-%d %H', User.created_at)
    
    query = await db.execute(
        select(group_by, func.count(User.id))
        .where(and_(
            User.created_at >= start_date,
            User.created_at <= end_date
        ))
        .group_by(group_by)
        .order_by(group_by)
    )
    
    return [{"timestamp": str(ts), "value": count} for ts, count in query.all()]


@router.get("/reports", response_model=ReportMetrics)
async def get_report_metrics(
    days: int = Query(default=30, ge=1, le=365),
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_active_user)
):
    """Get report generation metrics"""
    
    start_date = datetime.utcnow() - timedelta(days=days)
    
    # Reports by type
    type_query = await db.execute(
        select(Report.report_type, func.count(Report.id))
        .where(Report.created_at >= start_date)
        .group_by(Report.report_type)
    )
    reports_by_type = dict(type_query.all())
    
    # Reports by status
    status_query = await db.execute(
        select(Report.status, func.count(Report.id))
        .where(Report.created_at >= start_date)
        .group_by(Report.status)
    )
    reports_by_status = dict(status_query.all())
    
    # Average generation time (if stored)
    total_reports = sum(reports_by_type.values())
    
    return ReportMetrics(
        period_days=days,
        total_reports=total_reports,
        reports_by_type=reports_by_type,
        reports_by_status=reports_by_status,
        average_generation_time_seconds=None  # Would need to track this
    )
