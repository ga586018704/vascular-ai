"""
Redis Cache Configuration and Service
"""
import json
import pickle
import hashlib
from typing import Optional, Any, Union
from functools import wraps
import redis.asyncio as redis
from app.core.config import settings


class CacheService:
    """Redis-based caching service"""
    
    _instance = None
    _redis_client: Optional[redis.Redis] = None
    
    def __new__(cls):
        if cls._instance is None:
            cls._instance = super().__new__(cls)
        return cls._instance
    
    async def connect(self):
        """Initialize Redis connection"""
        if self._redis_client is None and settings.REDIS_URL:
            self._redis_client = redis.from_url(
                settings.REDIS_URL,
                encoding="utf-8",
                decode_responses=False
            )
    
    async def disconnect(self):
        """Close Redis connection"""
        if self._redis_client:
            await self._redis_client.close()
            self._redis_client = None
    
    @property
    def is_connected(self) -> bool:
        return self._redis_client is not None
    
    async def get(self, key: str) -> Optional[Any]:
        """Get value from cache"""
        if not self._redis_client:
            return None
        
        try:
            data = await self._redis_client.get(key)
            if data:
                return pickle.loads(data)
            return None
        except Exception:
            return None
    
    async def set(
        self,
        key: str,
        value: Any,
        expire: int = 3600,
        nx: bool = False
    ) -> bool:
        """Set value in cache with optional expiration (seconds)"""
        if not self._redis_client:
            return False
        
        try:
            serialized = pickle.dumps(value)
            await self._redis_client.set(key, serialized, ex=expire, nx=nx)
            return True
        except Exception:
            return False
    
    async def delete(self, key: str) -> bool:
        """Delete key from cache"""
        if not self._redis_client:
            return False
        
        try:
            await self._redis_client.delete(key)
            return True
        except Exception:
            return False
    
    async def delete_pattern(self, pattern: str) -> int:
        """Delete all keys matching pattern"""
        if not self._redis_client:
            return 0
        
        try:
            keys = await self._redis_client.keys(pattern)
            if keys:
                return await self._redis_client.delete(*keys)
            return 0
        except Exception:
            return 0
    
    async def exists(self, key: str) -> bool:
        """Check if key exists"""
        if not self._redis_client:
            return False
        
        try:
            return await self._redis_client.exists(key) > 0
        except Exception:
            return False
    
    async def ttl(self, key: str) -> int:
        """Get time-to-live for key"""
        if not self._redis_client:
            return -2
        
        try:
            return await self._redis_client.ttl(key)
        except Exception:
            return -2
    
    async def increment(self, key: str, amount: int = 1) -> int:
        """Increment counter"""
        if not self._redis_client:
            return 0
        
        try:
            return await self._redis_client.incrby(key, amount)
        except Exception:
            return 0
    
    async def expire(self, key: str, seconds: int) -> bool:
        """Set expiration on key"""
        if not self._redis_client:
            return False
        
        try:
            return await self._redis_client.expire(key, seconds)
        except Exception:
            return False
    
    @staticmethod
    def generate_key(*args, **kwargs) -> str:
        """Generate cache key from arguments"""
        key_data = json.dumps({"args": args, "kwargs": kwargs}, sort_keys=True)
        return hashlib.md5(key_data.encode()).hexdigest()


# Global cache instance
cache = CacheService()


def cached(expire: int = 3600, key_prefix: str = ""):
    """Decorator to cache function results"""
    def decorator(func):
        @wraps(func)
        async def async_wrapper(*args, **kwargs):
            # Generate cache key
            cache_key = f"{key_prefix}:{func.__name__}:{CacheService.generate_key(args[1:], kwargs)}"
            
            # Try to get from cache
            cached_value = await cache.get(cache_key)
            if cached_value is not None:
                return cached_value
            
            # Call function and cache result
            result = await func(*args, **kwargs)
            await cache.set(cache_key, result, expire=expire)
            return result
        
        @wraps(func)
        def sync_wrapper(*args, **kwargs):
            # For sync functions, don't cache (or implement sync Redis)
            return func(*args, **kwargs)
        
        return async_wrapper if func.__code__.co_flags & 0x80 else sync_wrapper
    return decorator


def invalidate_cache(pattern: str):
    """Decorator to invalidate cache after function call"""
    def decorator(func):
        @wraps(func)
        async def async_wrapper(*args, **kwargs):
            result = await func(*args, **kwargs)
            await cache.delete_pattern(pattern)
            return result
        
        @wraps(func)
        def sync_wrapper(*args, **kwargs):
            result = func(*args, **kwargs)
            # Can't await in sync function
            return result
        
        return async_wrapper if func.__code__.co_flags & 0x80 else sync_wrapper
    return decorator
