"""
Application Configuration
Production-ready configuration with security hardening
"""
import os
from typing import List, Optional
from pydantic_settings import BaseSettings, SettingsConfigDict
from pydantic import Field, field_validator


class Settings(BaseSettings):
    """Application settings with production security requirements"""
    
    model_config = SettingsConfigDict(
        env_file=".env",
        env_file_encoding="utf-8",
        case_sensitive=True,
        extra="ignore"  # Allow extra env vars without error
    )
    
    # Application
    APP_NAME: str = "VASCULAR.AI"
    APP_VERSION: str = "3.0.0"
    DEBUG: bool = Field(default=False)
    ENVIRONMENT: str = Field(default="production")
    
    # Security - SECRET_KEY is REQUIRED, no default for security
    SECRET_KEY: str = Field(..., min_length=32)  # Required field
    ALGORITHM: str = "HS256"
    ACCESS_TOKEN_EXPIRE_MINUTES: int = Field(default=30, ge=5, le=1440)
    REFRESH_TOKEN_EXPIRE_DAYS: int = Field(default=7, ge=1, le=90)
    
    @field_validator("SECRET_KEY", mode="before")
    @classmethod
    def validate_secret_key(cls, v: Optional[str]) -> str:
        """Validate SECRET_KEY is secure"""
        if not v:
            raise ValueError(
                "SECRET_KEY environment variable is REQUIRED.\n"
                "Generate a secure key with: openssl rand -hex 32\n"
                "Or use: python -c 'import secrets; print(secrets.token_hex(32))'"
            )
        if v == "your-secret-key-change-in-production":
            raise ValueError(
                "SECRET_KEY cannot be the default placeholder value. "
                "Please generate a secure random key."
            )
        if len(v) < 32:
            raise ValueError(
                f"SECRET_KEY must be at least 32 characters long (got {len(v)}). "
                "Use a secure random string."
            )
        return v
    
    # Database - PostgreSQL for production, SQLite for development only
    DATABASE_URL: str = Field(
        default="postgresql+asyncpg://vascular:vascular_password@localhost:5432/vascular_ai"
    )
    DATABASE_POOL_SIZE: int = Field(default=10, ge=1, le=100)
    DATABASE_MAX_OVERFLOW: int = Field(default=20, ge=0, le=100)
    DATABASE_POOL_TIMEOUT: int = Field(default=30, ge=1, le=300)
    DATABASE_POOL_RECYCLE: int = Field(default=1800, ge=60, le=3600)
    
    @field_validator("DATABASE_URL", mode="before")
    @classmethod
    def validate_database_url(cls, v: str, info) -> str:
        """Warn about SQLite in production"""
        environment = info.data.get("ENVIRONMENT", "production")
        if environment == "production" and "sqlite" in v.lower():
            import warnings
            warnings.warn(
                "WARNING: SQLite is not recommended for production. "
                "Please use PostgreSQL for production deployments. "
                "Example: postgresql+asyncpg://user:pass@host:5432/dbname",
                RuntimeWarning
            )
        return v
    
    # CORS - Restrict in production
    ALLOWED_ORIGINS: List[str] = Field(default_factory=list)
    
    @field_validator("ALLOWED_ORIGINS", mode="before")
    @classmethod
    def validate_cors_origins(cls, v, info) -> List[str]:
        """Set default CORS origins based on environment"""
        environment = info.data.get("ENVIRONMENT", "production")
        if not v:
            if environment == "development":
                return [
                    "http://localhost:3000",
                    "http://localhost:5173",
                    "http://127.0.0.1:3000",
                    "http://127.0.0.1:5173",
                    "http://localhost:8080",
                ]
            else:
                # Production: only specific origins
                return ["https://vascular.ai", "https://app.vascular.ai"]
        return v if isinstance(v, list) else v.split(",")
    
    # Redis
    REDIS_URL: str = Field(default="redis://localhost:6379/0")
    REDIS_PASSWORD: Optional[str] = Field(default=None)
    REDIS_SSL: bool = Field(default=False)
    
    # Celery
    CELERY_BROKER_URL: str = Field(default="redis://localhost:6379/0")
    CELERY_RESULT_BACKEND: str = Field(default="redis://localhost:6379/0")
    CELERY_WORKER_CONCURRENCY: int = Field(default=4, ge=1, le=20)
    
    # OpenAI
    OPENAI_API_KEY: Optional[str] = Field(default=None)
    OPENAI_MODEL: str = Field(default="gpt-4")
    OPENAI_TIMEOUT: int = Field(default=30, ge=5, le=120)
    OPENAI_MAX_RETRIES: int = Field(default=3, ge=0, le=10)
    
    # Anthropic
    ANTHROPIC_API_KEY: Optional[str] = Field(default=None)
    ANTHROPIC_MODEL: str = Field(default="claude-3-opus-20240229")
    ANTHROPIC_TIMEOUT: int = Field(default=30, ge=5, le=120)
    ANTHROPIC_MAX_RETRIES: int = Field(default=3, ge=0, le=10)
    
    # DICOM Storage
    DICOM_STORAGE_PATH: str = Field(default="./storage/dicom")
    REPORTS_STORAGE_PATH: str = Field(default="./storage/reports")
    TEMP_STORAGE_PATH: str = Field(default="./storage/temp")
    DICOM_MAX_FILE_SIZE: int = Field(default=1073741824)  # 1GB
    DICOM_MAX_TOTAL_SIZE: int = Field(default=5368709120)  # 5GB
    
    # Email
    SMTP_HOST: Optional[str] = Field(default=None)
    SMTP_PORT: int = Field(default=587, ge=1, le=65535)
    SMTP_USER: Optional[str] = Field(default=None)
    SMTP_PASSWORD: Optional[str] = Field(default=None)
    SMTP_TLS: bool = Field(default=True)
    EMAIL_FROM: str = Field(default="noreply@vascular.ai")
    
    # File Upload
    MAX_UPLOAD_SIZE: int = Field(default=1073741824)  # 1GB
    ALLOWED_EXTENSIONS: List[str] = Field(default_factory=lambda: [".dcm", ".dicom", ".zip"])
    
    # WebSocket
    WS_HEARTBEAT_INTERVAL: int = Field(default=30, ge=5, le=300)
    WS_CONNECTION_TIMEOUT: int = Field(default=60, ge=10, le=300)
    
    # Audit Logging
    AUDIT_LOG_RETENTION_DAYS: int = Field(default=2555)  # 7 years (HIPAA)
    AUDIT_LOG_LEVEL: str = Field(default="INFO")
    
    # Rate Limiting
    RATE_LIMIT_REQUESTS: int = Field(default=100, ge=10, le=10000)
    RATE_LIMIT_WINDOW: int = Field(default=60, ge=10, le=3600)
    RATE_LIMIT_STORAGE: str = Field(default="redis")  # redis or memory
    
    # Cache TTL
    CACHE_TTL_DEFAULT: int = Field(default=3600)  # 1 hour
    CACHE_TTL_ANALYTICS: int = Field(default=300)  # 5 minutes
    CACHE_TTL_PATHOLOGIES: int = Field(default=86400)  # 24 hours
    
    # FHIR Integration
    FHIR_ENABLED: bool = Field(default=False)
    FHIR_BASE_URL: Optional[str] = Field(default=None)
    FHIR_AUTH_TYPE: str = Field(default="oauth2")  # oauth2, bearer, basic
    FHIR_CLIENT_ID: Optional[str] = Field(default=None)
    FHIR_CLIENT_SECRET: Optional[str] = Field(default=None)
    
    # PACS Integration
    PACS_ENABLED: bool = Field(default=False)
    PACS_HOST: Optional[str] = Field(default=None)
    PACS_PORT: int = Field(default=11112, ge=1, le=65535)
    PACS_AE_TITLE: str = Field(default="VASCULAR_AI")
    PACS_CALLED_AE_TITLE: str = Field(default="PACS")
    PACS_WADO_URL: Optional[str] = Field(default=None)
    
    # Monitoring
    METRICS_ENABLED: bool = Field(default=True)
    TRACING_ENABLED: bool = Field(default=False)
    SENTRY_DSN: Optional[str] = Field(default=None)
    
    # Feature Flags
    FEATURE_3D_VIEWER: bool = Field(default=True)
    FEATURE_VOICE_ASSISTANT: bool = Field(default=True)
    FEATURE_MPR_VIEWER: bool = Field(default=True)
    FEATURE_COLLABORATION: bool = Field(default=False)


# Global settings instance - lazy loading for better testability
_settings: Optional[Settings] = None


def get_settings() -> Settings:
    """Get settings singleton with caching"""
    global _settings
    if _settings is None:
        _settings = Settings()
    return _settings


# Backward compatibility
settings = get_settings()
