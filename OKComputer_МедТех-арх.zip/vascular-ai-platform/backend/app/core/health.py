"""
Comprehensive Health Check System
Checks all dependencies and services
"""

import asyncio
import time
from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum
from typing import Any, Dict, List, Optional

import httpx
from sqlalchemy import text
from sqlalchemy.ext.asyncio import AsyncEngine

from app.core.cache import cache
from app.core.config import get_settings
from app.core.logging import get_logger
from app.db.session import engine

logger = get_logger(__name__)
settings = get_settings()


class HealthStatus(str, Enum):
    """Health check status"""
    HEALTHY = "healthy"
    DEGRADED = "degraded"
    UNHEALTHY = "unhealthy"
    UNKNOWN = "unknown"


@dataclass
class HealthCheckResult:
    """Result of a single health check"""
    name: str
    status: HealthStatus
    response_time_ms: float
    message: str = ""
    details: Dict[str, Any] = field(default_factory=dict)
    last_success: Optional[datetime] = None
    last_failure: Optional[datetime] = None
    
    def to_dict(self) -> Dict[str, Any]:
        return {
            "name": self.name,
            "status": self.status.value,
            "response_time_ms": round(self.response_time_ms, 2),
            "message": self.message,
            "details": self.details,
            "last_success": self.last_success.isoformat() if self.last_success else None,
            "last_failure": self.last_failure.isoformat() if self.last_failure else None
        }


class HealthChecker:
    """Comprehensive health checker for all dependencies"""
    
    def __init__(self):
        self.checks: Dict[str, HealthCheckResult] = {}
        self._check_history: List[Dict] = []
        self._max_history = 100
    
    async def check_database(self) -> HealthCheckResult:
        """Check database connectivity"""
        start = time.time()
        name = "database"
        
        try:
            async with engine.connect() as conn:
                # Check connection
                await conn.execute(text("SELECT 1"))
                
                # Check connection pool stats
                pool = engine.pool
                pool_stats = {
                    "size": pool.size() if hasattr(pool, 'size') else -1,
                    "checked_in": pool.checkedin() if hasattr(pool, 'checkedin') else -1,
                    "checked_out": pool.checkedout() if hasattr(pool, 'checkedout') else -1,
                    "overflow": pool.overflow() if hasattr(pool, 'overflow') else -1
                }
                
            elapsed = (time.time() - start) * 1000
            
            result = HealthCheckResult(
                name=name,
                status=HealthStatus.HEALTHY,
                response_time_ms=elapsed,
                message="Database connection successful",
                details={
                    "type": "postgresql" if "postgresql" in settings.DATABASE_URL else "sqlite",
                    "pool": pool_stats
                },
                last_success=datetime.utcnow()
            )
            
        except Exception as e:
            elapsed = (time.time() - start) * 1000
            result = HealthCheckResult(
                name=name,
                status=HealthStatus.UNHEALTHY,
                response_time_ms=elapsed,
                message=f"Database connection failed: {str(e)}",
                last_failure=datetime.utcnow()
            )
            logger.error(f"Health check failed for database: {e}")
        
        self.checks[name] = result
        return result
    
    async def check_redis(self) -> HealthCheckResult:
        """Check Redis connectivity"""
        start = time.time()
        name = "redis"
        
        try:
            if not cache.is_connected:
                raise Exception("Redis not connected")
            
            # Test ping
            redis = cache._redis
            if redis:
                await redis.ping()
                info = await redis.info()
                
            elapsed = (time.time() - start) * 1000
            
            result = HealthCheckResult(
                name=name,
                status=HealthStatus.HEALTHY,
                response_time_ms=elapsed,
                message="Redis connection successful",
                details={
                    "connected": True,
                    "redis_version": info.get("redis_version", "unknown") if 'info' in locals() else "unknown"
                },
                last_success=datetime.utcnow()
            )
            
        except Exception as e:
            elapsed = (time.time() - start) * 1000
            result = HealthCheckResult(
                name=name,
                status=HealthStatus.DEGRADED,
                response_time_ms=elapsed,
                message=f"Redis unavailable: {str(e)}",
                details={"connected": False},
                last_failure=datetime.utcnow()
            )
            logger.warning(f"Health check degraded for Redis: {e}")
        
        self.checks[name] = result
        return result
    
    async def check_openai(self) -> HealthCheckResult:
        """Check OpenAI API availability"""
        start = time.time()
        name = "openai"
        
        if not settings.OPENAI_API_KEY:
            return HealthCheckResult(
                name=name,
                status=HealthStatus.UNKNOWN,
                response_time_ms=0,
                message="OpenAI API key not configured"
            )
        
        try:
            async with httpx.AsyncClient(timeout=10.0) as client:
                response = await client.get(
                    "https://api.openai.com/v1/models",
                    headers={"Authorization": f"Bearer {settings.OPENAI_API_KEY}"}
                )
                
                if response.status_code == 200:
                    elapsed = (time.time() - start) * 1000
                    result = HealthCheckResult(
                        name=name,
                        status=HealthStatus.HEALTHY,
                        response_time_ms=elapsed,
                        message="OpenAI API accessible",
                        last_success=datetime.utcnow()
                    )
                else:
                    raise Exception(f"HTTP {response.status_code}")
                    
        except Exception as e:
            elapsed = (time.time() - start) * 1000
            result = HealthCheckResult(
                name=name,
                status=HealthStatus.DEGRADED,
                response_time_ms=elapsed,
                message=f"OpenAI API check failed: {str(e)}",
                last_failure=datetime.utcnow()
            )
        
        self.checks[name] = result
        return result
    
    async def check_anthropic(self) -> HealthCheckResult:
        """Check Anthropic API availability"""
        start = time.time()
        name = "anthropic"
        
        if not settings.ANTHROPIC_API_KEY:
            return HealthCheckResult(
                name=name,
                status=HealthStatus.UNKNOWN,
                response_time_ms=0,
                message="Anthropic API key not configured"
            )
        
        try:
            async with httpx.AsyncClient(timeout=10.0) as client:
                response = await client.get(
                    "https://api.anthropic.com/v1/models",
                    headers={"x-api-key": settings.ANTHROPIC_API_KEY}
                )
                
                if response.status_code == 200:
                    elapsed = (time.time() - start) * 1000
                    result = HealthCheckResult(
                        name=name,
                        status=HealthStatus.HEALTHY,
                        response_time_ms=elapsed,
                        message="Anthropic API accessible",
                        last_success=datetime.utcnow()
                    )
                else:
                    raise Exception(f"HTTP {response.status_code}")
                    
        except Exception as e:
            elapsed = (time.time() - start) * 1000
            result = HealthCheckResult(
                name=name,
                status=HealthStatus.DEGRADED,
                response_time_ms=elapsed,
                message=f"Anthropic API check failed: {str(e)}",
                last_failure=datetime.utcnow()
            )
        
        self.checks[name] = result
        return result
    
    async def check_disk_space(self) -> HealthCheckResult:
        """Check available disk space"""
        start = time.time()
        name = "disk"
        
        try:
            import shutil
            
            # Check upload directory
            upload_path = settings.UPLOAD_DIR
            upload_path.mkdir(parents=True, exist_ok=True)
            
            total, used, free = shutil.disk_usage(upload_path)
            free_gb = free / (1024**3)
            total_gb = total / (1024**3)
            used_percent = (used / total) * 100
            
            elapsed = (time.time() - start) * 1000
            
            # Determine status based on free space
            if free_gb < 1.0:  # Less than 1GB
                status = HealthStatus.UNHEALTHY
                message = f"Critical: Only {free_gb:.2f}GB free"
            elif free_gb < 5.0:  # Less than 5GB
                status = HealthStatus.DEGRADED
                message = f"Warning: {free_gb:.2f}GB free"
            else:
                status = HealthStatus.HEALTHY
                message = f"OK: {free_gb:.2f}GB free"
            
            result = HealthCheckResult(
                name=name,
                status=status,
                response_time_ms=elapsed,
                message=message,
                details={
                    "total_gb": round(total_gb, 2),
                    "free_gb": round(free_gb, 2),
                    "used_percent": round(used_percent, 2)
                },
                last_success=datetime.utcnow() if status == HealthStatus.HEALTHY else None
            )
            
        except Exception as e:
            elapsed = (time.time() - start) * 1000
            result = HealthCheckResult(
                name=name,
                status=HealthStatus.UNKNOWN,
                response_time_ms=elapsed,
                message=f"Disk check failed: {str(e)}",
                last_failure=datetime.utcnow()
            )
        
        self.checks[name] = result
        return result
    
    async def check_memory(self) -> HealthCheckResult:
        """Check system memory"""
        start = time.time()
        name = "memory"
        
        try:
            import psutil
            
            memory = psutil.virtual_memory()
            
            elapsed = (time.time() - start) * 1000
            
            # Determine status
            if memory.percent > 90:
                status = HealthStatus.UNHEALTHY
                message = f"Critical: {memory.percent}% memory used"
            elif memory.percent > 80:
                status = HealthStatus.DEGRADED
                message = f"Warning: {memory.percent}% memory used"
            else:
                status = HealthStatus.HEALTHY
                message = f"OK: {memory.percent}% memory used"
            
            result = HealthCheckResult(
                name=name,
                status=status,
                response_time_ms=elapsed,
                message=message,
                details={
                    "total_gb": round(memory.total / (1024**3), 2),
                    "available_gb": round(memory.available / (1024**3), 2),
                    "used_percent": memory.percent
                },
                last_success=datetime.utcnow() if status == HealthStatus.HEALTHY else None
            )
            
        except ImportError:
            elapsed = (time.time() - start) * 1000
            result = HealthCheckResult(
                name=name,
                status=HealthStatus.UNKNOWN,
                response_time_ms=elapsed,
                message="psutil not installed, cannot check memory"
            )
        except Exception as e:
            elapsed = (time.time() - start) * 1000
            result = HealthCheckResult(
                name=name,
                status=HealthStatus.UNKNOWN,
                response_time_ms=elapsed,
                message=f"Memory check failed: {str(e)}"
            )
        
        self.checks[name] = result
        return result
    
    async def run_all_checks(self) -> Dict[str, Any]:
        """Run all health checks concurrently"""
        start = time.time()
        
        # Run all checks concurrently
        results = await asyncio.gather(
            self.check_database(),
            self.check_redis(),
            self.check_openai(),
            self.check_anthropic(),
            self.check_disk_space(),
            self.check_memory(),
            return_exceptions=True
        )
        
        # Process results
        checks = []
        overall_status = HealthStatus.HEALTHY
        
        for result in results:
            if isinstance(result, Exception):
                logger.error(f"Health check raised exception: {result}")
                overall_status = HealthStatus.UNHEALTHY
                continue
            
            checks.append(result.to_dict())
            
            # Determine overall status
            if result.status == HealthStatus.UNHEALTHY:
                overall_status = HealthStatus.UNHEALTHY
            elif result.status == HealthStatus.DEGRADED and overall_status == HealthStatus.HEALTHY:
                overall_status = HealthStatus.DEGRADED
        
        total_time = (time.time() - start) * 1000
        
        response = {
            "status": overall_status.value,
            "timestamp": datetime.utcnow().isoformat(),
            "version": "2.0.0",
            "service": "VASCULAR.AI API",
            "environment": "production" if not settings.DEBUG else "development",
            "response_time_ms": round(total_time, 2),
            "checks": checks,
            "summary": {
                "total": len(checks),
                "healthy": sum(1 for c in checks if c["status"] == "healthy"),
                "degraded": sum(1 for c in checks if c["status"] == "degraded"),
                "unhealthy": sum(1 for c in checks if c["status"] == "unhealthy"),
                "unknown": sum(1 for c in checks if c["status"] == "unknown")
            }
        }
        
        # Store in history
        self._check_history.append({
            "timestamp": datetime.utcnow().isoformat(),
            "status": overall_status.value
        })
        if len(self._check_history) > self._max_history:
            self._check_history.pop(0)
        
        return response


# Global health checker instance
health_checker = HealthChecker()
