"""
Comprehensive Vascular Pathology Classification
Complete medical nomenclature for vascular diseases
"""
from enum import Enum
from dataclasses import dataclass
from typing import Optional, List, Dict, Any


class PathologyCategory(Enum):
    """Pathology categories by etiology"""
    DEGENERATIVE = "degenerative"           # Degenerative changes
    INFLAMMATORY = "inflammatory"           # Inflammatory conditions
    INFECTIOUS = "infectious"               # Infectious diseases
    TRAUMATIC = "traumatic"                 # Traumatic injuries
    CONGENITAL = "congenital"               # Congenital anomalies
    NEOPLASTIC = "neoplastic"               # Tumors and neoplasms
    IATROGENIC = "iatrogenic"               # Treatment-related
    SYSTEMIC = "systemic"                   # Systemic diseases
    FUNCTIONAL = "functional"               # Functional disorders
    IDIOPATHIC = "idiopathic"               # Unknown etiology


class PathologyType(Enum):
    """
    Comprehensive vascular pathology classification
    Based on SVS (Society for Vascular Surgery) and ESVS (European Society for Vascular Surgery) nomenclature
    """
    
    # === ANEURYSMAL DISEASES ===
    ANEURYSM = "aneurysm"                                   # General aneurysm
    ANEURYSM_SACCULAR = "aneurysm_saccular"                # Saccular (berry) aneurysm
    ANEURYSM_FUSIFORM = "aneurysm_fusiform"                # Fusiform aneurysm
    ANEURYSM_DISSECTING = "aneurysm_dissecting"            # Dissecting aneurysm
    ANEURYSM_MYCOTIC = "aneurysm_mycotic"                  # Mycotic (infectious) aneurysm
    ANEURYSM_TRAUMATIC = "aneurysm_traumatic"              # Traumatic aneurysm
    ANEURYSM_INFLAMMATORY = "aneurysm_inflammatory"        # Inflammatory aneurysm
    PSEUDOANEURYSM = "pseudoaneurysm"                      # False aneurysm
    ANEURYSM_RUPTURED = "aneurysm_ruptured"                # Ruptured aneurysm
    ANEURYSM_LEAKING = "aneurysm_leaking"                  # Leaking aneurysm
    ANEURYSM_THROMBOSED = "aneurysm_thrombosed"            # Thrombosed aneurysm
    ANEURYSM_CALCIFIED = "aneurysm_calcified"              # Calcified aneurysm
    ANEURYSM_INFLAMMATORY_AORTIC = "aneurysm_inflammatory_aortic"  # Inflammatory aortic aneurysm
    
    # === OCCLUSIVE DISEASES ===
    STENOSIS = "stenosis"                                  # General stenosis
    STENOSIS_CALCIFIED = "stenosis_calcified"              # Calcified stenosis
    STENOSIS_SOFT_PLAQUE = "stenosis_soft_plaque"          # Soft plaque stenosis
    STENOSIS_ULCERATED = "stenosis_ulcerated"              # Ulcerated stenosis
    STENOSIS_ECCENTRIC = "stenosis_eccentric"              # Eccentric stenosis
    STENOSIS_CONCENTRIC = "stenosis_concentric"            # Concentric stenosis
    STENOSIS_LONG_SEGMENT = "stenosis_long_segment"        # Long-segment stenosis
    STENOSIS_TANDEM = "stenosis_tandem"                    # Tandem stenosis
    STENOSIS_RECURRENT = "stenosis_recurrent"              # Recurrent stenosis
    STENOSIS_POST_RADIATION = "stenosis_post_radiation"    # Post-radiation stenosis
    
    OCCLUSION = "occlusion"                                # Complete occlusion
    OCCLUSION_CHRONIC_TOTAL = "occlusion_chronic_total"    # Chronic total occlusion (CTO)
    OCCLUSION_SUBACUTE = "occlusion_subacute"              # Subacute occlusion
    OCCLUSION_ACUTE = "occlusion_acute"                    # Acute occlusion
    OCCLUSION_STUMP = "occlusion_stump"                    # Occlusion stump
    
    # === THROMBOTIC DISEASES ===
    THROMBOSIS = "thrombosis"                              # General thrombosis
    THROMBOSIS_ACUTE = "thrombosis_acute"                  # Acute thrombosis (<14 days)
    THROMBOSIS_SUBACUTE = "thrombosis_subacute"            # Subacute thrombosis (14-28 days)
    THROMBOSIS_CHRONIC = "thrombosis_chronic"              # Chronic thrombosis (>28 days)
    THROMBOSIS_ORGANIZED = "thrombosis_organized"          # Organized thrombus
    THROMBOSIS_FRESH = "thrombosis_fresh"                  # Fresh thrombus
    THROMBOSIS_PROPAGATING = "thrombosis_propagating"      # Propagating thrombus
    THROMBOSIS_MURAL = "thrombosis_mural"                  # Mural thrombus
    THROMBOSIS_OBSTRUCTIVE = "thrombosis_obstructive"      # Obstructive thrombus
    THROMBOSIS_PARIETAL = "thrombosis_parietal"            # Parietal thrombus
    THROMBOSIS_CALCIFIED = "thrombosis_calcified"          # Calcified thrombus
    
    EMBOLISM = "embolism"                                  # Embolic event
    EMBOLISM_ACUTE = "embolism_acute"                      # Acute embolism
    EMBOLISM_PARADOXICAL = "embolism_paradoxical"          # Paradoxical embolism
    EMBOLISM_FAT = "embolism_fat"                          # Fat embolism
    EMBOLISM_AIR = "embolism_air"                          # Air embolism
    EMBOLISM_SEPTIC = "embolism_septic"                    # Septic embolism
    EMBOLISM_TUMOR = "embolism_tumor"                      # Tumor embolism
    EMBOLISM_AMNIOTIC = "embolism_amniotic"                # Amniotic fluid embolism
    
    # === DISSECTIONS ===
    DISSECTION = "dissection"                              # General dissection
    DISSECTION_TYPE_A = "dissection_type_a"                # Stanford Type A
    DISSECTION_TYPE_B = "dissection_type_b"                # Stanford Type B
    DISSECTION_TYPE_I = "dissection_type_i"                # DeBakey Type I
    DISSECTION_TYPE_II = "dissection_type_ii"              # DeBakey Type II
    DISSECTION_TYPE_III = "dissection_type_iii"            # DeBakey Type III
    DISSECTION_TYPE_IIIA = "dissection_type_iiia"          # DeBakey Type IIIa
    DISSECTION_TYPE_IIIB = "dissection_type_iiib"          # DeBakey Type IIIb
    DISSECTION_COMPLICATED = "dissection_complicated"      # Complicated dissection
    DISSECTION_UNCOMPLICATED = "dissection_uncomplicated"  # Uncomplicated dissection
    DISSECTION_WITH_MALPERFUSION = "dissection_malperfusion"  # With malperfusion
    DISSECTION_RUPTURED = "dissection_ruptured"            # Ruptured dissection
    DISSECTION_IMH = "dissection_imh"                      # Intramural hematoma
    DISSECTION_PAU = "dissection_pau"                      # Penetrating atherosclerotic ulcer
    
    # === ATHEROSCLEROTIC DISEASES ===
    ATHEROSCLEROSIS = "atherosclerosis"                    # General atherosclerosis
    ATHEROSCLEROSIS_DIFFUSE = "atherosclerosis_diffuse"    # Diffuse atherosclerosis
    ATHEROSCLEROSIS_FOCAL = "atherosclerosis_focal"        # Focal atherosclerosis
    ATHEROSCLEROSIS_CALCIFIED = "atherosclerosis_calcified"  # Calcified atherosclerosis
    ATHEROSCLEROSIS_SOFT_PLAQUE = "atherosclerosis_soft"    # Soft plaque
    ATHEROSCLEROSIS_MIXED = "atherosclerosis_mixed"        # Mixed plaque
    ATHEROSCLEROSIS_ULCERATED = "atherosclerosis_ulcerated"  # Ulcerated plaque
    ATHEROSCLEROSIS_EROSIVE = "atherosclerosis_erosive"    # Erosive plaque
    ATHEROSCLEROSIS_HEMORRHAGIC = "atherosclerosis_hemorrhagic"  # Intraplaque hemorrhage
    ATHEROSCLEROSIS_LIPID_RICH = "atherosclerosis_lipid"   # Lipid-rich plaque
    ATHEROSCLEROSIS_FIBROTIC = "atherosclerosis_fibrotic"  # Fibrotic plaque
    
    PLAQUE = "plaque"                                      # General plaque
    PLAQUE_FIBROUS = "plaque_fibrous"                      # Fibrous plaque
    PLAQUE_FIBROFATTY = "plaque_fibrofatty"                # Fibrofatty plaque
    PLAQUE_CALCIFIED = "plaque_calcified"                  # Calcified plaque
    PLAQUE_SOFT = "plaque_soft"                            # Soft plaque
    PLAQUE_VULNERABLE = "plaque_vulnerable"                # Vulnerable plaque
    PLAQUE_STABLE = "plaque_stable"                        # Stable plaque
    PLAQUE_ULCERATED = "plaque_ulcerated"                  # Ulcerated plaque
    PLAQUE_ERODED = "plaque_eroded"                        # Eroded plaque
    
    CALCIFICATION = "calcification"                        # General calcification
    CALCIFICATION_INTIMAL = "calcification_intimal"        # Intimal calcification
    CALCIFICATION_MEDIAL = "calcification_medial"          # Medial calcification (Monckeberg)
    CALCIFICATION_CIRCUMFERENTIAL = "calcification_circumferential"  # Circumferential
    CALCIFICATION_SPOTTY = "calcification_spotty"          # Spotty calcification
    CALCIFICATION_HEAVY = "calcification_heavy"            # Heavy calcification
    CALCIFICATION_RIM = "calcification_rim"                # Rim calcification
    
    # === VASCULITIS ===
    VASCULITIS = "vasculitis"                              # General vasculitis
    VASCULITIS_LARGE_VESSEL = "vasculitis_large"           # Large vessel vasculitis
    VASCULITIS_MEDIUM_VESSEL = "vasculitis_medium"         # Medium vessel vasculitis
    VASCULITIS_SMALL_VESSEL = "vasculitis_small"           # Small vessel vasculitis
    
    TAKAYASU_ARTERITIS = "takayasu_arteritis"              # Takayasu arteritis
    GIANT_CELL_ARTERITIS = "giant_cell_arteritis"          # Giant cell (temporal) arteritis
    POLYARTERITIS_NODOSA = "polyarteritis_nodosa"          # Polyarteritis nodosa
    KAWASAKI_DISEASE = "kawasaki_disease"                  # Kawasaki disease
    BEHCET_DISEASE = "behcet_disease"                      # Behcet disease
    Buerger_DISEASE = "buerger_disease"                    # Thromboangiitis obliterans
    WEGENER_GRANULOMATOSIS = "wegener_granulomatosis"      # Granulomatosis with polyangiitis
    CHURG_STRAUSS = "churg_strauss"                        # Eosinophilic granulomatosis
    MICROSCOPIC_POLYANGIITIS = "microscopic_polyangiitis"  # Microscopic polyangiitis
    HENOCH_SCHONLEIN = "henoch_schonlein"                  # IgA vasculitis
    CRYOGLOBULINEMIA = "cryoglobulinemia"                  # Cryoglobulinemic vasculitis
    
    # === CONNECTIVE TISSUE DISORDERS ===
    MARFAN_SYNDROME = "marfan_syndrome"                    # Marfan syndrome
    EHRLERS_DANLOS = "ehrlers_danlos"                      # Ehlers-Danlos syndrome
    EHRLERS_DANLOS_TYPE_IV = "ehrlers_danlos_type_iv"      # Vascular type EDS
    LOEYS_DIETZ = "loeys_dietz"                            # Loeys-Dietz syndrome
    LOEYS_DIETZ_TYPE_I = "loeys_dietz_type_i"              # LDS type 1
    LOEYS_DIETZ_TYPE_II = "loeys_dietz_type_ii"            # LDS type 2
    TURNER_SYNDROME = "turner_syndrome"                    # Turner syndrome
    POLYCYSTIC_KIDNEY_DISEASE = "polycystic_kidney"        # ADPKD
    
    # === FIBROMUSCULAR DYSPLASIA ===
    FIBROMUSCULAR_DYSPLASIA = "fibromuscular_dysplasia"    # FMD
    FMD_MULTIFOCAL = "fmd_multifocal"                      # Multifocal FMD (string of beads)
    FMD_FOCAL = "fmd_focal"                                # Focal FMD
    FMD_MEDIAL = "fmd_medial"                              # Medial FMD
    FMD_INTIMAL = "fmd_intimal"                            # Intimal FMD
    FMD_ADVENTITIAL = "fmd_adventitial"                    # Adventitial FMD
    
    # === MALFORMATIONS ===
    AVM = "arteriovenous_malformation"                     # Arteriovenous malformation
    AVM_HIGH_FLOW = "avm_high_flow"                        # High-flow AVM
    AVM_LOW_FLOW = "avm_low_flow"                          # Low-flow AVM
    AVM_NIDUS = "avm_nidus"                                # AVM with nidus
    AVM_DIFFUSE = "avm_diffuse"                            # Diffuse AVM
    AVM_CIRRHOID = "avm_cirrhoid"                          # Cirsoid AVM
    
    AVF = "arteriovenous_fistula"                          # Arteriovenous fistula
    AVF_CONGENITAL = "avf_congenital"                      # Congenital AVF
    AVF_ACQUIRED = "avf_acquired"                          # Acquired AVF
    AVF_TRAUMATIC = "avf_traumatic"                        # Traumatic AVF
    AVF_IATROGENIC = "avf_iatrogenic"                      # Iatrogenic AVF
    AVF_DIALYSIS = "avf_dialysis"                          # Dialysis access AVF
    
    CAVF = "carotid_cavernous_fistula"                     # Carotid-cavernous fistula
    CAVF_DIRECT = "cavf_direct"                            # Direct (high-flow) CCF
    CAVF_INDIRECT = "cavf_indirect"                        # Indirect (low-flow) CCF
    
    ANGIOMA = "angioma"                                    # Hemangioma
    ANGIOMA_CAPILLARY = "angioma_capillary"                # Capillary hemangioma
    ANGIOMA_CAVERNOUS = "angioma_cavernous"                # Cavernous hemangioma
    ANGIOMA_VENOUS = "angioma_venous"                      # Venous malformation
    LYMPHANGIOMA = "lymphangioma"                          # Lymphatic malformation
    LYMPHANGIOMA_MICROCYSTIC = "lymphangioma_microcystic"  # Microcystic lymphangioma
    LYMPHANGIOMA_MACROCYSTIC = "lymphangioma_macrocystic"  # Macrocystic lymphangioma
    
    # === VENOUS DISEASES ===
    VARICOSE_VEINS = "varicose_veins"                      # Varicose veins
    VARICOSE_VEINS_PRIMARY = "varicose_veins_primary"      # Primary varicose veins
    VARICOSE_VEINS_SECONDARY = "varicose_veins_secondary"  # Secondary varicose veins
    VARICOSE_VEINS_RECURRENT = "varicose_veins_recurrent"  # Recurrent varicose veins
    
    VENOUS_INSUFFICIENCY = "venous_insufficiency"          # Chronic venous insufficiency
    VENOUS_INSUFFICIENCY_PRIMARY = "venous_insufficiency_primary"
    VENOUS_INSUFFICIENCY_SECONDARY = "venous_insufficiency_secondary"
    VENOUS_INSUFFICIENCY_CONGENITAL = "venous_insufficiency_congenital"
    
    VENOUS_THROMBOSIS = "venous_thrombosis"                # DVT
    VENOUS_THROMBOSIS_PROXIMAL = "venous_thrombosis_proximal"  # Proximal DVT
    VENOUS_THROMBOSIS_DISTAL = "venous_thrombosis_distal"  # Distal DVT
    VENOUS_THROMBOSIS_PHLEGMasia = "venous_thrombosis_phlegmasia"  # Phlegmasia
    
    POST_THROMBOTIC_SYNDROME = "post_thrombotic_syndrome"  # PTS
    POST_THROMBOTIC_SYNDROME_MILD = "pts_mild"             # Mild PTS
    POST_THROMBOTIC_SYNDROME_MODERATE = "pts_moderate"     # Moderate PTS
    POST_THROMBOTIC_SYNDROME_SEVERE = "pts_severe"         # Severe PTS
    
    MAY_THURNER_SYNDROME = "may_thurner_syndrome"          # May-Thurner syndrome
    NUTCRACKER_SYNDROME = "nutcracker_syndrome"            # Nutcracker syndrome
    PELVIC_CONGESTION = "pelvic_congestion"                # Pelvic congestion syndrome
    
    # === VASOSPASTIC DISORDERS ===
    VASOSPASM = "vasospasm"                                # Vasospasm
    VASOSPASM_REVERSIBLE = "vasospasm_reversible"          # Reversible vasospasm
    VASOSPASM_FIXED = "vasospasm_fixed"                    # Fixed vasospasm
    RAYNAUD_PHENOMENON = "raynaud_phenomenon"              # Raynaud phenomenon
    RAYNAUD_DISEASE = "raynaud_disease"                    # Raynaud disease (primary)
    RAYNAUD_SYNDROME = "raynaud_syndrome"                  # Raynaud syndrome (secondary)
    LIVEDO_RETICULARIS = "livedo_reticularis"              # Livedo reticularis
    LIVEDO_RACEMOSA = "livedo_racemosa"                    # Livedo racemosa
    ERYTHROMELALGIA = "erythromelalgia"                    # Erythromelalgia
    ACROCYANOSIS = "acrocyanosis"                          # Acrocyanosis
    
    # === COMPRESSION SYNDROMES ===
    COMPRESSION = "compression"                            # External compression
    COMPRESSION_MEDIAN_ARCADE = "compression_median_arcade"  # Median arcuate ligament
    COMPRESSION_POPITEAL_ENTRAPMENT = "compression_popliteal"  # Popliteal entrapment
    COMPRESSION_THORACIC_OUTLET = "compression_thoracic"   # Thoracic outlet syndrome
    COMPRESSION_PANCOAST = "compression_pancoast"          # Pancoast tumor compression
    COMPRESSION_URACHER = "compression_uracher"            # Urachal remnant compression
    
    # === TRAUMATIC LESIONS ===
    VASCULAR_TRAUMA = "vascular_trauma"                    # General vascular trauma
    VASCULAR_TRAUMA_BLUNT = "vascular_trauma_blunt"        # Blunt trauma
    VASCULAR_TRAUMA_PENETRATING = "vascular_trauma_penetrating"  # Penetrating trauma
    VASCULAR_TRAUMA_IATROGENIC = "vascular_trauma_iatrogenic"  # Iatrogenic injury
    VASCULAR_LACERATION = "vascular_laceration"            # Vessel laceration
    VASCULAR_CONTUSION = "vascular_contusion"              # Vessel contusion
    VASCULAR_AVULSION = "vascular_avulsion"                # Vessel avulsion
    VASCULAR_THROMBOSIS_TRAUMATIC = "vascular_thrombosis_traumatic"  # Post-traumatic thrombosis
    
    # === POST-INTERVENTIONAL LESIONS ===
    STENT_RESTENOSIS = "stent_restenosis"                  # In-stent restenosis
    STENT_RESTENOSIS_FOCAL = "stent_restenosis_focal"      # Focal ISR
    STENT_RESTENOSIS_DIFFUSE = "stent_restenosis_diffuse"  # Diffuse ISR
    STENT_RESTENOSIS_OCC_TOTAL = "stent_restenosis_occ"    # Occlusive ISR
    STENT_FRACTURE = "stent_fracture"                      # Stent fracture
    STENT_MIGRATION = "stent_migration"                    # Stent migration
    STENT_ENDOLEAK = "stent_endoleak"                      # Endoleak
    STENT_ENDOLEAK_TYPE_I = "endoleak_type_i"              # Type I endoleak
    STENT_ENDOLEAK_TYPE_II = "endoleak_type_ii"            # Type II endoleak
    STENT_ENDOLEAK_TYPE_III = "endoleak_type_iii"          # Type III endoleak
    STENT_ENDOLEAK_TYPE_IV = "endoleak_type_iv"            # Type IV endoleak
    STENT_ENDOLEAK_TYPE_V = "endoleak_type_v"              # Type V (endotension)
    
    GRAFT_STENOSIS = "graft_stenosis"                      # Bypass graft stenosis
    GRAFT_OCCLUSION = "graft_occlusion"                    # Bypass graft occlusion
    GRAFT_ANASTOMOTIC_STENOSIS = "graft_anastomotic"       # Anastomotic stenosis
    GRAFT_BODY_STENOSIS = "graft_body_stenosis"            # Graft body stenosis
    GRAFT_INTIMAL_HYPERPLASIA = "graft_intimal_hyperplasia"  # Intimal hyperplasia
    GRAFT_DEGENERATION = "graft_degeneration"              # Graft degeneration
    GRAFT_INFECTION = "graft_infection"                    # Graft infection
    GRAFT_PSEUDOANEURYSM = "graft_pseudoaneurysm"          # Graft pseudoaneurysm
    GRAFT_SEROMA = "graft_seroma"                          # Graft seroma
    
    ENDARTERECTOMY_RESTENOSIS = "endarterectomy_restenosis"  # Post-endarterectomy stenosis
    PATCH_STENOSIS = "patch_stenosis"                      # Patch stenosis
    PATCH_ANEURYSM = "patch_aneurysm"                      # Patch aneurysm
    
    # === INFLAMMATORY/INFECTIOUS ===
    VASCULITIS_INFECTIOUS = "vasculitis_infectious"        # Infectious vasculitis
    VASCULITIS_SYPHILITIC = "vasculitis_syphilitic"        # Syphilitic aortitis
    VASCULITIS_TUBERCULOUS = "vasculitis_tuberculous"      # Tuberculous vasculitis
    VASCULITIS_FUNGAL = "vasculitis_fungal"                # Fungal vasculitis
    
    PERIAORTITIS = "periaortitis"                          # Periaortitis
    PERIAORTITIS_IDIOPATHIC = "periaortitis_idiopathic"    # Idiopathic retroperitoneal fibrosis
    PERIAORTITIS_IGG4 = "periaortitis_igg4"                # IgG4-related disease
    PERIAORTITIS_INFECTIOUS = "periaortitis_infectious"    # Infectious periaortitis
    
    GRAFT_INFECTION_STAPH = "graft_infection_staph"        # Staphylococcal graft infection
    GRAFT_INFECTION_STREP = "graft_infection_strep"        # Streptococcal graft infection
    GRAFT_INFECTION_GRAM_NEG = "graft_infection_gram_neg"  # Gram-negative graft infection
    GRAFT_INFECTION_FUNGAL = "graft_infection_fungal"      # Fungal graft infection
    GRAFT_INFECTION_MYCOTIC = "graft_infection_mycotic"    # Mycotic graft infection
    
    # === NEOPLASTIC ===
    VASCULAR_TUMOR_BENIGN = "vascular_tumor_benign"        # Benign vascular tumor
    VASCULAR_TUMOR_MALIGNANT = "vascular_tumor_malignant"  # Malignant vascular tumor
    ANGIOSARCOMA = "angiosarcoma"                          # Angiosarcoma
    HEMANGIOPERICYTOMA = "hemangiopericytoma"              # Hemangiopericytoma
    GLOMUS_TUMOR = "glomus_tumor"                          # Glomus tumor
    EPITHELIOID_HEMANGIOENDOTHELIOMA = "epithelioid_hemangioendothelioma"
    
    TUMOR_INVASION = "tumor_invasion"                      # Tumor invasion into vessel
    TUMOR_COMPRESSION = "tumor_compression"                # Tumor compression
    TUMOR_THROMBUS = "tumor_thrombus"                      # Tumor thrombus
    
    # === FUNCTIONAL DISORDERS ===
    VASOMOTOR_INSTABILITY = "vasomotor_instability"        # Vasomotor instability
    POSTURAL_HYPOTENSION = "postural_hypotension"          # Postural hypotension
    NEUROCARDIOGENIC_SYNCope = "neurocardiogenic_syncope"  # Neurocardiogenic syncope
    
    # === MISCELLANEOUS ===
    ARTERIAL_TORTUOSITY = "arterial_tortuosity"            # Arterial tortuosity
    ARTERIAL_TORTUOSITY_SEVERE = "arterial_tortuosity_severe"  # Severe tortuosity
    ARTERIAL_KINKING = "arterial_kinking"                  # Arterial kinking
    ARTERIAL_COILING = "arterial_coiling"                  # Arterial coiling
    
    VASCULAR_ECTASIA = "vascular_ectasia"                  # Vascular ectasia
    ARTERIOMEGALY = "arteriomegaly"                        # Arteriomegaly
    
    CYSTIC_ADVENTITIAL_DISEASE = "cystic_adventitial"      # Cystic adventitial disease
    ADVENTITIAL_CYST = "adventitial_cyst"                  # Adventitial cyst
    
    SEGMENTAL_MEDIALYSIS = "segmental_medialysis"          # Segmental medialysis
    
    PIGMENTED_PURPURA = "pigmented_purpura"                # Pigmented purpura
    PURPURA_FULMINANS = "purpura_fulminans"                # Purpura fulminans
    
    LIVEDOID_VASCULOPATHY = "livedoid_vasculopathy"        # Livedoid vasculopathy
    ATROPHIE_BLANCHE = "atrophie_blanche"                  # Atrophie blanche
    
    CHOLESTEROL_EMBOLI = "cholesterol_emboli"              # Cholesterol embolization
    BLUE_TOE_SYNDROME = "blue_toe_syndrome"                # Blue toe syndrome
    
    COMPARTMENT_SYNDROME = "compartment_syndrome"          # Compartment syndrome
    COMPARTMENT_SYNDROME_ACUTE = "compartment_syndrome_acute"
    COMPARTMENT_SYNDROME_CHRONIC = "compartment_syndrome_chronic"
    
    ARTERIAL_ULCER = "arterial_ulcer"                      # Arterial ulcer
    VENOUS_ULCER = "venous_ulcer"                          # Venous ulcer
    MIXED_ULCER = "mixed_ulcer"                            # Mixed etiology ulcer
    DIABETIC_FOOT_ULCER = "diabetic_foot_ulcer"            # Diabetic foot ulcer
    
    GANGRENE = "gangrene"                                  # Gangrene
    GANGRENE_DRY = "gangrene_dry"                          # Dry gangrene
    GANGRENE_WET = "gangrene_wet"                          # Wet gangrene
    GANGRENE_GAS = "gangrene_gas"                          # Gas gangrene
    
    NORMAL = "normal"                                      # Normal finding
    
    # === COMPLICATIONS ===
    ISCHEMIA = "ischemia"                                  # Ischemia
    ISCHEMIA_ACUTE = "ischemia_acute"                      # Acute ischemia
    ISCHEMIA_CHRONIC = "ischemia_chronic"                  # Chronic ischemia
    ISCHEMIA_CRITICAL = "ischemia_critical"                # Critical limb ischemia
    ISCHEMIA_SUBCRITICAL = "ischemia_subcritical"          # Subcritical ischemia
    
    INFARCTION = "infarction"                              # Infarction
    INFARCTION_MYOCARDIAL = "infarction_myocardial"        # Myocardial infarction
    INFARCTION_STROKE = "infarction_stroke"                # Stroke
    INFARCTION_RENAL = "infarction_renal"                  # Renal infarction
    INFARCTION_MESENTERIC = "infarction_mesenteric"        # Mesenteric infarction
    INFARCTION_SPLENIC = "infarction_splenic"              # Splenic infarction
    
    HEMORRHAGE = "hemorrhage"                              # Hemorrhage
    HEMORRHAGE_INTRAMURAL = "hemorrhage_intramural"        # Intramural hemorrhage
    HEMORRHAGE Retroperitoneal = "hemorrhage_retroperitoneal"  # Retroperitoneal hemorrhage
    HEMORRHAGE_INTRAPERITONEAL = "hemorrhage_intraperitoneal"  # Intraperitoneal hemorrhage
    
    MALPERFUSION = "malperfusion"                          # Malperfusion syndrome
    MALPERFUSION_VISCERAL = "malperfusion_visceral"        # Visceral malperfusion
    MALPERFUSION_RENAL = "malperfusion_renal"              # Renal malperfusion
    MALPERFUSION_SPINAL = "malperfusion_spinal"            # Spinal malperfusion
    MALPERFUSION_LOWER_EXTREMITY = "malperfusion_le"       # Lower extremity malperfusion
    
    HEART_FAILURE = "heart_failure"                        # Heart failure
    AORTIC_REGURGITATION = "aortic_regurgitation"          # Aortic regurgitation
    CARDIAC_TAMPONADE = "cardiac_tamponade"                # Cardiac tamponade
    
    RUPTURE = "rupture"                                    # Vessel rupture
    RUPTURE_FREE = "rupture_free"                          # Free rupture
    RUPTURE_CONTAINED = "rupture_contained"                # Contained rupture
    RUPTURE_AORTOENTERIC = "rupture_aortoenteric"          # Aortoenteric fistula
    RUPTURE_AORTOCAVAL = "rupture_aortocaval"              # Aortocaval fistula
    RUPTURE_AORTOPULMONARY = "rupture_aortopulmonary"      # Aortopulmonary fistula
    
    INFECTION = "infection"                                # General infection
    ABSCESS = "abscess"                                    # Abscess
    SEPSIS = "sepsis"                                      # Sepsis
    ENDOCARDITIS = "endocarditis"                          # Infective endocarditis


# Pathology severity classification
class PathologySeverity(Enum):
    """Severity levels for vascular pathologies"""
    NORMAL = "normal"                                      # Normal, no pathology
    MINIMAL = "minimal"                                    # Minimal changes
    MILD = "mild"                                          # Mild pathology
    MODERATE = "moderate"                                  # Moderate pathology
    SEVERE = "severe"                                      # Severe pathology
    CRITICAL = "critical"                                  # Critical, life-threatening
    EXTREME = "extreme"                                    # Extreme, imminent danger


# Pathology acuity classification
class PathologyAcuity(Enum):
    """Temporal classification of pathologies"""
    CHRONIC = "chronic"                                    # Chronic (>3 months)
    SUBACUTE = "subacute"                                  # Subacute (2 weeks - 3 months)
    ACUTE = "acute"                                        # Acute (<2 weeks)
    HYPERACUTE = "hyperacute"                              # Hyperacute (<24 hours)
    RECURRENT = "recurrent"                                # Recurrent episodes


# Clinical significance classification
class ClinicalSignificance(Enum):
    """Clinical significance of findings"""
    INCIDENTAL = "incidental"                              # Incidental finding
    MONITOR = "monitor"                                    # Requires monitoring
    TREATMENT_ELECTIVE = "treatment_elective"              # Elective treatment
    TREATMENT_URGENT = "treatment_urgent"                  # Urgent treatment
    TREATMENT_EMERGENCY = "treatment_emergency"            # Emergency treatment
    LIFE_THREATENING = "life_threatening"                  # Life-threatening


@dataclass
class PathologyClassification:
    """Complete pathology classification"""
    pathology_type: PathologyType
    category: PathologyCategory
    severity: PathologySeverity
    acuity: PathologyAcuity
    significance: ClinicalSignificance
    
    # Location details
    vessel_name: str
    vessel_segment: Optional[str] = None
    side: Optional[str] = None  # left, right, bilateral
    
    # Morphological details
    size_mm: Optional[float] = None
    length_mm: Optional[float] = None
    degree_percent: Optional[float] = None  # For stenosis
    
    # Additional characteristics
    calcification: Optional[str] = None
    thrombus: bool = False
    ulceration: bool = False
    hemorrhage: bool = False
    
    # Clinical context
    symptoms: List[str] = None
    risk_factors: List[str] = None
    complications: List[str] = None
    
    def __post_init__(self):
        if self.symptoms is None:
            self.symptoms = []
        if self.risk_factors is None:
            self.risk_factors = []
        if self.complications is None:
            self.complications = []


# Pathology descriptions for UI
def get_pathology_description(pathology_type: PathologyType) -> Dict[str, str]:
    """Get human-readable description of pathology"""
    descriptions = {
        # Aneurysms
        PathologyType.ANEURYSM: {
            "name": "Aneurysm",
            "name_ru": "Аневризма",
            "description": "Localized dilation of a blood vessel exceeding 50% of normal diameter",
            "description_ru": "Ограниченное расширение сосуда более чем на 50% от нормального диаметра",
        },
        PathologyType.ANEURYSM_SACCULAR: {
            "name": "Saccular Aneurysm",
            "name_ru": "Мешотчатая аневризма",
            "description": "Berry-like outpouching with neck connecting to parent vessel",
            "description_ru": "Ягодообразное выпячивание с шейкой, соединяющейся с материнским сосудом",
        },
        PathologyType.ANEURYSM_FUSIFORM: {
            "name": "Fusiform Aneurysm",
            "name_ru": "Фузиформная аневризма",
            "description": "Spindle-shaped dilation involving entire circumference",
            "description_ru": "Веретенообразное расширение, вовлекающее всю окружность сосуда",
        },
        PathologyType.ANEURYSM_DISSECTING: {
            "name": "Dissecting Aneurysm",
            "name_ru": "Диссекцирующая аневризма",
            "description": "Aneurysm resulting from arterial dissection",
            "description_ru": "Аневризма, возникшая в результате диссекции артерии",
        },
        PathologyType.ANEURYSM_MYCOTIC: {
            "name": "Mycotic Aneurysm",
            "name_ru": "Микотическая аневризма",
            "description": "Infectious aneurysm caused by bacterial or fungal infection",
            "description_ru": "Инфекционная аневризма, вызванная бактериальной или грибковой инфекцией",
        },
        PathologyType.PSEUDOANEURYSM: {
            "name": "Pseudoaneurysm",
            "name_ru": "Ложная аневризма",
            "description": "Contained rupture with blood collection outside vessel wall",
            "description_ru": "Ограниченный разрыв с скоплением крови вне стенки сосуда",
        },
        
        # Stenosis
        PathologyType.STENOSIS: {
            "name": "Stenosis",
            "name_ru": "Стеноз",
            "description": "Narrowing of blood vessel lumen",
            "description_ru": "Сужение просвета кровеносного сосуда",
        },
        PathologyType.STENOSIS_CALCIFIED: {
            "name": "Calcified Stenosis",
            "name_ru": "Кальцинированный стеноз",
            "description": "Stenosis with significant calcification",
            "description_ru": "Стеноз со значительной кальцификацией",
        },
        PathologyType.STENOSIS_SOFT_PLAQUE: {
            "name": "Soft Plaque Stenosis",
            "name_ru": "Стеноз мягкой бляшкой",
            "description": "Stenosis caused by non-calcified, lipid-rich plaque",
            "description_ru": "Стеноз, вызванный некальцинированной, богатой липидами бляшкой",
        },
        PathologyType.STENOSIS_ULCERATED: {
            "name": "Ulcerated Stenosis",
            "name_ru": "Язвенный стеноз",
            "description": "Stenosis with ulcerated plaque surface",
            "description_ru": "Стеноз с язвенной поверхностью бляшки",
        },
        
        # Occlusion
        PathologyType.OCCLUSION: {
            "name": "Occlusion",
            "name_ru": "Окклюзия",
            "description": "Complete blockage of blood vessel",
            "description_ru": "Полная закупорка кровеносного сосуда",
        },
        PathologyType.OCCLUSION_CHRONIC_TOTAL: {
            "name": "Chronic Total Occlusion",
            "name_ru": "Хроническая тотальная окклюзия",
            "description": "Complete occlusion present for >3 months",
            "description_ru": "Полная окклюзия, существующая более 3 месяцев",
        },
        
        # Thrombosis
        PathologyType.THROMBOSIS: {
            "name": "Thrombosis",
            "name_ru": "Тромбоз",
            "description": "Formation of blood clot within vessel",
            "description_ru": "Образование тромба внутри сосуда",
        },
        PathologyType.THROMBOSIS_ACUTE: {
            "name": "Acute Thrombosis",
            "name_ru": "Острый тромбоз",
            "description": "Fresh thrombus <14 days old",
            "description_ru": "Свежий тромб возрастом <14 дней",
        },
        PathologyType.THROMBOSIS_CHRONIC: {
            "name": "Chronic Thrombosis",
            "name_ru": "Хронический тромбоз",
            "description": "Organized thrombus >28 days old",
            "description_ru": "Организованный тромб возрастом >28 дней",
        },
        
        # Dissection
        PathologyType.DISSECTION: {
            "name": "Dissection",
            "name_ru": "Диссекция",
            "description": "Tear in vessel wall creating false lumen",
            "description_ru": "Разрыв стенки сосуда с образованием ложного просвета",
        },
        PathologyType.DISSECTION_TYPE_A: {
            "name": "Type A Dissection",
            "name_ru": "Диссекция типа A",
            "description": "Involves ascending aorta (Stanford classification)",
            "description_ru": "Вовлекает восходящую аорту (классификация Стэнфорда)",
        },
        PathologyType.DISSECTION_TYPE_B: {
            "name": "Type B Dissection",
            "name_ru": "Диссекция типа B",
            "description": "Does not involve ascending aorta (Stanford classification)",
            "description_ru": "Не вовлекает восходящую аорту (классификация Стэнфорда)",
        },
        
        # Atherosclerosis
        PathologyType.ATHEROSCLEROSIS: {
            "name": "Atherosclerosis",
            "name_ru": "Атеросклероз",
            "description": "Chronic inflammatory disease with plaque formation",
            "description_ru": "Хроническое воспалительное заболевание с образованием бляшек",
        },
        PathologyType.ATHEROSCLEROSIS_DIFFUSE: {
            "name": "Diffuse Atherosclerosis",
            "name_ru": "Диффузный атеросклероз",
            "description": "Extensive atherosclerotic involvement of vessel",
            "description_ru": "Обширное атеросклеротическое поражение сосуда",
        },
        
        # Vasculitis
        PathologyType.VASCULITIS: {
            "name": "Vasculitis",
            "name_ru": "Васкулит",
            "description": "Inflammation of blood vessel walls",
            "description_ru": "Воспаление стенок кровеносных сосудов",
        },
        PathologyType.TAKAYASU_ARTERITIS: {
            "name": "Takayasu Arteritis",
            "name_ru": "Артериит Такаясу",
            "description": "Large vessel vasculitis affecting aorta and branches",
            "description_ru": "Васкулит крупных сосудов, поражающий аорту и ветви",
        },
        PathologyType.GIANT_CELL_ARTERITIS: {
            "name": "Giant Cell Arteritis",
            "name_ru": "Гигантоклеточный артериит",
            "description": "Large vessel vasculitis typically affecting temporal arteries",
            "description_ru": "Васкулит крупных сосудов, обычно поражающий височные артерии",
        },
        
        # FMD
        PathologyType.FIBROMUSCULAR_DYSPLASIA: {
            "name": "Fibromuscular Dysplasia",
            "name_ru": "Фибромышечная дисплазия",
            "description": "Non-atherosclerotic vascular disease with abnormal cell growth",
            "description_ru": "Неатеросклеротическое сосудистое заболевание с аномальным ростом клеток",
        },
        PathologyType.FMD_MULTIFOCAL: {
            "name": "Multifocal FMD",
            "name_ru": "Многоочаговая ФМД",
            "description": "String of beads appearance on angiography",
            "description_ru": "Внешний вид 'низанки бус' на ангиографии",
        },
        
        # AVM/AVF
        PathologyType.AVM: {
            "name": "Arteriovenous Malformation",
            "name_ru": "Артериовенозная мальформация",
            "description": "Congenital connection between arteries and veins without capillary bed",
            "description_ru": "Врожденное соединение артерий и вен без капиллярного русла",
        },
        PathologyType.AVF: {
            "name": "Arteriovenous Fistula",
            "name_ru": "Артериовенозная фистула",
            "description": "Direct connection between artery and vein",
            "description_ru": "Прямое соединение между артерией и веной",
        },
        
        # Venous diseases
        PathologyType.VENOUS_INSUFFICIENCY: {
            "name": "Chronic Venous Insufficiency",
            "name_ru": "Хроническая венозная недостаточность",
            "description": "Impaired venous return causing venous hypertension",
            "description_ru": "Нарушение венозного оттока, вызывающее венозную гипертензию",
        },
        PathologyType.VENOUS_THROMBOSIS: {
            "name": "Deep Vein Thrombosis",
            "name_ru": "Тромбоз глубоких вен",
            "description": "Thrombosis of deep venous system",
            "description_ru": "Тромбоз глубокой венозной системы",
        },
        
        # Vasospastic
        PathologyType.RAYNAUD_PHENOMENON: {
            "name": "Raynaud Phenomenon",
            "name_ru": "Феномен Рейно",
            "description": "Episodic vasospasm of digital arteries",
            "description_ru": "Эпизодический вазоспазм артерий пальцев",
        },
        
        # Post-interventional
        PathologyType.STENT_RESTENOSIS: {
            "name": "In-Stent Restenosis",
            "name_ru": "Рестеноз внутри стента",
            "description": "Recurrent stenosis within previously placed stent",
            "description_ru": "Рецидивирующий стеноз внутри ранее установленного стента",
        },
        PathologyType.GRAFT_STENOSIS: {
            "name": "Bypass Graft Stenosis",
            "name_ru": "Стеноз шунта",
            "description": "Stenosis within bypass graft",
            "description_ru": "Стеноз внутри шунта",
        },
        
        # Trauma
        PathologyType.VASCULAR_TRAUMA: {
            "name": "Vascular Trauma",
            "name_ru": "Травма сосуда",
            "description": "Injury to blood vessel from external force",
            "description_ru": "Повреждение кровеносного сосуда от внешней силы",
        },
        
        # Complications
        PathologyType.ISCHEMIA_CRITICAL: {
            "name": "Critical Limb Ischemia",
            "name_ru": "Критическая ишемия конечности",
            "description": "Severe peripheral arterial disease with rest pain or tissue loss",
            "description_ru": "Тяжелое заболевание периферических артерий с болью в покое или потерей тканей",
        },
        PathologyType.GANGRENE: {
            "name": "Gangrene",
            "name_ru": "Гангрена",
            "description": "Tissue necrosis due to inadequate blood supply",
            "description_ru": "Некроз тканей из-за недостаточного кровоснабжения",
        },
        
        # Normal
        PathologyType.NORMAL: {
            "name": "Normal",
            "name_ru": "Норма",
            "description": "No pathological findings detected",
            "description_ru": "Патологических изменений не выявлено",
        },
    }
    
    return descriptions.get(pathology_type, {
        "name": pathology_type.value.replace("_", " ").title(),
        "name_ru": pathology_type.value.replace("_", " ").title(),
        "description": "Vascular pathology",
        "description_ru": "Сосудистая патология",
    })


# Get all pathology types by category
def get_pathologies_by_category(category: PathologyCategory) -> List[PathologyType]:
    """Get all pathologies belonging to a specific category"""
    category_map = {
        PathologyCategory.DEGENERATIVE: [
            PathologyType.ATHEROSCLEROSIS,
            PathologyType.ATHEROSCLEROSIS_DIFFUSE,
            PathologyType.ATHEROSCLEROSIS_FOCAL,
            PathologyType.ATHEROSCLEROSIS_CALCIFIED,
            PathologyType.ATHEROSCLEROSIS_SOFT_PLAQUE,
            PathologyType.ATHEROSCLEROSIS_MIXED,
            PathologyType.ATHEROSCLEROSIS_ULCERATED,
            PathologyType.ATHEROSCLEROSIS_EROSIVE,
            PathologyType.ATHEROSCLEROSIS_HEMORRHAGIC,
            PathologyType.ATHEROSCLEROSIS_LIPID_RICH,
            PathologyType.ATHEROSCLEROSIS_FIBROTIC,
            PathologyType.PLAQUE,
            PathologyType.PLAQUE_FIBROUS,
            PathologyType.PLAQUE_FIBROFATTY,
            PathologyType.PLAQUE_CALCIFIED,
            PathologyType.PLAQUE_SOFT,
            PathologyType.PLAQUE_VULNERABLE,
            PathologyType.PLAQUE_STABLE,
            PathologyType.PLAQUE_ULCERATED,
            PathologyType.PLAQUE_ERODED,
            PathologyType.CALCIFICATION,
            PathologyType.CALCIFICATION_INTIMAL,
            PathologyType.CALCIFICATION_MEDIAL,
            PathologyType.CALCIFICATION_CIRCUMFERENTIAL,
            PathologyType.CALCIFICATION_SPOTTY,
            PathologyType.CALCIFICATION_HEAVY,
            PathologyType.CALCIFICATION_RIM,
            PathologyType.ARTERIAL_TORTUOSITY,
            PathologyType.ARTERIAL_TORTUOSITY_SEVERE,
            PathologyType.ARTERIAL_KINKING,
            PathologyType.ARTERIAL_COILING,
            PathologyType.VASCULAR_ECTASIA,
            PathologyType.ARTERIOMEGALY,
        ],
        PathologyCategory.INFLAMMATORY: [
            PathologyType.VASCULITIS,
            PathologyType.VASCULITIS_LARGE_VESSEL,
            PathologyType.VASCULITIS_MEDIUM_VESSEL,
            PathologyType.VASCULITIS_SMALL_VESSEL,
            PathologyType.TAKAYASU_ARTERITIS,
            PathologyType.GIANT_CELL_ARTERITIS,
            PathologyType.POLYARTERITIS_NODOSA,
            PathologyType.KAWASAKI_DISEASE,
            PathologyType.BEHCET_DISEASE,
            PathologyType.Buerger_DISEASE,
            PathologyType.WEGENER_GRANULOMATOSIS,
            PathologyType.CHURG_STRAUSS,
            PathologyType.MICROSCOPIC_POLYANGIITIS,
            PathologyType.HENOCH_SCHONLEIN,
            PathologyType.CRYOGLOBULINEMIA,
            PathologyType.ANEURYSM_INFLAMMATORY,
            PathologyType.ANEURYSM_INFLAMMATORY_AORTIC,
            PathologyType.PERIAORTITIS,
            PathologyType.PERIAORTITIS_IDIOPATHIC,
            PathologyType.PERIAORTITIS_IGG4,
        ],
        PathologyCategory.INFECTIOUS: [
            PathologyType.ANEURYSM_MYCOTIC,
            PathologyType.VASCULITIS_INFECTIOUS,
            PathologyType.VASCULITIS_SYPHILITIC,
            PathologyType.VASCULITIS_TUBERCULOUS,
            PathologyType.VASCULITIS_FUNGAL,
            PathologyType.PERIAORTITIS_INFECTIOUS,
            PathologyType.GRAFT_INFECTION,
            PathologyType.GRAFT_INFECTION_STAPH,
            PathologyType.GRAFT_INFECTION_STREP,
            PathologyType.GRAFT_INFECTION_GRAM_NEG,
            PathologyType.GRAFT_INFECTION_FUNGAL,
            PathologyType.GRAFT_INFECTION_MYCOTIC,
            PathologyType.INFECTION,
            PathologyType.ABSCESS,
            PathologyType.SEPSIS,
            PathologyType.ENDOCARDITIS,
        ],
        PathologyCategory.TRAUMATIC: [
            PathologyType.ANEURYSM_TRAUMATIC,
            PathologyType.PSEUDOANEURYSM,
            PathologyType.VASCULAR_TRAUMA,
            PathologyType.VASCULAR_TRAUMA_BLUNT,
            PathologyType.VASCULAR_TRAUMA_PENETRATING,
            PathologyType.VASCULAR_TRAUMA_IATROGENIC,
            PathologyType.VASCULAR_LACERATION,
            PathologyType.VASCULAR_CONTUSION,
            PathologyType.VASCULAR_AVULSION,
            PathologyType.VASCULAR_THROMBOSIS_TRAUMATIC,
            PathologyType.DISSECTION_TRAUMATIC,
            PathologyType.AVF_TRAUMATIC,
        ],
        PathologyCategory.CONGENITAL: [
            PathologyType.AVM,
            PathologyType.AVM_HIGH_FLOW,
            PathologyType.AVM_LOW_FLOW,
            PathologyType.AVM_NIDUS,
            PathologyType.AVM_DIFFUSE,
            PathologyType.AVM_CIRRHOID,
            PathologyType.AVF_CONGENITAL,
            PathologyType.ANGIOMA,
            PathologyType.ANGIOMA_CAPILLARY,
            PathologyType.ANGIOMA_CAVERNOUS,
            PathologyType.ANGIOMA_VENOUS,
            PathologyType.LYMPHANGIOMA,
            PathologyType.LYMPHANGIOMA_MICROCYSTIC,
            PathologyType.LYMPHANGIOMA_MACROCYSTIC,
            PathologyType.ARTERIAL_TORTUOSITY,
            PathologyType.ARTERIAL_COILING,
            PathologyType.MARFAN_SYNDROME,
            PathologyType.EHRLERS_DANLOS,
            PathologyType.EHRLERS_DANLOS_TYPE_IV,
            PathologyType.LOEYS_DIETZ,
            PathologyType.LOEYS_DIETZ_TYPE_I,
            PathologyType.LOEYS_DIETZ_TYPE_II,
            PathologyType.TURNER_SYNDROME,
            PathologyType.POLYCYSTIC_KIDNEY_DISEASE,
        ],
        PathologyCategory.IATROGENIC: [
            PathologyType.STENT_RESTENOSIS,
            PathologyType.STENT_RESTENOSIS_FOCAL,
            PathologyType.STENT_RESTENOSIS_DIFFUSE,
            PathologyType.STENT_RESTENOSIS_OCC_TOTAL,
            PathologyType.STENT_FRACTURE,
            PathologyType.STENT_MIGRATION,
            PathologyType.STENT_ENDOLEAK,
            PathologyType.STENT_ENDOLEAK_TYPE_I,
            PathologyType.STENT_ENDOLEAK_TYPE_II,
            PathologyType.STENT_ENDOLEAK_TYPE_III,
            PathologyType.STENT_ENDOLEAK_TYPE_IV,
            PathologyType.STENT_ENDOLEAK_TYPE_V,
            PathologyType.GRAFT_STENOSIS,
            PathologyType.GRAFT_OCCLUSION,
            PathologyType.GRAFT_ANASTOMOTIC_STENOSIS,
            PathologyType.GRAFT_BODY_STENOSIS,
            PathologyType.GRAFT_INTIMAL_HYPERPLASIA,
            PathologyType.GRAFT_DEGENERATION,
            PathologyType.GRAFT_INFECTION,
            PathologyType.GRAFT_PSEUDOANEURYSM,
            PathologyType.GRAFT_SEROMA,
            PathologyType.ENDARTERECTOMY_RESTENOSIS,
            PathologyType.PATCH_STENOSIS,
            PathologyType.PATCH_ANEURYSM,
            PathologyType.AVF_IATROGENIC,
            PathologyType.AVF_DIALYSIS,
            PathologyType.VASCULAR_TRAUMA_IATROGENIC,
            PathologyType.STENOSIS_POST_RADIATION,
        ],
        PathologyCategory.SYSTEMIC: [
            PathologyType.MARFAN_SYNDROME,
            PathologyType.EHRLERS_DANLOS,
            PathologyType.EHRLERS_DANLOS_TYPE_IV,
            PathologyType.LOEYS_DIETZ,
            PathologyType.LOEYS_DIETZ_TYPE_I,
            PathologyType.LOEYS_DIETZ_TYPE_II,
            PathologyType.TURNER_SYNDROME,
            PathologyType.POLYCYSTIC_KIDNEY_DISEASE,
            PathologyType.FIBROMUSCULAR_DYSPLASIA,
            PathologyType.FMD_MULTIFOCAL,
            PathologyType.FMD_FOCAL,
            PathologyType.FMD_MEDIAL,
            PathologyType.FMD_INTIMAL,
            PathologyType.FMD_ADVENTITIAL,
        ],
        PathologyCategory.NEOPLASTIC: [
            PathologyType.VASCULAR_TUMOR_BENIGN,
            PathologyType.VASCULAR_TUMOR_MALIGNANT,
            PathologyType.ANGIOSARCOMA,
            PathologyType.HEMANGIOPERICYTOMA,
            PathologyType.GLOMUS_TUMOR,
            PathologyType.EPITHELIOID_HEMANGIOENDOTHELIOMA,
            PathologyType.TUMOR_INVASION,
            PathologyType.TUMOR_COMPRESSION,
            PathologyType.TUMOR_THROMBUS,
        ],
        PathologyCategory.FUNCTIONAL: [
            PathologyType.VASOSPASM,
            PathologyType.VASOSPASM_REVERSIBLE,
            PathologyType.VASOSPASM_FIXED,
            PathologyType.RAYNAUD_PHENOMENON,
            PathologyType.RAYNAUD_DISEASE,
            PathologyType.RAYNAUD_SYNDROME,
            PathologyType.LIVEDO_RETICULARIS,
            PathologyType.LIVEDO_RACEMOSA,
            PathologyType.ERYTHROMELALGIA,
            PathologyType.ACROCYANOSIS,
            PathologyType.VASOMOTOR_INSTABILITY,
            PathologyType.POSTURAL_HYPOTENSION,
            PathologyType.NEUROCARDIOGENIC_SYNCope,
        ],
    }
    
    return category_map.get(category, [])


# Total count
PATHOLOGY_COUNT = len(PathologyType)
print(f"Total pathologies defined: {PATHOLOGY_COUNT}")
