"""
DICOM File Validation
Production-ready DICOM validation with security checks
"""
import os
import io
import magic
from typing import Tuple, Optional, Dict, Any
from pydicom import dcmread
from pydicom.errors import InvalidDicomError
from pydicom.dataset import FileDataset
import logging

from app.core.config import get_settings

logger = logging.getLogger(__name__)


class DICOMValidationError(Exception):
    """Custom exception for DICOM validation errors"""
    def __init__(self, message: str, code: str = "VALIDATION_ERROR", details: Dict = None):
        self.message = message
        self.code = code
        self.details = details or {}
        super().__init__(self.message)


class DICOMValidator:
    """
    DICOM file validator with comprehensive security and integrity checks.
    """
    
    # Allowed DICOM MIME types
    ALLOWED_MIME_TYPES = {
        "application/dicom",
        "application/dicom+json",
        "application/octet-stream",  # Some DICOM files may have this
    }
    
    # Required DICOM tags for valid medical images
    REQUIRED_TAGS = [
        (0x0008, 0x0016),  # SOP Class UID
        (0x0008, 0x0018),  # SOP Instance UID
        (0x0020, 0x000D),  # Study Instance UID
        (0x0020, 0x000E),  # Series Instance UID
    ]
    
    # Optional but recommended tags
    RECOMMENDED_TAGS = [
        (0x0010, 0x0010),  # Patient Name
        (0x0010, 0x0020),  # Patient ID
        (0x0008, 0x0060),  # Modality
        (0x0008, 0x0070),  # Manufacturer
        (0x0008, 0x1030),  # Study Description
        (0x0020, 0x0011),  # Series Number
        (0x0020, 0x0013),  # Instance Number
    ]
    
    # Supported modalities for vascular imaging
    SUPPORTED_MODALITIES = {
        "CT",    # Computed Tomography
        "MR",    # Magnetic Resonance
        "XA",    # X-Ray Angiography
        "US",    # Ultrasound
        "PT",    # PET
        "NM",    # Nuclear Medicine
    }
    
    def __init__(self):
        self.settings = get_settings()
    
    async def validate_file(
        self,
        file_path: str,
        check_magic: bool = True,
        check_tags: bool = True,
        check_modality: bool = True,
        max_file_size: Optional[int] = None
    ) -> Tuple[bool, Dict[str, Any]]:
        """
        Validate a DICOM file comprehensively.
        
        Args:
            file_path: Path to the DICOM file
            check_magic: Check file magic bytes
            check_tags: Verify required DICOM tags
            check_modality: Verify supported modality
            max_file_size: Maximum allowed file size
            
        Returns:
            Tuple of (is_valid, validation_info)
        """
        validation_info = {
            "file_path": file_path,
            "is_valid": False,
            "checks": {},
            "warnings": [],
            "metadata": {}
        }
        
        try:
            # Check file exists
            if not os.path.exists(file_path):
                raise DICOMValidationError(
                    "File not found",
                    "FILE_NOT_FOUND",
                    {"path": file_path}
                )
            
            # Check file size
            file_size = os.path.getsize(file_path)
            validation_info["file_size"] = file_size
            
            max_size = max_file_size or self.settings.DICOM_MAX_FILE_SIZE
            if file_size > max_size:
                raise DICOMValidationError(
                    f"File size {file_size} bytes exceeds maximum {max_size} bytes",
                    "FILE_TOO_LARGE",
                    {"size": file_size, "max_size": max_size}
                )
            
            validation_info["checks"]["file_size"] = True
            
            # Check magic bytes
            if check_magic:
                is_dicom = await self._check_magic_bytes(file_path)
                validation_info["checks"]["magic_bytes"] = is_dicom
                
                if not is_dicom:
                    # Try to read anyway - some valid DICOM files may not have magic bytes
                    logger.warning(f"File {file_path} doesn't have DICOM magic bytes, attempting to read anyway")
            
            # Parse and validate DICOM structure
            if check_tags:
                ds, tag_info = await self._validate_dicom_tags(file_path)
                validation_info["checks"]["dicom_tags"] = True
                validation_info["metadata"] = tag_info
                
                # Check modality
                if check_modality and tag_info.get("modality"):
                    modality = tag_info["modality"]
                    if modality not in self.SUPPORTED_MODALITIES:
                        validation_info["warnings"].append(
                            f"Modality '{modality}' may not be optimal for vascular analysis. "
                            f"Supported modalities: {', '.join(self.SUPPORTED_MODALITIES)}"
                        )
            
            validation_info["is_valid"] = True
            logger.info(f"DICOM validation passed for {file_path}")
            
        except DICOMValidationError as e:
            validation_info["error"] = {
                "message": e.message,
                "code": e.code,
                "details": e.details
            }
            logger.warning(f"DICOM validation failed for {file_path}: {e.message}")
            
        except InvalidDicomError as e:
            validation_info["error"] = {
                "message": f"Invalid DICOM file: {str(e)}",
                "code": "INVALID_DICOM"
            }
            logger.warning(f"Invalid DICOM file {file_path}: {e}")
            
        except Exception as e:
            validation_info["error"] = {
                "message": f"Unexpected error during validation: {str(e)}",
                "code": "VALIDATION_ERROR"
            }
            logger.error(f"Unexpected error validating {file_path}: {e}", exc_info=True)
        
        return validation_info["is_valid"], validation_info
    
    async def validate_buffer(
        self,
        buffer: bytes,
        filename: str = "unknown",
        **kwargs
    ) -> Tuple[bool, Dict[str, Any]]:
        """
        Validate DICOM data from a buffer.
        
        Args:
            buffer: DICOM data as bytes
            filename: Original filename for logging
            **kwargs: Additional validation options
            
        Returns:
            Tuple of (is_valid, validation_info)
        """
        # Write to temp file for validation
        import tempfile
        
        with tempfile.NamedTemporaryFile(delete=False, suffix=".dcm") as tmp:
            tmp.write(buffer)
            tmp_path = tmp.name
        
        try:
            return await self.validate_file(tmp_path, **kwargs)
        finally:
            # Clean up temp file
            try:
                os.unlink(tmp_path)
            except:
                pass
    
    async def _check_magic_bytes(self, file_path: str) -> bool:
        """Check if file has DICOM magic bytes"""
        try:
            # Read first 132 bytes (DICOM preamble + magic)
            with open(file_path, 'rb') as f:
                header = f.read(132)
            
            if len(header) < 132:
                return False
            
            # Check for "DICM" magic at offset 128
            magic = header[128:132]
            return magic == b'DICM'
            
        except Exception as e:
            logger.error(f"Error checking magic bytes: {e}")
            return False
    
    async def _validate_dicom_tags(self, file_path: str) -> Tuple[FileDataset, Dict]:
        """Validate required DICOM tags and extract metadata"""
        try:
            # Read DICOM file
            ds = dcmread(file_path, force=True)
            
            # Check required tags
            missing_tags = []
            for tag in self.REQUIRED_TAGS:
                if tag not in ds:
                    missing_tags.append(tag)
            
            if missing_tags:
                tag_names = [f"{tag[0]:04X},{tag[1]:04X}" for tag in missing_tags]
                raise DICOMValidationError(
                    f"Missing required DICOM tags: {', '.join(tag_names)}",
                    "MISSING_REQUIRED_TAGS",
                    {"missing_tags": tag_names}
                )
            
            # Extract metadata
            metadata = {
                "sop_class_uid": getattr(ds, "SOPClassUID", None),
                "sop_instance_uid": getattr(ds, "SOPInstanceUID", None),
                "study_instance_uid": getattr(ds, "StudyInstanceUID", None),
                "series_instance_uid": getattr(ds, "SeriesInstanceUID", None),
                "patient_id": getattr(ds, "PatientID", None),
                "patient_name": str(getattr(ds, "PatientName", "")),
                "modality": getattr(ds, "Modality", None),
                "study_date": getattr(ds, "StudyDate", None),
                "study_time": getattr(ds, "StudyTime", None),
                "study_description": getattr(ds, "StudyDescription", None),
                "series_number": getattr(ds, "SeriesNumber", None),
                "instance_number": getattr(ds, "InstanceNumber", None),
                "rows": getattr(ds, "Rows", None),
                "columns": getattr(ds, "Columns", None),
                "slice_thickness": getattr(ds, "SliceThickness", None),
                "pixel_spacing": getattr(ds, "PixelSpacing", None),
                "manufacturer": getattr(ds, "Manufacturer", None),
                "manufacturer_model": getattr(ds, "ManufacturerModelName", None),
            }
            
            return ds, metadata
            
        except InvalidDicomError:
            raise
        except Exception as e:
            raise DICOMValidationError(
                f"Error reading DICOM tags: {str(e)}",
                "TAG_READ_ERROR"
            )
    
    def is_anonymized(self, ds: FileDataset) -> bool:
        """Check if DICOM file is properly anonymized"""
        # Check for common PHI tags
        phi_tags = [
            (0x0010, 0x0010),  # Patient Name
            (0x0010, 0x0020),  # Patient ID
            (0x0010, 0x0030),  # Patient Birth Date
            (0x0010, 0x0040),  # Patient Sex
            (0x0010, 0x1040),  # Patient Address
            (0x0010, 0x2154),  # Patient Phone
        ]
        
        has_phi = False
        for tag in phi_tags:
            if tag in ds and ds[tag].value:
                has_phi = True
                break
        
        return not has_phi
    
    async def anonymize(
        self,
        input_path: str,
        output_path: str,
        remove_pixels: bool = False
    ) -> Dict[str, Any]:
        """
        Anonymize a DICOM file by removing PHI.
        
        Args:
            input_path: Path to input DICOM file
            output_path: Path for anonymized output
            remove_pixels: Also remove pixel data
            
        Returns:
            Anonymization info
        """
        try:
            ds = dcmread(input_path)
            
            # Tags to remove/replace
            tags_to_remove = [
                (0x0010, 0x0010),  # Patient Name
                (0x0010, 0x0020),  # Patient ID -> replace with hash
                (0x0010, 0x0030),  # Patient Birth Date
                (0x0010, 0x0040),  # Patient Sex -> keep if needed for analysis
                (0x0010, 0x1040),  # Patient Address
                (0x0010, 0x2154),  # Patient Phone
                (0x0010, 0x21B0),  # Additional Patient History
            ]
            
            # Remove or anonymize tags
            for tag in tags_to_remove:
                if tag in ds:
                    if tag == (0x0010, 0x0020):  # Patient ID
                        # Hash the patient ID
                        import hashlib
                        original_id = str(ds[tag].value)
                        hashed_id = hashlib.sha256(original_id.encode()).hexdigest()[:16]
                        ds[tag].value = f"ANON_{hashed_id}"
                    else:
                        del ds[tag]
            
            # Remove pixel data if requested
            if remove_pixels and (0x7FE0, 0x0010) in ds:
                del ds[0x7FE0, 0x0010]
            
            # Save anonymized file
            ds.save_as(output_path)
            
            return {
                "success": True,
                "input_path": input_path,
                "output_path": output_path,
                "tags_removed": len(tags_to_remove),
                "pixel_data_removed": remove_pixels
            }
            
        except Exception as e:
            logger.error(f"Anonymization failed: {e}")
            return {
                "success": False,
                "error": str(e)
            }


# Convenience functions
async def validate_dicom_file(file_path: str, **kwargs) -> Tuple[bool, Dict]:
    """Quick validation of a DICOM file"""
    validator = DICOMValidator()
    return await validator.validate_file(file_path, **kwargs)


async def validate_dicom_buffer(buffer: bytes, filename: str = "unknown", **kwargs) -> Tuple[bool, Dict]:
    """Quick validation of DICOM data from buffer"""
    validator = DICOMValidator()
    return await validator.validate_buffer(buffer, filename, **kwargs)
