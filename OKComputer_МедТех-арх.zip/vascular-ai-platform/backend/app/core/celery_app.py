"""
Celery Configuration for Background Tasks
"""
from celery import Celery
from app.core.config import settings

# Create Celery app
celery_app = Celery(
    "vascular_ai",
    broker=settings.CELERY_BROKER_URL or "redis://localhost:6379/0",
    backend=settings.CELERY_RESULT_BACKEND or "redis://localhost:6379/0",
    include=[
        "app.tasks.dicom_tasks",
        "app.tasks.report_tasks",
        "app.tasks.notification_tasks",
        "app.tasks.analytics_tasks",
        "app.tasks.ml_tasks",
    ]
)

# Celery configuration
celery_app.conf.update(
    # Task settings
    task_serializer="json",
    accept_content=["json"],
    result_serializer="json",
    timezone="UTC",
    enable_utc=True,
    
    # Task execution
    task_always_eager=False,  # Set True for testing
    task_store_eager_result=True,
    task_ignore_result=False,
    task_track_started=True,
    
    # Results
    result_expires=3600 * 24,  # 24 hours
    result_extended=True,
    
    # Worker settings
    worker_prefetch_multiplier=4,
    worker_max_tasks_per_child=1000,
    
    # Rate limiting
    task_default_rate_limit="100/m",
    
    # Retries
    task_default_retry_delay=60,
    task_max_retries=3,
    
    # Queues
    task_routes={
        "app.tasks.dicom_tasks.*": {"queue": "dicom"},
        "app.tasks.report_tasks.*": {"queue": "reports"},
        "app.tasks.notification_tasks.*": {"queue": "notifications"},
        "app.tasks.analytics_tasks.*": {"queue": "analytics"},
        "app.tasks.ml_tasks.*": {"queue": "ml"},
    },
    
    # Beat schedule (periodic tasks)
    beat_schedule={
        "cleanup-old-dicom": {
            "task": "app.tasks.dicom_tasks.cleanup_old_dicom",
            "schedule": 3600 * 24,  # Daily
        },
        "generate-daily-analytics": {
            "task": "app.tasks.analytics_tasks.generate_daily_analytics",
            "schedule": 3600 * 24,  # Daily
        },
        "cleanup-expired-sessions": {
            "task": "app.tasks.notification_tasks.cleanup_expired_sessions",
            "schedule": 3600,  # Hourly
        },
    },
)


@celery_app.task(bind=True)
def debug_task(self):
    """Debug task to verify Celery is working"""
    print(f"Request: {self.request!r}")
    return {"status": "ok", "task_id": self.request.id}
