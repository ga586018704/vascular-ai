"""
Retry Logic and Circuit Breaker for External APIs
Production-ready resilience patterns
"""
import asyncio
import logging
from functools import wraps
from typing import Callable, Any, Optional
from datetime import datetime, timedelta

import httpx
from tenacity import (
    retry,
    stop_after_attempt,
    wait_exponential,
    wait_fixed,
    retry_if_exception_type,
    before_sleep_log,
    after_log
)
from circuitbreaker import circuit

from app.core.config import get_settings

logger = logging.getLogger(__name__)
settings = get_settings()


# === Retry Decorators ===

def retry_on_httpx_error(
    max_attempts: int = 3,
    min_wait: int = 4,
    max_wait: int = 60,
    exponential_base: int = 2
):
    """
    Retry decorator for httpx HTTP errors.
    
    Retries on:
    - Network errors (ConnectError, ReadError)
    - 5xx server errors
    - Timeouts
    """
    return retry(
        stop=stop_after_attempt(max_attempts),
        wait=wait_exponential(
            multiplier=exponential_base,
            min=min_wait,
            max=max_wait
        ),
        retry=retry_if_exception_type((
            httpx.ConnectError,
            httpx.ReadError,
            httpx.WriteError,
            httpx.TimeoutException,
            httpx.NetworkError,
        )),
        before_sleep=before_sleep_log(logger, logging.WARNING),
        after=after_log(logger, logging.INFO),
        reraise=True
    )


def retry_on_openai_error(max_attempts: int = None):
    """Retry decorator specifically for OpenAI API"""
    max_attempts = max_attempts or settings.OPENAI_MAX_RETRIES
    
    return retry(
        stop=stop_after_attempt(max_attempts),
        wait=wait_exponential(multiplier=1, min=4, max=60),
        retry=retry_if_exception_type((
            httpx.ConnectError,
            httpx.TimeoutException,
            httpx.HTTPStatusError,  # Includes rate limits
        )),
        before_sleep=before_sleep_log(logger, logging.WARNING),
        reraise=True
    )


def retry_on_anthropic_error(max_attempts: int = None):
    """Retry decorator specifically for Anthropic API"""
    max_attempts = max_attempts or settings.ANTHROPIC_MAX_RETRIES
    
    return retry(
        stop=stop_after_attempt(max_attempts),
        wait=wait_exponential(multiplier=1, min=4, max=60),
        retry=retry_if_exception_type((
            httpx.ConnectError,
            httpx.TimeoutException,
            httpx.HTTPStatusError,
        )),
        before_sleep=before_sleep_log(logger, logging.WARNING),
        reraise=True
    )


# === Circuit Breaker Decorators ===

def circuit_breaker(
    failure_threshold: int = 5,
    recovery_timeout: int = 60,
    expected_exception: type = Exception
):
    """
    Circuit breaker decorator.
    
    Opens after `failure_threshold` failures.
    Closes after `recovery_timeout` seconds.
    """
    return circuit(
        failure_threshold=failure_threshold,
        recovery_timeout=recovery_timeout,
        expected_exception=expected_exception
    )


# === Custom Circuit Breaker Implementation ===

class CircuitBreakerState:
    """Circuit breaker states"""
    CLOSED = "closed"      # Normal operation
    OPEN = "open"          # Failing, reject requests
    HALF_OPEN = "half_open"  # Testing if service recovered


class CircuitBreaker:
    """
    Custom circuit breaker implementation with detailed metrics.
    """
    
    def __init__(
        self,
        name: str,
        failure_threshold: int = 5,
        recovery_timeout: int = 60,
        half_open_max_calls: int = 3
    ):
        self.name = name
        self.failure_threshold = failure_threshold
        self.recovery_timeout = recovery_timeout
        self.half_open_max_calls = half_open_max_calls
        
        self.state = CircuitBreakerState.CLOSED
        self.failure_count = 0
        self.success_count = 0
        self.last_failure_time: Optional[datetime] = None
        self.half_open_calls = 0
        
        # Metrics
        self.total_calls = 0
        self.total_failures = 0
        self.total_successes = 0
        
    @property
    def is_open(self) -> bool:
        """Check if circuit is open (failing)"""
        if self.state == CircuitBreakerState.OPEN:
            # Check if recovery timeout has passed
            if self.last_failure_time:
                elapsed = (datetime.now() - self.last_failure_time).total_seconds()
                if elapsed >= self.recovery_timeout:
                    self.state = CircuitBreakerState.HALF_OPEN
                    self.half_open_calls = 0
                    logger.info(f"Circuit {self.name}: Transitioning to HALF_OPEN")
                    return False
            return True
        return False
    
    def record_success(self):
        """Record a successful call"""
        self.total_calls += 1
        self.total_successes += 1
        
        if self.state == CircuitBreakerState.HALF_OPEN:
            self.half_open_calls += 1
            if self.half_open_calls >= self.half_open_max_calls:
                # Service recovered, close circuit
                self._reset()
                logger.info(f"Circuit {self.name}: Service recovered, CLOSING circuit")
        else:
            self.failure_count = 0
    
    def record_failure(self):
        """Record a failed call"""
        self.total_calls += 1
        self.total_failures += 1
        self.failure_count += 1
        self.last_failure_time = datetime.now()
        
        if self.state == CircuitBreakerState.HALF_OPEN:
            # Service still failing, open circuit again
            self.state = CircuitBreakerState.OPEN
            logger.warning(f"Circuit {self.name}: Service still failing, OPENING circuit")
        elif self.failure_count >= self.failure_threshold:
            # Too many failures, open circuit
            self.state = CircuitBreakerState.OPEN
            logger.warning(
                f"Circuit {self.name}: Failure threshold reached ({self.failure_count}), "
                f"OPENING circuit"
            )
    
    def _reset(self):
        """Reset circuit to closed state"""
        self.state = CircuitBreakerState.CLOSED
        self.failure_count = 0
        self.success_count = 0
        self.half_open_calls = 0
        self.last_failure_time = None
    
    async def call(self, func: Callable, *args, **kwargs) -> Any:
        """
        Execute function with circuit breaker protection.
        
        Raises CircuitBreakerError if circuit is open.
        """
        if self.is_open:
            raise CircuitBreakerError(
                f"Circuit {self.name} is OPEN. Service temporarily unavailable."
            )
        
        try:
            result = await func(*args, **kwargs)
            self.record_success()
            return result
        except Exception as e:
            self.record_failure()
            raise
    
    def get_metrics(self) -> dict:
        """Get circuit breaker metrics"""
        return {
            "name": self.name,
            "state": self.state,
            "failure_count": self.failure_count,
            "failure_threshold": self.failure_threshold,
            "total_calls": self.total_calls,
            "total_failures": self.total_failures,
            "total_successes": self.total_successes,
            "success_rate": (
                self.total_successes / self.total_calls * 100
                if self.total_calls > 0 else 100
            ),
            "last_failure_time": self.last_failure_time.isoformat() if self.last_failure_time else None,
            "recovery_timeout": self.recovery_timeout
        }


class CircuitBreakerError(Exception):
    """Exception raised when circuit breaker is open"""
    pass


# === Global Circuit Breakers ===

# Circuit breakers for external services
_openai_circuit = CircuitBreaker(
    name="openai",
    failure_threshold=5,
    recovery_timeout=60
)

_anthropic_circuit = CircuitBreaker(
    name="anthropic",
    failure_threshold=5,
    recovery_timeout=60
)

_pacs_circuit = CircuitBreaker(
    name="pacs",
    failure_threshold=3,
    recovery_timeout=30
)

_fhir_circuit = CircuitBreaker(
    name="fhir",
    failure_threshold=3,
    recovery_timeout=30
)


def get_circuit_breaker(service: str) -> CircuitBreaker:
    """Get circuit breaker for a service"""
    circuits = {
        "openai": _openai_circuit,
        "anthropic": _anthropic_circuit,
        "pacs": _pacs_circuit,
        "fhir": _fhir_circuit,
    }
    return circuits.get(service)


def get_all_circuit_metrics() -> dict:
    """Get metrics for all circuit breakers"""
    return {
        "openai": _openai_circuit.get_metrics(),
        "anthropic": _anthropic_circuit.get_metrics(),
        "pacs": _pacs_circuit.get_metrics(),
        "fhir": _fhir_circuit.get_metrics(),
    }


# === Convenience Decorators ===

def with_openai_circuit_breaker(func: Callable) -> Callable:
    """Decorator to add circuit breaker for OpenAI calls"""
    @wraps(func)
    async def wrapper(*args, **kwargs):
        return await _openai_circuit.call(func, *args, **kwargs)
    return wrapper


def with_anthropic_circuit_breaker(func: Callable) -> Callable:
    """Decorator to add circuit breaker for Anthropic calls"""
    @wraps(func)
    async def wrapper(*args, **kwargs):
        return await _anthropic_circuit.call(func, *args, **kwargs)
    return wrapper


# === Usage Examples ===

"""
# Example 1: Using retry decorator
@retry_on_openai_error()
async def call_openai_api(prompt: str) -> str:
    async with httpx.AsyncClient() as client:
        response = await client.post(
            "https://api.openai.com/v1/chat/completions",
            headers={"Authorization": f"Bearer {settings.OPENAI_API_KEY}"},
            json={"model": "gpt-4", "messages": [{"role": "user", "content": prompt}]},
            timeout=30
        )
        response.raise_for_status()
        return response.json()["choices"][0]["message"]["content"]

# Example 2: Using circuit breaker
@with_openai_circuit_breaker
async def analyze_with_openai(data: dict) -> dict:
    # This will be protected by circuit breaker
    return await call_openai_api(str(data))

# Example 3: Using both retry and circuit breaker
@retry_on_openai_error(max_attempts=3)
@with_openai_circuit_breaker
async def robust_openai_call(prompt: str) -> str:
    async with httpx.AsyncClient() as client:
        response = await client.post(...)
        return response.json()
"""
