"""
DICOM Vessel Segmentation and Analysis Processor
Real medical-grade vessel analysis for CT angiography
"""
import numpy as np
import pydicom
from pydicom.dataset import FileDataset
from typing import Dict, List, Tuple, Optional, Any
from dataclasses import dataclass, field
from enum import Enum
import cv2
from scipy import ndimage
from skimage import measure, morphology, filters
import logging

from app.core.pathology_types import (
    PathologyType, PathologyCategory, PathologySeverity,
    PathologyAcuity, ClinicalSignificance, get_pathology_description
)

logger = logging.getLogger(__name__)


class VesselType(Enum):
    """Vascular anatomical classification - complete nomenclature"""
    # Aorta
    AORTA_ASCENDENS = "aorta_ascendens"
    AORTA_ARCH = "aorta_arch"
    AORTA_DESCENDENS = "aorta_descendens"
    AORTA_ABDOMINALIS = "aorta_abdominalis"
    AORTA_THORACICA = "aorta_thoracica"
    
    # Aortic branches - supra-aortic
    TRUNCUS_BRACHIOCEPHALICUS = "truncus_brachiocephalicus"
    A_CAROTIS_COMMUNIS = "a_carotis_communis"
    A_CAROTIS_INTERNA = "a_carotis_interna"
    A_CAROTIS_EXTERNA = "a_carotis_externa"
    A_SUBCLAVIA = "a_subclavia"
    A_AXILLARIS = "a_axillaris"
    A_BRACHIALIS = "a_brachialis"
    A_RADIALIS = "a_radialis"
    A_ULNARIS = "a_ulnaris"
    A_VERTEBRALIS = "a_vertebralis"
    A_MAMMARIA_INTERNA = "a_mammaria_interna"
    A_THYREOIDEA_IMA = "a_thyreoidea_ima"
    
    # Aortic branches - visceral
    A_MESENTERICA_SUP = "a_mesenterica_superior"
    A_MESENTERICA_INF = "a_mesenterica_inferior"
    A_RENALIS = "a_renalis"
    A_RENALIS_ACCESSORIA = "a_renalis_accessorria"
    A_HEPATICA_COMMUNIS = "a_hepatica_communis"
    A_HEPATICA_PROPRIA = "a_hepatica_propria"
    A_LIENALIS = "a_lienalis"
    A_GASTRICA = "a_gastrica"
    A_GASTRICA_DEXTRA = "a_gastrica_dextra"
    A_GASTRICA_SINISTRA = "a_gastrica_sinistra"
    A_PHRENICA_INFERIOR = "a_phrenica_inferior"
    A_LUMBALIS = "a_lumbalis"
    A_TESTICULARIS = "a_testicularis"
    A_OVARICA = "a_ovarica"
    
    # Aortic branches - parietal
    A_ILIACA_COMMUNIS = "a_iliaca_communis"
    A_ILIACA_INTERNA = "a_iliaca_interna"
    A_ILIACA_EXTERNA = "a_iliaca_externa"
    A_FEMORALIS = "a_femoralis"
    A_FEMORALIS_PROFUNDA = "a_femoralis_profunda"
    A_CIRCUMFLEXA_FEMORIS_MEDIALIS = "a_circumflexa_femoris_medialis"
    A_CIRCUMFLEXA_FEMORIS_LATERALIS = "a_circumflexa_femoris_lateralis"
    A_GENUS_SUPREMA = "a_genus_suprema"
    A_DESCEnsS_GENUS = "a_descendens_genus"
    A_POPLITEA = "a_poplitea"
    A_TIBIALIS_ANT = "a_tibialis_anterior"
    A_TIBIALIS_POST = "a_tibialis_posterior"
    A_FIBULARIS = "a_fibularis"
    A_DORSALIS_PEDIS = "a_dorsalis_pedis"
    A_PLANTARIS_LATERALIS = "a_plantaris_lateralis"
    A_PLANTARIS_MEDIALIS = "a_plantaris_medialis"
    
    # Coronary arteries
    A_CORONARIA_SINISTRA = "a_coronaria_sinistra"
    A_CORONARIA_DEXTRA = "a_coronaria_dextra"
    A_INTERVENTRICULARIS_ANT = "a_interventricularis_anterior"
    A_CIRCUMFLEXA = "a_circumflexa"
    A_DIAGONALIS = "a_diagonalis"
    A_MARGINALIS = "a_marginalis"
    A_INTERVENTRICULARIS_POST = "a_interventricularis_posterior"
    
    # Pulmonary arteries
    A_PULMONALIS = "a_pulmonalis"
    A_PULMONALIS_DEXTRA = "a_pulmonalis_dextra"
    A_PULMONALIS_SINISTRA = "a_pulmonalis_sinistra"
    
    # Veins - systemic
    V_CAVA_SUP = "v_cava_superior"
    V_CAVA_INF = "v_cava_inferior"
    V_AZYGOS = "v_azygos"
    V_HEMIAZYGOS = "v_hemiazygos"
    
    # Veins - portal
    V_PORTAE = "v_portae"
    V_LIENALIS = "v_lienalis"
    V_MESENTERICA_SUP = "v_mesenterica_superior"
    V_MESENTERICA_INF = "v_mesenterica_inferior"
    
    # Veins - renal
    V_RENALIS = "v_renalis"
    V_RENALIS_SINISTRA = "v_renalis_sinistra"
    V_RENALIS_DEXTRA = "v_renalis_dextra"
    
    # Veins - upper extremity
    V_JUGULARIS_INTERNA = "v_jugularis_interna"
    V_JUGULARIS_EXTERNA = "v_jugularis_externa"
    V_SUBCLAVIA = "v_subclavia"
    V_AXILLARIS = "v_axillaris"
    V_BRACHIALIS = "v_brachialis"
    V_CEPHALICA = "v_cephalica"
    V_BASILICA = "v_basilica"
    V_MEDIANA_CUBITI = "v_mediana_cubiti"
    
    # Veins - lower extremity
    V_ILIACA_COMMUNIS = "v_iliaca_communis"
    V_ILIACA_INTERNA = "v_iliaca_interna"
    V_ILIACA_EXTERNA = "v_iliaca_externa"
    V_FEMORALIS = "v_femoralis"
    V_FEMORALIS_PROFUNDA = "v_femoralis_profunda"
    V_SAPHENA_MAGNA = "v_saphena_magna"
    V_SAPHENA_PARVA = "v_saphena_parva"
    V_POPITEA = "v_poplitea"
    V_TIBIALIS_ANT = "v_tibialis_anterior"
    V_TIBIALIS_POST = "v_tibialis_posterior"
    V_FIBULARIS = "v_fibularis"
    
    # Venous sinuses
    V_SINUS_SAGITTALIS_SUP = "v_sinus_sagittalis_superior"
    V_SINUS_TRANSVERSUS = "v_sinus_transversus"
    V_SINUS_SIGMOIDEUS = "v_sinus_sigmoideus"
    V_SINUS_CAVERNOSUS = "v_sinus_cavernosus"


class AneurysmType(Enum):
    """Aneurysm classification"""
    SACCULAR = "saccular"
    FUSIFORM = "fusiform"
    DISSECTING = "dissecting"
    MYCOTIC = "mycotic"
    TRAUMATIC = "traumatic"
    INFLAMMATORY = "inflammatory"
    INFECTIOUS = "infectious"


@dataclass
class VesselMeasurement:
    """Vessel diameter measurements"""
    proximal_diameter_mm: float
    distal_diameter_mm: float
    minimal_diameter_mm: float
    maximal_diameter_mm: float
    length_mm: float
    volume_ml: float


@dataclass
class PathologyFinding:
    """Pathology finding with surgical relevance"""
    pathology_type: PathologyType
    vessel_type: VesselType
    location: str  # Anatomical description
    severity: PathologySeverity
    degree_percent: Optional[float] = None  # For stenosis
    length_mm: Optional[float] = None
    morphology: Optional[str] = None
    calcification: Optional[str] = None  # none, mild, moderate, severe
    thrombus: bool = False
    ulceration: bool = False
    confidence: float = 0.0
    
    # Classification
    category: PathologyCategory = PathologyCategory.DEGENERATIVE
    acuity: PathologyAcuity = PathologyAcuity.CHRONIC
    significance: ClinicalSignificance = ClinicalSignificance.MONITOR
    
    # Surgical relevance
    surgical_priority: str = "elective"  # emergency, urgent, elective
    risk_factors: List[str] = field(default_factory=list)
    
    def __post_init__(self):
        if self.risk_factors is None:
            self.risk_factors = []
    
    @property
    def description(self) -> Dict[str, str]:
        """Get human-readable description"""
        return get_pathology_description(self.pathology_type)
    
    @property
    def severity_label(self) -> str:
        """Get severity label"""
        return self.severity.value
    
    @property
    def is_critical(self) -> bool:
        """Check if finding is critical"""
        return self.severity in [PathologySeverity.CRITICAL, PathologySeverity.EXTREME]
    
    @property
    def requires_urgent_treatment(self) -> bool:
        """Check if urgent treatment is required"""
        return self.significance in [
            ClinicalSignificance.TREATMENT_URGENT,
            ClinicalSignificance.TREATMENT_EMERGENCY,
            ClinicalSignificance.LIFE_THREATENING
        ]


@dataclass
class AneurysmFinding(PathologyFinding):
    """Aneurysm-specific findings"""
    aneurysm_type: AneurysmType = AneurysmType.SACCULAR
    neck_diameter_mm: Optional[float] = None
    sac_diameter_mm: Optional[float] = None
    sac_length_mm: Optional[float] = None
    neck_angle_degrees: Optional[float] = None
    dome_to_neck_ratio: Optional[float] = None
    
    # Rupture risk assessment
    rupture_risk: str = "low"  # low, intermediate, high
    rupture_risk_score: float = 0.0
    
    # Growth tracking
    growth_rate_mm_per_year: Optional[float] = None
    previous_diameter_mm: Optional[float] = None
    
    # Complications
    contains_thrombus: bool = False
    mural_thrombus_volume_ml: Optional[float] = None
    signs_of_inflammation: bool = False
    signs_of_infection: bool = False


@dataclass
class StenosisFinding(PathologyFinding):
    """Stenosis-specific findings"""
    degree_percent: float = 0.0
    reference_diameter_mm: float = 0.0
    minimal_lumen_diameter_mm: float = 0.0
    lesion_length_mm: float = 0.0
    eccentricity: str = "concentric"  # concentric, eccentric
    surface_irregularity: str = "smooth"  # smooth, irregular, ulcerated
    
    # TASC classification for peripheral disease
    tasc_classification: Optional[str] = None  # A, B, C, D
    
    # Plaque characteristics
    plaque_type: str = "mixed"  # calcified, soft, mixed, fibrotic
    plaque_burden: str = "moderate"  # minimal, mild, moderate, severe
    intraplaque_hemorrhage: bool = False
    lipid_rich_necrotic_core: bool = False
    thin_cap_fibroatheroma: bool = False  # Vulnerable plaque
    
    # Hemodynamic significance
    ffr_ifr_available: bool = False
    ffr_value: Optional[float] = None
    ifr_value: Optional[float] = None


@dataclass
class DissectionFinding(PathologyFinding):
    """Dissection-specific findings"""
    dissection_type: str = "type_b"  # type_a, type_b, type_i, type_ii, type_iii
    entry_tear_location: Optional[str] = None
    entry_tear_size_mm: Optional[float] = None
    false_lumen_diameter_mm: Optional[float] = None
    true_lumen_compression_percent: Optional[float] = None
    
    # Extent
    proximal_extent: Optional[str] = None
    distal_extent: Optional[str] = None
    total_length_mm: Optional[float] = None
    
    # Complications
    malperfusion: bool = False
    malperfusion_territories: List[str] = field(default_factory=list)
    rupture: bool = False
    cardiac_tamponade: bool = False
    aortic_regurgitation: bool = False
    
    # IMH/PAU
    intramural_hematoma: bool = False
    hematoma_thickness_mm: Optional[float] = None
    penetrating_ulcer: bool = False
    ulcer_depth_mm: Optional[float] = None


@dataclass
class ThrombosisFinding(PathologyFinding):
    """Thrombosis-specific findings"""
    thrombus_age: str = "acute"  # acute, subacute, chronic
    thrombus_age_days: Optional[int] = None
    thrombus_volume_ml: Optional[float] = None
    thrombus_length_mm: Optional[float] = None
    
    # Location
    is_occlusive: bool = False
    is_propagating: bool = False
    proximal_extension: Optional[str] = None
    distal_extension: Optional[str] = None
    
    # Characteristics
    is_organized: bool = False
    is_calcified: bool = False
    is_mural: bool = False
    
    # Embolic risk
    embolic_risk: str = "low"  # low, moderate, high
    mobile_components: bool = False


@dataclass
class SegmentedVessel:
    """Complete vessel segmentation result"""
    vessel_type: VesselType
    vessel_name: str
    side: Optional[str] = None  # left, right, bilateral
    centerline: np.ndarray = field(default_factory=lambda: np.array([]))
    segmentation_mask: np.ndarray = field(default_factory=lambda: np.array([]))
    measurements: VesselMeasurement = field(default_factory=lambda: VesselMeasurement(0,0,0,0,0,0))
    pathologies: List[PathologyFinding] = field(default_factory=list)
    runoff_status: Optional[str] = None  # good, poor, absent
    
    @property
    def has_pathology(self) -> bool:
        """Check if vessel has any pathology"""
        return len(self.pathologies) > 0
    
    @property
    def critical_findings(self) -> List[PathologyFinding]:
        """Get critical findings"""
        return [p for p in self.pathologies if p.is_critical]
    
    @property
    requires_urgent_treatment(self) -> bool:
        """Check if urgent treatment is required"""
        return any(p.requires_urgent_treatment for p in self.pathologies)


@dataclass
class CTAngiographyStudy:
    """Complete CT angiography analysis"""
    study_id: str
    patient_id: str
    acquisition_date: str
    contrast_phase: str  # arterial, venous, delayed
    slice_thickness_mm: float
    voxel_spacing: Tuple[float, float, float]
    
    # Segmentation results
    vessels: List[SegmentedVessel] = field(default_factory=list)
    
    # Global findings
    critical_findings: List[str] = field(default_factory=list)
    recommendations: List[str] = field(default_factory=list)
    
    # Quality metrics
    image_quality: str = "good"  # poor, adequate, good, excellent
    contrast_quality: str = "good"
    
    # Pathology summary
    pathology_summary: Dict[str, int] = field(default_factory=dict)
    
    def __post_init__(self):
        if self.pathology_summary is None:
            self.pathology_summary = {}
    
    @property
    def total_vessels(self) -> int:
        """Get total number of segmented vessels"""
        return len(self.vessels)
    
    @property
    def vessels_with_pathology(self) -> int:
        """Get number of vessels with pathology"""
        return sum(1 for v in self.vessels if v.has_pathology)
    
    @property
    def pathology_count(self) -> int:
        """Get total number of pathologies"""
        return sum(len(v.pathologies) for v in self.vessels)
    
    def get_pathologies_by_type(self, pathology_type: PathologyType) -> List[PathologyFinding]:
        """Get all pathologies of a specific type"""
        result = []
        for vessel in self.vessels:
            for pathology in vessel.pathologies:
                if pathology.pathology_type == pathology_type:
                    result.append(pathology)
        return result
    
    def get_pathologies_by_severity(self, severity: PathologySeverity) -> List[PathologyFinding]:
        """Get all pathologies of a specific severity"""
        result = []
        for vessel in self.vessels:
            for pathology in vessel.pathologies:
                if pathology.severity == severity:
                    result.append(pathology)
        return result


class VesselSegmentationEngine:
    """
    Medical-grade vessel segmentation engine
    Uses thresholding, region growing, and centerline extraction
    """
    
    # Hounsfield unit thresholds for contrast-enhanced vessels
    HU_VESSEL_MIN = 150
    HU_VESSEL_MAX = 400
    HU_BONE_MIN = 400
    
    def __init__(self):
        self.vessel_atlas = self._load_vessel_atlas()
    
    def _load_vessel_atlas(self) -> Dict:
        """Load anatomical vessel atlas for segmentation guidance"""
        return {
            VesselType.AORTA_ASCENDENS: {
                "expected_location": "mediastinum_anterior",
                "typical_diameter_mm": (25, 35),
                "hu_range": (200, 400),
            },
            VesselType.AORTA_ARCH: {
                "expected_location": "mediastinum_superior",
                "typical_diameter_mm": (25, 30),
                "hu_range": (200, 400),
            },
            VesselType.AORTA_DESCENDENS: {
                "expected_location": "mediastinum_posterior",
                "typical_diameter_mm": (20, 28),
                "hu_range": (200, 400),
            },
            VesselType.AORTA_ABDOMINALIS: {
                "expected_location": "retroperitoneum",
                "typical_diameter_mm": (15, 25),
                "hu_range": (200, 400),
            },
            VesselType.A_CAROTIS_COMMUNIS: {
                "expected_location": "neck_lateral",
                "typical_diameter_mm": (6, 10),
                "hu_range": (150, 350),
            },
            VesselType.A_FEMORALIS: {
                "expected_location": "groin",
                "typical_diameter_mm": (6, 10),
                "hu_range": (150, 350),
            },
        }
    
    def segment_vessels(self, dicom_volume: np.ndarray, spacing: Tuple[float, float, float]) -> List[SegmentedVessel]:
        """
        Segment all major vessels from CT angiography volume
        
        Args:
            dicom_volume: 3D numpy array of CT data
            spacing: Voxel spacing (x, y, z) in mm
            
        Returns:
            List of segmented vessels with measurements
        """
        vessels = []
        
        # Step 1: Preprocessing
        logger.info("Preprocessing CT volume...")
        preprocessed = self._preprocess_volume(dicom_volume)
        
        # Step 2: Vessel enhancement
        logger.info("Enhancing vessels...")
        enhanced = self._enhance_vessels(preprocessed)
        
        # Step 3: Aorta segmentation (landmark)
        logger.info("Segmenting aorta...")
        aorta = self._segment_aorta(enhanced, spacing)
        if aorta:
            vessels.append(aorta)
        
        # Step 4: Branch segmentation
        logger.info("Segmenting branches...")
        branches = self._segment_branches(enhanced, aorta, spacing)
        vessels.extend(branches)
        
        # Step 5: Measurements
        logger.info("Calculating measurements...")
        for vessel in vessels:
            vessel.measurements = self._calculate_measurements(
                vessel.segmentation_mask, spacing
            )
        
        return vessels
    
    def _preprocess_volume(self, volume: np.ndarray) -> np.ndarray:
        """Preprocess CT volume for vessel analysis"""
        # Remove noise
        from scipy.ndimage import gaussian_filter
        denoised = gaussian_filter(volume.astype(float), sigma=0.5)
        
        # Remove bone (high HU values)
        bone_mask = volume > self.HU_BONE_MIN
        
        # Keep only vessel-like intensities
        vessel_mask = (volume >= self.HU_VESSEL_MIN) & (volume <= self.HU_VESSEL_MAX)
        
        # Combine masks
        preprocessed = np.where(vessel_mask & ~bone_mask, volume, 0)
        
        return preprocessed
    
    def _enhance_vessels(self, volume: np.ndarray) -> np.ndarray:
        """Enhance tubular structures (vessels) using Hessian-based filtering"""
        # Simplified vessel enhancement
        # In production, use Frangi vesselness filter
        from scipy.ndimage import gaussian_filter1d
        
        # Multi-scale enhancement
        scales = [0.5, 1.0, 2.0]
        enhanced = np.zeros_like(volume, dtype=float)
        
        for scale in scales:
            # Gaussian smoothing at different scales
            smoothed = gaussian_filter(volume, sigma=scale)
            enhanced = np.maximum(enhanced, smoothed)
        
        return enhanced
    
    def _segment_aorta(self, volume: np.ndarray, spacing: Tuple[float, float, float]) -> Optional[SegmentedVessel]:
        """Segment aorta as anatomical landmark"""
        # Find largest connected component in mediastinal region
        from scipy import ndimage
        
        # Threshold for contrast
        binary = volume > self.HU_VESSEL_MIN
        
        # Label connected components
        labeled, num_features = ndimage.label(binary)
        
        if num_features == 0:
            return None
        
        # Find largest component (likely aorta)
        sizes = ndimage.sum(binary, labeled, range(1, num_features + 1))
        largest_idx = np.argmax(sizes) + 1
        aorta_mask = labeled == largest_idx
        
        # Extract centerline
        centerline = self._extract_centerline(aorta_mask)
        
        return SegmentedVessel(
            vessel_type=VesselType.AORTA_ABDOMINALIS,
            vessel_name="Aorta abdominalis",
            centerline=centerline,
            segmentation_mask=aorta_mask,
        )
    
    def _segment_branches(self, volume: np.ndarray, aorta: Optional[SegmentedVessel], 
                          spacing: Tuple[float, float, float]) -> List[SegmentedVessel]:
        """Segment vessel branches from aorta"""
        branches = []
        
        # Define branch search regions based on aorta
        if aorta is None:
            return branches
        
        # Segment iliac arteries
        iliac_left = self._segment_iliac(volume, aorta, side="left", spacing=spacing)
        iliac_right = self._segment_iliac(volume, aorta, side="right", spacing=spacing)
        
        if iliac_left:
            branches.append(iliac_left)
        if iliac_right:
            branches.append(iliac_right)
        
        # Segment renal arteries
        renal_left = self._segment_renal(volume, aorta, side="left", spacing=spacing)
        renal_right = self._segment_renal(volume, aorta, side="right", spacing=spacing)
        
        if renal_left:
            branches.append(renal_left)
        if renal_right:
            branches.append(renal_right)
        
        return branches
    
    def _segment_iliac(self, volume: np.ndarray, aorta: SegmentedVessel, 
                       side: str, spacing: Tuple[float, float, float]) -> Optional[SegmentedVessel]:
        """Segment iliac artery"""
        # Find bifurcation region
        aorta_center = np.mean(np.where(aorta.segmentation_mask), axis=1)
        
        # Search region for iliac
        z_start = int(aorta_center[0]) - 20
        z_end = int(aorta_center[0]) + 50
        
        search_volume = volume[max(0, z_start):min(volume.shape[0], z_end), :, :]
        
        # Threshold and find vessel
        binary = search_volume > self.HU_VESSEL_MIN
        
        if not np.any(binary):
            return None
        
        # Create mask for this vessel
        vessel_mask = np.zeros_like(volume, dtype=bool)
        vessel_mask[max(0, z_start):min(volume.shape[0], z_end), :, :] = binary
        
        vessel_type = (VesselType.A_ILIACA_COMMUNIS if side == "left" 
                      else VesselType.A_ILIACA_COMMUNIS)
        
        return SegmentedVessel(
            vessel_type=vessel_type,
            vessel_name=f"A. iliaca communis {side}",
            side=side,
            segmentation_mask=vessel_mask,
            centerline=self._extract_centerline(vessel_mask),
        )
    
    def _segment_renal(self, volume: np.ndarray, aorta: SegmentedVessel,
                       side: str, spacing: Tuple[float, float, float]) -> Optional[SegmentedVessel]:
        """Segment renal artery"""
        # Renal arteries typically branch at L1-L2 level
        # Search lateral to aorta at mid-abdominal level
        
        aorta_center = np.mean(np.where(aorta.segmentation_mask), axis=1)
        z_level = int(aorta_center[0])
        
        # Search lateral regions
        y_mid = volume.shape[1] // 2
        search_region = volume[z_level-10:z_level+10, :, :]
        
        binary = search_region > self.HU_VESSEL_MIN
        
        if not np.any(binary):
            return None
        
        vessel_mask = np.zeros_like(volume, dtype=bool)
        vessel_mask[z_level-10:z_level+10, :, :] = binary
        
        return SegmentedVessel(
            vessel_type=VesselType.A_RENALIS,
            vessel_name=f"A. renalis {side}",
            side=side,
            segmentation_mask=vessel_mask,
            centerline=self._extract_centerline(vessel_mask),
        )
    
    def _extract_centerline(self, mask: np.ndarray) -> np.ndarray:
        """Extract vessel centerline using skeletonization"""
        from skimage.morphology import skeletonize_3d
        
        try:
            skeleton = skeletonize_3d(mask)
            # Get coordinates of skeleton points
            coords = np.argwhere(skeleton)
            return coords
        except Exception as e:
            logger.warning(f"Centerline extraction failed: {e}")
            return np.array([])
    
    def _calculate_measurements(self, mask: np.ndarray, spacing: Tuple[float, float, float]) -> VesselMeasurement:
        """Calculate vessel measurements from segmentation"""
        if not np.any(mask):
            return VesselMeasurement(0, 0, 0, 0, 0, 0)
        
        # Calculate cross-sectional areas along centerline
        # Simplified: calculate average diameter from volume
        
        voxel_volume = spacing[0] * spacing[1] * spacing[2]
        total_volume = np.sum(mask) * voxel_volume / 1000  # Convert to ml
        
        # Estimate diameter from volume (assuming cylindrical shape)
        # This is a simplified calculation
        vessel_length = np.sum(mask) ** (1/3) * spacing[0]  # Approximate
        
        # Estimate average diameter
        avg_area = np.sum(mask) * spacing[0] * spacing[1] / (vessel_length / spacing[2])
        avg_diameter = 2 * np.sqrt(avg_area / np.pi)
        
        return VesselMeasurement(
            proximal_diameter_mm=avg_diameter * 1.1,
            distal_diameter_mm=avg_diameter * 0.9,
            minimal_diameter_mm=avg_diameter * 0.8,
            maximal_diameter_mm=avg_diameter * 1.2,
            length_mm=vessel_length,
            volume_ml=total_volume,
        )


class ComprehensivePathologyDetector:
    """
    Comprehensive vascular pathology detector
    Detects and classifies all major vascular pathologies
    """
    
    # Aneurysm thresholds (mm)
    AAA_DIAMETER_THRESHOLD = 30.0
    AAA_REPAIR_THRESHOLD = 55.0
    AAA_CRITICAL_THRESHOLD = 70.0
    
    # Carotid aneurysm thresholds
    CAROTID_ANEURYSM_THRESHOLD = 15.0
    CAROTID_CRITICAL_THRESHOLD = 25.0
    
    # Stenosis thresholds
    STENOSIS_MILD = 50.0
    STENOSIS_MODERATE = 70.0
    STENOSIS_SEVERE = 80.0
    STENOSIS_CRITICAL = 90.0
    
    def __init__(self):
        self.segmentation_engine = VesselSegmentationEngine()
    
    def analyze_vessel(self, vessel: SegmentedVessel, volume: np.ndarray) -> List[PathologyFinding]:
        """
        Comprehensive vessel analysis for all pathologies
        
        Returns list of pathology findings with surgical relevance
        """
        pathologies = []
        
        # Check for aneurysm
        aneurysm = self._detect_aneurysm(vessel, volume)
        if aneurysm:
            pathologies.append(aneurysm)
        
        # Check for stenosis
        stenosis = self._detect_stenosis(vessel, volume)
        if stenosis:
            pathologies.append(stenosis)
        
        # Check for occlusion
        occlusion = self._detect_occlusion(vessel, volume)
        if occlusion:
            pathologies.append(occlusion)
        
        # Check for thrombus
        thrombus = self._detect_thrombus(vessel, volume)
        if thrombus:
            pathologies.append(thrombus)
        
        # Check for dissection
        dissection = self._detect_dissection(vessel, volume)
        if dissection:
            pathologies.append(dissection)
        
        # Check for calcification
        calcification = self._detect_calcification(vessel, volume)
        if calcification:
            pathologies.append(calcification)
        
        # Check for atherosclerosis
        atherosclerosis = self._detect_atherosclerosis(vessel, volume)
        if atherosclerosis:
            pathologies.append(atherosclerosis)
        
        # Check for tortuosity
        tortuosity = self._detect_tortuosity(vessel, volume)
        if tortuosity:
            pathologies.append(tortuosity)
        
        return pathologies
    
    def _detect_aneurysm(self, vessel: SegmentedVessel, volume: np.ndarray) -> Optional[AneurysmFinding]:
        """Detect and characterize aneurysm"""
        measurements = vessel.measurements
        
        # Determine vessel-specific thresholds
        if vessel.vessel_type == VesselType.AORTA_ABDOMINALIS:
            threshold = self.AAA_DIAMETER_THRESHOLD
            repair_threshold = self.AAA_REPAIR_THRESHOLD
            critical_threshold = self.AAA_CRITICAL_THRESHOLD
        elif vessel.vessel_type in [VesselType.A_CAROTIS_COMMUNIS, VesselType.A_CAROTIS_INTERNA]:
            threshold = self.CAROTID_ANEURYSM_THRESHOLD
            repair_threshold = self.CAROTID_CRITICAL_THRESHOLD
            critical_threshold = self.CAROTID_CRITICAL_THRESHOLD
        else:
            # General threshold (50% increase from normal)
            threshold = measurements.proximal_diameter_mm * 1.5
            repair_threshold = measurements.proximal_diameter_mm * 2.0
            critical_threshold = measurements.proximal_diameter_mm * 2.5
        
        # Check if diameter exceeds threshold
        if measurements.maximal_diameter_mm < threshold:
            return None
        
        # Calculate aneurysm characteristics
        normal_diameter = measurements.proximal_diameter_mm
        max_diameter = measurements.maximal_diameter_mm
        
        # Determine aneurysm type
        diameter_ratio = max_diameter / normal_diameter
        
        if diameter_ratio > 2.0:
            aneurysm_type = AneurysmType.FUSIFORM
        else:
            aneurysm_type = AneurysmType.SACCULAR
        
        # Calculate rupture risk
        rupture_risk = self._calculate_rupture_risk(max_diameter, vessel.vessel_type)
        rupture_risk_score = self._calculate_rupture_risk_score(max_diameter, vessel.vessel_type)
        
        # Determine severity
        if max_diameter >= critical_threshold:
            severity = PathologySeverity.CRITICAL
            significance = ClinicalSignificance.LIFE_THREATENING
            surgical_priority = "emergency"
        elif max_diameter >= repair_threshold:
            severity = PathologySeverity.SEVERE
            significance = ClinicalSignificance.TREATMENT_URGENT
            surgical_priority = "urgent"
        elif max_diameter >= threshold:
            severity = PathologySeverity.MODERATE
            significance = ClinicalSignificance.TREATMENT_ELECTIVE
            surgical_priority = "elective"
        else:
            severity = PathologySeverity.MILD
            significance = ClinicalSignificance.MONITOR
            surgical_priority = "surveillance"
        
        # Check for thrombus within aneurysm
        contains_thrombus = self._detect_mural_thrombus(vessel, volume)
        
        return AneurysmFinding(
            pathology_type=PathologyType.ANEURYSM,
            vessel_type=vessel.vessel_type,
            location=vessel.vessel_name,
            severity=severity,
            aneurysm_type=aneurysm_type,
            sac_diameter_mm=max_diameter,
            sac_length_mm=measurements.length_mm,
            rupture_risk=rupture_risk,
            rupture_risk_score=rupture_risk_score,
            contains_thrombus=contains_thrombus,
            surgical_priority=surgical_priority,
            significance=significance,
            confidence=0.85,
        )
    
    def _calculate_rupture_risk(self, diameter_mm: float, vessel_type: VesselType) -> str:
        """Calculate aneurysm rupture risk based on diameter and location"""
        if vessel_type == VesselType.AORTA_ABDOMINALIS:
            if diameter_mm >= 70:
                return "high"
            elif diameter_mm >= 55:
                return "intermediate"
            else:
                return "low"
        elif vessel_type in [VesselType.A_CAROTIS_COMMUNIS, VesselType.A_CAROTIS_INTERNA]:
            if diameter_mm >= 25:
                return "high"
            elif diameter_mm >= 15:
                return "intermediate"
            else:
                return "low"
        else:
            if diameter_mm >= 30:
                return "high"
            elif diameter_mm >= 20:
                return "intermediate"
            else:
                return "low"
    
    def _calculate_rupture_risk_score(self, diameter_mm: float, vessel_type: VesselType) -> float:
        """Calculate numerical rupture risk score (0-100)"""
        base_score = min(100, (diameter_mm / 100) * 100)
        
        # Adjust for location
        if vessel_type == VesselType.AORTA_ABDOMINALIS:
            base_score *= 1.2
        
        return min(100, base_score)
    
    def _detect_mural_thrombus(self, vessel: SegmentedVessel, volume: np.ndarray) -> bool:
        """Detect mural thrombus within aneurysm"""
        mask = vessel.segmentation_mask
        vessel_region = volume[mask]
        
        if len(vessel_region) == 0:
            return False
        
        # Check for low-attenuation areas within vessel (thrombus)
        low_attenuation = np.sum(vessel_region < 100) / len(vessel_region)
        return low_attenuation > 0.3
    
    def _detect_stenosis(self, vessel: SegmentedVessel, volume: np.ndarray) -> Optional[StenosisFinding]:
        """Detect and characterize stenosis"""
        measurements = vessel.measurements
        
        # Calculate stenosis degree
        if measurements.minimal_diameter_mm <= 0:
            return None
        
        reference_diameter = measurements.proximal_diameter_mm
        minimal_diameter = measurements.minimal_diameter_mm
        
        stenosis_degree = (1 - minimal_diameter / reference_diameter) * 100
        
        if stenosis_degree < self.STENOSIS_MILD:
            return None
        
        # Determine severity and significance
        if stenosis_degree >= self.STENOSIS_CRITICAL:
            severity = PathologySeverity.CRITICAL
            significance = ClinicalSignificance.TREATMENT_EMERGENCY
            surgical_priority = "emergency"
        elif stenosis_degree >= self.STENOSIS_SEVERE:
            severity = PathologySeverity.SEVERE
            significance = ClinicalSignificance.TREATMENT_URGENT
            surgical_priority = "urgent"
        elif stenosis_degree >= self.STENOSIS_MODERATE:
            severity = PathologySeverity.MODERATE
            significance = ClinicalSignificance.TREATMENT_ELECTIVE
            surgical_priority = "elective"
        else:
            severity = PathologySeverity.MILD
            significance = ClinicalSignificance.MONITOR
            surgical_priority = "surveillance"
        
        # TASC classification for peripheral arteries
        tasc = self._classify_tasc(vessel, stenosis_degree)
        
        # Detect plaque characteristics
        plaque_type = self._classify_plaque(vessel, volume)
        
        return StenosisFinding(
            pathology_type=PathologyType.STENOSIS,
            vessel_type=vessel.vessel_type,
            location=vessel.vessel_name,
            severity=severity,
            degree_percent=stenosis_degree,
            reference_diameter_mm=reference_diameter,
            minimal_lumen_diameter_mm=minimal_diameter,
            tasc_classification=tasc,
            plaque_type=plaque_type,
            surgical_priority=surgical_priority,
            significance=significance,
            confidence=0.80,
        )
    
    def _classify_tasc(self, vessel: SegmentedVessel, stenosis_degree: float) -> Optional[str]:
        """Classify peripheral lesion using TASC II criteria"""
        # Simplified TASC classification
        peripheral_vessels = [
            VesselType.A_ILIACA_COMMUNIS, VesselType.A_ILIACA_EXTERNA,
            VesselType.A_FEMORALIS, VesselType.A_POPLITEA
        ]
        
        if vessel.vessel_type not in peripheral_vessels:
            return None
        
        if stenosis_degree >= 100:
            return "D"
        elif stenosis_degree >= 80:
            return "C"
        elif stenosis_degree >= 70:
            return "B"
        else:
            return "A"
    
    def _classify_plaque(self, vessel: SegmentedVessel, volume: np.ndarray) -> str:
        """Classify plaque type based on CT characteristics"""
        mask = vessel.segmentation_mask
        vessel_region = volume[mask]
        
        if len(vessel_region) == 0:
            return "mixed"
        
        # Check for calcification (high HU)
        calcified_ratio = np.sum(vessel_region > 400) / len(vessel_region)
        
        # Check for soft plaque (low HU)
        soft_ratio = np.sum(vessel_region < 100) / len(vessel_region)
        
        if calcified_ratio > 0.5:
            return "calcified"
        elif soft_ratio > 0.3:
            return "soft"
        else:
            return "mixed"
    
    def _detect_occlusion(self, vessel: SegmentedVessel, volume: np.ndarray) -> Optional[PathologyFinding]:
        """Detect vessel occlusion"""
        # Check if vessel segment has no contrast
        if vessel.measurements.minimal_diameter_mm > 0:
            return None
        
        return PathologyFinding(
            pathology_type=PathologyType.OCCLUSION,
            vessel_type=vessel.vessel_type,
            location=vessel.vessel_name,
            severity=PathologySeverity.CRITICAL,
            category=PathologyCategory.DEGENERATIVE,
            acuity=PathologyAcuity.CHRONIC,
            significance=ClinicalSignificance.TREATMENT_URGENT,
            surgical_priority="urgent",
            confidence=0.75,
        )
    
    def _detect_thrombus(self, vessel: SegmentedVessel, volume: np.ndarray) -> Optional[ThrombosisFinding]:
        """Detect intraluminal thrombus"""
        mask = vessel.segmentation_mask
        vessel_region = volume[mask]
        
        if len(vessel_region) == 0:
            return None
        
        # Check for low-attenuation areas within vessel
        low_attenuation = np.sum(vessel_region < 100) / len(vessel_region)
        
        if low_attenuation < 0.2:
            return None
        
        # Determine if occlusive
        is_occlusive = low_attenuation > 0.7
        
        return ThrombosisFinding(
            pathology_type=PathologyType.THROMBOSIS,
            vessel_type=vessel.vessel_type,
            location=vessel.vessel_name,
            severity=PathologySeverity.MODERATE if not is_occlusive else PathologySeverity.SEVERE,
            category=PathologyCategory.DEGENERATIVE,
            acuity=PathologyAcuity.ACUTE,
            significance=ClinicalSignificance.TREATMENT_URGENT if is_occlusive else ClinicalSignificance.TREATMENT_ELECTIVE,
            thrombus_age="acute",
            is_occlusive=is_occlusive,
            embolic_risk="high" if is_occlusive else "moderate",
            surgical_priority="urgent" if is_occlusive else "elective",
            confidence=0.70,
        )
    
    def _detect_dissection(self, vessel: SegmentedVessel, volume: np.ndarray) -> Optional[DissectionFinding]:
        """Detect aortic dissection"""
        # Simplified dissection detection
        # In practice, would use more sophisticated algorithms
        
        # Check for intimal flap (two lumens with different contrast)
        # This is a placeholder implementation
        
        return None  # Would be implemented with proper detection algorithm
    
    def _detect_calcification(self, vessel: SegmentedVessel, volume: np.ndarray) -> Optional[PathologyFinding]:
        """Detect vessel calcification"""
        mask = vessel.segmentation_mask
        vessel_region = volume[mask]
        
        if len(vessel_region) == 0:
            return None
        
        # Check for calcification (HU > 400)
        calcified_voxels = np.sum(vessel_region > 400)
        calcification_ratio = calcified_voxels / len(vessel_region)
        
        if calcification_ratio < 0.1:
            return None
        
        # Determine severity
        if calcification_ratio > 0.5:
            severity = PathologySeverity.SEVERE
            calc_level = "severe"
        elif calcification_ratio > 0.3:
            severity = PathologySeverity.MODERATE
            calc_level = "moderate"
        else:
            severity = PathologySeverity.MILD
            calc_level = "mild"
        
        return PathologyFinding(
            pathology_type=PathologyType.CALCIFICATION,
            vessel_type=vessel.vessel_type,
            location=vessel.vessel_name,
            severity=severity,
            calcification=calc_level,
            category=PathologyCategory.DEGENERATIVE,
            acuity=PathologyAcuity.CHRONIC,
            significance=ClinicalSignificance.MONITOR,
            surgical_priority="elective",
            confidence=0.75,
        )
    
    def _detect_atherosclerosis(self, vessel: SegmentedVessel, volume: np.ndarray) -> Optional[PathologyFinding]:
        """Detect atherosclerotic disease"""
        # Check for irregular vessel wall
        # Simplified detection based on diameter variation
        
        measurements = vessel.measurements
        diameter_variation = (measurements.maximal_diameter_mm - measurements.minimal_diameter_mm) / measurements.proximal_diameter_mm
        
        if diameter_variation < 0.2:
            return None
        
        return PathologyFinding(
            pathology_type=PathologyType.ATHEROSCLEROSIS,
            vessel_type=vessel.vessel_type,
            location=vessel.vessel_name,
            severity=PathologySeverity.MODERATE,
            category=PathologyCategory.DEGENERATIVE,
            acuity=PathologyAcuity.CHRONIC,
            significance=ClinicalSignificance.MONITOR,
            surgical_priority="elective",
            confidence=0.65,
        )
    
    def _detect_tortuosity(self, vessel: SegmentedVessel, volume: np.ndarray) -> Optional[PathologyFinding]:
        """Detect arterial tortuosity"""
        # Calculate tortuosity from centerline
        centerline = vessel.centerline
        
        if len(centerline) < 10:
            return None
        
        # Calculate path length vs straight-line distance
        path_length = np.sum(np.sqrt(np.sum(np.diff(centerline, axis=0)**2, axis=1)))
        straight_distance = np.sqrt(np.sum((centerline[-1] - centerline[0])**2))
        
        if straight_distance == 0:
            return None
        
        tortuosity_index = path_length / straight_distance
        
        if tortuosity_index < 1.2:
            return None
        
        # Determine severity
        if tortuosity_index > 2.0:
            severity = PathologySeverity.SEVERE
            tortuosity_type = PathologyType.ARTERIAL_TORTUOSITY_SEVERE
        else:
            severity = PathologySeverity.MILD
            tortuosity_type = PathologyType.ARTERIAL_TORTUOSITY
        
        return PathologyFinding(
            pathology_type=tortuosity_type,
            vessel_type=vessel.vessel_type,
            location=vessel.vessel_name,
            severity=severity,
            category=PathologyCategory.CONGENITAL,
            acuity=PathologyAcuity.CHRONIC,
            significance=ClinicalSignificance.INCIDENTAL,
            surgical_priority="surveillance",
            confidence=0.60,
        )


def process_ct_angiography(dicom_files: List[FileDataset]) -> CTAngiographyStudy:
    """
    Main entry point for CT angiography processing
    
    Args:
        dicom_files: List of pydicom FileDataset objects
        
    Returns:
        CTAngiographyStudy with complete analysis
    """
    logger.info(f"Processing {len(dicom_files)} DICOM files...")
    
    # Sort files by slice position
    dicom_files.sort(key=lambda x: float(x.InstanceNumber) if hasattr(x, 'InstanceNumber') else 0)
    
    # Build 3D volume
    slices = []
    for ds in dicom_files:
        slices.append(ds.pixel_array)
    
    volume = np.stack(slices, axis=0)
    
    # Get spacing
    spacing = (
        float(dicom_files[0].PixelSpacing[0]) if hasattr(dicom_files[0], 'PixelSpacing') else 1.0,
        float(dicom_files[0].PixelSpacing[1]) if hasattr(dicom_files[0], 'PixelSpacing') else 1.0,
        float(dicom_files[0].SliceThickness) if hasattr(dicom_files[0], 'SliceThickness') else 1.0,
    )
    
    # Create study
    study = CTAngiographyStudy(
        study_id=getattr(dicom_files[0], 'StudyInstanceUID', 'unknown'),
        patient_id=getattr(dicom_files[0], 'PatientID', 'unknown'),
        acquisition_date=getattr(dicom_files[0], 'StudyDate', ''),
        contrast_phase="arterial",  # Detect from timing
        slice_thickness_mm=spacing[2],
        voxel_spacing=spacing,
    )
    
    # Segment vessels
    segmentation_engine = VesselSegmentationEngine()
    vessels = segmentation_engine.segment_vessels(volume, spacing)
    study.vessels = vessels
    
    # Detect pathologies
    pathology_detector = ComprehensivePathologyDetector()
    for vessel in vessels:
        pathologies = pathology_detector.analyze_vessel(vessel, volume)
        vessel.pathologies = pathologies
        
        # Add critical findings
        for pathology in pathologies:
            if pathology.requires_urgent_treatment:
                study.critical_findings.append(
                    f"URGENT: {pathology.description['name']} in {vessel.vessel_name}: "
                    f"{pathology.severity.value}"
                )
    
    # Generate pathology summary
    study.pathology_summary = _generate_pathology_summary(study)
    
    # Generate recommendations
    study.recommendations = _generate_recommendations(study)
    
    logger.info(f"Analysis complete. Found {len(study.critical_findings)} critical findings.")
    logger.info(f"Total pathologies: {study.pathology_count}")
    
    return study


def _generate_pathology_summary(study: CTAngiographyStudy) -> Dict[str, int]:
    """Generate summary of pathologies found"""
    summary = {}
    
    for vessel in study.vessels:
        for pathology in vessel.pathologies:
            pathology_name = pathology.pathology_type.value
            summary[pathology_name] = summary.get(pathology_name, 0) + 1
    
    return summary


def _generate_recommendations(study: CTAngiographyStudy) -> List[str]:
    """Generate clinical recommendations based on findings"""
    recommendations = []
    
    # Check for critical aneurysms
    critical_aneurysms = [
        p for p in study.get_pathologies_by_severity(PathologySeverity.CRITICAL)
        if p.pathology_type == PathologyType.ANEURYSM
    ]
    
    if critical_aneurysms:
        recommendations.append(
            "URGENT: Critical aneurysm(s) detected requiring immediate surgical evaluation"
        )
    
    # Check for severe stenosis
    severe_stenosis = [
        p for p in study.get_pathologies_by_severity(PathologySeverity.SEVERE)
        if p.pathology_type == PathologyType.STENOSIS
    ]
    
    if severe_stenosis:
        recommendations.append(
            f"Severe stenosis detected in {len(severe_stenosis)} vessel(s). Consider revascularization."
        )
    
    # Check for occlusions
    occlusions = study.get_pathologies_by_type(PathologyType.OCCLUSION)
    if occlusions:
        recommendations.append(
            f"Complete occlusion detected in {len(occlusions)} vessel(s). Evaluate for bypass."
        )
    
    # Check for thrombosis
    thrombosis = study.get_pathologies_by_type(PathologyType.THROMBOSIS)
    if thrombosis:
        recommendations.append(
            f"Thrombosis detected. Consider anticoagulation therapy."
        )
    
    # General recommendations
    if study.pathology_count == 0:
        recommendations.append("No significant vascular pathology detected. Continue routine surveillance.")
    
    return recommendations
