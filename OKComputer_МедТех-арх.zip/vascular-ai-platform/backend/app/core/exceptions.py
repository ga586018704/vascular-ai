"""
Custom Exceptions and Error Handling
"""
from fastapi import HTTPException, status
from typing import Optional, Dict, Any


class VascularAIException(Exception):
    """Base exception for VASCULAR.AI"""
    def __init__(self, message: str, details: Optional[Dict[str, Any]] = None):
        self.message = message
        self.details = details or {}
        super().__init__(self.message)


class NotFoundException(VascularAIException):
    """Resource not found"""
    def __init__(self, resource: str, identifier: str):
        super().__init__(
            message=f"{resource} with identifier '{identifier}' not found",
            details={"resource": resource, "identifier": identifier}
        )


class ValidationException(VascularAIException):
    """Validation error"""
    def __init__(self, field: str, message: str):
        super().__init__(
            message=f"Validation error for '{field}': {message}",
            details={"field": field, "error": message}
        )


class AuthenticationException(VascularAIException):
    """Authentication error"""
    def __init__(self, message: str = "Authentication failed"):
        super().__init__(message=message)


class AuthorizationException(VascularAIException):
    """Authorization error"""
    def __init__(self, message: str = "Insufficient permissions"):
        super().__init__(message=message)


class DicomProcessingException(VascularAIException):
    """DICOM processing error"""
    def __init__(self, message: str, file_path: Optional[str] = None):
        super().__init__(
            message=message,
            details={"file_path": file_path}
        )


class AIAnalysisException(VascularAIException):
    """AI analysis error"""
    def __init__(self, agent_type: str, message: str):
        super().__init__(
            message=f"AI analysis failed for {agent_type}: {message}",
            details={"agent_type": agent_type}
        )


class RateLimitException(VascularAIException):
    """Rate limit exceeded"""
    def __init__(self, retry_after: int):
        super().__init__(
            message=f"Rate limit exceeded. Retry after {retry_after} seconds",
            details={"retry_after": retry_after}
        )


# HTTP Exception mappings
def not_found_exception(resource: str, identifier: str) -> HTTPException:
    return HTTPException(
        status_code=status.HTTP_404_NOT_FOUND,
        detail={
            "error": "Not Found",
            "message": f"{resource} with identifier '{identifier}' not found",
            "resource": resource,
            "identifier": identifier
        }
    )


def validation_exception(field: str, message: str) -> HTTPException:
    return HTTPException(
        status_code=status.HTTP_422_UNPROCESSABLE_ENTITY,
        detail={
            "error": "Validation Error",
            "field": field,
            "message": message
        }
    )


def authentication_exception(message: str = "Authentication failed") -> HTTPException:
    return HTTPException(
        status_code=status.HTTP_401_UNAUTHORIZED,
        detail={
            "error": "Authentication Error",
            "message": message
        },
        headers={"WWW-Authenticate": "Bearer"}
    )


def authorization_exception(message: str = "Insufficient permissions") -> HTTPException:
    return HTTPException(
        status_code=status.HTTP_403_FORBIDDEN,
        detail={
            "error": "Authorization Error",
            "message": message
        }
    )


def rate_limit_exception(retry_after: int) -> HTTPException:
    return HTTPException(
        status_code=status.HTTP_429_TOO_MANY_REQUESTS,
        detail={
            "error": "Rate Limit Exceeded",
            "message": f"Too many requests. Retry after {retry_after} seconds",
            "retry_after": retry_after
        },
        headers={"Retry-After": str(retry_after)}
    )
