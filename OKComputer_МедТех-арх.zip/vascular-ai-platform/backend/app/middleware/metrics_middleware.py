"""
Metrics Collection Middleware
"""
import time
from fastapi import Request
from starlette.middleware.base import BaseHTTPMiddleware
from starlette.types import ASGIApp


class MetricsMiddleware(BaseHTTPMiddleware):
    """Middleware to collect request metrics"""
    
    def __init__(self, app: ASGIApp, exclude_paths: list = None):
        super().__init__(app)
        self.exclude_paths = exclude_paths or [
            "/metrics",
            "/health",
            "/ready",
            "/docs",
            "/openapi.json"
        ]
    
    async def dispatch(self, request: Request, call_next):
        # Skip excluded paths
        path = request.url.path
        for exclude in self.exclude_paths:
            if path.startswith(exclude):
                return await call_next(request)
        
        start_time = time.time()
        
        try:
            response = await call_next(request)
            status_code = response.status_code
        except Exception:
            status_code = 500
            raise
        finally:
            duration = time.time() - start_time
            # Metrics collection would go here
        
        return response
    
    def _normalize_path(self, path: str) -> str:
        """Normalize path by replacing IDs with placeholders"""
        parts = path.strip("/").split("/")
        normalized = []
        
        for part in parts:
            # Check if part looks like an ID (numeric or UUID)
            if part.isdigit() or (len(part) == 36 and "-" in part):
                normalized.append("{id}")
            else:
                normalized.append(part)
        
        return "/" + "/".join(normalized)
