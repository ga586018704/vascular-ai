"""
Request Timeout Middleware
Implements timeout for all incoming requests
"""

import asyncio
import time
from typing import Optional

from fastapi import Request, Response
from starlette.middleware.base import BaseHTTPMiddleware
from starlette.types import ASGIApp

from app.core.logging import get_logger

logger = get_logger(__name__)


class TimeoutMiddleware(BaseHTTPMiddleware):
    """
    Middleware that enforces request timeouts.
    
    Prevents long-running requests from consuming server resources.
    Returns 504 Gateway Timeout if request exceeds timeout.
    
    Args:
        app: ASGI application
        timeout_seconds: Maximum request duration (default: 60s)
        exclude_paths: List of paths to exclude from timeout
    """
    
    def __init__(
        self,
        app: ASGIApp,
        timeout_seconds: float = 60.0,
        exclude_paths: Optional[list] = None
    ):
        super().__init__(app)
        self.timeout_seconds = timeout_seconds
        self.exclude_paths = exclude_paths or [
            "/health",
            "/ready",
            "/live",
            "/docs",
            "/redoc",
            "/openapi.json",
            "/metrics"
        ]
    
    async def dispatch(self, request: Request, call_next) -> Response:
        """Process request with timeout enforcement"""
        path = request.url.path
        
        # Skip timeout for excluded paths
        if any(path.startswith(excluded) for excluded in self.exclude_paths):
            return await call_next(request)
        
        start_time = time.time()
        
        try:
            # Create task for request processing
            response_future = call_next(request)
            
            # Wait with timeout
            response = await asyncio.wait_for(
                response_future,
                timeout=self.timeout_seconds
            )
            
            # Add timeout info to headers
            elapsed = time.time() - start_time
            response.headers["X-Request-Duration"] = f"{elapsed:.3f}s"
            response.headers["X-Timeout-Limit"] = f"{self.timeout_seconds}s"
            
            return response
            
        except asyncio.TimeoutError:
            elapsed = time.time() - start_time
            logger.warning(
                f"Request timeout: {request.method} {path} "
                f"({elapsed:.2f}s > {self.timeout_seconds}s)",
                extra={
                    "request_id": getattr(request.state, "request_id", None),
                    "duration": elapsed,
                    "timeout": self.timeout_seconds
                }
            )
            
            return Response(
                content='{"detail": "Request timeout", "timeout": ' + 
                        f'{self.timeout_seconds}}',
                status_code=504,
                headers={
                    "Content-Type": "application/json",
                    "X-Request-Duration": f"{elapsed:.3f}s",
                    "X-Timeout-Limit": f"{self.timeout_seconds}s"
                }
            )
        
        except Exception as e:
            elapsed = time.time() - start_time
            logger.error(
                f"Request error after {elapsed:.2f}s: {e}",
                extra={"request_id": getattr(request.state, "request_id", None)}
            )
            raise


class TimeoutConfig:
    """Configuration for timeout middleware"""
    
    # Default timeout for most endpoints
    DEFAULT_TIMEOUT = 60.0
    
    # Extended timeout for long operations
    LONG_OPERATION_TIMEOUT = 300.0  # 5 minutes
    
    # Short timeout for quick operations
    QUICK_TIMEOUT = 10.0
    
    # Path-specific timeouts
    PATH_TIMEOUTS = {
        # DICOM upload and processing
        "/api/v1/dicom/upload": 300.0,
        "/api/v1/angiography/analyze": 300.0,
        "/api/v1/angiography/segment": 300.0,
        "/api/v1/ai/analyze": 120.0,
        "/api/v1/reports/generate": 120.0,
        "/api/v1/studies/compare": 180.0,
        
        # Export operations
        "/api/v1/reports/export": 180.0,
        "/api/v1/analytics/export": 180.0,
    }
    
    @classmethod
    def get_timeout_for_path(cls, path: str) -> float:
        """Get timeout for specific path"""
        for pattern, timeout in cls.PATH_TIMEOUTS.items():
            if path.startswith(pattern.replace("/v1", "").replace("/api", "")):
                return timeout
        return cls.DEFAULT_TIMEOUT
