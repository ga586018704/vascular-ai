"""
Global Error Handler Middleware
"""
import traceback
import uuid
from fastapi import Request, HTTPException
from fastapi.responses import JSONResponse
from starlette.middleware.base import BaseHTTPMiddleware
from starlette.types import ASGIApp
import logging

from app.core.exceptions import VascularAIException
from app.core.logging import get_logger

logger = get_logger(__name__)


class ErrorHandlerMiddleware(BaseHTTPMiddleware):
    """Global error handler middleware"""
    
    def __init__(self, app: ASGIApp, debug: bool = False):
        super().__init__(app)
        self.debug = debug
    
    async def dispatch(self, request: Request, call_next):
        request_id = str(uuid.uuid4())[:8]
        request.state.request_id = request_id
        
        try:
            response = await call_next(request)
            response.headers["X-Request-ID"] = request_id
            return response
            
        except HTTPException as exc:
            # Handle FastAPI HTTP exceptions
            logger.warning(
                f"HTTP Exception [{request_id}]: {exc.status_code} - {exc.detail}",
                extra={
                    "request_id": request_id,
                    "status_code": exc.status_code,
                    "path": request.url.path,
                    "method": request.method
                }
            )
            
            return JSONResponse(
                status_code=exc.status_code,
                headers={"X-Request-ID": request_id},
                content={
                    "error": True,
                    "request_id": request_id,
                    "status_code": exc.status_code,
                    "detail": exc.detail if isinstance(exc.detail, dict) else {"message": exc.detail}
                }
            )
            
        except VascularAIException as exc:
            # Handle custom exceptions
            logger.error(
                f"Application Exception [{request_id}]: {exc.message}",
                extra={
                    "request_id": request_id,
                    "exception_type": type(exc).__name__,
                    "details": exc.details
                }
            )
            
            return JSONResponse(
                status_code=400,
                headers={"X-Request-ID": request_id},
                content={
                    "error": True,
                    "request_id": request_id,
                    "status_code": 400,
                    "type": type(exc).__name__,
                    "message": exc.message,
                    "details": exc.details
                }
            )
            
        except Exception as exc:
            # Handle unexpected exceptions
            error_trace = traceback.format_exc() if self.debug else None
            
            logger.error(
                f"Unhandled Exception [{request_id}]: {str(exc)}",
                extra={
                    "request_id": request_id,
                    "exception_type": type(exc).__name__,
                    "traceback": traceback.format_exc()
                },
                exc_info=True
            )
            
            response_content = {
                "error": True,
                "request_id": request_id,
                "status_code": 500,
                "type": "InternalServerError",
                "message": "An unexpected error occurred"
            }
            
            if self.debug:
                response_content["debug"] = {
                    "exception": str(exc),
                    "type": type(exc).__name__,
                    "traceback": error_trace
                }
            
            return JSONResponse(
                status_code=500,
                headers={"X-Request-ID": request_id},
                content=response_content
            )
