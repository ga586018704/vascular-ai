"""
Audit Middleware - Automatically logs all API requests
"""
from fastapi import Request
from starlette.middleware.base import BaseHTTPMiddleware
from starlette.types import ASGIApp
import time


class AuditMiddleware(BaseHTTPMiddleware):
    """Middleware to automatically audit all API requests"""
    
    def __init__(self, app: ASGIApp, exclude_paths: list = None):
        super().__init__(app)
        self.exclude_paths = exclude_paths or [
            "/health",
            "/docs",
            "/openapi.json",
            "/static/",
            "/favicon.ico",
            "/api/metrics"
        ]
    
    async def dispatch(self, request: Request, call_next):
        # Skip excluded paths
        path = request.url.path
        for exclude in self.exclude_paths:
            if path.startswith(exclude):
                return await call_next(request)
        
        start_time = time.time()
        
        # Process request
        try:
            response = await call_next(request)
            success = response.status_code < 400
        except Exception:
            success = False
            raise
        finally:
            # Log the request (fire-and-forget)
            duration = time.time() - start_time
            # Audit logging is handled separately to not block response
        
        return response
