"""
Rate Limiting Middleware with Redis Backend
Production-ready rate limiting for distributed deployments
"""
import time
import json
from fastapi import Request, HTTPException
from starlette.middleware.base import BaseHTTPMiddleware
from starlette.types import ASGIApp
from typing import Dict, Optional
import logging

from app.core.config import get_settings

logger = logging.getLogger(__name__)


class RateLimitMiddleware(BaseHTTPMiddleware):
    """
    Rate limiting middleware using Redis for distributed deployments.
    Falls back to in-memory storage if Redis is unavailable.
    """
    
    def __init__(
        self,
        app: ASGIApp,
        requests_per_minute: int = 100,
        burst_size: int = 20,
        exclude_paths: list = None,
        storage_backend: str = "auto"  # auto, redis, memory
    ):
        super().__init__(app)
        self.requests_per_minute = requests_per_minute
        self.burst_size = burst_size
        self.exclude_paths = exclude_paths or [
            "/health",
            "/ready",
            "/live",
            "/docs",
            "/openapi.json",
            "/redoc",
            "/static",
            "/favicon.ico"
        ]
        self.storage_backend = storage_backend
        
        # Redis client (initialized lazily)
        self._redis = None
        
        # In-memory fallback storage
        self._memory_requests: Dict[str, list] = {}
        self._memory_blocked: Dict[str, float] = {}
        
        # Track storage mode
        self._using_redis = False
    
    def _get_redis(self):
        """Get Redis client with lazy initialization"""
        if self._redis is None and self.storage_backend in ("auto", "redis"):
            try:
                import redis.asyncio as redis
                settings = get_settings()
                self._redis = redis.from_url(
                    settings.REDIS_URL,
                    decode_responses=True,
                    socket_connect_timeout=5,
                    socket_timeout=5,
                    retry_on_timeout=True
                )
                self._using_redis = True
                logger.info("Rate limiting using Redis backend")
            except Exception as e:
                logger.warning(f"Redis unavailable for rate limiting: {e}. Using memory backend.")
                self._using_redis = False
        return self._redis
    
    async def dispatch(self, request: Request, call_next):
        # Skip excluded paths
        path = request.url.path
        for exclude in self.exclude_paths:
            if path.startswith(exclude):
                return await call_next(request)
        
        # Get client identifier
        client_id = self._get_client_id(request)
        current_time = time.time()
        
        # Check rate limit
        if self._using_redis and self._get_redis():
            allowed, retry_after = await self._check_rate_limit_redis(
                client_id, current_time
            )
        else:
            allowed, retry_after = self._check_rate_limit_memory(
                client_id, current_time
            )
        
        if not allowed:
            raise HTTPException(
                status_code=429,
                detail={
                    "error": "Rate Limit Exceeded",
                    "message": f"Rate limit of {self.requests_per_minute} requests per minute exceeded",
                    "retry_after": retry_after
                },
                headers={
                    "Retry-After": str(retry_after),
                    "X-RateLimit-Limit": str(self.requests_per_minute),
                    "X-RateLimit-Remaining": "0",
                    "X-RateLimit-Reset": str(int(current_time + retry_after))
                }
            )
        
        # Process request
        response = await call_next(request)
        
        # Add rate limit headers
        remaining = self.requests_per_minute - self._get_request_count(client_id, current_time) - 1
        response.headers["X-RateLimit-Limit"] = str(self.requests_per_minute)
        response.headers["X-RateLimit-Remaining"] = str(max(0, remaining))
        response.headers["X-RateLimit-Reset"] = str(int(current_time + 60))
        
        return response
    
    async def _check_rate_limit_redis(self, client_id: str, current_time: float) -> tuple[bool, int]:
        """Check rate limit using Redis"""
        redis = self._get_redis()
        if not redis:
            return self._check_rate_limit_memory(client_id, current_time)
        
        window_start = current_time - 60  # 1 minute window
        key = f"rate_limit:{client_id}"
        block_key = f"rate_limit:blocked:{client_id}"
        
        try:
            # Check if blocked
            blocked_until = await redis.get(block_key)
            if blocked_until:
                blocked_until = float(blocked_until)
                if current_time < blocked_until:
                    retry_after = int(blocked_until - current_time)
                    return False, retry_after
                else:
                    await redis.delete(block_key)
            
            # Get requests in current window using sorted set
            # Remove old entries
            await redis.zremrangebyscore(key, 0, window_start)
            
            # Count current requests
            request_count = await redis.zcard(key)
            
            # Check rate limit
            if request_count >= self.requests_per_minute:
                # Block client
                block_duration = 60
                await redis.setex(block_key, block_duration, str(current_time + block_duration))
                logger.warning(f"Rate limit exceeded for client: {client_id}")
                return False, block_duration
            
            # Check burst limit
            recent_count = await redis.zcount(key, current_time - 1, current_time)
            if recent_count >= self.burst_size:
                return False, 1
            
            # Add current request
            await redis.zadd(key, {str(current_time): current_time})
            await redis.expire(key, 120)  # Expire after 2 minutes
            
            return True, 0
            
        except Exception as e:
            logger.error(f"Redis rate limit error: {e}. Falling back to memory.")
            self._using_redis = False
            return self._check_rate_limit_memory(client_id, current_time)
    
    def _check_rate_limit_memory(self, client_id: str, current_time: float) -> tuple[bool, int]:
        """Check rate limit using in-memory storage (fallback)"""
        window_start = current_time - 60
        
        # Check if blocked
        if client_id in self._memory_blocked:
            if current_time < self._memory_blocked[client_id]:
                retry_after = int(self._memory_blocked[client_id] - current_time)
                return False, retry_after
            else:
                del self._memory_blocked[client_id]
        
        # Clean old requests
        if client_id in self._memory_requests:
            self._memory_requests[client_id] = [
                ts for ts in self._memory_requests[client_id] if ts > window_start
            ]
        else:
            self._memory_requests[client_id] = []
        
        # Check rate limit
        request_count = len(self._memory_requests.get(client_id, []))
        
        if request_count >= self.requests_per_minute:
            block_duration = 60
            self._memory_blocked[client_id] = current_time + block_duration
            logger.warning(f"Rate limit exceeded for client: {client_id}")
            return False, block_duration
        
        # Check burst limit
        recent_requests = len([
            ts for ts in self._memory_requests.get(client_id, [])
            if ts > current_time - 1
        ])
        
        if recent_requests >= self.burst_size:
            return False, 1
        
        # Record request
        self._memory_requests[client_id].append(current_time)
        
        return True, 0
    
    def _get_request_count(self, client_id: str, current_time: float) -> int:
        """Get current request count for a client"""
        if self._using_redis and self._get_redis():
            # Async operation - return estimate
            return len(self._memory_requests.get(client_id, []))
        return len(self._memory_requests.get(client_id, []))
    
    def _get_client_id(self, request: Request) -> str:
        """Get unique client identifier"""
        # Try to get from authenticated user
        user = getattr(request.state, "user", None)
        if user and hasattr(user, "id"):
            return f"user:{user.id}"
        
        # Fall back to API key if present
        api_key = request.headers.get("X-API-Key")
        if api_key:
            return f"api:{api_key[:8]}"
        
        # Fall back to IP address
        forwarded = request.headers.get("X-Forwarded-For")
        if forwarded:
            return f"ip:{forwarded.split(',')[0].strip()}"
        
        if request.client:
            return f"ip:{request.client.host}"
        
        return "ip:unknown"


# Convenience function for testing rate limits
async def check_rate_limit(client_id: str, redis_client=None) -> dict:
    """Check current rate limit status for a client"""
    settings = get_settings()
    
    result = {
        "client_id": client_id,
        "limit": settings.RATE_LIMIT_REQUESTS,
        "window": settings.RATE_LIMIT_WINDOW,
        "remaining": settings.RATE_LIMIT_REQUESTS,
        "reset_time": int(time.time() + settings.RATE_LIMIT_WINDOW)
    }
    
    if redis_client:
        key = f"rate_limit:{client_id}"
        window_start = time.time() - settings.RATE_LIMIT_WINDOW
        
        try:
            await redis_client.zremrangebyscore(key, 0, window_start)
            count = await redis_client.zcard(key)
            result["remaining"] = max(0, settings.RATE_LIMIT_REQUESTS - count)
        except Exception:
            pass
    
    return result
