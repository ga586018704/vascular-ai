"""
VASCULAR.AI - Advanced Vascular Medicine AI Platform
Main FastAPI Application
"""

import logging
from contextlib import asynccontextmanager
from datetime import datetime

from fastapi import FastAPI, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.middleware.trustedhost import TrustedHostMiddleware
from fastapi.responses import JSONResponse, RedirectResponse

from app.api.v1 import api_v1_router
from app.core.config import get_settings

settings = get_settings()
from app.core.cache import cache
from app.core.health import health_checker
from app.core.logging import setup_logging, get_logger
from app.db.session import engine, Base

# Middleware imports
from app.middleware.audit_middleware import AuditMiddleware
from app.middleware.metrics_middleware import MetricsMiddleware
from app.middleware.rate_limit import RateLimitMiddleware
from app.middleware.error_handler import ErrorHandlerMiddleware
from app.middleware.security_headers import SecurityHeadersMiddleware
from app.middleware.timeout import TimeoutMiddleware

# Setup logging
setup_logging()
logger = get_logger(__name__)


@asynccontextmanager
async def lifespan(app: FastAPI):
    """Application lifespan handler"""
    logger.info("=" * 60)
    logger.info("Starting up VASCULAR.AI Platform v2.0.0")
    logger.info("=" * 60)
    
    # Initialize database
    try:
        async with engine.begin() as conn:
            await conn.run_sync(Base.metadata.create_all)
        logger.info("Database initialized successfully")
    except Exception as e:
        logger.error(f"Database initialization failed: {e}")
        raise
    
    # Initialize cache
    try:
        await cache.connect()
        logger.info("Cache connected successfully")
    except Exception as e:
        logger.warning(f"Cache connection failed: {e}")
    
    yield
    
    # Shutdown
    logger.info("Shutting down VASCULAR.AI Platform...")
    try:
        await cache.disconnect()
        await engine.dispose()
        logger.info("Cleanup completed")
    except Exception as e:
        logger.error(f"Shutdown error: {e}")


# Initialize FastAPI app with enhanced configuration
app = FastAPI(
    title="VASCULAR.AI API",
    description="""
    Advanced AI-Powered Vascular Medicine Platform
    
    ## Features
    
    * **Authentication**: JWT-based authentication with role-based access control
    * **DICOM Processing**: Upload and process medical imaging files
    * **CT Angiography Analysis**: Automated vessel segmentation and pathology detection
    * **AI Agents**: 8 specialized AI agents for different vascular pathologies
    * **Risk Calculators**: VSGNE, Wells, and GAS risk scores
    * **Reports**: Generate and manage medical reports
    * **Analytics**: Dashboard and system monitoring
    * **Real-time**: WebSocket support for live updates
    
    ## Authentication
    
    Most endpoints require authentication. Use the `/api/auth/login` endpoint to obtain a JWT token,
    then include it in the Authorization header: `Bearer <token>`
    """,
    version="2.0.0",
    docs_url="/docs",
    redoc_url="/redoc",
    openapi_url="/openapi.json",
    lifespan=lifespan,
    contact={
        "name": "VASCULAR.AI Support",
        "email": "support@vascular.ai"
    },
    license_info={
        "name": "Proprietary",
        "url": "https://vascular.ai/license"
    }
)

# ============================================
# MIDDLEWARE (Order matters - first added = first executed)
# ============================================

# 1. Error Handler (catches all errors)
app.add_middleware(
    ErrorHandlerMiddleware,
    debug=settings.DEBUG
)

# 2. Security Headers
app.add_middleware(SecurityHeadersMiddleware)

# 3. Rate Limiting
app.add_middleware(
    RateLimitMiddleware,
    requests_per_minute=settings.RATE_LIMIT_REQUESTS,
    burst_size=20
)

# 4. CORS
app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.ALLOWED_ORIGINS,
    allow_credentials=True,
    allow_methods=["GET", "POST", "PUT", "DELETE", "PATCH", "OPTIONS"],
    allow_headers=["*"],
    expose_headers=["X-Request-ID", "X-RateLimit-Limit", "X-RateLimit-Remaining"]
)

# 5. Trusted Host
app.add_middleware(
    TrustedHostMiddleware,
    allowed_hosts=["*"] if settings.DEBUG else ["vascular.ai", "*.vascular.ai", "localhost"]
)

# 6. Metrics Collection
app.add_middleware(MetricsMiddleware)

# 7. Audit Logging (HIPAA compliance)
app.add_middleware(AuditMiddleware)

# 8. Request Timeout
app.add_middleware(
    TimeoutMiddleware,
    timeout_seconds=60.0,
    exclude_paths=[
        "/health",
        "/ready",
        "/live",
        "/docs",
        "/redoc",
        "/openapi.json",
        "/metrics",
        "/health/detailed"
    ]
)


# ============================================
# ROUTERS - API Versioning
# ============================================

# API v1 routes (current version)
app.include_router(
    api_v1_router,
    prefix="/api/v1",
    tags=["API v1"]
)

# Legacy routes for backward compatibility (deprecated)
# These will be removed in v2.0
app.include_router(
    api_v1_router,
    prefix="/api",
    tags=["API (Legacy - Deprecated)"],
    deprecated=True
)


# ============================================
# ENDPOINTS
# ============================================

@app.get("/", tags=["Root"], include_in_schema=False)
async def root():
    """Redirect to docs"""
    return RedirectResponse(url="/docs")


@app.get("/health", tags=["Health"])
async def health_check():
    """
    Health check endpoint
    
    Returns the current status of the API and its dependencies.
    """
    return {
        "status": "healthy",
        "timestamp": datetime.utcnow().isoformat(),
        "version": "2.0.0",
        "service": "VASCULAR.AI API",
        "environment": "production" if not settings.DEBUG else "development",
        "features": [
            "Authentication",
            "DICOM Processing",
            "CT Angiography Analysis",
            "AI Vessel Segmentation (ONNX/PyTorch)",
            "Pathology Classification",
            "Treatment Recommendations",
            "Study Comparison (Progression Tracking)",
            "AI Agents (8 types)",
            "Risk Calculators (VSGNE, Wells, GAS)",
            "PDF Reports",
            "WebSocket Real-time",
            "LLM Integration (GPT-4, Claude)",
            "Audit Logging (HIPAA)",
            "Redis Caching",
            "Celery Background Tasks",
            "Analytics Dashboard",
            "Prometheus Metrics",
            "Dark Mode",
            "PWA Support",
            "Multi-language Support"
        ],
        "links": {
            "documentation": "/docs",
            "redoc": "/redoc",
            "openapi": "/openapi.json"
        }
    }


@app.get("/ready", tags=["Health"])
async def readiness_check():
    """
    Readiness probe for Kubernetes
    
    Checks if the application is ready to receive traffic.
    """
    try:
        # Check database connection
        from sqlalchemy import text
        async with engine.connect() as conn:
            await conn.execute(text("SELECT 1"))
        
        return {
            "status": "ready",
            "timestamp": datetime.utcnow().isoformat(),
            "checks": {
                "database": "ok",
                "cache": "ok" if cache.is_connected else "degraded"
            }
        }
    except Exception as e:
        logger.error(f"Readiness check failed: {e}")
        return JSONResponse(
            status_code=503,
            content={
                "status": "not_ready",
                "timestamp": datetime.utcnow().isoformat(),
                "error": str(e)
            }
        )


@app.get("/live", tags=["Health"])
async def liveness_check():
    """
    Liveness probe for Kubernetes
    
    Checks if the application is running.
    """
    return {
        "status": "alive",
        "timestamp": datetime.utcnow().isoformat()
    }


@app.get("/health/detailed", tags=["Health"])
async def detailed_health_check():
    """
    Comprehensive health check with all dependencies
    
    Returns detailed status of all services:
    - Database connectivity and pool stats
    - Redis cache status
    - External API availability (OpenAI, Anthropic)
    - Disk space
    - Memory usage
    """
    return await health_checker.run_all_checks()


@app.get("/health/history", tags=["Health"])
async def health_history(limit: int = 100):
    """
    Get health check history
    
    Returns recent health check results for trend analysis.
    """
    return {
        "history": health_checker._check_history[-limit:],
        "total_records": len(health_checker._check_history)
    }


# ============================================
# MAIN
# ============================================

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(
        "app.main:app",
        host="0.0.0.0",
        port=8000,
        reload=settings.DEBUG,
        log_level="debug" if settings.DEBUG else "info",
        access_log=settings.DEBUG
    )
