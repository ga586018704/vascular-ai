"""
Endovascular AI Agent
Specialized in endovascular procedures and interventions
"""

import re
from typing import Dict, List, Optional

from app.agents.llm_agent import LLMEnhancedAgent
from app.schemas.ai_agents import AgentAnalysis, AgentCapability


class EndovascularAgent(LLMEnhancedAgent):
    """Endovascular procedures AI Agent"""
    
    def __init__(self):
        super().__init__()
        self.agent_id = "endovascular_specialist"
        self.name = "Endovascular Specialist"
        self.description = "AI specialist in endovascular procedures and interventions"
        self.specialty = "endovascular"
        
    def get_capabilities(self) -> List[AgentCapability]:
        """Get agent capabilities"""
        return [
            AgentCapability(
                name="EVAR/TEVAR Planning",
                description="Endovascular aneurysm repair planning and sizing",
                parameters=["aneurysm_location", "neck_diameter", "neck_length", "iliac_diameter"]
            ),
            AgentCapability(
                name="Stent Graft Selection",
                description="Recommend appropriate stent graft devices",
                parameters=["anatomy", "aneurysm_size", "access_vessels"]
            ),
            AgentCapability(
                name="Access Site Planning",
                description="Plan vascular access for endovascular procedures",
                parameters=["access_vessel", "sheath_size", "anatomy"]
            ),
            AgentCapability(
                name="Complication Management",
                description="Endovascular complication assessment and management",
                parameters=["complication_type", "severity", "timing"]
            ),
            AgentCapability(
                name="Follow-up Protocol",
                description="Post-procedure surveillance recommendations",
                parameters=["procedure_type", "device", "risk_factors"]
            )
        ]
    
    def _get_system_prompt(self) -> str:
        """Get LLM system prompt for endovascular specialist"""
        return """You are an expert Endovascular Specialist AI assistant with extensive knowledge of:
- Endovascular aneurysm repair (EVAR, TEVAR, FEVAR)
- Stent graft selection and sizing
- Vascular access planning
- Endovascular complication management
- Post-procedure surveillance protocols
- Device selection and compatibility

Provide detailed, evidence-based recommendations for endovascular procedures.
Include specific measurements, device recommendations, and follow-up protocols.
Always emphasize the importance of proper sizing and anatomical suitability."""
    
    def _rule_based_analysis(self, query: str, patient_context: Optional[Dict] = None) -> AgentAnalysis:
        """Rule-based analysis for endovascular queries"""
        query_lower = query.lower()
        findings = []
        recommendations = []
        warnings = []
        
        # EVAR/TEVAR Planning
        if any(term in query_lower for term in ["evar", "tevar", "aneurysm repair", "stent graft"]):
            findings.append("Endovascular aneurysm repair procedure identified")
            
            # Check for required measurements
            if patient_context:
                neck_diameter = patient_context.get("neck_diameter")
                neck_length = patient_context.get("neck_length")
                
                if neck_diameter and float(neck_diameter) > 32:
                    warnings.append("Neck diameter >32mm may require custom or fenestrated device")
                
                if neck_length and float(neck_length) < 10:
                    warnings.append("Short neck (<10mm) - consider fenestrated or snorkel technique")
            
            recommendations.extend([
                "Obtain high-quality CTA with 1mm slice thickness",
                "Measure infrarenal neck diameter and length",
                "Assess iliac artery diameter and tortuosity",
                "Evaluate access vessel suitability",
                "Plan for bilateral groin access or percutaneous approach"
            ])
        
        # Stent Graft Selection
        if any(term in query_lower for term in ["stent graft", "device selection", "graft sizing"]):
            findings.append("Stent graft device selection required")
            
            recommendations.extend([
                "Oversize stent graft by 10-20% for infrarenal neck",
                "Ensure minimum 10mm proximal seal zone",
                "Consider iliac limb extensions if needed",
                "Verify device compatibility with access vessels",
                "Have multiple device sizes available"
            ])
        
        # Access Site Planning
        if any(term in query_lower for term in ["access", "femoral", "iliac access", "sheath"]):
            findings.append("Vascular access planning required")
            
            recommendations.extend([
                "Assess common femoral artery diameter",
                "Evaluate for significant calcification or disease",
                "Consider percutaneous access with pre-close technique",
                "Plan for surgical cutdown if needed",
                "Ensure adequate sheath size for selected device"
            ])
        
        # Complications
        if any(term in query_lower for term in ["complication", "endoleak", "migration", "occlusion"]):
            findings.append("Endovascular complication assessment")
            
            if "endoleak" in query_lower:
                findings.append("Endoleak identified - requires classification")
                recommendations.extend([
                    "Type I: Consider cuff extension or embolization",
                    "Type II: Observe if small, embolize if expanding",
                    "Type III: Requires immediate repair",
                    "Type IV: Usually self-limiting",
                    "Type V ( endotension ): Consider relining or open conversion"
                ])
            
            if "migration" in query_lower:
                warnings.append("Graft migration can lead to rupture risk")
                recommendations.extend([
                    "Assess proximal seal zone integrity",
                    "Consider proximal extension cuff",
                    "Evaluate for anatomical changes",
                    "May require open conversion in severe cases"
                ])
        
        # Follow-up
        if any(term in query_lower for term in ["follow-up", "surveillance", "monitoring", "cta schedule"]):
            findings.append("Post-procedure surveillance planning")
            
            recommendations.extend([
                "1-month CTA to assess immediate results",
                "6-month CTA for baseline surveillance",
                "Annual CTA thereafter if stable",
                "More frequent imaging for high-risk patients",
                "Lifetime surveillance recommended"
            ])
        
        # Default response if no specific pattern matched
        if not findings:
            findings.append("Endovascular consultation request received")
            recommendations.extend([
                "Please provide specific procedure details",
                "Include relevant anatomical measurements",
                "Specify patient comorbidities and risk factors"
            ])
        
        confidence = self._calculate_confidence(findings, warnings)
        
        return AgentAnalysis(
            agent_id=self.agent_id,
            agent_name=self.name,
            findings=findings,
            recommendations=recommendations,
            confidence_score=confidence,
            warnings=warnings if warnings else None,
            suggested_tests=None,
            follow_up=None
        )
    
    def _calculate_confidence(self, findings: List[str], warnings: List[str]) -> float:
        """Calculate confidence score"""
        base_confidence = 85.0
        
        # Increase confidence with more findings
        base_confidence += min(len(findings) * 2, 10)
        
        # Decrease if warnings present
        if warnings:
            base_confidence -= len(warnings) * 3
        
        return max(70.0, min(base_confidence, 95.0))
