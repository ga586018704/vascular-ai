"""
Pediatric Vascular AI Agent
Specialized in pediatric vascular conditions and congenital anomalies
"""

import re
from typing import Dict, List, Optional

from app.agents.llm_agent import LLMEnhancedAgent
from app.schemas.ai_agents import AgentAnalysis, AgentCapability


class PediatricVascularAgent(LLMEnhancedAgent):
    """Pediatric Vascular Medicine AI Agent"""
    
    def __init__(self):
        super().__init__()
        self.agent_id = "pediatric_vascular"
        self.name = "Pediatric Vascular Specialist"
        self.description = "AI specialist in pediatric vascular diseases and congenital anomalies"
        self.specialty = "pediatric_vascular"
        
    def get_capabilities(self) -> List[AgentCapability]:
        """Get agent capabilities"""
        return [
            AgentCapability(
                name="Congenital Vascular Anomalies",
                description="Assessment of congenital vascular malformations",
                parameters=["anomaly_type", "age", "location", "symptoms"]
            ),
            AgentCapability(
                name="Pediatric Aortic Disease",
                description="Coarctation, arch anomalies in children",
                parameters=["diagnosis", "age", "weight", "symptoms"]
            ),
            AgentCapability(
                name="Vascular Tumors",
                description="Hemangiomas and vascular tumors in children",
                parameters=["tumor_type", "age", "location", "growth_pattern"]
            ),
            AgentCapability(
                name="Growth Considerations",
                description="Vascular interventions considering growth",
                parameters=["age", "expected_growth", "procedure_type"]
            ),
            AgentCapability(
                name="Developmental Milestones",
                description="Assessment considering developmental stage",
                parameters=["age", "developmental_stage", "condition"]
            )
        ]
    
    def _get_system_prompt(self) -> str:
        """Get LLM system prompt for pediatric specialist"""
        return """You are an expert Pediatric Vascular Specialist AI assistant with extensive knowledge of:
- Congenital vascular anomalies (CVMs)
- Pediatric aortic diseases (coarctation, arch hypoplasia)
- Vascular tumors and malformations
- Growth considerations in vascular interventions
- Age-appropriate diagnostic and treatment approaches
- Developmental impact of vascular diseases

Provide detailed, age-appropriate recommendations for pediatric vascular conditions.
Always consider growth potential, developmental stage, and long-term outcomes.
Emphasize the importance of specialized pediatric vascular centers and multidisciplinary care."""
    
    def _rule_based_analysis(self, query: str, patient_context: Optional[Dict] = None) -> AgentAnalysis:
        """Rule-based analysis for pediatric vascular queries"""
        query_lower = query.lower()
        findings = []
        recommendations = []
        warnings = []
        
        age = None
        if patient_context:
            age = patient_context.get("age")
        
        # Congenital Vascular Anomalies
        if any(term in query_lower for term in ["vascular anomaly", "malformation", "avm", "hemangioma", "lymphatic"]):
            findings.append("Congenital vascular anomaly identified")
            
            if "hemangioma" in query_lower:
                findings.append("Infantile hemangioma - most common vascular tumor")
                recommendations.extend([
                    "Most hemangiomas involute spontaneously",
                    "Consider propranolol for complicated hemangiomas",
                    "Refer to vascular anomalies center",
                    "Monitor for ulceration or visual obstruction",
                    "Photograph for documentation of growth"
                ])
            
            if "avm" in query_lower or "arteriovenous malformation" in query_lower:
                findings.append("Arteriovenous malformation - high-flow lesion")
                warnings.append("AVMs do not involute and may expand over time")
                recommendations.extend([
                    "MRI with contrast for full assessment",
                    "Consider angiography for treatment planning",
                    "Embolization may be indicated",
                    "Multidisciplinary team approach recommended",
                    "Long-term surveillance required"
                ])
        
        # Coarctation of Aorta
        if any(term in query_lower for term in ["coarctation", "aortic arch", "arch hypoplasia", "isthmus"]):
            findings.append("Aortic coarctation or arch anomaly suspected")
            
            if age and float(age) < 1:
                warnings.append("Neonatal coarctation may require urgent intervention")
            
            recommendations.extend([
                "Echocardiogram for initial assessment",
                "CTA or MRA for arch anatomy detail",
                "Assess for associated cardiac defects",
                "Monitor for hypertension",
                "Consider balloon angioplasty or surgery"
            ])
        
        # Growth Considerations
        if any(term in query_lower for term in ["growth", "growing", "child development", "adolescent"]):
            findings.append("Growth considerations for vascular intervention")
            
            recommendations.extend([
                "Consider growth potential in intervention planning",
                "Avoid permanent implants when possible in young children",
                "Plan for re-intervention as child grows",
                "Use age-appropriate device sizes",
                "Long-term follow-up into adulthood recommended"
            ])
        
        # Kawasaki Disease
        if "kawasaki" in query_lower:
            findings.append("Kawasaki disease with potential coronary involvement")
            recommendations.extend([
                "Echocardiogram to assess coronary arteries",
                "IVIG and aspirin per protocol",
                "Long-term cardiology follow-up",
                "Monitor for coronary aneurysms",
                "Activity restrictions if aneurysms present"
            ])
        
        # Renovascular Hypertension
        if any(term in query_lower for term in ["renovascular", "renal artery stenosis", "pediatric hypertension"]):
            findings.append("Pediatric renovascular hypertension")
            recommendations.extend([
                "MRA or CTA of renal arteries",
                "Doppler ultrasound as screening",
                "Consider fibromuscular dysplasia or vasculitis",
                "Angioplasty may be effective",
                "Monitor blood pressure closely"
            ])
        
        # General Pediatric Vascular
        if not findings:
            findings.append("Pediatric vascular consultation request")
            recommendations.extend([
                "Refer to pediatric vascular specialist",
                "Consider age-appropriate imaging",
                "Assess growth and developmental status",
                "Family history of vascular conditions",
                "Multidisciplinary care approach"
            ])
        
        # Age-specific warnings
        if age:
            age_val = float(age)
            if age_val < 1:
                warnings.append("Neonate/infant - specialized pediatric care essential")
            elif age_val < 18:
                warnings.append("Pediatric patient - consider growth and development")
        
        confidence = self._calculate_confidence(findings, warnings, age)
        
        return AgentAnalysis(
            agent_id=self.agent_id,
            agent_name=self.name,
            findings=findings,
            recommendations=recommendations,
            confidence_score=confidence,
            warnings=warnings if warnings else None,
            suggested_tests=None,
            follow_up=None
        )
    
    def _calculate_confidence(self, findings: List[str], warnings: List[str], age: Optional[str]) -> float:
        """Calculate confidence score"""
        base_confidence = 80.0
        
        # Increase with findings
        base_confidence += min(len(findings) * 2, 10)
        
        # Decrease with warnings
        if warnings:
            base_confidence -= len(warnings) * 2
        
        # Age-specific adjustments
        if age:
            age_val = float(age)
            if age_val < 5:
                base_confidence -= 5  # Less confidence in very young children
        
        return max(70.0, min(base_confidence, 92.0))
