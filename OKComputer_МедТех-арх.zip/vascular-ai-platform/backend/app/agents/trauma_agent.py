"""
Vascular Trauma AI Agent
Specialized in acute vascular trauma and emergency management
"""

import re
from typing import Dict, List, Optional

from app.agents.llm_agent import LLMEnhancedAgent
from app.schemas.ai_agents import AgentAnalysis, AgentCapability


class VascularTraumaAgent(LLMEnhancedAgent):
    """Vascular Trauma AI Agent for emergency situations"""
    
    def __init__(self):
        super().__init__()
        self.agent_id = "vascular_trauma"
        self.name = "Vascular Trauma Specialist"
        self.description = "AI specialist in acute vascular trauma and emergency vascular surgery"
        self.specialty = "vascular_trauma"
        
    def get_capabilities(self) -> List[AgentCapability]:
        """Get agent capabilities"""
        return [
            AgentCapability(
                name="Hard Signs Assessment",
                description="Identify hard signs of vascular injury requiring immediate intervention",
                parameters=["signs_present", "mechanism", "location"]
            ),
            AgentCapability(
                name="Damage Control",
                description="Damage control vascular surgery techniques",
                parameters=["injury_pattern", "hemodynamic_status", "resources"]
            ),
            AgentCapability(
                name="Shunt Placement",
                description="Temporary vascular shunt management",
                parameters=["vessel_injured", "diameter", "location"]
            ),
            AgentCapability(
                name="Compartment Syndrome",
                description="Recognize and manage compartment syndrome",
                parameters=["compartment", "pressure", "symptoms"]
            ),
            AgentCapability(
                name="Zone Approach",
                description="Anatomical zone-based trauma approach",
                parameters=["zone", "mechanism", "exposure_needed"]
            )
        ]
    
    def _get_system_prompt(self) -> str:
        """Get LLM system prompt for trauma specialist"""
        return """You are an expert Vascular Trauma Specialist AI assistant with extensive knowledge of:
- Acute vascular trauma recognition and management
- Hard and soft signs of vascular injury
- Damage control vascular surgery
- Temporary vascular shunts
- Compartment syndrome diagnosis and management
- Anatomical zone-based approaches (neck, chest, abdomen, extremities)
- Endovascular trauma management
- Massive transfusion protocols

Provide rapid, evidence-based recommendations for vascular trauma.
Emphasize life-threatening conditions requiring immediate intervention.
Time is critical - prioritize actions that save lives and limbs."""
    
    def _rule_based_analysis(self, query: str, patient_context: Optional[Dict] = None) -> AgentAnalysis:
        """Rule-based analysis for trauma queries"""
        query_lower = query.lower()
        findings = []
        recommendations = []
        warnings = []
        
        # Hard Signs of Vascular Injury
        hard_signs = ["pulsatile bleeding", "expanding hematoma", "absent pulses", "ischemia", "bruit", "thrill"]
        present_hard_signs = [sign for sign in hard_signs if sign in query_lower]
        
        if present_hard_signs:
            findings.append(f"HARD SIGNS present: {', '.join(present_hard_signs)}")
            warnings.append("HARD SIGNS = Immediate operative intervention required")
            recommendations.extend([
                "IMMEDIATE operative exploration",
                "Activate massive transfusion protocol",
                "Prepare for damage control surgery",
                "Notify vascular surgery team immediately",
                "Do NOT delay for imaging"
            ])
        
        # Soft Signs
        soft_signs = ["history of bleeding", "hypotension", "neurologic deficit", "proximity injury", "fracture"]
        present_soft_signs = [sign for sign in soft_signs if sign in query_lower]
        
        if present_soft_signs and not present_hard_signs:
            findings.append(f"Soft signs present: {', '.join(present_soft_signs)}")
            recommendations.extend([
                "Obtain CTA for further evaluation",
                "Monitor pulses every 15 minutes",
                "Check ankle-brachial index (ABI)",
                "ABI <0.9 requires further imaging",
                "Low threshold for operative exploration"
            ])
        
        # Zone-specific injuries
        if any(term in query_lower for term in ["neck zone", "zone i", "zone ii", "zone iii"]):
            findings.append("Neck zone vascular injury")
            
            if "zone ii" in query_lower:
                recommendations.extend([
                    "Zone II: Direct surgical exposure",
                    "Anterior sternocleidomastoid approach",
                    "Control proximal and distal before exploration",
                    "Prepare for difficult airway management"
                ])
            elif "zone i" in query_lower:
                warnings.append("Zone I: Difficult exposure, may require sternotomy")
                recommendations.extend([
                    "Zone I: Consider endovascular approach",
                    "May require sternotomy or thoracotomy",
                    "CTA essential for planning",
                    "Vascular and cardiac surgery backup"
                ])
        
        # Extremity Trauma
        if any(term in query_lower for term in ["leg", "arm", "femoral", "popliteal", "brachial", "extremity"]):
            findings.append("Extremity vascular injury")
            
            if "popliteal" in query_lower:
                warnings.append("Popliteal artery injury - high amputation risk")
                recommendations.extend([
                    "Popliteal artery: medial approach",
                    "Above-knee to below-knee bypass if needed",
                    "Fasciotomy strongly recommended",
                    "4-compartment leg fasciotomy if ischemia >4-6 hours"
                ])
        
        # Compartment Syndrome
        if any(term in query_lower for term in ["compartment", "compartment syndrome", "fasciotomy", "pressure"]):
            findings.append("Compartment syndrome concern")
            warnings.append("Compartment syndrome = surgical emergency")
            
            recommendations.extend([
                "Measure compartment pressures",
                "Delta pressure <30 mmHg = fasciotomy indicated",
                "Clinical diagnosis overrules pressure readings",
                "4-compartment fasciotomy for leg",
                "Delayed closure or skin grafting"
            ])
        
        # Damage Control
        if any(term in query_lower for term in ["damage control", "unstable", "hypotensive", "shock"]):
            findings.append("Damage control situation")
            warnings.append("Patient unstable - damage control principles apply")
            
            recommendations.extend([
                "Temporary vascular shunt placement",
                "Ligation for non-essential vessels",
                "Pack and plan for second look",
                "Transfer to ICU for rewarming and resuscitation",
                "Definitive repair within 24-48 hours"
            ])
        
        # Iatrogenic Injuries
        if any(term in query_lower for term in ["iatrogenic", "catheter", "line", "complication", "access"]):
            findings.append("Iatrogenic vascular injury")
            recommendations.extend([
                "Apply direct pressure",
                "Ultrasound to assess pseudoaneurysm",
                "Consider ultrasound-guided compression or thrombin",
                "Surgical repair if failed conservative management",
                "Document and report complication"
            ])
        
        # Default trauma response
        if not findings:
            findings.append("Vascular trauma evaluation request")
            recommendations.extend([
                "Assess for hard signs of vascular injury",
                "Check pulses and perfusion",
                "Measure ABI if extremity involved",
                "CTA if stable with soft signs",
                "Immediate exploration if hard signs present"
            ])
        
        # Always add urgency warning for trauma
        warnings.append("Vascular trauma = time-critical emergency")
        
        confidence = self._calculate_confidence(findings, warnings, present_hard_signs)
        
        return AgentAnalysis(
            agent_id=self.agent_id,
            agent_name=self.name,
            findings=findings,
            recommendations=recommendations,
            confidence_score=confidence,
            warnings=warnings if warnings else None,
            suggested_tests=None,
            follow_up=None
        )
    
    def _calculate_confidence(self, findings: List[str], warnings: List[str], hard_signs: List[str]) -> float:
        """Calculate confidence score"""
        base_confidence = 88.0
        
        # Increase with clear findings
        base_confidence += min(len(findings) * 2, 8)
        
        # Hard signs increase confidence in emergency
        if hard_signs:
            base_confidence += 5
        
        # Decrease slightly with many warnings (complex cases)
        if warnings:
            base_confidence -= min(len(warnings), 5)
        
        return max(80.0, min(base_confidence, 95.0))
