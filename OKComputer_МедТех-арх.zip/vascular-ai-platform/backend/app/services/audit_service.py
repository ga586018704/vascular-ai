"""
Audit Service for HIPAA-compliant logging
"""
import json
import hashlib
from datetime import datetime
from typing import Optional, Dict, Any
from fastapi import Request
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, and_, desc
from app.models.audit import AuditLog, DataAccessLog


class AuditService:
    """Service for managing audit logs"""
    
    @staticmethod
    async def log_action(
        db: AsyncSession,
        action: str,
        resource_type: str,
        user_id: Optional[int] = None,
        username: Optional[str] = None,
        resource_id: Optional[str] = None,
        request: Optional[Request] = None,
        details: Optional[Dict[str, Any]] = None,
        success: bool = True,
        error_message: Optional[str] = None,
        session_id: Optional[str] = None
    ) -> AuditLog:
        """Log a system action"""
        
        ip_address = None
        user_agent = None
        
        if request:
            # Get client IP (handle proxies)
            forwarded = request.headers.get("X-Forwarded-For")
            if forwarded:
                ip_address = forwarded.split(",")[0].strip()
            else:
                ip_address = request.client.host if request.client else None
            
            user_agent = request.headers.get("User-Agent")
        
        audit_entry = AuditLog(
            timestamp=datetime.utcnow(),
            user_id=user_id,
            username=username,
            action=action,
            resource_type=resource_type,
            resource_id=str(resource_id) if resource_id else None,
            ip_address=ip_address,
            user_agent=user_agent,
            details=json.dumps(details) if details else None,
            success=1 if success else 0,
            error_message=error_message,
            session_id=session_id
        )
        
        db.add(audit_entry)
        await db.commit()
        await db.refresh(audit_entry)
        
        return audit_entry
    
    @staticmethod
    async def log_phi_access(
        db: AsyncSession,
        user_id: int,
        username: str,
        patient_id: str,
        patient_name: Optional[str],
        access_type: str,
        data_types: list,
        request: Optional[Request] = None,
        justification: Optional[str] = None,
        emergency_access: bool = False,
        session_id: Optional[str] = None
    ) -> DataAccessLog:
        """Log access to Protected Health Information"""
        
        ip_address = None
        if request:
            forwarded = request.headers.get("X-Forwarded-For")
            ip_address = forwarded.split(",")[0].strip() if forwarded else (
                request.client.host if request.client else None
            )
        
        # Hash patient name for privacy
        hashed_name = None
        if patient_name:
            hashed_name = hashlib.sha256(patient_name.encode()).hexdigest()[:32]
        
        access_log = DataAccessLog(
            timestamp=datetime.utcnow(),
            user_id=user_id,
            username=username,
            patient_id=patient_id,
            patient_name=hashed_name,
            access_type=access_type,
            data_types=json.dumps(data_types),
            justification=justification,
            emergency_access=1 if emergency_access else 0,
            ip_address=ip_address,
            session_id=session_id
        )
        
        db.add(access_log)
        await db.commit()
        await db.refresh(access_log)
        
        return access_log
    
    @staticmethod
    async def get_user_activity(
        db: AsyncSession,
        user_id: int,
        start_date: Optional[datetime] = None,
        end_date: Optional[datetime] = None,
        limit: int = 100
    ) -> list:
        """Get activity log for a specific user"""
        
        query = select(AuditLog).where(AuditLog.user_id == user_id)
        
        if start_date:
            query = query.where(AuditLog.timestamp >= start_date)
        if end_date:
            query = query.where(AuditLog.timestamp <= end_date)
        
        query = query.order_by(desc(AuditLog.timestamp)).limit(limit)
        
        result = await db.execute(query)
        return result.scalars().all()
    
    @staticmethod
    async def get_resource_access_history(
        db: AsyncSession,
        resource_type: str,
        resource_id: str,
        limit: int = 100
    ) -> list:
        """Get access history for a specific resource"""
        
        query = select(AuditLog).where(
            and_(
                AuditLog.resource_type == resource_type,
                AuditLog.resource_id == resource_id
            )
        ).order_by(desc(AuditLog.timestamp)).limit(limit)
        
        result = await db.execute(query)
        return result.scalars().all()
    
    @staticmethod
    async def get_failed_logins(
        db: AsyncSession,
        start_date: Optional[datetime] = None,
        ip_address: Optional[str] = None,
        limit: int = 100
    ) -> list:
        """Get failed login attempts for security monitoring"""
        
        query = select(AuditLog).where(
            and_(
                AuditLog.action == "LOGIN",
                AuditLog.success == 0
            )
        )
        
        if start_date:
            query = query.where(AuditLog.timestamp >= start_date)
        if ip_address:
            query = query.where(AuditLog.ip_address == ip_address)
        
        query = query.order_by(desc(AuditLog.timestamp)).limit(limit)
        
        result = await db.execute(query)
        return result.scalars().all()
    
    @staticmethod
    async def get_patient_access_history(
        db: AsyncSession,
        patient_id: str,
        limit: int = 100
    ) -> list:
        """Get all access records for a specific patient (HIPAA requirement)"""
        
        query = select(DataAccessLog).where(
            DataAccessLog.patient_id == patient_id
        ).order_by(desc(DataAccessLog.timestamp)).limit(limit)
        
        result = await db.execute(query)
        return result.scalars().all()
    
    @staticmethod
    async def get_audit_summary(
        db: AsyncSession,
        start_date: datetime,
        end_date: datetime
    ) -> Dict[str, Any]:
        """Get summary statistics for audit period"""
        
        from sqlalchemy import func
        
        # Total actions
        total_query = select(func.count(AuditLog.id)).where(
            and_(
                AuditLog.timestamp >= start_date,
                AuditLog.timestamp <= end_date
            )
        )
        total_result = await db.execute(total_query)
        total_actions = total_result.scalar()
        
        # Actions by type
        action_query = select(
            AuditLog.action,
            func.count(AuditLog.id)
        ).where(
            and_(
                AuditLog.timestamp >= start_date,
                AuditLog.timestamp <= end_date
            )
        ).group_by(AuditLog.action)
        action_result = await db.execute(action_query)
        actions_by_type = dict(action_result.all())
        
        # Failed actions
        failed_query = select(func.count(AuditLog.id)).where(
            and_(
                AuditLog.timestamp >= start_date,
                AuditLog.timestamp <= end_date,
                AuditLog.success == 0
            )
        )
        failed_result = await db.execute(failed_query)
        failed_count = failed_result.scalar()
        
        # PHI access count
        phi_query = select(func.count(DataAccessLog.id)).where(
            and_(
                DataAccessLog.timestamp >= start_date,
                DataAccessLog.timestamp <= end_date
            )
        )
        phi_result = await db.execute(phi_query)
        phi_access_count = phi_result.scalar()
        
        return {
            "period_start": start_date.isoformat(),
            "period_end": end_date.isoformat(),
            "total_actions": total_actions,
            "actions_by_type": actions_by_type,
            "failed_actions": failed_count,
            "phi_access_count": phi_access_count
        }
