"""
Vascular Surgery Treatment Recommendation Service
Provides evidence-based treatment recommendations in surgeon's language
"""
from typing import List, Dict, Optional, Any
from dataclasses import dataclass, field
from enum import Enum
import logging

from app.core.dicom_processor import (
    PathologyType, AneurysmType, VesselType,
    PathologyFinding, AneurysmFinding, StenosisFinding,
    CTAngiographyStudy
)

logger = logging.getLogger(__name__)


class TreatmentPriority(Enum):
    """Treatment urgency classification"""
    EMERGENCY = "emergency"  # < 24 hours
    URGENT = "urgent"        # < 72 hours  
    ELECTIVE = "elective"    # Planned
    SURVEILLANCE = "surveillance"  # Monitor


class TreatmentApproach(Enum):
    """Treatment approach classification"""
    OPEN_SURGERY = "open_surgery"
    ENDOVASCULAR = "endovascular"
    HYBRID = "hybrid"
    CONSERVATIVE = "conservative"
    MEDICAL = "medical_therapy"


@dataclass
class SurgicalRisk:
    """Surgical risk assessment"""
    cardiac_risk: str  # low, intermediate, high
    pulmonary_risk: str
    renal_risk: str
    bleeding_risk: str
    overall_risk: str
    
    # Risk scores
    revised_cardiac_risk_index: int = 0
    pos_possum_score: Optional[float] = None
    

@dataclass
class TreatmentOption:
    """Individual treatment option"""
    approach: TreatmentApproach
    procedure_name: str
    description: str
    indications: List[str]
    contraindications: List[str]
    advantages: List[str]
    disadvantages: List[str]
    
    # Technical details
    anesthesia: str
    approach_description: str
    expected_duration_minutes: int
    hospital_stay_days: int
    
    # Outcomes
    technical_success_rate: float  # percentage
    primary_patency_1yr: Optional[float] = None
    primary_patency_5yr: Optional[float] = None
    mortality_30day: float = 0.0
    major_complication_rate: float = 0.0
    
    # Contraindications specific
    anatomical_contraindications: List[str] = field(default_factory=list)
    medical_contraindications: List[str] = field(default_factory=list)


@dataclass
class TreatmentRecommendation:
    """Complete treatment recommendation"""
    pathology: PathologyFinding
    priority: TreatmentPriority
    
    # Options
    recommended_approach: TreatmentApproach
    alternative_approaches: List[TreatmentApproach]
    
    # Detailed options
    primary_option: TreatmentOption
    alternative_options: List[TreatmentOption]
    
    # Surgeon's language
    clinical_summary: str
    anatomical_description: str
    pathophysiology: str
    
    # Decision support
    decision_rationale: str
    evidence_level: str  # A, B, C
    guideline_reference: str
    
    # Preoperative workup
    required_tests: List[str]
    optional_tests: List[str]
    consultations: List[str]
    
    # Risk assessment
    surgical_risks: SurgicalRisk
    procedure_specific_risks: List[str]
    risk_mitigation: List[str]
    
    # Postoperative care
    surveillance_protocol: str
    follow_up_schedule: List[str]
    

class TreatmentGuidelineDB:
    """Evidence-based treatment guidelines database"""
    
    def __init__(self):
        self.guidelines = self._load_guidelines()
    
    def _load_guidelines(self) -> Dict:
        """Load treatment guidelines"""
        return {
            PathologyType.ANEURYSM: {
                "guidelines": ["SVS 2018 AAA Guidelines", "ESVS 2019 Aortic Guidelines"],
                "evidence": {
                    "open_repair": {"mortality": 3.0, "success": 98.0},
                    "evar": {"mortality": 1.5, "success": 95.0},
                }
            },
            PathologyType.STENOSIS: {
                "guidelines": ["SVS 2023 PAD Guidelines", "TASC II Classification"],
                "evidence": {
                    "bypass": {"patency_5yr": 70.0, "mortality": 2.0},
                    "angioplasty": {"patency_5yr": 40.0, "mortality": 0.5},
                    "stent": {"patency_5yr": 60.0, "mortality": 0.5},
                }
            },
        }
    
    def get_guideline(self, pathology: PathologyType) -> Dict:
        """Get guideline for pathology"""
        return self.guidelines.get(pathology, {})


class TreatmentRecommender:
    """
    Vascular surgery treatment recommender
    Generates recommendations in surgeon's language
    """
    
    def __init__(self):
        self.guideline_db = TreatmentGuidelineDB()
    
    def recommend_treatment(self, pathology: PathologyFinding, 
                           patient_factors: Dict[str, Any]) -> TreatmentRecommendation:
        """
        Generate treatment recommendation for pathology
        
        Args:
            pathology: Detected pathology
            patient_factors: Patient-specific factors (age, comorbidities, etc.)
            
        Returns:
            Complete treatment recommendation
        """
        if isinstance(pathology, AneurysmFinding):
            return self._recommend_aneurysm_treatment(pathology, patient_factors)
        elif isinstance(pathology, StenosisFinding):
            return self._recommend_stenosis_treatment(pathology, patient_factors)
        else:
            return self._recommend_generic_treatment(pathology, patient_factors)
    
    def _recommend_aneurysm_treatment(self, aneurysm: AneurysmFinding,
                                      patient_factors: Dict) -> TreatmentRecommendation:
        """Generate aneurysm treatment recommendation"""
        
        # Determine priority
        if aneurysm.sac_diameter_mm and aneurysm.sac_diameter_mm >= 70:
            priority = TreatmentPriority.URGENT
        elif aneurysm.rupture_risk == "high":
            priority = TreatmentPriority.URGENT
        elif aneurysm.sac_diameter_mm and aneurysm.sac_diameter_mm >= 55:
            priority = TreatmentPriority.ELECTIVE
        else:
            priority = TreatmentPriority.SURVEILLANCE
        
        # Determine approach based on anatomy and patient factors
        age = patient_factors.get("age", 65)
        asa = patient_factors.get("asa_class", 2)
        
        # Primary option
        if aneurysm.vessel_type == VesselType.AORTA_ABDOMINALIS:
            primary_option = self._get_aaa_evar_option(aneurysm)
            alternative = self._get_aaa_open_option(aneurysm)
        elif aneurysm.vessel_type in [VesselType.A_CAROTIS_COMMUNIS, VesselType.A_CAROTIS_INTERNA]:
            primary_option = self._get_carotid_aneurysm_option(aneurysm)
            alternative = self._get_carotid_open_option(aneurysm)
        else:
            primary_option = self._get_generic_evar_option(aneurysm)
            alternative = self._get_generic_open_option(aneurysm)
        
        # Build clinical summary
        clinical_summary = self._build_aneurysm_summary(aneurysm)
        
        # Anatomical description
        anatomical_description = self._describe_aneurysm_anatomy(aneurysm)
        
        # Risk assessment
        surgical_risks = self._assess_surgical_risk(patient_factors)
        
        return TreatmentRecommendation(
            pathology=aneurysm,
            priority=priority,
            recommended_approach=TreatmentApproach.ENDOVASCULAR,
            alternative_approaches=[TreatmentApproach.OPEN_SURGERY],
            primary_option=primary_option,
            alternative_options=[alternative],
            clinical_summary=clinical_summary,
            anatomical_description=anatomical_description,
            pathophysiology=self._get_aneurysm_pathophysiology(aneurysm),
            decision_rationale=self._get_aneurysm_rationale(aneurysm, patient_factors),
            evidence_level="A",
            guideline_reference="SVS 2018 AAA Guidelines, ESVS 2019 Aortic Guidelines",
            required_tests=self._get_aneurysm_workup(),
            optional_tests=["Cardiac stress test", "Pulmonary function tests"],
            consultations=["Vascular surgery", "Anesthesiology"],
            surgical_risks=surgical_risks,
            procedure_specific_risks=self._get_aneurysm_risks(aneurysm),
            risk_mitigation=self._get_risk_mitigation(patient_factors),
            surveillance_protocol=self._get_aneurysm_surveillance(aneurysm),
            follow_up_schedule=["CTA at 1 month", "CTA at 6 months", "Annual CTA"],
        )
    
    def _recommend_stenosis_treatment(self, stenosis: StenosisFinding,
                                      patient_factors: Dict) -> TreatmentRecommendation:
        """Generate stenosis treatment recommendation"""
        
        degree = stenosis.degree_percent or 0
        
        # Determine priority
        if degree >= 80:
            priority = TreatmentPriority.ELECTIVE
        elif degree >= 70:
            priority = TreatmentPriority.ELECTIVE
        else:
            priority = TreatmentPriority.SURVEILLANCE
        
        # Determine approach based on TASC and location
        tasc = stenosis.tasc_classification
        
        if stenosis.vessel_type in [VesselType.A_CAROTIS_COMMUNIS, VesselType.A_CAROTIS_INTERNA]:
            primary_option = self._get_carotid_stent_option(stenosis)
            alternative = self._get_carotid_endarterectomy_option(stenosis)
        elif stenosis.vessel_type in [VesselType.A_ILIACA_COMMUNIS, VesselType.A_ILIACA_EXTERNA]:
            if tasc in ["A", "B"]:
                primary_option = self._get_iliac_angioplasty_option(stenosis)
                alternative = self._get_iliac_stent_option(stenosis)
            else:
                primary_option = self._get_iliac_bypass_option(stenosis)
                alternative = self._get_iliac_endovascular_option(stenosis)
        elif stenosis.vessel_type in [VesselType.A_FEMORALIS, VesselType.A_POPLITEA]:
            if tasc in ["A", "B"]:
                primary_option = self._get_femoral_angioplasty_option(stenosis)
                alternative = self._get_femoral_bypass_option(stenosis)
            else:
                primary_option = self._get_femoral_bypass_option(stenosis)
                alternative = self._get_femoral_endovascular_option(stenosis)
        else:
            primary_option = self._get_generic_angioplasty_option(stenosis)
            alternative = self._get_generic_bypass_option(stenosis)
        
        return TreatmentRecommendation(
            pathology=stenosis,
            priority=priority,
            recommended_approach=TreatmentApproach.ENDOVASCULAR if tasc in ["A", "B"] else TreatmentApproach.OPEN_SURGERY,
            alternative_approaches=[TreatmentApproach.OPEN_SURGERY, TreatmentApproach.HYBRID],
            primary_option=primary_option,
            alternative_options=[alternative],
            clinical_summary=self._build_stenosis_summary(stenosis),
            anatomical_description=self._describe_stenosis_anatomy(stenosis),
            pathophysiology=self._get_stenosis_pathophysiology(stenosis),
            decision_rationale=self._get_stenosis_rationale(stenosis, patient_factors),
            evidence_level="A",
            guideline_reference="SVS 2023 PAD Guidelines, TASC II Classification",
            required_tests=self._get_stenosis_workup(stenosis),
            optional_tests=["ABI measurement", "Treadmill test"],
            consultations=["Vascular surgery"],
            surgical_risks=self._assess_surgical_risk(patient_factors),
            procedure_specific_risks=self._get_stenosis_risks(stenosis),
            risk_mitigation=self._get_risk_mitigation(patient_factors),
            surveillance_protocol=self._get_stenosis_surveillance(stenosis),
            follow_up_schedule=["Duplex at 1 month", "Duplex at 6 months", "Annual duplex"],
        )
    
    def _get_aaa_evar_option(self, aneurysm: AneurysmFinding) -> TreatmentOption:
        """Get EVAR option for AAA"""
        return TreatmentOption(
            approach=TreatmentApproach.ENDOVASCULAR,
            procedure_name="EVAR (Endovascular Aortic Repair)",
            description="Endovascular repair of abdominal aortic aneurysm using modular stent-graft system",
            indications=[
                "Infrarenal AAA ≥ 55mm",
                "Aneurysm growth > 5mm/6 months",
                "Symptomatic aneurysm",
                "Suitable anatomy (adequate landing zones)"
            ],
            contraindications=[
                "Inadequate proximal neck (<10mm)",
                "Severe neck angulation (>60°)",
                "Iliac access <7mm",
                "Severe circumferential thrombus in landing zone"
            ],
            advantages=[
                "Minimally invasive",
                "Lower 30-day mortality (1.5% vs 3.0%)",
                "Shorter hospital stay (2-3 days)",
                "Faster recovery"
            ],
            disadvantages=[
                "Requires lifelong surveillance",
                "Endoleak risk (10-20%)",
                "Reintervention rate 15-20% at 5 years",
                "Radiation exposure"
            ],
            anesthesia="General or regional (per institutional preference)",
            approach_description="Bilateral femoral cutdown or percutaneous access. Aortic stent-graft deployed under fluoroscopic guidance.",
            expected_duration_minutes=120,
            hospital_stay_days=2,
            technical_success_rate=95.0,
            primary_patency_5yr=85.0,
            mortality_30day=1.5,
            major_complication_rate=8.0,
        )
    
    def _get_aaa_open_option(self, aneurysm: AneurysmFinding) -> TreatmentOption:
        """Get open repair option for AAA"""
        return TreatmentOption(
            approach=TreatmentApproach.OPEN_SURGERY,
            procedure_name="Open AAA Repair",
            description="Transperitoneal or retroperitoneal approach with prosthetic graft interposition",
            indications=[
                "Infrarenal AAA ≥ 55mm",
                "Unsuitable anatomy for EVAR",
                "Infected/mycotic aneurysm",
                "Young patient with long life expectancy"
            ],
            contraindications=[
                "High surgical risk (ASA IV-V)",
                "Severe cardiopulmonary disease",
                "Limited life expectancy <2 years"
            ],
            advantages=[
                "Durable repair",
                "No endoleak risk",
                "Lower reintervention rate",
                "Cost-effective long-term"
            ],
            disadvantages=[
                "Higher 30-day mortality (3.0%)",
                "Longer hospital stay (7-10 days)",
                "Slower recovery (6-8 weeks)",
                "More physiologic stress"
            ],
            anesthesia="General endotracheal",
            approach_description="Midline laparotomy or left retroperitoneal approach. Aortic cross-clamping with tube or bifurcated graft interposition.",
            expected_duration_minutes=180,
            hospital_stay_days=7,
            technical_success_rate=98.0,
            primary_patency_5yr=95.0,
            mortality_30day=3.0,
            major_complication_rate=15.0,
        )
    
    def _get_carotid_endarterectomy_option(self, stenosis: StenosisFinding) -> TreatmentOption:
        """Get carotid endarterectomy option"""
        return TreatmentOption(
            approach=TreatmentApproach.OPEN_SURGERY,
            procedure_name="Carotid Endarterectomy (CEA)",
            description="Open removal of atherosclerotic plaque from carotid bifurcation",
            indications=[
                "Symptomatic carotid stenosis >50%",
                "Asymptomatic carotid stenosis >70%",
                "Recent TIA/stroke with ipsilateral stenosis"
            ],
            contraindications=[
                "High cervical lesion (above C2)",
                "Previous neck radiation",
                "Contralateral recurrent laryngeal nerve palsy",
                "Tracheostomy"
            ],
            advantages=[
                "Gold standard with proven stroke prevention",
                "Durable result",
                "No stent-related complications"
            ],
            disadvantages=[
                "Cranial nerve injury risk (5-10%)",
                "Neck incision",
                "Longer recovery than stenting"
            ],
            anesthesia="General or regional",
            approach_description="Longitudinal incision along anterior border of sternocleidomastoid. Plaque removal with patch angioplasty.",
            expected_duration_minutes=90,
            hospital_stay_days=1,
            technical_success_rate=98.0,
            mortality_30day=0.5,
            major_complication_rate=3.0,
        )
    
    def _build_aneurysm_summary(self, aneurysm: AneurysmFinding) -> str:
        """Build clinical summary for aneurysm"""
        diameter = aneurysm.sac_diameter_mm or 0
        
        summary = f"""
КЛИНИЧЕСКАЯ КАРТИНА:
Обнаружена {aneurysm.aneurysm_type.value} аневризма {aneurysm.vessel_type.value} 
с максимальным диаметром {diameter:.1f} мм.

АНАТОМИЧЕСКИЕ ОСОБЕННОСТИ:
{self._describe_aneurysm_anatomy(aneurysm)}

РИСК РАЗРЫВА:
{aneurysm.rupture_risk.upper()} риск разрыва на основании размера и локализации.

ПОКАЗАНИЯ К ЛЕЧЕНИЮ:
{"Срочное хирургическое вмешательство показано при диаметре ≥55 мм" if diameter >= 55 else "Наблюдение показано при диаметре <55 мм"}
"""
        return summary.strip()
    
    def _describe_aneurysm_anatomy(self, aneurysm: AneurysmFinding) -> str:
        """Describe aneurysm anatomy in surgical terms"""
        descriptions = {
            VesselType.AORTA_ABDOMINALIS: "Инфраренальная абдоминальная аорта",
            VesselType.AORTA_ASCENDENS: "Восходящая аорта",
            VesselType.AORTA_ARCH: "Дуга аорты",
            VesselType.A_CAROTIS_COMMUNIS: "Общая сонная артерия",
            VesselType.A_CAROTIS_INTERNA: "Внутренняя сонная артерия",
            VesselType.A_ILIACA_COMMUNIS: "Общая подвздошная артерия",
        }
        
        location = descriptions.get(aneurysm.vessel_type, aneurysm.vessel_type.value)
        
        return f"""
Локализация: {location}
Тип: {aneurysm.aneurysm_type.value}
Максимальный диаметр мешка: {aneurysm.sac_diameter_mm or 'N/A'} мм
Диаметр шейки: {aneurysm.neck_diameter_mm or 'N/A'} мм
Длина мешка: {aneurysm.sac_length_mm or 'N/A'} мм
Угол шейки: {aneurysm.neck_angle_degrees or 'N/A'}°
        """.strip()
    
    def _get_aneurysm_pathophysiology(self, aneurysm: AneurysmFinding) -> str:
        """Get pathophysiology description"""
        return """
ПАТОФИЗИОЛОГИЯ:
Аневризма представляет собой локализованное расширение сосуда >50% от нормального диаметра.
Основные механизмы:
- Дегенерация эластических волокон медии
- Воспалительная реакция стенки
- Гемодинамическое напряжение (закон Лапласа: напряжение = давление × радиус)
- Матричная металлопротеиназная активность

Риск разрыва экспоненциально возрастает с увеличением диаметра.
Критический диаметр для АБА: 55-60 мм (5-10% риск разрыва/год)
        """.strip()
    
    def _get_aneurysm_rationale(self, aneurysm: AneurysmFinding, patient_factors: Dict) -> str:
        """Get treatment decision rationale"""
        diameter = aneurysm.sac_diameter_mm or 0
        age = patient_factors.get("age", 65)
        
        rationale = f"""
ОБОСНОВАНИЕ РЕШЕНИЯ:

1. РАЗМЕРНЫЙ КРИТЕРИЙ:
   - Диаметр аневризмы: {diameter:.1f} мм
   - Порог для вмешательства: 55 мм (SVS Guidelines)
   - {"Достигнут размерный критерий для репарации" if diameter >= 55 else "Наблюдение до достижения 55 мм"}

2. РИСК РАЗРЫВА:
   - Оценка риска: {aneurysm.rupture_risk.upper()}
   - Скорость роста: учитывать при наблюдении

3. ПАЦИЕНТСКИЕ ФАКТОРЫ:
   - Возраст: {age} лет
   - Ожидаемая продолжительность жизни: {'>10 лет' if age < 75 else '<10 лет'}
   - Предпочтительный подход: {'EVAR' if age > 70 else 'Индивидуальный выбор'}

4. АНАТОМИЧЕСКАЯ ПРИГОДНОСТЬ:
   - Требуется оценка проксимальной шейки и подвздошных артерий
   - Для EVAR: необходима адекватная зона фиксации ≥10 мм
        """
        return rationale.strip()
    
    def _get_aneurysm_workup(self) -> List[str]:
        """Get required preoperative workup for aneurysm"""
        return [
            "CTA aorta with runoff (0.625mm slices)",
            "Complete blood count",
            "Coagulation profile (PT/INR, aPTT)",
            "Serum creatinine and eGFR",
            "Blood type and crossmatch",
            "ECG",
            "Echocardiogram",
        ]
    
    def _get_aneurysm_risks(self, aneurysm: AneurysmFinding) -> List[str]:
        """Get procedure-specific risks"""
        return [
            "Endoleak (Type I: 2%, Type II: 10%, Type III: 2%)",
            "Graft migration (<5% at 5 years)",
            "Limb occlusion (2-5%)",
            "Access site complications (hematoma, pseudoaneurysm)",
            "Contrast-induced nephropathy",
            "Spinal cord ischemia (<1% for infrarenal)",
        ]
    
    def _get_aneurysm_surveillance(self, aneurysm: AneurysmFinding) -> str:
        """Get surveillance protocol"""
        return """
ПРОТОКОЛ НАБЛЮДЕНИЯ ПОСЛЕ EVAR:

1 месяц: CTA (оценка положения протеза, эндолик)
6 месяцев: CTA
12 месяцев: CTA
Ежегодно: CTA (или duplex + plain abdominal X-ray)

ПРИЗНАКИ, ТРЕБУЮЩИЕ ВНИМАНИЯ:
- Увеличение размера мешка >5 мм
- Новый эндолик
- Миграция протеза >5 мм
- Нарушение целостности компонентов
        """.strip()
    
    def _build_stenosis_summary(self, stenosis: StenosisFinding) -> str:
        """Build clinical summary for stenosis"""
        degree = stenosis.degree_percent or 0
        
        return f"""
КЛИНИЧЕСКАЯ КАРТИНА:
Обнаружен стеноз {stenosis.vessel_type.value} степени {degree:.0f}%.

ГЕМОДИНАМИЧЕСКАЯ ЗНАЧИМОСТЬ:
{'Критический стеноз (>80%) - высокий риск ишемии' if degree >= 80 else 
 'Гемодинамически значимый стеноз (70-80%)' if degree >= 70 else 
 'Умеренный стеноз (50-70%) - клиническое наблюдение'}

КЛАССИФИКАЦИЯ TASC:
{stenosis.tasc_classification or 'N/A'} (для периферических артерий)
        """.strip()
    
    def _describe_stenosis_anatomy(self, stenosis: StenosisFinding) -> str:
        """Describe stenosis anatomy"""
        return f"""
Локализация: {stenosis.vessel_type.value}
Степень стеноза: {stenosis.degree_percent or 'N/A'}%
Референсный диаметр: {stenosis.reference_diameter_mm or 'N/A'} мм
Минимальный просвет: {stenosis.minimal_lumen_diameter_mm or 'N/A'} мм
Длина поражения: {stenosis.lesion_length_mm or 'N/A'} мм
Эксцентричность: {stenosis.eccentricity}
Поверхность: {stenosis.surface_irregularity}
        """.strip()
    
    def _get_stenosis_pathophysiology(self, stenosis: StenosisFinding) -> str:
        """Get stenosis pathophysiology"""
        return """
ПАТОФИЗИОЛОГИЯ:
Атеросклеротический стеноз приводит к прогрессирующему сужению просвета сосуда.
Критические пороги:
- >50% стеноз - начало гемодинамического значения
- >70% стеноз - значимый градиент давления
- >80% стеноз - критический, высокий риск окклюзии

Процесс атерогенеза:
1. Эндотелиальная дисфункция
2. Накопление липидов
3. Воспалительная реакция
4. Формирование фиброзной капсулы
5. Кальцификация
        """.strip()
    
    def _get_stenosis_rationale(self, stenosis: StenosisFinding, patient_factors: Dict) -> str:
        """Get stenosis treatment rationale"""
        degree = stenosis.degree_percent or 0
        
        return f"""
ОБОСНОВАНИЕ РЕШЕНИЯ:

1. СТЕПЕНЬ СТЕНОЗА:
   - Стеноз: {degree:.0f}%
   - Порог для реваскуляризации: 70% (симптоматический), 80% (асимптоматический)
   - {"Показана реваскуляризация" if degree >= 70 else "Наблюдение и оптимизация терапии"}

2. КЛАССИФИКАЦИЯ TASC II:
   - Класс: {stenosis.tasc_classification or 'N/A'}
   - TASC A-B: предпочтительно эндоваскулярное лечение
   - TASC C-D: предпочтительно открытое хирургическое лечение

3. ПАЦИЕНТСКИЕ ФАКТОРЫ:
   - Сопутствующая патология влияет на выбор подхода
   - Оценка риска открытой хирургии vs эндоваскулярного вмешательства
        """.strip()
    
    def _get_stenosis_workup(self, stenosis: StenosisFinding) -> List[str]:
        """Get stenosis workup"""
        return [
            "Duplex ultrasound",
            "CTA or MRA",
            "ABI measurement",
            "Treadmill test (if claudication)",
            "Complete blood count",
            "Coagulation profile",
        ]
    
    def _get_stenosis_risks(self, stenosis: StenosisFinding) -> List[str]:
        """Get stenosis procedure risks"""
        return [
            "Distal embolization (2-5%)",
            "Acute thrombosis (<2%)",
            "Restenosis (20-40% at 1 year for angioplasty)",
            "Vessel perforation (<1%)",
            "Access site complications",
        ]
    
    def _get_stenosis_surveillance(self, stenosis: StenosisFinding) -> str:
        """Get stenosis surveillance"""
        return """
ПРОТОКОЛ НАБЛЮДЕНИЯ:

После ангиопластики/стентирования:
1 месяц: Duplex ultrasound
6 месяцев: Duplex ultrasound
12 месяцев: Duplex ultrasound
Ежегодно: Duplex ultrasound

После шунтирования:
3 месяца: Duplex (оценка патентности)
6 месяцев: Duplex
12 месяцев: Duplex
Ежегодно: Duplex

Целевые показатели:
- PSV <300 cm/s
- ABI >0.9
- Отсутствие рецидива симптомов
        """.strip()
    
    def _assess_surgical_risk(self, patient_factors: Dict) -> SurgicalRisk:
        """Assess surgical risk"""
        age = patient_factors.get("age", 65)
        asa = patient_factors.get("asa_class", 2)
        
        # Simplified risk assessment
        if asa >= 4 or age > 80:
            overall = "high"
        elif asa == 3 or age > 70:
            overall = "intermediate"
        else:
            overall = "low"
        
        return SurgicalRisk(
            cardiac_risk="intermediate" if asa >= 3 else "low",
            pulmonary_risk="intermediate" if asa >= 3 else "low",
            renal_risk="low",
            bleeding_risk="low",
            overall_risk=overall,
            revised_cardiac_risk_index=asa,
        )
    
    def _get_risk_mitigation(self, patient_factors: Dict) -> List[str]:
        """Get risk mitigation strategies"""
        return [
            "Preoperative cardiac optimization",
            "Adequate hydration (contrast protection)",
            "Antibiotic prophylaxis",
            "DVT prophylaxis",
            "Blood products availability",
        ]


def generate_treatment_plan(study: CTAngiographyStudy, 
                            patient_factors: Dict[str, Any]) -> Dict[str, Any]:
    """
    Generate complete treatment plan from CT angiography study
    
    This is the main entry point for treatment planning
    """
    recommender = TreatmentRecommender()
    
    recommendations = []
    
    for vessel in study.vessels:
        for pathology in vessel.pathologies:
            recommendation = recommender.recommend_treatment(pathology, patient_factors)
            recommendations.append(recommendation)
    
    # Sort by priority
    priority_order = {
        TreatmentPriority.EMERGENCY: 0,
        TreatmentPriority.URGENT: 1,
        TreatmentPriority.ELECTIVE: 2,
        TreatmentPriority.SURVEILLANCE: 3,
    }
    recommendations.sort(key=lambda x: priority_order[x.priority])
    
    return {
        "study_id": study.study_id,
        "patient_id": study.patient_id,
        "analysis_date": study.acquisition_date,
        "total_findings": len(recommendations),
        "critical_findings": study.critical_findings,
        "recommendations": recommendations,
        "summary": _generate_plan_summary(recommendations),
    }


def _generate_plan_summary(recommendations: List[TreatmentRecommendation]) -> str:
    """Generate human-readable summary of treatment plan"""
    if not recommendations:
        return "Патологий не обнаружено. Продолжать наблюдение."
    
    lines = ["ПЛАН ЛЕЧЕНИЯ:", ""]
    
    for i, rec in enumerate(recommendations, 1):
        lines.append(f"{i}. {rec.pathology.vessel_type.value}")
        lines.append(f"   Патология: {rec.pathology.pathology_type.value}")
        lines.append(f"   Приоритет: {rec.priority.value}")
        lines.append(f"   Рекомендуемый подход: {rec.recommended_approach.value}")
        lines.append(f"   Процедура: {rec.primary_option.procedure_name}")
        lines.append("")
    
    return "\n".join(lines)
