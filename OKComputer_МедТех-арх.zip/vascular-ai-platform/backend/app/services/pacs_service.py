"""
PACS (Picture Archiving and Communication System) Integration Service
Supports DICOM C-FIND, C-MOVE, C-GET, WADO-RS protocols
"""
import asyncio
import logging
from typing import List, Dict, Optional, Tuple, BinaryIO
from dataclasses import dataclass
from datetime import datetime
import io

from pydicom import Dataset
from pynetdicom import AE, debug_logger
from pynetdicom.sop_class import (
    PatientRootQueryRetrieveInformationModelFind,
    PatientRootQueryRetrieveInformationModelMove,
    PatientRootQueryRetrieveInformationModelGet,
    StudyRootQueryRetrieveInformationModelFind,
    StudyRootQueryRetrieveInformationModelMove,
    StudyRootQueryRetrieveInformationModelGet,
    Verification,
)
import aiohttp
import aiofiles

logger = logging.getLogger(__name__)


@dataclass
class PACSConfig:
    """PACS server configuration"""
    host: str
    port: int = 11112
    ae_title: str = "VASCULAR_AI"
    called_ae_title: str = "PACS"
    timeout: int = 30
    
    # WADO-RS configuration
    wado_url: Optional[str] = None
    wado_auth_token: Optional[str] = None


@dataclass
class DICOMQuery:
    """DICOM query parameters"""
    patient_id: Optional[str] = None
    patient_name: Optional[str] = None
    study_date_from: Optional[str] = None
    study_date_to: Optional[str] = None
    study_instance_uid: Optional[str] = None
    accession_number: Optional[str] = None
    modality: Optional[str] = None
    study_description: Optional[str] = None


class PACSService:
    """
    PACS integration service supporting multiple protocols:
    - DICOM DIMSE (C-FIND, C-MOVE, C-GET)
    - DICOMweb (WADO-RS, QIDO-RS, STOW-RS)
    """
    
    def __init__(self, config: PACSConfig):
        self.config = config
        self.ae = AE(ae_title=config.ae_title)
        self._setup_contexts()
        self.assoc = None
    
    def _setup_contexts(self):
        """Setup DICOM presentation contexts"""
        # Verification
        self.ae.add_requested_context(Verification)
        
        # Patient Root Query/Retrieve
        self.ae.add_requested_context(PatientRootQueryRetrieveInformationModelFind)
        self.ae.add_requested_context(PatientRootQueryRetrieveInformationModelMove)
        self.ae.add_requested_context(PatientRootQueryRetrieveInformationModelGet)
        
        # Study Root Query/Retrieve
        self.ae.add_requested_context(StudyRootQueryRetrieveInformationModelFind)
        self.ae.add_requested_context(StudyRootQueryRetrieveInformationModelMove)
        self.ae.add_requested_context(StudyRootQueryRetrieveInformationModelGet)
        
        # Storage contexts for common SOP classes
        storage_sops = [
            "1.2.840.10008.5.1.4.1.1.2",   # CT Image
            "1.2.840.10008.5.1.4.1.1.2.1", # Enhanced CT Image
            "1.2.840.10008.5.1.4.1.1.4",   # MR Image
            "1.2.840.10008.5.1.4.1.1.4.1", # Enhanced MR Image
            "1.2.840.10008.5.1.4.1.1.128", # PET Image
            "1.2.840.10008.5.1.4.1.1.481.2", # RT Dose
            "1.2.840.10008.5.1.4.1.1.88.67", # X-Ray Radiation Dose SR
        ]
        
        for sop in storage_sops:
            self.ae.add_requested_context(sop)
    
    async def _connect(self) -> bool:
        """Establish association with PACS server"""
        try:
            self.assoc = self.ae.associate(
                self.config.host,
                self.config.port,
                ae_title=self.config.called_ae_title,
                timeout=self.config.timeout
            )
            
            if self.assoc.is_established:
                logger.info(f"Connected to PACS: {self.config.host}:{self.config.port}")
                return True
            else:
                logger.error(f"Failed to connect to PACS: {self.assoc.acceptor.primitive}")
                return False
                
        except Exception as e:
            logger.error(f"PACS connection error: {e}")
            return False
    
    def _disconnect(self):
        """Close association"""
        if self.assoc and self.assoc.is_established:
            self.assoc.release()
            logger.info("Disconnected from PACS")
    
    # === C-FIND OPERATIONS ===
    
    async def find_patients(self, query: DICOMQuery) -> List[Dict]:
        """Search for patients using C-FIND"""
        if not await self._connect():
            return []
        
        try:
            # Create query dataset
            ds = Dataset()
            ds.QueryRetrieveLevel = "PATIENT"
            ds.PatientID = query.patient_id or ""
            ds.PatientName = query.patient_name or ""
            ds.PatientBirthDate = ""
            ds.PatientSex = ""
            ds.NumberOfPatientRelatedStudies = ""
            
            # Send C-FIND request
            responses = self.assoc.send_c_find(
                ds,
                PatientRootQueryRetrieveInformationModelFind
            )
            
            patients = []
            for (status, identifier) in responses:
                if status.Status == 0xFF00:  # Pending
                    patients.append({
                        "patient_id": getattr(identifier, "PatientID", ""),
                        "patient_name": str(getattr(identifier, "PatientName", "")),
                        "birth_date": getattr(identifier, "PatientBirthDate", ""),
                        "sex": getattr(identifier, "PatientSex", ""),
                        "study_count": getattr(identifier, "NumberOfPatientRelatedStudies", 0)
                    })
            
            return patients
            
        finally:
            self._disconnect()
    
    async def find_studies(self, query: DICOMQuery) -> List[Dict]:
        """Search for studies using C-FIND"""
        if not await self._connect():
            return []
        
        try:
            ds = Dataset()
            ds.QueryRetrieveLevel = "STUDY"
            ds.PatientID = query.patient_id or ""
            ds.StudyInstanceUID = query.study_instance_uid or ""
            ds.AccessionNumber = query.accession_number or ""
            ds.StudyDate = self._format_study_date_range(
                query.study_date_from,
                query.study_date_to
            )
            ds.StudyTime = ""
            ds.ModalitiesInStudy = query.modality or ""
            ds.StudyDescription = query.study_description or ""
            ds.NumberOfStudyRelatedSeries = ""
            ds.NumberOfStudyRelatedInstances = ""
            ds.PatientName = ""
            ds.PatientBirthDate = ""
            ds.PatientSex = ""
            
            responses = self.assoc.send_c_find(
                ds,
                StudyRootQueryRetrieveInformationModelFind
            )
            
            studies = []
            for (status, identifier) in responses:
                if status.Status == 0xFF00:
                    studies.append({
                        "study_instance_uid": getattr(identifier, "StudyInstanceUID", ""),
                        "patient_id": getattr(identifier, "PatientID", ""),
                        "patient_name": str(getattr(identifier, "PatientName", "")),
                        "accession_number": getattr(identifier, "AccessionNumber", ""),
                        "study_date": getattr(identifier, "StudyDate", ""),
                        "study_time": getattr(identifier, "StudyTime", ""),
                        "modalities": getattr(identifier, "ModalitiesInStudy", ""),
                        "study_description": getattr(identifier, "StudyDescription", ""),
                        "series_count": getattr(identifier, "NumberOfStudyRelatedSeries", 0),
                        "instance_count": getattr(identifier, "NumberOfStudyRelatedInstances", 0)
                    })
            
            return studies
            
        finally:
            self._disconnect()
    
    async def find_series(self, study_uid: str) -> List[Dict]:
        """Find all series in a study"""
        if not await self._connect():
            return []
        
        try:
            ds = Dataset()
            ds.QueryRetrieveLevel = "SERIES"
            ds.StudyInstanceUID = study_uid
            ds.SeriesInstanceUID = ""
            ds.Modality = ""
            ds.SeriesNumber = ""
            ds.SeriesDescription = ""
            ds.NumberOfSeriesRelatedInstances = ""
            ds.BodyPartExamined = ""
            ds.ProtocolName = ""
            
            responses = self.assoc.send_c_find(
                ds,
                StudyRootQueryRetrieveInformationModelFind
            )
            
            series_list = []
            for (status, identifier) in responses:
                if status.Status == 0xFF00:
                    series_list.append({
                        "series_instance_uid": getattr(identifier, "SeriesInstanceUID", ""),
                        "study_instance_uid": getattr(identifier, "StudyInstanceUID", ""),
                        "modality": getattr(identifier, "Modality", ""),
                        "series_number": getattr(identifier, "SeriesNumber", ""),
                        "series_description": getattr(identifier, "SeriesDescription", ""),
                        "instance_count": getattr(identifier, "NumberOfSeriesRelatedInstances", 0),
                        "body_part": getattr(identifier, "BodyPartExamined", ""),
                        "protocol": getattr(identifier, "ProtocolName", "")
                    })
            
            return series_list
            
        finally:
            self._disconnect()
    
    async def find_instances(self, series_uid: str) -> List[Dict]:
        """Find all instances in a series"""
        if not await self._connect():
            return []
        
        try:
            ds = Dataset()
            ds.QueryRetrieveLevel = "IMAGE"
            ds.SeriesInstanceUID = series_uid
            ds.SOPClassUID = ""
            ds.SOPInstanceUID = ""
            ds.InstanceNumber = ""
            ds.Rows = ""
            ds.Columns = ""
            ds.SliceThickness = ""
            ds.SliceLocation = ""
            
            responses = self.assoc.send_c_find(
                ds,
                StudyRootQueryRetrieveInformationModelFind
            )
            
            instances = []
            for (status, identifier) in responses:
                if status.Status == 0xFF00:
                    instances.append({
                        "sop_instance_uid": getattr(identifier, "SOPInstanceUID", ""),
                        "sop_class_uid": getattr(identifier, "SOPClassUID", ""),
                        "series_instance_uid": getattr(identifier, "SeriesInstanceUID", ""),
                        "instance_number": getattr(identifier, "InstanceNumber", ""),
                        "rows": getattr(identifier, "Rows", ""),
                        "columns": getattr(identifier, "Columns", ""),
                        "slice_thickness": getattr(identifier, "SliceThickness", ""),
                        "slice_location": getattr(identifier, "SliceLocation", "")
                    })
            
            return instances
            
        finally:
            self._disconnect()
    
    # === C-MOVE OPERATIONS ===
    
    async def move_study(self, study_uid: str, destination_ae: str) -> Dict:
        """Move entire study to destination AE using C-MOVE"""
        if not await self._connect():
            return {"success": False, "error": "Connection failed"}
        
        try:
            ds = Dataset()
            ds.QueryRetrieveLevel = "STUDY"
            ds.StudyInstanceUID = study_uid
            
            responses = self.assoc.send_c_move(
                ds,
                destination_ae,
                StudyRootQueryRetrieveInformationModelMove
            )
            
            result = {"success": True, "completed": 0, "failed": 0, "warning": 0}
            
            for (status, identifier) in responses:
                if status.Status in [0xFF00]:  # Pending
                    pass
                elif status.Status == 0x0000:  # Success
                    result["completed"] = getattr(status, "NumberOfCompletedSuboperations", 0)
                    result["failed"] = getattr(status, "NumberOfFailedSuboperations", 0)
                    result["warning"] = getattr(status, "NumberOfWarningSuboperations", 0)
                else:
                    result["success"] = False
                    result["error"] = f"C-MOVE failed with status: {hex(status.Status)}"
            
            return result
            
        finally:
            self._disconnect()
    
    async def move_series(self, series_uid: str, destination_ae: str) -> Dict:
        """Move series to destination AE"""
        if not await self._connect():
            return {"success": False, "error": "Connection failed"}
        
        try:
            ds = Dataset()
            ds.QueryRetrieveLevel = "SERIES"
            ds.SeriesInstanceUID = series_uid
            
            responses = self.assoc.send_c_move(
                ds,
                destination_ae,
                StudyRootQueryRetrieveInformationModelMove
            )
            
            result = {"success": True, "completed": 0, "failed": 0, "warning": 0}
            
            for (status, identifier) in responses:
                if status.Status == 0x0000:
                    result["completed"] = getattr(status, "NumberOfCompletedSuboperations", 0)
                    result["failed"] = getattr(status, "NumberOfFailedSuboperations", 0)
                    result["warning"] = getattr(status, "NumberOfWarningSuboperations", 0)
            
            return result
            
        finally:
            self._disconnect()
    
    # === C-GET OPERATIONS ===
    
    async def get_study(self, study_uid: str) -> List[Dataset]:
        """Retrieve entire study using C-GET"""
        if not await self._connect():
            return []
        
        instances = []
        
        try:
            ds = Dataset()
            ds.QueryRetrieveLevel = "STUDY"
            ds.StudyInstanceUID = study_uid
            
            responses = self.assoc.send_c_get(
                ds,
                StudyRootQueryRetrieveInformationModelGet
            )
            
            for (status, identifier) in responses:
                if status.Status == 0xFF00:  # Pending
                    if identifier:
                        instances.append(identifier)
            
            return instances
            
        finally:
            self._disconnect()
    
    async def get_instance(self, study_uid: str, series_uid: str, 
                          instance_uid: str) -> Optional[Dataset]:
        """Retrieve specific instance using C-GET"""
        if not await self._connect():
            return None
        
        try:
            ds = Dataset()
            ds.QueryRetrieveLevel = "IMAGE"
            ds.StudyInstanceUID = study_uid
            ds.SeriesInstanceUID = series_uid
            ds.SOPInstanceUID = instance_uid
            
            responses = self.assoc.send_c_get(
                ds,
                StudyRootQueryRetrieveInformationModelGet
            )
            
            for (status, identifier) in responses:
                if status.Status == 0xFF00 and identifier:
                    return identifier
            
            return None
            
        finally:
            self._disconnect()
    
    # === WADO-RS OPERATIONS ===
    
    async def wado_retrieve_study(self, study_uid: str, 
                                   output_dir: str) -> List[str]:
        """Retrieve study using WADO-RS"""
        if not self.config.wado_url:
            raise ValueError("WADO URL not configured")
        
        headers = {}
        if self.config.wado_auth_token:
            headers["Authorization"] = f"Bearer {self.config.wado_auth_token}"
        
        url = f"{self.config.wado_url}/studies/{study_uid}"
        
        async with aiohttp.ClientSession() as session:
            async with session.get(url, headers=headers) as response:
                if response.status == 200:
                    content_type = response.headers.get("Content-Type", "")
                    
                    if "multipart/related" in content_type:
                        # Parse multipart response
                        return await self._parse_multipart_response(
                            response, output_dir
                        )
                    else:
                        # Single DICOM instance
                        data = await response.read()
                        filepath = f"{output_dir}/{study_uid}.dcm"
                        async with aiofiles.open(filepath, "wb") as f:
                            await f.write(data)
                        return [filepath]
                else:
                    raise Exception(f"WADO retrieve failed: {response.status}")
    
    async def wado_retrieve_instance(self, study_uid: str, series_uid: str,
                                     instance_uid: str) -> bytes:
        """Retrieve specific instance using WADO-RS"""
        if not self.config.wado_url:
            raise ValueError("WADO URL not configured")
        
        headers = {}
        if self.config.wado_auth_token:
            headers["Authorization"] = f"Bearer {self.config.wado_auth_token}"
        
        url = (f"{self.config.wado_url}/studies/{study_uid}/series/"
               f"{series_uid}/instances/{instance_uid}")
        
        async with aiohttp.ClientSession() as session:
            async with session.get(url, headers=headers) as response:
                if response.status == 200:
                    return await response.read()
                else:
                    raise Exception(f"WADO retrieve failed: {response.status}")
    
    async def wado_retrieve_frame(self, study_uid: str, series_uid: str,
                                  instance_uid: str, frame_numbers: List[int],
                                  render_params: Optional[Dict] = None) -> bytes:
        """Retrieve rendered frame using WADO-RS URI"""
        if not self.config.wado_url:
            raise ValueError("WADO URL not configured")
        
        frames_str = ",".join(map(str, frame_numbers))
        url = (f"{self.config.wado_url}/studies/{study_uid}/series/"
               f"{series_uid}/instances/{instance_uid}/frames/{frames_str}/render")
        
        params = {}
        if render_params:
            params.update(render_params)
        
        headers = {"Accept": "image/jpeg,image/png"}
        if self.config.wado_auth_token:
            headers["Authorization"] = f"Bearer {self.config.wado_auth_token}"
        
        async with aiohttp.ClientSession() as session:
            async with session.get(url, headers=headers, params=params) as response:
                if response.status == 200:
                    return await response.read()
                else:
                    raise Exception(f"WADO frame retrieve failed: {response.status}")
    
    async def _parse_multipart_response(self, response, output_dir: str) -> List[str]:
        """Parse multipart/related DICOM response"""
        # Simplified multipart parsing
        # In production, use proper multipart parser
        saved_files = []
        
        content = await response.read()
        boundary = response.headers.get("Content-Type", "").split("boundary=")[-1].strip('"')
        
        parts = content.split(f"--{boundary}".encode())
        
        for i, part in enumerate(parts[1:-1]):  # Skip first and last
            if b"Content-Type" in part:
                # Extract DICOM data
                header_end = part.find(b"\r\n\r\n")
                if header_end > 0:
                    dicom_data = part[header_end + 4:]
                    filepath = f"{output_dir}/instance_{i}.dcm"
                    async with aiofiles.open(filepath, "wb") as f:
                        await f.write(dicom_data)
                    saved_files.append(filepath)
        
        return saved_files
    
    # === QIDO-RS OPERATIONS ===
    
    async def qido_search_studies(self, query_params: Dict) -> List[Dict]:
        """Search studies using QIDO-RS"""
        if not self.config.wado_url:
            raise ValueError("WADO URL not configured")
        
        url = f"{self.config.wado_url}/studies"
        
        headers = {"Accept": "application/dicom+json"}
        if self.config.wado_auth_token:
            headers["Authorization"] = f"Bearer {self.config.wado_auth_token}"
        
        async with aiohttp.ClientSession() as session:
            async with session.get(url, headers=headers, params=query_params) as response:
                if response.status == 200:
                    return await response.json()
                else:
                    raise Exception(f"QIDO search failed: {response.status}")
    
    # === UTILITY METHODS ===
    
    def _format_study_date_range(self, date_from: Optional[str], 
                                  date_to: Optional[str]) -> str:
        """Format study date range for DICOM query"""
        if date_from and date_to:
            return f"{date_from}-{date_to}"
        elif date_from:
            return f"{date_from}-"
        elif date_to:
            return f"-{date_to}"
        return ""
    
    async def verify_connection(self) -> bool:
        """Verify PACS connection using C-ECHO"""
        if not await self._connect():
            return False
        
        try:
            status = self.assoc.send_c_echo()
            return status.Status == 0x0000
        finally:
            self._disconnect()
    
    async def get_study_thumbnail(self, study_uid: str) -> Optional[bytes]:
        """Get study thumbnail (first instance preview)"""
        # Find first series
        series_list = await self.find_series(study_uid)
        if not series_list:
            return None
        
        first_series = series_list[0]
        
        # Find first instance
        instances = await self.find_instances(first_series["series_instance_uid"])
        if not instances:
            return None
        
        first_instance = instances[0]
        
        # Retrieve using WADO if available
        if self.config.wado_url:
            try:
                return await self.wado_retrieve_frame(
                    study_uid,
                    first_series["series_instance_uid"],
                    first_instance["sop_instance_uid"],
                    [1],
                    {"quality": 50, "width": 256}
                )
            except:
                pass
        
        return None


# DICOM Storage SCP (Service Class Provider)
class DICOMStorageSCP:
    """
    DICOM Storage SCP for receiving DICOM instances from PACS
    """
    
    def __init__(self, host: str = "0.0.0.0", port: int = 11112, 
                 ae_title: str = "VASCULAR_AI"):
        self.host = host
        self.port = port
        self.ae_title = ae_title
        self.ae = AE(ae_title=ae_title)
        self._setup_contexts()
        self.handlers = []
    
    def _setup_contexts(self):
        """Setup storage presentation contexts"""
        storage_sops = [
            "1.2.840.10008.5.1.4.1.1.2",   # CT Image
            "1.2.840.10008.5.1.4.1.1.2.1", # Enhanced CT Image
            "1.2.840.10008.5.1.4.1.1.4",   # MR Image
            "1.2.840.10008.5.1.4.1.1.4.1", # Enhanced MR Image
            "1.2.840.10008.5.1.4.1.1.128", # PET Image
            "1.2.840.10008.5.1.4.1.1.88.67", # X-Ray Radiation Dose SR
        ]
        
        for sop in storage_sops:
            self.ae.add_supported_context(sop)
    
    def on_store(self, ds: Dataset, context, info) -> int:
        """Handle incoming C-STORE request"""
        logger.info(f"Received DICOM instance: {ds.SOPInstanceUID}")
        
        # Process the received dataset
        for handler in self.handlers:
            handler(ds)
        
        return 0x0000  # Success
    
    def add_handler(self, handler):
        """Add handler for received DICOM instances"""
        self.handlers.append(handler)
    
    def start(self):
        """Start the storage SCP"""
        self.ae.start_server((self.host, self.port), block=False)
        logger.info(f"DICOM Storage SCP started on {self.host}:{self.port}")
    
    def stop(self):
        """Stop the storage SCP"""
        self.ae.shutdown()
        logger.info("DICOM Storage SCP stopped")


# Convenience functions
async def query_pacs_studies(config: PACSConfig, patient_id: str) -> List[Dict]:
    """Convenience function to query studies for a patient"""
    service = PACSService(config)
    query = DICOMQuery(patient_id=patient_id)
    return await service.find_studies(query)


async def retrieve_study_to_disk(config: PACSConfig, study_uid: str, 
                                  output_dir: str) -> List[str]:
    """Convenience function to retrieve study to disk"""
    service = PACSService(config)
    
    if config.wado_url:
        return await service.wado_retrieve_study(study_uid, output_dir)
    else:
        instances = await service.get_study(study_uid)
        saved_files = []
        
        for i, instance in enumerate(instances):
            filepath = f"{output_dir}/instance_{i}.dcm"
            instance.save_as(filepath)
            saved_files.append(filepath)
        
        return saved_files
