"""
AI-Powered Vessel Segmentation Service
Integrates with deep learning models for medical image analysis
"""
import numpy as np
import logging
from typing import Dict, List, Tuple, Optional, Any
from dataclasses import dataclass
from enum import Enum
import json
import os

logger = logging.getLogger(__name__)

# Try to import ML libraries
try:
    import onnxruntime as ort
    ONNX_AVAILABLE = True
except ImportError:
    ONNX_AVAILABLE = False
    logger.warning("ONNX Runtime not available. Using fallback segmentation.")

try:
    import torch
    import torch.nn as nn
    TORCH_AVAILABLE = True
except ImportError:
    TORCH_AVAILABLE = False
    logger.warning("PyTorch not available.")


class ModelType(Enum):
    """Available AI models for vessel segmentation"""
    UNET_3D = "unet3d"
    VNET = "vnet"
    NNUNET = "nnunet"
    DEEPVESSEL = "deepvessel"
    FRANGI_NET = "frangi_net"


@dataclass
class SegmentationConfig:
    """Configuration for AI segmentation"""
    model_type: ModelType = ModelType.UNET_3D
    model_path: Optional[str] = None
    input_size: Tuple[int, int, int] = (128, 128, 128)
    voxel_spacing: Tuple[float, float, float] = (1.0, 1.0, 1.0)
    hu_range: Tuple[int, int] = (-1000, 1000)
    use_gpu: bool = True
    batch_size: int = 1


@dataclass
class SegmentationResult:
    """Result of AI segmentation"""
    vessel_mask: np.ndarray
    vessel_type: str
    confidence: float
    centerline: np.ndarray
    diameter_mm: float
    volume_ml: float
    morphology: Dict[str, Any]


class AISegmentationEngine:
    """
    AI-powered vessel segmentation engine
    Supports multiple deep learning models for medical image analysis
    """
    
    def __init__(self, config: SegmentationConfig = None):
        self.config = config or SegmentationConfig()
        self.session = None
        self.model_loaded = False
        self._load_model()
    
    def _load_model(self):
        """Load the AI model"""
        if not ONNX_AVAILABLE and not TORCH_AVAILABLE:
            logger.warning("No ML framework available. Using rule-based fallback.")
            return
        
        model_path = self.config.model_path or self._get_default_model_path()
        
        if not model_path or not os.path.exists(model_path):
            logger.warning(f"Model not found at {model_path}. Using fallback segmentation.")
            return
        
        try:
            if ONNX_AVAILABLE and model_path.endswith('.onnx'):
                providers = ['CUDAExecutionProvider', 'CPUExecutionProvider'] if self.config.use_gpu else ['CPUExecutionProvider']
                self.session = ort.InferenceSession(model_path, providers=providers)
                self.model_loaded = True
                logger.info(f"Loaded ONNX model: {model_path}")
            elif TORCH_AVAILABLE and model_path.endswith('.pth'):
                self.model = torch.load(model_path, map_location='cpu')
                self.model.eval()
                self.model_loaded = True
                logger.info(f"Loaded PyTorch model: {model_path}")
        except Exception as e:
            logger.error(f"Failed to load model: {e}")
    
    def _get_default_model_path(self) -> str:
        """Get default model path based on model type"""
        base_path = os.path.join(os.path.dirname(__file__), '..', '..', 'models')
        model_files = {
            ModelType.UNET_3D: 'unet3d_vessel_seg.onnx',
            ModelType.VNET: 'vnet_vessel_seg.onnx',
            ModelType.NNUNET: 'nnunet_vessel_seg.onnx',
            ModelType.DEEPVESSEL: 'deepvessel.onnx',
            ModelType.FRANGI_NET: 'frangi_net.onnx',
        }
        return os.path.join(base_path, model_files.get(self.config.model_type, 'unet3d_vessel_seg.onnx'))
    
    def segment_vessel(
        self,
        volume: np.ndarray,
        vessel_type: str,
        roi_bbox: Optional[Tuple[Tuple[int, int], Tuple[int, int], Tuple[int, int]]] = None
    ) -> SegmentationResult:
        """
        Segment a vessel from CT volume using AI
        
        Args:
            volume: 3D CT volume (H, W, D)
            vessel_type: Type of vessel to segment
            roi_bbox: Optional ROI bounding box ((z1,z2), (y1,y2), (x1,x2))
            
        Returns:
            SegmentationResult with mask and measurements
        """
        if not self.model_loaded:
            logger.info("Using fallback segmentation (no AI model loaded)")
            return self._fallback_segmentation(volume, vessel_type, roi_bbox)
        
        try:
            # Preprocess volume
            preprocessed = self._preprocess(volume, roi_bbox)
            
            # Run inference
            if ONNX_AVAILABLE and self.session:
                result = self._onnx_inference(preprocessed)
            elif TORCH_AVAILABLE and hasattr(self, 'model'):
                result = self._torch_inference(preprocessed)
            else:
                return self._fallback_segmentation(volume, vessel_type, roi_bbox)
            
            # Post-process result
            mask = self._postprocess(result, volume.shape)
            
            # Calculate measurements
            measurements = self._calculate_measurements(mask)
            
            return SegmentationResult(
                vessel_mask=mask,
                vessel_type=vessel_type,
                confidence=0.85,  # Model confidence
                centerline=measurements['centerline'],
                diameter_mm=measurements['diameter_mm'],
                volume_ml=measurements['volume_ml'],
                morphology=measurements['morphology'],
            )
            
        except Exception as e:
            logger.error(f"AI segmentation failed: {e}")
            return self._fallback_segmentation(volume, vessel_type, roi_bbox)
    
    def _preprocess(
        self,
        volume: np.ndarray,
        roi_bbox: Optional[Tuple] = None
    ) -> np.ndarray:
        """Preprocess volume for model input"""
        # Extract ROI if specified
        if roi_bbox:
            (z1, z2), (y1, y2), (x1, x2) = roi_bbox
            volume = volume[z1:z2, y1:y2, x1:x2]
        
        # Normalize to model input size
        from scipy.ndimage import zoom
        factors = [
            self.config.input_size[i] / volume.shape[i]
            for i in range(3)
        ]
        resized = zoom(volume, factors, order=1)
        
        # Normalize HU values
        hu_min, hu_max = self.config.hu_range
        normalized = (resized - hu_min) / (hu_max - hu_min)
        normalized = np.clip(normalized, 0, 1)
        
        # Add batch and channel dimensions
        return normalized[np.newaxis, np.newaxis, ...].astype(np.float32)
    
    def _onnx_inference(self, input_tensor: np.ndarray) -> np.ndarray:
        """Run ONNX inference"""
        input_name = self.session.get_inputs()[0].name
        outputs = self.session.run(None, {input_name: input_tensor})
        return outputs[0]
    
    def _torch_inference(self, input_tensor: np.ndarray) -> np.ndarray:
        """Run PyTorch inference"""
        with torch.no_grad():
            tensor = torch.from_numpy(input_tensor)
            if self.config.use_gpu and torch.cuda.is_available():
                tensor = tensor.cuda()
                self.model = self.model.cuda()
            output = self.model(tensor)
            return output.cpu().numpy()
    
    def _postprocess(self, model_output: np.ndarray, original_shape: Tuple) -> np.ndarray:
        """Post-process model output to original shape"""
        # Remove batch and channel dimensions
        mask = model_output[0, 0]
        
        # Apply threshold
        mask = (mask > 0.5).astype(np.uint8)
        
        # Resize to original shape
        from scipy.ndimage import zoom
        factors = [
            original_shape[i] / mask.shape[i]
            for i in range(3)
        ]
        resized_mask = zoom(mask, factors, order=0)
        
        return (resized_mask > 0.5).astype(np.uint8)
    
    def _calculate_measurements(self, mask: np.ndarray) -> Dict:
        """Calculate vessel measurements from mask"""
        from skimage.morphology import skeletonize_3d
        from scipy import ndimage
        
        # Calculate volume
        voxel_volume = np.prod(self.config.voxel_spacing) / 1000  # ml
        volume_ml = np.sum(mask) * voxel_volume
        
        # Extract centerline
        try:
            centerline = skeletonize_3d(mask)
            centerline_coords = np.argwhere(centerline)
        except:
            centerline_coords = np.array([])
        
        # Calculate diameter (assuming cylindrical shape)
        if np.sum(mask) > 0:
            # Estimate from volume and length
            if len(centerline_coords) > 0:
                length_mm = len(centerline_coords) * self.config.voxel_spacing[0]
                avg_area = np.sum(mask) * np.prod(self.config.voxel_spacing[:2]) / length_mm
                diameter_mm = 2 * np.sqrt(avg_area / np.pi)
            else:
                diameter_mm = 0
        else:
            diameter_mm = 0
        
        # Morphology analysis
        labeled, num_features = ndimage.label(mask)
        
        return {
            'centerline': centerline_coords,
            'diameter_mm': diameter_mm,
            'volume_ml': volume_ml,
            'morphology': {
                'num_components': num_features,
                'euler_number': ndimage.sum(mask),
            }
        }
    
    def _fallback_segmentation(
        self,
        volume: np.ndarray,
        vessel_type: str,
        roi_bbox: Optional[Tuple] = None
    ) -> SegmentationResult:
        """Fallback rule-based segmentation when AI model is not available"""
        logger.info(f"Using fallback segmentation for {vessel_type}")
        
        # Use traditional image processing
        from scipy import ndimage
        from skimage import morphology, filters
        
        # Extract ROI
        if roi_bbox:
            (z1, z2), (y1, y2), (x1, x2) = roi_bbox
            roi = volume[z1:z2, y1:y2, x1:x2]
        else:
            roi = volume
        
        # Threshold for vessels (contrast-enhanced CT)
        vessel_threshold = 150  # HU
        binary = roi > vessel_threshold
        
        # Remove small objects
        cleaned = morphology.remove_small_objects(binary, min_size=100)
        
        # Find largest connected component (likely the vessel)
        labeled, num_features = ndimage.label(cleaned)
        if num_features > 0:
            sizes = ndimage.sum(cleaned, labeled, range(1, num_features + 1))
            largest_idx = np.argmax(sizes) + 1
            mask = (labeled == largest_idx).astype(np.uint8)
        else:
            mask = np.zeros_like(roi, dtype=np.uint8)
        
        # Create full-size mask
        if roi_bbox:
            full_mask = np.zeros_like(volume, dtype=np.uint8)
            (z1, z2), (y1, y2), (x1, x2) = roi_bbox
            full_mask[z1:z2, y1:y2, x1:x2] = mask
        else:
            full_mask = mask
        
        # Calculate measurements
        measurements = self._calculate_measurements(full_mask)
        
        return SegmentationResult(
            vessel_mask=full_mask,
            vessel_type=vessel_type,
            confidence=0.60,  # Lower confidence for fallback
            centerline=measurements['centerline'],
            diameter_mm=measurements['diameter_mm'],
            volume_ml=measurements['volume_ml'],
            morphology=measurements['morphology'],
        )


class MultiVesselSegmentor:
    """
    Segment multiple vessel types from a single CT volume
    """
    
    VESSEL_HIERARCHY = {
        'aorta': {
            'priority': 1,
            'hu_range': (200, 400),
            'expected_location': 'center',
        },
        'aorta_ascending': {
            'priority': 2,
            'parent': 'aorta',
            'hu_range': (200, 400),
        },
        'aorta_arch': {
            'priority': 2,
            'parent': 'aorta',
            'hu_range': (200, 400),
        },
        'aorta_descending': {
            'priority': 2,
            'parent': 'aorta',
            'hu_range': (200, 400),
        },
        'aorta_abdominal': {
            'priority': 2,
            'parent': 'aorta',
            'hu_range': (200, 400),
        },
        'iliac_left': {
            'priority': 3,
            'parent': 'aorta_abdominal',
            'side': 'left',
            'hu_range': (150, 350),
        },
        'iliac_right': {
            'priority': 3,
            'parent': 'aorta_abdominal',
            'side': 'right',
            'hu_range': (150, 350),
        },
        'femoral_left': {
            'priority': 4,
            'parent': 'iliac_left',
            'side': 'left',
            'hu_range': (150, 350),
        },
        'femoral_right': {
            'priority': 4,
            'parent': 'iliac_right',
            'side': 'right',
            'hu_range': (150, 350),
        },
        'carotid_left': {
            'priority': 3,
            'side': 'left',
            'hu_range': (150, 350),
        },
        'carotid_right': {
            'priority': 3,
            'side': 'right',
            'hu_range': (150, 350),
        },
        'renal_left': {
            'priority': 3,
            'parent': 'aorta_abdominal',
            'side': 'left',
            'hu_range': (150, 350),
        },
        'renal_right': {
            'priority': 3,
            'parent': 'aorta_abdominal',
            'side': 'right',
            'hu_range': (150, 350),
        },
    }
    
    def __init__(self, config: SegmentationConfig = None):
        self.config = config or SegmentationConfig()
        self.engine = AISegmentationEngine(config)
    
    def segment_all_vessels(
        self,
        volume: np.ndarray,
        spacing: Tuple[float, float, float]
    ) -> Dict[str, SegmentationResult]:
        """
        Segment all major vessels from CT volume
        
        Returns:
            Dictionary mapping vessel names to segmentation results
        """
        results = {}
        
        # Sort vessels by priority
        sorted_vessels = sorted(
            self.VESSEL_HIERARCHY.items(),
            key=lambda x: x[1]['priority']
        )
        
        for vessel_name, vessel_info in sorted_vessels:
            logger.info(f"Segmenting {vessel_name}...")
            
            # Determine ROI based on parent vessel
            roi = self._get_roi(volume, vessel_name, vessel_info, results)
            
            # Segment vessel
            result = self.engine.segment_vessel(
                volume,
                vessel_name,
                roi_bbox=roi
            )
            
            results[vessel_name] = result
        
        return results
    
    def _get_roi(
        self,
        volume: np.ndarray,
        vessel_name: str,
        vessel_info: Dict,
        previous_results: Dict
    ) -> Optional[Tuple]:
        """Determine ROI for vessel segmentation"""
        # If parent vessel is segmented, use its location
        parent = vessel_info.get('parent')
        if parent and parent in previous_results:
            parent_mask = previous_results[parent].vessel_mask
            coords = np.argwhere(parent_mask)
            if len(coords) > 0:
                # Get bounding box of parent
                z_min, y_min, x_min = coords.min(axis=0)
                z_max, y_max, x_max = coords.max(axis=0)
                
                # Expand based on side
                side = vessel_info.get('side')
                if side == 'left':
                    x_min = max(0, x_min - 50)
                    x_max = (x_min + x_max) // 2
                elif side == 'right':
                    x_min = (x_min + x_max) // 2
                    x_max = min(volume.shape[2], x_max + 50)
                
                return ((z_min, z_max), (y_min, y_max), (x_min, x_max))
        
        return None


# Convenience function for API usage
def segment_vessels_ai(
    volume: np.ndarray,
    spacing: Tuple[float, float, float],
    model_type: str = "unet3d"
) -> Dict[str, Any]:
    """
    Convenience function to segment vessels using AI
    
    Args:
        volume: 3D CT volume
        spacing: Voxel spacing (x, y, z) in mm
        model_type: AI model type to use
        
    Returns:
        Dictionary with segmentation results
    """
    config = SegmentationConfig(
        model_type=ModelType(model_type),
        voxel_spacing=spacing,
    )
    
    segmentor = MultiVesselSegmentor(config)
    results = segmentor.segment_all_vessels(volume, spacing)
    
    # Convert to serializable format
    return {
        vessel_name: {
            'mask_shape': result.vessel_mask.shape,
            'vessel_type': result.vessel_type,
            'confidence': result.confidence,
            'diameter_mm': result.diameter_mm,
            'volume_ml': result.volume_ml,
            'morphology': result.morphology,
        }
        for vessel_name, result in results.items()
    }
