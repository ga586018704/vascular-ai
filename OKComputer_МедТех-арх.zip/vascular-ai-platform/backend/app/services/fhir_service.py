"""
FHIR (Fast Healthcare Interoperability Resources) Service
Integration with EHR systems for seamless data exchange
"""
import json
import requests
from typing import Dict, List, Optional, Any
from dataclasses import dataclass
from datetime import datetime
import logging

from app.core.config import settings

logger = logging.getLogger(__name__)


@dataclass
class FHIRConfig:
    """FHIR server configuration"""
    base_url: str
    auth_type: str = "oauth2"  # oauth2, basic, bearer
    client_id: Optional[str] = None
    client_secret: Optional[str] = None
    access_token: Optional[str] = None
    refresh_token: Optional[str] = None
    token_expires: Optional[datetime] = None


class FHIRService:
    """
    FHIR R4 compliant service for EHR integration
    Supports Patient, Observation, DiagnosticReport, ImagingStudy, DocumentReference
    """
    
    FHIR_VERSION = "R4"
    
    def __init__(self, config: FHIRConfig):
        self.config = config
        self.session = requests.Session()
        self._authenticate()
    
    def _authenticate(self):
        """Authenticate with FHIR server"""
        if self.config.auth_type == "oauth2":
            self._oauth2_authenticate()
        elif self.config.auth_type == "bearer":
            self.session.headers.update({
                "Authorization": f"Bearer {self.config.access_token}"
            })
        elif self.config.auth_type == "basic":
            self.session.auth = (self.config.client_id, self.config.client_secret)
    
    def _oauth2_authenticate(self):
        """OAuth2 authentication flow"""
        token_url = f"{self.config.base_url}/oauth2/token"
        
        response = requests.post(
            token_url,
            data={
                "grant_type": "client_credentials",
                "client_id": self.config.client_id,
                "client_secret": self.config.client_secret,
                "scope": "system/*.read system/*.write"
            }
        )
        
        if response.status_code == 200:
            token_data = response.json()
            self.config.access_token = token_data["access_token"]
            self.config.refresh_token = token_data.get("refresh_token")
            expires_in = token_data.get("expires_in", 3600)
            self.config.token_expires = datetime.now().timestamp() + expires_in
            
            self.session.headers.update({
                "Authorization": f"Bearer {self.config.access_token}"
            })
        else:
            raise Exception(f"OAuth2 authentication failed: {response.text}")
    
    def _check_token(self):
        """Check and refresh token if needed"""
        if self.config.token_expires and datetime.now().timestamp() > self.config.token_expires - 300:
            self._authenticate()
    
    def _make_request(self, method: str, endpoint: str, data: Dict = None) -> Dict:
        """Make authenticated request to FHIR server"""
        self._check_token()
        
        url = f"{self.config.base_url}/{endpoint}"
        headers = {
            "Content-Type": "application/fhir+json",
            "Accept": "application/fhir+json"
        }
        
        try:
            if method == "GET":
                response = self.session.get(url, headers=headers)
            elif method == "POST":
                response = self.session.post(url, headers=headers, json=data)
            elif method == "PUT":
                response = self.session.put(url, headers=headers, json=data)
            elif method == "DELETE":
                response = self.session.delete(url, headers=headers)
            else:
                raise ValueError(f"Unsupported method: {method}")
            
            response.raise_for_status()
            return response.json() if response.content else {}
            
        except requests.exceptions.RequestException as e:
            logger.error(f"FHIR request failed: {e}")
            raise
    
    # === PATIENT OPERATIONS ===
    
    def get_patient(self, patient_id: str) -> Dict:
        """Get patient by ID"""
        return self._make_request("GET", f"Patient/{patient_id}")
    
    def search_patients(self, params: Dict[str, str]) -> Dict:
        """Search patients by criteria"""
        query = "&".join([f"{k}={v}" for k, v in params.items()])
        return self._make_request("GET", f"Patient?{query}")
    
    def create_patient(self, patient_data: Dict) -> Dict:
        """Create new patient"""
        fhir_patient = self._convert_to_fhir_patient(patient_data)
        return self._make_request("POST", "Patient", fhir_patient)
    
    def update_patient(self, patient_id: str, patient_data: Dict) -> Dict:
        """Update existing patient"""
        fhir_patient = self._convert_to_fhir_patient(patient_data)
        fhir_patient["id"] = patient_id
        return self._make_request("PUT", f"Patient/{patient_id}", fhir_patient)
    
    def _convert_to_fhir_patient(self, data: Dict) -> Dict:
        """Convert internal patient data to FHIR Patient resource"""
        return {
            "resourceType": "Patient",
            "identifier": [{
                "system": "http://vascular.ai/patients",
                "value": data.get("mrn", "")
            }],
            "name": [{
                "use": "official",
                "family": data.get("last_name", ""),
                "given": [data.get("first_name", "")]
            }],
            "gender": data.get("gender", "unknown"),
            "birthDate": data.get("date_of_birth", ""),
            "telecom": [
                {"system": "phone", "value": data.get("phone", ""), "use": "mobile"},
                {"system": "email", "value": data.get("email", ""), "use": "home"}
            ],
            "address": [{
                "use": "home",
                "line": [data.get("address", "")],
                "city": data.get("city", ""),
                "postalCode": data.get("postal_code", ""),
                "country": data.get("country", "")
            }]
        }
    
    # === OBSERVATION OPERATIONS ===
    
    def create_vital_signs(self, patient_id: str, vitals: Dict) -> Dict:
        """Create vital signs observation"""
        observation = {
            "resourceType": "Observation",
            "status": "final",
            "category": [{
                "coding": [{
                    "system": "http://terminology.hl7.org/CodeSystem/observation-category",
                    "code": "vital-signs",
                    "display": "Vital Signs"
                }]
            }],
            "code": {
                "coding": [{
                    "system": "http://loinc.org",
                    "code": "85354-9",
                    "display": "Blood pressure panel"
                }]
            },
            "subject": {"reference": f"Patient/{patient_id}"},
            "effectiveDateTime": datetime.now().isoformat(),
            "component": []
        }
        
        if "systolic" in vitals:
            observation["component"].append({
                "code": {
                    "coding": [{
                        "system": "http://loinc.org",
                        "code": "8480-6",
                        "display": "Systolic BP"
                    }]
                },
                "valueQuantity": {
                    "value": vitals["systolic"],
                    "unit": "mmHg",
                    "system": "http://unitsofmeasure.org",
                    "code": "mm[Hg]"
                }
            })
        
        if "diastolic" in vitals:
            observation["component"].append({
                "code": {
                    "coding": [{
                        "system": "http://loinc.org",
                        "code": "8462-4",
                        "display": "Diastolic BP"
                    }]
                },
                "valueQuantity": {
                    "value": vitals["diastolic"],
                    "unit": "mmHg",
                    "system": "http://unitsofmeasure.org",
                    "code": "mm[Hg]"
                }
            })
        
        return self._make_request("POST", "Observation", observation)
    
    def create_vascular_measurement(self, patient_id: str, study_id: str, 
                                   measurement: Dict) -> Dict:
        """Create vascular measurement observation"""
        observation = {
            "resourceType": "Observation",
            "status": "final",
            "category": [{
                "coding": [{
                    "system": "http://terminology.hl7.org/CodeSystem/observation-category",
                    "code": "imaging",
                    "display": "Imaging"
                }]
            }],
            "code": {
                "coding": [{
                    "system": "http://vascular.ai/codes",
                    "code": "vessel-diameter",
                    "display": f"{measurement['vessel_name']} diameter"
                }]
            },
            "subject": {"reference": f"Patient/{patient_id}"},
            "focus": [{"reference": f"ImagingStudy/{study_id}"}],
            "effectiveDateTime": datetime.now().isoformat(),
            "valueQuantity": {
                "value": measurement["diameter_mm"],
                "unit": "mm",
                "system": "http://unitsofmeasure.org",
                "code": "mm"
            },
            "bodySite": {
                "coding": [{
                    "system": "http://snomed.info/sct",
                    "code": self._get_snomed_code_for_vessel(measurement["vessel_name"]),
                    "display": measurement["vessel_name"]
                }]
            }
        }
        
        return self._make_request("POST", "Observation", observation)
    
    # === IMAGING STUDY OPERATIONS ===
    
    def create_imaging_study(self, patient_id: str, study_data: Dict) -> Dict:
        """Create imaging study from DICOM metadata"""
        imaging_study = {
            "resourceType": "ImagingStudy",
            "status": "available",
            "subject": {"reference": f"Patient/{patient_id}"},
            "started": study_data.get("study_date", datetime.now().isoformat()),
            "numberOfSeries": study_data.get("series_count", 1),
            "numberOfInstances": study_data.get("instance_count", 1),
            "description": study_data.get("description", "CT Angiography"),
            "series": [{
                "uid": study_data.get("series_uid", ""),
                "number": 1,
                "modality": {
                    "system": "http://dicom.nema.org/resources/ontology/DCM",
                    "code": study_data.get("modality", "CT")
                },
                "description": study_data.get("series_description", ""),
                "numberOfInstances": study_data.get("instance_count", 1),
                "bodySite": {
                    "display": study_data.get("body_part", "")
                },
                "instance": [{
                    "uid": study_data.get("sop_instance_uid", ""),
                    "sopClass": {
                        "system": "urn:ietf:rfc:3986",
                        "code": "urn:oid:1.2.840.10008.5.1.4.1.1.2"
                    },
                    "number": 1
                }]
            }],
            "endpoint": [{
                "reference": f"Endpoint/{study_data.get('endpoint_id', 'wado')}",
                "display": "WADO-RS endpoint"
            }]
        }
        
        return self._make_request("POST", "ImagingStudy", imaging_study)
    
    def get_imaging_study(self, study_id: str) -> Dict:
        """Get imaging study by ID"""
        return self._make_request("GET", f"ImagingStudy/{study_id}")
    
    # === DIAGNOSTIC REPORT OPERATIONS ===
    
    def create_diagnostic_report(self, patient_id: str, study_id: str, 
                                 report_data: Dict) -> Dict:
        """Create diagnostic report with findings"""
        diagnostic_report = {
            "resourceType": "DiagnosticReport",
            "status": "final",
            "category": [{
                "coding": [{
                    "system": "http://terminology.hl7.org/CodeSystem/v2-0074",
                    "code": "RAD",
                    "display": "Radiology"
                }]
            }],
            "code": {
                "coding": [{
                    "system": "http://loinc.org",
                    "code": "18748-4",
                    "display": "Diagnostic imaging study"
                }]
            },
            "subject": {"reference": f"Patient/{patient_id}"},
            "imagingStudy": [{"reference": f"ImagingStudy/{study_id}"}],
            "effectiveDateTime": report_data.get("report_date", datetime.now().isoformat()),
            "issued": datetime.now().isoformat(),
            "performer": [{
                "reference": f"Practitioner/{report_data.get('radiologist_id', '')}",
                "display": report_data.get("radiologist_name", "")
            }],
            "result": [],
            "conclusion": report_data.get("conclusion", ""),
            "conclusionCode": [{
                "coding": [{
                    "system": "http://snomed.info/sct",
                    "code": report_data.get("snomed_code", ""),
                    "display": report_data.get("diagnosis", "")
                }]
            }]
        }
        
        # Add observations for each finding
        for finding in report_data.get("findings", []):
            obs = self._create_finding_observation(patient_id, finding)
            diagnostic_report["result"].append({
                "reference": f"Observation/{obs.get('id', '')}"
            })
        
        return self._make_request("POST", "DiagnosticReport", diagnostic_report)
    
    def _create_finding_observation(self, patient_id: str, finding: Dict) -> Dict:
        """Create observation for a specific finding"""
        return {
            "resourceType": "Observation",
            "status": "final",
            "category": [{
                "coding": [{
                    "system": "http://terminology.hl7.org/CodeSystem/observation-category",
                    "code": "imaging",
                    "display": "Imaging"
                }]
            }],
            "code": {
                "coding": [{
                    "system": "http://vascular.ai/codes",
                    "code": finding.get("pathology_type", "finding"),
                    "display": finding.get("description", "")
                }]
            },
            "subject": {"reference": f"Patient/{patient_id}"},
            "effectiveDateTime": datetime.now().isoformat(),
            "valueString": finding.get("description", ""),
            "note": [{
                "text": finding.get("clinical_significance", "")
            }]
        }
    
    # === DOCUMENT REFERENCE OPERATIONS ===
    
    def create_document_reference(self, patient_id: str, document_data: Dict) -> Dict:
        """Create document reference for PDF report"""
        document_reference = {
            "resourceType": "DocumentReference",
            "status": "current",
            "docStatus": "final",
            "type": {
                "coding": [{
                    "system": "http://loinc.org",
                    "code": "18748-4",
                    "display": "Diagnostic imaging study"
                }]
            },
            "category": [{
                "coding": [{
                    "system": "http://hl7.org/fhir/us/core/CodeSystem/us-core-documentreference-category",
                    "code": "clinical-note",
                    "display": "Clinical Note"
                }]
            }],
            "subject": {"reference": f"Patient/{patient_id}"},
            "date": datetime.now().isoformat(),
            "author": [{
                "reference": f"Practitioner/{document_data.get('author_id', '')}",
                "display": document_data.get("author_name", "")
            }],
            "content": [{
                "attachment": {
                    "contentType": "application/pdf",
                    "url": document_data.get("document_url", ""),
                    "title": document_data.get("title", "Vascular Report"),
                    "creation": datetime.now().isoformat()
                },
                "format": {
                    "system": "urn:ietf:bcp:13",
                    "code": "application/pdf",
                    "display": "PDF"
                }
            }],
            "context": {
                "encounter": [{"reference": f"Encounter/{document_data.get('encounter_id', '')}"}],
                "event": [{
                    "coding": [{
                        "system": "http://snomed.info/sct",
                        "code": document_data.get("procedure_code", ""),
                        "display": document_data.get("procedure_name", "")
                    }]
                }],
                "period": {
                    "start": document_data.get("study_date", ""),
                    "end": document_data.get("study_date", "")
                }
            }
        }
        
        return self._make_request("POST", "DocumentReference", document_reference)
    
    # === BULK OPERATIONS ===
    
    def bulk_export(self, resource_type: str, since: Optional[str] = None) -> Dict:
        """Bulk export of FHIR resources"""
        params = {"_type": resource_type}
        if since:
            params["_since"] = since
        
        query = "&".join([f"{k}={v}" for k, v in params.items()])
        return self._make_request("GET", f"$export?{query}")
    }
    
    def transaction_bundle(self, resources: List[Dict]) -> Dict:
        """Execute transaction bundle"""
        bundle = {
            "resourceType": "Bundle",
            "type": "transaction",
            "entry": []
        }
        
        for resource in resources:
            bundle["entry"].append({
                "resource": resource,
                "request": {
                    "method": "POST" if "id" not in resource else "PUT",
                    "url": resource["resourceType"] + (f"/{resource['id']}" if "id" in resource else "")
                }
            })
        
        return self._make_request("POST", "", bundle)
    
    # === UTILITY METHODS ===
    
    def _get_snomed_code_for_vessel(self, vessel_name: str) -> str:
        """Get SNOMED CT code for vessel name"""
        vessel_codes = {
            "aorta": "15825003",
            "aorta abdominalis": "7832008",
            "aorta ascendens": "54247002",
            "aorta descendens": "32622004",
            "a carotis communis": "32062004",
            "a carotis interna": "36206007",
            "a iliaca communis": "73634005",
            "a femoralis": "7657000",
            "a renalis": "2841007",
            "a mesenterica superior": "22066006",
            "v cava inferior": "64131007",
            "v cava superior": "48345008",
        }
        
        return vessel_codes.get(vessel_name.lower(), "181353007")  # Default: Blood vessel structure
    
    def validate_resource(self, resource: Dict) -> bool:
        """Validate FHIR resource against profile"""
        # Simplified validation - in production use FHIR validator
        required_fields = {
            "Patient": ["resourceType"],
            "Observation": ["resourceType", "status", "code"],
            "ImagingStudy": ["resourceType", "status", "subject"],
            "DiagnosticReport": ["resourceType", "status", "code", "subject"],
        }
        
        resource_type = resource.get("resourceType")
        if not resource_type:
            return False
        
        required = required_fields.get(resource_type, ["resourceType"])
        return all(field in resource for field in required)


# HL7 v2.x Message Parser and Generator
class HL7Service:
    """
    HL7 v2.x message handling for legacy EHR systems
    """
    
    MESSAGE_TYPES = {
        "ADT": "Admission, Discharge, Transfer",
        "ORM": "Order",
        "ORU": "Observation Result",
        "MDM": "Medical Document Management",
        "PPR": "Patient Problem",
        "MDT": "Medical Document Transaction",
    }
    
    def __init__(self):
        self.segment_separator = "\r"
        self.field_separator = "|"
        self.component_separator = "^"
        self.subcomponent_separator = "&"
        self.repetition_separator = "~"
        self.escape_character = "\\"
    
    def parse_message(self, message: str) -> Dict:
        """Parse HL7 v2.x message"""
        segments = message.split(self.segment_separator)
        
        parsed = {
            "segments": [],
            "message_type": None,
            "message_control_id": None,
            "timestamp": None
        }
        
        for segment in segments:
            if not segment.strip():
                continue
            
            segment_type = segment[:3]
            fields = segment.split(self.field_separator)
            
            segment_data = {
                "type": segment_type,
                "fields": fields[1:]  # Skip segment type
            }
            
            parsed["segments"].append(segment_data)
            
            # Extract key info from MSH
            if segment_type == "MSH":
                parsed["message_type"] = self._parse_message_type(fields[8])
                parsed["message_control_id"] = fields[9]
                parsed["timestamp"] = fields[6]
        
        return parsed
    
    def _parse_message_type(self, field: str) -> Dict:
        """Parse message type field"""
        parts = field.split(self.component_separator)
        return {
            "code": parts[0] if len(parts) > 0 else "",
            "trigger": parts[1] if len(parts) > 1 else "",
            "structure": parts[2] if len(parts) > 2 else ""
        }
    
    def create_oru_message(self, patient_data: Dict, observations: List[Dict]) -> str:
        """Create ORU (Observation Result) message"""
        timestamp = datetime.now().strftime("%Y%m%d%H%M%S")
        
        segments = []
        
        # MSH - Message Header
        msh = f"MSH|{self.field_separator}^~\\&|VASCULAR_AI|HOSPITAL|EHR_SYSTEM|EHR|{timestamp}||ORU^R01|{timestamp}0001|P|2.5"
        segments.append(msh)
        
        # PID - Patient Identification
        pid = f"PID|1||{patient_data.get('mrn', '')}^^^HOSPITAL^MR||{patient_data.get('last_name', '')}^{patient_data.get('first_name', '')}||{patient_data.get('dob', '')}|{patient_data.get('gender', '')}"
        segments.append(pid)
        
        # OBR - Observation Request
        obr = f"OBR|1||{timestamp}0001|18748-4^Diagnostic imaging study^LN|||{timestamp}|||||||||||||||||||||||"
        segments.append(obr)
        
        # OBX - Observation Results
        for i, obs in enumerate(observations, 1):
            obx = f"OBX|{i}|{obs.get('value_type', 'ST')}|{obs.get('code', '')}^{obs.get('name', '')}^LN||{obs.get('value', '')}|{obs.get('unit', '')}|||||F"
            segments.append(obx)
        
        return self.segment_separator.join(segments)
    
    def create_adt_message(self, patient_data: Dict, event_type: str = "A08") -> str:
        """Create ADT (Admission, Discharge, Transfer) message"""
        timestamp = datetime.now().strftime("%Y%m%d%H%M%S")
        
        segments = []
        
        # MSH
        msh = f"MSH|{self.field_separator}^~\\&|VASCULAR_AI|HOSPITAL|EHR_SYSTEM|EHR|{timestamp}||ADT^{event_type}|{timestamp}0001|P|2.5"
        segments.append(msh)
        
        # EVN - Event Type
        evn = f"EVN|{event_type}|{timestamp}"
        segments.append(evn)
        
        # PID
        pid = f"PID|1||{patient_data.get('mrn', '')}^^^HOSPITAL^MR||{patient_data.get('last_name', '')}^{patient_data.get('first_name', '')}||{patient_data.get('dob', '')}|{patient_data.get('gender', '')}"
        segments.append(pid)
        
        # PV1 - Patient Visit
        pv1 = f"PV1|1|O|||||||{patient_data.get('attending_physician', '')}|||||||||||||||||||||||||||||||"
        segments.append(pv1)
        
        return self.segment_separator.join(segments)


# Convenience functions
def create_fhir_service_from_config(config_dict: Dict) -> FHIRService:
    """Create FHIR service from configuration dictionary"""
    config = FHIRConfig(
        base_url=config_dict.get("base_url", ""),
        auth_type=config_dict.get("auth_type", "oauth2"),
        client_id=config_dict.get("client_id"),
        client_secret=config_dict.get("client_secret"),
        access_token=config_dict.get("access_token")
    )
    return FHIRService(config)
