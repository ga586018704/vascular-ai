"""
Risk Calculators Tests
"""

import pytest
from fastapi import status


class TestVSGNECalculator:
    """Test VSGNE Risk Calculator"""
    
    def test_vsgne_low_risk(self, client, auth_headers):
        """Test VSGNE calculator with low risk patient"""
        response = client.post(
            "/api/calculators/vsgne",
            headers=auth_headers,
            json={
                "age": 60,
                "gender": "male",
                "asa_class": 2,
                "functional_status": "independent",
                "procedure_type": "elective",
                "anesthesia_type": "general"
            }
        )
        assert response.status_code == status.HTTP_200_OK
        data = response.json()
        assert "risk_score" in data
        assert "risk_category" in data
        assert "mortality_risk" in data
        assert data["risk_category"] in ["low", "moderate", "high"]
    
    def test_vsgne_high_risk(self, client, auth_headers):
        """Test VSGNE calculator with high risk patient"""
        response = client.post(
            "/api/calculators/vsgne",
            headers=auth_headers,
            json={
                "age": 85,
                "gender": "female",
                "asa_class": 4,
                "functional_status": "dependent",
                "procedure_type": "emergency",
                "anesthesia_type": "general"
            }
        )
        assert response.status_code == status.HTTP_200_OK
        data = response.json()
        assert data["risk_category"] in ["high", "very_high"]
    
    def test_vsgne_invalid_data(self, client, auth_headers):
        """Test VSGNE calculator with invalid data"""
        response = client.post(
            "/api/calculators/vsgne",
            headers=auth_headers,
            json={
                "age": 150,  # Invalid age
                "gender": "invalid",
                "asa_class": 6  # Invalid ASA
            }
        )
        assert response.status_code == status.HTTP_422_UNPROCESSABLE_ENTITY


class TestGASCalculator:
    """Test GAS (Global Anemia Score) Calculator"""
    
    def test_gas_normal(self, client, auth_headers):
        """Test GAS calculator with normal values"""
        response = client.post(
            "/api/calculators/gas",
            headers=auth_headers,
            json={
                "hemoglobin": 13.5,
                "age": 50,
                "gender": "male"
            }
        )
        assert response.status_code == status.HTTP_200_OK
        data = response.json()
        assert "gas_score" in data
        assert "risk_category" in data
        assert "interpretation" in data
    
    def test_gas_anemia(self, client, auth_headers):
        """Test GAS calculator with anemia"""
        response = client.post(
            "/api/calculators/gas",
            headers=auth_headers,
            json={
                "hemoglobin": 8.5,
                "age": 70,
                "gender": "female"
            }
        )
        assert response.status_code == status.HTTP_200_OK
        data = response.json()
        assert "anemia" in data["interpretation"].lower() or data["risk_category"] in ["moderate", "high"]


class TestWellsDVT:
    """Test Wells DVT Score"""
    
    def test_wells_dvt_low_probability(self, client, auth_headers):
        """Test Wells DVT with low probability"""
        response = client.post(
            "/api/calculators/wells-dvt",
            headers=auth_headers,
            json={
                "active_cancer": False,
                "paralysis": False,
                "recent_bedrest": False,
                "localized_tenderness": False,
                "swollen_leg": False,
                "calf_swelling": False,
                "pitting_edema": False,
                "collateral_veins": False,
                "alternative_diagnosis": True
            }
        )
        assert response.status_code == status.HTTP_200_OK
        data = response.json()
        assert "score" in data
        assert "probability" in data
        assert data["probability"] == "low"
    
    def test_wells_dvt_high_probability(self, client, auth_headers):
        """Test Wells DVT with high probability"""
        response = client.post(
            "/api/calculators/wells-dvt",
            headers=auth_headers,
            json={
                "active_cancer": True,
                "paralysis": True,
                "recent_bedrest": True,
                "localized_tenderness": True,
                "swollen_leg": True,
                "calf_swelling": True,
                "pitting_edema": True,
                "collateral_veins": True,
                "alternative_diagnosis": False
            }
        )
        assert response.status_code == status.HTTP_200_OK
        data = response.json()
        assert data["probability"] == "high"
        assert data["recommendation"] is not None


class TestAAARisk:
    """Test AAA Rupture Risk Calculator"""
    
    def test_aaa_small(self, client, auth_headers):
        """Test AAA calculator with small aneurysm"""
        response = client.post(
            "/api/calculators/aaa-risk",
            headers=auth_headers,
            json={
                "diameter": 3.5,
                "growth_rate": 0.1,
                "family_history": False,
                "smoking": False,
                "copd": False,
                "renal_failure": False
            }
        )
        assert response.status_code == status.HTTP_200_OK
        data = response.json()
        assert "annual_rupture_risk" in data
        assert "risk_category" in data
        assert data["risk_category"] == "low"
    
    def test_aaa_large(self, client, auth_headers):
        """Test AAA calculator with large aneurysm"""
        response = client.post(
            "/api/calculators/aaa-risk",
            headers=auth_headers,
            json={
                "diameter": 6.5,
                "growth_rate": 0.5,
                "family_history": True,
                "smoking": True,
                "copd": True,
                "renal_failure": False
            }
        )
        assert response.status_code == status.HTTP_200_OK
        data = response.json()
        assert data["risk_category"] in ["high", "very_high"]
        assert "repair_recommended" in data


class TestCalculatorList:
    """Test calculator listing"""
    
    def test_list_calculators(self, client, auth_headers):
        """Test listing all calculators"""
        response = client.get("/api/calculators/list", headers=auth_headers)
        assert response.status_code == status.HTTP_200_OK
        data = response.json()
        assert "calculators" in data
        calculators = data["calculators"]
        assert len(calculators) >= 4
        
        # Check calculator structure
        calc = calculators[0]
        assert "id" in calc
        assert "name" in calc
        assert "description" in calc
        assert "parameters" in calc
