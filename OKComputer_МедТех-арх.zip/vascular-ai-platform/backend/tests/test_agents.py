"""
AI Agents Tests
"""

import pytest
from fastapi import status


class TestAIAgents:
    """Test AI agent endpoints"""
    
    def test_list_agents(self, client, auth_headers):
        """Test listing all agents"""
        response = client.get("/api/agents/list", headers=auth_headers)
        assert response.status_code == status.HTTP_200_OK
        data = response.json()
        assert isinstance(data, list)
        assert len(data) >= 6  # Should have at least 6 agents
        
        # Check agent structure
        agent = data[0]
        assert "agent_id" in agent
        assert "name" in agent
        assert "description" in agent
        assert "capabilities" in agent
    
    def test_get_agent_capabilities(self, client, auth_headers):
        """Test getting agent capabilities"""
        response = client.get("/api/agents/vascular/capabilities", headers=auth_headers)
        assert response.status_code == status.HTTP_200_OK
        data = response.json()
        assert isinstance(data, list)
        
        if len(data) > 0:
            capability = data[0]
            assert "name" in capability
            assert "description" in capability
    
    def test_get_nonexistent_agent_capabilities(self, client, auth_headers):
        """Test getting capabilities for non-existent agent"""
        response = client.get("/api/agents/nonexistent/capabilities", headers=auth_headers)
        assert response.status_code == status.HTTP_404_NOT_FOUND
    
    def test_analyze_with_agent(self, client, auth_headers):
        """Test analyzing with an agent"""
        response = client.post(
            "/api/agents/vascular/analyze",
            headers=auth_headers,
            json={
                "query": "Patient with claudication and ABI of 0.6",
                "patient_context": {
                    "age": 65,
                    "gender": "male",
                    "smoking_history": True
                },
                "use_llm": False
            }
        )
        assert response.status_code == status.HTTP_200_OK
        data = response.json()
        assert "agent_id" in data
        assert "agent_name" in data
        assert "findings" in data
        assert "recommendations" in data
        assert "confidence_score" in data
        assert isinstance(data["confidence_score"], float)
    
    def test_analyze_with_nonexistent_agent(self, client, auth_headers):
        """Test analyzing with non-existent agent"""
        response = client.post(
            "/api/agents/nonexistent/analyze",
            headers=auth_headers,
            json={
                "query": "Test query",
                "use_llm": False
            }
        )
        assert response.status_code == status.HTTP_404_NOT_FOUND
    
    def test_batch_analyze(self, client, auth_headers):
        """Test batch analysis with multiple agents"""
        response = client.post(
            "/api/agents/batch-analyze",
            headers=auth_headers,
            json={
                "query": "Patient with leg pain and swelling",
                "agent_ids": ["vascular", "phlebology"],
                "patient_context": {
                    "age": 55,
                    "symptoms": ["leg pain", "swelling"]
                }
            }
        )
        assert response.status_code == status.HTTP_200_OK
        data = response.json()
        assert "results" in data
        assert "total_agents" in data
        assert "successful" in data
        assert data["total_agents"] == 2
        assert data["successful"] == 2
    
    def test_smart_routing(self, client, auth_headers):
        """Test smart agent routing"""
        response = client.post(
            "/api/agents/smart-routing",
            headers=auth_headers,
            json={
                "query": "Patient with varicose veins and leg swelling",
                "patient_context": {
                    "age": 45,
                    "gender": "female"
                }
            }
        )
        assert response.status_code == status.HTTP_200_OK
        data = response.json()
        assert "selected_agent" in data
        assert "analysis" in data
        assert "routing_confidence" in data
    
    def test_llm_consultation(self, client, auth_headers):
        """Test direct LLM consultation"""
        response = client.post(
            "/api/agents/llm-consult",
            headers=auth_headers,
            json={
                "query": "What are the indications for carotid endarterectomy?",
                "patient_context": None
            }
        )
        # May fail if LLM not configured, so accept both success and error
        assert response.status_code in [status.HTTP_200_OK, status.HTTP_500_INTERNAL_SERVER_ERROR]
    
    def test_get_specialty_guidelines(self, client, auth_headers):
        """Test getting specialty guidelines"""
        response = client.get("/api/agents/specialty/vascular/guidelines", headers=auth_headers)
        assert response.status_code == status.HTTP_200_OK
        data = response.json()
        assert "guidelines" in data
        assert "key_points" in data
    
    def test_get_nonexistent_specialty_guidelines(self, client, auth_headers):
        """Test getting guidelines for non-existent specialty"""
        response = client.get("/api/agents/specialty/nonexistent/guidelines", headers=auth_headers)
        assert response.status_code == status.HTTP_404_NOT_FOUND


class TestAgentSpecialties:
    """Test different agent specialties"""
    
    @pytest.mark.parametrize("agent_id,query", [
        ("vascular", "Patient with abdominal aortic aneurysm 5.5cm"),
        ("phlebology", "Patient with DVT in left leg"),
        ("neurovascular", "Patient with carotid stenosis 80%"),
        ("endovascular", "EVAR planning for 5cm AAA"),
        ("pediatric", "Child with coarctation of aorta"),
        ("trauma", "Popliteal artery injury from trauma"),
    ])
    def test_agent_specialties(self, client, auth_headers, agent_id, query):
        """Test each agent specialty"""
        response = client.post(
            f"/api/agents/{agent_id}/analyze",
            headers=auth_headers,
            json={
                "query": query,
                "use_llm": False
            }
        )
        assert response.status_code == status.HTTP_200_OK
        data = response.json()
        assert data["agent_id"] == agent_id
        assert len(data["findings"]) > 0
        assert len(data["recommendations"]) > 0
        assert data["confidence_score"] > 0
