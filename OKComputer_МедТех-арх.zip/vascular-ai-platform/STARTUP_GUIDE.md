# VASCULAR.AI - Production Startup Guide

## Quick Start

### 1. Environment Setup

```bash
# Copy environment template
cp backend/.env.example backend/.env

# Edit .env with your settings
nano backend/.env
```

**Required environment variables:**
```bash
# CRITICAL: Generate a strong SECRET_KEY (min 32 chars)
SECRET_KEY=$(openssl rand -hex 32)
echo "SECRET_KEY=$SECRET_KEY" >> backend/.env

# Database (PostgreSQL recommended for production)
DATABASE_URL=postgresql+asyncpg://user:password@localhost/vascular_ai

# Redis (for rate limiting and caching)
REDIS_URL=redis://localhost:6379/0
```

### 2. Database Setup

```bash
# Create PostgreSQL database
sudo -u postgres createdb vascular_ai

# Run migrations
cd backend
alembic upgrade head
```

### 3. Start Services

**Option A: Using Docker Compose (Recommended)**
```bash
docker-compose up -d
```

**Option B: Manual Start**
```bash
# Terminal 1: Start Redis
redis-server

# Terminal 2: Start Celery Worker
cd backend
celery -A app.tasks worker --loglevel=info

# Terminal 3: Start API Server
cd backend
uvicorn app.main:app --host 0.0.0.0 --port 8000 --workers 4

# Terminal 4: Start Frontend
cd frontend
npm run dev
```

### 4. Verify Installation

```bash
# Run verification script
cd scripts
python verify_fixes.py

# Test health endpoint
curl http://localhost:8000/health/detailed
```

---

## Production Deployment

### Docker Compose Production

```yaml
version: '3.8'

services:
  api:
    build: ./backend
    ports:
      - "8000:8000"
    environment:
      - DATABASE_URL=postgresql+asyncpg://postgres:password@db/vascular_ai
      - REDIS_URL=redis://redis:6379/0
      - SECRET_KEY=${SECRET_KEY}
    depends_on:
      - db
      - redis
    command: uvicorn app.main:app --host 0.0.0.0 --port 8000 --workers 4

  worker:
    build: ./backend
    environment:
      - DATABASE_URL=postgresql+asyncpg://postgres:password@db/vascular_ai
      - REDIS_URL=redis://redis:6379/0
      - SECRET_KEY=${SECRET_KEY}
    depends_on:
      - db
      - redis
    command: celery -A app.tasks worker --loglevel=info --concurrency=4

  db:
    image: postgres:15-alpine
    environment:
      - POSTGRES_DB=vascular_ai
      - POSTGRES_PASSWORD=password
    volumes:
      - postgres_data:/var/lib/postgresql/data

  redis:
    image: redis:7-alpine
    volumes:
      - redis_data:/data

  frontend:
    build: ./frontend
    ports:
      - "80:80"
    depends_on:
      - api

volumes:
  postgres_data:
  redis_data:
```

### Kubernetes Deployment

```bash
# Apply manifests
kubectl apply -f k8s/namespace.yaml
kubectl apply -f k8s/configmap.yaml
kubectl apply -f k8s/secret.yaml
kubectl apply -f k8s/postgres.yaml
kubectl apply -f k8s/redis.yaml
kubectl apply -f k8s/api.yaml
kubectl apply -f k8s/worker.yaml
kubectl apply -f k8s/frontend.yaml
kubectl apply -f k8s/ingress.yaml
```

---

## Health Checks

### Endpoints

| Endpoint | Description |
|----------|-------------|
| `GET /health` | Basic health status |
| `GET /health/detailed` | Comprehensive health with all dependencies |
| `GET /health/history` | Health check history |
| `GET /ready` | Kubernetes readiness probe |
| `GET /live` | Kubernetes liveness probe |

### Example Response

```bash
curl http://localhost:8000/health/detailed | jq
```

```json
{
  "status": "healthy",
  "timestamp": "2024-01-15T10:30:00Z",
  "checks": [
    {
      "name": "database",
      "status": "healthy",
      "response_time_ms": 5.23,
      "message": "Database connection successful"
    },
    {
      "name": "redis",
      "status": "healthy",
      "response_time_ms": 2.15,
      "message": "Redis connection successful"
    }
  ],
  "summary": {
    "total": 6,
    "healthy": 6,
    "degraded": 0,
    "unhealthy": 0
  }
}
```

---

## API Usage

### Authentication

```bash
# Login
curl -X POST http://localhost:8000/api/v1/auth/login \
  -H "Content-Type: application/json" \
  -d '{"username": "admin", "password": "password"}'

# Response: {"access_token": "eyJhbG...", "token_type": "bearer"}
```

### Patients (with Pagination)

```bash
# List patients
curl "http://localhost:8000/api/v1/patients?page=1&page_size=20" \
  -H "Authorization: Bearer $TOKEN"

# Search patients
curl "http://localhost:8000/api/v1/patients?search=John&page=1" \
  -H "Authorization: Bearer $TOKEN"
```

### DICOM Upload

```bash
# Upload DICOM file
curl -X POST http://localhost:8000/api/v1/dicom/upload \
  -H "Authorization: Bearer $TOKEN" \
  -F "file=@scan.dcm" \
  -F "patient_id=123"
```

---

## Monitoring

### Prometheus Metrics

```bash
curl http://localhost:8000/metrics
```

### Key Metrics

- `http_requests_total` - Total HTTP requests
- `http_request_duration_seconds` - Request duration histogram
- `rate_limit_hits_total` - Rate limit hits
- `dicom_uploads_total` - DICOM upload counter
- `ai_analysis_duration_seconds` - AI analysis duration

### Grafana Dashboard

Import `monitoring/grafana-dashboard.json` for pre-configured dashboards.

---

## Troubleshooting

### Database Connection Issues

```bash
# Test database connection
psql $DATABASE_URL -c "SELECT 1"

# Check migration status
cd backend
alembic current
alembic history

# Reset database (WARNING: deletes all data!)
alembic downgrade base
alembic upgrade head
```

### Redis Connection Issues

```bash
# Test Redis
redis-cli ping

# Check Redis logs
docker logs vascular-ai-redis-1
```

### Rate Limiting Issues

```bash
# Check rate limit status
curl -I http://localhost:8000/api/v1/patients \
  -H "Authorization: Bearer $TOKEN"

# Response headers:
# X-RateLimit-Limit: 100
# X-RateLimit-Remaining: 95
```

---

## Security Checklist

Before going to production:

- [ ] Change default SECRET_KEY (min 32 chars)
- [ ] Use PostgreSQL (not SQLite)
- [ ] Enable HTTPS
- [ ] Configure CORS for production domain
- [ ] Set up Redis for rate limiting
- [ ] Enable audit logging
- [ ] Configure backup strategy
- [ ] Set up monitoring and alerts
- [ ] Review file upload size limits
- [ ] Test disaster recovery

---

## Support

For issues and questions:
- Documentation: `/docs` (Swagger UI)
- Health: `/health/detailed`
- Email: support@vascular.ai
