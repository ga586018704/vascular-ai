# VASCULAR.AI - Развёртывание через iPhone + Termius

## 📲 Что понадобится

1. **iPhone** с Safari
2. **Приложение Termius** (App Store, бесплатно)
3. **Кредитная карта** для оплаты сервера

---

## Шаг 1: Аренда сервера (5 минут)

### В Safari:

1. Открой **hetzner.com**
2. Нажми **"Console"** (верхний правый угол)
3. Зарегистрируйся:
   - Email
   - Пароль
   - Подтверди email

4. Добавь способ оплаты (Visa/Mastercard)

5. Создай сервер:
   - Нажми **"Add Server"**
   - **Location:** Nuremberg
   - **Image:** Ubuntu 22.04
   - **Type:** CX21 (2 vCPU, 4 GB RAM)
   - **SSH Keys:** Пропусти (будем использовать пароль)
   - **Name:** `vascular-ai`
   - Нажми **"Create & Buy"**

6. **Скопируй IP адрес** (например: `78.46.123.45`)

---

## Шаг 2: Установи Termius

1. Открой **App Store**
2. Найди **"Termius"**
3. Установи (бесплатно)
4. Открой приложение

---

## Шаг 3: Подключись к серверу

### В Termius:

1. Нажми **"+"** (справа внизу)
2. Выбери **"New Host"**
3. Заполни:
   - **Alias:** Vascular AI
   - **Hostname:** `ТВОЙ_IP` (вставь скопированный)
   - **Username:** `root`
   - **Password:** (оставь пустым, спросит позже)

4. Нажми **"Save"**

5. Нажми на созданный хост

6. Введи пароль (пришёл на email от Hetzner)

---

## Шаг 4: Установка платформы (ОДНА КОМАНДА!)

### В Termius вставь эту команду (длинное нажатие → Paste):

```bash
curl -fsSL https://raw.githubusercontent.com/vascular-ai/deploy/main/install.sh | bash
```

Жди 5-10 минут (зависит от скорости интернета)

---

## Шаг 5: Добавь API ключи

### В Termius:

```bash
nano /opt/vascular-ai/.env
```

### Откроется редактор. Найди строки:
```
OPENAI_API_KEY=
ANTHROPIC_API_KEY=
```

### Добавь свои ключи:
```
OPENAI_API_KEY=sk-your-key-here
ANTHROPIC_API_KEY=sk-ant-your-key-here
```

### Сохрани:
1. Нажми **Ctrl+O** (на виртуальной клавиатуре Termius)
2. Нажми **Enter**
3. Нажми **Ctrl+X**

### Перезапусти:
```bash
cd /opt/vascular-ai && docker compose -f docker-compose.prod.yml restart api
```

---

## ✅ Готово!

Открой в Safari:
- **Веб-приложение:** `http://ТВОЙ_IP`
- **API Docs:** `http://ТВОЙ_IP/docs`

---

## 📋 Команды для управления (копируй в Termius)

### Проверить статус:
```bash
cd /opt/vascular-ai && docker compose ps
```

### Посмотреть логи:
```bash
cd /opt/vascular-ai && docker compose logs -f
```

### Перезапустить:
```bash
cd /opt/vascular-ai && docker compose restart
```

### Остановить:
```bash
cd /opt/vascular-ai && docker compose down
```

### Запустить снова:
```bash
cd /opt/vascular-ai && docker compose up -d
```

---

## 🔐 Добавить домен + SSL (опционально)

1. Купи домен (reg.ru, namecheap.com)
2. В DNS добавь A-запись на твой IP
3. В Termius:

```bash
# Установи certbot
apt install -y certbot

# Получи сертификат (замени example.com)
certbot certonly --standalone -d example.com --agree-tos -m твой@email.com

# Перезапусти nginx
cd /opt/vascular-ai && docker compose restart nginx
```

---

## ❓ Проблемы?

### Не подключается?
- Проверь IP адрес
- Подожди 2-3 минуты после создания сервера

### Ошибка в установке?
```bash
# Перезапусти установку
cd /opt/vascular-ai && docker compose down
curl -fsSL https://raw.githubusercontent.com/vascular-ai/deploy/main/install.sh | bash
```

### Забыл пароль?
- В Hetzner Console → Servers → vascular-ai → Reset Root Password

---

## 💰 Стоимость
- Сервер Hetzner CX21: **€6.21/мес** (~$6.80)
- Termius: **Бесплатно**
- Домен (опционально): **~$10/год**

---

## 📞 Поддержка
Пиши мне — помогу! 🚀
