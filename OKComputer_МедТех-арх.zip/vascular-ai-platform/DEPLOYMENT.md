# VASCULAR.AI Deployment Guide

## Table of Contents
1. [Prerequisites](#prerequisites)
2. [Local Development](#local-development)
3. [Docker Deployment](#docker-deployment)
4. [Production Deployment](#production-deployment)
5. [Cloud Deployment](#cloud-deployment)
6. [Monitoring & Maintenance](#monitoring--maintenance)

## Prerequisites

### System Requirements
- **CPU**: 2+ cores (4+ recommended for production)
- **RAM**: 4GB minimum (8GB+ recommended)
- **Storage**: 20GB+ available space
- **OS**: Linux (Ubuntu 20.04+ recommended), macOS, or Windows with WSL2

### Required Software
- Python 3.11+
- Node.js 20+
- Docker & Docker Compose (optional)
- Git

## Local Development

### Quick Start
```bash
# Clone repository
git clone https://github.com/your-org/vascular-ai.git
cd vascular-ai

# Run startup script
./start.sh
```

### Manual Setup

#### Backend Setup
```bash
cd backend

# Create virtual environment
python3 -m venv venv
source venv/bin/activate

# Install dependencies
pip install -r requirements.txt

# Configure environment
cp .env.example .env
# Edit .env with your settings

# Run migrations
alembic upgrade head

# Start server
uvicorn app.main:app --reload --host 0.0.0.0 --port 8000
```

#### Frontend Setup
```bash
cd frontend

# Install dependencies
npm install

# Configure environment
cp .env.example .env
# Edit .env with your settings

# Start development server
npm run dev
```

## Docker Deployment

### Development with Docker Compose
```bash
# Start all services
docker-compose up -d

# View logs
docker-compose logs -f

# Stop services
docker-compose down
```

### Production with Docker Compose
```bash
# Create production environment file
cat > .env.production << EOF
SECRET_KEY=$(openssl rand -hex 32)
DATABASE_URL=postgresql+asyncpg://vascular:secure_password@db:5432/vascular_ai
ENVIRONMENT=production
EOF

# Start with production profile
docker-compose --profile production up -d
```

### Building Custom Images
```bash
# Build backend
docker build -t vascular-ai-backend:latest ./backend

# Build frontend
docker build -t vascular-ai-frontend:latest ./frontend

# Run containers
docker run -d -p 8000:8000 --name vascular-api vascular-ai-backend:latest
docker run -d -p 3000:80 --name vascular-frontend vascular-ai-frontend:latest
```

## Production Deployment

### Security Checklist
- [ ] Change default SECRET_KEY (min 32 characters)
- [ ] Use PostgreSQL instead of SQLite
- [ ] Enable HTTPS with valid SSL certificate
- [ ] Configure proper CORS origins
- [ ] Set up firewall rules
- [ ] Disable DEBUG mode
- [ ] Configure log rotation
- [ ] Set up automated backups

### Nginx Configuration
```nginx
# /etc/nginx/sites-available/vascular-ai
server {
    listen 80;
    server_name your-domain.com;
    return 301 https://$server_name$request_uri;
}

server {
    listen 443 ssl http2;
    server_name your-domain.com;

    ssl_certificate /path/to/cert.pem;
    ssl_certificate_key /path/to/key.pem;
    ssl_protocols TLSv1.2 TLSv1.3;
    ssl_ciphers HIGH:!aNULL:!MD5;

    # Frontend
    location / {
        root /var/www/vascular-ai/frontend;
        try_files $uri $uri/ /index.html;
    }

    # Backend API
    location /api/ {
        proxy_pass http://localhost:8000/;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
        proxy_cache_bypass $http_upgrade;
    }

    # WebSocket
    location /api/ws/ {
        proxy_pass http://localhost:8000/api/ws/;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection "upgrade";
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
    }
}
```

### Systemd Service
```ini
# /etc/systemd/system/vascular-ai.service
[Unit]
Description=VASCULAR.AI Backend
After=network.target

[Service]
Type=simple
User=vascular
WorkingDirectory=/opt/vascular-ai/backend
Environment=PATH=/opt/vascular-ai/backend/venv/bin
EnvironmentFile=/opt/vascular-ai/backend/.env
ExecStart=/opt/vascular-ai/backend/venv/bin/uvicorn app.main:app --host 0.0.0.0 --port 8000 --workers 4
Restart=always
RestartSec=10

[Install]
WantedBy=multi-user.target
```

Enable and start service:
```bash
sudo systemctl enable vascular-ai
sudo systemctl start vascular-ai
sudo systemctl status vascular-ai
```

## Cloud Deployment

### AWS Deployment

#### Using ECS (Elastic Container Service)
```bash
# Build and push images to ECR
aws ecr get-login-password --region us-east-1 | docker login --username AWS --password-stdin your-account.dkr.ecr.us-east-1.amazonaws.com

docker tag vascular-ai-backend:latest your-account.dkr.ecr.us-east-1.amazonaws.com/vascular-ai-backend:latest
docker tag vascular-ai-frontend:latest your-account.dkr.ecr.us-east-1.amazonaws.com/vascular-ai-frontend:latest

docker push your-account.dkr.ecr.us-east-1.amazonaws.com/vascular-ai-backend:latest
docker push your-account.dkr.ecr.us-east-1.amazonaws.com/vascular-ai-frontend:latest
```

#### Using Elastic Beanstalk
```bash
# Initialize EB application
eb init -p docker vascular-ai

# Create environment
eb create vascular-ai-production

# Deploy
eb deploy
```

### Google Cloud Platform

#### Using Cloud Run
```bash
# Build and push to GCR
gcloud builds submit --tag gcr.io/your-project/vascular-ai-backend ./backend
gcloud builds submit --tag gcr.io/your-project/vascular-ai-frontend ./frontend

# Deploy to Cloud Run
gcloud run deploy vascular-ai-backend \
  --image gcr.io/your-project/vascular-ai-backend \
  --platform managed \
  --region us-central1
```

### Azure Deployment

#### Using Container Instances
```bash
# Create resource group
az group create --name vascular-ai-rg --location eastus

# Create container
az container create \
  --resource-group vascular-ai-rg \
  --name vascular-ai-backend \
  --image your-registry/vascular-ai-backend:latest \
  --cpu 2 \
  --memory 4 \
  --ports 8000
```

### Kubernetes Deployment

```yaml
# k8s-deployment.yaml
apiVersion: apps/v1
kind: Deployment
metadata:
  name: vascular-ai-backend
spec:
  replicas: 3
  selector:
    matchLabels:
      app: vascular-ai-backend
  template:
    metadata:
      labels:
        app: vascular-ai-backend
    spec:
      containers:
      - name: backend
        image: your-registry/vascular-ai-backend:latest
        ports:
        - containerPort: 8000
        env:
        - name: DATABASE_URL
          valueFrom:
            secretKeyRef:
              name: vascular-ai-secrets
              key: database-url
        - name: SECRET_KEY
          valueFrom:
            secretKeyRef:
              name: vascular-ai-secrets
              key: secret-key
        resources:
          requests:
            memory: "512Mi"
            cpu: "500m"
          limits:
            memory: "1Gi"
            cpu: "1000m"
        livenessProbe:
          httpGet:
            path: /health
            port: 8000
          initialDelaySeconds: 30
          periodSeconds: 10
        readinessProbe:
          httpGet:
            path: /health
            port: 8000
          initialDelaySeconds: 5
          periodSeconds: 5
---
apiVersion: v1
kind: Service
metadata:
  name: vascular-ai-backend-service
spec:
  selector:
    app: vascular-ai-backend
  ports:
  - port: 80
    targetPort: 8000
  type: ClusterIP
```

Deploy to Kubernetes:
```bash
# Create secrets
kubectl create secret generic vascular-ai-secrets \
  --from-literal=database-url=postgresql://... \
  --from-literal=secret-key=...

# Apply deployment
kubectl apply -f k8s-deployment.yaml

# Check status
kubectl get pods
kubectl get services
```

## Monitoring & Maintenance

### Logging
```bash
# View application logs
docker-compose logs -f api

# View systemd logs
sudo journalctl -u vascular-ai -f

# View Kubernetes logs
kubectl logs -f deployment/vascular-ai-backend
```

### Health Checks
```bash
# API health check
curl http://localhost:8000/health

# Full system check
curl http://localhost:8000/health | jq
```

### Database Backup
```bash
# Backup SQLite
cp data/vascular_ai.db backups/vascular_ai_$(date +%Y%m%d).db

# Backup PostgreSQL
pg_dump -h localhost -U vascular vascular_ai > backups/vascular_ai_$(date +%Y%m%d).sql
```

### Automated Backups (Cron)
```bash
# Edit crontab
crontab -e

# Add backup job (daily at 2 AM)
0 2 * * * /opt/vascular-ai/scripts/backup.sh
```

### Updating
```bash
# Pull latest changes
git pull origin main

# Update backend
cd backend
source venv/bin/activate
pip install -r requirements.txt
alembic upgrade head

# Update frontend
cd ../frontend
npm install
npm run build

# Restart services
sudo systemctl restart vascular-ai
```

## Troubleshooting

### Common Issues

#### Port Already in Use
```bash
# Find process using port 8000
sudo lsof -i :8000

# Kill process
sudo kill -9 <PID>
```

#### Database Connection Issues
```bash
# Test database connection
python -c "from app.db.session import engine; import asyncio; asyncio.run(engine.connect())"
```

#### Permission Denied
```bash
# Fix permissions
sudo chown -R $USER:$USER /opt/vascular-ai
chmod +x /opt/vascular-ai/start.sh
```

### Getting Help
- Check logs: `docker-compose logs` or `journalctl -u vascular-ai`
- Review documentation: `/docs` endpoint
- Open an issue on GitHub

## Performance Tuning

### Database Optimization
- Use PostgreSQL for production
- Add database indexes
- Configure connection pooling
- Enable query caching

### Application Optimization
- Increase worker processes
- Enable Gzip compression
- Use CDN for static assets
- Implement caching with Redis

### Monitoring Tools
- Prometheus + Grafana
- New Relic
- DataDog
- AWS CloudWatch

---

For additional support, contact: support@vascular-ai.com
