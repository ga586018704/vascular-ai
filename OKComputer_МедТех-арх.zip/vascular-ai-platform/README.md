# VASCULAR.AI - Advanced Vascular Medicine Platform

[![CI/CD](https://github.com/your-org/vascular-ai/actions/workflows/ci-cd.yml/badge.svg)](https://github.com/your-org/vascular-ai/actions/workflows/ci-cd.yml)
[![License](https://img.shields.io/badge/license-Proprietary-blue.svg)](LICENSE)
[![Python](https://img.shields.io/badge/python-3.11-blue.svg)](https://python.org)
[![FastAPI](https://img.shields.io/badge/FastAPI-0.109.0-009688.svg)](https://fastapi.tiangolo.com)

A comprehensive AI-powered platform for vascular medicine, providing automated analysis of CT angiography, vessel segmentation, pathology detection, and evidence-based treatment recommendations.

## 🌟 Features

### Core Capabilities

- **🔐 Authentication & Authorization**
  - JWT-based authentication
  - Role-based access control (Admin, Doctor, Radiologist, Technician, Viewer)
  - Session management and audit logging

- **📥 DICOM Processing**
  - Upload and store medical imaging files
  - Automatic metadata extraction
  - Background processing with Celery

- **🔬 CT Angiography Analysis**
  - AI-powered vessel segmentation (ONNX/PyTorch models)
  - 50+ vessel types with complete anatomical nomenclature
  - **314+ pathology types** across 10 categories
  - Aneurysms (saccular, fusiform, dissecting, mycotic, pseudoaneurysm)
  - Stenosis & Occlusion (atherosclerotic, calcified, ulcerated, CTO)
  - Dissections (Stanford Type A/B, DeBakey I/II/III)
  - Vasculitis (Takayasu, Giant Cell, PAN, Behcet, Buerger)
  - Thrombosis & Embolism (acute, chronic, organized)
  - Connective tissue disorders (Marfan, EDS, Loeys-Dietz)
  - Post-interventional complications (ISR, endoleaks, graft failure)
  - Treatment recommendations in surgeon's language
  - Evidence-based guidelines (SVS, ESVS, TASC)

- **📊 Study Comparison**
  - Track disease progression over time
  - Diameter change analysis with annual growth rates
  - New/resolved/progressed finding detection
  - Clinical recommendations based on progression
  - Export comparison reports

- **🎨 Dark Mode & PWA**
  - Dark mode optimized for operating rooms
  - Progressive Web App (PWA) support
  - Offline functionality with service workers
  - Installable on desktop and mobile devices
  - Push notifications for critical findings

- **🌐 3D Vessel Visualization**
  - Interactive 3D rendering with Three.js/WebGL
  - Tube geometry from centerline data
  - Pathology markers with animations
  - Auto-rotation and manual controls
  - Screenshot export

- **🎙️ AI Voice Assistant**
  - Speech recognition and synthesis
  - Natural language command processing
  - Voice-controlled analysis and reporting
  - Multilingual support (RU/EN)
  - Context-aware suggestions

- **🔀 Multi-Planar Reconstruction (MPR)**
  - Axial, Sagittal, Coronal views
  - Synchronized crosshair navigation
  - Window/Level adjustment
  - Segmentation overlay
  - Playback mode

- **🔗 FHIR R4 Integration**
  - Full FHIR compliance
  - Patient, Observation, ImagingStudy resources
  - OAuth2/Bearer/Basic authentication
  - Bulk export support

- **📡 HL7 v2.x Integration**
  - ADT, ORU, ORM, MDM message support
  - Legacy EHR system compatibility
  - Bidirectional message exchange

- **🏥 PACS Integration**
  - DICOM DIMSE (C-FIND, C-MOVE, C-GET)
  - DICOMweb (WADO-RS, QIDO-RS, STOW-RS)
  - Multi-modality support (CT, MR, PET)
  - Study retrieval and thumbnail generation

- **🤖 AI Agents**
  - 8 specialized agents for different vascular pathologies
  - Aortic, peripheral, carotid, venous, renal, mesenteric analysis
  - Real-time analysis with WebSocket support

- **🧮 Risk Calculators**
  - VSGNE Risk Score (surgical mortality prediction)
  - Wells Score (DVT probability)
  - Global Aortic Score (AAA risk)

- **📝 Reports**
  - Generate medical reports
  - PDF export
  - Report templates
  - Approval workflow

- **📊 Analytics Dashboard**
  - System health monitoring
  - User activity tracking
  - Study statistics
  - Prometheus metrics

- **🌍 Multi-language Support**
  - English, Russian, German, French, Spanish
  - Easy to add more languages

## 🏗️ Architecture

```
VASCULAR.AI
├── Backend (FastAPI)
│   ├── API Layer (REST + WebSocket)
│   ├── Service Layer (Business Logic)
│   ├── Data Layer (SQLAlchemy + Async)
│   ├── AI/ML Layer (Segmentation + Classification)
│   └── Background Tasks (Celery + Redis)
│
├── Frontend (React + TypeScript)
│   ├── Components (Material-UI)
│   ├── Pages (React Router)
│   ├── Services (API Client)
│   └── State Management (Context API)
│
└── Infrastructure
    ├── Docker + Docker Compose
    ├── PostgreSQL/SQLite (Database)
    ├── Redis (Cache + Message Broker)
    ├── Nginx (Reverse Proxy)
    └── Prometheus (Metrics)
```

## 🚀 Quick Start

### Prerequisites

- Docker 20.10+
- Docker Compose 2.0+
- Git

### Installation

1. Clone the repository:
```bash
git clone https://github.com/your-org/vascular-ai.git
cd vascular-ai
```

2. Create environment file:
```bash
cp .env.example .env
# Edit .env with your configuration
```

3. Start all services:
```bash
docker-compose up -d
```

4. Access the platform:
- Frontend: http://localhost:3000
- API: http://localhost:8000
- API Documentation: http://localhost:8000/docs

### Create Admin User

```bash
curl -X POST http://localhost:8000/api/auth/register \
  -H "Content-Type: application/json" \
  -d '{
    "username": "admin",
    "email": "admin@vascular.ai",
    "password": "your-secure-password",
    "full_name": "Administrator",
    "role": "admin"
  }'
```

## 📁 Project Structure

```
vascular-ai/
├── backend/
│   ├── app/
│   │   ├── api/              # API endpoints
│   │   ├── core/             # Core utilities
│   │   ├── db/               # Database models
│   │   ├── middleware/       # FastAPI middleware
│   │   ├── models/           # SQLAlchemy models
│   │   ├── services/         # Business logic
│   │   └── tasks/            # Celery tasks
│   ├── alembic/              # Database migrations
│   ├── tests/                # Test suite
│   ├── Dockerfile
│   └── requirements.txt
│
├── frontend/
│   ├── src/
│   │   ├── components/       # React components
│   │   ├── contexts/         # React contexts
│   │   ├── i18n/             # Translations
│   │   ├── layouts/          # Page layouts
│   │   ├── pages/            # Page components
│   │   └── services/         # API services
│   ├── public/
│   ├── Dockerfile
│   └── package.json
│
├── docker-compose.yml
├── .github/workflows/        # CI/CD pipelines
└── README.md
```

## 🔧 Configuration

### Environment Variables

| Variable | Description | Default |
|----------|-------------|---------|
| `SECRET_KEY` | JWT secret key | Required |
| `DATABASE_URL` | Database connection string | `sqlite+aiosqlite:///./vascular_ai.db` |
| `REDIS_URL` | Redis connection string | `redis://localhost:6379/0` |
| `OPENAI_API_KEY` | OpenAI API key | Optional |
| `ANTHROPIC_API_KEY` | Anthropic API key | Optional |
| `SMTP_HOST` | SMTP server host | Optional |
| `SMTP_PORT` | SMTP server port | `587` |

### Rate Limiting

Default rate limits:
- 100 requests per minute per user
- 20 burst requests per second

Configure via `RATE_LIMIT_REQUESTS` environment variable.

## 🧪 Development

### Backend Development

```bash
cd backend
python -m venv venv
source venv/bin/activate  # On Windows: venv\Scripts\activate
pip install -r requirements.txt

# Run development server
uvicorn app.main:app --reload --port 8000

# Run tests
pytest

# Run database migrations
alembic upgrade head
```

### Frontend Development

```bash
cd frontend
npm install

# Run development server
npm run dev

# Run tests
npm test

# Build for production
npm run build
```

## 📚 API Documentation

Interactive API documentation is available at:
- Swagger UI: http://localhost:8000/docs
- ReDoc: http://localhost:8000/redoc
- OpenAPI JSON: http://localhost:8000/openapi.json

### Authentication

All API endpoints (except `/auth/*`) require authentication via Bearer token:

```bash
curl -H "Authorization: Bearer <your-token>" \
  http://localhost:8000/api/dicom/studies
```

### Key Endpoints

| Endpoint | Description |
|----------|-------------|
| `POST /api/auth/login` | Authenticate user |
| `POST /api/dicom/upload` | Upload DICOM files |
| `POST /api/angiography/analyze` | Analyze CT angiography |
| `POST /api/studies/compare` | Compare two studies |
| `GET /api/studies/{patient_id}/studies` | Get patient studies |
| `POST /api/agents/analyze` | Run AI agent analysis |
| `POST /api/calculators/vsgne` | Calculate VSGNE score |
| `GET /api/analytics/dashboard` | Get dashboard statistics |

## 🔒 Security

- JWT-based authentication with refresh tokens
- Password hashing with bcrypt
- Rate limiting to prevent abuse
- Security headers (CSP, HSTS, X-Frame-Options)
- Audit logging for HIPAA compliance
- Input validation and sanitization

## 📊 Monitoring

- Prometheus metrics at `/api/metrics`
- Health checks at `/health`, `/ready`, `/live`
- Structured logging with JSON format
- Request tracing with X-Request-ID headers

## 🤝 Contributing

1. Fork the repository
2. Create a feature branch (`git checkout -b feature/amazing-feature`)
3. Commit your changes (`git commit -m 'Add amazing feature'`)
4. Push to the branch (`git push origin feature/amazing-feature`)
5. Open a Pull Request

### Code Style

- Python: Black formatter (line length 100)
- TypeScript: ESLint + Prettier
- Commit messages: Conventional Commits

## 📄 License

This project is proprietary software. See [LICENSE](LICENSE) for details.

## 🙏 Acknowledgments

- [FastAPI](https://fastapi.tiangolo.com/) - Modern web framework
- [SQLAlchemy](https://www.sqlalchemy.org/) - Database toolkit
- [Material-UI](https://mui.com/) - React component library
- [Celery](https://docs.celeryq.dev/) - Distributed task queue

## 📞 Support

For support, email support@vascular.ai or open an issue on GitHub.

---

<p align="center">
  Made with ❤️ for vascular surgeons worldwide
</p>
