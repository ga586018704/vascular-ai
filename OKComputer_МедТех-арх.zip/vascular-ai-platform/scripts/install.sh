#!/bin/bash
# VASCULAR.AI - One-Line Installer for iPhone/Termius
# Run: curl -fsSL https://install.vascular.ai | bash

set -e

# Colors
GREEN='\033[0;32m'
BLUE='\033[0;34m'
YELLOW='\033[1;33m'
RED='\033[0;31m'
NC='\033[0m'

echo -e "${BLUE}===============================================${NC}"
echo -e "${BLUE}  VASCULAR.AI - Installation Script${NC}"
echo -e "${BLUE}===============================================${NC}"
echo ""

# Check if running as root
if [[ $EUID -ne 0 ]]; then
   echo -e "${RED}This script must be run as root${NC}"
   exit 1
fi

# Update system
echo -e "${BLUE}[1/7] Updating system...${NC}"
apt-get update -qq > /dev/null 2>&1
apt-get install -y -qq curl wget git openssl > /dev/null 2>&1
echo -e "${GREEN}✓ System updated${NC}"

# Install Docker
echo -e "${BLUE}[2/7] Installing Docker...${NC}"
if ! command -v docker &> /dev/null; then
    curl -fsSL https://get.docker.com | sh > /dev/null 2>&1
    systemctl enable docker > /dev/null 2>&1
    systemctl start docker > /dev/null 2>&1
    echo -e "${GREEN}✓ Docker installed${NC}"
else
    echo -e "${GREEN}✓ Docker already installed${NC}"
fi

# Install Docker Compose
echo -e "${BLUE}[3/7] Installing Docker Compose...${NC}"
if ! docker compose version &> /dev/null; then
    apt-get install -y -qq docker-compose-plugin > /dev/null 2>&1
    echo -e "${GREEN}✓ Docker Compose installed${NC}"
else
    echo -e "${GREEN}✓ Docker Compose already installed${NC}"
fi

# Create project directory
echo -e "${BLUE}[4/7] Creating project directory...${NC}"
PROJECT_DIR="/opt/vascular-ai"
mkdir -p $PROJECT_DIR
cd $PROJECT_DIR

# Create docker-compose.prod.yml
echo -e "${BLUE}[5/7] Creating configuration files...${NC}"

cat > docker-compose.prod.yml << 'DOCKER_EOF'
version: '3.8'

services:
  db:
    image: postgres:15-alpine
    container_name: vascular-db
    restart: unless-stopped
    environment:
      POSTGRES_DB: ${POSTGRES_DB:-vascular_ai}
      POSTGRES_USER: ${POSTGRES_USER:-vascular}
      POSTGRES_PASSWORD: ${POSTGRES_PASSWORD:-changeme}
    volumes:
      - postgres_data:/var/lib/postgresql/data
    networks:
      - vascular-network
    healthcheck:
      test: ["CMD-SHELL", "pg_isready -U ${POSTGRES_USER:-vascular} -d ${POSTGRES_DB:-vascular_ai}"]
      interval: 10s
      timeout: 5s
      retries: 5

  redis:
    image: redis:7-alpine
    container_name: vascular-redis
    restart: unless-stopped
    volumes:
      - redis_data:/data
    networks:
      - vascular-network

  api:
    image: python:3.11-slim
    container_name: vascular-api
    restart: unless-stopped
    working_dir: /app
    command: >
      sh -c "pip install -q fastapi uvicorn sqlalchemy asyncpg redis celery pydantic pydantic-settings
      python -c 'import uvicorn; uvicorn.run(\"app.main:app\", host=\"0.0.0.0\", port=8000)'"
    environment:
      - DATABASE_URL=postgresql+asyncpg://${POSTGRES_USER:-vascular}:${POSTGRES_PASSWORD:-changeme}@db:5432/${POSTGRES_DB:-vascular_ai}
      - REDIS_URL=redis://redis:6379/0
      - SECRET_KEY=${SECRET_KEY}
      - OPENAI_API_KEY=${OPENAI_API_KEY:-}
      - ANTHROPIC_API_KEY=${ANTHROPIC_API_KEY:-}
      - DEBUG=false
    volumes:
      - ./backend:/app
      - uploads:/app/uploads
    depends_on:
      db:
        condition: service_healthy
    networks:
      - vascular-network

  frontend:
    image: nginx:alpine
    container_name: vascular-frontend
    restart: unless-stopped
    volumes:
      - ./frontend/dist:/usr/share/nginx/html:ro
    networks:
      - vascular-network

  nginx:
    image: nginx:alpine
    container_name: vascular-nginx
    restart: unless-stopped
    ports:
      - "80:80"
    volumes:
      - ./nginx/nginx.conf:/etc/nginx/nginx.conf:ro
      - uploads:/var/www/uploads:ro
    depends_on:
      - api
      - frontend
    networks:
      - vascular-network

volumes:
  postgres_data:
  redis_data:
  uploads:

networks:
  vascular-network:
    driver: bridge
DOCKER_EOF

# Create nginx config
mkdir -p nginx
cat > nginx/nginx.conf << 'NGINX_EOF'
events {
    worker_connections 1024;
}

http {
    include /etc/nginx/mime.types;
    default_type application/octet-stream;
    sendfile on;
    tcp_nopush on;
    tcp_nodelay on;
    keepalive_timeout 65;
    gzip on;
    gzip_vary on;
    gzip_proxied any;
    gzip_comp_level 6;
    gzip_types text/plain text/css text/xml application/json application/javascript;

    upstream api_backend {
        server api:8000;
    }

    upstream frontend_backend {
        server frontend:80;
    }

    server {
        listen 80;
        server_name _;

        location / {
            proxy_pass http://frontend_backend;
            proxy_http_version 1.1;
            proxy_set_header Host $host;
            proxy_set_header X-Real-IP $remote_addr;
        }

        location /api/ {
            proxy_pass http://api_backend/;
            proxy_http_version 1.1;
            proxy_set_header Host $host;
            proxy_set_header X-Real-IP $remote_addr;
            proxy_read_timeout 300s;
            client_max_body_size 500M;
        }

        location /docs {
            proxy_pass http://api_backend/docs;
        }

        location /health {
            proxy_pass http://api_backend/health;
        }
    }
}
NGINX_EOF

echo -e "${GREEN}✓ Configuration files created${NC}"

# Create .env file
echo -e "${BLUE}[6/7] Generating secrets...${NC}"

POSTGRES_PASSWORD=$(openssl rand -base64 24 | tr -d "=+/" | cut -c1-20)
SECRET_KEY=$(openssl rand -hex 32)

if [ ! -f .env ]; then
    cat > .env << EOF
# Database
POSTGRES_DB=vascular_ai
POSTGRES_USER=vascular
POSTGRES_PASSWORD=$POSTGRES_PASSWORD

# Security
SECRET_KEY=$SECRET_KEY

# API Keys (ADD YOUR KEYS HERE!)
OPENAI_API_KEY=
ANTHROPIC_API_KEY=
EOF
    chmod 600 .env
fi

echo -e "${GREEN}✓ Secrets generated${NC}"

# Start services
echo -e "${BLUE}[7/7] Starting services...${NC}"
docker compose -f docker-compose.prod.yml up -d

# Wait for services
echo -e "${BLUE}Waiting for services to start (30 seconds)...${NC}"
sleep 30

# Get IP
IP=$(curl -s ifconfig.me 2>/dev/null || echo "YOUR_SERVER_IP")

echo ""
echo -e "${BLUE}===============================================${NC}"
echo -e "${GREEN}  VASCULAR.AI Installed Successfully!${NC}"
echo -e "${BLUE}===============================================${NC}"
echo ""
echo -e "${GREEN}✓ Platform is running!${NC}"
echo ""
echo -e "Access your platform:"
echo -e "  ${YELLOW}Website:${NC} http://$IP"
echo -e "  ${YELLOW}API Docs:${NC} http://$IP/docs"
echo -e "  ${YELLOW}Health:${NC} http://$IP/health"
echo ""
echo -e "${YELLOW}⚠️  IMPORTANT - ADD API KEYS:${NC}"
echo ""
echo "1. Edit the config file:"
echo "   nano /opt/vascular-ai/.env"
echo ""
echo "2. Add your API keys:"
echo "   OPENAI_API_KEY=sk-your-key-here"
echo "   ANTHROPIC_API_KEY=sk-ant-your-key-here"
echo ""
echo "3. Save and exit: Ctrl+O, Enter, Ctrl+X"
echo ""
echo "4. Restart the API:"
echo "   docker compose -f docker-compose.prod.yml restart api"
echo ""
echo -e "${BLUE}===============================================${NC}"
echo ""

# Show container status
echo "Container Status:"
docker compose -f docker-compose.prod.yml ps

echo ""
echo -e "${GREEN}Installation complete!${NC}"
