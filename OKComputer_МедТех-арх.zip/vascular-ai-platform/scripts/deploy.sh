#!/bin/bash
# VASCULAR.AI - Production Deployment Script
# Run this on your VPS server

set -e

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Configuration
PROJECT_NAME="vascular-ai"
PROJECT_DIR="/opt/$PROJECT_NAME"
DOMAIN="${DOMAIN:-}"

# Functions
log_info() {
    echo -e "${BLUE}[INFO]${NC} $1"
}

log_success() {
    echo -e "${GREEN}[SUCCESS]${NC} $1"
}

log_warn() {
    echo -e "${YELLOW}[WARN]${NC} $1"
}

log_error() {
    echo -e "${RED}[ERROR]${NC} $1"
}

# Check if running as root
check_root() {
    if [[ $EUID -ne 0 ]]; then
        log_error "This script must be run as root"
        exit 1
    fi
}

# Install Docker and Docker Compose
install_docker() {
    log_info "Installing Docker and Docker Compose..."
    
    # Remove old versions
    apt-get remove -y docker docker-engine docker.io containerd runc 2>/dev/null || true
    
    # Install dependencies
    apt-get update
    apt-get install -y \
        apt-transport-https \
        ca-certificates \
        curl \
        gnupg \
        lsb-release \
        git
    
    # Add Docker GPG key
    mkdir -p /etc/apt/keyrings
    curl -fsSL https://download.docker.com/linux/ubuntu/gpg | gpg --dearmor -o /etc/apt/keyrings/docker.gpg
    
    # Add Docker repository
    echo \
        "deb [arch=$(dpkg --print-architecture) signed-by=/etc/apt/keyrings/docker.gpg] https://download.docker.com/linux/ubuntu \
        $(lsb_release -cs) stable" | tee /etc/apt/sources.list.d/docker.list > /dev/null
    
    # Install Docker
    apt-get update
    apt-get install -y docker-ce docker-ce-cli containerd.io docker-compose-plugin
    
    # Start Docker
    systemctl start docker
    systemctl enable docker
    
    log_success "Docker installed successfully"
}

# Setup project directory
setup_project() {
    log_info "Setting up project directory..."
    
    mkdir -p $PROJECT_DIR
    cd $PROJECT_DIR
    
    # Create necessary directories
    mkdir -p logs uploads nginx/ssl monitoring/grafana/dashboards monitoring/grafana/datasources
    
    log_success "Project directory created at $PROJECT_DIR"
}

# Generate secure secrets
generate_secrets() {
    log_info "Generating secure secrets..."
    
    POSTGRES_PASSWORD=$(openssl rand -base64 32)
    SECRET_KEY=$(openssl rand -hex 64)
    GRAFANA_PASSWORD=$(openssl rand -base64 16)
    
    cat > $PROJECT_DIR/.env << EOF
# Database
POSTGRES_DB=vascular_ai
POSTGRES_USER=vascular
POSTGRES_PASSWORD=$POSTGRES_PASSWORD

# Security
SECRET_KEY=$SECRET_KEY

# API Keys (fill these in)
OPENAI_API_KEY=
ANTHROPIC_API_KEY=

# Grafana
GRAFANA_USER=admin
GRAFANA_PASSWORD=$GRAFANA_PASSWORD

# Domain (for SSL)
DOMAIN=$DOMAIN
EOF
    
    chmod 600 $PROJECT_DIR/.env
    
    log_success "Secrets generated and saved to .env"
    log_warn "Please edit .env and add your API keys!"
}

# Setup SSL with Let's Encrypt
setup_ssl() {
    if [ -z "$DOMAIN" ]; then
        log_warn "No domain specified, skipping SSL setup"
        return
    fi
    
    log_info "Setting up SSL for $DOMAIN..."
    
    # Install certbot
    apt-get install -y certbot
    
    # Obtain certificate
    certbot certonly --standalone -d $DOMAIN --agree-tos -n -m admin@$DOMAIN
    
    # Update nginx config to use SSL
    sed -i "s/# server {/server {/" $PROJECT_DIR/nginx/nginx.conf
    sed -i "s/#     listen 443/    listen 443/" $PROJECT_DIR/nginx/nginx.conf
    sed -i "s/#     ssl_certificate/    ssl_certificate/" $PROJECT_DIR/nginx/nginx.conf
    sed -i "s/your-domain.com/$DOMAIN/g" $PROJECT_DIR/nginx/nginx.conf
    
    log_success "SSL certificate obtained for $DOMAIN"
}

# Create Prometheus config
create_monitoring() {
    log_info "Creating monitoring configuration..."
    
    cat > $PROJECT_DIR/monitoring/prometheus.yml << 'EOF'
global:
  scrape_interval: 15s
  evaluation_interval: 15s

scrape_configs:
  - job_name: 'prometheus'
    static_configs:
      - targets: ['localhost:9090']

  - job_name: 'vascular-api'
    static_configs:
      - targets: ['api:8000']
    metrics_path: '/metrics'
EOF

    # Create Grafana datasource
    mkdir -p $PROJECT_DIR/monitoring/grafana/datasources
    cat > $PROJECT_DIR/monitoring/grafana/datasources/prometheus.yml << 'EOF'
apiVersion: 1
datasources:
  - name: Prometheus
    type: prometheus
    access: proxy
    url: http://prometheus:9090
    isDefault: true
EOF

    log_success "Monitoring configuration created"
}

# Create systemd service
create_service() {
    log_info "Creating systemd service..."
    
    cat > /etc/systemd/system/$PROJECT_NAME.service << EOF
[Unit]
Description=VASCULAR.AI Platform
Requires=docker.service
After=docker.service

[Service]
Type=oneshot
RemainAfterExit=yes
WorkingDirectory=$PROJECT_DIR
ExecStart=/usr/bin/docker compose -f docker-compose.prod.yml up -d
ExecStop=/usr/bin/docker compose -f docker-compose.prod.yml down
TimeoutStartSec=0

[Install]
WantedBy=multi-user.target
EOF

    systemctl daemon-reload
    systemctl enable $PROJECT_NAME
    
    log_success "Systemd service created"
}

# Deploy the application
deploy() {
    log_info "Deploying VASCULAR.AI..."
    
    cd $PROJECT_DIR
    
    # Pull latest images
    docker compose -f docker-compose.prod.yml pull
    
    # Build and start
    docker compose -f docker-compose.prod.yml up -d --build
    
    log_success "Deployment completed!"
}

# Show status
show_status() {
    log_info "Checking deployment status..."
    
    cd $PROJECT_DIR
    
    echo ""
    echo "==============================================="
    echo "Container Status:"
    echo "==============================================="
    docker compose -f docker-compose.prod.yml ps
    
    echo ""
    echo "==============================================="
    echo "Access Information:"
    echo "==============================================="
    
    if [ -n "$DOMAIN" ]; then
        echo "Website: https://$DOMAIN"
    else
        IP=$(curl -s ifconfig.me)
        echo "Website: http://$IP"
    fi
    
    echo "API Docs: http://localhost/docs"
    echo "Health: http://localhost/health"
    echo "Grafana: http://localhost/grafana (admin / see .env)"
    echo ""
    echo "Logs: docker compose -f docker-compose.prod.yml logs -f"
    echo ""
}

# Main menu
show_menu() {
    echo ""
    echo "==============================================="
    echo "  VASCULAR.AI - Deployment Menu"
    echo "==============================================="
    echo ""
    echo "1) Full installation (first time)"
    echo "2) Deploy/Update application"
    echo "3) View logs"
    echo "4) Restart services"
    echo "5) Stop services"
    echo "6) Backup database"
    echo "7) Show status"
    echo "8) Exit"
    echo ""
}

# Full installation
full_install() {
    log_info "Starting full installation..."
    
    check_root
    install_docker
    setup_project
    generate_secrets
    create_monitoring
    create_service
    
    log_warn "==============================================="
    log_warn "IMPORTANT: Edit $PROJECT_DIR/.env and add:"
    log_warn "  - OPENAI_API_KEY"
    log_warn "  - ANTHROPIC_API_KEY"
    log_warn "  - DOMAIN (optional, for SSL)"
    log_warn "==============================================="
    
    read -p "Press Enter after editing .env to continue..."
    
    # Source the env file
    source $PROJECT_DIR/.env
    
    if [ -n "$DOMAIN" ]; then
        setup_ssl
    fi
    
    deploy
    show_status
}

# Main
main() {
    if [ "$1" == "--full" ]; then
        full_install
        exit 0
    fi
    
    while true; do
        show_menu
        read -p "Select option: " choice
        
        case $choice in
            1) full_install ;;
            2) deploy; show_status ;;
            3) cd $PROJECT_DIR && docker compose -f docker-compose.prod.yml logs -f ;;
            4) cd $PROJECT_DIR && docker compose -f docker-compose.prod.yml restart ;;
            5) cd $PROJECT_DIR && docker compose -f docker-compose.prod.yml down ;;
            6) 
                log_info "Creating backup..."
                cd $PROJECT_DIR
                docker compose -f docker-compose.prod.yml exec -T db pg_dump -U vascular vascular_ai > backup_$(date +%Y%m%d_%H%M%S).sql
                log_success "Backup created"
                ;;
            7) show_status ;;
            8) exit 0 ;;
            *) log_error "Invalid option" ;;
        esac
    done
}

main "$@"
