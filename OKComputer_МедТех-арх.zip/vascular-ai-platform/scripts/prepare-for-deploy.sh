#!/bin/bash
# VASCULAR.AI - Prepare for Deployment Script
# Run this on your local machine to prepare files for server upload

set -e

# Colors
GREEN='\033[0;32m'
BLUE='\033[0;34m'
YELLOW='\033[1;33m'
RED='\033[0;31m'
NC='\033[0m'

echo -e "${BLUE}===============================================${NC}"
echo -e "${BLUE}  VASCULAR.AI - Deployment Preparation${NC}"
echo -e "${BLUE}===============================================${NC}"
echo ""

# Get project root
PROJECT_ROOT="$(cd "$(dirname "$0")/.." && pwd)"
cd "$PROJECT_ROOT"

# Check required files
echo -e "${BLUE}Checking required files...${NC}"

required_files=(
    "docker-compose.prod.yml"
    "backend/Dockerfile.prod"
    "frontend/Dockerfile.prod"
    "nginx/nginx.conf"
    "nginx/conf.d/app.conf"
)

for file in "${required_files[@]}"; do
    if [ ! -f "$file" ]; then
        echo -e "${RED}Missing: $file${NC}"
        exit 1
    fi
    echo -e "${GREEN}✓${NC} $file"
done

echo ""

# Create deployment package
echo -e "${BLUE}Creating deployment package...${NC}"

DEPLOY_DIR="$PROJECT_ROOT/deploy-package"
mkdir -p "$DEPLOY_DIR"

# Copy files
cp docker-compose.prod.yml "$DEPLOY_DIR/"
cp -r backend "$DEPLOY_DIR/"
cp -r frontend "$DEPLOY_DIR/"
cp -r nginx "$DEPLOY_DIR/"
cp -r scripts "$DEPLOY_DIR/"
cp -r monitoring "$DEPLOY_DIR/" 2>/dev/null || true

# Remove unnecessary files
echo -e "${BLUE}Cleaning up...${NC}"
rm -rf "$DEPLOY_DIR/backend/__pycache__"
rm -rf "$DEPLOY_DIR/backend/.pytest_cache"
rm -rf "$DEPLOY_DIR/backend/venv"
rm -rf "$DEPLOY_DIR/backend/.env"
rm -rf "$DEPLOY_DIR/frontend/node_modules"
rm -rf "$DEPLOY_DIR/frontend/dist"
rm -rf "$DEPLOY_DIR/frontend/.env"

# Create .env template
echo -e "${BLUE}Creating .env template...${NC}"

cat > "$DEPLOY_DIR/.env.example" << 'EOF'
# Database Configuration
POSTGRES_DB=vascular_ai
POSTGRES_USER=vascular
POSTGRES_PASSWORD=CHANGE_THIS_PASSWORD

# Security
SECRET_KEY=CHANGE_THIS_TO_64_CHAR_HEX_STRING

# API Keys (required for AI features)
OPENAI_API_KEY=sk-your-openai-key
ANTHROPIC_API_KEY=sk-ant-your-anthropic-key

# Grafana Admin
GRAFANA_USER=admin
GRAFANA_PASSWORD=CHANGE_THIS_PASSWORD

# Domain (optional, for SSL)
DOMAIN=your-domain.com
EOF

# Create README for server
cat > "$DEPLOY_DIR/README.txt" << 'EOF'
VASCULAR.AI - Deployment Package
================================

1. Upload all files to your server:
   scp -r deploy-package/* root@YOUR_SERVER_IP:/opt/vascular-ai/

2. On server, run:
   cd /opt/vascular-ai
   chmod +x scripts/deploy.sh
   ./deploy.sh --full

3. Edit .env and add your API keys:
   nano /opt/vascular-ai/.env

4. Restart API:
   docker compose -f docker-compose.prod.yml restart api

Access:
- Website: http://YOUR_SERVER_IP
- API Docs: http://YOUR_SERVER_IP/docs
- Health: http://YOUR_SERVER_IP/health
EOF

# Create tar archive
echo -e "${BLUE}Creating archive...${NC}"
cd "$PROJECT_ROOT"
tar -czf "vascular-ai-deploy-$(date +%Y%m%d).tar.gz" -C "$DEPLOY_DIR" .

# Cleanup
rm -rf "$DEPLOY_DIR"

# Summary
echo ""
echo -e "${GREEN}===============================================${NC}"
echo -e "${GREEN}  Deployment package created!${NC}"
echo -e "${GREEN}===============================================${NC}"
echo ""
echo -e "File: ${YELLOW}vascular-ai-deploy-$(date +%Y%m%d).tar.gz${NC}"
echo ""
echo -e "Next steps:"
echo -e "1. ${BLUE}Upload to server:${NC}"
echo -e "   scp vascular-ai-deploy-*.tar.gz root@YOUR_SERVER_IP:/tmp/"
echo ""
echo -e "2. ${BLUE}On server, extract and deploy:${NC}"
echo -e "   ssh root@YOUR_SERVER_IP"
echo -e "   mkdir -p /opt/vascular-ai"
echo -e "   tar -xzf /tmp/vascular-ai-deploy-*.tar.gz -C /opt/vascular-ai/"
echo -e "   cd /opt/vascular-ai"
echo -e "   chmod +x scripts/deploy.sh"
echo -e "   ./deploy.sh --full"
echo ""
echo -e "3. ${BLUE}Add your API keys:${NC}"
echo -e "   nano /opt/vascular-ai/.env"
echo ""
echo -e "4. ${BLUE}Access your platform:${NC}"
echo -e "   http://YOUR_SERVER_IP"
echo ""
