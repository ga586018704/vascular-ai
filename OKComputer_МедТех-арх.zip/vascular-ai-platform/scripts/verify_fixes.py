#!/usr/bin/env python3
"""
VASCULAR.AI Platform Fixes Verification Script
Tests all critical fixes to ensure platform is production-ready
"""

import asyncio
import sys
import os

# Add backend to path
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', 'backend'))

async def test_config():
    """Test configuration loading"""
    print("\n" + "="*60)
    print("TEST 1: Configuration & SECRET_KEY Validation")
    print("="*60)
    
    try:
        from app.core.config import get_settings
        settings = get_settings()
        
        # Check SECRET_KEY
        assert len(settings.SECRET_KEY) >= 32, "SECRET_KEY must be >= 32 characters"
        assert settings.SECRET_KEY != "your-secret-key-change-in-production", "Default SECRET_KEY detected!"
        
        print("✅ SECRET_KEY is properly configured")
        print(f"   Length: {len(settings.SECRET_KEY)} characters")
        
        # Check database URL
        if "postgresql" in settings.DATABASE_URL:
            print("✅ PostgreSQL database configured")
        else:
            print("⚠️  Using SQLite (development only)")
        
        return True
        
    except Exception as e:
        print(f"❌ Configuration test failed: {e}")
        return False


async def test_database():
    """Test database connectivity"""
    print("\n" + "="*60)
    print("TEST 2: Database Connectivity")
    print("="*60)
    
    try:
        from sqlalchemy import text
        from app.db.session import engine
        
        async with engine.connect() as conn:
            result = await conn.execute(text("SELECT 1"))
            assert result.scalar() == 1
        
        print("✅ Database connection successful")
        
        # Check pool stats if available
        pool = engine.pool
        if hasattr(pool, 'size'):
            print(f"   Pool size: {pool.size()}")
            print(f"   Checked in: {pool.checkedin()}")
            print(f"   Checked out: {pool.checkedout()}")
        
        return True
        
    except Exception as e:
        print(f"❌ Database test failed: {e}")
        return False


async def test_redis():
    """Test Redis connectivity"""
    print("\n" + "="*60)
    print("TEST 3: Redis Cache")
    print("="*60)
    
    try:
        from app.core.cache import cache
        
        if cache.is_connected:
            await cache.set("test_key", "test_value", expire=60)
            value = await cache.get("test_key")
            assert value == "test_value", "Cache read/write failed"
            await cache.delete("test_key")
            
            print("✅ Redis cache is working")
            return True
        else:
            print("⚠️  Redis not connected (will use memory fallback)")
            return True
            
    except Exception as e:
        print(f"❌ Redis test failed: {e}")
        return False


async def test_dicom_validator():
    """Test DICOM validation"""
    print("\n" + "="*60)
    print("TEST 4: DICOM Validation")
    print("="*60)
    
    try:
        from app.core.dicom_validator import DICOMValidator
        
        validator = DICOMValidator()
        
        # Test allowed modalities
        assert "CT" in validator.SUPPORTED_MODALITIES
        assert "MR" in validator.SUPPORTED_MODALITIES
        
        print("✅ DICOM validator initialized")
        print(f"   Supported modalities: {', '.join(validator.SUPPORTED_MODALITIES)}")
        print(f"   Max file size: {validator.MAX_FILE_SIZE / (1024*1024):.1f} MB")
        
        return True
        
    except Exception as e:
        print(f"❌ DICOM validator test failed: {e}")
        return False


async def test_retry_logic():
    """Test retry decorators"""
    print("\n" + "="*60)
    print("TEST 5: Retry Logic & Circuit Breaker")
    print("="*60)
    
    try:
        from app.core.retry import CircuitBreaker, RetryConfig
        
        # Test circuit breaker
        cb = CircuitBreaker(failure_threshold=3, recovery_timeout=30)
        assert cb.state == "CLOSED"
        
        print("✅ Circuit breaker initialized")
        print(f"   Initial state: {cb.state}")
        
        # Test retry config
        config = RetryConfig()
        assert config.max_attempts > 0
        
        print("✅ Retry configuration loaded")
        print(f"   Max attempts: {config.max_attempts}")
        
        return True
        
    except Exception as e:
        print(f"❌ Retry logic test failed: {e}")
        return False


async def test_health_checker():
    """Test health checker"""
    print("\n" + "="*60)
    print("TEST 6: Health Checker")
    print("="*60)
    
    try:
        from app.core.health import health_checker, HealthStatus
        
        # Run a quick check
        result = await health_checker.check_database()
        
        print("✅ Health checker initialized")
        print(f"   Database status: {result.status.value}")
        print(f"   Response time: {result.response_time_ms:.2f}ms")
        
        return True
        
    except Exception as e:
        print(f"❌ Health checker test failed: {e}")
        return False


async def test_middleware():
    """Test middleware imports"""
    print("\n" + "="*60)
    print("TEST 7: Middleware Stack")
    print("="*60)
    
    try:
        from app.middleware.timeout import TimeoutMiddleware
        from app.middleware.rate_limit import RateLimitMiddleware
        from app.middleware.security_headers import SecurityHeadersMiddleware
        from app.middleware.error_handler import ErrorHandlerMiddleware
        
        print("✅ All middleware modules imported successfully")
        print("   - TimeoutMiddleware")
        print("   - RateLimitMiddleware (Redis-based)")
        print("   - SecurityHeadersMiddleware")
        print("   - ErrorHandlerMiddleware")
        
        return True
        
    except Exception as e:
        print(f"❌ Middleware test failed: {e}")
        return False


async def test_api_structure():
    """Test API structure"""
    print("\n" + "="*60)
    print("TEST 8: API Versioning & Structure")
    print("="*60)
    
    try:
        from app.api.v1 import api_v1_router
        
        # Check routes are registered
        routes = [r.path for r in api_v1_router.routes]
        
        print("✅ API v1 router initialized")
        print(f"   Total routes: {len(routes)}")
        
        # Check key routes exist
        key_prefixes = ["/auth", "/users", "/patients", "/studies", "/dicom"]
        for prefix in key_prefixes:
            matching = [r for r in routes if prefix in r]
            if matching:
                print(f"   ✅ {prefix} routes registered")
        
        return True
        
    except Exception as e:
        print(f"❌ API structure test failed: {e}")
        return False


async def test_models():
    """Test model soft delete fields"""
    print("\n" + "="*60)
    print("TEST 9: Model Soft Delete Fields")
    print("="*60)
    
    try:
        from app.models.patient import Patient
        from app.models.study import Study
        from app.models.user import User
        
        # Check Patient model
        assert hasattr(Patient, 'deleted_at')
        assert hasattr(Patient, 'created_by_id')
        print("✅ Patient model has soft delete fields")
        
        # Check Study model
        assert hasattr(Study, 'deleted_at')
        assert hasattr(Study, 'created_by_id')
        print("✅ Study model has soft delete fields")
        
        # Check User model
        assert hasattr(User, 'deleted_at')
        assert hasattr(User, 'created_by_id')
        print("✅ User model has soft delete fields")
        
        return True
        
    except Exception as e:
        print(f"❌ Model test failed: {e}")
        return False


async def run_all_tests():
    """Run all verification tests"""
    print("\n" + "="*60)
    print("VASCULAR.AI PLATFORM FIXES VERIFICATION")
    print("="*60)
    print("\nTesting all critical fixes...\n")
    
    tests = [
        ("Configuration", test_config),
        ("Database", test_database),
        ("Redis Cache", test_redis),
        ("DICOM Validator", test_dicom_validator),
        ("Retry Logic", test_retry_logic),
        ("Health Checker", test_health_checker),
        ("Middleware", test_middleware),
        ("API Structure", test_api_structure),
        ("Models", test_models),
    ]
    
    results = []
    for name, test_func in tests:
        try:
            result = await test_func()
            results.append((name, result))
        except Exception as e:
            print(f"\n❌ {name} test crashed: {e}")
            results.append((name, False))
    
    # Summary
    print("\n" + "="*60)
    print("VERIFICATION SUMMARY")
    print("="*60)
    
    passed = sum(1 for _, r in results if r)
    total = len(results)
    
    for name, result in results:
        status = "✅ PASS" if result else "❌ FAIL"
        print(f"{status} - {name}")
    
    print("\n" + "-"*60)
    print(f"Total: {passed}/{total} tests passed")
    
    if passed == total:
        print("\n🎉 All critical fixes verified! Platform is production-ready!")
        return 0
    else:
        print(f"\n⚠️  {total - passed} test(s) failed. Please review the errors above.")
        return 1


if __name__ == "__main__":
    exit_code = asyncio.run(run_all_tests())
    sys.exit(exit_code)
