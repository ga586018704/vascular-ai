"""
Celery Configuration
"""
from celery import Celery
from app.core.config import settings

# Initialize Celery
celery_app = Celery(
    "vascular_ai",
    broker=settings.CELERY_BROKER_URL,
    backend=settings.CELERY_RESULT_BACKEND,
    include=["app.tasks.dicom_tasks", "app.tasks.ai_tasks"]
)

# Celery configuration
celery_app.conf.update(
    task_serializer="json",
    accept_content=["json"],
    result_serializer="json",
    timezone="UTC",
    enable_utc=True,
    task_track_started=True,
    task_time_limit=3600,  # 1 hour
    worker_prefetch_multiplier=1,
)

if __name__ == "__main__":
    celery_app.start()
