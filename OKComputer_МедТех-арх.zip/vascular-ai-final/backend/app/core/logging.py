"""
Logging Configuration
"""
import logging
import sys
from pythonjsonlogger import jsonlogger


def setup_logging():
    """Setup application logging"""
    logHandler = logging.StreamHandler(sys.stdout)
    formatter = jsonlogger.JsonFormatter(
        '%(timestamp)s %(level)s %(name)s %(message)s'
    )
    logHandler.setFormatter(formatter)
    
    root_logger = logging.getLogger()
    root_logger.addHandler(logHandler)
    root_logger.setLevel(logging.INFO)


def get_logger(name: str):
    """Get logger instance"""
    return logging.getLogger(name)
