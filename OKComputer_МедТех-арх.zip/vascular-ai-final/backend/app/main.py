"""
VASCULAR.AI - Main FastAPI Application
"""
from fastapi import FastAPI, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse
from contextlib import asynccontextmanager
import time

from app.core.config import settings
from app.core.logging import setup_logging

# Setup logging
setup_logging()

@asynccontextmanager
async def lifespan(app: FastAPI):
    """Application lifespan handler"""
    print("=" * 60)
    print("Starting VASCULAR.AI Platform v1.0.0")
    print("=" * 60)
    yield
    print("Shutting down VASCULAR.AI...")

# Initialize FastAPI app
app = FastAPI(
    title="VASCULAR.AI API",
    description="""
    AI-Powered Vascular Medicine Platform
    
    ## Features
    - DICOM Processing
    - CT Angiography Analysis
    - AI Vessel Segmentation
    - Pathology Classification (314+)
    - Risk Calculators (VSGNE, Wells, GAS)
    - Laboratory Tests
    - PDF Reports
    """,
    version="1.0.0",
    docs_url="/docs",
    redoc_url="/redoc",
    openapi_url="/openapi.json",
    lifespan=lifespan
)

# CORS middleware
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Request timing middleware
@app.middleware("http")
async def add_process_time_header(request: Request, call_next):
    start_time = time.time()
    response = await call_next(request)
    process_time = time.time() - start_time
    response.headers["X-Process-Time"] = str(process_time)
    return response

# Root endpoint
@app.get("/")
async def root():
    """Root endpoint"""
    return {
        "name": "VASCULAR.AI API",
        "version": "1.0.0",
        "status": "running",
        "features": [
            "DICOM Processing",
            "CT Angiography Analysis",
            "AI Agents (8 types)",
            "Risk Calculators",
            "Laboratory Tests",
            "Pathology Guide (314+)",
            "PDF Reports"
        ]
    }

# Health check
@app.get("/health")
async def health_check():
    """Health check endpoint"""
    return {
        "status": "healthy",
        "service": "VASCULAR.AI API",
        "version": "1.0.0",
        "timestamp": time.time()
    }

# Ready check
@app.get("/ready")
async def ready_check():
    """Readiness probe"""
    return {"status": "ready"}

# Live check
@app.get("/live")
async def live_check():
    """Liveness probe"""
    return {"status": "alive"}

# Import and include routers
from app.api import auth, patients, lab_tests, risk_calculators

app.include_router(auth.router, prefix="/api/auth", tags=["Authentication"])
app.include_router(patients.router, prefix="/api/patients", tags=["Patients"])
app.include_router(lab_tests.router, prefix="/api/lab-tests", tags=["Laboratory Tests"])
app.include_router(risk_calculators.router, prefix="/api/calculators", tags=["Risk Calculators"])

if __name__ == "__main__":
    import uvicorn
    uvicorn.run("app.main:app", host="0.0.0.0", port=8000, reload=True)
