"""
AI Analysis Tasks
"""
from app.core.celery_app import celery_app


@celery_app.task
def analyze_pathology(image_id: int, pathology_type: str):
    """Analyze pathology with AI"""
    return {"status": "completed", "image_id": image_id, "pathology": pathology_type}


@celery_app.task
def generate_report(patient_id: int, study_id: int):
    """Generate PDF report"""
    return {"status": "completed", "patient_id": patient_id, "study_id": study_id}
