"""
DICOM Processing Tasks
"""
from app.core.celery_app import celery_app


@celery_app.task
def process_dicom_file(file_path: str):
    """Process uploaded DICOM file"""
    return {"status": "completed", "file": file_path}


@celery_app.task
def analyze_angiography(study_id: int):
    """Analyze CT angiography"""
    return {"status": "completed", "study_id": study_id}
