"""
Patients API Endpoints
"""
from fastapi import APIRouter, Query
from typing import List, Optional
from pydantic import BaseModel
from datetime import datetime

router = APIRouter()


class PatientResponse(BaseModel):
    id: int
    first_name: str
    last_name: str
    date_of_birth: Optional[str]
    medical_record_number: Optional[str]
    created_at: datetime


class PatientListResponse(BaseModel):
    items: List[PatientResponse]
    total: int


@router.get("", response_model=PatientListResponse)
async def list_patients(
    page: int = Query(1, ge=1),
    page_size: int = Query(20, ge=1, le=100),
    search: Optional[str] = Query(None)
):
    """List all patients with pagination"""
    # Demo data
    return {
        "items": [
            {
                "id": 1,
                "first_name": "Иван",
                "last_name": "Петров",
                "date_of_birth": "1975-03-15",
                "medical_record_number": "MRN001",
                "created_at": datetime.now()
            },
            {
                "id": 2,
                "first_name": "Мария",
                "last_name": "Иванова",
                "date_of_birth": "1980-07-22",
                "medical_record_number": "MRN002",
                "created_at": datetime.now()
            }
        ],
        "total": 2
    }


@router.get("/{patient_id}")
async def get_patient(patient_id: int):
    """Get patient by ID"""
    return {
        "id": patient_id,
        "first_name": "Иван",
        "last_name": "Петров",
        "date_of_birth": "1975-03-15",
        "medical_record_number": f"MRN{patient_id:03d}",
        "diagnoses": ["Атеросклероз БЦА", "Стеноз ПСА 70%"],
        "created_at": datetime.now()
    }


@router.post("")
async def create_patient():
    """Create new patient"""
    return {"message": "Patient created", "id": 3}


@router.put("/{patient_id}")
async def update_patient(patient_id: int):
    """Update patient"""
    return {"message": "Patient updated", "id": patient_id}


@router.delete("/{patient_id}")
async def delete_patient(patient_id: int):
    """Delete patient"""
    return {"message": "Patient deleted", "id": patient_id}
