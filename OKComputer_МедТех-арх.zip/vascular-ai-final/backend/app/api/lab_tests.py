"""
Laboratory Tests API Endpoints
"""
from fastapi import APIRouter, Query
from typing import List, Optional
from pydantic import BaseModel
from datetime import datetime

router = APIRouter()


class LabTestReference(BaseModel):
    id: int
    test_code: str
    test_name: str
    test_name_ru: Optional[str]
    category: str
    ref_min: Optional[float]
    ref_max: Optional[float]
    ref_unit: str


class LabResult(BaseModel):
    id: int
    test: LabTestReference
    value: float
    unit: str
    status: str
    tested_at: datetime


@router.get("/references")
async def list_lab_references(
    category: Optional[str] = Query(None),
    search: Optional[str] = Query(None)
):
    """List all lab test references"""
    return {
        "items": [
            {
                "id": 1,
                "test_code": "INR",
                "test_name": "International Normalized Ratio",
                "test_name_ru": "МНО",
                "category": "coagulation",
                "ref_min": 0.85,
                "ref_max": 1.15,
                "ref_unit": "ratio"
            },
            {
                "id": 2,
                "test_code": "PT",
                "test_name": "Prothrombin Time",
                "test_name_ru": "Протромбиновое время",
                "category": "coagulation",
                "ref_min": 11.0,
                "ref_max": 16.0,
                "ref_unit": "seconds"
            },
            {
                "id": 3,
                "test_code": "HGB",
                "test_name": "Hemoglobin",
                "test_name_ru": "Гемоглобин",
                "category": "cbc",
                "ref_min": 120.0,
                "ref_max": 160.0,
                "ref_unit": "g/L"
            }
        ],
        "total": 3
    }


@router.get("/results")
async def list_patient_results(
    patient_id: int = Query(...),
    category: Optional[str] = Query(None)
):
    """List patient lab results"""
    return {
        "items": [
            {
                "id": 1,
                "test": {
                    "id": 1,
                    "test_code": "INR",
                    "test_name": "INR",
                    "test_name_ru": "МНО",
                    "category": "coagulation",
                    "ref_min": 0.85,
                    "ref_max": 1.15,
                    "ref_unit": "ratio"
                },
                "value": 1.2,
                "unit": "ratio",
                "status": "normal",
                "tested_at": datetime.now()
            }
        ],
        "total": 1
    }


@router.post("/results")
async def create_lab_result():
    """Add lab result"""
    return {"message": "Lab result added", "id": 1}


@router.get("/panels/preoperative")
async def get_preoperative_panel():
    """Get preoperative lab panel"""
    return {
        "name": "Preoperative Vascular Surgery Panel",
        "name_ru": "Предоперационный скрининг",
        "tests": ["CBC", "INR", "PT", "APTT", "CREATININE", "GLUCOSE"]
    }
