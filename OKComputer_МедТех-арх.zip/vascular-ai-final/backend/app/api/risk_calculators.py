"""
Risk Calculators API Endpoints
"""
from fastapi import APIRouter
from pydantic import BaseModel
from typing import Dict, Any

router = APIRouter()


class VSGNERequest(BaseModel):
    age: int
    gender: str
    bmi: float
    diabetes: bool
    hypertension: bool
    cardiac_history: bool


class WellsRequest(BaseModel):
    active_cancer: bool
    bedridden_recently: bool
    calf_swelling: bool
    collateral_veins: bool
    entire_leg_swollen: bool
    localized_tenderness: bool
    pitting_edema: bool
    paralysis_paresis: bool
    previous_dvt: bool
    alternative_diagnosis_less_likely: bool


@router.post("/vsgne")
async def calculate_vsgne(data: VSGNERequest):
    """Calculate VSGNE surgical risk score"""
    score = 0
    risk_factors = []
    
    if data.age > 70:
        score += 2
        risk_factors.append("Возраст > 70")
    
    if data.diabetes:
        score += 2
        risk_factors.append("Сахарный диабет")
    
    if data.hypertension:
        score += 1
        risk_factors.append("Артериальная гипертензия")
    
    if data.cardiac_history:
        score += 3
        risk_factors.append("Сердечно-сосудистые заболевания")
    
    # Risk level
    if score <= 2:
        risk_level = "Низкий"
        mortality = "< 1%"
    elif score <= 5:
        risk_level = "Средний"
        mortality = "1-5%"
    else:
        risk_level = "Высокий"
        mortality = "> 5%"
    
    return {
        "score": score,
        "risk_level": risk_level,
        "estimated_mortality": mortality,
        "risk_factors": risk_factors,
        "recommendations": [
            "Кардиологическая консультация" if data.cardiac_history else None,
            "Оптимизация глюкозы" if data.diabetes else None
        ]
    }


@router.post("/wells")
async def calculate_wells(data: WellsRequest):
    """Calculate Wells score for DVT"""
    score = 0
    
    if data.active_cancer:
        score += 1
    if data.bedridden_recently:
        score += 1
    if data.calf_swelling:
        score += 1
    if data.collateral_veins:
        score += 1
    if data.entire_leg_swollen:
        score += 1
    if data.localized_tenderness:
        score += 1
    if data.pitting_edema:
        score += 1
    if data.paralysis_paresis:
        score += 1
    if data.previous_dvt:
        score += 1
    if data.alternative_diagnosis_less_likely:
        score -= 2
    
    # Interpretation
    if score <= 0:
        probability = "Низкая вероятность"
        recommendation = "D-dimer тест"
    elif score <= 2:
        probability = "Умеренная вероятность"
        recommendation = "УЗИ вен"
    else:
        probability = "Высокая вероятность"
        recommendation = "УЗИ вен + антикоагулянты"
    
    return {
        "score": score,
        "probability": probability,
        "recommendation": recommendation
    }


@router.get("")
async def list_calculators():
    """List available risk calculators"""
    return {
        "calculators": [
            {
                "id": "vsgne",
                "name": "VSGNE Score",
                "description": "Surgical risk assessment for vascular surgery",
                "description_ru": "Оценка хирургического риска"
            },
            {
                "id": "wells",
                "name": "Wells Score",
                "description": "DVT probability assessment",
                "description_ru": "Оценка вероятности ВТЭ"
            },
            {
                "id": "gas",
                "name": "GAS Score",
                "description": "Gangrene severity assessment",
                "description_ru": "Оценка тяжести гангрены"
            }
        ]
    }
