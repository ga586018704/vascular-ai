"""
Authentication API Endpoints
"""
from fastapi import APIRouter, HTTPException, status
from pydantic import BaseModel

router = APIRouter()


class LoginRequest(BaseModel):
    username: str
    password: str


class TokenResponse(BaseModel):
    access_token: str
    token_type: str = "bearer"


@router.post("/login", response_model=TokenResponse)
async def login(credentials: LoginRequest):
    """User login"""
    # Demo login - replace with real auth
    if credentials.username == "admin" and credentials.password == "admin":
        return {"access_token": "demo_token", "token_type": "bearer"}
    raise HTTPException(
        status_code=status.HTTP_401_UNAUTHORIZED,
        detail="Invalid credentials"
    )


@router.post("/register")
async def register():
    """User registration"""
    return {"message": "Registration endpoint"}


@router.get("/me")
async def get_current_user():
    """Get current user info"""
    return {
        "id": 1,
        "username": "admin",
        "email": "admin@vascular.ai",
        "role": "admin"
    }
