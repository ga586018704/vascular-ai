import { useState, useEffect } from 'react'
import { 
  Box, 
  Typography, 
  Container, 
  AppBar, 
  Toolbar, 
  Button,
  Card,
  CardContent,
  Grid,
  Chip
} from '@mui/material'
import { 
  MedicalServices as MedicalIcon,
  Science as ScienceIcon,
  Assessment as AssessmentIcon,
  Biotech as BiotechIcon
} from '@mui/icons-material'

function App() {
  const [health, setHealth] = useState<any>(null)

  useEffect(() => {
    fetch('/health')
      .then(res => res.json())
      .then(data => setHealth(data))
      .catch(err => console.error(err))
  }, [])

  const features = [
    {
      icon: <ScienceIcon sx={{ fontSize: 40 }} />,
      title: 'DICOM Processing',
      description: 'Upload and analyze CT/MR angiography'
    },
    {
      icon: <BiotechIcon sx={{ fontSize: 40 }} />,
      title: 'AI Analysis',
      description: '8 AI agents for vascular pathologies'
    },
    {
      icon: <AssessmentIcon sx={{ fontSize: 40 }} />,
      title: 'Risk Calculators',
      description: 'VSGNE, Wells, GAS scores'
    },
    {
      icon: <MedicalIcon sx={{ fontSize: 40 }} />,
      title: 'Lab Tests',
      description: '40+ laboratory parameters'
    }
  ]

  return (
    <Box>
      <AppBar position="static">
        <Toolbar>
          <MedicalIcon sx={{ mr: 2 }} />
          <Typography variant="h6" component="div" sx={{ flexGrow: 1 }}>
            VASCULAR.AI
          </Typography>
          <Button color="inherit">Login</Button>
        </Toolbar>
      </AppBar>

      <Container maxWidth="lg" sx={{ mt: 4 }}>
        {/* Hero Section */}
        <Box sx={{ textAlign: 'center', py: 8 }}>
          <MedicalIcon sx={{ fontSize: 80, color: 'primary.main', mb: 2 }} />
          <Typography variant="h2" component="h1" gutterBottom>
            VASCULAR.AI
          </Typography>
          <Typography variant="h5" color="text.secondary" paragraph>
            AI-Powered Vascular Medicine Platform
          </Typography>
          {health && (
            <Chip 
              label={`API Status: ${health.status}`} 
              color="success" 
              sx={{ mt: 2 }}
            />
          )}
        </Box>

        {/* Features Grid */}
        <Grid container spacing={3} sx={{ mt: 4 }}>
          {features.map((feature, index) => (
            <Grid item xs={12} sm={6} md={3} key={index}>
              <Card sx={{ height: '100%', textAlign: 'center', p: 2 }}>
                <CardContent>
                  <Box sx={{ color: 'primary.main', mb: 2 }}>
                    {feature.icon}
                  </Box>
                  <Typography variant="h6" gutterBottom>
                    {feature.title}
                  </Typography>
                  <Typography variant="body2" color="text.secondary">
                    {feature.description}
                  </Typography>
                </CardContent>
              </Card>
            </Grid>
          ))}
        </Grid>

        {/* Footer */}
        <Box sx={{ textAlign: 'center', py: 4, mt: 4 }}>
          <Typography variant="body2" color="text.secondary">
            © 2024 VASCULAR.AI - All rights reserved
          </Typography>
        </Box>
      </Container>
    </Box>
  )
}

export default App
