# VASCULAR.AI - Deployment Guide

## 🚀 Быстрый запуск

### 1. Очисти сервер (если нужно)
```bash
docker stop $(docker ps -aq) 2>/dev/null
docker rm $(docker ps -aq) 2>/dev/null
docker system prune -af
rm -rf /opt/vascular-ai
```

### 2. Скачай и распакуй архив
```bash
cd /opt
curl -L -o vascular-ai.zip "ВАША_ССЫЛКА"
unzip vascular-ai.zip
cd vascular-ai
```

### 3. Запусти
```bash
chmod +x scripts/start.sh
./scripts/start.sh
```

Или вручную:
```bash
# Создай .env
cp .env.example .env
nano .env  # Добавь API ключи

# Запусти
docker compose up -d --build
```

### 4. Проверь
- Website: http://YOUR_IP
- API Docs: http://YOUR_IP/docs
- Health: http://YOUR_IP/health

## 📋 Команды

```bash
# Статус
docker compose ps

# Логи
docker compose logs -f

# Перезапуск
docker compose restart

# Остановка
docker compose down
```

## 💰 Стоимость
- Сервер Hetzner CX21: €6.21/мес
- Домен (опционально): ~$10/год
