#!/bin/bash
# VASCULAR.AI - Start Script

echo "=================================="
echo "  Starting VASCULAR.AI Platform"
echo "=================================="

# Check if running as root
if [ "$EUID" -ne 0 ]; then 
    echo "Please run as root"
    exit 1
fi

# Check Docker
if ! command -v docker &> /dev/null; then
    echo "Installing Docker..."
    curl -fsSL https://get.docker.com | sh
    systemctl start docker
    systemctl enable docker
fi

# Create .env if not exists
if [ ! -f .env ]; then
    echo "Creating .env file..."
    cat > .env << EOF
POSTGRES_DB=vascular_ai
POSTGRES_USER=vascular
POSTGRES_PASSWORD=$(openssl rand -base64 12)
SECRET_KEY=$(openssl rand -hex 32)
OPENAI_API_KEY=
ANTHROPIC_API_KEY=
EOF
    echo ".env created! Please edit and add your API keys."
fi

# Start services
echo "Starting services..."
docker compose up -d --build

echo ""
echo "=================================="
echo "  VASCULAR.AI is starting up!"
echo "=================================="
echo ""
echo "Access your platform:"
echo "  Website: http://$(curl -s ifconfig.me 2>/dev/null || echo 'localhost')"
echo "  API Docs: http://$(curl -s ifconfig.me 2>/dev/null || echo 'localhost')/docs"
echo "  Health: http://$(curl -s ifconfig.me 2>/dev/null || echo 'localhost')/health"
echo ""
echo "To view logs: docker compose logs -f"
echo ""
