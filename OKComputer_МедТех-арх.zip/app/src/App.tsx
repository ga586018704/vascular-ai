import { useState, useCallback } from 'react';
import { 
  Activity, 
  Brain, 
  FileText, 
  Settings, 
  User, 
  LogOut, 
  FolderOpen,
  ChevronRight,
  Menu,
  Bell,
  HelpCircle,
  Stethoscope,
  Scan,
  BarChart3,
  Calendar,
  Printer,
  Download,
  Share2,
  Maximize2,
  RotateCcw,
  Save,
  LayoutGrid,
  FlaskConical,
  Droplets,
  AlertTriangle
} from 'lucide-react';
import { cn } from '@/lib/utils';
import { Volume3DViewer } from '@/components/viewer/Volume3DViewer';
import { AIDiagnosisPanel } from '@/components/diagnosis/AIDiagnosisPanel';
import { LaboratoryPanel } from '@/components/laboratory/LabPanel';
import { LabUpload } from '@/components/laboratory/LabUpload';
import type { 
  DicomStudy, 
  AIDiagnosis, 
  AIFinding, 
  TreatmentRecommendation, 
  Volume3D,
  Patient
} from '@/types';
import type { 
  LabPanel as LabPanelType, 
  LabAIDiagnosis as LabAIDiag,
  ClinicalAlert 
} from '@/types/laboratory';

// Mock Patient Data
const mockPatient: Patient = {
  id: 'P-2024-001',
  mrn: '12345678',
  firstName: 'Alexander',
  lastName: 'Petrov',
  dateOfBirth: new Date('1965-03-15'),
  sex: 'M',
  age: 59,
  bmi: 27.5,
  allergies: ['Penicillin', 'Iodine'],
  medications: ['Aspirin 100mg', 'Atorvastatin 20mg', 'Metformin 500mg'],
  comorbidities: ['Type 2 Diabetes', 'Hypertension', 'Hyperlipidemia'],
  previousSurgeries: [
    { procedure: 'CABG x3', date: new Date('2019-06-10'), outcome: 'Uneventful' }
  ],
  vitals: {
    timestamp: new Date(),
    bloodPressure: { systolic: 145, diastolic: 88 },
    heartRate: 78,
    respiratoryRate: 16,
    temperature: 36.6,
    oxygenSaturation: 97,
    weight: 85,
    height: 175
  },
  labResults: [
    { test: 'Creatinine', value: 1.2, unit: 'mg/dL', referenceRange: '0.7-1.3', abnormal: false, timestamp: new Date() },
    { test: 'eGFR', value: 68, unit: 'mL/min', referenceRange: '>60', abnormal: false, timestamp: new Date() },
    { test: 'HbA1c', value: 7.2, unit: '%', referenceRange: '<7.0', abnormal: true, timestamp: new Date() },
    { test: 'LDL', value: 98, unit: 'mg/dL', referenceRange: '<100', abnormal: false, timestamp: new Date() }
  ],
  imaging: [],
  riskFactors: ['Smoking (20 pack-years)', 'Family history of CAD', 'Sedentary lifestyle']
};

// Mock Lab Panels with Comprehensive Hematology Data
const mockLabPanels: LabPanelType[] = [
  {
    id: 'LP-001',
    name: 'Complete Blood Count (CBC)',
    nameRu: 'Общий анализ крови',
    category: 'hematology',
    collectedAt: new Date('2024-06-15T08:00:00'),
    receivedAt: new Date('2024-06-15T08:30:00'),
    reportedAt: new Date('2024-06-15T10:15:00'),
    labName: 'Central Laboratory',
    physician: 'Dr. Ivanova',
    status: 'complete',
    tests: [
      {
        id: 'T-WBC',
        code: 'WBC',
        name: 'White Blood Cells',
        nameRu: 'Лейкоциты',
        category: 'hematology',
        value: 12.5,
        unit: '×10⁹/L',
        referenceRange: { min: 4.0, max: 10.0 },
        status: 'high',
        previousValue: 8.2,
        changePercent: 52.4,
        timestamp: new Date('2024-06-15T10:15:00'),
        method: 'Automated counting',
        labName: 'Central Laboratory',
        isUrgent: false,
        notes: 'Elevated, suggestive of infection/inflammation'
      },
      {
        id: 'T-RBC',
        code: 'RBC',
        name: 'Red Blood Cells',
        nameRu: 'Эритроциты',
        category: 'hematology',
        value: 3.8,
        unit: '×10¹²/L',
        referenceRange: { min: 4.5, max: 5.5 },
        status: 'low',
        previousValue: 4.2,
        changePercent: -9.5,
        timestamp: new Date('2024-06-15T10:15:00'),
        method: 'Automated counting',
        labName: 'Central Laboratory',
        isUrgent: false
      },
      {
        id: 'T-HGB',
        code: 'HGB',
        name: 'Hemoglobin',
        nameRu: 'Гемоглобин',
        category: 'hematology',
        value: 9.8,
        unit: 'g/dL',
        referenceRange: { min: 13.5, max: 17.5 },
        status: 'critical_low',
        previousValue: 12.5,
        changePercent: -21.6,
        timestamp: new Date('2024-06-15T10:15:00'),
        method: 'Cyanmethemoglobin',
        labName: 'Central Laboratory',
        isUrgent: true,
        notes: 'CRITICAL: Severe anemia, transfusion may be indicated'
      },
      {
        id: 'T-HCT',
        code: 'HCT',
        name: 'Hematocrit',
        nameRu: 'Гематокрит',
        category: 'hematology',
        value: 29.5,
        unit: '%',
        referenceRange: { min: 41, max: 50 },
        status: 'critical_low',
        previousValue: 38.2,
        changePercent: -22.8,
        timestamp: new Date('2024-06-15T10:15:00'),
        method: 'Calculated',
        labName: 'Central Laboratory',
        isUrgent: true
      },
      {
        id: 'T-PLT',
        code: 'PLT',
        name: 'Platelets',
        nameRu: 'Тромбоциты',
        category: 'hematology',
        value: 485,
        unit: '×10⁹/L',
        referenceRange: { min: 150, max: 400 },
        status: 'high',
        previousValue: 320,
        changePercent: 51.6,
        timestamp: new Date('2024-06-15T10:15:00'),
        method: 'Automated counting',
        labName: 'Central Laboratory',
        isUrgent: false,
        notes: 'Reactive thrombocytosis likely'
      },
      {
        id: 'T-MCV',
        code: 'MCV',
        name: 'Mean Corpuscular Volume',
        nameRu: 'Средний объем эритроцита',
        category: 'hematology',
        value: 78.2,
        unit: 'fL',
        referenceRange: { min: 80, max: 100 },
        status: 'low',
        timestamp: new Date('2024-06-15T10:15:00'),
        method: 'Calculated',
        labName: 'Central Laboratory',
        isUrgent: false,
        notes: 'Microcytic anemia pattern'
      },
      {
        id: 'T-MCH',
        code: 'MCH',
        name: 'Mean Corpuscular Hemoglobin',
        nameRu: 'Среднее содержание Hb в эритроците',
        category: 'hematology',
        value: 25.8,
        unit: 'pg',
        referenceRange: { min: 27, max: 33 },
        status: 'low',
        timestamp: new Date('2024-06-15T10:15:00'),
        method: 'Calculated',
        labName: 'Central Laboratory',
        isUrgent: false
      },
      {
        id: 'T-NEU',
        code: 'NEU%',
        name: 'Neutrophils',
        nameRu: 'Нейтрофилы',
        category: 'hematology',
        value: 78,
        unit: '%',
        referenceRange: { min: 40, max: 70 },
        status: 'high',
        timestamp: new Date('2024-06-15T10:15:00'),
        method: 'Automated differential',
        labName: 'Central Laboratory',
        isUrgent: false,
        notes: 'Left shift may indicate bacterial infection'
      },
      {
        id: 'T-LYM',
        code: 'LYM%',
        name: 'Lymphocytes',
        nameRu: 'Лимфоциты',
        category: 'hematology',
        value: 15,
        unit: '%',
        referenceRange: { min: 20, max: 40 },
        status: 'low',
        timestamp: new Date('2024-06-15T10:15:00'),
        method: 'Automated differential',
        labName: 'Central Laboratory',
        isUrgent: false
      }
    ]
  },
  {
    id: 'LP-002',
    name: 'Coagulation Panel',
    nameRu: 'Коагулограмма',
    category: 'coagulation',
    collectedAt: new Date('2024-06-15T08:05:00'),
    receivedAt: new Date('2024-06-15T08:35:00'),
    reportedAt: new Date('2024-06-15T10:30:00'),
    labName: 'Coagulation Lab',
    physician: 'Dr. Ivanova',
    status: 'complete',
    tests: [
      {
        id: 'T-PT',
        code: 'PT',
        name: 'Prothrombin Time',
        nameRu: 'Протромбиновое время',
        category: 'coagulation',
        value: 14.2,
        unit: 'sec',
        referenceRange: { min: 11, max: 13.5 },
        status: 'high',
        timestamp: new Date('2024-06-15T10:30:00'),
        method: 'Optical clot detection',
        labName: 'Coagulation Lab',
        isUrgent: false
      },
      {
        id: 'T-INR',
        code: 'INR',
        name: 'International Normalized Ratio',
        nameRu: 'МНО',
        category: 'coagulation',
        value: 1.3,
        unit: '',
        referenceRange: { min: 0.9, max: 1.1 },
        status: 'high',
        timestamp: new Date('2024-06-15T10:30:00'),
        method: 'Calculated',
        labName: 'Coagulation Lab',
        isUrgent: false,
        notes: 'Slightly elevated, monitor if on anticoagulation'
      },
      {
        id: 'T-APTT',
        code: 'APTT',
        name: 'Activated Partial Thromboplastin Time',
        nameRu: 'АЧТВ',
        category: 'coagulation',
        value: 38.5,
        unit: 'sec',
        referenceRange: { min: 25, max: 35 },
        status: 'high',
        timestamp: new Date('2024-06-15T10:30:00'),
        method: 'Optical clot detection',
        labName: 'Coagulation Lab',
        isUrgent: false
      },
      {
        id: 'T-FIB',
        code: 'FIB',
        name: 'Fibrinogen',
        nameRu: 'Фибриноген',
        category: 'coagulation',
        value: 4.8,
        unit: 'g/L',
        referenceRange: { min: 2.0, max: 4.0 },
        status: 'high',
        timestamp: new Date('2024-06-15T10:30:00'),
        method: 'Clauss method',
        labName: 'Coagulation Lab',
        isUrgent: false,
        notes: 'Acute phase reactant - elevated in inflammation'
      },
      {
        id: 'T-DDI',
        code: 'D-Dimer',
        name: 'D-Dimer',
        nameRu: 'D-Димер',
        category: 'coagulation',
        value: 1250,
        unit: 'ng/mL',
        referenceRange: { max: 500 },
        status: 'critical_high',
        timestamp: new Date('2024-06-15T10:30:00'),
        method: 'Immunoturbidimetric',
        labName: 'Coagulation Lab',
        isUrgent: true,
        notes: 'CRITICAL: Highly elevated, consider thromboembolic event'
      }
    ]
  },
  {
    id: 'LP-003',
    name: 'Iron Studies',
    nameRu: 'Исследование железа',
    category: 'biochemistry',
    collectedAt: new Date('2024-06-15T08:10:00'),
    receivedAt: new Date('2024-06-15T08:40:00'),
    reportedAt: new Date('2024-06-15T11:00:00'),
    labName: 'Chemistry Lab',
    physician: 'Dr. Ivanova',
    status: 'complete',
    tests: [
      {
        id: 'T-FE',
        code: 'FE',
        name: 'Serum Iron',
        nameRu: 'Сывороточное железо',
        category: 'biochemistry',
        value: 35,
        unit: 'μg/dL',
        referenceRange: { min: 60, max: 170 },
        status: 'critical_low',
        timestamp: new Date('2024-06-15T11:00:00'),
        method: 'Colorimetric',
        labName: 'Chemistry Lab',
        isUrgent: false,
        notes: 'Consistent with iron deficiency anemia'
      },
      {
        id: 'T-FERR',
        code: 'FERR',
        name: 'Ferritin',
        nameRu: 'Ферритин',
        category: 'biochemistry',
        value: 8,
        unit: 'ng/mL',
        referenceRange: { min: 30, max: 400 },
        status: 'critical_low',
        timestamp: new Date('2024-06-15T11:00:00'),
        method: 'Chemiluminescence',
        labName: 'Chemistry Lab',
        isUrgent: false,
        notes: 'Depleted iron stores - diagnostic of iron deficiency'
      },
      {
        id: 'T-TIBC',
        code: 'TIBC',
        name: 'Total Iron Binding Capacity',
        nameRu: 'Общая железосвязывающая способность',
        category: 'biochemistry',
        value: 480,
        unit: 'μg/dL',
        referenceRange: { min: 250, max: 400 },
        status: 'high',
        timestamp: new Date('2024-06-15T11:00:00'),
        method: 'Calculated',
        labName: 'Chemistry Lab',
        isUrgent: false,
        notes: 'Elevated in iron deficiency'
      },
      {
        id: 'T-TRANS',
        code: 'TSAT',
        name: 'Transferrin Saturation',
        nameRu: 'Насыщение трансферрина',
        category: 'biochemistry',
        value: 7,
        unit: '%',
        referenceRange: { min: 20, max: 50 },
        status: 'critical_low',
        timestamp: new Date('2024-06-15T11:00:00'),
        method: 'Calculated',
        labName: 'Chemistry Lab',
        isUrgent: false,
        notes: 'Severely reduced iron availability'
      }
    ]
  },
  {
    id: 'LP-004',
    name: 'Rare Disease Screen',
    nameRu: 'Скрининг редких заболеваний',
    category: 'rare_diseases',
    collectedAt: new Date('2024-06-15T08:15:00'),
    receivedAt: new Date('2024-06-15T08:45:00'),
    reportedAt: new Date('2024-06-15T14:00:00'),
    labName: 'Molecular Diagnostics',
    physician: 'Dr. Ivanova',
    status: 'complete',
    tests: [
      {
        id: 'T-HBE',
        code: 'HbElec',
        name: 'Hemoglobin Electrophoresis',
        nameRu: 'Электрофорез гемоглобина',
        category: 'rare_diseases',
        value: 'HbA 96.5%, HbA2 2.8%, HbF 0.7%',
        unit: '',
        referenceRange: { text: 'HbA >95%, HbA2 <3.5%' },
        status: 'normal',
        timestamp: new Date('2024-06-15T14:00:00'),
        method: 'Capillary electrophoresis',
        labName: 'Molecular Diagnostics',
        isUrgent: false,
        notes: 'No hemoglobinopathy detected'
      },
      {
        id: 'T-G6PD',
        code: 'G6PD',
        name: 'G6PD Activity',
        nameRu: 'Активность Г6ФД',
        category: 'rare_diseases',
        value: 8.5,
        unit: 'U/g Hb',
        referenceRange: { min: 4.6, max: 13.5 },
        status: 'normal',
        timestamp: new Date('2024-06-15T14:00:00'),
        method: 'Spectrophotometric',
        labName: 'Molecular Diagnostics',
        isUrgent: false,
        notes: 'Normal enzyme activity'
      },
      {
        id: 'T-HAPT',
        code: 'HAPTO',
        name: 'Haptoglobin',
        nameRu: 'Гаптоглобин',
        category: 'rare_diseases',
        value: 15,
        unit: 'mg/dL',
        referenceRange: { min: 30, max: 200 },
        status: 'critical_low',
        timestamp: new Date('2024-06-15T14:00:00'),
        method: 'Immunoturbidimetric',
        labName: 'Molecular Diagnostics',
        isUrgent: false,
        notes: 'Low haptoglobin suggests hemolysis - correlate with LDH and reticulocytes'
      }
    ]
  }
];

// Mock AI Lab Diagnosis
const mockLabAIDiagnosis: LabAIDiag = {
  id: 'AI-LAB-001',
  panelId: 'LP-001',
  timestamp: new Date(),
  primaryDiagnosis: {
    condition: 'Iron Deficiency Anemia with Inflammatory Component',
    icd10: 'D50.9',
    confidence: 0.94,
    explanation: 'Severe microcytic hypochromic anemia (Hb 9.8 g/dL, MCV 78.2 fL) with depleted iron stores (ferritin 8 ng/mL, TSAT 7%) and elevated inflammatory markers. The pattern is consistent with iron deficiency anemia likely exacerbated by chronic inflammation (anemia of chronic disease).'
  },
  differentialDiagnoses: [
    {
      condition: 'Anemia of Chronic Disease',
      icd10: 'D63.8',
      confidence: 0.78,
      keyFindings: ['Elevated ferritin relative to iron', 'High Fibrinogen', 'Elevated D-Dimer'],
      supportingTests: ['CRP elevation', 'Elevated ESR'],
      excludingTests: ['Low ferritin argues against pure ACD']
    },
    {
      condition: 'Thalassemia Trait',
      icd10: 'D56.3',
      confidence: 0.23,
      keyFindings: ['Microcytosis', 'Low MCH'],
      supportingTests: ['Normal Hb electrophoresis'],
      excludingTests: ['HbA2 normal', 'Severe iron deficiency present']
    }
  ],
  recognizedPatterns: [
    {
      pattern: 'Iron Deficiency Pattern',
      description: 'Low Fe, low ferritin, high TIBC, low TSAT - classic for iron deficiency',
      severity: 'severe',
      urgency: 'urgent'
    },
    {
      pattern: 'Hypercoagulable State',
      description: 'Markedly elevated D-Dimer (1250 ng/mL) with elevated fibrinogen suggests active thrombosis risk',
      severity: 'critical',
      urgency: 'emergency'
    },
    {
      pattern: 'Inflammatory Response',
      description: 'Leukocytosis (12.5×10⁹/L) with neutrophilia suggests active infection/inflammation',
      severity: 'moderate',
      urgency: 'urgent'
    }
  ],
  criticalAlerts: [
    {
      parameter: 'Hemoglobin',
      value: 9.8,
      threshold: '< 10 g/dL',
      action: 'Consider blood transfusion if symptomatic or Hb < 8 g/dL',
      timestamp: new Date()
    },
    {
      parameter: 'D-Dimer',
      value: 1250,
      threshold: '> 500 ng/mL',
      action: 'Rule out DVT/PE; consider imaging studies',
      timestamp: new Date()
    }
  ],
  recommendations: [
    {
      category: 'immediate',
      action: 'Initiate IV iron supplementation (Ferric carboxymaltose 1000mg × 2 doses)',
      rationale: 'Severe iron deficiency with depleted stores requires rapid repletion',
      priority: 1
    },
    {
      category: 'immediate',
      action: 'Evaluate for source of blood loss (GI evaluation recommended)',
      rationale: 'Iron deficiency in adult male suggests occult blood loss',
      priority: 2
    },
    {
      category: 'short_term',
      action: 'Repeat CBC in 4 weeks to assess response',
      rationale: 'Monitor hematologic recovery after iron therapy',
      priority: 3
    },
    {
      category: 'short_term',
      action: 'Consider thromboprophylaxis given elevated D-Dimer and immobility risk',
      rationale: 'High D-Dimer indicates increased thrombotic risk',
      priority: 4
    }
  ],
  suggestedTests: [
    {
      test: 'Reticulocyte Count',
      category: 'hematology',
      urgency: 'urgent',
      rationale: 'Assess bone marrow response to anemia'
    },
    {
      test: 'CRP & ESR',
      category: 'biochemistry',
      urgency: 'urgent',
      rationale: 'Quantify inflammatory component'
    },
    {
      test: 'Fecal Occult Blood',
      category: 'biochemistry',
      urgency: 'routine',
      rationale: 'Screen for GI bleeding source'
    },
    {
      test: 'LDH, Bilirubin, Haptoglobin',
      category: 'biochemistry',
      urgency: 'urgent',
      rationale: 'Rule out hemolytic component'
    }
  ],
  transfusionRecommendations: [
    {
      indicated: true,
      product: 'Packed Red Blood Cells',
      units: 2,
      urgency: 'urgent',
      specialRequirements: ['Leukoreduced', 'CMV-negative if indicated'],
      contraindications: ['Volume overload risk - monitor closely']
    }
  ],
  trendAnalysis: [
    {
      parameter: 'Hemoglobin',
      trend: 'worsening',
      prediction: 'If untreated, may drop below 8 g/dL within 2-4 weeks',
      daysToCritical: 14
    }
  ]
};

// Mock Clinical Alerts
const mockAlerts: ClinicalAlert[] = [
  {
    id: 'ALT-001',
    timestamp: new Date(),
    severity: 'critical',
    category: 'critical_value',
    title: 'Critical Hemoglobin Value',
    message: 'Hemoglobin 9.8 g/dL (Reference: 13.5-17.5). Severe anemia requiring urgent evaluation.',
    relatedTests: ['HGB', 'HCT', 'RBC', 'MCV', 'MCH'],
    actions: [
      { description: 'Notify attending physician immediately', priority: 'immediate' },
      { description: 'Consider blood transfusion', priority: 'urgent' },
      { description: 'Evaluate for active bleeding', priority: 'urgent' }
    ]
  },
  {
    id: 'ALT-002',
    timestamp: new Date(),
    severity: 'life_threatening',
    category: 'critical_value',
    title: 'Elevated D-Dimer - Thrombosis Risk',
    message: 'D-Dimer 1250 ng/mL (Reference: <500). Highly elevated - consider PE/DVT workup.',
    relatedTests: ['D-Dimer', 'Fibrinogen', 'PT', 'APTT'],
    actions: [
      { description: 'Immediate CT-PA or bilateral lower extremity Doppler', priority: 'immediate' },
      { description: 'Initiate empiric anticoagulation if no contraindications', priority: 'immediate' }
    ]
  }
];

// Rest of imports and data...
const mockStudy: DicomStudy = {
  id: 'ST-2024-001',
  patientId: mockPatient.id,
  studyUid: '1.2.840.113619.2.55.3.2831164357.',
  studyDescription: 'CTA Aorta and Iliac Arteries',
  modality: 'CT',
  studyDate: new Date('2024-06-15'),
  numSlices: 512,
  dicomPath: '/studies/ST-2024-001',
  status: 'analyzed',
  metadata: {
    patientName: 'Petrov Alexander',
    patientId: '12345678',
    studyDescription: 'CTA Aorta and Iliac Arteries',
    modality: 'CT',
    bodyPartExamined: 'ABDOMEN',
    sliceThickness: 0.625,
    pixelSpacing: [0.7, 0.7]
  },
  voxelSpacing: [0.7, 0.7, 0.625],
  imageSize: [512, 512, 512]
};

const mockVolume: Volume3D = {
  dimensions: [256, 256, 256],
  spacing: [0.7, 0.7, 0.625],
  origin: [0, 0, 0],
  data: new Float32Array(256 * 256 * 256).map(() => Math.random()),
  minValue: 0,
  maxValue: 1
};

const mockDiagnosis: AIDiagnosis = {
  id: 'AI-2024-001',
  studyId: mockStudy.id,
  timestamp: new Date(),
  overallConfidence: 0.94,
  severity: 'high',
  processingTime: 45000,
  findings: [
    {
      id: 'F-001',
      type: 'aneurysm',
      location: {
        vesselName: 'Infrarenal Aorta',
        segment: 'Juxtarenal',
        startPoint: [0.1, 0.2, 0.3]
      },
      severity: 'severe',
      confidence: 0.97,
      description: 'Saccular aneurysm of the infrarenal aorta with significant wall irregularity and partial thrombus formation.',
      measurements: [
        { type: 'diameter', value: 56.3, unit: 'mm', normalRange: [20, 30], isAbnormal: true },
        { type: 'length', value: 78.5, unit: 'mm', isAbnormal: false },
        { type: 'volume', value: 145.2, unit: 'mL', isAbnormal: true }
      ],
      sliceIndices: [145, 146, 147, 148, 149]
    },
    {
      id: 'F-002',
      type: 'stenosis',
      location: {
        vesselName: 'Right Common Iliac Artery',
        segment: 'Proximal',
        side: 'right',
        startPoint: [0.15, 0.25, 0.35]
      },
      severity: 'moderate',
      confidence: 0.89,
      description: 'Moderate calcified stenosis at the origin of the right common iliac artery.',
      measurements: [
        { type: 'diameter', value: 6.2, unit: 'mm', normalRange: [8, 12], isAbnormal: true },
        { type: 'area', value: 30.2, unit: 'mm²', isAbnormal: true }
      ],
      sliceIndices: [180, 181, 182]
    }
  ],
  recommendations: [
    {
      id: 'R-001',
      priority: 1,
      approach: 'endovascular',
      procedure: 'EVAR with Custom-made Fenestrated Stent Graft',
      indication: 'Large juxtarenal aortic aneurysm (56mm) with high rupture risk',
      contraindications: ['Severe aortic tortuosity', 'Inadequate landing zones'],
      benefits: ['Minimally invasive approach', 'Shorter hospital stay (2-3 days)', 'Lower perioperative mortality (<2%)'],
      risks: ['Endoleak (10-15%)', 'Stent migration (2-5%)', 'Renal artery occlusion (3-8%)'],
      expectedOutcomes: 'Successful aneurysm exclusion with preserved renal perfusion',
      alternatives: ['Open surgical repair', 'Conservative management with surveillance'],
      evidenceLevel: 'A',
      guidelines: ['ESVS 2024', 'SVS 2023'],
      confidence: 0.92
    }
  ]
};

// Sidebar Navigation Item
interface NavItemProps {
  icon: React.ComponentType<{ className?: string }>;
  label: string;
  active?: boolean;
  onClick?: () => void;
  badge?: number;
}

const NavItem: React.FC<NavItemProps> = ({ icon: Icon, label, active, onClick, badge }) => (
  <button
    onClick={onClick}
    className={cn(
      'w-full flex items-center gap-3 px-4 py-3 text-sm font-medium transition-all rounded-xl',
      active 
        ? 'bg-gradient-to-r from-blue-600 to-blue-500 text-white shadow-lg shadow-blue-500/25' 
        : 'text-slate-400 hover:text-white hover:bg-slate-800/50'
    )}
  >
    <Icon className={cn('w-5 h-5', active && 'text-white')} />
    <span className="flex-1 text-left">{label}</span>
    {badge !== undefined && badge > 0 && (
      <span className={cn(
        'px-2 py-0.5 text-xs rounded-full',
        active ? 'bg-white/20 text-white' : 'bg-red-500/20 text-red-400'
      )}>
        {badge}
      </span>
    )}
  </button>
);

// Patient Info Card
const PatientInfoCard: React.FC<{ patient: Patient }> = ({ patient }) => (
  <div className="glass rounded-2xl p-4 space-y-4">
    <div className="flex items-center gap-4">
      <div className="w-14 h-14 rounded-full bg-gradient-to-br from-blue-500 to-cyan-500 flex items-center justify-center text-xl font-bold text-white">
        {patient.firstName[0]}{patient.lastName[0]}
      </div>
      <div className="flex-1 min-w-0">
        <h3 className="font-semibold text-white truncate">
          {patient.lastName}, {patient.firstName}
        </h3>
        <p className="text-sm text-slate-400">
          MRN: {patient.mrn} • {patient.sex} • {patient.age}y
        </p>
      </div>
    </div>
    
    <div className="grid grid-cols-2 gap-2 text-xs">
      <div className="bg-slate-800/50 rounded-lg p-2">
        <span className="text-slate-500">BMI</span>
        <div className="font-mono text-cyan-400">{patient.bmi}</div>
      </div>
      <div className="bg-slate-800/50 rounded-lg p-2">
        <span className="text-slate-500">BP</span>
        <div className="font-mono text-cyan-400">
          {patient.vitals.bloodPressure.systolic}/{patient.vitals.bloodPressure.diastolic}
        </div>
      </div>
    </div>
    
    {patient.comorbidities.length > 0 && (
      <div>
        <span className="text-xs text-slate-500 uppercase tracking-wider">Comorbidities</span>
        <div className="flex flex-wrap gap-1 mt-1">
          {patient.comorbidities.slice(0, 3).map((c, i) => (
            <span key={i} className="text-xs bg-amber-500/20 text-amber-400 px-2 py-0.5 rounded">
              {c}
            </span>
          ))}
          {patient.comorbidities.length > 3 && (
            <span className="text-xs text-slate-500">+{patient.comorbidities.length - 3}</span>
          )}
        </div>
      </div>
    )}
  </div>
);

// Study Info Card
const StudyInfoCard: React.FC<{ study: DicomStudy }> = ({ study }) => (
  <div className="glass rounded-2xl p-4">
    <div className="flex items-center justify-between mb-3">
      <h4 className="font-semibold text-white">Current Study</h4>
      <span className={cn(
        'text-xs px-2 py-1 rounded-full',
        study.status === 'analyzed' ? 'bg-emerald-500/20 text-emerald-400' :
        study.status === 'processing' ? 'bg-amber-500/20 text-amber-400' :
        'bg-slate-700 text-slate-400'
      )}>
        {study.status}
      </span>
    </div>
    
    <div className="space-y-2 text-sm">
      <div className="flex justify-between">
        <span className="text-slate-500">Description</span>
        <span className="text-slate-300 text-right max-w-[60%]">{study.studyDescription}</span>
      </div>
      <div className="flex justify-between">
        <span className="text-slate-500">Modality</span>
        <span className="text-cyan-400 font-mono">{study.modality}</span>
      </div>
      <div className="flex justify-between">
        <span className="text-slate-500">Date</span>
        <span className="text-slate-300">{study.studyDate.toLocaleDateString()}</span>
      </div>
      <div className="flex justify-between">
        <span className="text-slate-500">Slices</span>
        <span className="text-slate-300 font-mono">{study.numSlices}</span>
      </div>
    </div>
  </div>
);

// Main App Component
function App() {
  const [sidebarOpen, setSidebarOpen] = useState(true);
  const [activeView, setActiveView] = useState('viewer');
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [diagnosis, setDiagnosis] = useState<AIDiagnosis | undefined>(mockDiagnosis);
  const [showPatientInfo, setShowPatientInfo] = useState(true);
  const [labAnalyzing, setLabAnalyzing] = useState(false);
  const [labDiagnosis, setLabDiagnosis] = useState<LabAIDiag | undefined>(mockLabAIDiagnosis);
  
  // Simulate AI analysis for imaging
  const runAIAnalysis = useCallback(() => {
    setIsAnalyzing(true);
    setTimeout(() => {
      setIsAnalyzing(false);
      setDiagnosis(mockDiagnosis);
    }, 3000);
  }, []);
  
  // Simulate AI analysis for lab
  const runLabAIAnalysis = useCallback(() => {
    setLabAnalyzing(true);
    setTimeout(() => {
      setLabAnalyzing(false);
      setLabDiagnosis(mockLabAIDiagnosis);
    }, 2500);
  }, []);
  
  const handleFindingClick = useCallback((_finding: AIFinding) => {
    // Handle finding selection - can be extended for navigation
  }, []);
  
  const handleRecommendationClick = useCallback((_rec: TreatmentRecommendation) => {
    // Handle recommendation selection - can be extended for treatment planning
  }, []);
  
  const handleLabUpload = useCallback((_files: File[]) => {
    // Handle lab file upload - can be extended for processing
  }, []);
  
  return (
    <div className="min-h-screen bg-[#0A0F1C] text-white flex">
      {/* Sidebar */}
      <aside 
        className={cn(
          'fixed left-0 top-0 h-full bg-[#111827] border-r border-slate-800/50 z-50 transition-all duration-300',
          sidebarOpen ? 'w-72' : 'w-0 overflow-hidden'
        )}
      >
        <div className="h-full flex flex-col">
          {/* Logo */}
          <div className="p-4 border-b border-slate-800/50">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-blue-600 via-cyan-500 to-blue-600 flex items-center justify-center">
                <Activity className="w-6 h-6 text-white" />
              </div>
              <div>
                <h1 className="font-bold text-lg tracking-tight">VASCULAR<span className="text-cyan-400">.AI</span></h1>
                <p className="text-xs text-slate-500">Revolutionary Surgery Platform</p>
              </div>
            </div>
          </div>
          
          {/* Navigation */}
          <nav className="flex-1 p-3 space-y-1 overflow-auto">
            <div className="text-xs font-semibold text-slate-600 uppercase tracking-wider px-4 py-2">
              Main
            </div>
            <NavItem 
              icon={Scan} 
              label="3D Viewer" 
              active={activeView === 'viewer'}
              onClick={() => setActiveView('viewer')}
            />
            <NavItem 
              icon={Brain} 
              label="AI Diagnosis" 
              active={activeView === 'diagnosis'}
              badge={diagnosis?.findings.length}
              onClick={() => setActiveView('diagnosis')}
            />
            <NavItem 
              icon={Stethoscope} 
              label="Treatment Plan" 
              active={activeView === 'treatment'}
              onClick={() => setActiveView('treatment')}
            />
            <NavItem 
              icon={FlaskConical} 
              label="Laboratory" 
              active={activeView === 'laboratory'}
              badge={mockAlerts.length}
              onClick={() => setActiveView('laboratory')}
            />
            <NavItem 
              icon={BarChart3} 
              label="Measurements" 
              active={activeView === 'measurements'}
              onClick={() => setActiveView('measurements')}
            />
            
            <div className="text-xs font-semibold text-slate-600 uppercase tracking-wider px-4 py-2 mt-4">
              Patient
            </div>
            <NavItem 
              icon={User} 
              label="Patient Info" 
              active={activeView === 'patient'}
              onClick={() => setActiveView('patient')}
            />
            <NavItem 
              icon={FileText} 
              label="History" 
              active={activeView === 'history'}
              onClick={() => setActiveView('history')}
            />
            <NavItem 
              icon={Calendar} 
              label="Appointments" 
              active={activeView === 'appointments'}
              onClick={() => setActiveView('appointments')}
            />
            
            <div className="text-xs font-semibold text-slate-600 uppercase tracking-wider px-4 py-2 mt-4">
              System
            </div>
            <NavItem 
              icon={FolderOpen} 
              label="Studies" 
              active={activeView === 'studies'}
              onClick={() => setActiveView('studies')}
            />
            <NavItem 
              icon={Settings} 
              label="Settings" 
              active={activeView === 'settings'}
              onClick={() => setActiveView('settings')}
            />
            <NavItem 
              icon={HelpCircle} 
              label="Help" 
              active={activeView === 'help'}
              onClick={() => setActiveView('help')}
            />
          </nav>
          
          {/* User */}
          <div className="p-4 border-t border-slate-800/50">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-full bg-gradient-to-br from-emerald-500 to-teal-500 flex items-center justify-center">
                <User className="w-5 h-5 text-white" />
              </div>
              <div className="flex-1 min-w-0">
                <p className="text-sm font-medium text-white truncate">Dr. Ivanov S.V.</p>
                <p className="text-xs text-slate-500">Vascular Surgeon</p>
              </div>
              <button className="p-2 hover:bg-slate-800 rounded-lg transition-colors">
                <LogOut className="w-4 h-4 text-slate-400" />
              </button>
            </div>
          </div>
        </div>
      </aside>
      
      {/* Main Content */}
      <main className={cn(
        'flex-1 flex flex-col transition-all duration-300',
        sidebarOpen ? 'ml-72' : 'ml-0'
      )}>
        {/* Header */}
        <header className="h-16 bg-[#111827]/80 backdrop-blur-xl border-b border-slate-800/50 flex items-center justify-between px-4 sticky top-0 z-40">
          <div className="flex items-center gap-4">
            <button
              onClick={() => setSidebarOpen(!sidebarOpen)}
              className="p-2 hover:bg-slate-800 rounded-lg transition-colors"
            >
              <Menu className="w-5 h-5 text-slate-400" />
            </button>
            
            <div className="flex items-center gap-2 text-sm text-slate-400">
              <span>Patients</span>
              <ChevronRight className="w-4 h-4" />
              <span className="text-white">{mockPatient.lastName}, {mockPatient.firstName}</span>
              <ChevronRight className="w-4 h-4" />
              <span className="text-cyan-400">
                {activeView === 'laboratory' ? 'Laboratory Results' : mockStudy.studyDescription}
              </span>
            </div>
          </div>
          
          <div className="flex items-center gap-2">
            {activeView !== 'laboratory' && (
              <button 
                onClick={runAIAnalysis}
                disabled={isAnalyzing}
                className={cn(
                  'flex items-center gap-2 px-4 py-2 rounded-lg font-medium text-sm transition-all',
                  isAnalyzing 
                    ? 'bg-slate-800 text-slate-400 cursor-not-allowed'
                    : 'bg-gradient-to-r from-blue-600 to-cyan-500 text-white hover:shadow-lg hover:shadow-blue-500/25'
                )}
              >
                {isAnalyzing ? (
                  <>
                    <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                    Analyzing...
                  </>
                ) : (
                  <>
                    <Brain className="w-4 h-4" />
                    Run AI Analysis
                  </>
                )}
              </button>
            )}
            
            <button className="p-2 hover:bg-slate-800 rounded-lg transition-colors relative">
              <Bell className="w-5 h-5 text-slate-400" />
              <span className="absolute top-1 right-1 w-2 h-2 bg-red-500 rounded-full" />
            </button>
            
            <button className="p-2 hover:bg-slate-800 rounded-lg transition-colors">
              <Settings className="w-5 h-5 text-slate-400" />
            </button>
          </div>
        </header>
        
        {/* Content Area */}
        <div className="flex-1 flex overflow-hidden">
          {activeView === 'laboratory' ? (
            /* Laboratory View */
            <div className="flex-1 flex">
              {/* Left Panel - Lab Results */}
              <div className="flex-1 p-4 overflow-auto">
                <div className="max-w-4xl mx-auto space-y-6">
                  <div className="flex items-center justify-between">
                    <div>
                      <h2 className="text-2xl font-bold text-white flex items-center gap-3">
                        <FlaskConical className="w-8 h-8 text-purple-400" />
                        Laboratory Analysis
                      </h2>
                      <p className="text-slate-400 mt-1">
                        AI-powered hematology & transfusion diagnostics
                      </p>
                    </div>
                    <button
                      onClick={runLabAIAnalysis}
                      disabled={labAnalyzing}
                      className={cn(
                        'flex items-center gap-2 px-4 py-2 rounded-lg font-medium text-sm transition-all',
                        labAnalyzing 
                          ? 'bg-slate-800 text-slate-400 cursor-not-allowed'
                          : 'bg-gradient-to-r from-purple-600 to-pink-500 text-white hover:shadow-lg hover:shadow-purple-500/25'
                      )}
                    >
                      {labAnalyzing ? (
                        <>
                          <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                          Analyzing...
                        </>
                      ) : (
                        <>
                          <Brain className="w-4 h-4" />
                          Run AI Lab Analysis
                        </>
                      )}
                    </button>
                  </div>
                  
                  {/* Upload Section */}
                  <LabUpload onUpload={handleLabUpload} />
                  
                  {/* Lab Panel */}
                  <LaboratoryPanel
                    panels={mockLabPanels}
                    aiDiagnosis={labDiagnosis}
                    alerts={mockAlerts}
                    isAnalyzing={labAnalyzing}
                    onRunAnalysis={runLabAIAnalysis}
                  />
                </div>
              </div>
              
              {/* Right Panel - Patient Info */}
              <aside className="w-96 bg-[#111827] border-l border-slate-800/50 p-4 overflow-auto">
                <PatientInfoCard patient={mockPatient} />
                
                {/* Critical Alerts Summary */}
                {mockAlerts.length > 0 && (
                  <div className="mt-4 glass rounded-2xl p-4 border-l-4 border-red-500">
                    <h4 className="font-semibold text-red-400 flex items-center gap-2 mb-3">
                      <AlertTriangle className="w-5 h-5" />
                      Critical Alerts ({mockAlerts.length})
                    </h4>
                    <div className="space-y-2">
                      {mockAlerts.map((alert) => (
                        <div key={alert.id} className="bg-red-500/10 rounded-lg p-2">
                          <p className="text-sm text-white font-medium">{alert.title}</p>
                          <p className="text-xs text-slate-400 mt-1 line-clamp-2">
                            {alert.message}
                          </p>
                        </div>
                      ))}
                    </div>
                  </div>
                )}
                
                {/* Quick Stats */}
                <div className="mt-4 glass rounded-2xl p-4">
                  <h4 className="font-semibold text-white mb-3 flex items-center gap-2">
                    <Droplets className="w-5 h-5 text-purple-400" />
                    Hematology Summary
                  </h4>
                  <div className="space-y-2">
                    <div className="flex justify-between text-sm">
                      <span className="text-slate-400">Hemoglobin</span>
                      <span className="font-mono text-red-400">9.8 g/dL ↓</span>
                    </div>
                    <div className="flex justify-between text-sm">
                      <span className="text-slate-400">WBC</span>
                      <span className="font-mono text-amber-400">12.5 ×10⁹/L ↑</span>
                    </div>
                    <div className="flex justify-between text-sm">
                      <span className="text-slate-400">Platelets</span>
                      <span className="font-mono text-amber-400">485 ×10⁹/L ↑</span>
                    </div>
                    <div className="flex justify-between text-sm">
                      <span className="text-slate-400">D-Dimer</span>
                      <span className="font-mono text-red-400">1250 ng/mL ↑↑</span>
                    </div>
                  </div>
                </div>
              </aside>
            </div>
          ) : (
            /* Standard Viewer View */
            <>
              {/* Main Viewer */}
              <div className="flex-1 flex flex-col">
                {/* Toolbar */}
                <div className="h-12 bg-[#151D2B] border-b border-slate-800/50 flex items-center justify-between px-4">
                  <div className="flex items-center gap-2">
                    <button className="p-1.5 hover:bg-slate-700 rounded text-slate-400 hover:text-white transition-colors">
                      <LayoutGrid className="w-4 h-4" />
                    </button>
                    <button className="p-1.5 hover:bg-slate-700 rounded text-slate-400 hover:text-white transition-colors">
                      <Maximize2 className="w-4 h-4" />
                    </button>
                    <div className="w-px h-4 bg-slate-700 mx-2" />
                    <button className="p-1.5 hover:bg-slate-700 rounded text-slate-400 hover:text-white transition-colors">
                      <RotateCcw className="w-4 h-4" />
                    </button>
                    <button className="p-1.5 hover:bg-slate-700 rounded text-slate-400 hover:text-white transition-colors">
                      <Save className="w-4 h-4" />
                    </button>
                  </div>
                  
                  <div className="flex items-center gap-2">
                    <button className="flex items-center gap-2 px-3 py-1.5 bg-slate-800 hover:bg-slate-700 rounded-lg text-sm text-slate-300 transition-colors">
                      <Printer className="w-4 h-4" />
                      Print
                    </button>
                    <button className="flex items-center gap-2 px-3 py-1.5 bg-slate-800 hover:bg-slate-700 rounded-lg text-sm text-slate-300 transition-colors">
                      <Download className="w-4 h-4" />
                      Export
                    </button>
                    <button className="flex items-center gap-2 px-3 py-1.5 bg-slate-800 hover:bg-slate-700 rounded-lg text-sm text-slate-300 transition-colors">
                      <Share2 className="w-4 h-4" />
                      Share
                    </button>
                  </div>
                </div>
                
                {/* Viewer */}
                <div className="flex-1 p-4">
                  <Volume3DViewer
                    volume={mockVolume}
                    findings={diagnosis?.findings || []}
                    measurements={[]}
                    onFindingSelect={handleFindingClick}
                    className="h-full"
                  />
                </div>
              </div>
              
              {/* Right Panel */}
              <aside className={cn(
                'w-96 bg-[#111827] border-l border-slate-800/50 flex flex-col transition-all duration-300',
                !showPatientInfo && 'w-0 overflow-hidden'
              )}>
                {/* Panel Header */}
                <div className="h-12 border-b border-slate-800/50 flex items-center justify-between px-4">
                  <span className="font-medium text-white">Patient Info & AI Diagnosis</span>
                  <button 
                    onClick={() => setShowPatientInfo(!showPatientInfo)}
                    className="p-1.5 hover:bg-slate-800 rounded text-slate-400"
                  >
                    <ChevronRight className="w-4 h-4" />
                  </button>
                </div>
                
                {/* Panel Content */}
                <div className="flex-1 overflow-auto p-4 space-y-4">
                  <PatientInfoCard patient={mockPatient} />
                  <StudyInfoCard study={mockStudy} />
                  <AIDiagnosisPanel
                    diagnosis={diagnosis}
                    isAnalyzing={isAnalyzing}
                    onFindingClick={handleFindingClick}
                    onRecommendationClick={handleRecommendationClick}
                  />
                </div>
              </aside>
            </>
          )}
        </div>
      </main>
    </div>
  );
}

export default App;
