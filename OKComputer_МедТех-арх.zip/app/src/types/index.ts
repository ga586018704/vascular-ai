// VASCULAR.AI - Type Definitions

// User & Authentication
export interface User {
  id: string;
  email: string;
  fullName: string;
  role: 'admin' | 'surgeon' | 'resident' | 'radiologist' | 'nurse' | 'researcher';
  licenseNumber?: string;
  avatar?: string;
  isActive: boolean;
  lastLogin?: Date;
  createdAt: Date;
}

export interface AuthState {
  user: User | null;
  token: string | null;
  refreshToken: string | null;
  isAuthenticated: boolean;
  isLoading: boolean;
}

// DICOM & Medical Imaging
export interface DicomStudy {
  id: string;
  patientId: string;
  studyUid: string;
  studyDescription: string;
  modality: 'CT' | 'MRI' | 'US' | 'XA' | 'OT';
  studyDate: Date;
  numSlices: number;
  dicomPath: string;
  status: 'uploaded' | 'processing' | 'analyzed' | 'error';
  metadata: DicomMetadata;
  voxelSpacing: [number, number, number];
  imageSize: [number, number, number];
  tags?: Record<string, string>;
}

export interface DicomMetadata {
  patientName?: string;
  patientId?: string;
  patientBirthDate?: string;
  patientSex?: 'M' | 'F' | 'O';
  studyInstanceUid?: string;
  seriesInstanceUid?: string;
  sopInstanceUid?: string;
  modality?: string;
  studyDescription?: string;
  seriesDescription?: string;
  bodyPartExamined?: string;
  sliceThickness?: number;
  pixelSpacing?: [number, number];
  imagePosition?: [number, number, number];
  imageOrientation?: number[];
  windowCenter?: number;
  windowWidth?: number;
}

export interface DicomSlice {
  index: number;
  sliceLocation: number;
  instanceNumber: number;
  pixelData: Uint8Array | Float32Array;
  rows: number;
  columns: number;
  minValue: number;
  maxValue: number;
  windowCenter: number;
  windowWidth: number;
}

// 3D Visualization
export interface Volume3D {
  dimensions: [number, number, number];
  spacing: [number, number, number];
  origin: [number, number, number];
  data: Float32Array;
  minValue: number;
  maxValue: number;
}

export interface Mesh3D {
  vertices: Float32Array;
  indices: Uint32Array;
  normals: Float32Array;
  colors?: Uint8Array;
  name: string;
  visible: boolean;
  opacity: number;
}

export interface View3DState {
  cameraPosition: [number, number, number];
  cameraTarget: [number, number, number];
  zoom: number;
  rotation: [number, number, number];
  sliceIndex: number;
  slicePlane: 'axial' | 'sagittal' | 'coronal' | '3d';
  windowLevel: number;
  windowWidth: number;
}

// AI Diagnosis
export interface AIDiagnosis {
  id: string;
  studyId: string;
  timestamp: Date;
  findings: AIFinding[];
  overallConfidence: number;
  recommendations: TreatmentRecommendation[];
  severity: 'normal' | 'low' | 'moderate' | 'high' | 'critical';
  processingTime: number;
}

export interface AIFinding {
  id: string;
  type: 'stenosis' | 'aneurysm' | 'occlusion' | 'plaque' | 'thrombus' | 'dissection' | 'calcification' | 'other';
  location: VesselLocation;
  severity: 'mild' | 'moderate' | 'severe';
  confidence: number;
  measurements: Measurement[];
  description: string;
  bbox3D?: [number, number, number, number, number, number];
  sliceIndices?: number[];
  imageUrls?: string[];
}

export interface VesselLocation {
  vesselName: string;
  segment: string;
  side?: 'left' | 'right' | 'bilateral';
  startPoint?: [number, number, number];
  endPoint?: [number, number, number];
}

export interface Measurement {
  type: 'diameter' | 'length' | 'area' | 'volume' | 'angle' | 'distance';
  value: number;
  unit: string;
  normalRange?: [number, number];
  isAbnormal: boolean;
}

// Vessel Analysis
export interface VesselAnalysis {
  vesselName: string;
  centerline: Float32Array;
  diameterProfile: number[];
  minDiameter: number;
  maxDiameter: number;
  meanDiameter: number;
  length: number;
  volume: number;
  stenoses: Stenosis[];
  aneurysms: Aneurysm[];
  tortuosity: number;
  calcificationScore: number;
}

export interface Stenosis {
  id: string;
  location: [number, number, number];
  degree: number;
  length: number;
  type: 'concentric' | 'eccentric' | 'calcified' | 'soft' | 'mixed';
  severity: 'mild' | 'moderate' | 'severe' | 'critical';
  proximalDiameter: number;
  distalDiameter: number;
  minimalDiameter: number;
}

export interface Aneurysm {
  id: string;
  location: [number, number, number];
  type: 'saccular' | 'fusiform' | 'dissecting' | 'pseudo';
  maxDiameter: number;
  neckDiameter: number;
  height: number;
  volume: number;
  aspectRatio: number;
  ruptureRisk: 'low' | 'intermediate' | 'high';
}

// Treatment Planning
export interface TreatmentPlan {
  id: string;
  studyId: string;
  patientId: string;
  createdAt: Date;
  updatedAt: Date;
  createdBy: string;
  status: 'draft' | 'reviewed' | 'approved' | 'completed';
  diagnosis: string;
  findings: AIFinding[];
  recommendations: TreatmentRecommendation[];
  selectedApproach?: TreatmentApproach;
  surgicalPlan?: SurgicalPlan;
  endovascularPlan?: EndovascularPlan;
  hybridPlan?: HybridPlan;
  followUpPlan?: FollowUpPlan;
  risks: RiskAssessment;
  consentForm?: ConsentForm;
}

export interface TreatmentRecommendation {
  id: string;
  priority: number;
  approach: 'surgical' | 'endovascular' | 'hybrid' | 'conservative' | 'observation';
  procedure: string;
  indication: string;
  contraindications: string[];
  benefits: string[];
  risks: string[];
  expectedOutcomes: string;
  alternatives: string[];
  evidenceLevel: 'A' | 'B' | 'C';
  guidelines: string[];
  confidence: number;
}

export interface TreatmentApproach {
  type: 'surgical' | 'endovascular' | 'hybrid' | 'conservative';
  procedure: string;
  approachDescription: string;
  accessRoute: string;
  anesthesia: string;
  estimatedDuration: number;
  requiredEquipment: string[];
  requiredTeam: string[];
}

export interface SurgicalPlan {
  incision: IncisionPlan;
  exposure: string[];
  procedure: ProcedureStep[];
  closure: string[];
  specialConsiderations: string[];
}

export interface EndovascularPlan {
  access: AccessSite[];
  devices: Device[];
  procedure: ProcedureStep[];
  expectedOutcome: string;
  bailoutStrategies: string[];
}

export interface HybridPlan {
  surgicalComponent: SurgicalPlan;
  endovascularComponent: EndovascularPlan;
  sequence: 'surgical-first' | 'endovascular-first' | 'simultaneous';
  coordination: string[];
}

export interface IncisionPlan {
  type: string;
  location: string;
  length: number;
  direction: string;
  landmarks: string[];
}

export interface ProcedureStep {
  order: number;
  description: string;
  critical: boolean;
  estimatedTime: number;
  potentialComplications: string[];
  bailoutOptions: string[];
}

export interface AccessSite {
  vessel: string;
  side: 'left' | 'right';
  approach: 'retrograde' | 'antegrade';
  sheathSize: string;
  closureDevice?: string;
}

export interface Device {
  category: 'stent' | 'graft' | 'balloon' | 'catheter' | 'wire' | 'embolic' | 'other';
  name: string;
  manufacturer: string;
  size: string;
  length?: number;
  diameter?: number;
  quantity: number;
  alternatives: string[];
}

export interface FollowUpPlan {
  schedule: FollowUpVisit[];
  imaging: ImagingSchedule[];
  medications: MedicationPlan[];
  lifestyle: string[];
  warningSigns: string[];
}

export interface FollowUpVisit {
  timepoint: string;
  type: 'clinical' | 'imaging' | 'lab';
  assessments: string[];
}

export interface ImagingSchedule {
  modality: string;
  timepoint: string;
  indication: string;
}

export interface MedicationPlan {
  medication: string;
  dosage: string;
  frequency: string;
  duration: string;
  indication: string;
}

// Risk Assessment
export interface RiskAssessment {
  overallRisk: 'low' | 'moderate' | 'high' | 'very-high';
  scores: RiskScore[];
  factors: RiskFactor[];
  predictedOutcomes: PredictedOutcome[];
}

export interface RiskScore {
  name: string;
  score: number;
  maxScore: number;
  category: string;
  interpretation: string;
}

export interface RiskFactor {
  factor: string;
  present: boolean;
  weight: number;
  modifiable: boolean;
}

export interface PredictedOutcome {
  outcome: string;
  probability: number;
  confidenceInterval: [number, number];
}

export interface ConsentForm {
  procedure: string;
  risks: string[];
  benefits: string[];
  alternatives: string[];
  patientQuestions: string[];
  physicianSignature?: string;
  patientSignature?: string;
  date?: Date;
}

// Patient Data
export interface Patient {
  id: string;
  mrn: string;
  firstName: string;
  lastName: string;
  dateOfBirth: Date;
  sex: 'M' | 'F' | 'O';
  age: number;
  bmi: number;
  allergies: string[];
  medications: string[];
  comorbidities: string[];
  previousSurgeries: PreviousSurgery[];
  vitals: VitalSigns;
  labResults: LabResult[];
  imaging: DicomStudy[];
  riskFactors: string[];
}

export interface PreviousSurgery {
  procedure: string;
  date: Date;
  complications?: string[];
  outcome: string;
}

export interface VitalSigns {
  timestamp: Date;
  bloodPressure: { systolic: number; diastolic: number };
  heartRate: number;
  respiratoryRate: number;
  temperature: number;
  oxygenSaturation: number;
  weight: number;
  height: number;
}

export interface LabResult {
  test: string;
  value: number;
  unit: string;
  referenceRange: string;
  abnormal: boolean;
  timestamp: Date;
}

// UI State
export interface UIState {
  sidebarOpen: boolean;
  activeTab: string;
  theme: 'dark' | 'light';
  notifications: Notification[];
  modals: ModalState;
  loading: LoadingState;
}

export interface Notification {
  id: string;
  type: 'success' | 'error' | 'warning' | 'info';
  title: string;
  message: string;
  timestamp: Date;
  read: boolean;
  action?: { label: string; onClick: () => void };
}

export interface ModalState {
  uploadOpen: boolean;
  settingsOpen: boolean;
  helpOpen: boolean;
  patientInfoOpen: boolean;
}

export interface LoadingState {
  global: boolean;
  upload: boolean;
  analysis: boolean;
  export: boolean;
}

// Export & Reporting
export interface ExportOptions {
  format: 'pdf' | 'dicom' | 'nifti' | 'obj' | 'stl' | 'report';
  includeImages: boolean;
  includeMeasurements: boolean;
  include3DModels: boolean;
  anonymize: boolean;
  quality: 'low' | 'medium' | 'high';
}

export interface Report {
  id: string;
  studyId: string;
  patientId: string;
  createdAt: Date;
  createdBy: string;
  sections: ReportSection[];
  signature?: string;
}

export interface ReportSection {
  title: string;
  content: string;
  images?: string[];
  tables?: DataTable[];
}

export interface DataTable {
  headers: string[];
  rows: (string | number)[][];
}

// Calculator Results
export interface CalculatorResult {
  calculator: string;
  inputs: Record<string, number | string | boolean>;
  result: number | string;
  interpretation: string;
  riskCategory?: string;
  recommendations?: string[];
  references?: string[];
}

// Comparison
export interface ComparisonStudy {
  studyId: string;
  date: Date;
  findings: AIFinding[];
  measurements: Measurement[];
  images: string[];
}

export interface ComparisonResult {
  baseline: ComparisonStudy;
  followUp: ComparisonStudy;
  changes: ChangeAnalysis[];
  progression: 'improved' | 'stable' | 'worsened' | 'new-findings';
  recommendations: string[];
}

export interface ChangeAnalysis {
  finding: string;
  baselineValue: number;
  followUpValue: number;
  change: number;
  changePercent: number;
  significance: 'significant' | 'non-significant';
}
