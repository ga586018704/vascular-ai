// VASCULAR.AI - Laboratory & Hematology Types
// Developed by Chief Hematologist-Transfusiologist

export type LabCategory = 
  | 'hematology' 
  | 'biochemistry' 
  | 'coagulation' 
  | 'immunology' 
  | 'microbiology' 
  | 'genetic' 
  | 'tumor_markers' 
  | 'hormones' 
  | 'electrolytes'
  | 'rare_diseases';

export type TestStatus = 'normal' | 'low' | 'high' | 'critical_low' | 'critical_high' | 'borderline';

export interface LabTest {
  id: string;
  code: string;
  name: string;
  nameRu: string;
  category: LabCategory;
  value: number | string;
  unit: string;
  referenceRange: {
    min?: number;
    max?: number;
    text?: string;
  };
  status: TestStatus;
  previousValue?: number;
  changePercent?: number;
  timestamp: Date;
  method?: string;
  labName?: string;
  isUrgent: boolean;
  notes?: string;
}

export interface LabPanel {
  id: string;
  name: string;
  nameRu: string;
  category: LabCategory;
  tests: LabTest[];
  collectedAt: Date;
  receivedAt: Date;
  reportedAt: Date;
  labName: string;
  physician: string;
  status: 'pending' | 'partial' | 'complete';
}

// Hematology Specific
export interface HematologyPanel {
  // Complete Blood Count (CBC)
  wbc: LabTest;              // White Blood Cells
  rbc: LabTest;              // Red Blood Cells
  hgb: LabTest;              // Hemoglobin
  hct: LabTest;              // Hematocrit
  mcv: LabTest;              // Mean Corpuscular Volume
  mch: LabTest;              // Mean Corpuscular Hemoglobin
  mchc: LabTest;             // Mean Corpuscular Hemoglobin Concentration
  rdw: LabTest;              // Red Cell Distribution Width
  plt: LabTest;              // Platelets
  mpv: LabTest;              // Mean Platelet Volume
  
  // Differential Count
  neutrophils: LabTest;
  lymphocytes: LabTest;
  monocytes: LabTest;
  eosinophils: LabTest;
  basophils: LabTest;
  bands: LabTest;
  atypicalLymphocytes?: LabTest;
  
  // Extended Hematology
  reticulocytes?: LabTest;
  esr?: LabTest;             // Erythrocyte Sedimentation Rate
  crp?: LabTest;             // C-Reactive Protein
  
  // Special Markers
  ferritin?: LabTest;
  transferrin?: LabTest;
  iron?: LabTest;
  tibc?: LabTest;            // Total Iron Binding Capacity
  transferrinSaturation?: LabTest;
  folate?: LabTest;
  b12?: LabTest;
  
  // Hemolysis Markers
  bilirubinTotal?: LabTest;
  bilirubinDirect?: LabTest;
  ldh?: LabTest;             // Lactate Dehydrogenase
  haptoglobin?: LabTest;
  
  // Coombs Test
  directCoombs?: LabTest;
  indirectCoombs?: LabTest;
}

// Coagulation Panel
export interface CoagulationPanel {
  pt: LabTest;               // Prothrombin Time
  inr: LabTest;              // International Normalized Ratio
  aptt: LabTest;             // Activated Partial Thromboplastin Time
  fibrinogen: LabTest;
  tt: LabTest;               // Thrombin Time
  dDimer: LabTest;
  
  // Factor Assays
  factorII?: LabTest;        // Prothrombin
  factorV?: LabTest;
  factorVII?: LabTest;
  factorVIII?: LabTest;
  factorIX?: LabTest;
  factorX?: LabTest;
  factorXI?: LabTest;
  factorXII?: LabTest;
  
  // Inhibitors
  antithrombinIII?: LabTest;
  proteinC?: LabTest;
  proteinS?: LabTest;
  lupusAnticoagulant?: LabTest;
  
  // Platelet Function
  bleedingTime?: LabTest;
  plateletAggregation?: LabTest;
  
  // FDP
  fdp?: LabTest;             // Fibrin Degradation Products
  
  // Special Tests
  reptilaseTime?: LabTest;
  ecarinTime?: LabTest;
}

// Rare Disease Markers
export interface RareDiseasePanel {
  // Porphyrias
  porphobilinogenUrine?: LabTest;
  deltaAlaUrine?: LabTest;   // Delta-aminolevulinic acid
  porphyrinsUrine?: LabTest;
  porphyrinsStool?: LabTest;
  zincProtoporphyrin?: LabTest;
  
  // Hemoglobinopathies
  hemoglobinElectrophoresis?: LabTest;
  hbf?: LabTest;             // Fetal Hemoglobin
  hba2?: LabTest;
  hbs?: LabTest;             // Sickle Hemoglobin
  hbc?: LabTest;
  hbe?: LabTest;
  hbd?: LabTest;
  
  // Thalassemias
  alphaThalassemiaScreen?: LabTest;
  betaThalassemiaScreen?: LabTest;
  
  // Thrombophilias
  factorVLeiden?: LabTest;
  prothrombinG20210A?: LabTest;
  mthfr?: LabTest;           // Methylenetetrahydrofolate reductase
  antiphospholipidAntibodies?: LabTest;
  
  // G6PD Deficiency
  g6pdActivity?: LabTest;
  
  // Paroxysmal Nocturnal Hemoglobinuria (PNH)
  cd55?: LabTest;
  cd59?: LabTest;
  flear?: LabTest;           // Fluorescent Erythrocyte Assay
  
  // Aplastic Anemia / MDS Markers
  cd34?: LabTest;
  cytogenetics?: string;
  fish?: string;             // Fluorescence In Situ Hybridization
  
  // Hairy Cell Leukemia
  tartrateResistantAcidPhosphatase?: LabTest;
  
  // Mastocytosis
  tryptase?: LabTest;
  
  // Amyloidosis
  serumFreeLightChains?: LabTest;
  kappaLambdaRatio?: LabTest;
}

// Transfusion Medicine
export interface TransfusionPanel {
  // Blood Type
  aboGroup: 'A' | 'B' | 'AB' | 'O';
  rhFactor: 'positive' | 'negative';
  rhPhenotype?: string;
  
  // Antibody Screen
  antibodyScreen: 'negative' | 'positive';
  identifiedAntibodies?: string[];
  
  // Crossmatch
  crossmatchResult?: 'compatible' | 'incompatible' | 'minor_incompatible';
  
  // Special Requirements
  cmvNegative?: boolean;
  irradiated?: boolean;
  washed?: boolean;
  leukoreduced?: boolean;
  
  // Transfusion History
  previousTransfusions?: {
    date: Date;
    product: string;
    units: number;
    reactions?: string[];
  }[];
  
  // Hemovigilance
  transfusionReactions?: {
    type: 'febrile' | 'allergic' | 'hemolytic' | 'trali' | 'taco' | 'bacterial' | 'other';
    date: Date;
    severity: 'mild' | 'moderate' | 'severe';
    description: string;
  }[];
}

// AI Diagnosis Result for Lab
export interface LabAIDiagnosis {
  id: string;
  panelId: string;
  timestamp: Date;
  
  // Primary Diagnosis
  primaryDiagnosis: {
    condition: string;
    icd10: string;
    confidence: number;
    explanation: string;
  };
  
  // Differential Diagnoses
  differentialDiagnoses: {
    condition: string;
    icd10: string;
    confidence: number;
    keyFindings: string[];
    supportingTests: string[];
    excludingTests: string[];
  }[];
  
  // Pattern Recognition
  recognizedPatterns: {
    pattern: string;
    description: string;
    severity: 'mild' | 'moderate' | 'severe' | 'critical';
    urgency: 'routine' | 'urgent' | 'emergency';
  }[];
  
  // Critical Alerts
  criticalAlerts: {
    parameter: string;
    value: number | string;
    threshold: string;
    action: string;
    timestamp: Date;
  }[];
  
  // Recommendations
  recommendations: {
    category: 'immediate' | 'short_term' | 'long_term' | 'lifestyle' | 'follow_up';
    action: string;
    rationale: string;
    priority: number;
  }[];
  
  // Additional Tests
  suggestedTests: {
    test: string;
    category: LabCategory;
    urgency: 'routine' | 'urgent' | 'stat';
    rationale: string;
  }[];
  
  // Transfusion Recommendations
  transfusionRecommendations?: {
    indicated: boolean;
    product: string;
    units?: number;
    urgency: 'routine' | 'urgent' | 'emergency';
    specialRequirements: string[];
    contraindications: string[];
  }[];
  
  // Trends
  trendAnalysis?: {
    parameter: string;
    trend: 'improving' | 'stable' | 'worsening' | 'fluctuating';
    prediction?: string;
    daysToCritical?: number;
  }[];
}

// Reference Ranges Database
export interface ReferenceRange {
  testCode: string;
  testName: string;
  
  // Adult ranges
  adultMale?: { min?: number; max?: number };
  adultFemale?: { min?: number; max?: number };
  
  // Pediatric ranges by age
  pediatric?: {
    ageGroup: string;
    minAge: number;
    maxAge: number;
    min?: number;
    max?: number;
  }[];
  
  // Critical values
  criticalLow?: number;
  criticalHigh?: number;
  
  // Units
  unit: string;
  
  // Clinical significance
  clinicalNotes?: string;
}

// Lab Trend Data
export interface LabTrend {
  testId: string;
  testName: string;
  unit: string;
  
  dataPoints: {
    timestamp: Date;
    value: number;
    status: TestStatus;
    referenceMin?: number;
    referenceMax?: number;
  }[];
  
  statistics: {
    min: number;
    max: number;
    mean: number;
    median: number;
    stdDev: number;
    trend: 'increasing' | 'decreasing' | 'stable' | 'fluctuating';
    slope?: number;
  };
  
  // Predictions
  predictions?: {
    timestamp: Date;
    predictedValue: number;
    confidenceInterval: [number, number];
  }[];
}

// Clinical Decision Support
export interface ClinicalAlert {
  id: string;
  timestamp: Date;
  severity: 'info' | 'warning' | 'critical' | 'life_threatening';
  category: 
    | 'critical_value' 
    | 'drug_interaction' 
    | 'transfusion_reaction' 
    | 'incompatible_type' 
    | 'rare_phenotype' 
    | 'pattern_recognition';
  
  title: string;
  message: string;
  
  // Affected parameters
  relatedTests: string[];
  
  // Suggested actions
  actions: {
    description: string;
    priority: 'immediate' | 'urgent' | 'routine';
    assignedTo?: string;
  }[];
  
  // Acknowledgment
  acknowledgedBy?: string;
  acknowledgedAt?: Date;
  
  // Escalation
  escalatedTo?: string;
  escalatedAt?: Date;
}

// Bone Marrow Analysis
export interface BoneMarrowReport {
  id: string;
  patientId: string;
  collectedAt: Date;
  
  // Aspiration
  aspiration: {
    site: string;
    cellularity: string;  // percentage or description
    megakaryocytes: string;
    ironStores: 'absent' | 'decreased' | 'normal' | 'increased';
    specialStains: {
      stain: string;
      result: string;
    }[];
  };
  
  // Biopsy
  biopsy: {
    length: number;
    quality: 'adequate' | 'inadequate';
    architecture: string;
    infiltrate?: string;
    fibrosis?: string;
  };
  
  // Differential Count
  differential: {
    myeloblasts: number;
    promyelocytes: number;
    myelocytes: number;
    metamyelocytes: number;
    bandNeutrophils: number;
    segmentedNeutrophils: number;
    eosinophils: number;
    basophils: number;
    lymphocytes: number;
    plasmaCells: number;
    monocytes: number;
    erythroidPrecursors: number;
    macrophages: number;
    mastCells: number;
    abnormalCells?: string;
  };
  
  // Flow Cytometry
  flowCytometry?: {
    markers: {
      marker: string;
      positive: boolean;
      percentage?: number;
    }[];
    interpretation: string;
  };
  
  // Cytogenetics
  cytogenetics?: {
    karyotype: string;
    abnormalities: string[];
    fishResults?: Record<string, string>;
  };
  
  // Molecular Studies
  molecularStudies?: {
    test: string;
    result: string;
    mutation?: string;
    variantAlleleFrequency?: number;
  }[];
  
  // Final Interpretation
  impression: string;
  classification?: string;  // WHO classification
  grade?: string;
  
  // Recommendations
  recommendations: string[];
}

// Laboratory types module
// All types are exported above
