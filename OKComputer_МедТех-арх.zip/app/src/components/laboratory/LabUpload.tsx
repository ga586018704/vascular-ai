import { useState, useCallback } from 'react';
import { 
  Upload, 
  FileText, 
  X, 
  CheckCircle, 
  AlertCircle,
  FileSpreadsheet,
  Database,
  Link,
  ScanLine,
  Loader2,
  Info
} from 'lucide-react';
import { cn } from '@/lib/utils';

interface LISConfig {
  system: string;
  url: string;
  apiKey?: string;
}

interface LabUploadProps {
  onUpload?: (files: File[]) => void;
  onParseHL7?: (data: string) => void;
  onConnectLIS?: (config: LISConfig) => void;
  className?: string;
}

const SUPPORTED_FORMATS = [
  { ext: '.pdf', name: 'PDF Report', icon: FileText },
  { ext: '.csv', name: 'CSV Data', icon: FileSpreadsheet },
  { ext: '.hl7', name: 'HL7 Message', icon: Database },
  { ext: '.json', name: 'JSON Data', icon: Database },
  { ext: '.xml', name: 'XML Report', icon: FileText },
];

const LIS_SYSTEMS = [
  { id: 'cerner', name: 'Cerner PowerChart' },
  { id: 'epic', name: 'Epic Beaker' },
  { id: 'meditech', name: 'Meditech' },
  { id: 'orchard', name: 'Orchard Harvest' },
  { id: 'sunquest', name: 'Sunquest' },
  { id: 'custom', name: 'Custom LIS' },
];

export const LabUpload: React.FC<LabUploadProps> = ({
  onUpload,
  onParseHL7,
  onConnectLIS,
  className = ''
}) => {
  const [activeTab, setActiveTab] = useState<'upload' | 'hl7' | 'lis'>('upload');
  const [dragActive, setDragActive] = useState(false);
  const [files, setFiles] = useState<File[]>([]);
  const [uploading, setUploading] = useState(false);
  const [hl7Message, setHl7Message] = useState('');
  const [lisConfig, setLisConfig] = useState<LISConfig>({
    system: 'cerner',
    url: '',
    apiKey: ''
  });
  const [connected, setConnected] = useState(false);
  
  const handleDrag = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    if (e.type === 'dragenter' || e.type === 'dragover') {
      setDragActive(true);
    } else if (e.type === 'dragleave') {
      setDragActive(false);
    }
  }, []);
  
  const handleDrop = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setDragActive(false);
    
    if (e.dataTransfer.files && e.dataTransfer.files.length > 0) {
      const newFiles = Array.from(e.dataTransfer.files);
      setFiles(prev => [...prev, ...newFiles]);
    }
  }, []);
  
  const handleFileSelect = useCallback((e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files.length > 0) {
      const newFiles = Array.from(e.target.files);
      setFiles(prev => [...prev, ...newFiles]);
    }
  }, []);
  
  const removeFile = useCallback((index: number) => {
    setFiles(prev => prev.filter((_, i) => i !== index));
  }, []);
  
  const handleUpload = useCallback(async () => {
    if (files.length === 0) return;
    
    setUploading(true);
    
    // Simulate upload
    await new Promise(resolve => setTimeout(resolve, 2000));
    
    onUpload?.(files);
    setFiles([]);
    setUploading(false);
  }, [files, onUpload]);
  
  const handleHL7Parse = useCallback(() => {
    if (!hl7Message.trim()) return;
    onParseHL7?.(hl7Message);
    setHl7Message('');
  }, [hl7Message, onParseHL7]);
  
  const handleLISConnect = useCallback(async () => {
    if (!lisConfig.url) return;
    
    setUploading(true);
    
    // Simulate connection
    await new Promise(resolve => setTimeout(resolve, 1500));
    
    onConnectLIS?.(lisConfig);
    setConnected(true);
    setUploading(false);
  }, [lisConfig, onConnectLIS]);
  
  return (
    <div className={cn('glass rounded-2xl overflow-hidden', className)}>
      {/* Tabs */}
      <div className="flex border-b border-slate-700/50">
        <button
          onClick={() => setActiveTab('upload')}
          className={cn(
            'flex-1 px-4 py-3 text-sm font-medium transition-colors relative',
            activeTab === 'upload' ? 'text-white' : 'text-slate-400 hover:text-slate-300'
          )}
        >
          <div className="flex items-center justify-center gap-2">
            <Upload className="w-4 h-4" />
            File Upload
          </div>
          {activeTab === 'upload' && (
            <div className="absolute bottom-0 left-0 right-0 h-0.5 bg-gradient-to-r from-purple-500 to-pink-500" />
          )}
        </button>
        <button
          onClick={() => setActiveTab('hl7')}
          className={cn(
            'flex-1 px-4 py-3 text-sm font-medium transition-colors relative',
            activeTab === 'hl7' ? 'text-white' : 'text-slate-400 hover:text-slate-300'
          )}
        >
          <div className="flex items-center justify-center gap-2">
            <Database className="w-4 h-4" />
            HL7 Message
          </div>
          {activeTab === 'hl7' && (
            <div className="absolute bottom-0 left-0 right-0 h-0.5 bg-gradient-to-r from-purple-500 to-pink-500" />
          )}
        </button>
        <button
          onClick={() => setActiveTab('lis')}
          className={cn(
            'flex-1 px-4 py-3 text-sm font-medium transition-colors relative',
            activeTab === 'lis' ? 'text-white' : 'text-slate-400 hover:text-slate-300'
          )}
        >
          <div className="flex items-center justify-center gap-2">
            <Link className="w-4 h-4" />
            LIS Integration
          </div>
          {activeTab === 'lis' && (
            <div className="absolute bottom-0 left-0 right-0 h-0.5 bg-gradient-to-r from-purple-500 to-pink-500" />
          )}
        </button>
      </div>
      
      {/* Content */}
      <div className="p-6">
        {activeTab === 'upload' && (
          <div className="space-y-4">
            {/* Drop Zone */}
            <div
              onDragEnter={handleDrag}
              onDragLeave={handleDrag}
              onDragOver={handleDrag}
              onDrop={handleDrop}
              className={cn(
                'border-2 border-dashed rounded-xl p-8 text-center transition-all',
                dragActive 
                  ? 'border-purple-500 bg-purple-500/10' 
                  : 'border-slate-700 bg-slate-800/30 hover:border-slate-600'
              )}
            >
              <Upload className={cn(
                'w-12 h-12 mx-auto mb-4 transition-colors',
                dragActive ? 'text-purple-400' : 'text-slate-500'
              )} />
              <p className="text-white font-medium mb-2">
                {dragActive ? 'Drop files here' : 'Drag & drop lab reports'}
              </p>
              <p className="text-sm text-slate-400 mb-4">
                or click to browse files
              </p>
              <input
                type="file"
                multiple
                accept=".pdf,.csv,.hl7,.json,.xml"
                onChange={handleFileSelect}
                className="hidden"
                id="lab-file-input"
              />
              <label
                htmlFor="lab-file-input"
                className="inline-flex items-center gap-2 px-4 py-2 bg-slate-700 hover:bg-slate-600 rounded-lg text-sm text-white cursor-pointer transition-colors"
              >
                <ScanLine className="w-4 h-4" />
                Browse Files
              </label>
            </div>
            
            {/* Supported Formats */}
            <div className="flex flex-wrap justify-center gap-2">
              {SUPPORTED_FORMATS.map(({ ext, name, icon: Icon }) => (
                <div 
                  key={ext}
                  className="flex items-center gap-1.5 px-2 py-1 bg-slate-800/50 rounded text-xs text-slate-400"
                >
                  <Icon className="w-3 h-3" />
                  {name}
                </div>
              ))}
            </div>
            
            {/* File List */}
            {files.length > 0 && (
              <div className="space-y-2">
                <p className="text-sm text-slate-400">Selected files ({files.length}):</p>
                {files.map((file, index) => (
                  <div 
                    key={index}
                    className="flex items-center justify-between bg-slate-800/50 rounded-lg p-3"
                  >
                    <div className="flex items-center gap-3">
                      <FileText className="w-5 h-5 text-purple-400" />
                      <div>
                        <p className="text-sm text-white">{file.name}</p>
                        <p className="text-xs text-slate-500">
                          {(file.size / 1024).toFixed(1)} KB
                        </p>
                      </div>
                    </div>
                    <button
                      onClick={() => removeFile(index)}
                      className="p-1.5 hover:bg-slate-700 rounded text-slate-400 hover:text-red-400 transition-colors"
                    >
                      <X className="w-4 h-4" />
                    </button>
                  </div>
                ))}
                
                <button
                  onClick={handleUpload}
                  disabled={uploading}
                  className={cn(
                    'w-full py-3 rounded-lg font-medium text-white transition-all flex items-center justify-center gap-2',
                    uploading 
                      ? 'bg-slate-700 cursor-not-allowed' 
                      : 'bg-gradient-to-r from-purple-600 to-pink-500 hover:shadow-lg hover:shadow-purple-500/25'
                  )}
                >
                  {uploading ? (
                    <>
                      <Loader2 className="w-5 h-5 animate-spin" />
                      Uploading & Parsing...
                    </>
                  ) : (
                    <>
                      <Upload className="w-5 h-5" />
                      Upload & Analyze
                    </>
                  )}
                </button>
              </div>
            )}
          </div>
        )}
        
        {activeTab === 'hl7' && (
          <div className="space-y-4">
            <div>
              <label className="block text-sm text-slate-400 mb-2">
                Paste HL7 Message
              </label>
              <textarea
                value={hl7Message}
                onChange={(e) => setHl7Message(e.target.value)}
                placeholder="MSH|^~\\&|LAB|HOSPITAL|..."
                className="w-full h-48 bg-slate-800/50 border border-slate-700/50 rounded-lg p-3 text-xs font-mono text-slate-300 placeholder-slate-600 focus:outline-none focus:border-purple-500/50 resize-none"
              />
            </div>
            
            <div className="bg-slate-800/30 rounded-lg p-3">
              <p className="text-xs text-slate-400 flex items-center gap-2">
                <Info className="w-4 h-4" />
                HL7 v2.x messages will be parsed automatically
              </p>
            </div>
            
            <button
              onClick={handleHL7Parse}
              disabled={!hl7Message.trim()}
              className={cn(
                'w-full py-3 rounded-lg font-medium text-white transition-all flex items-center justify-center gap-2',
                !hl7Message.trim()
                  ? 'bg-slate-700 cursor-not-allowed'
                  : 'bg-gradient-to-r from-purple-600 to-pink-500 hover:shadow-lg hover:shadow-purple-500/25'
              )}
            >
              <Database className="w-5 h-5" />
              Parse HL7 Message
            </button>
          </div>
        )}
        
        {activeTab === 'lis' && (
          <div className="space-y-4">
            {connected ? (
              <div className="text-center py-8">
                <div className="w-16 h-16 bg-emerald-500/20 rounded-full flex items-center justify-center mx-auto mb-4">
                  <CheckCircle className="w-8 h-8 text-emerald-400" />
                </div>
                <h3 className="text-lg font-semibold text-white">Connected to LIS</h3>
                <p className="text-sm text-slate-400 mt-2">
                  {LIS_SYSTEMS.find(s => s.id === lisConfig.system)?.name}
                </p>
                <button
                  onClick={() => setConnected(false)}
                  className="mt-4 text-sm text-slate-400 hover:text-white transition-colors"
                >
                  Disconnect
                </button>
              </div>
            ) : (
              <>
                <div>
                  <label className="block text-sm text-slate-400 mb-2">
                    LIS System
                  </label>
                  <select
                    value={lisConfig.system}
                    onChange={(e) => setLisConfig(prev => ({ ...prev, system: e.target.value }))}
                    className="w-full bg-slate-800/50 border border-slate-700/50 rounded-lg px-3 py-2 text-sm text-white focus:outline-none focus:border-purple-500/50"
                  >
                    {LIS_SYSTEMS.map((system) => (
                      <option key={system.id} value={system.id}>
                        {system.name}
                      </option>
                    ))}
                  </select>
                </div>
                
                <div>
                  <label className="block text-sm text-slate-400 mb-2">
                    API Endpoint URL
                  </label>
                  <input
                    type="text"
                    value={lisConfig.url}
                    onChange={(e) => setLisConfig(prev => ({ ...prev, url: e.target.value }))}
                    placeholder="https://lis.hospital.com/api/v1"
                    className="w-full bg-slate-800/50 border border-slate-700/50 rounded-lg px-3 py-2 text-sm text-white placeholder-slate-600 focus:outline-none focus:border-purple-500/50"
                  />
                </div>
                
                <div>
                  <label className="block text-sm text-slate-400 mb-2">
                    API Key (optional)
                  </label>
                  <input
                    type="password"
                    value={lisConfig.apiKey}
                    onChange={(e) => setLisConfig(prev => ({ ...prev, apiKey: e.target.value }))}
                    placeholder="••••••••••••••••"
                    className="w-full bg-slate-800/50 border border-slate-700/50 rounded-lg px-3 py-2 text-sm text-white placeholder-slate-600 focus:outline-none focus:border-purple-500/50"
                  />
                </div>
                
                <div className="bg-slate-800/30 rounded-lg p-3">
                  <p className="text-xs text-slate-400 flex items-center gap-2">
                    <AlertCircle className="w-4 h-4" />
                    Connection will be encrypted with TLS 1.3
                  </p>
                </div>
                
                <button
                  onClick={handleLISConnect}
                  disabled={!lisConfig.url || uploading}
                  className={cn(
                    'w-full py-3 rounded-lg font-medium text-white transition-all flex items-center justify-center gap-2',
                    !lisConfig.url || uploading
                      ? 'bg-slate-700 cursor-not-allowed'
                      : 'bg-gradient-to-r from-purple-600 to-pink-500 hover:shadow-lg hover:shadow-purple-500/25'
                  )}
                >
                  {uploading ? (
                    <>
                      <Loader2 className="w-5 h-5 animate-spin" />
                      Connecting...
                    </>
                  ) : (
                    <>
                      <Link className="w-5 h-5" />
                      Connect to LIS
                    </>
                  )}
                </button>
              </>
            )}
          </div>
        )}
      </div>
    </div>
  );
};

export default LabUpload;
