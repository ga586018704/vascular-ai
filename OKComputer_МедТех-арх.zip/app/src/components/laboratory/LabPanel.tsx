import { useState, useMemo, useCallback } from 'react';
import { 
  FlaskConical, 
  TrendingUp, 
  TrendingDown, 
  AlertTriangle, 
  CheckCircle, 
  Brain,
  Activity,
  Droplets,
  Microscope,
  Dna,
  ChevronRight,
  Search,
  Info,
  Zap,
  Shield,
  AlertOctagon,
  Beaker,
  TestTube,
  Syringe,
  Thermometer
} from 'lucide-react';
import type { 
  LabTest, 
  LabPanel, 
  LabCategory, 
  TestStatus,
  LabAIDiagnosis,
  ClinicalAlert 
} from '@/types/laboratory';
import { cn } from '@/lib/utils';

// Status Badge Component
const StatusBadge: React.FC<{ status: TestStatus; showIcon?: boolean }> = ({ status, showIcon = true }) => {
  const configs: Record<TestStatus, { bg: string; text: string; icon: React.ElementType }> = {
    normal: { bg: 'bg-emerald-500/20', text: 'text-emerald-400', icon: CheckCircle },
    low: { bg: 'bg-amber-500/20', text: 'text-amber-400', icon: TrendingDown },
    high: { bg: 'bg-orange-500/20', text: 'text-orange-400', icon: TrendingUp },
    critical_low: { bg: 'bg-red-500/20', text: 'text-red-400', icon: AlertOctagon },
    critical_high: { bg: 'bg-red-500/20', text: 'text-red-400', icon: AlertOctagon },
    borderline: { bg: 'bg-blue-500/20', text: 'text-blue-400', icon: Info },
  };
  
  const config = configs[status];
  const Icon = config.icon;
  
  return (
    <span className={cn(
      'inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-xs font-medium',
      config.bg,
      config.text
    )}>
      {showIcon && <Icon className="w-3 h-3" />}
      <span className="uppercase">{status.replace('_', ' ')}</span>
    </span>
  );
};

// Category Icon
const CategoryIcon: React.FC<{ category: LabCategory; className?: string }> = ({ category, className }) => {
  const icons: Record<LabCategory, React.ElementType> = {
    hematology: Droplets,
    biochemistry: FlaskConical,
    coagulation: Syringe,
    immunology: Shield,
    microbiology: Microscope,
    genetic: Dna,
    tumor_markers: Activity,
    hormones: Thermometer,
    electrolytes: Beaker,
    rare_diseases: TestTube,
  };
  
  const Icon = icons[category] || FlaskConical;
  return <Icon className={className} />;
};

// Lab Test Card
const LabTestCard: React.FC<{
  test: LabTest;
  isExpanded: boolean;
  onToggle: () => void;
}> = ({ test, isExpanded, onToggle }) => {
  const [showTrend, setShowTrend] = useState(false);
  
  const isCritical = test.status === 'critical_low' || test.status === 'critical_high';
  const isAbnormal = test.status !== 'normal' && test.status !== 'borderline';
  
  return (
    <div 
      className={cn(
        'rounded-xl border transition-all duration-200 overflow-hidden',
        isCritical 
          ? 'bg-red-500/10 border-red-500/30' 
          : isAbnormal 
            ? 'bg-amber-500/5 border-amber-500/20'
            : 'bg-slate-800/50 border-slate-700/50',
        isExpanded && (isCritical ? 'ring-1 ring-red-500/50' : 'ring-1 ring-blue-500/30')
      )}
    >
      <div 
        className="p-3 flex items-center gap-3 cursor-pointer"
        onClick={onToggle}
      >
        <StatusBadge status={test.status} />
        
        <div className="flex-1 min-w-0">
          <div className="flex items-center gap-2">
            <span className="font-medium text-white text-sm truncate">{test.name}</span>
            <span className="text-xs text-slate-500">({test.code})</span>
          </div>
          <span className="text-xs text-slate-400">{test.nameRu}</span>
        </div>
        
        <div className="text-right">
          <div className={cn(
            'font-mono font-bold text-lg',
            isCritical ? 'text-red-400' : isAbnormal ? 'text-amber-400' : 'text-cyan-400'
          )}>
            {typeof test.value === 'number' ? test.value.toFixed(2) : test.value}
            <span className="text-sm text-slate-500 ml-1">{test.unit}</span>
          </div>
          <div className="text-xs text-slate-500">
            Ref: {test.referenceRange.min !== undefined && test.referenceRange.max !== undefined 
              ? `${test.referenceRange.min}-${test.referenceRange.max}` 
              : test.referenceRange.text || 'N/A'}
          </div>
        </div>
        
        {test.changePercent !== undefined && (
          <div className={cn(
            'text-xs font-medium px-2 py-1 rounded',
            test.changePercent > 0 
              ? 'bg-emerald-500/20 text-emerald-400' 
              : 'bg-red-500/20 text-red-400'
          )}>
            {test.changePercent > 0 ? '+' : ''}{test.changePercent.toFixed(1)}%
          </div>
        )}
        
        <ChevronRight className={cn(
          'w-5 h-5 text-slate-500 transition-transform',
          isExpanded && 'rotate-90'
        )} />
      </div>
      
      {isExpanded && (
        <div className="px-3 pb-3 border-t border-slate-700/50 pt-3 space-y-3">
          {/* Previous values */}
          {test.previousValue !== undefined && (
            <div className="flex items-center justify-between text-sm">
              <span className="text-slate-400">Previous value:</span>
              <span className="font-mono text-slate-300">
                {test.previousValue.toFixed(2)} {test.unit}
              </span>
            </div>
          )}
          
          {/* Method */}
          {test.method && (
            <div className="flex items-center justify-between text-sm">
              <span className="text-slate-400">Method:</span>
              <span className="text-slate-300">{test.method}</span>
            </div>
          )}
          
          {/* Lab info */}
          {test.labName && (
            <div className="flex items-center justify-between text-sm">
              <span className="text-slate-400">Laboratory:</span>
              <span className="text-slate-300">{test.labName}</span>
            </div>
          )}
          
          {/* Timestamp */}
          <div className="flex items-center justify-between text-sm">
            <span className="text-slate-400">Collected:</span>
            <span className="text-slate-300">{test.timestamp.toLocaleString()}</span>
          </div>
          
          {/* Notes */}
          {test.notes && (
            <div className="bg-slate-900/50 rounded-lg p-2 text-sm">
              <span className="text-slate-400">Notes:</span>
              <p className="text-slate-300 mt-1">{test.notes}</p>
            </div>
          )}
          
          {/* Trend button */}
          <button
            onClick={(e) => {
              e.stopPropagation();
              setShowTrend(!showTrend);
            }}
            className="w-full py-2 bg-slate-700/50 hover:bg-slate-700 rounded-lg text-sm text-slate-300 transition-colors flex items-center justify-center gap-2"
          >
            <Activity className="w-4 h-4" />
            {showTrend ? 'Hide Trend' : 'Show Trend'}
          </button>
          
          {/* Mock trend chart */}
          {showTrend && (
            <div className="h-32 bg-slate-900/50 rounded-lg p-3">
              <div className="h-full flex items-end gap-1">
                {Array.from({ length: 20 }).map((_, i) => {
                  const height = 30 + Math.random() * 50;
                  const isCurrent = i === 19;
                  return (
                    <div
                      key={i}
                      className={cn(
                        'flex-1 rounded-t transition-all',
                        isCurrent 
                          ? 'bg-cyan-500' 
                          : 'bg-slate-700 hover:bg-slate-600'
                      )}
                      style={{ height: `${height}%` }}
                    />
                  );
                })}
              </div>
            </div>
          )}
        </div>
      )}
    </div>
  );
};

// AI Diagnosis Panel
const AIDiagnosisPanel: React.FC<{
  diagnosis?: LabAIDiagnosis;
  isAnalyzing: boolean;
}> = ({ diagnosis, isAnalyzing }) => {
  const [expandedDiff, setExpandedDiff] = useState<string | null>(null);
  
  if (isAnalyzing) {
    return (
      <div className="glass rounded-2xl p-6 flex flex-col items-center justify-center">
        <div className="relative">
          <div className="w-16 h-16 rounded-full border-4 border-blue-500/20 border-t-blue-500 animate-spin" />
          <Brain className="w-8 h-8 text-blue-400 absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2" />
        </div>
        <h3 className="text-lg font-semibold text-white mt-4">AI Analysis in Progress</h3>
        <p className="text-sm text-slate-400 text-center mt-2">
          Analyzing laboratory patterns and cross-referencing with clinical databases...
        </p>
      </div>
    );
  }
  
  if (!diagnosis) {
    return (
      <div className="glass rounded-2xl p-6 flex flex-col items-center justify-center">
        <Brain className="w-12 h-12 text-slate-600" />
        <h3 className="text-lg font-semibold text-slate-400 mt-4">No AI Analysis</h3>
        <p className="text-sm text-slate-500 text-center mt-2">
          Run AI analysis to get diagnostic insights
        </p>
      </div>
    );
  }
  
  return (
    <div className="space-y-4">
      {/* Primary Diagnosis */}
      <div className="glass rounded-2xl p-4 border-l-4 border-blue-500">
        <div className="flex items-center gap-2 mb-2">
          <Brain className="w-5 h-5 text-blue-400" />
          <h4 className="font-semibold text-white">Primary Diagnosis</h4>
          <span className="ml-auto text-xs bg-blue-500/20 text-blue-400 px-2 py-0.5 rounded-full">
            {Math.round(diagnosis.primaryDiagnosis.confidence * 100)}% confidence
          </span>
        </div>
        <h3 className="text-xl font-bold text-white">{diagnosis.primaryDiagnosis.condition}</h3>
        <p className="text-sm text-slate-400 mt-1">ICD-10: {diagnosis.primaryDiagnosis.icd10}</p>
        <p className="text-sm text-slate-300 mt-2">{diagnosis.primaryDiagnosis.explanation}</p>
      </div>
      
      {/* Critical Alerts */}
      {diagnosis.criticalAlerts.length > 0 && (
        <div className="space-y-2">
          <h4 className="font-semibold text-red-400 flex items-center gap-2">
            <AlertOctagon className="w-5 h-5" />
            Critical Alerts ({diagnosis.criticalAlerts.length})
          </h4>
          {diagnosis.criticalAlerts.map((alert, idx) => (
            <div key={idx} className="bg-red-500/10 border border-red-500/30 rounded-xl p-3">
              <div className="flex items-center justify-between">
                <span className="font-medium text-red-400">{alert.parameter}</span>
                <span className="font-mono text-red-300">{alert.value}</span>
              </div>
              <p className="text-sm text-slate-300 mt-1">{alert.action}</p>
            </div>
          ))}
        </div>
      )}
      
      {/* Recognized Patterns */}
      {diagnosis.recognizedPatterns.length > 0 && (
        <div className="space-y-2">
          <h4 className="font-semibold text-amber-400 flex items-center gap-2">
            <Zap className="w-5 h-5" />
            Recognized Patterns
          </h4>
          {diagnosis.recognizedPatterns.map((pattern, idx) => (
            <div key={idx} className="bg-amber-500/10 border border-amber-500/30 rounded-xl p-3">
              <div className="flex items-center justify-between">
                <span className="font-medium text-amber-400">{pattern.pattern}</span>
                <span className={cn(
                  'text-xs px-2 py-0.5 rounded-full',
                  pattern.severity === 'critical' ? 'bg-red-500/20 text-red-400' :
                  pattern.severity === 'severe' ? 'bg-orange-500/20 text-orange-400' :
                  pattern.severity === 'moderate' ? 'bg-amber-500/20 text-amber-400' :
                  'bg-emerald-500/20 text-emerald-400'
                )}>
                  {pattern.severity}
                </span>
              </div>
              <p className="text-sm text-slate-300 mt-1">{pattern.description}</p>
              <span className={cn(
                'text-xs mt-2 inline-block',
                pattern.urgency === 'emergency' ? 'text-red-400' :
                pattern.urgency === 'urgent' ? 'text-amber-400' :
                'text-slate-400'
              )}>
                {pattern.urgency === 'emergency' && <AlertOctagon className="w-3 h-3 inline mr-1" />}
                {pattern.urgency}
              </span>
            </div>
          ))}
        </div>
      )}
      
      {/* Differential Diagnoses */}
      {diagnosis.differentialDiagnoses.length > 0 && (
        <div className="space-y-2">
          <h4 className="font-semibold text-cyan-400 flex items-center gap-2">
            <Activity className="w-5 h-5" />
            Differential Diagnoses
          </h4>
          {diagnosis.differentialDiagnoses.map((diff, idx) => (
            <div 
              key={idx} 
              className="bg-slate-800/50 border border-slate-700/50 rounded-xl overflow-hidden"
            >
              <button
                onClick={() => setExpandedDiff(expandedDiff === diff.condition ? null : diff.condition)}
                className="w-full p-3 flex items-center justify-between"
              >
                <div className="flex items-center gap-3">
                  <span className="text-slate-500">#{idx + 1}</span>
                  <span className="font-medium text-white">{diff.condition}</span>
                  <span className="text-xs text-slate-500">{diff.icd10}</span>
                </div>
                <div className="flex items-center gap-2">
                  <span className="text-xs bg-cyan-500/20 text-cyan-400 px-2 py-0.5 rounded-full">
                    {Math.round(diff.confidence * 100)}%
                  </span>
                  <ChevronRight className={cn(
                    'w-4 h-4 text-slate-500 transition-transform',
                    expandedDiff === diff.condition && 'rotate-90'
                  )} />
                </div>
              </button>
              
              {expandedDiff === diff.condition && (
                <div className="px-3 pb-3 border-t border-slate-700/50 pt-2 space-y-2">
                  <div>
                    <span className="text-xs text-slate-500">Key Findings:</span>
                    <ul className="mt-1 space-y-1">
                      {diff.keyFindings.map((finding, fidx) => (
                        <li key={fidx} className="text-sm text-slate-300 flex items-center gap-2">
                          <CheckCircle className="w-3 h-3 text-emerald-400" />
                          {finding}
                        </li>
                      ))}
                    </ul>
                  </div>
                  <div>
                    <span className="text-xs text-slate-500">Supporting Tests:</span>
                    <div className="flex flex-wrap gap-1 mt-1">
                      {diff.supportingTests.map((test, tidx) => (
                        <span key={tidx} className="text-xs bg-emerald-500/20 text-emerald-400 px-2 py-0.5 rounded">
                          {test}
                        </span>
                      ))}
                    </div>
                  </div>
                </div>
              )}
            </div>
          ))}
        </div>
      )}
      
      {/* Recommendations */}
      {diagnosis.recommendations.length > 0 && (
        <div className="space-y-2">
          <h4 className="font-semibold text-emerald-400 flex items-center gap-2">
            <CheckCircle className="w-5 h-5" />
            AI Recommendations
          </h4>
          {diagnosis.recommendations.map((rec, idx) => (
            <div 
              key={idx}
              className={cn(
                'rounded-xl p-3 border',
                rec.category === 'immediate' ? 'bg-red-500/10 border-red-500/30' :
                rec.category === 'short_term' ? 'bg-amber-500/10 border-amber-500/30' :
                rec.category === 'long_term' ? 'bg-blue-500/10 border-blue-500/30' :
                'bg-emerald-500/10 border-emerald-500/30'
              )}
            >
              <div className="flex items-center gap-2 mb-1">
                <span className={cn(
                  'text-xs px-2 py-0.5 rounded-full uppercase font-medium',
                  rec.category === 'immediate' ? 'bg-red-500/20 text-red-400' :
                  rec.category === 'short_term' ? 'bg-amber-500/20 text-amber-400' :
                  rec.category === 'long_term' ? 'bg-blue-500/20 text-blue-400' :
                  'bg-emerald-500/20 text-emerald-400'
                )}>
                  {rec.category.replace('_', ' ')}
                </span>
                <span className="text-xs text-slate-500">Priority: {rec.priority}</span>
              </div>
              <p className="text-sm text-white font-medium">{rec.action}</p>
              <p className="text-xs text-slate-400 mt-1">{rec.rationale}</p>
            </div>
          ))}
        </div>
      )}
      
      {/* Suggested Tests */}
      {diagnosis.suggestedTests.length > 0 && (
        <div className="space-y-2">
          <h4 className="font-semibold text-purple-400 flex items-center gap-2">
            <FlaskConical className="w-5 h-5" />
            Suggested Additional Tests
          </h4>
          <div className="grid grid-cols-2 gap-2">
            {diagnosis.suggestedTests.map((test, idx) => (
              <div key={idx} className="bg-slate-800/50 rounded-lg p-2 border border-slate-700/50">
                <div className="flex items-center justify-between">
                  <span className="text-sm text-white">{test.test}</span>
                  <span className={cn(
                    'text-xs px-1.5 py-0.5 rounded',
                    test.urgency === 'stat' ? 'bg-red-500/20 text-red-400' :
                    test.urgency === 'urgent' ? 'bg-amber-500/20 text-amber-400' :
                    'bg-slate-600/50 text-slate-400'
                  )}>
                    {test.urgency}
                  </span>
                </div>
                <p className="text-xs text-slate-400 mt-1">{test.rationale}</p>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};

// Main Lab Panel Component
interface LaboratoryPanelProps {
  panels?: LabPanel[];
  aiDiagnosis?: LabAIDiagnosis;
  alerts?: ClinicalAlert[];
  isAnalyzing?: boolean;
  onRunAnalysis?: () => void;
  className?: string;
}

export const LaboratoryPanel: React.FC<LaboratoryPanelProps> = ({
  panels = [],
  aiDiagnosis,
  alerts = [],
  isAnalyzing = false,
  onRunAnalysis,
  className = ''
}) => {
  const [activeCategory, setActiveCategory] = useState<LabCategory | 'all'>('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [expandedTests, setExpandedTests] = useState<Set<string>>(new Set());
  const [activeTab, setActiveTab] = useState<'results' | 'ai' | 'alerts'>('results');
  
  // Filter tests
  const filteredPanels = useMemo(() => {
    return panels.map(panel => ({
      ...panel,
      tests: panel.tests.filter(test => {
        const matchesCategory = activeCategory === 'all' || test.category === activeCategory;
        const matchesSearch = 
          test.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
          test.nameRu.toLowerCase().includes(searchQuery.toLowerCase()) ||
          test.code.toLowerCase().includes(searchQuery.toLowerCase());
        return matchesCategory && matchesSearch;
      })
    })).filter(panel => panel.tests.length > 0);
  }, [panels, activeCategory, searchQuery]);
  
  // Statistics
  const stats = useMemo(() => {
    const allTests = panels.flatMap(p => p.tests);
    return {
      total: allTests.length,
      normal: allTests.filter(t => t.status === 'normal').length,
      abnormal: allTests.filter(t => ['low', 'high', 'borderline'].includes(t.status)).length,
      critical: allTests.filter(t => ['critical_low', 'critical_high'].includes(t.status)).length,
    };
  }, [panels]);
  
  const toggleTest = useCallback((testId: string) => {
    setExpandedTests(prev => {
      const next = new Set(prev);
      if (next.has(testId)) {
        next.delete(testId);
      } else {
        next.add(testId);
      }
      return next;
    });
  }, []);
  
  const categories: { value: LabCategory | 'all'; label: string; icon: React.ElementType }[] = [
    { value: 'all', label: 'All Tests', icon: FlaskConical },
    { value: 'hematology', label: 'Hematology', icon: Droplets },
    { value: 'biochemistry', label: 'Biochemistry', icon: Beaker },
    { value: 'coagulation', label: 'Coagulation', icon: Syringe },
    { value: 'immunology', label: 'Immunology', icon: Shield },
    { value: 'rare_diseases', label: 'Rare Diseases', icon: Dna },
  ];
  
  return (
    <div className={cn('flex flex-col h-full', className)}>
      {/* Header */}
      <div className="p-4 border-b border-slate-700/50">
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-purple-500 to-pink-500 flex items-center justify-center">
              <FlaskConical className="w-5 h-5 text-white" />
            </div>
            <div>
              <h2 className="font-bold text-white text-lg">Laboratory Results</h2>
              <p className="text-xs text-slate-400">AI-Powered Hematology & Transfusion Analysis</p>
            </div>
          </div>
          
          <button
            onClick={onRunAnalysis}
            disabled={isAnalyzing}
            className={cn(
              'flex items-center gap-2 px-4 py-2 rounded-lg font-medium text-sm transition-all',
              isAnalyzing 
                ? 'bg-slate-800 text-slate-400 cursor-not-allowed'
                : 'bg-gradient-to-r from-purple-600 to-pink-500 text-white hover:shadow-lg hover:shadow-purple-500/25'
            )}
          >
            {isAnalyzing ? (
              <>
                <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                Analyzing...
              </>
            ) : (
              <>
                <Brain className="w-4 h-4" />
                Run AI Analysis
              </>
            )}
          </button>
        </div>
        
        {/* Statistics */}
        <div className="grid grid-cols-4 gap-2 mb-4">
          <div className="bg-slate-800/50 rounded-lg p-2 text-center">
            <div className="text-2xl font-bold text-white">{stats.total}</div>
            <div className="text-xs text-slate-400">Total Tests</div>
          </div>
          <div className="bg-emerald-500/10 rounded-lg p-2 text-center">
            <div className="text-2xl font-bold text-emerald-400">{stats.normal}</div>
            <div className="text-xs text-emerald-400/70">Normal</div>
          </div>
          <div className="bg-amber-500/10 rounded-lg p-2 text-center">
            <div className="text-2xl font-bold text-amber-400">{stats.abnormal}</div>
            <div className="text-xs text-amber-400/70">Abnormal</div>
          </div>
          <div className="bg-red-500/10 rounded-lg p-2 text-center">
            <div className="text-2xl font-bold text-red-400">{stats.critical}</div>
            <div className="text-xs text-red-400/70">Critical</div>
          </div>
        </div>
        
        {/* Tabs */}
        <div className="flex border-b border-slate-700/50">
          <button
            onClick={() => setActiveTab('results')}
            className={cn(
              'flex-1 px-4 py-2 text-sm font-medium transition-colors relative',
              activeTab === 'results' ? 'text-white' : 'text-slate-400 hover:text-slate-300'
            )}
          >
            <div className="flex items-center justify-center gap-2">
              <TestTube className="w-4 h-4" />
              Results
            </div>
            {activeTab === 'results' && (
              <div className="absolute bottom-0 left-0 right-0 h-0.5 bg-gradient-to-r from-purple-500 to-pink-500" />
            )}
          </button>
          <button
            onClick={() => setActiveTab('ai')}
            className={cn(
              'flex-1 px-4 py-2 text-sm font-medium transition-colors relative',
              activeTab === 'ai' ? 'text-white' : 'text-slate-400 hover:text-slate-300'
            )}
          >
            <div className="flex items-center justify-center gap-2">
              <Brain className="w-4 h-4" />
              AI Diagnosis
            </div>
            {activeTab === 'ai' && (
              <div className="absolute bottom-0 left-0 right-0 h-0.5 bg-gradient-to-r from-purple-500 to-pink-500" />
            )}
          </button>
          <button
            onClick={() => setActiveTab('alerts')}
            className={cn(
              'flex-1 px-4 py-2 text-sm font-medium transition-colors relative',
              activeTab === 'alerts' ? 'text-white' : 'text-slate-400 hover:text-slate-300'
            )}
          >
            <div className="flex items-center justify-center gap-2">
              <AlertTriangle className="w-4 h-4" />
              Alerts
              {alerts.length > 0 && (
                <span className="bg-red-500 text-white text-xs px-1.5 py-0.5 rounded-full">
                  {alerts.length}
                </span>
              )}
            </div>
            {activeTab === 'alerts' && (
              <div className="absolute bottom-0 left-0 right-0 h-0.5 bg-gradient-to-r from-purple-500 to-pink-500" />
            )}
          </button>
        </div>
      </div>
      
      {/* Content */}
      <div className="flex-1 overflow-auto">
        {activeTab === 'results' && (
          <>
            {/* Search & Filter */}
            <div className="p-4 space-y-3">
              <div className="relative">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-500" />
                <input
                  type="text"
                  placeholder="Search tests..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="w-full bg-slate-800/50 border border-slate-700/50 rounded-lg pl-10 pr-4 py-2 text-sm text-white placeholder-slate-500 focus:outline-none focus:border-purple-500/50"
                />
              </div>
              
              <div className="flex gap-2 overflow-x-auto pb-1">
                {categories.map(({ value, label, icon: Icon }) => (
                  <button
                    key={value}
                    onClick={() => setActiveCategory(value)}
                    className={cn(
                      'flex items-center gap-2 px-3 py-1.5 rounded-lg text-xs font-medium whitespace-nowrap transition-colors',
                      activeCategory === value
                        ? 'bg-purple-500/20 text-purple-400 border border-purple-500/30'
                        : 'bg-slate-800/50 text-slate-400 border border-slate-700/50 hover:bg-slate-700/50'
                    )}
                  >
                    <Icon className="w-3.5 h-3.5" />
                    {label}
                  </button>
                ))}
              </div>
            </div>
            
            {/* Test Results */}
            <div className="px-4 pb-4 space-y-4">
              {filteredPanels.map((panel) => (
                <div key={panel.id}>
                  <div className="flex items-center justify-between mb-2">
                    <h4 className="font-medium text-slate-300 flex items-center gap-2">
                      <CategoryIcon category={panel.category} className="w-4 h-4 text-purple-400" />
                      {panel.name}
                    </h4>
                    <span className="text-xs text-slate-500">
                      {panel.collectedAt.toLocaleDateString()}
                    </span>
                  </div>
                  <div className="space-y-2">
                    {panel.tests.map((test) => (
                      <LabTestCard
                        key={test.id}
                        test={test}
                        isExpanded={expandedTests.has(test.id)}
                        onToggle={() => toggleTest(test.id)}
                      />
                    ))}
                  </div>
                </div>
              ))}
              
              {filteredPanels.length === 0 && (
                <div className="text-center py-8">
                  <FlaskConical className="w-12 h-12 text-slate-600 mx-auto" />
                  <p className="text-slate-400 mt-4">No tests found</p>
                </div>
              )}
            </div>
          </>
        )}
        
        {activeTab === 'ai' && (
          <div className="p-4">
            <AIDiagnosisPanel diagnosis={aiDiagnosis} isAnalyzing={isAnalyzing} />
          </div>
        )}
        
        {activeTab === 'alerts' && (
          <div className="p-4 space-y-3">
            {alerts.length === 0 ? (
              <div className="text-center py-8">
                <CheckCircle className="w-12 h-12 text-emerald-500 mx-auto" />
                <p className="text-slate-400 mt-4">No active alerts</p>
              </div>
            ) : (
              alerts.map((alert) => (
                <div
                  key={alert.id}
                  className={cn(
                    'rounded-xl p-4 border',
                    alert.severity === 'life_threatening' ? 'bg-red-500/20 border-red-500/50' :
                    alert.severity === 'critical' ? 'bg-red-500/10 border-red-500/30' :
                    alert.severity === 'warning' ? 'bg-amber-500/10 border-amber-500/30' :
                    'bg-blue-500/10 border-blue-500/30'
                  )}
                >
                  <div className="flex items-start gap-3">
                    {alert.severity === 'life_threatening' || alert.severity === 'critical' ? (
                      <AlertOctagon className="w-5 h-5 text-red-400 shrink-0" />
                    ) : alert.severity === 'warning' ? (
                      <AlertTriangle className="w-5 h-5 text-amber-400 shrink-0" />
                    ) : (
                      <Info className="w-5 h-5 text-blue-400 shrink-0" />
                    )}
                    <div className="flex-1">
                      <h4 className="font-medium text-white">{alert.title}</h4>
                      <p className="text-sm text-slate-300 mt-1">{alert.message}</p>
                      <div className="flex flex-wrap gap-1 mt-2">
                        {alert.relatedTests.map((test, idx) => (
                          <span key={idx} className="text-xs bg-slate-700/50 text-slate-400 px-2 py-0.5 rounded">
                            {test}
                          </span>
                        ))}
                      </div>
                      {alert.actions.length > 0 && (
                        <div className="mt-3 space-y-1">
                          {alert.actions.map((action, idx) => (
                            <div key={idx} className="flex items-center gap-2 text-sm">
                              <span className={cn(
                                'text-xs px-1.5 py-0.5 rounded',
                                action.priority === 'immediate' ? 'bg-red-500/20 text-red-400' :
                                action.priority === 'urgent' ? 'bg-amber-500/20 text-amber-400' :
                                'bg-slate-600/50 text-slate-400'
                              )}>
                                {action.priority}
                              </span>
                              <span className="text-slate-300">{action.description}</span>
                            </div>
                          ))}
                        </div>
                      )}
                    </div>
                  </div>
                </div>
              ))
            )}
          </div>
        )}
      </div>
    </div>
  );
};

export default LaboratoryPanel;
