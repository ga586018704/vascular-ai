import { useState, useMemo } from 'react';
import { 
  Brain, 
  AlertTriangle, 
  CheckCircle, 
  Activity, 
  TrendingUp, 
  TrendingDown,
  ChevronRight,
  ChevronDown,
  Info,
  Target,
  Stethoscope,
  Sparkles,
  Zap,
  Shield,
  Clock
} from 'lucide-react';
import type { AIDiagnosis, AIFinding, TreatmentRecommendation } from '@/types';
import { cn } from '@/lib/utils';

interface AIDiagnosisPanelProps {
  diagnosis?: AIDiagnosis;
  isAnalyzing?: boolean;
  onFindingClick?: (finding: AIFinding) => void;
  onRecommendationClick?: (recommendation: TreatmentRecommendation) => void;
  className?: string;
}

// Severity Badge Component
const SeverityBadge: React.FC<{ severity: string; confidence?: number }> = ({ 
  severity, 
  confidence 
}) => {
  const configs = {
    normal: { bg: 'bg-emerald-500/20', text: 'text-emerald-400', border: 'border-emerald-500/30', icon: CheckCircle },
    low: { bg: 'bg-blue-500/20', text: 'text-blue-400', border: 'border-blue-500/30', icon: Info },
    moderate: { bg: 'bg-amber-500/20', text: 'text-amber-400', border: 'border-amber-500/30', icon: AlertTriangle },
    high: { bg: 'bg-orange-500/20', text: 'text-orange-400', border: 'border-orange-500/30', icon: AlertTriangle },
    critical: { bg: 'bg-red-500/20', text: 'text-red-400', border: 'border-red-500/30', icon: AlertTriangle },
    mild: { bg: 'bg-emerald-500/20', text: 'text-emerald-400', border: 'border-emerald-500/30', icon: CheckCircle },
    severe: { bg: 'bg-red-500/20', text: 'text-red-400', border: 'border-red-500/30', icon: AlertTriangle },
  };
  
  const config = configs[severity as keyof typeof configs] || configs.normal;
  const Icon = config.icon;
  
  return (
    <div className={cn(
      'inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-semibold border',
      config.bg,
      config.text,
      config.border
    )}>
      <Icon className="w-3.5 h-3.5" />
      <span className="uppercase">{severity}</span>
      {confidence !== undefined && (
        <span className="opacity-70">({Math.round(confidence * 100)}%)</span>
      )}
    </div>
  );
};

// Finding Type Icon
const FindingTypeIcon: React.FC<{ type: string }> = ({ type }) => {
  const icons: Record<string, React.ReactNode> = {
    stenosis: <Activity className="w-4 h-4" />,
    aneurysm: <Target className="w-4 h-4" />,
    occlusion: <Shield className="w-4 h-4" />,
    plaque: <TrendingUp className="w-4 h-4" />,
    thrombus: <Zap className="w-4 h-4" />,
    dissection: <TrendingDown className="w-4 h-4" />,
    calcification: <Sparkles className="w-4 h-4" />,
    other: <Stethoscope className="w-4 h-4" />,
  };
  
  return <>{icons[type] || icons.other}</>;
};

// Finding Card Component
const FindingCard: React.FC<{
  finding: AIFinding;
  isExpanded: boolean;
  onToggle: () => void;
  onClick: () => void;
}> = ({ finding, isExpanded, onToggle, onClick }) => {
  return (
    <div 
      className={cn(
        'card-medical cursor-pointer transition-all duration-200',
        isExpanded && 'card-medical-active'
      )}
      onClick={onClick}
    >
      <div className="flex items-start gap-3">
        <div className={cn(
          'w-10 h-10 rounded-lg flex items-center justify-center shrink-0',
          finding.severity === 'severe' ? 'bg-red-500/20 text-red-400' :
          finding.severity === 'moderate' ? 'bg-amber-500/20 text-amber-400' :
          'bg-emerald-500/20 text-emerald-400'
        )}>
          <FindingTypeIcon type={finding.type} />
        </div>
        
        <div className="flex-1 min-w-0">
          <div className="flex items-center justify-between gap-2">
            <h4 className="font-semibold text-white capitalize truncate">
              {finding.type}
            </h4>
            <SeverityBadge severity={finding.severity} confidence={finding.confidence} />
          </div>
          
          <p className="text-sm text-slate-400 mt-1">
            {finding.location.vesselName}
            {finding.location.segment && ` - ${finding.location.segment}`}
            {finding.location.side && ` (${finding.location.side})`}
          </p>
          
          {/* Measurements Preview */}
          {finding.measurements.length > 0 && (
            <div className="flex flex-wrap gap-2 mt-2">
              {finding.measurements.slice(0, 3).map((m, i) => (
                <span 
                  key={i}
                  className={cn(
                    'text-xs px-2 py-0.5 rounded font-mono',
                    m.isAbnormal 
                      ? 'bg-red-500/20 text-red-400' 
                      : 'bg-slate-700/50 text-slate-300'
                  )}
                >
                  {m.type}: {m.value.toFixed(1)} {m.unit}
                </span>
              ))}
              {finding.measurements.length > 3 && (
                <span className="text-xs text-slate-500 px-2 py-0.5">
                  +{finding.measurements.length - 3} more
                </span>
              )}
            </div>
          )}
        </div>
        
        <button
          onClick={(e) => {
            e.stopPropagation();
            onToggle();
          }}
          className="shrink-0 p-1 hover:bg-slate-700 rounded transition-colors"
        >
          {isExpanded ? (
            <ChevronDown className="w-5 h-5 text-slate-400" />
          ) : (
            <ChevronRight className="w-5 h-5 text-slate-400" />
          )}
        </button>
      </div>
      
      {/* Expanded Details */}
      {isExpanded && (
        <div className="mt-4 pt-4 border-t border-slate-700/50 space-y-3">
          <div>
            <h5 className="text-xs font-medium text-slate-500 uppercase tracking-wider mb-1">
              Description
            </h5>
            <p className="text-sm text-slate-300">{finding.description}</p>
          </div>
          
          {/* All Measurements */}
          {finding.measurements.length > 0 && (
            <div>
              <h5 className="text-xs font-medium text-slate-500 uppercase tracking-wider mb-2">
                Measurements
              </h5>
              <div className="grid grid-cols-2 gap-2">
                {finding.measurements.map((m, i) => (
                  <div 
                    key={i}
                    className={cn(
                      'bg-slate-800/50 rounded-lg p-2 border',
                      m.isAbnormal 
                        ? 'border-red-500/30 bg-red-500/5' 
                        : 'border-slate-700'
                    )}
                  >
                    <div className="text-xs text-slate-500 capitalize">{m.type}</div>
                    <div className={cn(
                      'text-lg font-mono font-semibold',
                      m.isAbnormal ? 'text-red-400' : 'text-cyan-400'
                    )}>
                      {m.value.toFixed(2)}
                      <span className="text-sm text-slate-500 ml-1">{m.unit}</span>
                    </div>
                    {m.normalRange && (
                      <div className="text-xs text-slate-500">
                        Normal: {m.normalRange[0]}-{m.normalRange[1]} {m.unit}
                      </div>
                    )}
                  </div>
                ))}
              </div>
            </div>
          )}
          
          {/* Slice Preview */}
          {finding.sliceIndices && finding.sliceIndices.length > 0 && (
            <div>
              <h5 className="text-xs font-medium text-slate-500 uppercase tracking-wider mb-2">
                Affected Slices
              </h5>
              <div className="flex gap-2 flex-wrap">
                {finding.sliceIndices.map((slice, i) => (
                  <span 
                    key={i}
                    className="text-xs bg-slate-800 text-slate-300 px-2 py-1 rounded font-mono"
                  >
                    #{slice}
                  </span>
                ))}
              </div>
            </div>
          )}
        </div>
      )}
    </div>
  );
};

// Recommendation Card Component
const RecommendationCard: React.FC<{
  recommendation: TreatmentRecommendation;
  isSelected: boolean;
  onClick: () => void;
}> = ({ recommendation, isSelected, onClick }) => {
  const approachColors: Record<string, string> = {
    surgical: 'bg-purple-500/20 text-purple-400 border-purple-500/30',
    endovascular: 'bg-cyan-500/20 text-cyan-400 border-cyan-500/30',
    hybrid: 'bg-pink-500/20 text-pink-400 border-pink-500/30',
    conservative: 'bg-emerald-500/20 text-emerald-400 border-emerald-500/30',
    observation: 'bg-slate-500/20 text-slate-400 border-slate-500/30',
  };
  
  const evidenceColors: Record<string, string> = {
    A: 'bg-emerald-500/20 text-emerald-400',
    B: 'bg-blue-500/20 text-blue-400',
    C: 'bg-amber-500/20 text-amber-400',
  };
  
  return (
    <div
      onClick={onClick}
      className={cn(
        'card-medical cursor-pointer transition-all duration-200',
        isSelected && 'ring-2 ring-blue-500 ring-offset-2 ring-offset-slate-900'
      )}
    >
      <div className="flex items-start gap-3">
        <div className={cn(
          'shrink-0 w-12 h-12 rounded-xl flex items-center justify-center text-lg font-bold border',
          approachColors[recommendation.approach] || approachColors.observation
        )}>
          {recommendation.priority}
        </div>
        
        <div className="flex-1 min-w-0">
          <div className="flex items-center gap-2 flex-wrap">
            <span className={cn(
              'text-xs px-2 py-0.5 rounded-full font-medium border uppercase',
              approachColors[recommendation.approach] || approachColors.observation
            )}>
              {recommendation.approach}
            </span>
            <span className={cn(
              'text-xs px-2 py-0.5 rounded-full font-medium',
              evidenceColors[recommendation.evidenceLevel] || evidenceColors.C
            )}>
              Level {recommendation.evidenceLevel}
            </span>
          </div>
          
          <h4 className="font-semibold text-white mt-2">{recommendation.procedure}</h4>
          
          <p className="text-sm text-slate-400 mt-1 line-clamp-2">
            {recommendation.indication}
          </p>
          
          {/* Benefits & Risks */}
          <div className="flex gap-4 mt-3">
            <div className="flex items-center gap-1.5 text-xs">
              <TrendingUp className="w-3.5 h-3.5 text-emerald-400" />
              <span className="text-emerald-400">{recommendation.benefits.length} benefits</span>
            </div>
            <div className="flex items-center gap-1.5 text-xs">
              <TrendingDown className="w-3.5 h-3.5 text-red-400" />
              <span className="text-red-400">{recommendation.risks.length} risks</span>
            </div>
            <div className="flex items-center gap-1.5 text-xs">
              <Target className="w-3.5 h-3.5 text-cyan-400" />
              <span className="text-cyan-400">{Math.round(recommendation.confidence * 100)}% match</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

// Main AI Diagnosis Panel
export const AIDiagnosisPanel: React.FC<AIDiagnosisPanelProps> = ({
  diagnosis,
  isAnalyzing = false,
  onFindingClick,
  onRecommendationClick,
  className = ''
}) => {
  const [expandedFinding, setExpandedFinding] = useState<string | null>(null);
  const [selectedRecommendation, setSelectedRecommendation] = useState<string | null>(null);
  const [activeTab, setActiveTab] = useState<'findings' | 'recommendations'>('findings');
  
  const severityCounts = useMemo(() => {
    if (!diagnosis) return {};
    return diagnosis.findings.reduce((acc, f) => {
      acc[f.severity] = (acc[f.severity] || 0) + 1;
      return acc;
    }, {} as Record<string, number>);
  }, [diagnosis]);
  
  if (isAnalyzing) {
    return (
      <div className={cn('card-medical flex flex-col items-center justify-center py-12', className)}>
        <div className="relative">
          <div className="w-16 h-16 rounded-full border-4 border-blue-500/20 border-t-blue-500 animate-spin" />
          <Brain className="w-8 h-8 text-blue-400 absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2" />
        </div>
        <h3 className="text-lg font-semibold text-white mt-4">AI Analysis in Progress</h3>
        <p className="text-sm text-slate-400 mt-2 text-center max-w-xs">
          Our neural networks are analyzing the imaging data to identify vascular abnormalities...
        </p>
        <div className="flex items-center gap-2 mt-4 text-xs text-slate-500">
          <Clock className="w-4 h-4" />
          <span>Typically takes 30-60 seconds</span>
        </div>
      </div>
    );
  }
  
  if (!diagnosis) {
    return (
      <div className={cn('card-medical flex flex-col items-center justify-center py-12', className)}>
        <div className="w-16 h-16 rounded-full bg-slate-800 flex items-center justify-center">
          <Brain className="w-8 h-8 text-slate-500" />
        </div>
        <h3 className="text-lg font-semibold text-slate-400 mt-4">No Analysis Available</h3>
        <p className="text-sm text-slate-500 mt-2 text-center max-w-xs">
          Upload imaging data and run AI analysis to see findings and recommendations
        </p>
      </div>
    );
  }
  
  return (
    <div className={cn('flex flex-col h-full', className)}>
      {/* Header */}
      <div className="p-4 border-b border-slate-700/50">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-blue-500 to-cyan-500 flex items-center justify-center">
              <Brain className="w-5 h-5 text-white" />
            </div>
            <div>
              <h3 className="font-semibold text-white">AI Diagnosis</h3>
              <p className="text-xs text-slate-400">
                Confidence: {Math.round(diagnosis.overallConfidence * 100)}% • 
                Processed in {(diagnosis.processingTime / 1000).toFixed(1)}s
              </p>
            </div>
          </div>
          <SeverityBadge severity={diagnosis.severity} />
        </div>
        
        {/* Severity Summary */}
        {Object.keys(severityCounts).length > 0 && (
          <div className="flex gap-2 mt-3 flex-wrap">
            {Object.entries(severityCounts).map(([severity, count]) => (
              <div 
                key={severity}
                className={cn(
                  'flex items-center gap-1.5 px-2 py-1 rounded-lg text-xs',
                  severity === 'critical' || severity === 'severe'
                    ? 'bg-red-500/20 text-red-400'
                    : severity === 'moderate'
                    ? 'bg-amber-500/20 text-amber-400'
                    : 'bg-emerald-500/20 text-emerald-400'
                )}
              >
                <span className="font-semibold">{count}</span>
                <span className="capitalize">{severity}</span>
              </div>
            ))}
          </div>
        )}
      </div>
      
      {/* Tabs */}
      <div className="flex border-b border-slate-700/50">
        <button
          onClick={() => setActiveTab('findings')}
          className={cn(
            'flex-1 px-4 py-3 text-sm font-medium transition-colors relative',
            activeTab === 'findings' 
              ? 'text-white' 
              : 'text-slate-400 hover:text-slate-300'
          )}
        >
          <div className="flex items-center justify-center gap-2">
            <Target className="w-4 h-4" />
            Findings
            <span className="bg-slate-700 text-slate-300 px-1.5 py-0.5 rounded-full text-xs">
              {diagnosis.findings.length}
            </span>
          </div>
          {activeTab === 'findings' && (
            <div className="absolute bottom-0 left-0 right-0 h-0.5 bg-gradient-to-r from-blue-500 to-cyan-500" />
          )}
        </button>
        <button
          onClick={() => setActiveTab('recommendations')}
          className={cn(
            'flex-1 px-4 py-3 text-sm font-medium transition-colors relative',
            activeTab === 'recommendations' 
              ? 'text-white' 
              : 'text-slate-400 hover:text-slate-300'
          )}
        >
          <div className="flex items-center justify-center gap-2">
            <Stethoscope className="w-4 h-4" />
            Recommendations
            <span className="bg-slate-700 text-slate-300 px-1.5 py-0.5 rounded-full text-xs">
              {diagnosis.recommendations.length}
            </span>
          </div>
          {activeTab === 'recommendations' && (
            <div className="absolute bottom-0 left-0 right-0 h-0.5 bg-gradient-to-r from-blue-500 to-cyan-500" />
          )}
        </button>
      </div>
      
      {/* Content */}
      <div className="flex-1 overflow-auto p-4 space-y-3">
        {activeTab === 'findings' ? (
          diagnosis.findings.length === 0 ? (
            <div className="text-center py-8">
              <CheckCircle className="w-12 h-12 text-emerald-500 mx-auto" />
              <h4 className="text-lg font-semibold text-white mt-4">No Abnormalities Detected</h4>
              <p className="text-sm text-slate-400 mt-2">
                AI analysis did not identify any significant vascular abnormalities
              </p>
            </div>
          ) : (
            diagnosis.findings.map((finding) => (
              <FindingCard
                key={finding.id}
                finding={finding}
                isExpanded={expandedFinding === finding.id}
                onToggle={() => setExpandedFinding(
                  expandedFinding === finding.id ? null : finding.id
                )}
                onClick={() => onFindingClick?.(finding)}
              />
            ))
          )
        ) : (
          diagnosis.recommendations.length === 0 ? (
            <div className="text-center py-8">
              <Info className="w-12 h-12 text-slate-500 mx-auto" />
              <h4 className="text-lg font-semibold text-slate-400 mt-4">No Recommendations</h4>
              <p className="text-sm text-slate-500 mt-2">
                No treatment recommendations available for current findings
              </p>
            </div>
          ) : (
            diagnosis.recommendations.map((recommendation) => (
              <RecommendationCard
                key={recommendation.id}
                recommendation={recommendation}
                isSelected={selectedRecommendation === recommendation.id}
                onClick={() => {
                  setSelectedRecommendation(recommendation.id);
                  onRecommendationClick?.(recommendation);
                }}
              />
            ))
          )
        )}
      </div>
    </div>
  );
};

export default AIDiagnosisPanel;
