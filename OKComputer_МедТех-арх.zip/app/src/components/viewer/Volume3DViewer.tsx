import { useState, useCallback } from 'react';
import type { Volume3D, AIFinding } from '@/types';
import { cn } from '@/lib/utils';
import { 
  Maximize2, 
  RotateCcw, 
  ZoomIn, 
  ZoomOut,
  Layers,
  Target,
  Crosshair,
  Box
} from 'lucide-react';

interface Volume3DViewerProps {
  volume?: Volume3D;
  findings?: AIFinding[];
  measurements?: Array<{
    start: [number, number, number];
    end: [number, number, number];
    label: string;
    value: string;
  }>;
  onFindingSelect?: (finding: AIFinding) => void;
  className?: string;
}

// Mock slice data generator
const generateMockSlice = (index: number, totalSlices: number): number[][] => {
  const size = 256;
  const slice: number[][] = [];
  for (let y = 0; y < size; y++) {
    const row: number[] = [];
    for (let x = 0; x < size; x++) {
      // Create a circular pattern with some noise
      const cx = size / 2;
      const cy = size / 2;
      const dist = Math.sqrt((x - cx) ** 2 + (y - cy) ** 2);
      const normalizedDist = dist / (size / 2);
      
      // Add vessel-like structures
      let value = 0.3 + Math.random() * 0.1;
      
      // Main vessel (aorta)
      if (normalizedDist < 0.15) {
        value = 0.7 + Math.random() * 0.2;
      }
      
      // Side vessels
      const angle = Math.atan2(y - cy, x - cx);
      if (Math.abs(Math.sin(angle * 3)) < 0.3 && normalizedDist > 0.2 && normalizedDist < 0.4) {
        value = 0.6 + Math.random() * 0.15;
      }
      
      // Add some "pathology" in specific slices
      if (index > totalSlices * 0.4 && index < totalSlices * 0.5) {
        if (normalizedDist > 0.12 && normalizedDist < 0.18) {
          value = 0.4 + Math.random() * 0.1; // Thrombus/aneurysm area
        }
      }
      
      row.push(Math.min(1, Math.max(0, value)));
    }
    slice.push(row);
  }
  return slice;
};

// Slice Viewer Component
const SliceViewer: React.FC<{
  sliceData: number[][];
  windowLevel: number;
  windowWidth: number;
  findings: AIFinding[];
  sliceIndex: number;
  onFindingClick: (finding: AIFinding) => void;
}> = ({ sliceData, windowLevel, windowWidth, findings, sliceIndex, onFindingClick }) => {
  // Apply window/level and convert to canvas
  const canvasRef = (canvas: HTMLCanvasElement | null) => {
    if (!canvas || !sliceData) return;
    
    const ctx = canvas.getContext('2d');
    if (!ctx) return;
    
    const height = sliceData.length;
    const width = sliceData[0]?.length || 0;
    
    canvas.width = width;
    canvas.height = height;
    
    const imageData = ctx.createImageData(width, height);
    const data = imageData.data;
    
    for (let y = 0; y < height; y++) {
      for (let x = 0; x < width; x++) {
        const value = sliceData[y][x];
        const normalized = (value - windowLevel + windowWidth * 0.5) / windowWidth;
        const pixelValue = Math.max(0, Math.min(255, Math.floor(normalized * 255)));
        
        const idx = (y * width + x) * 4;
        // CT Angio colormap (red-yellow)
        data[idx] = pixelValue;     // R
        data[idx + 1] = Math.floor(pixelValue * 0.8 + 50); // G
        data[idx + 2] = Math.floor(pixelValue * 0.3);      // B
        data[idx + 3] = 255;        // A
      }
    }
    
    ctx.putImageData(imageData, 0, 0);
  };
  
  // Find findings that affect this slice
  const relevantFindings = findings.filter(f => 
    f.sliceIndices?.includes(sliceIndex)
  );
  
  return (
    <div className="relative w-full h-full">
      <canvas 
        ref={canvasRef}
        className="w-full h-full object-contain"
        style={{ imageRendering: 'pixelated' }}
      />
      
      {/* Finding markers overlay */}
      {relevantFindings.map((finding) => (
        <button
          key={finding.id}
          onClick={() => onFindingClick(finding)}
          className={cn(
            'absolute w-6 h-6 -ml-3 -mt-3 rounded-full border-2 animate-pulse',
            finding.severity === 'severe' 
              ? 'bg-red-500/50 border-red-400' 
              : finding.severity === 'moderate'
              ? 'bg-amber-500/50 border-amber-400'
              : 'bg-emerald-500/50 border-emerald-400'
          )}
          style={{
            left: '50%',
            top: '50%',
          }}
          title={`${finding.type} - ${finding.location.vesselName}`}
        >
          <Target className="w-3 h-3 text-white absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2" />
        </button>
      ))}
    </div>
  );
};

// 3D Mock Viewer
const Viewer3D: React.FC<{
  volume?: Volume3D;
  findings: AIFinding[];
}> = ({ volume, findings }) => {
  return (
    <div className="w-full h-full flex items-center justify-center bg-gradient-to-b from-slate-900 to-slate-800">
      <div className="text-center">
        <Box className="w-24 h-24 text-slate-600 mx-auto mb-4" />
        <h3 className="text-lg font-semibold text-slate-400">3D Volume Rendering</h3>
        <p className="text-sm text-slate-500 mt-2">
          {volume ? 
            `${volume.dimensions[0]}×${volume.dimensions[1]}×${volume.dimensions[2]} voxels` : 
            'No volume data loaded'}
        </p>
        <div className="mt-4 flex gap-2 justify-center">
          {findings.map((f) => (
            <span 
              key={f.id}
              className={cn(
                'text-xs px-2 py-1 rounded-full',
                f.severity === 'severe' ? 'bg-red-500/20 text-red-400' :
                f.severity === 'moderate' ? 'bg-amber-500/20 text-amber-400' :
                'bg-emerald-500/20 text-emerald-400'
              )}
            >
              {f.type}
            </span>
          ))}
        </div>
      </div>
    </div>
  );
};

// Main Volume 3D Viewer Component
export function Volume3DViewer({
  volume,
  findings = [],
  measurements = [],
  onFindingSelect,
  className = ''
}: Volume3DViewerProps) {
  const [slicePlane, setSlicePlane] = useState<'axial' | 'sagittal' | 'coronal' | '3d'>('axial');
  const [sliceIndex, setSliceIndex] = useState(volume ? Math.floor(volume.dimensions[2] / 2) : 128);
  const [windowLevel, setWindowLevel] = useState(0.5);
  const [windowWidth, setWindowWidth] = useState(1.0);
  const [zoom, setZoom] = useState(1);
  
  const totalSlices = volume?.dimensions[2] || 256;
  
  // Generate mock slice data
  const sliceData = generateMockSlice(sliceIndex, totalSlices);
  
  const handleSliceChange = useCallback((delta: number) => {
    setSliceIndex(prev => Math.max(0, Math.min(totalSlices - 1, prev + delta)));
  }, [totalSlices]);
  
  const handleFindingClick = useCallback((finding: AIFinding) => {
    onFindingSelect?.(finding);
  }, [onFindingSelect]);
  
  return (
    <div className={`viewer-3d flex flex-col ${className}`}>
      {/* Toolbar */}
      <div className="flex items-center justify-between p-3 border-b border-slate-700 bg-slate-900/50">
        <div className="flex items-center gap-2">
          <span className="text-xs text-slate-400 font-medium">VIEW:</span>
          {(['axial', 'sagittal', 'coronal', '3d'] as const).map((plane) => (
            <button
              key={plane}
              onClick={() => setSlicePlane(plane)}
              className={`px-3 py-1.5 text-xs font-medium rounded-md transition-all ${
                slicePlane === plane
                  ? 'bg-blue-600 text-white'
                  : 'bg-slate-800 text-slate-300 hover:bg-slate-700'
              }`}
            >
              {plane.toUpperCase()}
            </button>
          ))}
        </div>
        
        {slicePlane !== '3d' && (
          <div className="flex items-center gap-3">
            <button
              onClick={() => handleSliceChange(-1)}
              className="w-8 h-8 flex items-center justify-center bg-slate-800 hover:bg-slate-700 rounded-md text-slate-300"
            >
              ←
            </button>
            <span className="text-xs text-slate-400 font-mono min-w-[80px] text-center">
              Slice: {sliceIndex + 1} / {totalSlices}
            </span>
            <button
              onClick={() => handleSliceChange(1)}
              className="w-8 h-8 flex items-center justify-center bg-slate-800 hover:bg-slate-700 rounded-md text-slate-300"
            >
              →
            </button>
          </div>
        )}
        
        <div className="flex items-center gap-2">
          <button 
            onClick={() => setZoom(z => Math.max(0.5, z - 0.1))}
            className="p-1.5 bg-slate-800 hover:bg-slate-700 rounded text-slate-400"
          >
            <ZoomOut className="w-4 h-4" />
          </button>
          <span className="text-xs text-slate-400 font-mono w-12 text-center">{Math.round(zoom * 100)}%</span>
          <button 
            onClick={() => setZoom(z => Math.min(3, z + 0.1))}
            className="p-1.5 bg-slate-800 hover:bg-slate-700 rounded text-slate-400"
          >
            <ZoomIn className="w-4 h-4" />
          </button>
          <div className="w-px h-4 bg-slate-700 mx-1" />
          <button className="p-1.5 bg-slate-800 hover:bg-slate-700 rounded text-slate-400">
            <Maximize2 className="w-4 h-4" />
          </button>
          <button className="p-1.5 bg-slate-800 hover:bg-slate-700 rounded text-slate-400">
            <RotateCcw className="w-4 h-4" />
          </button>
        </div>
      </div>
      
      {/* Viewer Content */}
      <div className="flex-1 relative overflow-hidden">
        {slicePlane === '3d' ? (
          <Viewer3D volume={volume} findings={findings} />
        ) : (
          <SliceViewer
            sliceData={sliceData}
            windowLevel={windowLevel}
            windowWidth={windowWidth}
            findings={findings}
            sliceIndex={sliceIndex}
            onFindingClick={handleFindingClick}
          />
        )}
        
        {/* Overlay Info */}
        <div className="absolute top-4 left-4 pointer-events-none">
          <div className="glass px-3 py-2 rounded-lg">
            <div className="text-xs text-slate-400">Window/Level</div>
            <div className="text-sm font-mono text-cyan-400">
              {Math.round(windowWidth * 1000)} / {Math.round(windowLevel * 1000)}
            </div>
          </div>
        </div>
        
        {/* Findings Count */}
        {findings.length > 0 && (
          <div className="absolute top-4 right-4 pointer-events-none">
            <div className="glass px-3 py-2 rounded-lg">
              <div className="text-xs text-slate-400">AI Findings</div>
              <div className="text-lg font-bold text-red-400">{findings.length}</div>
            </div>
          </div>
        )}
        
        {/* Zoom indicator */}
        <div className="absolute bottom-4 left-4 pointer-events-none">
          <div className="glass px-3 py-2 rounded-lg flex items-center gap-2">
            <Crosshair className="w-4 h-4 text-slate-400" />
            <span className="text-xs text-slate-400 font-mono">{zoom.toFixed(1)}x</span>
          </div>
        </div>
        
        {/* Measurements overlay */}
        {measurements.length > 0 && (
          <div className="absolute bottom-4 right-4 pointer-events-none">
            <div className="glass px-3 py-2 rounded-lg">
              <div className="text-xs text-slate-400">Measurements</div>
              <div className="text-lg font-bold text-cyan-400">{measurements.length}</div>
            </div>
          </div>
        )}
      </div>
      
      {/* Window/Level Controls */}
      <div className="p-3 border-t border-slate-700 bg-slate-900/50">
        <div className="flex items-center gap-4">
          <div className="flex-1">
            <label className="text-xs text-slate-400 mb-1 block">Window Level</label>
            <input
              type="range"
              min="0"
              max="1"
              step="0.01"
              value={windowLevel}
              onChange={(e) => setWindowLevel(parseFloat(e.target.value))}
              className="slider-medical"
            />
          </div>
          <div className="flex-1">
            <label className="text-xs text-slate-400 mb-1 block">Window Width</label>
            <input
              type="range"
              min="0.1"
              max="2"
              step="0.01"
              value={windowWidth}
              onChange={(e) => setWindowWidth(parseFloat(e.target.value))}
              className="slider-medical"
            />
          </div>
          <div className="flex items-center gap-2">
            <Layers className="w-4 h-4 text-slate-400" />
            <select 
              className="bg-slate-800 text-slate-300 text-xs rounded px-2 py-1 border border-slate-700"
              value={slicePlane}
              onChange={(e) => setSlicePlane(e.target.value as any)}
            >
              <option value="axial">Axial</option>
              <option value="sagittal">Sagittal</option>
              <option value="coronal">Coronal</option>
              <option value="3d">3D Volume</option>
            </select>
          </div>
        </div>
      </div>
    </div>
  );
}

export default Volume3DViewer;
