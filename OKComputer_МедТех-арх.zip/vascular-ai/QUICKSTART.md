# VASCULAR.AI - Руководство по быстрому старту

## 🚀 Быстрый старт за 5 минут

```bash
# 1. Клонирование репозитория
git clone https://github.com/your-org/vascular-ai.git
cd vascular-ai

# 2. Запуск через Docker Compose
docker-compose up -d

# 3. Проверка работоспособности
curl http://localhost:8000/health
```

✅ Готово! API доступно по адресу: http://localhost:8000

---

## 📋 Системные требования

### Минимальные (для разработки)
| Компонент | Требование |
|-----------|------------|
| CPU | 4 ядра |
| RAM | 8 GB |
| Disk | 20 GB SSD |
| GPU | Не требуется |

### Рекомендуемые (для production)
| Компонент | Требование |
|-----------|------------|
| CPU | 16+ ядер |
| RAM | 64 GB |
| Disk | 500 GB NVMe SSD |
| GPU | NVIDIA A100 / V100 / RTX 4090 |

### Программное обеспечение
- Docker 24.0+
- Docker Compose 2.20+
- NVIDIA Docker Runtime (для GPU)
- Node.js 20+ (для frontend разработки)
- Python 3.11+ (для backend разработки)

---

## 🔧 Локальная разработка

### Backend (FastAPI)

```bash
# Переход в директорию backend
cd backend

# Создание виртуального окружения
python -m venv venv
source venv/bin/activate  # Windows: venv\Scripts\activate

# Установка зависимостей
pip install -r requirements.txt

# Настройка переменных окружения
cp .env.example .env
# Отредактируйте .env файл

# Запуск миграций
alembic upgrade head

# Запуск сервера разработки
uvicorn app.main:app --reload --host 0.0.0.0 --port 8000
```

### Frontend (React + TypeScript)

```bash
# Переход в директорию frontend
cd frontend

# Установка зависимостей
npm install

# Запуск сервера разработки
npm run dev
```

Frontend доступен по адресу: http://localhost:5173

### AI Service (PyTorch + GPU)

```bash
# Переход в директорию ai-service
cd ai-service

# Создание виртуального окружения
python -m venv venv
source venv/bin/activate

# Установка зависимостей
pip install -r requirements.txt

# Загрузка моделей
python scripts/download_models.py

# Запуск сервиса
python src/main.py
```

---

## 🐳 Docker Compose

### Базовый запуск

```bash
# Запуск всех сервисов
docker-compose up -d

# Просмотр логов
docker-compose logs -f

# Остановка
docker-compose down
```

### Сервисы

| Сервис | Порт | Описание |
|--------|------|----------|
| backend | 8000 | FastAPI сервер |
| frontend | 80 | React приложение |
| ai-service | 8001 | GPU сервис сегментации |
| postgres | 5432 | База данных |
| redis | 6379 | Кэш и очереди |
| minio | 9000 | S3-совместимое хранилище |
| prometheus | 9090 | Метрики |
| grafana | 3000 | Дашборды |

---

## 🧪 Тестирование

### Backend тесты

```bash
cd backend

# Все тесты
pytest

# С покрытием
pytest --cov=app --cov-report=html

# Конкретный модуль
pytest tests/test_security.py -v
```

### Frontend тесты

```bash
cd frontend

# Unit тесты
npm run test

# E2E тесты
npm run test:e2e
```

### AI Service тесты

```bash
cd ai-service

# Тесты моделей
pytest tests/test_models.py

# Тесты сегментации
pytest tests/test_segmentation.py -v
```

---

## 📊 Первоначальная настройка

### 1. Создание суперпользователя

```bash
# Через API
curl -X POST http://localhost:8000/api/v1/auth/register \
  -H "Content-Type: application/json" \
  -d '{
    "email": "admin@vascular.ai",
    "password": "SecurePass123!",
    "first_name": "Admin",
    "last_name": "User",
    "role": "admin"
  }'
```

### 2. Получение токена

```bash
# Login
curl -X POST http://localhost:8000/api/v1/auth/login \
  -H "Content-Type: application/x-www-form-urlencoded" \
  -d "username=admin@vascular.ai&password=SecurePass123!"

# Ответ: {"access_token": "...", "token_type": "bearer"}
```

### 3. Создание тестового пациента

```bash
curl -X POST http://localhost:8000/api/v1/patients \
  -H "Authorization: Bearer $TOKEN" \
  -H "Content-Type: application/json" \
  -d '{
    "first_name": "Иван",
    "last_name": "Петров",
    "date_of_birth": "1975-03-15",
    "gender": "male",
    "mrn": "MRN001"
  }'
```

---

## 🔑 Переменные окружения

### Обязательные

```bash
# База данных
DATABASE_URL=postgresql+asyncpg://user:pass@localhost/vascular_ai

# Безопасность
SECRET_KEY=your-super-secret-key-min-32-chars
ENCRYPTION_KEY=your-encryption-key-for-phi

# AI Service
AI_SERVICE_URL=http://ai-service:8001
MODEL_PATH=/models

# Внешние API
OPENAI_API_KEY=sk-...
ANTHROPIC_API_KEY=sk-ant-...
NCBI_API_KEY=your-ncbi-key
```

### Опциональные

```bash
# Redis
REDIS_URL=redis://localhost:6379/0

# S3/MinIO
S3_ENDPOINT=http://minio:9000
S3_ACCESS_KEY=minioadmin
S3_SECRET_KEY=minioadmin
S3_BUCKET=vascular-ai

# Мониторинг
PROMETHEUS_MULTIPROC_DIR=/tmp/prometheus
```

---

## 🐛 Отладка

### Просмотр логов

```bash
# Все сервисы
docker-compose logs -f

# Конкретный сервис
docker-compose logs -f backend

# Последние 100 строк
docker-compose logs --tail=100 backend
```

### Проверка здоровья

```bash
# Backend
curl http://localhost:8000/health

# AI Service
curl http://localhost:8001/health

# Database
docker-compose exec postgres pg_isready -U postgres
```

### Распространенные проблемы

#### Проблема: `Connection refused` к базе данных
```bash
# Решение: проверить статус PostgreSQL
docker-compose ps postgres
docker-compose logs postgres

# Перезапуск
docker-compose restart postgres
```

#### Проблема: GPU не обнаружен
```bash
# Проверка NVIDIA Docker
nvidia-docker run --rm nvidia/cuda:12.0-base nvidia-smi

# Проверка runtime в docker-compose.yml
# Должно быть: runtime: nvidia
```

#### Проблема: Медленная сегментация
```bash
# Проверка загрузки GPU
nvidia-smi

# Проверка логов AI Service
docker-compose logs ai-service | grep -i "inference"
```

---

## 📚 Полезные команды

### База данных

```bash
# Подключение к PostgreSQL
docker-compose exec postgres psql -U postgres -d vascular_ai

# Создание миграции
cd backend && alembic revision --autogenerate -m "description"

# Откат миграции
alembic downgrade -1
```

### Redis

```bash
# Подключение к Redis
docker-compose exec redis redis-cli

# Очистка кэша
FLUSHALL
```

### MinIO

```bash
# Создание бакета
docker-compose exec minio mc mb local/vascular-ai

# Просмотр файлов
docker-compose exec minio mc ls local/vascular-ai
```

---

## 🔄 CI/CD

### Локальный запуск pipeline

```bash
# Установка act (GitHub Actions локально)
brew install act

# Запуск workflow
act -j test
act -j build
act -j security-scan
```

### Ручной деплой

```bash
# Staging
./scripts/deploy.sh staging

# Production
./scripts/deploy.sh production
```

---

## 📖 Документация API

### Swagger UI
```
http://localhost:8000/docs
```

### ReDoc
```
http://localhost:8000/redoc
```

### OpenAPI Schema
```bash
curl http://localhost:8000/openapi.json > openapi.json
```

---

## 🎯 Примеры использования

### Загрузка DICOM исследования

```bash
# Загрузка файла
curl -X POST http://localhost:8000/api/v1/studies \
  -H "Authorization: Bearer $TOKEN" \
  -F "patient_id=123" \
  -F "study_description=CT Angiography" \
  -F "files=@/path/to/dicom.zip"
```

### Запуск сегментации

```bash
# Сегментация сосудов
curl -X POST http://localhost:8000/api/v1/segmentation \
  -H "Authorization: Bearer $TOKEN" \
  -H "Content-Type: application/json" \
  -d '{
    "study_id": "study-uuid",
    "vessel_types": ["aorta", "iliac_artery"],
    "min_confidence": 0.85
  }'
```

### AI Agent анализ

```bash
# Анализ через AI Agent
curl -X POST http://localhost:8000/api/v1/agents/analyze \
  -H "Authorization: Bearer $TOKEN" \
  -H "Content-Type: application/json" \
  -d '{
    "agent_type": "vascular_surgery",
    "query": "AAA 5.2cm, male, 68 years, hypertension",
    "patient_context": {"age": 68, "gender": "male"}
  }'
```

---

## 🤝 Contributing

### Workflow

1. Создайте feature branch: `git checkout -b feature/amazing-feature`
2. Сделайте изменения и commit: `git commit -m 'Add amazing feature'`
3. Push в remote: `git push origin feature/amazing-feature`
4. Создайте Pull Request

### Code Style

```bash
# Backend - Black + isort
black app/ tests/
isort app/ tests/

# Frontend - ESLint + Prettier
npm run lint
npm run format
```

### Pre-commit hooks

```bash
# Установка
pre-commit install

# Запуск
pre-commit run --all-files
```

---

## 📞 Поддержка

- 📧 Email: support@vascular.ai
- 💬 Slack: #vascular-ai-dev
- 🐛 Issues: https://github.com/your-org/vascular-ai/issues
- 📖 Wiki: https://github.com/your-org/vascular-ai/wiki

---

## 📄 Лицензия

MIT License - см. [LICENSE](LICENSE) файл

---

**Готово к разработке!** 🚀

Если у вас возникли вопросы, обратитесь к [полной документации](VASCULAR_AI_COMPLETE_SUMMARY.md).