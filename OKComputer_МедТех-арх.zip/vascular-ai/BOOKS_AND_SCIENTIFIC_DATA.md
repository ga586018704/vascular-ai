# VASCULAR.AI - Книги и научные данные

## 📚 Интегрированные источники

Платформа VASCULAR.AI интегрирует данные из авторитетных книг и научных источников для обеспечения evidence-based подхода к клинической практике.

---

## Книги в базе данных

### 1. Chronic Venous Disorders of the Lower Limbs: A Surgical Approach

**Авторы:** Subramoniam Vaidyanathan, Riju Ramachandran Menon, Pradeep Jacob, Binni John  
**Издательство:** Springer India  
**Год:** 2015  
**ISBN:** 978-81-322-1991-0  
**DOI:** [10.1007/978-81-322-1991-0](https://link.springer.com/book/10.1007/978-81-322-1991-0)

**Описание:**  
Комплексное руководство по диагностике и лечению хронических венозных заболеваний нижних конечностей. Книга охватывает все современные методы лечения, включая эндовенозные процедуры.

**Интегрированные данные:**
- Классификация CEAP (обновленная 2020)
- Эндовенозная лазерная абляция (EVLA)
- Радиочастотная абляция (RFA)
- Пенная склеротерапия
- Лечение венозных язв

---

### 2. Lymphedema: A Concise Compendium of Theory and Practice

**Авторы:** Byung-Boong Lee, John Bergan, Stanley G. Rockson  
**Издательство:** Springer  
**Год:** 2011  
**ISBN:** 978-0-85729-566-8  
**DOI:** 10.1007/978-0-85729-566-8

**Описание:**  
Исчерпывающее руководство по теории и практике лечения лимфедемы.

**Интегрированные данные:**
- Классификация ISL (International Society of Lymphology)
- Комплексная деконгестивная терапия (CDT)
- Ручной лимфодренаж (MLD)
- Компрессионная терапия

---

### 3. ACR Manual on Contrast Media

**Автор:** American College of Radiology  
**Издательство:** American College of Radiology  
**Год:** 2023  
**URL:** [ACR Contrast Manual](https://www.acr.org/Clinical-Resources/Contrast-Manual)

**Описание:**  
Официальное руководство Американского колледжа радиологии по использованию контрастных веществ.

**Интегрированные данные:**
- Профилактика CIN (контраст-индуцированной нефропатии)
- Управление реакциями на контраст
- Протоколы гидратации
- Противопоказания и меры предосторожности

---

### 4. Complications in Vascular and Endovascular Surgery

**Авторы:** Alain Branchereau, Michael Jacobs  
**Издательство:** Wiley-Blackwell  
**Год:** 2017  
**ISBN:** 978-1-119-23487-3

**Описание:**  
Руководство по осложнениям в сосудистой и эндоваскулярной хирургии.

**Интегрированные данные:**
- Осложнения сосудистого доступа
- Осложнения стентирования
- Управление осложнениями
- Профилактика

---

## Клинические руководства

### ESVS Guidelines 2024

**European Society for Vascular Surgery**

- **Aortic Disease** - Руководство по лечению заболеваний аорты
- **Chronic Limb-Threatening Ischemia** - Руководство по критической ишемии конечностей
- **Management of Atherosclerotic Carotid and Vertebral Artery Disease** - Руководство по стенозу сонных артерий

### ACC/AHA Guidelines

**American College of Cardiology / American Heart Association**

- **Management of PAD** (2016) - Руководство по лечению периферических артериальных заболеваний

### SVS Guidelines

**Society for Vascular Surgery**

- Руководства по венозным заболеваниям
- Руководства по аорте
- Руководства по периферическим артериям

---

## Структура интеграции

### Модели данных

```python
# Ссылка на книгу
BookReference:
  - title: str
  - authors: List[str]
  - year: int
  - publisher: str
  - isbn: str
  - doi: str
  - url: str

# Научные данные
ScientificDataStore:
  - BOOKS: Dict[str, BookReference]
  - VENOUS_DISORDERS: Dict[str, ArticleData]
  - LYMPHEDEMA: Dict[str, ArticleData]
  - CONTRAST_MEDIA: Dict[str, ArticleData]
  - ENDOVASCULAR_COMPLICATIONS: Dict[str, ArticleData]
  - CLINICAL_GUIDELINES: Dict[str, GuidelineData]
```

### Категории данных

| Категория | Источники | Количество записей |
|-----------|-----------|-------------------|
| Венозные заболевания | Springer book | 5+ |
| Лимфедема | Lee, Bergan, Rockson | 2+ |
| Контрастные вещества | ACR Manual | 2+ |
| Эндоваскулярные осложнения | Branchereau, Jacobs | 2+ |
| Клинические руководства | ESVS, ACC/AHA, SVS | 3+ |

---

## Примеры интегрированных данных

### Классификация CEAP

```json
{
  "title": "CEAP Classification of Chronic Venous Disorders",
  "source": "chronic_venous_disorders",
  "content": {
    "clinical_classes": {
      "C0": "Нет видимых признаков венозной болезни",
      "C1": "Телеангиэктазии или ретикулярные вены",
      "C2": "Варикозные вены",
      "C3": "Отеки",
      "C4a": "Пигментация или экзема",
      "C4b": "Липодерматосклероз",
      "C5": "Заживший венозный язвенный дефект",
      "C6": "Активный венозный язвенный дефект"
    },
    "etiology": {
      "Ec": "Врожденная",
      "Ep": "Первичная",
      "Es": "Вторичная (посттромботическая)"
    },
    "anatomy": {
      "As": "Поверхностные вены",
      "Ad": "Глубокие вены",
      "Ap": "Перфорантные вены"
    },
    "pathophysiology": {
      "Pr": "Рефлюкс",
      "Po": "Обструкция"
    }
  },
  "key_points": [
    "CEAP - стандартизированная классификация",
    "Обновлена в 2020 году",
    "Обязательна для документации"
  ]
}
```

### Эндовенозная лазерная абляция

```json
{
  "title": "Эндовенозная лазерная абляция (EVLA)",
  "source": "chronic_venous_disorders",
  "indications": [
    "Варикозные вены GSV/SSV с рефлюксом",
    "CEAP C2-C6",
    "Диаметр вены 2-15 мм"
  ],
  "technique": {
    "anesthesia": "Тумесцентная",
    "energy": "50-100 J/cm",
    "wavelength": "810-1470 nm"
  },
  "outcomes": {
    "success_5y": "93-98%",
    "recurrence": "5-15%",
    "return_to_work": "1-2 дня"
  },
  "key_points": [
    "Золотой стандарт лечения GSV рефлюкса",
    "Может выполняться в амбулаторных условиях"
  ]
}
```

### Профилактика CIN

```json
{
  "title": "Профилактика контраст-индуцированной нефропатии",
  "source": "acrs_contrast_manual",
  "risk_factors": [
    "Хроническая болезнь почек",
    "Диабет",
    "Дегидратация",
    "Сердечная недостаточность"
  ],
  "prevention": {
    "hydration": "Изотонический NaCl 1 мл/кг/ч за 12ч до и после",
    "minimize_dose": "Минимальная доза контраста",
    "discontinue_nephrotoxic": "Отмена нефротоксичных препаратов"
  },
  "contrast_selection": {
    "preferred": "Изоосмолярные (iodixanol)",
    "alternative": "Низкоосмолярные"
  },
  "key_points": [
    "Гидратация - основа профилактики",
    "Оценка СКФ обязательна",
    "Метформин - отменить за 48 часов"
  ]
}
```

---

## API для доступа к данным

### Поиск по книгам

```http
GET /api/v1/kb/search?q=EVLA&source=chronic_venous_disorders
```

### Получить данные по категории

```http
GET /api/v1/kb/categories/venous_disease/articles
```

### Поиск по клиническим руководствам

```http
GET /api/v1/kb/guidelines?organization=ESVS&year=2024
```

---

## Обновление данных

### Процесс интеграции новых источников

1. **Анализ источника**
   - Извлечение ключевых данных
   - Структурирование информации
   - Определение категорий

2. **Валидация**
   - Проверка медицинской точности
   - Соответствие текущим руководствам
   - Рецензирование экспертами

3. **Интеграция**
   - Добавление в `book_data.py`
   - Создание seed-данных
   - Обновление API

4. **Тестирование**
   - Проверка поиска
   - Валидация отображения
   - Тестирование AI агентов

---

## AI интеграция

AI агенты платформы используют данные из книг для:

1. **Evidence-based рекомендаций**
   - Прямые цитаты из авторитетных источников
   - Указание уровня доказательств

2. **Клинического анализа**
   - Сравнение с классификациями (CEAP, ISL)
   - Рекомендации по лечению

3. **Обучения**
   - Обновление базы знаний
   - Интеграция новых исследований

Пример использования:

```python
from app.agents.specialized.phlebology_agent import PhlebologyAgent
from app.knowledge_base.book_data import ScientificDataStore

agent = PhlebologyAgent()

# Анализ с использованием данных из книг
analysis = await agent.analyze(
    query="Варикоз C2, диаметр GSV 8мм",
    include_book_references=True
)

# Результат включает:
# - Рекомендации из ESVS guidelines
# - Данные об EVLA/RFA из Springer book
# - CEAP классификацию
```

---

## Лицензирование

Данные из книг используются в соответствии с:
- Fair use для образовательных целей
- Цитирование источников
- Некоммерческое использование

Для полного доступа к книгам рекомендуется приобрести лицензию у издательств.

---

## Будущие интеграции

### Планируемые источники

- [ ] Rutherford's Vascular Surgery (9th edition)
- [ ] Cronenwett and Johnston's Decision Making in Vascular Surgery
- [ ] Moore's Vascular and Endovascular Surgery
- [ ] Handbook of Venous Disorders (5th edition)
- [ ] Флебология. Руководство для врачей (под ред. С.В. Сapello)

### Обновления

- Ежеквартальное обновление клинических руководств
- Интеграция новых публикаций из PubMed
- Обновление по мере выхода новых изданий книг

---

**Последнее обновление:** Апрель 2024  
**Версия:** 1.0  
**Ответственный:** Medical Content Team