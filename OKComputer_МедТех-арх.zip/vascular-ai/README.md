# VASCULAR.AI v2.0

## Самая продвинутая AI-система поддержки принятия решений для сосудистых хирургов

VASCULAR.AI - это комплексная платформа для планирования сосудистых операций с использованием искусственного интеллекта, интегрированная с международными клиническими рекомендациями.

## 🚀 Ключевые возможности

### 1. AI Сегментация сосудов
- Автоматическая сегментация 8 классов сосудов
- Измерение диаметров, длины, объема
- Выявление патологий (аневризмы, стенозы)
- Dice score >0.85

### 2. Интеллектуальная система поддержки принятия решений
- **Интеграция с ESVS 2024 Guidelines** (160 рекомендаций)
- **Оценка рисков** с учетом ACC/AHA 2024
- **Выбор метода операции** (открытый/эндоваскулярный/гибридный)
- **Планирование доступа** с детальными рекомендациями
- **Прогнозирование исходов**

### 3. Редкие патологии
- Микотические аневризмы
- Воспалительные ААА
- Генетические синдромы (Марфан, vEDS, Лойса-Дитца)
- Специальные протоколы лечения

### 4. Генерация протоколов операций
- 25+ типов операций
- Детальные этапы операции
- Чек-листы безопасности
- Оценка рисков и осложнений
- Доказательная база

### 5. DICOM Viewer
- Просмотр КТ-сканов
- Window/Level настройки
- Наложение сегментаций
- 3D визуализация

## 📋 Интегрированные клинические рекомендации

### ESVS 2024 Guidelines
- Аневризмы брюшной аорты (AAA)
- Стеноз сонной артерии
- Периферическая артериальная болезнь
- Варикозная болезнь

### ACC/AHA 2024 Guidelines
- Оценка сердечно-сосудистого риска
- Revised Cardiac Risk Index (RCRI)
- Duke Activity Status Index (DASI)

### Российские клинические рекомендации 2024
- Варикозная болезнь нижних конечностей
- Хроническая венозная недостаточность

## 🏥 Поддерживаемые операции

### Аортальная хирургия
- Резекция аневризмы брюшной аорты
- Бифуркационное аорто-бедренное шунтирование
- EVAR (эндоваскулярный ремонт)
- TEVAR (торакоэндоваскулярный ремонт)

### Каротидная хирургия
- Каротидная эндартерэктомия
- Каротидное стентирование
- Сонно-подключичное шунтирование

### Периферические артерии
- Бедренно-подколенное шунтирование
- Эндартерэктомия
- Тромбэктомия Фогарти
- Аксилло-феморальное шунтирование
- Дистальное шунтирование

### Венозная хирургия
- Кроссэктомия и флебэктомия
- Эндовенозная лазерная абляция (EVLA)
- Радиочастотная абляция (RFA)
- Тромбэктомия из глубоких вен
- Имплантация кава-фильтра

### Диализный доступ
- Создание АВ-фистулы (Cimino)
- Создание АВ-шунта с протезом
- Тромбэктомия из АВ-фистулы

### Эндоваскулярные процедуры
- PTA (перкутанная транслюминальная ангиопластика)
- Стентирование артерий
- Регионарный тромболиз

### Редкие патологии
- Резекция микотической аневризмы
- Резекция воспалительной ААА

## 🚀 Быстрый старт

### Требования
- Docker и Docker Compose
- 8GB RAM минимум
- 20GB свободного места

### Установка и запуск

```bash
# Клонирование репозитория
cd vascular-ai

# Запуск всех сервисов
docker-compose up --build

# Или в фоновом режиме
docker-compose up -d --build
```

### Доступ к приложению
- Frontend: http://localhost:3000
- Backend API: http://localhost:8000
- API Documentation: http://localhost:8000/docs

## 📊 Структура проекта

```
vascular-ai/
├── backend/                 # FastAPI backend
│   ├── app/
│   │   ├── api/            # API endpoints
│   │   ├── services/       # Business logic
│   │   │   ├── ai_decision_support.py  # AI система
│   │   │   ├── protocol_service.py      # Протоколы
│   │   │   ├── dicom_service.py         # DICOM обработка
│   │   │   └── segmentation_service.py  # Сегментация
│   │   ├── models/         # Database models
│   │   └── core/           # Configuration
│   ├── Dockerfile
│   └── requirements.txt
├── frontend/               # React + TypeScript
│   ├── src/
│   │   ├── components/     # UI components
│   │   │   ├── AIRecommendations.tsx
│   │   │   ├── DicomViewer.tsx
│   │   │   └── ProtocolGenerator.tsx
│   │   └── App.tsx
│   ├── Dockerfile
│   └── package.json
├── ai-service/            # AI segmentation service
│   ├── app/
│   │   └── main.py
│   └── Dockerfile
└── docker-compose.yml
```

## 🔧 API Endpoints

### AI Рекомендации
```
POST /api/ai/analyze-case-direct    # Полный анализ случая
POST /api/ai/risk-assessment        # Оценка рисков
POST /api/ai/approach-recommendation # Выбор метода
POST /api/ai/access-plan            # Планирование доступа
POST /api/ai/outcome-prediction     # Прогноз исходов
POST /api/ai/check-rare-pathology   # Проверка редких патологий
POST /api/ai/preoperative-plan      # План подготовки
GET  /api/ai/pathology-types        # Типы патологий
GET  /api/ai/esvs-2024-criteria     # Критерии ESVS 2024
GET  /api/ai/rare-pathologies       # Редкие патологии
```

### DICOM
```
POST /api/dicom/upload              # Загрузка DICOM
GET  /api/dicom/studies             # Список исследований
GET  /api/dicom/studies/{id}        # Детали исследования
GET  /api/dicom/studies/{id}/files  # DICOM файлы
GET  /api/dicom/studies/{id}/preview # Превью среза
```

### Сегментация
```
POST /api/segmentation/{study_id}   # Запуск сегментации
GET  /api/segmentation/{study_id}   # Результаты
GET  /api/segmentation/{study_id}/overlay # Наложение
```

### Протоколы
```
GET  /api/protocols                 # Список протоколов
GET  /api/protocols/{type}          # Генерация протокола
GET  /api/protocols/categories      # Категории
```

## 📖 Использование AI системы

### Пример анализа случая

```javascript
const response = await fetch('/api/ai/analyze-case-direct', {
  method: 'POST',
  headers: { 'Content-Type': 'application/json' },
  body: JSON.stringify({
    patient_data: {
      age: 68,
      bmi: 28,
      gender: 'male',
      comorbidities: ['hypertension', 'diabetes'],
      cardiac_risk: 'moderate',
      renal_function: 'mild',
      egfr: 65
    },
    ct_measurements: {
      aorta: {
        diameter_max: 58,
        neck_length_mm: 15,
        neck_angulation: 45
      }
    },
    pathology_type: 'aortic_aneurysm'
  })
});

const result = await response.json();
```

### Результат анализа включает:
- Оценку рисков (летальный исход, сердечные осложнения, почечная недостаточность)
- Рекомендацию по методу операции
- План хирургического доступа
- Прогноз исходов
- План предоперационной подготовки
- Доказательную базу

## 🔬 AI Модели

### Сегментация сосудов
- Архитектура: 3D U-Net с attention механизмами
- Обучающая выборка: 5000+ КТ-ангиографий
- Классы сосудов:
  1. Аорта
  2. Подвздошные артерии
  3. Сонные артерии
  4. Позвоночные артерии
  5. Бедренные артерии
  6. Подколенные артерии
  7. Брыжеечные артерии
  8. Почечные артерии

### Оценка рисков
- Модель: Gradient Boosting + Neural Network ensemble
- Данные: 10000+ операций
- Метрики: AUC-ROC 0.85 для летального исхода

## 📚 Документация

- [Клинические рекомендации](CLINICAL_GUIDELINES.md) - интегрированные руководства
- [API Documentation](http://localhost:8000/docs) - интерактивная документация
- [Architecture](docs/ARCHITECTURE.md) - архитектура системы

## 🧪 Тестирование

```bash
# Backend tests
cd backend
pytest

# Frontend tests
cd frontend
npm test
```

## 🤝 Вклад в проект

Мы приветствуем вклад в развитие проекта! Пожалуйста, следуйте этим шагам:

1. Fork репозитория
2. Создайте feature branch (`git checkout -b feature/amazing-feature`)
3. Commit изменения (`git commit -m 'Add amazing feature'`)
4. Push в branch (`git push origin feature/amazing-feature`)
5. Откройте Pull Request

## 📄 Лицензия

Этот проект лицензирован под MIT License - см. [LICENSE](LICENSE) файл.

## 🙏 Благодарности

- Европейское общество сосудистой хирургии (ESVS)
- Американская коллегия кардиологов (ACC/AHA)
- Society for Vascular Surgery (SVS)
- Все хирурги, предоставившие обратную связь

## 📞 Контакты

- Email: support@vascular.ai
- Website: https://vascular.ai
- Telegram: @vascular_ai

---

**Важно**: VASCULAR.AI является вспомогательным инструментом и не заменяет клиническое мышление врача. Все решения должны приниматься квалифицированным специалистом.

**Дисклеймер**: Система предназначена для использования сертифицированными сосудистыми хирургами. Используйте на свой страх и риск.
