import { useState } from 'react'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { Toaster } from '@/components/ui/sonner'
import { toast } from 'sonner'

import Header from './components/Header'
import DicomUpload from './components/DicomUpload'
import StudyList from './components/StudyList'
import DicomViewer from './components/DicomViewer'
import SegmentationPanel from './components/SegmentationPanel'
import ProtocolGenerator from './components/ProtocolGenerator'
import AIRecommendations from './components/AIRecommendations'
import './App.css'

export interface Study {
  id: number
  study_uid: string
  patient_id: string
  description: string
  modality: string
  num_slices: number
  status: string
  created_at: string
}

export interface SegmentationResult {
  id: number
  status: string
  classes: number[]
  dice_scores: Record<string, number>
  measurements: Record<string, VesselMeasurement>
  vessel_details: VesselDetail[]
}

export interface VesselMeasurement {
  diameter_max: number
  diameter_mean: number
  diameter_min: number
  length: number
  volume: number
  has_pathology: boolean
  pathology_type: string | null
  pathology_severity: string | null
}

export interface VesselDetail {
  vessel_name: string
  diameter_max: number
  diameter_mean: number
  length: number
  volume: number
  has_pathology: boolean
  pathology_type: string | null
  pathology_severity: string | null
}

function App() {
  const [selectedStudy, setSelectedStudy] = useState<Study | null>(null)
  const [segmentation, setSegmentation] = useState<SegmentationResult | null>(null)
  const [refreshStudies, setRefreshStudies] = useState(0)

  const handleStudySelect = (study: Study) => {
    setSelectedStudy(study)
    setSegmentation(null)
    toast.info(`Выбрано исследование: ${study.patient_id}`)
  }

  const handleUploadSuccess = () => {
    setRefreshStudies(prev => prev + 1)
    toast.success('DICOM файлы успешно загружены')
  }

  const handleSegmentationComplete = (result: SegmentationResult) => {
    setSegmentation(result)
    toast.success('Сегментация завершена')
  }

  return (
    <div className="min-h-screen bg-slate-50">
      <Header />
      
      <main className="container mx-auto p-4 space-y-6">
        {/* Upload Section */}
        <DicomUpload onUploadSuccess={handleUploadSuccess} />
        
        {/* Main Content Tabs */}
        <Tabs defaultValue="studies" className="w-full">
          <TabsList className="grid w-full grid-cols-5">
            <TabsTrigger value="studies">Исследования</TabsTrigger>
            <TabsTrigger value="viewer" disabled={!selectedStudy}>
              Просмотр КТ
            </TabsTrigger>
            <TabsTrigger value="segmentation" disabled={!selectedStudy}>
              Сегментация
            </TabsTrigger>
            <TabsTrigger value="ai" disabled={!segmentation}>
              🤖 AI
            </TabsTrigger>
            <TabsTrigger value="protocol" disabled={!segmentation}>
              Протокол
            </TabsTrigger>
          </TabsList>
          
          <TabsContent value="studies" className="mt-4">
            <StudyList 
              onSelect={handleStudySelect}
              refreshTrigger={refreshStudies}
            />
          </TabsContent>
          
          <TabsContent value="viewer" className="mt-4">
            {selectedStudy && (
              <DicomViewer study={selectedStudy} />
            )}
          </TabsContent>
          
          <TabsContent value="segmentation" className="mt-4">
            {selectedStudy && (
              <SegmentationPanel 
                study={selectedStudy}
                onSegmentationComplete={handleSegmentationComplete}
              />
            )}
          </TabsContent>
          
          <TabsContent value="ai" className="mt-4">
            {selectedStudy && segmentation && (
              <AIRecommendations 
                study={selectedStudy}
                segmentation={segmentation}
              />
            )}
          </TabsContent>
          
          <TabsContent value="protocol" className="mt-4">
            {selectedStudy && segmentation && (
              <ProtocolGenerator 
                study={selectedStudy}
                segmentation={segmentation}
              />
            )}
          </TabsContent>
        </Tabs>
      </main>
      
      <Toaster position="top-right" />
    </div>
  )
}

export default App
