import axios from 'axios';

const API_URL = import.meta.env.VITE_API_URL || 'http://localhost:8000/api/v1';

const api = axios.create({
  baseURL: `${API_URL}/kb`,
  headers: {
    'Content-Type': 'application/json',
  },
});

api.interceptors.request.use((config) => {
  const token = localStorage.getItem('token');
  if (token) {
    config.headers.Authorization = `Bearer ${token}`;
  }
  return config;
});

export interface SearchParams {
  q: string;
  type?: string;
  category_id?: string;
  tags?: string[];
  page?: number;
  limit?: number;
}

export interface Article {
  id: string;
  code: string;
  title: string;
  article_type: string;
  summary: string;
  content: string;
  view_count: number;
  categories: Category[];
  tags: Tag[];
  source?: {
    book: string;
    authors: string[];
    year: number;
  };
}

export interface Category {
  id: string;
  code: string;
  name: string;
  children?: Category[];
}

export interface Tag {
  id: string;
  code: string;
  name: string;
}

export const knowledgeBaseApi = {
  // Search
  search: async (params: SearchParams) => {
    const response = await api.get('/search', { params });
    return response.data;
  },

  // Articles
  getArticle: async (articleId: string) => {
    const response = await api.get(`/articles/${articleId}`);
    return response.data;
  },

  getArticleByCode: async (code: string) => {
    const response = await api.get(`/articles/by-code/${code}`);
    return response.data;
  },

  getPopularArticles: async (params?: { type?: string; limit?: number }) => {
    const response = await api.get('/articles/popular', { params });
    return response.data;
  },

  getRecentArticles: async (params?: { limit?: number }) => {
    const response = await api.get('/articles/recent', { params });
    return response.data;
  },

  // Categories
  getCategories: async (params?: { parent_id?: string }) => {
    const response = await api.get('/categories', { params });
    return response.data;
  },

  getCategoryTree: async () => {
    const response = await api.get('/categories/tree');
    return response.data;
  },

  getArticlesByCategory: async (categoryId: string, params?: { page?: number; limit?: number }) => {
    const response = await api.get(`/categories/${categoryId}/articles`, { params });
    return response.data;
  },

  // Tags
  getTags: async (params?: { search?: string; limit?: number }) => {
    const response = await api.get('/tags', { params });
    return response.data;
  },

  getArticlesByTag: async (tagCode: string, params?: { page?: number; limit?: number }) => {
    const response = await api.get(`/tags/${tagCode}/articles`, { params });
    return response.data;
  },

  // Medications
  searchMedications: async (params: { q: string; drug_class?: string; limit?: number }) => {
    const response = await api.get('/medications/search', { params });
    return response.data;
  },

  getMedication: async (articleId: string) => {
    const response = await api.get(`/medications/${articleId}`);
    return response.data;
  },

  checkDrugInteractions: async (drugs: string[]) => {
    const response = await api.post('/medications/check-interactions', { drugs });
    return response.data;
  },

  // Diseases
  searchDiseases: async (params: { q: string; body_system?: string; limit?: number }) => {
    const response = await api.get('/diseases/search', { params });
    return response.data;
  },

  getDisease: async (articleId: string) => {
    const response = await api.get(`/diseases/${articleId}`);
    return response.data;
  },

  // Procedures
  searchProcedures: async (params: { q: string; specialty?: string; limit?: number }) => {
    const response = await api.get('/procedures/search', { params });
    return response.data;
  },

  getProcedure: async (articleId: string) => {
    const response = await api.get(`/procedures/${articleId}`);
    return response.data;
  },

  // Guidelines
  getGuidelines: async (params?: { organization?: string; year?: number; page?: number; limit?: number }) => {
    const response = await api.get('/guidelines', { params });
    return response.data;
  },

  getGuideline: async (articleId: string) => {
    const response = await api.get(`/guidelines/${articleId}`);
    return response.data;
  },

  // Favorites
  getFavorites: async (params?: { page?: number; limit?: number }) => {
    const response = await api.get('/favorites', { params });
    return response.data;
  },

  addToFavorites: async (articleId: string, notes?: string) => {
    const response = await api.post(`/favorites/${articleId}`, null, { params: { notes } });
    return response.data;
  },

  removeFromFavorites: async (articleId: string) => {
    const response = await api.delete(`/favorites/${articleId}`);
    return response.data;
  },

  // Quick Reference
  getQuickReference: async (category: string) => {
    const response = await api.get(`/quick-reference/${category}`);
    return response.data;
  },

  // Analytics
  getPopularSearches: async (params?: { days?: number; limit?: number }) => {
    const response = await api.get('/analytics/popular-searches', { params });
    return response.data;
  },

  // Sources
  getSources: async () => {
    const response = await api.get('/sources');
    return response.data;
  },
};

export default knowledgeBaseApi;