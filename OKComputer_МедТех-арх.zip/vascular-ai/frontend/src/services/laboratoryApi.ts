import axios from 'axios';

const API_URL = import.meta.env.VITE_API_URL || 'http://localhost:8000/api/v1';

const api = axios.create({
  baseURL: `${API_URL}/laboratory`,
  headers: {
    'Content-Type': 'application/json',
  },
});

api.interceptors.request.use((config) => {
  const token = localStorage.getItem('token');
  if (token) {
    config.headers.Authorization = `Bearer ${token}`;
  }
  return config;
});

export interface CreateTestRequest {
  patient_id: string;
  test_codes?: string[];
  panel_code?: string;
  priority: 'routine' | 'urgent' | 'stat';
  clinical_indication?: string;
}

export interface TestResult {
  id: string;
  test_code: string;
  test_name: string;
  value_numeric?: number;
  value_text?: string;
  unit?: string;
  reference_min?: number;
  reference_max?: number;
  interpretation: string;
  is_critical: boolean;
  is_abnormal: boolean;
  created_at: string;
}

export interface LaboratoryTest {
  id: string;
  order_number: string;
  patient_id: string;
  doctor_id: string;
  status: string;
  priority: string;
  order_date: string;
  result_date?: string;
  results: TestResult[];
}

export const laboratoryApi = {
  // Tests
  getTests: async (params?: { patient_id?: string; status?: string; page?: number; limit?: number }) => {
    const response = await api.get('/tests', { params });
    return response.data;
  },

  getTest: async (testId: string) => {
    const response = await api.get(`/tests/${testId}`);
    return response.data;
  },

  createTest: async (data: CreateTestRequest) => {
    const response = await api.post('/tests', data);
    return response.data;
  },

  updateTest: async (testId: string, data: Partial<CreateTestRequest>) => {
    const response = await api.put(`/tests/${testId}`, data);
    return response.data;
  },

  cancelTest: async (testId: string, reason: string) => {
    const response = await api.post(`/tests/${testId}/cancel`, null, { params: { reason } });
    return response.data;
  },

  verifyTest: async (testId: string) => {
    const response = await api.post(`/tests/${testId}/verify`);
    return response.data;
  },

  // Results
  addResult: async (testId: string, data: Partial<TestResult>) => {
    const response = await api.post(`/tests/${testId}/results`, data);
    return response.data;
  },

  getResults: async (params: { patient_id: string; test_code?: string; limit?: number }) => {
    const response = await api.get('/results', { params });
    return response.data;
  },

  getTestHistory: async (patientId: string, testCode: string) => {
    const response = await api.get(`/patients/${patientId}/history/${testCode}`);
    return response.data;
  },

  // Panels
  getPanels: async () => {
    const response = await api.get('/panels');
    return response.data;
  },

  getPanel: async (code: string) => {
    const response = await api.get(`/panels/${code}`);
    return response.data;
  },

  // Reference Ranges
  getReferenceRange: async (testCode: string, params?: { gender?: string; age_months?: number }) => {
    const response = await api.get(`/reference-ranges/${testCode}`, { params });
    return response.data;
  },

  // Analysis
  analyze: async (data: {
    patient_id: string;
    test_codes?: string[];
    date_from?: string;
    date_to?: string;
    include_trends?: boolean;
    include_ai_analysis?: boolean;
  }) => {
    const response = await api.post('/analyze', data);
    return response.data;
  },

  compare: async (data: {
    patient_id: string;
    test_codes: string[];
    date_points: string[];
  }) => {
    const response = await api.post('/compare', data);
    return response.data;
  },

  // Statistics
  getStatistics: async (params: { date_from: string; date_to: string; laboratory_id?: string }) => {
    const response = await api.get('/statistics', { params });
    return response.data;
  },

  // Critical Values
  getCriticalValues: async (params?: { patient_id?: string; status?: string }) => {
    const response = await api.get('/critical-values', { params });
    return response.data;
  },

  acknowledgeCriticalValue: async (alertId: string, notes?: string) => {
    const response = await api.post(`/critical-values/${alertId}/acknowledge`, { notes });
    return response.data;
  },
};

export default laboratoryApi;