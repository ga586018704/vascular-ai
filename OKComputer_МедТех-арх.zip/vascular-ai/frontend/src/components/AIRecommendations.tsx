import { useState, useEffect } from 'react'
import { 
  Brain, 
  AlertTriangle, 
  CheckCircle2, 
  Activity,
  User,
  Heart,
  Stethoscope,
  Scissors,
  Zap,
  TrendingUp,
  Clock,
  Shield,
  FileText,
  Loader2,
  ChevronDown,
  ChevronUp,
  Info,
  Dna,
  BookOpen,
  AlertCircle,
  Microscope,
  Calendar
} from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Badge } from '@/components/ui/badge'
import { Separator } from '@/components/ui/separator'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { toast } from 'sonner'
import type { Study, SegmentationResult } from '../App'

interface AIRecommendationsProps {
  study: Study
  segmentation: SegmentationResult
}

interface RiskLevel {
  probability: number
  level: string
}

interface AIAnalysis {
  case_summary: {
    patient_age: number
    pathology: string
    complexity: string
    esvs_class?: string
    urgency: {
      level: string
      timeframe: string
      reason: string
      esvs_recommendation?: string
    }
    summary_text: string
  }
  rare_pathology_alert?: Array<{
    type: string
    severity: string
    message: string
    recommendations: string[]
  }>
  risk_assessment: {
    mortality: RiskLevel & { factors?: string[]; esvs_reference?: string }
    cardiac_complications: RiskLevel & { types?: string[] }
    renal_failure: RiskLevel & { preventive_measures?: string[] }
    infection: RiskLevel & { preventive_measures?: string[] }
    paraplegia?: {
      probability: number
      level: string
      preventive_measures?: string[]
    }
    overall_score: number
    risk_stratification: string
    risk_modification_suggestions?: string[]
  }
  approach_recommendation: {
    type: string
    confidence: string
    rationale: string[]
    contraindications: string[]
    alternative: string
    anatomical_score?: number
    esvs_class?: string
  }
  access_plan: {
    primary?: {
      name: string
      description: string
      length?: string
      advantages: string[]
      disadvantages: string[]
    }
    alternative?: {
      name: string
      description: string
      indications?: string
    }
    position?: string
    special_considerations?: string[] | string
  }
  outcome_prediction: {
    graft_patency: {
      '1_year': string
      '5_year': string
      factors_affecting?: string[]
      improvement_strategies?: string[]
    }
    recovery_time: {
      hospital_stay: string
      return_to_daily_activities: string
      return_to_work?: string
      full_recovery?: string
    }
    quality_of_life?: {
      short_term: string
      long_term: string
    }
    return_to_normal?: {
      driving: string
      light_physical_activity: string
      heavy_physical_activity: string
    }
    long_term_survival?: {
      '1_year': string
      '5_year': string
      '10_year': string
    }
    reintervention_probability?: {
      '1_year': string
      '5_year': string
      common_reasons: string[]
    }
  }
  preoperative_preparation: {
    preparations: Array<{
      specialist: string
      actions: string[]
      timeline: string
    }>
    anesthesia_recommendation: {
      primary: string
      alternative?: string
      monitoring: string[]
      special_considerations?: string[]
    }
    required_blood?: {
      units_required: string
      type: string
      crossmatch: string
    }
    icu_probability?: {
      probability: string
      duration: string
      reason: string
    }
    special_considerations?: string[]
  }
  postoperative_monitoring?: {
    monitoring: Record<string, string>
    complications_to_watch: string[]
    mobilization: string
    anticoagulation: {
      indication: string
      agent: string
      duration: string
    }
    follow_up: string
  }
  evidence_base?: {
    guidelines: string[]
    key_studies: string[]
    recommendation_class: string
    key_points?: string[]
  }
  esvs_2024_compliance?: {
    compliant: boolean
    violations: string[]
    warnings: string[]
  }
  surveillance_plan?: {
    interval_months?: number
    method?: string
    esvs_reference?: string
    schedule?: Array<{time: string; method: string}>
  }
  alternative_options?: Array<{
    option: string
    suitable_for: string
    contraindications: string[]
    advantages: string[]
    disadvantages: string[]
  }>
}

const API_URL = import.meta.env.VITE_API_URL || 'http://localhost:8000'

export default function AIRecommendations({ 
  study, 
  segmentation 
}: AIRecommendationsProps) {
  const [analyzing, setAnalyzing] = useState(false)
  const [analysis, setAnalysis] = useState<AIAnalysis | null>(null)
  const [activeTab, setActiveTab] = useState('patient')
  const [patientData, setPatientData] = useState({
    age: 65,
    bmi: 25,
    gender: 'male',
    comorbidities: [] as string[],
    cardiac_risk: 'low',
    renal_function: 'normal',
    egfr: 90,
    pathology_type: 'aortic_aneurysm',
    genetic_syndrome: '',
    family_history_aaa: false,
    smoking_status: 'never',
    frailty_score: undefined as number | undefined,
    das_score: undefined as number | undefined,
    functional_status: 'independent'
  })
  const [expandedSections, setExpandedSections] = useState<Record<string, boolean>>({
    risks: true,
    approach: true,
    access: true,
    outcome: true,
    preparation: true,
    rarePathology: true,
    evidence: false
  })

  const comorbidityOptions = [
    { id: 'ischemic_heart_disease', label: 'ИБС' },
    { id: 'heart_failure', label: 'ХСН' },
    { id: 'hypertension', label: 'Артериальная гипертензия' },
    { id: 'diabetes', label: 'Сахарный диабет' },
    { id: 'renal_failure', label: 'ХБП' },
    { id: 'copd', label: 'ХОБЛ' },
    { id: 'obesity', label: 'Ожирение' },
    { id: 'cerebrovascular_disease', label: 'Инсульт/ТИА в анамнезе' },
    { id: 'atrial_fibrillation', label: 'Мерцательная аритмия' },
    { id: 'mechanical_heart_valve', label: 'Механический клапан сердца' },
    { id: 'immunosuppression', label: 'Иммуносупрессия' }
  ]

  const pathologyOptions = [
    { id: 'aortic_aneurysm', name: 'Аневризма брюшной аорты', urgency: 'Элективная', esvs: 'Class I' },
    { id: 'aortic_aneurysm_rupture', name: 'Разрыв аневризмы аорты', urgency: 'Экстренная', esvs: 'Class I' },
    { id: 'mycotic_aneurysm', name: 'Микотическая аневризма', urgency: 'Срочная', esvs: 'Class I' },
    { id: 'inflammatory_aaa', name: 'Воспалительная ААА', urgency: 'Элективная', esvs: 'Class IIa' },
    { id: 'carotid_stenosis', name: 'Асимпт. стеноз сонной артерии', urgency: 'Элективная', esvs: 'Class IIa' },
    { id: 'carotid_stenosis_symptomatic', name: 'Симпт. стеноз сонной артерии', urgency: 'Срочная', esvs: 'Class I' },
    { id: 'femoropopliteal_occlusion', name: 'Окклюзия бедренной артерии', urgency: 'Элективная', esvs: 'Class I' },
    { id: 'femoropopliteal_occlusion_critical', name: 'Критическая ишемия', urgency: 'Срочная', esvs: 'Class I' },
    { id: 'acute_arterial_thrombosis', name: 'Острый артериальный тромбоз', urgency: 'Экстренная', esvs: 'Class I' },
    { id: 'acute_deep_vein_thrombosis', name: 'Острый ТГВ', urgency: 'Срочная', esvs: 'Class I' },
    { id: 'varicose_veins', name: 'Варикозная болезнь', urgency: 'Элективная', esvs: 'Class I' },
    { id: 'av_fistula_failure', name: 'Тромбоз АВ-фистулы', urgency: 'Срочная', esvs: 'Class I' },
  ]

  const geneticSyndromeOptions = [
    { id: '', label: 'Нет' },
    { id: 'marfan', label: 'Синдром Марфана (FBN1)' },
    { id: 'vascular_ehlers_danlos', label: 'vEDS (COL3A1)' },
    { id: 'loeyes_dietz', label: 'Синдром Лойса-Дитца (TGFBR1/2)' }
  ]

  // Автоматически запускаем анализ при наличии сегментации
  useEffect(() => {
    if (segmentation?.measurements) {
      // Предзаполняем данные из сегментации
      const aortaDiameter = segmentation.measurements.aorta?.diameter_max
      if (aortaDiameter) {
        toast.info(`Обнаружена аневризма аорты диаметром ${aortaDiameter.toFixed(1)} мм`)
      }
    }
  }, [segmentation])

  const toggleComorbidity = (conditionId: string) => {
    setPatientData(prev => ({
      ...prev,
      comorbidities: prev.comorbidities.includes(conditionId)
        ? prev.comorbidities.filter(c => c !== conditionId)
        : [...prev.comorbidities, conditionId]
    }))
  }

  const runAIAnalysis = async () => {
    try {
      setAnalyzing(true)
      
      // Формируем данные КТ из сегментации
      const ctMeasurements = segmentation?.measurements || {}
      
      const response = await fetch(`${API_URL}/api/ai/analyze-case-direct`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          patient_data: {
            age: patientData.age,
            bmi: patientData.bmi,
            gender: patientData.gender,
            comorbidities: patientData.comorbidities,
            cardiac_risk: patientData.cardiac_risk,
            renal_function: patientData.renal_function,
            egfr: patientData.egfr,
            genetic_syndrome: patientData.genetic_syndrome || undefined,
            family_history_aaa: patientData.family_history_aaa,
            smoking_status: patientData.smoking_status,
            frailty_score: patientData.frailty_score,
            das_score: patientData.das_score,
            functional_status: patientData.functional_status
          },
          ct_measurements: {
            ...ctMeasurements,
            saccular_morphology: ctMeasurements.aorta?.morphology === 'saccular',
            rapid_growth: ctMeasurements.aorta?.growth_rate > 5,
            wall_thickness_mm: ctMeasurements.aorta?.wall_thickness,
            retroperitoneal_fibrosis: ctMeasurements.aorta?.inflammatory_changes
          },
          pathology_type: patientData.pathology_type
        })
      })

      if (!response.ok) {
        throw new Error('Analysis failed')
      }

      const data = await response.json()
      setAnalysis(data.analysis)
      toast.success('AI-анализ завершен!')
      setActiveTab('results')
    } catch (error) {
      toast.error('Ошибка AI-анализа')
      console.error(error)
    } finally {
      setAnalyzing(false)
    }
  }

  const toggleSection = (section: string) => {
    setExpandedSections(prev => ({
      ...prev,
      [section]: !prev[section]
    }))
  }

  const getRiskColor = (level: string) => {
    switch (level) {
      case 'Низкий': return 'bg-green-100 text-green-800 border-green-300'
      case 'Умеренный': return 'bg-yellow-100 text-yellow-800 border-yellow-300'
      case 'Высокий': return 'bg-orange-100 text-orange-800 border-orange-300'
      case 'Очень высокий': return 'bg-red-100 text-red-800 border-red-300'
      default: return 'bg-gray-100 text-gray-800 border-gray-300'
    }
  }

  const getSeverityColor = (severity: string) => {
    switch (severity) {
      case 'low': return 'text-green-600'
      case 'moderate': return 'text-yellow-600'
      case 'high': return 'text-orange-600'
      case 'extreme': return 'text-red-600 font-bold'
      default: return 'text-gray-600'
    }
  }

  const getApproachIcon = (type: string) => {
    switch (type) {
      case 'open': return <Scissors className="h-5 w-5" />
      case 'endovascular': return <Zap className="h-5 w-5" />
      case 'hybrid': return <Activity className="h-5 w-5" />
      case 'conservative': return <Heart className="h-5 w-5" />
      default: return <Stethoscope className="h-5 w-5" />
    }
  }

  const getApproachName = (type: string) => {
    switch (type) {
      case 'open': return 'Открытая операция'
      case 'endovascular': return 'Эндоваскулярное вмешательство'
      case 'hybrid': return 'Гибридный подход'
      case 'conservative': return 'Консервативное лечение'
      default: return type
    }
  }

  const getUrgencyBadgeColor = (urgency: string) => {
    switch (urgency) {
      case 'Экстренная': return 'bg-red-500 text-white'
      case 'Срочная': return 'bg-orange-500 text-white'
      case 'Приоритетная': return 'bg-yellow-500 text-black'
      case 'Элективная': return 'bg-green-500 text-white'
      default: return 'bg-gray-500 text-white'
    }
  }

  return (
    <div className="space-y-6">
      <Tabs value={activeTab} onValueChange={setActiveTab}>
        <TabsList className="grid w-full grid-cols-2">
          <TabsTrigger value="patient">
            <User className="h-4 w-4 mr-2" />
            Данные пациента
          </TabsTrigger>
          <TabsTrigger value="results" disabled={!analysis}>
            <Brain className="h-4 w-4 mr-2" />
            Результаты AI-анализа
          </TabsTrigger>
        </TabsList>

        <TabsContent value="patient" className="space-y-4">
          {/* Patient Data Input */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center space-x-2 text-lg">
                <User className="h-5 w-5" />
                <span>Данные пациента для AI-анализа</span>
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-6">
              {/* Основные параметры */}
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                <div className="space-y-2">
                  <Label>Возраст</Label>
                  <Input
                    type="number"
                    value={patientData.age}
                    onChange={(e) => setPatientData(prev => ({ ...prev, age: parseInt(e.target.value) }))}
                  />
                </div>
                <div className="space-y-2">
                  <Label>ИМТ</Label>
                  <Input
                    type="number"
                    value={patientData.bmi}
                    onChange={(e) => setPatientData(prev => ({ ...prev, bmi: parseFloat(e.target.value) }))}
                  />
                </div>
                <div className="space-y-2">
                  <Label>Пол</Label>
                  <select
                    className="w-full p-2 border rounded"
                    value={patientData.gender}
                    onChange={(e) => setPatientData(prev => ({ ...prev, gender: e.target.value }))}
                  >
                    <option value="male">Мужской</option>
                    <option value="female">Женский</option>
                  </select>
                </div>
                <div className="space-y-2">
                  <Label>Статус курения</Label>
                  <select
                    className="w-full p-2 border rounded"
                    value={patientData.smoking_status}
                    onChange={(e) => setPatientData(prev => ({ ...prev, smoking_status: e.target.value }))}
                  >
                    <option value="never">Никогда</option>
                    <option value="former">Бросил</option>
                    <option value="current">Курит</option>
                  </select>
                </div>
              </div>

              {/* Тип патологии */}
              <div className="space-y-2">
                <Label>Тип патологии</Label>
                <select
                  className="w-full p-2 border rounded"
                  value={patientData.pathology_type}
                  onChange={(e) => setPatientData(prev => ({ ...prev, pathology_type: e.target.value }))}
                >
                  {pathologyOptions.map(p => (
                    <option key={p.id} value={p.id}>
                      {p.name} ({p.urgency}) - {p.esvs}
                    </option>
                  ))}
                </select>
              </div>

              {/* Генетические синдромы */}
              <div className="space-y-2">
                <Label className="flex items-center space-x-2">
                  <Dna className="h-4 w-4" />
                  <span>Генетический синдром</span>
                </Label>
                <select
                  className="w-full p-2 border rounded"
                  value={patientData.genetic_syndrome}
                  onChange={(e) => setPatientData(prev => ({ ...prev, genetic_syndrome: e.target.value }))}
                >
                  {geneticSyndromeOptions.map(s => (
                    <option key={s.id} value={s.id}>{s.label}</option>
                  ))}
                </select>
              </div>

              {/* Сопутствующие заболевания */}
              <div className="space-y-2">
                <Label>Сопутствующие заболевания</Label>
                <div className="flex flex-wrap gap-2">
                  {comorbidityOptions.map(condition => (
                    <button
                      key={condition.id}
                      onClick={() => toggleComorbidity(condition.id)}
                      className={`px-3 py-1 rounded-full text-sm transition-colors ${
                        patientData.comorbidities.includes(condition.id)
                          ? 'bg-blue-500 text-white'
                          : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                      }`}
                    >
                      {condition.label}
                    </button>
                  ))}
                </div>
              </div>

              {/* Функциональный статус */}
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label>Функциональный статус</Label>
                  <select
                    className="w-full p-2 border rounded"
                    value={patientData.functional_status}
                    onChange={(e) => setPatientData(prev => ({ ...prev, functional_status: e.target.value }))}
                  >
                    <option value="independent">Независимый</option>
                    <option value="assisted">Частично зависимый</option>
                    <option value="dependent">Зависимый</option>
                  </select>
                </div>
                <div className="space-y-2">
                  <Label>Функция почек (КФР)</Label>
                  <select
                    className="w-full p-2 border rounded"
                    value={patientData.renal_function}
                    onChange={(e) => setPatientData(prev => ({ ...prev, renal_function: e.target.value }))}
                  >
                    <option value="normal">Норма (КФР >90)</option>
                    <option value="mild">Легкое снижение (КФР 60-89)</option>
                    <option value="moderate">Умеренное снижение (КФР 30-59)</option>
                    <option value="severe">Тяжелое снижение (КФР <30)</option>
                  </select>
                </div>
              </div>

              {/* Дополнительные параметры */}
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label>Оценка хрупкости (Fried Frailty, 0-9)</Label>
                  <Input
                    type="number"
                    min={0}
                    max={9}
                    value={patientData.frailty_score || ''}
                    onChange={(e) => setPatientData(prev => ({ 
                      ...prev, 
                      frailty_score: e.target.value ? parseInt(e.target.value) : undefined 
                    }))}
                    placeholder="Не оценена"
                  />
                </div>
                <div className="space-y-2">
                  <Label>DASI (METs)</Label>
                  <Input
                    type="number"
                    value={patientData.das_score || ''}
                    onChange={(e) => setPatientData(prev => ({ 
                      ...prev, 
                      das_score: e.target.value ? parseInt(e.target.value) : undefined 
                    }))}
                    placeholder="Не оценен"
                  />
                </div>
              </div>

              {/* Семейный анамнез */}
              <div className="flex items-center space-x-2">
                <input
                  type="checkbox"
                  id="family_history"
                  checked={patientData.family_history_aaa}
                  onChange={(e) => setPatientData(prev => ({ ...prev, family_history_aaa: e.target.checked }))}
                  className="w-4 h-4"
                />
                <Label htmlFor="family_history" className="cursor-pointer">
                  Семейный анамнез аневризмы аорты
                </Label>
              </div>

              <Button
                onClick={runAIAnalysis}
                disabled={analyzing}
                className="w-full"
                size="lg"
              >
                {analyzing ? (
                  <>
                    <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                    AI анализирует...
                  </>
                ) : (
                  <>
                    <Brain className="h-4 w-4 mr-2" />
                    Запустить AI-анализ
                  </>
                )}
              </Button>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="results" className="space-y-4">
          {/* AI Analysis Results */}
          {analysis && (
            <>
              {/* Rare Pathology Alert */}
              {analysis.rare_pathology_alert && analysis.rare_pathology_alert.length > 0 && (
                <Card className="border-red-300 bg-red-50">
                  <CardHeader className="cursor-pointer pb-2" onClick={() => toggleSection('rarePathology')}>
                    <CardTitle className="flex items-center justify-between text-base text-red-800">
                      <div className="flex items-center space-x-2">
                        <AlertCircle className="h-5 w-5" />
                        <span>Обнаружены признаки редкой патологии!</span>
                      </div>
                      {expandedSections.rarePathology ? <ChevronUp className="h-5 w-5" /> : <ChevronDown className="h-5 w-5" />}
                    </CardTitle>
                  </CardHeader>
                  {expandedSections.rarePathology && (
                    <CardContent>
                      {analysis.rare_pathology_alert.map((alert, i) => (
                        <div key={i} className="mb-4 p-3 bg-white rounded border border-red-200">
                          <div className="flex items-center space-x-2 mb-2">
                            <Dna className="h-4 w-4 text-red-600" />
                            <span className="font-semibold text-red-800">{alert.message}</span>
                          </div>
                          <div className="text-sm text-gray-700 mb-2">
                            Степень тяжести: <span className={getSeverityColor(alert.severity)}>{alert.severity}</span>
                          </div>
                          <div className="text-sm">
                            <span className="font-medium">Рекомендации:</span>
                            <ul className="list-disc list-inside mt-1">
                              {alert.recommendations.map((rec, j) => (
                                <li key={j}>{rec}</li>
                              ))}
                            </ul>
                          </div>
                        </div>
                      ))}
                    </CardContent>
                  )}
                </Card>
              )}

              {/* Case Summary */}
              <Card className="bg-gradient-to-r from-blue-50 to-indigo-50">
                <CardContent className="p-4">
                  <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
                    <div className="flex-1">
                      <h3 className="font-semibold text-lg">{analysis.case_summary.summary_text}</h3>
                      <div className="flex flex-wrap gap-2 mt-2">
                        <Badge variant="outline">Сложность: {analysis.case_summary.complexity}</Badge>
                        <Badge className={getUrgencyBadgeColor(analysis.case_summary.urgency.level)}>
                          {analysis.case_summary.urgency.level}
                        </Badge>
                        {analysis.case_summary.esvs_class && (
                          <Badge variant="outline" className="border-blue-400 text-blue-700">
                            <BookOpen className="h-3 w-3 mr-1" />
                            {analysis.case_summary.esvs_class}
                          </Badge>
                        )}
                      </div>
                      <p className="text-sm text-gray-600 mt-2">
                        Срок: {analysis.case_summary.urgency.timeframe} | {analysis.case_summary.urgency.reason}
                      </p>
                      {analysis.case_summary.urgency.esvs_recommendation && (
                        <p className="text-xs text-blue-600 mt-1">
                          {analysis.case_summary.urgency.esvs_recommendation}
                        </p>
                      )}
                    </div>
                    <div className="text-right bg-white p-3 rounded-lg shadow-sm">
                      <div className="text-sm text-gray-500">Общий балл риска</div>
                      <div className="text-3xl font-bold text-blue-600">{analysis.risk_assessment.overall_score}</div>
                      <div className="text-xs text-gray-500 mt-1">{analysis.risk_assessment.risk_stratification}</div>
                    </div>
                  </div>
                </CardContent>
              </Card>

              {/* Risk Assessment */}
              <Card>
                <CardHeader className="cursor-pointer pb-2" onClick={() => toggleSection('risks')}>
                  <CardTitle className="flex items-center justify-between text-base">
                    <div className="flex items-center space-x-2">
                      <AlertTriangle className="h-5 w-5 text-orange-500" />
                      <span>Оценка рисков</span>
                    </div>
                    {expandedSections.risks ? <ChevronUp className="h-5 w-5" /> : <ChevronDown className="h-5 w-5" />}
                  </CardTitle>
                </CardHeader>
                {expandedSections.risks && (
                  <CardContent>
                    <div className="grid grid-cols-2 gap-3">
                      <div className="bg-gray-50 p-3 rounded border">
                        <div className="text-sm text-gray-500">Летальный исход</div>
                        <div className="flex items-center space-x-2 mt-1">
                          <span className="text-lg font-semibold">{analysis.risk_assessment.mortality.probability}%</span>
                          <Badge className={getRiskColor(analysis.risk_assessment.mortality.level)}>
                            {analysis.risk_assessment.mortality.level}
                          </Badge>
                        </div>
                        {analysis.risk_assessment.mortality.factors && (
                          <div className="text-xs text-gray-500 mt-1">
                            Факторы: {analysis.risk_assessment.mortality.factors.join(', ')}
                          </div>
                        )}
                      </div>
                      <div className="bg-gray-50 p-3 rounded border">
                        <div className="text-sm text-gray-500">Сердечные осложнения</div>
                        <div className="flex items-center space-x-2 mt-1">
                          <span className="text-lg font-semibold">{analysis.risk_assessment.cardiac_complications.probability}%</span>
                          <Badge className={getRiskColor(analysis.risk_assessment.cardiac_complications.level)}>
                            {analysis.risk_assessment.cardiac_complications.level}
                          </Badge>
                        </div>
                      </div>
                      <div className="bg-gray-50 p-3 rounded border">
                        <div className="text-sm text-gray-500">Почечная недостаточность</div>
                        <div className="flex items-center space-x-2 mt-1">
                          <span className="text-lg font-semibold">{analysis.risk_assessment.renal_failure.probability}%</span>
                          <Badge className={getRiskColor(analysis.risk_assessment.renal_failure.level)}>
                            {analysis.risk_assessment.renal_failure.level}
                          </Badge>
                        </div>
                      </div>
                      <div className="bg-gray-50 p-3 rounded border">
                        <div className="text-sm text-gray-500">Инфекция</div>
                        <div className="flex items-center space-x-2 mt-1">
                          <span className="text-lg font-semibold">{analysis.risk_assessment.infection.probability}%</span>
                          <Badge className={getRiskColor(analysis.risk_assessment.infection.level)}>
                            {analysis.risk_assessment.infection.level}
                          </Badge>
                        </div>
                      </div>
                    </div>
                    
                    {analysis.risk_assessment.paraplegia && analysis.risk_assessment.paraplegia.probability > 0 && (
                      <div className="mt-3 p-3 bg-red-50 rounded border border-red-200">
                        <div className="text-sm text-red-700 font-medium">Риск параплегии</div>
                        <div className="flex items-center space-x-2 mt-1">
                          <span className="text-lg font-semibold text-red-600">{analysis.risk_assessment.paraplegia.probability}%</span>
                          <Badge className={getRiskColor(analysis.risk_assessment.paraplegia.level)}>
                            {analysis.risk_assessment.paraplegia.level}
                          </Badge>
                        </div>
                        {analysis.risk_assessment.paraplegia.preventive_measures && (
                          <div className="text-xs text-gray-600 mt-1">
                            Профилактика: {analysis.risk_assessment.paraplegia.preventive_measures.join(', ')}
                          </div>
                        )}
                      </div>
                    )}

                    {analysis.risk_assessment.risk_modification_suggestions && analysis.risk_assessment.risk_modification_suggestions.length > 0 && (
                      <div className="mt-3 p-3 bg-green-50 rounded border border-green-200">
                        <div className="text-sm font-medium text-green-700 flex items-center">
                          <TrendingUp className="h-4 w-4 mr-1" />
                          Рекомендации по модификации риска:
                        </div>
                        <ul className="list-disc list-inside text-sm text-green-700 mt-1">
                          {analysis.risk_assessment.risk_modification_suggestions.map((suggestion, i) => (
                            <li key={i}>{suggestion}</li>
                          ))}
                        </ul>
                      </div>
                    )}
                  </CardContent>
                )}
              </Card>

              {/* Approach Recommendation */}
              <Card>
                <CardHeader className="cursor-pointer pb-2" onClick={() => toggleSection('approach')}>
                  <CardTitle className="flex items-center justify-between text-base">
                    <div className="flex items-center space-x-2">
                      <Activity className="h-5 w-5 text-green-500" />
                      <span>Рекомендуемый подход</span>
                    </div>
                    {expandedSections.approach ? <ChevronUp className="h-5 w-5" /> : <ChevronDown className="h-5 w-5" />}
                  </CardTitle>
                </CardHeader>
                {expandedSections.approach && (
                  <CardContent>
                    <div className="flex items-center space-x-3 mb-4">
                      <div className="p-2 bg-blue-100 rounded-lg">
                        {getApproachIcon(analysis.approach_recommendation.type)}
                      </div>
                      <div>
                        <div className="font-semibold text-lg">
                          {getApproachName(analysis.approach_recommendation.type)}
                        </div>
                        <div className="text-sm text-gray-500">
                          Уверенность: {analysis.approach_recommendation.confidence}
                          {analysis.approach_recommendation.anatomical_score !== undefined && (
                            <span className="ml-2">| Анатомический балл: {analysis.approach_recommendation.anatomical_score}/10</span>
                          )}
                        </div>
                      </div>
                    </div>

                    <div className="space-y-3">
                      <div className="bg-green-50 p-3 rounded">
                        <div className="text-sm font-medium text-green-700 mb-1">Обоснование:</div>
                        <ul className="list-disc list-inside text-sm space-y-1">
                          {analysis.approach_recommendation.rationale.map((r, i) => (
                            <li key={i} className="text-gray-700">{r}</li>
                          ))}
                        </ul>
                      </div>

                      {analysis.approach_recommendation.contraindications && analysis.approach_recommendation.contraindications.length > 0 && (
                        <div className="bg-red-50 p-3 rounded">
                          <div className="text-sm font-medium text-red-700 mb-1">Противопоказания:</div>
                          <ul className="list-disc list-inside text-sm text-red-600">
                            {analysis.approach_recommendation.contraindications.map((c, i) => (
                              <li key={i}>{c}</li>
                            ))}
                          </ul>
                        </div>
                      )}

                      <div className="p-3 bg-blue-50 rounded">
                        <div className="text-sm font-medium text-blue-700">Альтернатива:</div>
                        <div className="text-sm text-gray-700">{analysis.approach_recommendation.alternative}</div>
                      </div>
                    </div>
                  </CardContent>
                )}
              </Card>

              {/* Access Plan */}
              {analysis.access_plan && analysis.access_plan.primary && (
                <Card>
                  <CardHeader className="cursor-pointer pb-2" onClick={() => toggleSection('access')}>
                    <CardTitle className="flex items-center justify-between text-base">
                      <div className="flex items-center space-x-2">
                        <Scissors className="h-5 w-5 text-purple-500" />
                        <span>План доступа</span>
                      </div>
                      {expandedSections.access ? <ChevronUp className="h-5 w-5" /> : <ChevronDown className="h-5 w-5" />}
                    </CardTitle>
                  </CardHeader>
                  {expandedSections.access && (
                    <CardContent>
                      <div className="space-y-3">
                        <div>
                          <div className="font-semibold text-lg">{analysis.access_plan.primary.name}</div>
                          <div className="text-sm text-gray-600">{analysis.access_plan.primary.description}</div>
                          {analysis.access_plan.primary.length && (
                            <div className="text-sm text-gray-500 mt-1">Длина разреза: {analysis.access_plan.primary.length}</div>
                          )}
                        </div>

                        <div className="grid grid-cols-2 gap-3">
                          <div className="bg-green-50 p-3 rounded">
                            <div className="text-sm font-medium text-green-700">Преимущества:</div>
                            <ul className="list-disc list-inside text-xs mt-1">
                              {analysis.access_plan.primary.advantages.map((a, i) => (
                                <li key={i}>{a}</li>
                              ))}
                            </ul>
                          </div>
                          <div className="bg-red-50 p-3 rounded">
                            <div className="text-sm font-medium text-red-700">Недостатки:</div>
                            <ul className="list-disc list-inside text-xs mt-1">
                              {analysis.access_plan.primary.disadvantages.map((d, i) => (
                                <li key={i}>{d}</li>
                              ))}
                            </ul>
                          </div>
                        </div>

                        {analysis.access_plan.alternative && (
                          <div className="bg-yellow-50 p-3 rounded">
                            <div className="text-sm font-medium text-yellow-700">Альтернативный доступ:</div>
                            <div className="text-sm">{analysis.access_plan.alternative.name}</div>
                            <div className="text-xs text-gray-600">{analysis.access_plan.alternative.description}</div>
                          </div>
                        )}

                        <div className="text-sm bg-gray-50 p-2 rounded">
                          <span className="font-medium">Положение пациента:</span> {analysis.access_plan.position}
                        </div>
                        {analysis.access_plan.special_considerations && (
                          <div className="text-sm bg-blue-50 p-2 rounded">
                            <span className="font-medium text-blue-700">Особенности:</span>
                            <ul className="list-disc list-inside mt-1">
                              {Array.isArray(analysis.access_plan.special_considerations) 
                                ? analysis.access_plan.special_considerations.map((s, i) => <li key={i}>{s}</li>)
                                : <li>{analysis.access_plan.special_considerations}</li>
                              }
                            </ul>
                          </div>
                        )}
                      </div>
                    </CardContent>
                  )}
                </Card>
              )}

              {/* Outcome Prediction */}
              {analysis.outcome_prediction && (
                <Card>
                  <CardHeader className="cursor-pointer pb-2" onClick={() => toggleSection('outcome')}>
                    <CardTitle className="flex items-center justify-between text-base">
                      <div className="flex items-center space-x-2">
                        <TrendingUp className="h-5 w-5 text-blue-500" />
                        <span>Прогноз исходов</span>
                      </div>
                      {expandedSections.outcome ? <ChevronUp className="h-5 w-5" /> : <ChevronDown className="h-5 w-5" />}
                    </CardTitle>
                  </CardHeader>
                  {expandedSections.outcome && (
                    <CardContent className="space-y-4">
                      <div className="grid grid-cols-2 gap-3">
                        <div className="bg-blue-50 p-3 rounded">
                          <div className="text-sm text-blue-600 mb-1">Патентность шунта</div>
                          <div className="text-lg font-semibold">1 год: {analysis.outcome_prediction.graft_patency['1_year']}</div>
                          <div className="text-lg font-semibold">5 лет: {analysis.outcome_prediction.graft_patency['5_year']}</div>
                        </div>
                        <div className="bg-green-50 p-3 rounded">
                          <div className="text-sm text-green-600 mb-1">Восстановление</div>
                          <div className="text-sm">Госпитализация: {analysis.outcome_prediction.recovery_time.hospital_stay}</div>
                          <div className="text-sm">Активность: {analysis.outcome_prediction.recovery_time.return_to_daily_activities}</div>
                          {analysis.outcome_prediction.recovery_time.return_to_work && (
                            <div className="text-sm">Работа: {analysis.outcome_prediction.recovery_time.return_to_work}</div>
                          )}
                        </div>
                      </div>

                      {analysis.outcome_prediction.long_term_survival && (
                        <div className="bg-purple-50 p-3 rounded">
                          <div className="text-sm text-purple-600 mb-1">Выживаемость</div>
                          <div className="flex gap-4">
                            <span>1 год: {analysis.outcome_prediction.long_term_survival['1_year']}</span>
                            <span>5 лет: {analysis.outcome_prediction.long_term_survival['5_year']}</span>
                            <span>10 лет: {analysis.outcome_prediction.long_term_survival['10_year']}</span>
                          </div>
                        </div>
                      )}

                      {analysis.outcome_prediction.reintervention_probability && (
                        <div className="bg-orange-50 p-3 rounded">
                          <div className="text-sm text-orange-600 mb-1">Вероятность повторного вмешательства</div>
                          <div className="flex gap-4">
                            <span>1 год: {analysis.outcome_prediction.reintervention_probability['1_year']}</span>
                            <span>5 лет: {analysis.outcome_prediction.reintervention_probability['5_year']}</span>
                          </div>
                          <div className="text-xs text-gray-600 mt-1">
                            Причины: {analysis.outcome_prediction.reintervention_probability.common_reasons.join(', ')}
                          </div>
                        </div>
                      )}
                    </CardContent>
                  )}
                </Card>
              )}

              {/* Preoperative Preparation */}
              {analysis.preoperative_preparation && (
                <Card>
                  <CardHeader className="cursor-pointer pb-2" onClick={() => toggleSection('preparation')}>
                    <CardTitle className="flex items-center justify-between text-base">
                      <div className="flex items-center space-x-2">
                        <Shield className="h-5 w-5 text-teal-500" />
                        <span>Предоперационная подготовка</span>
                      </div>
                      {expandedSections.preparation ? <ChevronUp className="h-5 w-5" /> : <ChevronDown className="h-5 w-5" />}
                    </CardTitle>
                  </CardHeader>
                  {expandedSections.preparation && (
                    <CardContent>
                      <div className="space-y-4">
                        {analysis.preoperative_preparation.preparations.map((prep, i) => (
                          <div key={i} className="border-l-4 border-teal-500 pl-3">
                            <div className="font-medium">{prep.specialist}</div>
                            <div className="text-sm text-gray-500">{prep.timeline}</div>
                            <ul className="list-disc list-inside text-sm mt-1">
                              {prep.actions.map((action, j) => (
                                <li key={j}>{action}</li>
                              ))}
                            </ul>
                          </div>
                        ))}

                        <Separator />

                        <div className="bg-blue-50 p-3 rounded">
                          <div className="font-medium mb-1">Рекомендуемая анестезия:</div>
                          <div className="text-sm">{analysis.preoperative_preparation.anesthesia_recommendation.primary}</div>
                          {analysis.preoperative_preparation.anesthesia_recommendation.alternative && (
                            <div className="text-sm text-gray-600 mt-1">
                              Альтернатива: {analysis.preoperative_preparation.anesthesia_recommendation.alternative}
                            </div>
                          )}
                          <div className="text-sm text-gray-500 mt-1">
                            Мониторинг: {analysis.preoperative_preparation.anesthesia_recommendation.monitoring.join(', ')}
                          </div>
                        </div>

                        {analysis.preoperative_preparation.required_blood && (
                          <div className="bg-red-50 p-3 rounded">
                            <div className="font-medium text-red-700">Подготовка крови:</div>
                            <div className="text-sm">{analysis.preoperative_preparation.required_blood.units_required}</div>
                            <div className="text-sm text-gray-600">{analysis.preoperative_preparation.required_blood.type}</div>
                          </div>
                        )}

                        {analysis.preoperative_preparation.icu_probability && (
                          <div className="bg-yellow-50 p-3 rounded">
                            <div className="font-medium text-yellow-700">Вероятность ИТО:</div>
                            <div className="text-sm">{analysis.preoperative_preparation.icu_probability.probability}</div>
                            <div className="text-xs text-gray-600">{analysis.preoperative_preparation.icu_probability.reason}</div>
                          </div>
                        )}
                      </div>
                    </CardContent>
                  )}
                </Card>
              )}

              {/* Evidence Base */}
              {analysis.evidence_base && (
                <Card>
                  <CardHeader className="cursor-pointer pb-2" onClick={() => toggleSection('evidence')}>
                    <CardTitle className="flex items-center justify-between text-base">
                      <div className="flex items-center space-x-2">
                        <BookOpen className="h-5 w-5 text-indigo-500" />
                        <span>Доказательная база</span>
                      </div>
                      {expandedSections.evidence ? <ChevronUp className="h-5 w-5" /> : <ChevronDown className="h-5 w-5" />}
                    </CardTitle>
                  </CardHeader>
                  {expandedSections.evidence && (
                    <CardContent>
                      <div className="bg-indigo-50 p-4 rounded">
                        <div className="mb-3">
                          <span className="font-medium">Клинические рекомендации:</span>
                          <ul className="list-disc list-inside text-sm mt-1">
                            {analysis.evidence_base.guidelines.map((g, i) => (
                              <li key={i}>{g}</li>
                            ))}
                          </ul>
                        </div>
                        <div className="mb-3">
                          <span className="font-medium">Ключевые исследования:</span>
                          <ul className="list-disc list-inside text-sm mt-1">
                            {analysis.evidence_base.key_studies.map((s, i) => (
                              <li key={i}>{s}</li>
                            ))}
                          </ul>
                        </div>
                        <div>
                          <Badge variant="outline" className="border-indigo-400 text-indigo-700">
                            {analysis.evidence_base.recommendation_class}
                          </Badge>
                        </div>
                        {analysis.evidence_base.key_points && (
                          <div className="mt-3 pt-3 border-t border-indigo-200">
                            <span className="font-medium">Ключевые положения:</span>
                            <ul className="list-disc list-inside text-sm mt-1">
                              {analysis.evidence_base.key_points.map((p, i) => (
                                <li key={i}>{p}</li>
                              ))}
                            </ul>
                          </div>
                        )}
                      </div>
                    </CardContent>
                  )}
                </Card>
              )}

              {/* Surveillance Plan */}
              {analysis.surveillance_plan && (
                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center space-x-2 text-base">
                      <Calendar className="h-5 w-5 text-cyan-500" />
                      <span>План наблюдения</span>
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="bg-cyan-50 p-3 rounded">
                      {analysis.surveillance_plan.schedule ? (
                        <div className="space-y-2">
                          {analysis.surveillance_plan.schedule.map((item, i) => (
                            <div key={i} className="flex justify-between text-sm">
                              <span>{item.time}:</span>
                              <span className="font-medium">{item.method}</span>
                            </div>
                          ))}
                        </div>
                      ) : (
                        <div className="text-sm">
                          <span className="font-medium">Интервал:</span> {analysis.surveillance_plan.interval_months} месяцев
                          <br />
                          <span className="font-medium">Метод:</span> {analysis.surveillance_plan.method}
                        </div>
                      )}
                      {analysis.surveillance_plan.esvs_reference && (
                        <div className="text-xs text-cyan-700 mt-2">
                          {analysis.surveillance_plan.esvs_reference}
                        </div>
                      )}
                    </div>
                  </CardContent>
                </Card>
              )}

              {/* ESVS Compliance */}
              {analysis.esvs_2024_compliance && (
                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center space-x-2 text-base">
                      <CheckCircle2 className="h-5 w-5 text-green-500" />
                      <span>Соответствие ESVS 2024</span>
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className={`p-3 rounded ${analysis.esvs_2024_compliance.compliant ? 'bg-green-50' : 'bg-yellow-50'}`}>
                      <div className="text-sm font-medium mb-2">
                        {analysis.esvs_2024_compliance.compliant 
                          ? 'Соответствует рекомендациям ESVS 2024' 
                          : 'Требует внимания'}
                      </div>
                      {analysis.esvs_2024_compliance.warnings.length > 0 && (
                        <div className="text-sm">
                          <span className="font-medium">Рекомендации:</span>
                          <ul className="list-disc list-inside mt-1">
                            {analysis.esvs_2024_compliance.warnings.map((w, i) => (
                              <li key={i}>{w}</li>
                            ))}
                          </ul>
                        </div>
                      )}
                    </div>
                  </CardContent>
                </Card>
              )}
            </>
          )}
        </TabsContent>
      </Tabs>
    </div>
  )
}
