import { useState, useEffect } from 'react'
import { 
  Calendar, 
  User, 
  Scan, 
  Layers, 
  ChevronRight,
  Loader2,
  RefreshCw,
  Trash2
} from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { toast } from 'sonner'
import type { Study } from '../App'

interface StudyListProps {
  onSelect: (study: Study) => void
  refreshTrigger: number
}

const API_URL = import.meta.env.VITE_API_URL || 'http://localhost:8000'

const statusLabels: Record<string, { label: string; color: string }> = {
  uploaded: { label: 'Загружено', color: 'bg-blue-100 text-blue-800' },
  processing: { label: 'Обработка', color: 'bg-yellow-100 text-yellow-800' },
  segmented: { label: 'Сегментировано', color: 'bg-green-100 text-green-800' },
  error: { label: 'Ошибка', color: 'bg-red-100 text-red-800' },
}

export default function StudyList({ onSelect, refreshTrigger }: StudyListProps) {
  const [studies, setStudies] = useState<Study[]>([])
  const [loading, setLoading] = useState(true)

  const fetchStudies = async () => {
    try {
      setLoading(true)
      const response = await fetch(`${API_URL}/api/dicom/studies`)
      
      if (!response.ok) {
        throw new Error('Failed to fetch studies')
      }
      
      const data = await response.json()
      setStudies(data.studies || [])
    } catch (error) {
      toast.error('Ошибка загрузки исследований')
      console.error(error)
    } finally {
      setLoading(false)
    }
  }

  useEffect(() => {
    fetchStudies()
  }, [refreshTrigger])

  const handleDelete = async (studyId: number, e: React.MouseEvent) => {
    e.stopPropagation()
    
    if (!confirm('Удалить исследование?')) {
      return
    }
    
    try {
      const response = await fetch(`${API_URL}/api/dicom/studies/${studyId}`, {
        method: 'DELETE',
      })
      
      if (response.ok) {
        toast.success('Исследование удалено')
        fetchStudies()
      } else {
        throw new Error('Failed to delete')
      }
    } catch (error) {
      toast.error('Ошибка удаления')
    }
  }

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleString('ru-RU', {
      day: '2-digit',
      month: '2-digit',
      year: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
    })
  }

  if (loading) {
    return (
      <Card>
        <CardContent className="p-8 flex justify-center">
          <Loader2 className="h-8 w-8 animate-spin text-blue-500" />
        </CardContent>
      </Card>
    )
  }

  if (studies.length === 0) {
    return (
      <Card>
        <CardContent className="p-8 text-center">
          <Scan className="h-12 w-12 mx-auto text-gray-300 mb-4" />
          <p className="text-gray-500">Нет загруженных исследований</p>
          <p className="text-sm text-gray-400 mt-1">
            Загрузите DICOM файлы выше
          </p>
        </CardContent>
      </Card>
    )
  }

  return (
    <Card>
      <CardHeader className="flex flex-row items-center justify-between">
        <CardTitle className="flex items-center space-x-2">
          <Scan className="h-5 w-5" />
          <span>Список исследований</span>
        </CardTitle>
        <Button
          variant="ghost"
          size="sm"
          onClick={fetchStudies}
          disabled={loading}
        >
          <RefreshCw className={`h-4 w-4 ${loading ? 'animate-spin' : ''}`} />
        </Button>
      </CardHeader>
      <CardContent>
        <div className="space-y-2">
          {studies.map((study) => {
            const status = statusLabels[study.status] || statusLabels.uploaded
            
            return (
              <div
                key={study.id}
                onClick={() => onSelect(study)}
                className="
                  flex items-center justify-between p-4 
                  border rounded-lg cursor-pointer
                  hover:bg-blue-50 hover:border-blue-300
                  transition-colors duration-200
                "
              >
                <div className="flex-1 space-y-1">
                  <div className="flex items-center space-x-2">
                    <User className="h-4 w-4 text-gray-400" />
                    <span className="font-medium">{study.patient_id}</span>
                    <Badge className={status.color} variant="secondary">
                      {status.label}
                    </Badge>
                  </div>
                  
                  <div className="flex items-center space-x-4 text-sm text-gray-500">
                    <span className="flex items-center space-x-1">
                      <Calendar className="h-3 w-3" />
                      <span>{formatDate(study.created_at)}</span>
                    </span>
                    <span className="flex items-center space-x-1">
                      <Layers className="h-3 w-3" />
                      <span>{study.num_slices} срезов</span>
                    </span>
                    <span>{study.modality}</span>
                  </div>
                  
                  {study.description && (
                    <p className="text-sm text-gray-600">
                      {study.description}
                    </p>
                  )}
                </div>
                
                <div className="flex items-center space-x-2">
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={(e) => handleDelete(study.id, e)}
                    className="text-red-500 hover:text-red-700 hover:bg-red-50"
                  >
                    <Trash2 className="h-4 w-4" />
                  </Button>
                  <ChevronRight className="h-5 w-5 text-gray-400" />
                </div>
              </div>
            )
          })}
        </div>
      </CardContent>
    </Card>
  )
}
