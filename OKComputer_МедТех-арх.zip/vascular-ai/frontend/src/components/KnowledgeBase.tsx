import React, { useState, useEffect } from 'react';
import { 
  BookOpen, 
  Search, 
  Bookmark, 
  ExternalLink, 
  ChevronRight,
  Star,
  History,
  AlertCircle,
  Pill,
  Activity,
  Stethoscope,
  FileText,
  TreePine
} from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Badge } from './ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import { ScrollArea } from './ui/scroll-area';
import { knowledgeBaseApi } from '../services/knowledgeBaseApi';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from './ui/dialog';

interface Article {
  id: string;
  code: string;
  title: string;
  article_type: string;
  summary: string;
  content: string;
  categories: Category[];
  tags: Tag[];
  view_count: number;
  is_favorite: boolean;
  source?: {
    book: string;
    authors: string[];
    year: number;
  };
}

interface Category {
  id: string;
  code: string;
  name: string;
  children?: Category[];
}

interface Tag {
  id: string;
  code: string;
  name: string;
}

interface Medication {
  id: string;
  generic_name: string;
  brand_names: string[];
  drug_class: string;
  indications: string[];
  contraindications: string[];
  drug_interactions: any[];
}

export const KnowledgeBase: React.FC = () => {
  const [searchQuery, setSearchQuery] = useState('');
  const [searchResults, setSearchResults] = useState<Article[]>([]);
  const [categories, setCategories] = useState<Category[]>([]);
  const [selectedArticle, setSelectedArticle] = useState<Article | null>(null);
  const [favorites, setFavorites] = useState<Article[]>([]);
  const [popularArticles, setPopularArticles] = useState<Article[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [showArticleDialog, setShowArticleDialog] = useState(false);
  const [drugInteractionDialog, setDrugInteractionDialog] = useState(false);
  const [drugsToCheck, setDrugsToCheck] = useState('');
  const [interactionResults, setInteractionResults] = useState<any>(null);

  useEffect(() => {
    loadCategories();
    loadPopularArticles();
    loadFavorites();
  }, []);

  useEffect(() => {
    if (searchQuery.length >= 2) {
      performSearch();
    }
  }, [searchQuery]);

  const loadCategories = async () => {
    try {
      const response = await knowledgeBaseApi.getCategoryTree();
      setCategories(response.tree);
    } catch (error) {
      console.error('Failed to load categories:', error);
    }
  };

  const loadPopularArticles = async () => {
    try {
      const response = await knowledgeBaseApi.getPopularArticles();
      setPopularArticles(response.items);
    } catch (error) {
      console.error('Failed to load popular articles:', error);
    }
  };

  const loadFavorites = async () => {
    try {
      const response = await knowledgeBaseApi.getFavorites();
      setFavorites(response.items);
    } catch (error) {
      console.error('Failed to load favorites:', error);
    }
  };

  const performSearch = async () => {
    setIsLoading(true);
    try {
      const response = await knowledgeBaseApi.search({ q: searchQuery });
      setSearchResults(response.items);
    } catch (error) {
      console.error('Search failed:', error);
    } finally {
      setIsLoading(false);
    }
  };

  const loadArticle = async (articleId: string) => {
    try {
      const article = await knowledgeBaseApi.getArticle(articleId);
      setSelectedArticle(article);
      setShowArticleDialog(true);
    } catch (error) {
      console.error('Failed to load article:', error);
    }
  };

  const toggleFavorite = async (articleId: string) => {
    try {
      const isFavorite = favorites.some(f => f.id === articleId);
      if (isFavorite) {
        await knowledgeBaseApi.removeFromFavorites(articleId);
      } else {
        await knowledgeBaseApi.addToFavorites(articleId);
      }
      loadFavorites();
    } catch (error) {
      console.error('Failed to toggle favorite:', error);
    }
  };

  const checkDrugInteractions = async () => {
    try {
      const drugs = drugsToCheck.split(',').map(d => d.trim());
      const results = await knowledgeBaseApi.checkDrugInteractions(drugs);
      setInteractionResults(results);
    } catch (error) {
      console.error('Failed to check interactions:', error);
    }
  };

  const getArticleTypeIcon = (type: string) => {
    const icons: Record<string, React.ReactNode> = {
      disease: <Activity className="w-4 h-4" />,
      medication: <Pill className="w-4 h-4" />,
      procedure: <Stethoscope className="w-4 h-4" />,
      guideline: <FileText className="w-4 h-4" />,
      anatomy: <TreePine className="w-4 h-4" />
    };
    return icons[type] || <BookOpen className="w-4 h-4" />;
  };

  const renderCategoryTree = (cats: Category[], level = 0) => {
    return cats.map((cat) => (
      <div key={cat.id} style={{ marginLeft: level * 16 }}>
        <Button 
          variant="ghost" 
          className="w-full justify-start text-left"
          onClick={() => loadCategoryArticles(cat.id)}
        >
          <ChevronRight className="w-4 h-4 mr-2" />
          {cat.name}
        </Button>
        {cat.children && renderCategoryTree(cat.children, level + 1)}
      </div>
    ));
  };

  const loadCategoryArticles = async (categoryId: string) => {
    try {
      const response = await knowledgeBaseApi.getArticlesByCategory(categoryId);
      setSearchResults(response.items);
    } catch (error) {
      console.error('Failed to load category articles:', error);
    }
  };

  return (
    <Card className="w-full h-[calc(100vh-100px)]">
      <CardHeader className="flex flex-row items-center justify-between">
        <CardTitle className="flex items-center gap-2">
          <BookOpen className="w-5 h-5" />
          Medical Knowledge Base
        </CardTitle>
        <div className="flex items-center gap-2">
          <div className="relative">
            <Search className="absolute left-2 top-2.5 h-4 w-4 text-muted-foreground" />
            <Input
              placeholder="Search articles, drugs, procedures..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-8 w-80"
            />
          </div>
          <Button 
            variant="outline" 
            onClick={() => setDrugInteractionDialog(true)}
          >
            <Pill className="w-4 h-4 mr-2" />
            Drug Interactions
          </Button>
        </div>
      </CardHeader>
      <CardContent className="p-0">
        <div className="flex h-[calc(100%-80px)]">
          {/* Sidebar */}
          <div className="w-64 border-r p-4">
            <Tabs defaultValue="categories">
              <TabsList className="w-full">
                <TabsTrigger value="categories" className="flex-1">Categories</TabsTrigger>
                <TabsTrigger value="favorites" className="flex-1">
                  <Star className="w-3 h-3 mr-1" />
                  Favs
                </TabsTrigger>
              </TabsList>
              
              <TabsContent value="categories" className="mt-2">
                <ScrollArea className="h-[calc(100vh-250px)]">
                  {renderCategoryTree(categories)}
                </ScrollArea>
              </TabsContent>
              
              <TabsContent value="favorites" className="mt-2">
                <ScrollArea className="h-[calc(100vh-250px)]">
                  {favorites.map((article) => (
                    <Button
                      key={article.id}
                      variant="ghost"
                      className="w-full justify-start text-left mb-1"
                      onClick={() => loadArticle(article.id)}
                    >
                      {getArticleTypeIcon(article.article_type)}
                      <span className="ml-2 truncate">{article.title}</span>
                    </Button>
                  ))}
                </ScrollArea>
              </TabsContent>
            </Tabs>
          </div>

          {/* Main Content */}
          <div className="flex-1 p-4 overflow-auto">
            {searchQuery && searchResults.length > 0 ? (
              <div className="space-y-4">
                <h3 className="text-lg font-medium">Search Results</h3>
                {searchResults.map((article) => (
                  <Card 
                    key={article.id} 
                    className="cursor-pointer hover:shadow-md transition-shadow"
                    onClick={() => loadArticle(article.id)}
                  >
                    <CardContent className="p-4">
                      <div className="flex items-start justify-between">
                        <div className="flex items-start gap-3">
                          {getArticleTypeIcon(article.article_type)}
                          <div>
                            <h4 className="font-medium">{article.title}</h4>
                            <p className="text-sm text-muted-foreground mt-1">
                              {article.summary}
                            </p>
                            <div className="flex items-center gap-2 mt-2">
                              <Badge variant="secondary">{article.article_type}</Badge>
                              {article.source && (
                                <span className="text-xs text-muted-foreground">
                                  From: {article.source.book} ({article.source.year})
                                </span>
                              )}
                            </div>
                          </div>
                        </div>
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={(e) => {
                            e.stopPropagation();
                            toggleFavorite(article.id);
                          }}
                        >
                          <Star 
                            className={`w-4 h-4 ${favorites.some(f => f.id === article.id) ? 'fill-yellow-400 text-yellow-400' : ''}`} 
                          />
                        </Button>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            ) : (
              <div className="space-y-6">
                <div>
                  <h3 className="text-lg font-medium mb-4">Popular Articles</h3>
                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                    {popularArticles.map((article) => (
                      <Card 
                        key={article.id}
                        className="cursor-pointer hover:shadow-md transition-shadow"
                        onClick={() => loadArticle(article.id)}
                      >
                        <CardContent className="p-4">
                          <div className="flex items-center gap-2 mb-2">
                            {getArticleTypeIcon(article.article_type)}
                            <Badge variant="secondary">{article.article_type}</Badge>
                          </div>
                          <h4 className="font-medium">{article.title}</h4>
                          <p className="text-sm text-muted-foreground mt-1">
                            {article.view_count} views
                          </p>
                        </CardContent>
                      </Card>
                    ))}
                  </div>
                </div>

                <div>
                  <h3 className="text-lg font-medium mb-4">Quick Reference</h3>
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                    <QuickReferenceCard 
                      title="Vascular Emergencies"
                      icon={<AlertCircle className="w-5 h-5 text-red-500" />}
                      onClick={() => loadQuickReference('vascular_emergency')}
                    />
                    <QuickReferenceCard 
                      title="Anticoagulation"
                      icon={<Pill className="w-5 h-5 text-blue-500" />}
                      onClick={() => loadQuickReference('anticoagulation')}
                    />
                    <QuickReferenceCard 
                      title="AAA Sizes"
                      icon={<Activity className="w-5 h-5 text-green-500" />}
                      onClick={() => loadQuickReference('aaa_sizes')}
                    />
                  </div>
                </div>
              </div>
            )}
          </div>
        </div>
      </CardContent>

      {/* Article Dialog */}
      <Dialog open={showArticleDialog} onOpenChange={setShowArticleDialog}>
        <DialogContent className="max-w-4xl max-h-[90vh] overflow-auto">
          {selectedArticle && (
            <>
              <DialogHeader>
                <div className="flex items-center gap-2">
                  {getArticleTypeIcon(selectedArticle.article_type)}
                  <DialogTitle>{selectedArticle.title}</DialogTitle>
                </div>
                <div className="flex items-center gap-2 mt-2">
                  <Badge>{selectedArticle.article_type}</Badge>
                  {selectedArticle.source && (
                    <span className="text-sm text-muted-foreground">
                      Source: {selectedArticle.source.book} ({selectedArticle.source.year})
                    </span>
                  )}
                </div>
              </DialogHeader>
              <div className="prose max-w-none">
                <div dangerouslySetInnerHTML={{ __html: selectedArticle.content }} />
              </div>
              {selectedArticle.tags && selectedArticle.tags.length > 0 && (
                <div className="mt-4">
                  <p className="text-sm font-medium mb-2">Tags:</p>
                  <div className="flex flex-wrap gap-2">
                    {selectedArticle.tags.map((tag) => (
                      <Badge key={tag.id} variant="outline">{tag.name}</Badge>
                    ))}
                  </div>
                </div>
              )}
            </>
          )}
        </DialogContent>
      </Dialog>

      {/* Drug Interaction Dialog */}
      <Dialog open={drugInteractionDialog} onOpenChange={setDrugInteractionDialog}>
        <DialogContent className="max-w-2xl">
          <DialogHeader>
            <DialogTitle>Check Drug Interactions</DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <div>
              <label className="text-sm font-medium">Enter drug names (comma separated)</label>
              <Input
                placeholder="e.g., warfarin, aspirin, atorvastatin"
                value={drugsToCheck}
                onChange={(e) => setDrugsToCheck(e.target.value)}
              />
            </div>
            <Button onClick={checkDrugInteractions} disabled={!drugsToCheck}>
              Check Interactions
            </Button>
            
            {interactionResults && (
              <div className="mt-4">
                {interactionResults.has_major_interactions && (
                  <div className="bg-red-50 border border-red-200 rounded-lg p-4 mb-4">
                    <div className="flex items-center gap-2 text-red-700">
                      <AlertCircle className="w-5 h-5" />
                      <span className="font-medium">Major Interactions Found!</span>
                    </div>
                  </div>
                )}
                
                <div className="space-y-2">
                  {interactionResults.interactions.map((interaction: any, idx: number) => (
                    <div 
                      key={idx} 
                      className={`border rounded-lg p-3 ${
                        interaction.severity === 'major' ? 'border-red-300 bg-red-50' :
                        interaction.severity === 'moderate' ? 'border-yellow-300 bg-yellow-50' :
                        'border-blue-300 bg-blue-50'
                      }`}
                    >
                      <div className="flex items-center justify-between">
                        <span className="font-medium">
                          {interaction.drug1} + {interaction.drug2}
                        </span>
                        <Badge 
                          className={
                            interaction.severity === 'major' ? 'bg-red-500' :
                            interaction.severity === 'moderate' ? 'bg-yellow-500' :
                            'bg-blue-500'
                          }
                        >
                          {interaction.severity}
                        </Badge>
                      </div>
                      <p className="text-sm mt-1">{interaction.description}</p>
                      <p className="text-sm text-muted-foreground mt-1">
                        Recommendation: {interaction.recommendation}
                      </p>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>
        </DialogContent>
      </Dialog>
    </Card>
  );
};

const QuickReferenceCard: React.FC<{
  title: string;
  icon: React.ReactNode;
  onClick: () => void;
}> = ({ title, icon, onClick }) => (
  <Card 
    className="cursor-pointer hover:shadow-md transition-shadow"
    onClick={onClick}
  >
    <CardContent className="p-4 flex items-center gap-3">
      {icon}
      <span className="font-medium">{title}</span>
    </CardContent>
  </Card>
);

export default KnowledgeBase;