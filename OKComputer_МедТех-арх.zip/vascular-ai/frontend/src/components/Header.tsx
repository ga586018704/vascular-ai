import { Activity, Heart, Brain } from 'lucide-react'

export default function Header() {
  return (
    <header className="bg-gradient-to-r from-blue-900 via-blue-800 to-blue-900 text-white">
      <div className="container mx-auto px-4 py-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-3">
            <div className="relative">
              <Activity className="h-8 w-8 text-red-400" />
              <Heart className="h-4 w-4 text-red-500 absolute -bottom-1 -right-1" />
            </div>
            <div>
              <h1 className="text-2xl font-bold tracking-tight">
                VASCULAR<span className="text-red-400">.AI</span>
              </h1>
              <p className="text-xs text-blue-200">
                AI-платформа для планирования сосудистых операций
              </p>
            </div>
          </div>
          
          <div className="flex items-center space-x-6">
            <div className="hidden md:flex items-center space-x-2 text-sm text-blue-200">
              <Brain className="h-4 w-4" />
              <span>AI-сегментация сосудов</span>
            </div>
            <div className="flex items-center space-x-2">
              <div className="flex items-center space-x-1">
                <div className="w-2 h-2 bg-green-400 rounded-full animate-pulse"></div>
                <span className="text-xs text-green-400">Система активна</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </header>
  )
}
