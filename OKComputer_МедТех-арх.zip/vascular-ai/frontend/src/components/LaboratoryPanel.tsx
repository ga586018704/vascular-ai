import React, { useState, useEffect } from 'react';
import { 
  FlaskConical, 
  Plus, 
  Search, 
  AlertCircle, 
  TrendingUp, 
  TrendingDown,
  CheckCircle2,
  Clock,
  FileText,
  ChevronDown,
  ChevronRight
} from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { Input } from './ui/input';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from './ui/dialog';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { laboratoryApi } from '../services/laboratoryApi';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, ReferenceLine } from 'recharts';

interface LaboratoryTest {
  id: string;
  order_number: string;
  patient_id: string;
  status: 'ordered' | 'collected' | 'processing' | 'completed' | 'cancelled';
  priority: 'routine' | 'urgent' | 'stat';
  order_date: string;
  result_date?: string;
  results: TestResult[];
}

interface TestResult {
  id: string;
  test_code: string;
  test_name: string;
  value_numeric?: number;
  value_text?: string;
  unit?: string;
  reference_min?: number;
  reference_max?: number;
  interpretation: 'normal' | 'low' | 'high' | 'critical_low' | 'critical_high';
  is_critical: boolean;
  is_abnormal: boolean;
  created_at: string;
}

interface TestPanel {
  id: string;
  code: string;
  name: string;
  test_codes: string[];
}

export const LaboratoryPanel: React.FC<{ patientId: string }> = ({ patientId }) => {
  const [tests, setTests] = useState<LaboratoryTest[]>([]);
  const [panels, setPanels] = useState<TestPanel[]>([]);
  const [selectedTest, setSelectedTest] = useState<LaboratoryTest | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [showNewOrderDialog, setShowNewOrderDialog] = useState(false);
  const [testHistory, setTestHistory] = useState<any[]>([]);

  useEffect(() => {
    loadTests();
    loadPanels();
  }, [patientId]);

  const loadTests = async () => {
    setIsLoading(true);
    try {
      const response = await laboratoryApi.getTests({ patient_id: patientId });
      setTests(response.items);
    } catch (error) {
      console.error('Failed to load tests:', error);
    } finally {
      setIsLoading(false);
    }
  };

  const loadPanels = async () => {
    try {
      const response = await laboratoryApi.getPanels();
      setPanels(response.items);
    } catch (error) {
      console.error('Failed to load panels:', error);
    }
  };

  const loadTestHistory = async (testCode: string) => {
    try {
      const history = await laboratoryApi.getTestHistory(patientId, testCode);
      setTestHistory(history);
    } catch (error) {
      console.error('Failed to load test history:', error);
    }
  };

  const handleCreateOrder = async (panelCode: string, priority: string) => {
    try {
      await laboratoryApi.createTest({
        patient_id: patientId,
        panel_code: panelCode,
        priority: priority as 'routine' | 'urgent' | 'stat'
      });
      setShowNewOrderDialog(false);
      loadTests();
    } catch (error) {
      console.error('Failed to create order:', error);
    }
  };

  const getStatusBadge = (status: string) => {
    const statusConfig: Record<string, { color: string; icon: React.ReactNode }> = {
      ordered: { color: 'bg-blue-100 text-blue-800', icon: <Clock className="w-3 h-3" /> },
      collected: { color: 'bg-yellow-100 text-yellow-800', icon: <FlaskConical className="w-3 h-3" /> },
      processing: { color: 'bg-purple-100 text-purple-800', icon: <Clock className="w-3 h-3" /> },
      completed: { color: 'bg-green-100 text-green-800', icon: <CheckCircle2 className="w-3 h-3" /> },
      cancelled: { color: 'bg-gray-100 text-gray-800', icon: <AlertCircle className="w-3 h-3" /> }
    };
    const config = statusConfig[status] || statusConfig.ordered;
    return (
      <Badge className={`${config.color} flex items-center gap-1`}>
        {config.icon}
        {status.charAt(0).toUpperCase() + status.slice(1)}
      </Badge>
    );
  };

  const getPriorityBadge = (priority: string) => {
    const priorityConfig: Record<string, string> = {
      routine: 'bg-gray-100 text-gray-800',
      urgent: 'bg-orange-100 text-orange-800',
      stat: 'bg-red-100 text-red-800'
    };
    return (
      <Badge className={priorityConfig[priority] || priorityConfig.routine}>
        {priority.toUpperCase()}
      </Badge>
    );
  };

  const getInterpretationBadge = (interpretation: string) => {
    const config: Record<string, { color: string; icon: React.ReactNode }> = {
      normal: { color: 'bg-green-100 text-green-800', icon: <CheckCircle2 className="w-3 h-3" /> },
      low: { color: 'bg-yellow-100 text-yellow-800', icon: <TrendingDown className="w-3 h-3" /> },
      high: { color: 'bg-orange-100 text-orange-800', icon: <TrendingUp className="w-3 h-3" /> },
      critical_low: { color: 'bg-red-100 text-red-800', icon: <AlertCircle className="w-3 h-3" /> },
      critical_high: { color: 'bg-red-100 text-red-800', icon: <AlertCircle className="w-3 h-3" /> }
    };
    const c = config[interpretation] || config.normal;
    return (
      <Badge className={`${c.color} flex items-center gap-1`}>
        {c.icon}
        {interpretation.replace('_', ' ')}
      </Badge>
    );
  };

  const filteredTests = tests.filter(test => 
    test.order_number.toLowerCase().includes(searchQuery.toLowerCase()) ||
    test.results.some(r => r.test_name.toLowerCase().includes(searchQuery.toLowerCase()))
  );

  return (
    <Card className="w-full">
      <CardHeader className="flex flex-row items-center justify-between">
        <CardTitle className="flex items-center gap-2">
          <FlaskConical className="w-5 h-5" />
          Laboratory Tests
        </CardTitle>
        <div className="flex items-center gap-2">
          <div className="relative">
            <Search className="absolute left-2 top-2.5 h-4 w-4 text-muted-foreground" />
            <Input
              placeholder="Search tests..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-8 w-64"
            />
          </div>
          <Dialog open={showNewOrderDialog} onOpenChange={setShowNewOrderDialog}>
            <DialogTrigger asChild>
              <Button>
                <Plus className="w-4 h-4 mr-2" />
                New Order
              </Button>
            </DialogTrigger>
            <DialogContent className="max-w-lg">
              <DialogHeader>
                <DialogTitle>Create New Laboratory Order</DialogTitle>
              </DialogHeader>
              <NewOrderForm 
                panels={panels} 
                onSubmit={handleCreateOrder}
                onCancel={() => setShowNewOrderDialog(false)}
              />
            </DialogContent>
          </Dialog>
        </div>
      </CardHeader>
      <CardContent>
        <Tabs defaultValue="orders">
          <TabsList>
            <TabsTrigger value="orders">Orders</TabsTrigger>
            <TabsTrigger value="results">Results</TabsTrigger>
            <TabsTrigger value="trends">Trends</TabsTrigger>
          </TabsList>

          <TabsContent value="orders" className="space-y-4">
            {filteredTests.map((test) => (
              <div 
                key={test.id}
                className="border rounded-lg p-4 hover:bg-gray-50 cursor-pointer transition-colors"
                onClick={() => setSelectedTest(selectedTest?.id === test.id ? null : test)}
              >
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-4">
                    {selectedTest?.id === test.id ? 
                      <ChevronDown className="w-4 h-4" /> : 
                      <ChevronRight className="w-4 h-4" />
                    }
                    <div>
                      <p className="font-medium">{test.order_number}</p>
                      <p className="text-sm text-muted-foreground">
                        {new Date(test.order_date).toLocaleDateString()}
                      </p>
                    </div>
                  </div>
                  <div className="flex items-center gap-2">
                    {getStatusBadge(test.status)}
                    {getPriorityBadge(test.priority)}
                  </div>
                </div>

                {selectedTest?.id === test.id && test.results.length > 0 && (
                  <div className="mt-4 pl-8">
                    <table className="w-full">
                      <thead>
                        <tr className="text-left text-sm text-muted-foreground">
                          <th className="pb-2">Test</th>
                          <th className="pb-2">Value</th>
                          <th className="pb-2">Reference</th>
                          <th className="pb-2">Status</th>
                        </tr>
                      </thead>
                      <tbody>
                        {test.results.map((result) => (
                          <tr key={result.id} className="border-t">
                            <td className="py-2">{result.test_name}</td>
                            <td className="py-2">
                              {result.value_numeric !== null ? (
                                <span className={result.is_critical ? 'text-red-600 font-bold' : ''}>
                                  {result.value_numeric} {result.unit}
                                </span>
                              ) : (
                                result.value_text || '-'
                              )}
                            </td>
                            <td className="py-2 text-sm text-muted-foreground">
                              {result.reference_min !== null && result.reference_max !== null && (
                                `${result.reference_min} - ${result.reference_max} ${result.unit}`
                              )}
                            </td>
                            <td className="py-2">
                              {getInterpretationBadge(result.interpretation)}
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                )}
              </div>
            ))}
          </TabsContent>

          <TabsContent value="results">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {Array.from(new Set(tests.flatMap(t => t.results).map(r => r.test_code))).map(testCode => {
                const latestResult = tests
                  .flatMap(t => t.results)
                  .filter(r => r.test_code === testCode)
                  .sort((a, b) => new Date(b.created_at).getTime() - new Date(a.created_at).getTime())[0];
                
                if (!latestResult) return null;

                return (
                  <Card 
                    key={testCode} 
                    className="cursor-pointer hover:shadow-md transition-shadow"
                    onClick={() => loadTestHistory(testCode)}
                  >
                    <CardContent className="p-4">
                      <div className="flex items-center justify-between">
                        <div>
                          <p className="font-medium">{latestResult.test_name}</p>
                          <p className="text-2xl font-bold mt-1">
                            {latestResult.value_numeric} 
                            <span className="text-sm font-normal text-muted-foreground ml-1">
                              {latestResult.unit}
                            </span>
                          </p>
                        </div>
                        {getInterpretationBadge(latestResult.interpretation)}
                      </div>
                      <p className="text-xs text-muted-foreground mt-2">
                        Ref: {latestResult.reference_min} - {latestResult.reference_max} {latestResult.unit}
                      </p>
                    </CardContent>
                  </Card>
                );
              })}
            </div>
          </TabsContent>

          <TabsContent value="trends">
            {testHistory.length > 0 && (
              <div className="h-80">
                <ResponsiveContainer width="100%" height="100%">
                  <LineChart data={testHistory}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis 
                      dataKey="date" 
                      tickFormatter={(value) => new Date(value).toLocaleDateString()}
                    />
                    <YAxis />
                    <Tooltip 
                      labelFormatter={(value) => new Date(value).toLocaleDateString()}
                    />
                    <ReferenceLine 
                      y={testHistory[0]?.reference_max} 
                      stroke="red" 
                      strokeDasharray="3 3"
                      label="Max"
                    />
                    <ReferenceLine 
                      y={testHistory[0]?.reference_min} 
                      stroke="red" 
                      strokeDasharray="3 3"
                      label="Min"
                    />
                    <Line 
                      type="monotone" 
                      dataKey="value" 
                      stroke="#2563eb" 
                      strokeWidth={2}
                      dot={{ fill: '#2563eb' }}
                    />
                  </LineChart>
                </ResponsiveContainer>
              </div>
            )}
          </TabsContent>
        </Tabs>
      </CardContent>
    </Card>
  );
};

const NewOrderForm: React.FC<{
  panels: TestPanel[];
  onSubmit: (panelCode: string, priority: string) => void;
  onCancel: () => void;
}> = ({ panels, onSubmit, onCancel }) => {
  const [selectedPanel, setSelectedPanel] = useState('');
  const [priority, setPriority] = useState('routine');

  return (
    <div className="space-y-4">
      <div>
        <label className="text-sm font-medium">Test Panel</label>
        <Select value={selectedPanel} onValueChange={setSelectedPanel}>
          <SelectTrigger>
            <SelectValue placeholder="Select a panel" />
          </SelectTrigger>
          <SelectContent>
            {panels.map((panel) => (
              <SelectItem key={panel.id} value={panel.code}>
                {panel.name} ({panel.test_codes.length} tests)
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>

      <div>
        <label className="text-sm font-medium">Priority</label>
        <Select value={priority} onValueChange={setPriority}>
          <SelectTrigger>
            <SelectValue />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="routine">Routine</SelectItem>
            <SelectItem value="urgent">Urgent</SelectItem>
            <SelectItem value="stat">STAT</SelectItem>
          </SelectContent>
        </Select>
      </div>

      <div className="flex justify-end gap-2">
        <Button variant="outline" onClick={onCancel}>Cancel</Button>
        <Button 
          onClick={() => onSubmit(selectedPanel, priority)}
          disabled={!selectedPanel}
        >
          Create Order
        </Button>
      </div>
    </div>
  );
};

export default LaboratoryPanel;