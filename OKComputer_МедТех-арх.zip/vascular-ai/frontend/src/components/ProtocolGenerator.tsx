import { useState, useEffect } from 'react'
import { 
  FileText, 
  Download, 
  Loader2, 
  CheckCircle2, 
  Stethoscope,
  ClipboardList,
  AlertCircle,
  BookOpen,
  ChevronDown,
  ChevronUp,
  FolderOpen,
  Activity,
  Scissors,
  Zap
} from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Textarea } from '@/components/ui/textarea'
import { Badge } from '@/components/ui/badge'
import { Separator } from '@/components/ui/separator'
import { toast } from 'sonner'
import type { Study, SegmentationResult } from '../App'

interface ProtocolGeneratorProps {
  study: Study
  segmentation: SegmentationResult
}

interface ProtocolCategory {
  name: string
  protocols: ProtocolType[]
}

interface ProtocolType {
  id: string
  name: string
  name_en: string
}

const API_URL = import.meta.env.VITE_API_URL || 'http://localhost:8000'

const categoryIcons: Record<string, React.ReactNode> = {
  open_surgery: <Scissors className="h-5 w-5" />,
  endovascular: <Zap className="h-5 w-5" />,
}

const categoryNames: Record<string, string> = {
  open_surgery: 'Открытые операции',
  endovascular: 'Эндоваскулярные операции',
}

export default function ProtocolGenerator({ 
  study, 
  segmentation 
}: ProtocolGeneratorProps) {
  const [categories, setCategories] = useState<Record<string, ProtocolCategory>>({})
  const [selectedType, setSelectedType] = useState('')
  const [surgeonName, setSurgeonName] = useState('')
  const [notes, setNotes] = useState('')
  const [generating, setGenerating] = useState(false)
  const [protocol, setProtocol] = useState<any>(null)
  const [expandedCategory, setExpandedCategory] = useState<string | null>(null)
  const [loadingProtocols, setLoadingProtocols] = useState(true)

  // Load protocol categories on mount
  useEffect(() => {
    loadProtocolCategories()
  }, [])

  const loadProtocolCategories = async () => {
    try {
      setLoadingProtocols(true)
      const response = await fetch(`${API_URL}/api/protocols/categories`)
      
      if (response.ok) {
        const data = await response.json()
        setCategories(data)
        // Expand first category by default
        const firstCategory = Object.keys(data)[0]
        if (firstCategory) {
          setExpandedCategory(firstCategory)
        }
      }
    } catch (error) {
      toast.error('Ошибка загрузки списка протоколов')
      console.error(error)
    } finally {
      setLoadingProtocols(false)
    }
  }

  const generateProtocol = async () => {
    if (!selectedType) {
      toast.error('Выберите тип операции')
      return
    }

    try {
      setGenerating(true)
      
      const response = await fetch(`${API_URL}/api/protocols/generate`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          study_id: study.id,
          protocol_type: selectedType,
          surgeon_name: surgeonName || 'Хирург',
          notes,
        }),
      })

      if (!response.ok) {
        const error = await response.json()
        throw new Error(error.detail || 'Failed to generate protocol')
      }

      const data = await response.json()
      
      if (data.success) {
        setProtocol(data.protocol)
        toast.success('Протокол успешно сгенерирован!')
      } else {
        throw new Error(data.message || 'Generation failed')
      }
    } catch (error: any) {
      toast.error(`Ошибка генерации: ${error.message}`)
      console.error(error)
    } finally {
      setGenerating(false)
    }
  }

  const downloadProtocol = () => {
    if (protocol?.download_url) {
      window.open(`${API_URL}${protocol.download_url}`, '_blank')
    }
  }

  const toggleCategory = (category: string) => {
    setExpandedCategory(expandedCategory === category ? null : category)
  }

  if (loadingProtocols) {
    return (
      <Card>
        <CardContent className="p-8 flex justify-center">
          <Loader2 className="h-8 w-8 animate-spin text-blue-500" />
        </CardContent>
      </Card>
    )
  }

  return (
    <div className="space-y-6">
      {/* Protocol Type Selection */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center space-x-2">
            <FileText className="h-5 w-5" />
            <span>Генерация операционного протокола</span>
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          {/* Surgeon Info */}
          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="surgeon">ФИО хирурга</Label>
              <Input
                id="surgeon"
                placeholder="Иванов И.И."
                value={surgeonName}
                onChange={(e) => setSurgeonName(e.target.value)}
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="notes">Примечания</Label>
              <Textarea
                id="notes"
                placeholder="Особенности пациента..."
                value={notes}
                onChange={(e) => setNotes(e.target.value)}
                rows={1}
              />
            </div>
          </div>

          <Separator />

          {/* Protocol Categories */}
          <div>
            <Label className="mb-3 block">Тип операции</Label>
            <div className="space-y-2">
              {Object.entries(categories).map(([catId, category]) => (
                <div key={catId} className="border rounded-lg overflow-hidden">
                  <button
                    onClick={() => toggleCategory(catId)}
                    className="w-full flex items-center justify-between p-3 bg-gray-50 hover:bg-gray-100 transition-colors"
                  >
                    <div className="flex items-center space-x-2">
                      {categoryIcons[catId] || <FolderOpen className="h-5 w-5" />}
                      <span className="font-medium">{categoryNames[catId] || catId}</span>
                      <Badge variant="secondary">{category.protocols.length}</Badge>
                    </div>
                    {expandedCategory === catId ? (
                      <ChevronUp className="h-5 w-5 text-gray-400" />
                    ) : (
                      <ChevronDown className="h-5 w-5 text-gray-400" />
                    )}
                  </button>
                  
                  {expandedCategory === catId && (
                    <div className="p-2 space-y-1">
                      {category.protocols.map((proto) => (
                        <div
                          key={proto.id}
                          onClick={() => setSelectedType(proto.id)}
                          className={`
                            p-3 rounded-lg cursor-pointer transition-colors
                            ${selectedType === proto.id 
                              ? 'bg-blue-50 border-2 border-blue-500' 
                              : 'hover:bg-gray-50 border-2 border-transparent'
                            }
                          `}
                        >
                          <div className="flex items-start space-x-2">
                            <Stethoscope className="h-4 w-4 mt-0.5 text-gray-400" />
                            <div>
                              <div className="font-medium text-sm">{proto.name}</div>
                              <div className="text-xs text-gray-500">{proto.name_en}</div>
                            </div>
                          </div>
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              ))}
            </div>
          </div>

          {/* Selected Protocol Info */}
          {selectedType && (
            <div className="bg-blue-50 p-3 rounded-lg">
              <div className="flex items-center space-x-2 text-blue-700">
                <CheckCircle2 className="h-4 w-4" />
                <span className="text-sm font-medium">
                  Выбрано: {Object.values(categories)
                    .flatMap(c => c.protocols)
                    .find(p => p.id === selectedType)?.name}
                </span>
              </div>
            </div>
          )}

          {/* Generate Button */}
          <Button
            onClick={generateProtocol}
            disabled={generating || !selectedType}
            className="w-full"
            size="lg"
          >
            {generating ? (
              <>
                <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                Генерация протокола...
              </>
            ) : (
              <>
                <FileText className="h-4 w-4 mr-2" />
                Сгенерировать протокол
              </>
            )}
          </Button>
        </CardContent>
      </Card>

      {/* Generated Protocol */}
      {protocol && (
        <Card>
          <CardHeader className="flex flex-row items-center justify-between">
            <CardTitle className="flex items-center space-x-2">
              <CheckCircle2 className="h-5 w-5 text-green-500" />
              <span>{protocol.title}</span>
            </CardTitle>
            <Button
              variant="outline"
              size="sm"
              onClick={downloadProtocol}
            >
              <Download className="h-4 w-4 mr-2" />
              Открыть HTML
            </Button>
          </CardHeader>
          <CardContent className="space-y-4">
            {/* Preoperative Plan */}
            <div>
              <h4 className="text-sm font-medium mb-2 flex items-center">
                <BookOpen className="h-4 w-4 mr-1" />
                Предоперационное планирование
              </h4>
              <div className="bg-gray-50 p-3 rounded-lg space-y-2">
                <div>
                  <span className="text-xs text-gray-500">Показания:</span>
                  <ul className="list-disc list-inside text-sm mt-1">
                    {protocol.preoperative_plan?.indications?.map((ind: string, i: number) => (
                      <li key={i}>{ind}</li>
                    ))}
                  </ul>
                </div>
                <div className="grid grid-cols-2 gap-2 text-sm">
                  <div>
                    <span className="text-xs text-gray-500">Доступ:</span>
                    <p>{protocol.preoperative_plan?.recommended_approach}</p>
                  </div>
                  <div>
                    <span className="text-xs text-gray-500">Материал:</span>
                    <p>{protocol.preoperative_plan?.graft_recommendation}</p>
                  </div>
                </div>
                <div>
                  <span className="text-xs text-gray-500">Ориентировочная длительность:</span>
                  <p className="text-sm">{protocol.preoperative_plan?.estimated_duration}</p>
                </div>
              </div>
            </div>

            <Separator />

            {/* Operation Steps */}
            <div>
              <h4 className="text-sm font-medium mb-2 flex items-center">
                <ClipboardList className="h-4 w-4 mr-1" />
                Этапы операции
              </h4>
              <ol className="list-decimal list-inside space-y-1">
                {protocol.operation_steps?.slice(0, 5).map((step: string, i: number) => (
                  <li key={i} className="text-sm">{step}</li>
                ))}
                {protocol.operation_steps?.length > 5 && (
                  <li className="text-sm text-gray-500">
                    ... и ещё {protocol.operation_steps.length - 5} этапов
                  </li>
                )}
              </ol>
            </div>

            <Separator />

            {/* Checklist */}
            <div>
              <h4 className="text-sm font-medium mb-2 flex items-center">
                <CheckCircle2 className="h-4 w-4 mr-1" />
                Чек-лист безопасности
              </h4>
              <div className="space-y-1">
                {protocol.checklist?.slice(0, 3).map((item: string, i: number) => (
                  <div key={i} className="flex items-center space-x-2 text-sm">
                    <input type="checkbox" className="rounded" />
                    <span>{item}</span>
                  </div>
                ))}
                {protocol.checklist?.length > 3 && (
                  <p className="text-sm text-gray-500">
                    ... и ещё {protocol.checklist.length - 3} пунктов
                  </p>
                )}
              </div>
            </div>

            <Separator />

            {/* Risks */}
            <div>
              <h4 className="text-sm font-medium mb-2 flex items-center">
                <AlertCircle className="h-4 w-4 mr-1" />
                Возможные осложнения
              </h4>
              <div className="flex flex-wrap gap-2">
                {protocol.risks?.slice(0, 4).map((risk: string, i: number) => (
                  <Badge key={i} variant="secondary" className="text-xs">
                    {risk}
                  </Badge>
                ))}
                {protocol.risks?.length > 4 && (
                  <Badge variant="outline" className="text-xs">
                    +{protocol.risks.length - 4}
                  </Badge>
                )}
              </div>
            </div>

            {/* Materials */}
            {protocol.graft_types && protocol.graft_types.length > 0 && (
              <>
                <Separator />
                <div>
                  <h4 className="text-sm font-medium mb-2 flex items-center">
                    <Activity className="h-4 w-4 mr-1" />
                    Рекомендуемые материалы
                  </h4>
                  <div className="flex flex-wrap gap-2">
                    {protocol.graft_types.map((graft: string, i: number) => (
                      <Badge key={i} variant="outline" className="text-xs">
                        {graft}
                      </Badge>
                    ))}
                  </div>
                </div>
              </>
            )}

            {/* References */}
            <div className="bg-blue-50 p-3 rounded-lg">
              <h4 className="text-sm font-medium mb-1">Ссылки на гайдлайны</h4>
              <div className="flex flex-wrap gap-2">
                {protocol.references?.map((ref: string, i: number) => (
                  <Badge key={i} variant="outline" className="text-xs">
                    {ref}
                  </Badge>
                ))}
              </div>
            </div>

            {/* Surgeon Notes */}
            {protocol.surgeon_notes && (
              <div>
                <h4 className="text-sm font-medium mb-1">Примечания хирурга</h4>
                <p className="text-sm text-gray-600">{protocol.surgeon_notes}</p>
              </div>
            )}
          </CardContent>
        </Card>
      )}
    </div>
  )
}
