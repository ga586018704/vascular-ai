import { useState, useCallback } from 'react'
import { useDropzone } from 'react-dropzone'
import { Upload, File, X, Loader2 } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Progress } from '@/components/ui/progress'
import { toast } from 'sonner'

interface DicomUploadProps {
  onUploadSuccess: () => void
}

const API_URL = import.meta.env.VITE_API_URL || 'http://localhost:8000'

export default function DicomUpload({ onUploadSuccess }: DicomUploadProps) {
  const [files, setFiles] = useState<File[]>([])
  const [uploading, setUploading] = useState(false)
  const [progress, setProgress] = useState(0)

  const onDrop = useCallback((acceptedFiles: File[]) => {
    // Filter only DICOM files
    const dicomFiles = acceptedFiles.filter(file => 
      file.name.endsWith('.dcm') || file.name.endsWith('.DCM')
    )
    
    if (dicomFiles.length !== acceptedFiles.length) {
      toast.warning('Некоторые файлы не являются DICOM и были пропущены')
    }
    
    setFiles(prev => [...prev, ...dicomFiles])
  }, [])

  const { getRootProps, getInputProps, isDragActive } = useDropzone({
    onDrop,
    accept: {
      'application/dicom': ['.dcm', '.DCM']
    }
  })

  const removeFile = (index: number) => {
    setFiles(prev => prev.filter((_, i) => i !== index))
  }

  const clearFiles = () => {
    setFiles([])
    setProgress(0)
  }

  const handleUpload = async () => {
    if (files.length === 0) {
      toast.error('Выберите DICOM файлы')
      return
    }

    setUploading(true)
    setProgress(0)

    const formData = new FormData()
    files.forEach(file => {
      formData.append('files', file)
    })

    try {
      const response = await fetch(`${API_URL}/api/dicom/upload`, {
        method: 'POST',
        body: formData,
      })

      if (!response.ok) {
        throw new Error('Upload failed')
      }

      const data = await response.json()
      
      if (data.success) {
        toast.success(`Загружено ${data.num_files} срезов`)
        clearFiles()
        onUploadSuccess()
      } else {
        throw new Error(data.message || 'Upload failed')
      }
    } catch (error) {
      toast.error('Ошибка загрузки файлов')
      console.error(error)
    } finally {
      setUploading(false)
    }
  }

  const formatFileSize = (bytes: number) => {
    if (bytes === 0) return '0 Bytes'
    const k = 1024
    const sizes = ['Bytes', 'KB', 'MB', 'GB']
    const i = Math.floor(Math.log(bytes) / Math.log(k))
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i]
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center space-x-2">
          <Upload className="h-5 w-5" />
          <span>Загрузка DICOM (КТ-ангиография)</span>
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        {/* Dropzone */}
        <div
          {...getRootProps()}
          className={`
            border-2 border-dashed rounded-lg p-8 text-center cursor-pointer
            transition-colors duration-200
            ${isDragActive 
              ? 'border-blue-500 bg-blue-50' 
              : 'border-gray-300 hover:border-gray-400'
            }
          `}
        >
          <input {...getInputProps()} />
          <Upload className="h-12 w-12 mx-auto text-gray-400 mb-4" />
          {isDragActive ? (
            <p className="text-blue-600">Отпустите файлы здесь...</p>
          ) : (
            <div>
              <p className="text-gray-600 mb-2">
                Перетащите DICOM файлы сюда или кликните для выбора
              </p>
              <p className="text-sm text-gray-400">
                Поддерживаются файлы .dcm (КТ-ангиография)
              </p>
            </div>
          )}
        </div>

        {/* File List */}
        {files.length > 0 && (
          <div className="space-y-2">
            <div className="flex items-center justify-between">
              <span className="text-sm font-medium">
                Выбрано файлов: {files.length}
              </span>
              <Button
                variant="ghost"
                size="sm"
                onClick={clearFiles}
                disabled={uploading}
              >
                <X className="h-4 w-4 mr-1" />
                Очистить
              </Button>
            </div>
            
            <div className="max-h-40 overflow-y-auto border rounded-lg divide-y">
              {files.map((file, index) => (
                <div
                  key={index}
                  className="flex items-center justify-between p-2 hover:bg-gray-50"
                >
                  <div className="flex items-center space-x-2">
                    <File className="h-4 w-4 text-blue-500" />
                    <span className="text-sm truncate max-w-xs">
                      {file.name}
                    </span>
                    <span className="text-xs text-gray-400">
                      {formatFileSize(file.size)}
                    </span>
                  </div>
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => removeFile(index)}
                    disabled={uploading}
                  >
                    <X className="h-4 w-4" />
                  </Button>
                </div>
              ))}
            </div>

            {/* Progress */}
            {uploading && (
              <div className="space-y-2">
                <Progress value={progress} />
                <p className="text-sm text-center text-gray-500">
                  Загрузка и обработка...
                </p>
              </div>
            )}

            {/* Upload Button */}
            <Button
              className="w-full"
              onClick={handleUpload}
              disabled={uploading}
            >
              {uploading ? (
                <>
                  <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                  Загрузка...
                </>
              ) : (
                <>
                  <Upload className="h-4 w-4 mr-2" />
                  Загрузить {files.length} файл(ов)
                </>
              )}
            </Button>
          </div>
        )}
      </CardContent>
    </Card>
  )
}
