import { useEffect, useRef, useState, useCallback } from 'react'
import { 
  ZoomIn, 
  ZoomOut, 
  RotateCcw,
  Play,
  Pause,
  Sun,
  Contrast,
  ChevronLeft,
  ChevronRight,
  Maximize2,
  Minimize2,
  Grid3X3
} from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Slider } from '@/components/ui/slider'
import { Badge } from '@/components/ui/badge'
import { toast } from 'sonner'
import type { Study } from '../App'

// DICOM Parser for metadata
import dicomParser from 'dicom-parser'

interface DicomViewerProps {
  study: Study
}

interface DicomImage {
  filename: string
  data: ArrayBuffer
  instanceNumber: number
  sliceLocation: number
  rows: number
  columns: number
  pixelSpacing: number[]
  windowCenter: number
  windowWidth: number
  bitsAllocated: number
  bitsStored: number
  highBit: number
  rescaleSlope: number
  rescaleIntercept: number
}

const API_URL = import.meta.env.VITE_API_URL || 'http://localhost:8000'

export default function DicomViewer({ study }: DicomViewerProps) {
  const canvasRef = useRef<HTMLCanvasElement>(null)
  const containerRef = useRef<HTMLDivElement>(null)
  const [images, setImages] = useState<DicomImage[]>([])
  const [currentIndex, setCurrentIndex] = useState(0)
  const [loading, setLoading] = useState(true)
  const [zoom, setZoom] = useState(1)
  const [playing, setPlaying] = useState(false)
  const [windowWidth, setWindowWidth] = useState(400)
  const [windowCenter, setWindowCenter] = useState(40)
  const [pan, setPan] = useState({ x: 0, y: 0 })
  const [isDragging, setIsDragging] = useState(false)
  const [dragStart, setDragStart] = useState({ x: 0, y: 0 })
  const playIntervalRef = useRef<NodeJS.Timeout | null>(null)

  // Load DICOM files
  useEffect(() => {
    const loadDicomFiles = async () => {
      try {
        setLoading(true)
        
        // Get list of files from study path
        const response = await fetch(`${API_URL}/api/dicom/studies/${study.id}/files`)
        if (!response.ok) throw new Error('Failed to get file list')
        
        const { files } = await response.json()
        
        // Load each DICOM file
        const loadedImages: DicomImage[] = []
        
        for (const filename of files) {
          try {
            const fileResponse = await fetch(
              `${API_URL}/api/dicom/studies/${study.study_uid}/file/${filename}`
            )
            if (!fileResponse.ok) continue
            
            const arrayBuffer = await fileResponse.arrayBuffer()
            
            // Parse DICOM metadata
            const dataSet = dicomParser.parseDicom(new Uint8Array(arrayBuffer))
            
            const image: DicomImage = {
              filename,
              data: arrayBuffer,
              instanceNumber: dataSet.intString('x00200013') || 0,
              sliceLocation: dataSet.floatString('x00201041') || 0,
              rows: dataSet.uint16('x00280010') || 512,
              columns: dataSet.uint16('x00280011') || 512,
              pixelSpacing: parsePixelSpacing(dataSet.string('x00280030')),
              windowCenter: dataSet.floatString('x00281050') || 40,
              windowWidth: dataSet.floatString('x00281051') || 400,
              bitsAllocated: dataSet.uint16('x00280100') || 16,
              bitsStored: dataSet.uint16('x00280101') || 16,
              highBit: dataSet.uint16('x00280102') || 15,
              rescaleSlope: dataSet.floatString('x00281053') || 1,
              rescaleIntercept: dataSet.floatString('x00281052') || 0,
            }
            
            loadedImages.push(image)
          } catch (e) {
            console.error(`Error loading ${filename}:`, e)
          }
        }
        
        // Sort by instance number
        loadedImages.sort((a, b) => a.instanceNumber - b.instanceNumber)
        
        setImages(loadedImages)
        
        if (loadedImages.length > 0) {
          setWindowWidth(loadedImages[0].windowWidth)
          setWindowCenter(loadedImages[0].windowCenter)
        }
        
        toast.success(`Загружено ${loadedImages.length} срезов`)
      } catch (error) {
        toast.error('Ошибка загрузки DICOM файлов')
        console.error(error)
      } finally {
        setLoading(false)
      }
    }
    
    loadDicomFiles()
  }, [study])

  // Render current image
  useEffect(() => {
    if (images.length === 0 || !canvasRef.current) return
    
    renderImage()
  }, [images, currentIndex, windowWidth, windowCenter, zoom, pan])

  const parsePixelSpacing = (spacing: string | undefined): number[] => {
    if (!spacing) return [1, 1]
    const parts = spacing.split('\\').map(parseFloat)
    return parts.length === 2 ? parts : [1, 1]
  }

  const renderImage = () => {
    const canvas = canvasRef.current
    if (!canvas || images.length === 0) return
    
    const ctx = canvas.getContext('2d')
    if (!ctx) return
    
    const image = images[currentIndex]
    
    // Parse DICOM pixel data
    try {
      const dataSet = dicomParser.parseDicom(new Uint8Array(image.data))
      const pixelDataElement = dataSet.elements.x7fe00010
      
      if (!pixelDataElement) return
      
      // Get pixel data
      const pixelData = new Int16Array(
        dataSet.byteArray.buffer,
        pixelDataElement.dataOffset,
        pixelDataElement.length / 2
      )
      
      // Set canvas size
      canvas.width = image.columns
      canvas.height = image.rows
      
      // Create ImageData
      const imageData = ctx.createImageData(image.columns, image.rows)
      
      // Apply window/level and convert to 8-bit
      const min = windowCenter - windowWidth / 2
      const max = windowCenter + windowWidth / 2
      
      for (let i = 0; i < pixelData.length; i++) {
        // Apply rescale
        let value = pixelData[i] * image.rescaleSlope + image.rescaleIntercept
        
        // Apply window/level
        value = ((value - min) / (max - min)) * 255
        value = Math.max(0, Math.min(255, value))
        
        const idx = i * 4
        imageData.data[idx] = value     // R
        imageData.data[idx + 1] = value // G
        imageData.data[idx + 2] = value // B
        imageData.data[idx + 3] = 255   // A
      }
      
      // Clear canvas
      ctx.fillStyle = 'black'
      ctx.fillRect(0, 0, canvas.width, canvas.height)
      
      // Apply transformations
      ctx.save()
      
      // Translate to center for zoom
      const centerX = canvas.width / 2
      const centerY = canvas.height / 2
      
      ctx.translate(centerX + pan.x, centerY + pan.y)
      ctx.scale(zoom, zoom)
      ctx.translate(-centerX, -centerY)
      
      // Draw image
      ctx.putImageData(imageData, 0, 0)
      
      ctx.restore()
      
    } catch (error) {
      console.error('Error rendering image:', error)
    }
  }

  const handlePrevSlice = () => {
    setCurrentIndex(prev => Math.max(0, prev - 1))
  }

  const handleNextSlice = () => {
    setCurrentIndex(prev => Math.min(images.length - 1, prev + 1))
  }

  const handlePlay = () => {
    if (playing) {
      if (playIntervalRef.current) {
        clearInterval(playIntervalRef.current)
      }
      setPlaying(false)
    } else {
      setPlaying(true)
      playIntervalRef.current = setInterval(() => {
        setCurrentIndex(prev => {
          if (prev >= images.length - 1) {
            return 0
          }
          return prev + 1
        })
      }, 100)
    }
  }

  const handleZoomIn = () => setZoom(prev => Math.min(5, prev + 0.25))
  const handleZoomOut = () => setZoom(prev => Math.max(0.25, prev - 0.25))
  const handleReset = () => {
    setZoom(1)
    setPan({ x: 0, y: 0 })
    if (images.length > 0) {
      setWindowWidth(images[currentIndex].windowWidth)
      setWindowCenter(images[currentIndex].windowCenter)
    }
  }

  const handleMouseDown = (e: React.MouseEvent) => {
    if (e.button === 1 || (e.button === 0 && e.shiftKey)) {
      setIsDragging(true)
      setDragStart({ x: e.clientX - pan.x, y: e.clientY - pan.y })
    }
  }

  const handleMouseMove = (e: React.MouseEvent) => {
    if (isDragging) {
      setPan({
        x: e.clientX - dragStart.x,
        y: e.clientY - dragStart.y
      })
    }
  }

  const handleMouseUp = () => {
    setIsDragging(false)
  }

  const handleWheel = (e: React.WheelEvent) => {
    e.preventDefault()
    if (e.deltaY < 0) {
      handleZoomIn()
    } else {
      handleZoomOut()
    }
  }

  useEffect(() => {
    return () => {
      if (playIntervalRef.current) {
        clearInterval(playIntervalRef.current)
      }
    }
  }, [])

  if (loading) {
    return (
      <Card className="h-[600px] flex items-center justify-center">
        <div className="flex flex-col items-center space-y-4">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-500"></div>
          <p className="text-gray-500">Загрузка DICOM файлов...</p>
        </div>
      </Card>
    )
  }

  if (images.length === 0) {
    return (
      <Card className="h-[600px] flex items-center justify-center">
        <p className="text-gray-500">Не удалось загрузить изображения</p>
      </Card>
    )
  }

  const currentImage = images[currentIndex]

  return (
    <Card className="h-full">
      <CardHeader className="flex flex-row items-center justify-between pb-2">
        <CardTitle className="flex items-center space-x-2 text-base">
          <span>Просмотр КТ:</span>
          <Badge variant="outline">{study.patient_id}</Badge>
          <Badge variant="secondary">
            {currentIndex + 1} / {images.length}
          </Badge>
        </CardTitle>
        <div className="flex items-center space-x-1">
          <Button variant="ghost" size="sm" onClick={handleZoomOut}>
            <ZoomOut className="h-4 w-4" />
          </Button>
          <span className="text-sm text-gray-500 w-16 text-center">
            {Math.round(zoom * 100)}%
          </span>
          <Button variant="ghost" size="sm" onClick={handleZoomIn}>
            <ZoomIn className="h-4 w-4" />
          </Button>
          <Button variant="ghost" size="sm" onClick={handleReset}>
            <RotateCcw className="h-4 w-4" />
          </Button>
        </div>
      </CardHeader>
      
      <CardContent className="space-y-4">
        {/* Canvas Container */}
        <div 
          ref={containerRef}
          className="relative bg-black rounded-lg overflow-hidden flex items-center justify-center"
          style={{ height: '500px' }}
          onMouseDown={handleMouseDown}
          onMouseMove={handleMouseMove}
          onMouseUp={handleMouseUp}
          onMouseLeave={handleMouseUp}
          onWheel={handleWheel}
        >
          <canvas
            ref={canvasRef}
            className="max-w-full max-h-full"
            style={{ 
              cursor: isDragging ? 'grabbing' : 'grab',
              imageRendering: 'pixelated'
            }}
          />
          
          {/* Info Overlay */}
          <div className="absolute top-2 left-2 bg-black/70 text-white text-xs px-2 py-1 rounded space-y-1">
            <div>WW: {Math.round(windowWidth)}</div>
            <div>WL: {Math.round(windowCenter)}</div>
            <div>Zoom: {Math.round(zoom * 100)}%</div>
          </div>
          
          <div className="absolute top-2 right-2 bg-black/70 text-white text-xs px-2 py-1 rounded">
            {currentImage?.rows} x {currentImage?.columns}
          </div>
          
          <div className="absolute bottom-2 left-2 bg-black/70 text-white text-xs px-2 py-1 rounded">
            Slice: {currentIndex + 1} / {images.length}
          </div>
        </div>

        {/* Controls */}
        <div className="space-y-4">
          {/* Slice Navigation */}
          <div className="flex items-center space-x-4">
            <Button
              variant="outline"
              size="sm"
              onClick={handlePrevSlice}
              disabled={currentIndex === 0 || playing}
            >
              <ChevronLeft className="h-4 w-4" />
            </Button>
            
            <div className="flex-1">
              <Slider
                value={[currentIndex]}
                onValueChange={([value]) => setCurrentIndex(value)}
                max={images.length - 1}
                step={1}
                disabled={playing}
              />
            </div>
            
            <Button
              variant="outline"
              size="sm"
              onClick={handleNextSlice}
              disabled={currentIndex >= images.length - 1 || playing}
            >
              <ChevronRight className="h-4 w-4" />
            </Button>
            
            <Button
              variant={playing ? 'default' : 'outline'}
              size="sm"
              onClick={handlePlay}
            >
              {playing ? (
                <Pause className="h-4 w-4" />
              ) : (
                <Play className="h-4 w-4" />
              )}
            </Button>
          </div>

          {/* Window/Level Controls */}
          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <div className="flex items-center space-x-2">
                <Contrast className="h-4 w-4 text-gray-500" />
                <label className="text-sm text-gray-500">Window Width</label>
              </div>
              <Slider
                value={[windowWidth]}
                onValueChange={([value]) => setWindowWidth(value)}
                min={1}
                max={2000}
                step={10}
              />
            </div>
            <div className="space-y-2">
              <div className="flex items-center space-x-2">
                <Sun className="h-4 w-4 text-gray-500" />
                <label className="text-sm text-gray-500">Window Center</label>
              </div>
              <Slider
                value={[windowCenter]}
                onValueChange={([value]) => setWindowCenter(value)}
                min={-1000}
                max={1000}
                step={10}
              />
            </div>
          </div>
          
          {/* Presets */}
          <div className="flex space-x-2">
            <Button 
              variant="outline" 
              size="sm"
              onClick={() => { setWindowWidth(400); setWindowCenter(40); }}
            >
              Абдомен
            </Button>
            <Button 
              variant="outline" 
              size="sm"
              onClick={() => { setWindowWidth(1500); setWindowCenter(-600); }}
            >
              Лёгкие
            </Button>
            <Button 
              variant="outline" 
              size="sm"
              onClick={() => { setWindowWidth(80); setWindowCenter(40); }}
            >
              Мягкие ткани
            </Button>
            <Button 
              variant="outline" 
              size="sm"
              onClick={() => { setWindowWidth(2000); setWindowCenter(400); }}
            >
              Кости
            </Button>
          </div>
        </div>
      </CardContent>
    </Card>
  )
}
