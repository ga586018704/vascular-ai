"""
VASCULAR.AI - 3D Volume Renderer
3D visualization of medical images and segmentations using VTK.js
"""

import React, { useEffect, useRef, useState } from 'react';
import vtkFullScreenRenderWindow from '@kitware/vtk.js/Rendering/Misc/FullScreenRenderWindow';
import vtkVolume from '@kitware/vtk.js/Rendering/Core/Volume';
import vtkVolumeMapper from '@kitware/vtk.js/Rendering/Core/VolumeMapper';
import vtkImageData from '@kitware/vtk.js/Common/DataModel/ImageData';
import vtkDataArray from '@kitware/vtk.js/Common/Core/DataArray';
import vtkColorTransferFunction from '@kitware/vtk.js/Rendering/Core/ColorTransferFunction';
import vtkPiecewiseFunction from '@kitware/vtk.js/Common/DataModel/PiecewiseFunction';
import vtkInteractorStyleTrackballCamera from '@kitware/vtk.js/Interaction/Style/InteractorStyleTrackballCamera';
import './VolumeRenderer3D.css';

interface VolumeRenderer3DProps {
  imageData?: Float32Array;
  dimensions: [number, number, number];
  spacing: [number, number, number];
  segmentationMask?: Uint8Array;
  vesselColors?: Record<number, [number, number, number]>;
  opacity?: number;
}

const VolumeRenderer3D: React.FC<VolumeRenderer3DProps> = ({
  imageData,
  dimensions,
  spacing,
  segmentationMask,
  vesselColors = {
    1: [1.0, 0.0, 0.0],    // Aorta - Red
    2: [0.0, 1.0, 0.0],    // Iliac - Green
    3: [0.0, 0.0, 1.0],    // Femoral - Blue
    4: [1.0, 1.0, 0.0],    // Popliteal - Yellow
    5: [1.0, 0.0, 1.0],    // Tibial - Magenta
    6: [0.0, 1.0, 1.0],    // Carotid - Cyan
    7: [1.0, 0.5, 0.0],    // Subclavian - Orange
  },
  opacity = 0.5,
}) => {
  const containerRef = useRef<HTMLDivElement>(null);
  const vtkContainerRef = useRef<any>(null);
  const volumeRef = useRef<any>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [renderMode, setRenderMode] = useState<'volume' | 'mip' | 'segmentation'>('volume');
  const [windowLevel, setWindowLevel] = useState({ window: 400, level: 50 });

  useEffect(() => {
    if (!containerRef.current || !imageData) return;

    // Initialize VTK render window
    const fullScreenRenderer = vtkFullScreenRenderWindow.newInstance({
      rootContainer: containerRef.current,
      containerStyle: { height: '100%', width: '100%' },
    });

    vtkContainerRef.current = fullScreenRenderer;

    const renderer = fullScreenRenderer.getRenderer();
    const renderWindow = fullScreenRenderer.getRenderWindow();

    // Create volume
    const volume = vtkVolume.newInstance();
    const mapper = vtkVolumeMapper.newInstance();
    volume.setMapper(mapper);

    // Create image data
    const vtkImage = vtkImageData.newInstance();
    vtkImage.setDimensions(dimensions);
    vtkImage.setSpacing(spacing);

    // Set scalar data
    const scalarArray = vtkDataArray.newInstance({
      name: 'scalars',
      values: imageData,
      numberOfComponents: 1,
    });
    vtkImage.getPointData().setScalars(scalarArray);

    mapper.setInputData(vtkImage);

    // Setup color and opacity transfer functions
    setupTransferFunctions(volume, windowLevel);

    // Add volume to renderer
    renderer.addVolume(volume);
    renderer.resetCamera();
    renderWindow.render();

    volumeRef.current = volume;

    // Setup interactor
    const interactor = renderWindow.getInteractor();
    const interactorStyle = vtkInteractorStyleTrackballCamera.newInstance();
    interactor.setInteractorStyle(interactorStyle);

    setIsLoading(false);

    return () => {
      fullScreenRenderer.delete();
    };
  }, [imageData, dimensions, spacing]);

  // Update transfer functions when window/level changes
  useEffect(() => {
    if (volumeRef.current) {
      setupTransferFunctions(volumeRef.current, windowLevel);
      vtkContainerRef.current.getRenderWindow().render();
    }
  }, [windowLevel]);

  // Setup color and opacity transfer functions
  const setupTransferFunctions = (volume: any, wl: { window: number; level: number }) => {
    const colorTransferFunction = vtkColorTransferFunction.newInstance();
    const piecewiseFunction = vtkPiecewiseFunction.newInstance();

    const min = wl.level - wl.window / 2;
    const max = wl.level + wl.window / 2;

    // Vascular windowing - enhance contrast for vessels
    colorTransferFunction.addRGBPoint(min, 0.0, 0.0, 0.0);
    colorTransferFunction.addRGBPoint(min + wl.window * 0.2, 0.3, 0.3, 0.3);
    colorTransferFunction.addRGBPoint(min + wl.window * 0.5, 0.7, 0.7, 0.7);
    colorTransferFunction.addRGBPoint(max, 1.0, 1.0, 1.0);

    // Opacity - make vessels more visible
    piecewiseFunction.addPoint(min, 0.0);
    piecewiseFunction.addPoint(min + wl.window * 0.1, 0.0);
    piecewiseFunction.addPoint(min + wl.window * 0.3, 0.3);
    piecewiseFunction.addPoint(min + wl.window * 0.6, 0.6);
    piecewiseFunction.addPoint(max, 1.0);

    volume.getProperty().setRGBTransferFunction(0, colorTransferFunction);
    volume.getProperty().setScalarOpacity(0, piecewiseFunction);
    volume.getProperty().setColorWindow(wl.window);
    volume.getProperty().setColorLevel(wl.level);
  };

  // Add segmentation overlay
  useEffect(() => {
    if (!segmentationMask || !vtkContainerRef.current || !volumeRef.current) return;

    // Create segmentation volume
    const segVolume = vtkVolume.newInstance();
    const segMapper = vtkVolumeMapper.newInstance();
    segVolume.setMapper(segMapper);

    const segImage = vtkImageData.newInstance();
    segImage.setDimensions(dimensions);
    segImage.setSpacing(spacing);

    const segArray = vtkDataArray.newInstance({
      name: 'segmentation',
      values: segmentationMask,
      numberOfComponents: 1,
    });
    segImage.getPointData().setScalars(segArray);

    segMapper.setInputData(segImage);

    // Setup segmentation colors
    const segColorTF = vtkColorTransferFunction.newInstance();
    const segOpacityTF = vtkPiecewiseFunction.newInstance();

    // Background transparent
    segColorTF.addRGBPoint(0, 0, 0, 0);
    segOpacityTF.addPoint(0, 0);

    // Vessel colors
    Object.entries(vesselColors).forEach(([label, color]) => {
      const labelNum = parseInt(label);
      segColorTF.addRGBPoint(labelNum, color[0], color[1], color[2]);
      segOpacityTF.addPoint(labelNum, opacity);
    });

    segVolume.getProperty().setRGBTransferFunction(0, segColorTF);
    segVolume.getProperty().setScalarOpacity(0, segOpacityTF);

    vtkContainerRef.current.getRenderer().addVolume(segVolume);
    vtkContainerRef.current.getRenderWindow().render();

    return () => {
      vtkContainerRef.current?.getRenderer().removeVolume(segVolume);
    };
  }, [segmentationMask, opacity]);

  // Reset camera
  const resetCamera = () => {
    if (vtkContainerRef.current) {
      vtkContainerRef.current.getRenderer().resetCamera();
      vtkContainerRef.current.getRenderWindow().render();
    }
  };

  // Change render mode
  const setRenderModeHandler = (mode: 'volume' | 'mip' | 'segmentation') => {
    setRenderMode(mode);
    if (volumeRef.current) {
      const mapper = volumeRef.current.getMapper();
      
      switch (mode) {
        case 'mip':
          // Maximum Intensity Projection
          mapper.setBlendModeToMaximumIntensity();
          break;
        case 'segmentation':
          // Show only segmentation
          mapper.setBlendModeToComposite();
          break;
        default:
          // Volume rendering
          mapper.setBlendModeToComposite();
      }
      
      vtkContainerRef.current.getRenderWindow().render();
    }
  };

  return (
    <div className="volume-renderer-3d">
      {/* Toolbar */}
      <div className="renderer-toolbar">
        <div className="render-modes">
          <button
            className={`mode-btn ${renderMode === 'volume' ? 'active' : ''}`}
            onClick={() => setRenderModeHandler('volume')}
          >
            Volume
          </button>
          <button
            className={`mode-btn ${renderMode === 'mip' ? 'active' : ''}`}
            onClick={() => setRenderModeHandler('mip')}
          >
            MIP
          </button>
          <button
            className={`mode-btn ${renderMode === 'segmentation' ? 'active' : ''}`}
            onClick={() => setRenderModeHandler('segmentation')}
          >
            Segmentation
          </button>
        </div>

        <div className="window-controls">
          <label>
            Window:
            <input
              type="range"
              min="100"
              max="2000"
              value={windowLevel.window}
              onChange={(e) => setWindowLevel(prev => ({ ...prev, window: parseInt(e.target.value) }))}
            />
            <span>{windowLevel.window}</span>
          </label>
          <label>
            Level:
            <input
              type="range"
              min="-1000"
              max="1000"
              value={windowLevel.level}
              onChange={(e) => setWindowLevel(prev => ({ ...prev, level: parseInt(e.target.value) }))}
            />
            <span>{windowLevel.level}</span>
          </label>
        </div>

        <button className="reset-btn" onClick={resetCamera}>
          Reset View
        </button>
      </div>

      {/* VTK Container */}
      <div ref={containerRef} className="vtk-container">
        {isLoading && (
          <div className="loading-overlay">
            <div className="spinner"></div>
            <span>Loading 3D Volume...</span>
          </div>
        )}
      </div>

      {/* Segmentation Legend */}
      {segmentationMask && (
        <div className="segmentation-legend">
          <h4>Vessels</h4>
          {Object.entries(vesselColors).map(([label, color]) => (
            <div key={label} className="legend-item">
              <span
                className="legend-color"
                style={{
                  backgroundColor: `rgb(${color[0] * 255}, ${color[1] * 255}, ${color[2] * 255})`,
                }}
              />
              <span className="legend-label">{getVesselName(parseInt(label))}</span>
            </div>
          ))}
        </div>
      )}

      {/* Info Panel */}
      <div className="info-panel">
        <div>Dimensions: {dimensions.join(' × ')}</div>
        <div>Spacing: {spacing.join(' × ')} mm</div>
        <div>Mode: {renderMode.toUpperCase()}</div>
      </div>
    </div>
  );
};

// Helper function to get vessel name
const getVesselName = (label: number): string => {
  const names: Record<number, string> = {
    1: 'Aorta',
    2: 'Iliac Artery',
    3: 'Femoral Artery',
    4: 'Popliteal Artery',
    5: 'Tibial Artery',
    6: 'Carotid Artery',
    7: 'Subclavian Artery',
  };
  return names[label] || `Vessel ${label}`;
};

export default VolumeRenderer3D;
