"""
VASCULAR.AI - DICOM Viewer Component
Interactive medical image viewer using Cornerstone.js
"""

import React, { useEffect, useRef, useState, useCallback } from 'react';
import cornerstone from 'cornerstone-core';
import cornerstoneTools from 'cornerstone-tools';
import cornerstoneMath from 'cornerstone-math';
import cornerstoneWADOImageLoader from 'cornerstone-wado-image-loader';
import dicomParser from 'dicom-parser';
import Hammer from 'hammerjs';
import './DicomViewer.css';

// Initialize Cornerstone
 cornerstoneTools.external.cornerstone = cornerstone;
cornerstoneTools.external.cornerstoneMath = cornerstoneMath;
cornerstoneTools.external.Hammer = Hammer;
cornerstoneWADOImageLoader.external.cornerstone = cornerstone;
cornerstoneWADOImageLoader.external.dicomParser = dicomParser;

// Initialize tools
cornerstoneTools.init({
  showSVGCursors: true,
});

interface DicomViewerProps {
  studyUid: string;
  imageIds: string[];
  segmentationMask?: string; // URL to segmentation mask
  onSliceChange?: (sliceIndex: number) => void;
  onMeasurement?: (measurement: any) => void;
}

interface ViewerState {
  currentSlice: number;
  totalSlices: number;
  windowWidth: number;
  windowCenter: number;
  zoom: number;
  pan: { x: number; y: number };
  isPlaying: boolean;
  playbackSpeed: number;
}

const DicomViewer: React.FC<DicomViewerProps> = ({
  studyUid,
  imageIds,
  segmentationMask,
  onSliceChange,
  onMeasurement,
}) => {
  const elementRef = useRef<HTMLDivElement>(null);
  const [state, setState] = useState<ViewerState>({
    currentSlice: 0,
    totalSlices: imageIds.length,
    windowWidth: 400,
    windowCenter: 50,
    zoom: 1,
    pan: { x: 0, y: 0 },
    isPlaying: false,
    playbackSpeed: 10,
  });
  const [activeTool, setActiveTool] = useState<string>('Wwwc');
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const playbackIntervalRef = useRef<NodeJS.Timeout | null>(null);

  // Initialize Cornerstone element
  useEffect(() => {
    const element = elementRef.current;
    if (!element) return;

    cornerstone.enable(element);
    
    // Add event listeners
    const handleImageRendered = (event: any) => {
      const viewport = event.detail.viewport;
      setState(prev => ({
        ...prev,
        windowWidth: viewport.voi.windowWidth,
        windowCenter: viewport.voi.windowCenter,
        zoom: viewport.scale,
        pan: viewport.translation,
      }));
    };

    const handleStackScroll = (event: any) => {
      const newSliceIndex = event.detail.newImageIdIndex;
      setState(prev => ({ ...prev, currentSlice: newSliceIndex }));
      onSliceChange?.(newSliceIndex);
    };

    element.addEventListener('cornerstoneimagerendered', handleImageRendered);
    element.addEventListener('cornerstonestackscroll', handleStackScroll);

    // Load first image
    loadImage(0);

    // Setup tools
    setupTools();

    return () => {
      element.removeEventListener('cornerstoneimagerendered', handleImageRendered);
      element.removeEventListener('cornerstonestackscroll', handleStackScroll);
      cornerstone.disable(element);
    };
  }, []);

  // Load image
  const loadImage = async (sliceIndex: number) => {
    if (!elementRef.current) return;
    
    setIsLoading(true);
    setError(null);

    try {
      const imageId = imageIds[sliceIndex];
      const image = await cornerstone.loadImage(imageId);
      
      const viewport = cornerstone.getDefaultViewportForImage(elementRef.current, image);
      viewport.voi.windowWidth = state.windowWidth;
      viewport.voi.windowCenter = state.windowCenter;
      
      cornerstone.displayImage(elementRef.current, image, viewport);
      
      // Add stack state
      cornerstoneTools.addStackStateManager(elementRef.current, ['stack']);
      cornerstoneTools.addToolState(elementRef.current, 'stack', {
        currentImageIdIndex: sliceIndex,
        imageIds: imageIds,
      });

      setState(prev => ({ ...prev, currentSlice: sliceIndex }));
    } catch (err) {
      setError(`Failed to load image: ${err}`);
    } finally {
      setIsLoading(false);
    }
  };

  // Setup tools
  const setupTools = () => {
    const element = elementRef.current;
    if (!element) return;

    // Add tools
    const WwwcTool = cornerstoneTools.WwwcTool;
    const PanTool = cornerstoneTools.PanTool;
    const ZoomTool = cornerstoneTools.ZoomTool;
    const LengthTool = cornerstoneTools.LengthTool;
    const AngleTool = cornerstoneTools.AngleTool;
    const RectangleRoiTool = cornerstoneTools.RectangleRoiTool;
    const EllipticalRoiTool = cornerstoneTools.EllipticalRoiTool;
    const ArrowAnnotateTool = cornerstoneTools.ArrowAnnotateTool;
    const StackScrollTool = cornerstoneTools.StackScrollTool;
    const StackScrollMouseWheelTool = cornerstoneTools.StackScrollMouseWheelTool;

    cornerstoneTools.addTool(WwwcTool);
    cornerstoneTools.addTool(PanTool);
    cornerstoneTools.addTool(ZoomTool);
    cornerstoneTools.addTool(LengthTool);
    cornerstoneTools.addTool(AngleTool);
    cornerstoneTools.addTool(RectangleRoiTool);
    cornerstoneTools.addTool(EllipticalRoiTool);
    cornerstoneTools.addTool(ArrowAnnotateTool);
    cornerstoneTools.addTool(StackScrollTool);
    cornerstoneTools.addTool(StackScrollMouseWheelTool);

    // Set active tool
    cornerstoneTools.setToolActive('Wwwc', { mouseButtonMask: 1 });
    cornerstoneTools.setToolActive('StackScrollMouseWheel', {});
  };

  // Change tool
  const setToolActive = (toolName: string) => {
    const element = elementRef.current;
    if (!element) return;

    cornerstoneTools.setToolPassive(activeTool);
    cornerstoneTools.setToolActive(toolName, { mouseButtonMask: 1 });
    setActiveTool(toolName);
  };

  // Navigate slices
  const goToSlice = (sliceIndex: number) => {
    if (sliceIndex < 0 || sliceIndex >= imageIds.length) return;
    loadImage(sliceIndex);
  };

  const nextSlice = () => goToSlice(state.currentSlice + 1);
  const prevSlice = () => goToSlice(state.currentSlice - 1);

  // Playback controls
  const togglePlayback = () => {
    if (state.isPlaying) {
      stopPlayback();
    } else {
      startPlayback();
    }
  };

  const startPlayback = () => {
    setState(prev => ({ ...prev, isPlaying: true }));
    playbackIntervalRef.current = setInterval(() => {
      setState(prev => {
        const nextSlice = (prev.currentSlice + 1) % imageIds.length;
        goToSlice(nextSlice);
        return { ...prev, currentSlice: nextSlice };
      });
    }, 1000 / state.playbackSpeed);
  };

  const stopPlayback = () => {
    if (playbackIntervalRef.current) {
      clearInterval(playbackIntervalRef.current);
      playbackIntervalRef.current = null;
    }
    setState(prev => ({ ...prev, isPlaying: false }));
  };

  // Window/Level presets
  const applyWindowPreset = (preset: string) => {
    const element = elementRef.current;
    if (!element) return;

    const presets: Record<string, { ww: number; wc: number }> = {
      vascular: { ww: 400, wc: 50 },
      soft: { ww: 350, wc: 40 },
      bone: { ww: 1500, wc: 300 },
      lung: { ww: 1500, wc: -600 },
      brain: { ww: 80, wc: 40 },
    };

    const { ww, wc } = presets[preset] || presets.vascular;
    
    const viewport = cornerstone.getViewport(element);
    if (viewport) {
      viewport.voi.windowWidth = ww;
      viewport.voi.windowCenter = wc;
      cornerstone.setViewport(element, viewport);
    }
  };

  // Reset view
  const resetView = () => {
    const element = elementRef.current;
    if (!element) return;

    cornerstone.reset(element);
    applyWindowPreset('vascular');
  };

  // Handle keyboard shortcuts
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      switch (e.key) {
        case 'ArrowUp':
        case 'ArrowRight':
          nextSlice();
          break;
        case 'ArrowDown':
        case 'ArrowLeft':
          prevSlice();
          break;
        case ' ':
          togglePlayback();
          break;
        case 'r':
        case 'R':
          resetView();
          break;
        case 'w':
          setToolActive('Wwwc');
          break;
        case 'p':
          setToolActive('Pan');
          break;
        case 'z':
          setToolActive('Zoom');
          break;
        case 'l':
          setToolActive('Length');
          break;
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [state.currentSlice, state.isPlaying]);

  return (
    <div className="dicom-viewer">
      {/* Toolbar */}
      <div className="viewer-toolbar">
        <div className="tool-group">
          <button
            className={`tool-btn ${activeTool === 'Wwwc' ? 'active' : ''}`}
            onClick={() => setToolActive('Wwwc')}
            title="Window/Level (W)"
          >
            🌓
          </button>
          <button
            className={`tool-btn ${activeTool === 'Pan' ? 'active' : ''}`}
            onClick={() => setToolActive('Pan')}
            title="Pan (P)"
          >
            ✋
          </button>
          <button
            className={`tool-btn ${activeTool === 'Zoom' ? 'active' : ''}`}
            onClick={() => setToolActive('Zoom')}
            title="Zoom (Z)"
          >
            🔍
          </button>
        </div>

        <div className="tool-group">
          <button
            className={`tool-btn ${activeTool === 'Length' ? 'active' : ''}`}
            onClick={() => setToolActive('Length')}
            title="Length (L)"
          >
            ?
          </button>
          <button
            className={`tool-btn ${activeTool === 'Angle' ? 'active' : ''}`}
            onClick={() => setToolActive('Angle')}
            title="Angle"
          >
            ∠
          </button>
          <button
            className={`tool-btn ${activeTool === 'EllipticalRoi' ? 'active' : ''}`}
            onClick={() => setToolActive('EllipticalRoi')}
            title="Ellipse ROI"
          >
            ⭕
          </button>
        </div>

        <div className="tool-group">
          <button className="tool-btn" onClick={prevSlice} title="Previous Slice">
            ◀
          </button>
          <button className="tool-btn" onClick={togglePlayback} title="Play/Pause (Space)">
            {state.isPlaying ? '⏸' : '▶'}
          </button>
          <button className="tool-btn" onClick={nextSlice} title="Next Slice">
            ▶
          </button>
        </div>

        <div className="tool-group">
          <select 
            className="preset-select"
            onChange={(e) => applyWindowPreset(e.target.value)}
            defaultValue="vascular"
          >
            <option value="vascular">Vascular (W:400, C:50)</option>
            <option value="soft">Soft Tissue (W:350, C:40)</option>
            <option value="bone">Bone (W:1500, C:300)</option>
            <option value="lung">Lung (W:1500, C:-600)</option>
            <option value="brain">Brain (W:80, C:40)</option>
          </select>
        </div>

        <div className="tool-group">
          <button className="tool-btn" onClick={resetView} title="Reset (R)">
            ↺
          </button>
        </div>
      </div>

      {/* Viewer */}
      <div className="viewer-container">
        {isLoading && (
          <div className="loading-overlay">
            <div className="spinner"></div>
            <span>Loading...</span>
          </div>
        )}
        
        {error && (
          <div className="error-overlay">
            <span>⚠️ {error}</span>
          </div>
        )}

        <div
          ref={elementRef}
          className="cornerstone-element"
          onContextMenu={(e) => e.preventDefault()}
        />

        {/* Overlay info */}
        <div className="viewer-overlay">
          <div className="overlay-top-left">
            <span>Study: {studyUid}</span>
          </div>
          <div className="overlay-top-right">
            <span>WW: {Math.round(state.windowWidth)}</span>
            <span>WC: {Math.round(state.windowCenter)}</span>
          </div>
          <div className="overlay-bottom-left">
            <span>Zoom: {state.zoom.toFixed(2)}x</span>
          </div>
          <div className="overlay-bottom-right">
            <span>Slice: {state.currentSlice + 1} / {state.totalSlices}</span>
          </div>
        </div>
      </div>

      {/* Navigation slider */}
      <div className="viewer-navigation">
        <input
          type="range"
          min={0}
          max={imageIds.length - 1}
          value={state.currentSlice}
          onChange={(e) => goToSlice(parseInt(e.target.value))}
          className="slice-slider"
        />
        <div className="slice-info">
          <span>Slice {state.currentSlice + 1} of {state.totalSlices}</span>
        </div>
      </div>
    </div>
  );
};

export default DicomViewer;
