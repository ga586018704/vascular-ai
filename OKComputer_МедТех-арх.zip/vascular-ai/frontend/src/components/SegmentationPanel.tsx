import { useState, useEffect } from 'react'
import { 
  Play, 
  Loader2, 
  CheckCircle2, 
  AlertCircle,
  Activity,
  Ruler,
  AlertTriangle,
  Info,
  RefreshCw,
  TrendingUp,
  Heart
} from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Progress } from '@/components/ui/progress'
import { Separator } from '@/components/ui/separator'
import { toast } from 'sonner'
import type { Study, SegmentationResult, VesselDetail } from '../App'

interface SegmentationPanelProps {
  study: Study
  onSegmentationComplete: (result: SegmentationResult) => void
}

const API_URL = import.meta.env.VITE_API_URL || 'http://localhost:8000'

const vesselNames: Record<string, string> = {
  aorta: 'Аорта',
  iliac_right: 'Правая подвздошная артерия',
  iliac_left: 'Левая подвздошная артерия',
  femoral_right: 'Правая бедренная артерия',
  femoral_left: 'Левая бедренная артерия',
  carotid_right: 'Правая сонная артерия',
  carotid_left: 'Левая сонная артерия',
  subclavian_right: 'Правая подключичная артерия',
  subclavian_left: 'Левая подключичная артерия',
}

const pathologyColors: Record<string, string> = {
  mild: 'bg-yellow-100 text-yellow-800 border-yellow-300',
  moderate: 'bg-orange-100 text-orange-800 border-orange-300',
  severe: 'bg-red-100 text-red-800 border-red-300',
}

const pathologyLabels: Record<string, string> = {
  aneurysm: 'Аневризма',
  stenosis: 'Стеноз',
  thrombus: 'Тромб',
  occlusion: 'Окклюзия',
}

const severityLabels: Record<string, string> = {
  mild: 'Лёгкая',
  moderate: 'Средняя',
  severe: 'Тяжёлая',
}

export default function SegmentationPanel({ 
  study, 
  onSegmentationComplete 
}: SegmentationPanelProps) {
  const [segmenting, setSegmenting] = useState(false)
  const [segmentation, setSegmentation] = useState<SegmentationResult | null>(null)
  const [progress, setProgress] = useState(0)
  const [loadingExisting, setLoadingExisting] = useState(false)

  // Load existing segmentation on mount
  useEffect(() => {
    if (study.status === 'segmented') {
      loadExistingSegmentation()
    }
  }, [study.id])

  const loadExistingSegmentation = async () => {
    try {
      setLoadingExisting(true)
      const response = await fetch(
        `${API_URL}/api/segmentation/study/${study.id}`
      )
      
      if (response.ok) {
        const data = await response.json()
        setSegmentation(data)
        onSegmentationComplete(data)
      }
    } catch (error) {
      console.log('No existing segmentation found')
    } finally {
      setLoadingExisting(false)
    }
  }

  const startSegmentation = async () => {
    try {
      setSegmenting(true)
      setProgress(10)
      
      const response = await fetch(
        `${API_URL}/api/segmentation/start/${study.id}`,
        { method: 'POST' }
      )
      
      if (!response.ok) {
        const error = await response.json()
        throw new Error(error.detail || 'Failed to start segmentation')
      }
      
      const data = await response.json()
      
      if (data.success) {
        setProgress(30)
        // Poll for status
        pollSegmentationStatus(data.segmentation_id)
      } else {
        throw new Error(data.message || 'Segmentation failed')
      }
    } catch (error: any) {
      toast.error(`Ошибка: ${error.message}`)
      setSegmenting(false)
      console.error(error)
    }
  }

  const pollSegmentationStatus = async (segmentationId: number) => {
    const checkStatus = async () => {
      try {
        const response = await fetch(
          `${API_URL}/api/segmentation/status/${segmentationId}`
        )
        
        if (!response.ok) {
          throw new Error('Failed to check status')
        }
        
        const data = await response.json()
        
        if (data.status === 'completed') {
          setProgress(100)
          setSegmenting(false)
          setSegmentation(data)
          onSegmentationComplete(data)
          toast.success('Сегментация завершена успешно!')
        } else if (data.status === 'error') {
          setSegmenting(false)
          toast.error(`Ошибка сегментации: ${data.error}`)
        } else {
          // Still processing
          setProgress(prev => Math.min(90, prev + 15))
          setTimeout(() => checkStatus(), 2000)
        }
      } catch (error) {
        setSegmenting(false)
        toast.error('Ошибка проверки статуса')
        console.error(error)
      }
    }
    
    checkStatus()
  }

  if (loadingExisting) {
    return (
      <Card>
        <CardContent className="p-8 flex justify-center">
          <Loader2 className="h-8 w-8 animate-spin text-blue-500" />
        </CardContent>
      </Card>
    )
  }

  return (
    <div className="space-y-6">
      {/* Start Segmentation Card */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center space-x-2">
            <Activity className="h-5 w-5 text-blue-500" />
            <span>AI-Сегментация сосудов</span>
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-600">
                Автоматическое выделение сосудов с помощью нейросети
              </p>
              <p className="text-xs text-gray-400 mt-1">
                Поддерживаемые классы: Аорта, Подвздошные, Бедренные артерии
              </p>
            </div>
            <Button
              onClick={startSegmentation}
              disabled={segmenting}
              className="min-w-[160px]"
              size="lg"
            >
              {segmenting ? (
                <>
                  <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                  Обработка...
                </>
              ) : segmentation ? (
                <>
                  <RefreshCw className="h-4 w-4 mr-2" />
                  Повторить
                </>
              ) : (
                <>
                  <Play className="h-4 w-4 mr-2" />
                  Сегментировать
                </>
              )}
            </Button>
          </div>

          {segmenting && (
            <div className="space-y-3">
              <Progress value={progress} className="h-2" />
              <div className="flex items-center justify-center space-x-2 text-sm text-gray-500">
                <Loader2 className="h-4 w-4 animate-spin" />
                <span>
                  {progress < 30 && 'Запуск сегментации...'}
                  {progress >= 30 && progress < 60 && 'Обработка изображений...'}
                  {progress >= 60 && progress < 90 && 'Расчет измерений...'}
                  {progress >= 90 && 'Завершение...'}
                </span>
              </div>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Segmentation Results */}
      {segmentation && segmentation.status === 'completed' && (
        <>
          {/* Dice Scores */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center space-x-2 text-base">
                <CheckCircle2 className="h-5 w-5 text-green-500" />
                <span>Точность сегментации (Dice score)</span>
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
                {Object.entries(segmentation.dice_scores || {}).map(([name, score]) => {
                  if (name === 'background') return null
                  const scoreValue = score as number
                  return (
                    <div key={name} className="bg-gray-50 p-3 rounded-lg border">
                      <div className="text-xs text-gray-500 capitalize mb-1">
                        {vesselNames[name] || name}
                      </div>
                      <div className={`text-xl font-bold ${
                        scoreValue > 0.85 ? 'text-green-600' : 
                        scoreValue > 0.7 ? 'text-yellow-600' : 'text-red-600'
                      }`}>
                        {(scoreValue * 100).toFixed(1)}%
                      </div>
                    </div>
                  )
                })}
              </div>
            </CardContent>
          </Card>

          {/* Vessel Measurements */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center space-x-2 text-base">
                <Ruler className="h-5 w-5 text-blue-500" />
                <span>Измерения сосудов</span>
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {segmentation.vessel_details?.map((vessel: VesselDetail) => (
                  <div 
                    key={vessel.vessel_name}
                    className="border rounded-lg p-4 hover:shadow-md transition-shadow"
                  >
                    <div className="flex items-center justify-between mb-3">
                      <div className="flex items-center space-x-2">
                        <Heart className="h-5 w-5 text-red-500" />
                        <span className="font-semibold text-lg">
                          {vesselNames[vessel.vessel_name] || vessel.vessel_name}
                        </span>
                      </div>
                      {vessel.has_pathology && (
                        <Badge 
                          className={`${pathologyColors[vessel.pathology_severity || 'mild']} border`}
                        >
                          <AlertTriangle className="h-3 w-3 mr-1" />
                          {pathologyLabels[vessel.pathology_type || '']} 
                          {vessel.pathology_severity && `(${severityLabels[vessel.pathology_severity]})`}
                        </Badge>
                      )}
                    </div>
                    
                    <div className="grid grid-cols-4 gap-4 text-sm">
                      <div className="bg-blue-50 p-2 rounded">
                        <div className="text-xs text-gray-500 mb-1">D max</div>
                        <div className="font-semibold text-blue-700">
                          {vessel.diameter_max?.toFixed(1)} мм
                        </div>
                      </div>
                      <div className="bg-green-50 p-2 rounded">
                        <div className="text-xs text-gray-500 mb-1">D средн</div>
                        <div className="font-semibold text-green-700">
                          {vessel.diameter_mean?.toFixed(1)} мм
                        </div>
                      </div>
                      <div className="bg-purple-50 p-2 rounded">
                        <div className="text-xs text-gray-500 mb-1">Длина</div>
                        <div className="font-semibold text-purple-700">
                          {vessel.length?.toFixed(1)} мм
                        </div>
                      </div>
                      <div className="bg-orange-50 p-2 rounded">
                        <div className="text-xs text-gray-500 mb-1">Объем</div>
                        <div className="font-semibold text-orange-700">
                          {vessel.volume?.toFixed(1)} мл
                        </div>
                      </div>
                    </div>
                    
                    {/* Pathology Alert */}
                    {vessel.has_pathology && vessel.pathology_type === 'aneurysm' && (
                      <div className="mt-3 bg-red-50 border border-red-200 rounded p-3">
                        <div className="flex items-center space-x-2 text-red-700">
                          <TrendingUp className="h-5 w-5" />
                          <span className="font-semibold">Обнаружена аневризма!</span>
                        </div>
                        <p className="text-sm text-red-600 mt-1">
                          Диаметр {vessel.diameter_max?.toFixed(1)} мм 
                          {vessel.diameter_max && vessel.diameter_max > 55 
                            ? ' - абсолютное показание к операции' 
                            : vessel.diameter_max && vessel.diameter_max > 45 
                              ? ' - относительное показание к операции'
                              : ''}
                        </p>
                      </div>
                    )}
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>

          {/* Detected Classes */}
          <Card>
            <CardHeader>
              <CardTitle className="text-base">Обнаруженные структуры</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="flex flex-wrap gap-2">
                {segmentation.vessel_details?.map((vessel: VesselDetail) => (
                  <Badge key={vessel.vessel_name} variant="outline" className="px-3 py-1">
                    {vesselNames[vessel.vessel_name] || vessel.vessel_name}
                  </Badge>
                ))}
              </div>
            </CardContent>
          </Card>

          {/* Next Step Info */}
          <div className="bg-blue-50 border border-blue-200 rounded-lg p-4 flex items-start space-x-3">
            <Info className="h-5 w-5 text-blue-500 mt-0.5 flex-shrink-0" />
            <div>
              <p className="text-sm text-blue-800 font-medium">
                Сегментация завершена!
              </p>
              <p className="text-sm text-blue-600 mt-1">
                На основе этих измерений можно сгенерировать операционный протокол. 
                Перейдите на вкладку <strong>"Протокол"</strong>.
              </p>
            </div>
          </div>
        </>
      )}

      {segmentation && segmentation.status === 'error' && (
        <Card className="border-red-200">
          <CardContent className="p-4">
            <div className="flex items-center space-x-2 text-red-600">
              <AlertCircle className="h-5 w-5" />
              <span>Ошибка сегментации: {segmentation.error}</span>
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  )
}
