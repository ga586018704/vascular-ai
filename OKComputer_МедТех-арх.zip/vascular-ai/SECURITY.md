# VASCULAR.AI - Security Documentation

## Обзор безопасности

VASCULAR.AI реализует комплексный набор мер безопасности для защиты медицинских данных (PHI) и соответствия требованиям HIPAA/GDPR.

## Архитектура безопасности

```
┌─────────────────────────────────────────────────────────────────┐
│                        Клиентский уровень                        │
│  • HTTPS (TLS 1.2+)                                             │
│  • Input validation                                             │
│  • Session management                                           │
└─────────────────────────────────────────────────────────────────┘
                              │
                              ▼
┌─────────────────────────────────────────────────────────────────┐
│                      Уровень API (FastAPI)                       │
│  • JWT Authentication                                           │
│  • Rate Limiting                                                │
│  • RBAC (Role-Based Access Control)                             │
│  • Security Headers                                             │
│  • Request Logging                                              │
└─────────────────────────────────────────────────────────────────┘
                              │
                              ▼
┌─────────────────────────────────────────────────────────────────┐
│                      Сервисный уровень                           │
│  • PHI Encryption (Fernet)                                      │
│  • Input Sanitization                                           │
│  • Audit Logging                                                │
│  • Business Logic Validation                                    │
└─────────────────────────────────────────────────────────────────┘
                              │
                              ▼
┌─────────────────────────────────────────────────────────────────┐
│                      Уровень данных                              │
│  • Database Encryption                                          │
│  • Secure File Storage                                          │
│  • Backup Encryption                                            │
│  • Access Controls                                              │
└─────────────────────────────────────────────────────────────────┘
```

## Функции безопасности

### 1. Аутентификация

#### JWT Tokens
- **Access Token**: 30 минут (настраивается)
- **Refresh Token**: 7 дней
- **Алгоритм**: HS256
- **Secret Key**: 32+ символа, генерируется случайно

```python
# Создание токена
token = SecurityManager.create_access_token(
    data={"sub": user_id, "email": email, "role": role},
    expires_delta=timedelta(minutes=30)
)

# Проверка токена
payload = SecurityManager.verify_token(token)
```

#### Password Hashing
- **Алгоритм**: bcrypt
- **Salt rounds**: 12
- **Минимальная длина пароля**: 8 символов

```python
# Хеширование пароля
hashed = SecurityManager.get_password_hash(password)

# Проверка пароля
is_valid = SecurityManager.verify_password(password, hashed)
```

### 2. Авторизация (RBAC)

#### Роли и разрешения

| Роль | Разрешения |
|------|------------|
| **admin** | Полный доступ |
| **surgeon** | read:study, write:study, read:calculator, read:protocol |
| **resident** | read:study, read:calculator, read:protocol |
| **radiologist** | read:study, write:study, read:calculator |
| **nurse** | read:study (ограниченный) |

```python
# Проверка разрешения
if not RBAC.has_permission(user.role, "write:study"):
    raise HTTPException(status_code=403, detail="Permission denied")

# Использование в endpoint
@router.post("/studies")
async def create_study(
    current_user: User = Depends(require_permission("write:study"))
):
    ...
```

### 3. Шифрование PHI

#### Fernet Encryption (AES-128 в режиме CBC)

```python
# Шифрование PHI
encrypted = SecurityManager.encrypt_phi(patient_data)

# Расшифрование
decrypted = SecurityManager.decrypt_phi(encrypted)
```

#### Что шифруется
- Patient ID
- Patient Name
- SSN/MRN
- Даты рождения
- Медицинские записи

#### Хеширование идентификаторов
```python
# Для поиска без раскрытия ID
patient_hash = SecurityManager.hash_patient_id(patient_id)
```

### 4. Rate Limiting

#### Конфигурация

| Endpoint | Limit |
|----------|-------|
| `/api/auth/*` | 5/minute |
| `/api/dicom/upload` | 10/hour |
| `/api/calculator/*` | 100/minute |
| `/api/search/*` | 60/minute |
| API general | 1000/minute |

```python
# Middleware автоматически применяет rate limiting
app.add_middleware(RateLimitMiddleware)
```

### 5. Security Headers

Все ответы включают:

```
X-Content-Type-Options: nosniff
X-Frame-Options: DENY
X-XSS-Protection: 1; mode=block
Strict-Transport-Security: max-age=31536000; includeSubDomains
Content-Security-Policy: default-src 'self'
Referrer-Policy: strict-origin-when-cross-origin
Permissions-Policy: geolocation=(), microphone=(), camera=()
```

### 6. Input Validation

```python
# Валидация email
if not InputValidator.validate_email(email):
    raise HTTPException(status_code=400, detail="Invalid email")

# Валидация study_id
if not InputValidator.validate_study_id(study_id):
    raise HTTPException(status_code=400, detail="Invalid study ID")

# Санитизация filename
safe_filename = InputValidator.sanitize_filename(user_input)
```

### 7. Audit Logging

#### Типы событий

```python
# Аутентификация
AuditLogger.log_authentication(
    user_id="123",
    success=True,
    ip_address="192.168.1.1",
    user_agent="Mozilla/5.0..."
)

# Доступ к DICOM
AuditLogger.log_dicom_access(
    user_id="123",
    study_id="study_456",
    action="view",
    ip_address="192.168.1.1"
)

# Модификация данных
AuditLogger.log_data_modification(
    user_id="123",
    table="studies",
    record_id="456",
    action="update",
    changes={"status": "processed"},
    ip_address="192.168.1.1"
)
```

#### Формат логов (JSON)

```json
{
  "timestamp": "2024-01-15T10:30:00Z",
  "level": "INFO",
  "event_type": "DICOM_ACCESS",
  "user_id": "123",
  "study_id": "study_456",
  "action": "view",
  "ip_address": "192.168.1.1",
  "user_agent": "Mozilla/5.0...",
  "session_id": "abc123"
}
```

## API Endpoints Security

### Публичные endpoints (без аутентификации)

- `GET /health` - Health check
- `POST /api/auth/login` - Login
- `POST /api/auth/register` - Registration

### Защищенные endpoints (требуется JWT)

Все остальные endpoints требуют валидный JWT токен в заголовке:

```
Authorization: Bearer <token>
```

### Примеры использования

#### Login

```bash
curl -X POST https://vascular.ai/api/auth/login \
  -H "Content-Type: application/x-www-form-urlencoded" \
  -d "username=user@example.com&password=SecurePass123!"
```

Response:
```json
{
  "access_token": "eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9...",
  "refresh_token": "eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9...",
  "token_type": "bearer",
  "expires_in": 1800,
  "user": {
    "id": 1,
    "email": "user@example.com",
    "full_name": "Dr. Smith"
  }
}
```

#### Access Protected Resource

```bash
curl https://vascular.ai/api/dicom/studies \
  -H "Authorization: Bearer eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9..."
```

#### Refresh Token

```bash
curl -X POST https://vascular.ai/api/auth/refresh \
  -H "Content-Type: application/json" \
  -d '{"refresh_token": "eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9..."}'
```

## Тестирование безопасности

### Запуск тестов

```bash
# Все security тесты
pytest tests/security/ -v

# Конкретный тест
pytest tests/security/test_authentication.py::TestSecurityManager -v

# С покрытием
pytest tests/security/ --cov=app.core.security --cov-report=html
```

### Статический анализ

```bash
# Bandit - поиск уязвимостей
bandit -r app/ -f json -o bandit-report.json

# Safety - проверка зависимостей
safety check -r requirements.txt
```

### Penetration Testing Checklist

- [ ] SQL Injection
- [ ] XSS (Cross-Site Scripting)
- [ ] CSRF (Cross-Site Request Forgery)
- [ ] Authentication Bypass
- [ ] Authorization Bypass
- [ ] Path Traversal
- [ ] File Upload vulnerabilities
- [ ] Rate Limiting bypass
- [ ] JWT manipulation
- [ ] Session fixation

## HIPAA Compliance

### Технические меры

| Требование | Реализация |
|------------|------------|
| Access Control | RBAC, JWT authentication |
| Audit Controls | Structured JSON logging |
| Integrity | Input validation, checksums |
| Transmission Security | TLS 1.2+, PHI encryption |

### Административные меры

- Security Officer назначен
- Privacy Officer назначен
- Incident Response Plan разработан
- Training Program реализован
- Business Associate Agreements

### Физические меры

- Data center security (cloud provider)
- Workstation security policies
- Device and media controls

## Incident Response

### Severity Levels

| Level | Описание | Примеры |
|-------|----------|---------|
| **Critical** | PHI breach >500 records | Database compromise |
| **High** | PHI breach <500 records | Unauthorized access |
| **Medium** | Security vulnerability | XSS, SQL injection found |
| **Low** | Policy violation | Weak password |

### Response Timeline

| Этап | Время | Действия |
|------|-------|----------|
| Detection | 0-1 час | Обнаружение, остановка системы |
| Assessment | 1-4 часа | Оценка scope, документирование |
| Containment | 4-24 часа | Изоляция, исправление |
| Notification | 24-72 часа | HHS, пациенты, СМИ |
| Recovery | 1-7 дней | Восстановление, мониторинг |

## Контакты

- **Security Officer**: security@vascular.ai
- **Privacy Officer**: privacy@vascular.ai
- **Incident Response**: incident@vascular.ai

## Обновления

| Дата | Версия | Изменения |
|------|--------|-----------|
| 2024-01-15 | 1.0 | Initial security documentation |

---

**Важно**: Этот документ должен регулярно обновляться при изменении системы безопасности.
