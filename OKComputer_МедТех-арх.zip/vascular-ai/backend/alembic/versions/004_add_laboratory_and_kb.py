"""Add laboratory and knowledge base tables

Revision ID: 004
Revises: 003
Create Date: 2024-04-04 00:00:00.000000

"""
from alembic import op
import sqlalchemy as sa
from sqlalchemy.dialects import postgresql

# revision identifiers, used by Alembic.
revision = '004'
down_revision = '003'
branch_labels = None
depends_on = None


def upgrade():
    # ==================== Laboratory Tables ====================
    
    # Reference Ranges
    op.create_table(
        'reference_ranges',
        sa.Column('id', postgresql.UUID(as_uuid=True), primary_key=True),
        sa.Column('test_code', sa.String(50), nullable=False, index=True),
        sa.Column('test_name', sa.String(200), nullable=False),
        sa.Column('category', sa.String(50), nullable=False),
        sa.Column('unit', sa.String(50), nullable=False),
        sa.Column('unit_display', sa.String(100)),
        sa.Column('min_value', sa.Numeric(15, 6)),
        sa.Column('max_value', sa.Numeric(15, 6)),
        sa.Column('critical_low', sa.Numeric(15, 6)),
        sa.Column('critical_high', sa.Numeric(15, 6)),
        sa.Column('gender', sa.String(10)),
        sa.Column('age_min', sa.Integer),
        sa.Column('age_max', sa.Integer),
        sa.Column('conditions', postgresql.JSON(astext_type=sa.Text()), default={}),
        sa.Column('source', sa.String(200)),
        sa.Column('methodology', sa.Text),
        sa.Column('is_active', sa.Boolean, default=True),
        sa.Column('created_at', sa.DateTime, default=sa.func.now()),
        sa.Column('updated_at', sa.DateTime, default=sa.func.now(), onupdate=sa.func.now()),
        sa.Column('laboratory_id', postgresql.UUID(as_uuid=True), sa.ForeignKey('laboratories.id')),
    )
    
    op.create_index('ix_reference_ranges_test_gender_age', 'reference_ranges', 
                    ['test_code', 'gender', 'age_min', 'age_max'])
    
    # Laboratories
    op.create_table(
        'laboratories',
        sa.Column('id', postgresql.UUID(as_uuid=True), primary_key=True),
        sa.Column('code', sa.String(50), unique=True, nullable=False),
        sa.Column('name', sa.String(200), nullable=False),
        sa.Column('address', sa.Text),
        sa.Column('phone', sa.String(50)),
        sa.Column('email', sa.String(100)),
        sa.Column('lab_type', sa.String(50)),
        sa.Column('hl7_interface', postgresql.JSON(astext_type=sa.Text()), default={}),
        sa.Column('api_endpoint', sa.String(500)),
        sa.Column('is_active', sa.Boolean, default=True),
        sa.Column('created_at', sa.DateTime, default=sa.func.now()),
        sa.Column('updated_at', sa.DateTime, default=sa.func.now(), onupdate=sa.func.now()),
    )
    
    # Test Panels
    op.create_table(
        'test_panels',
        sa.Column('id', postgresql.UUID(as_uuid=True), primary_key=True),
        sa.Column('code', sa.String(50), unique=True, nullable=False),
        sa.Column('name', sa.String(200), nullable=False),
        sa.Column('description', sa.Text),
        sa.Column('category', sa.String(50), nullable=False),
        sa.Column('test_codes', postgresql.ARRAY(sa.String), default=[]),
        sa.Column('is_active', sa.Boolean, default=True),
        sa.Column('default_priority', sa.String(20), default='routine'),
        sa.Column('created_at', sa.DateTime, default=sa.func.now()),
        sa.Column('updated_at', sa.DateTime, default=sa.func.now(), onupdate=sa.func.now()),
    )
    
    # Laboratory Tests
    op.create_table(
        'laboratory_tests',
        sa.Column('id', postgresql.UUID(as_uuid=True), primary_key=True),
        sa.Column('patient_id', postgresql.UUID(as_uuid=True), sa.ForeignKey('patients.id'), nullable=False),
        sa.Column('doctor_id', postgresql.UUID(as_uuid=True), sa.ForeignKey('users.id'), nullable=False),
        sa.Column('laboratory_id', postgresql.UUID(as_uuid=True), sa.ForeignKey('laboratories.id')),
        sa.Column('order_number', sa.String(100), unique=True, nullable=False, index=True),
        sa.Column('order_date', sa.DateTime, default=sa.func.now()),
        sa.Column('status', sa.String(50), default='ordered'),
        sa.Column('clinical_indication', sa.Text),
        sa.Column('diagnosis_codes', postgresql.ARRAY(sa.String), default=[]),
        sa.Column('priority', sa.String(20), default='routine'),
        sa.Column('collection_date', sa.DateTime),
        sa.Column('collection_type', sa.String(50)),
        sa.Column('collected_by', sa.String(200)),
        sa.Column('result_date', sa.DateTime),
        sa.Column('verified_by', postgresql.UUID(as_uuid=True), sa.ForeignKey('users.id')),
        sa.Column('verified_at', sa.DateTime),
        sa.Column('notes', sa.Text),
        sa.Column('created_at', sa.DateTime, default=sa.func.now()),
        sa.Column('updated_at', sa.DateTime, default=sa.func.now(), onupdate=sa.func.now()),
    )
    
    # Test Results
    op.create_table(
        'test_results',
        sa.Column('id', postgresql.UUID(as_uuid=True), primary_key=True),
        sa.Column('laboratory_test_id', postgresql.UUID(as_uuid=True), sa.ForeignKey('laboratory_tests.id'), nullable=False),
        sa.Column('reference_range_id', postgresql.UUID(as_uuid=True), sa.ForeignKey('reference_ranges.id')),
        sa.Column('test_code', sa.String(50), nullable=False, index=True),
        sa.Column('test_name', sa.String(200), nullable=False),
        sa.Column('category', sa.String(50), nullable=False),
        sa.Column('value_numeric', sa.Numeric(15, 6)),
        sa.Column('value_text', sa.Text),
        sa.Column('value_coded', sa.String(100)),
        sa.Column('unit', sa.String(50)),
        sa.Column('reference_min', sa.Numeric(15, 6)),
        sa.Column('reference_max', sa.Numeric(15, 6)),
        sa.Column('reference_text', sa.String(200)),
        sa.Column('interpretation', sa.String(20)),
        sa.Column('interpretation_text', sa.Text),
        sa.Column('is_critical', sa.Boolean, default=False),
        sa.Column('is_abnormal', sa.Boolean, default=False),
        sa.Column('is_delta_check', sa.Boolean, default=False),
        sa.Column('previous_value', sa.Numeric(15, 6)),
        sa.Column('previous_date', sa.DateTime),
        sa.Column('delta_percent', sa.Numeric(5, 2)),
        sa.Column('methodology', sa.String(200)),
        sa.Column('instrument', sa.String(100)),
        sa.Column('comments', sa.Text),
        sa.Column('created_at', sa.DateTime, default=sa.func.now()),
        sa.Column('updated_at', sa.DateTime, default=sa.func.now(), onupdate=sa.func.now()),
    )
    
    op.create_index('ix_test_results_test_date', 'test_results', ['test_code', 'created_at'])
    
    # Critical Value Alerts
    op.create_table(
        'critical_value_alerts',
        sa.Column('id', postgresql.UUID(as_uuid=True), primary_key=True),
        sa.Column('test_result_id', postgresql.UUID(as_uuid=True), sa.ForeignKey('test_results.id'), nullable=False),
        sa.Column('patient_id', postgresql.UUID(as_uuid=True), sa.ForeignKey('patients.id'), nullable=False),
        sa.Column('alert_type', sa.String(50)),
        sa.Column('value', sa.Numeric(15, 6)),
        sa.Column('test_name', sa.String(200)),
        sa.Column('notified_users', postgresql.ARRAY(postgresql.UUID(as_uuid=True)), default=[]),
        sa.Column('notification_methods', postgresql.ARRAY(sa.String), default=[]),
        sa.Column('status', sa.String(50), default='pending'),
        sa.Column('acknowledged_by', postgresql.UUID(as_uuid=True), sa.ForeignKey('users.id')),
        sa.Column('acknowledged_at', sa.DateTime),
        sa.Column('notes', sa.Text),
        sa.Column('created_at', sa.DateTime, default=sa.func.now()),
        sa.Column('resolved_at', sa.DateTime),
    )
    
    # Test Trends
    op.create_table(
        'test_trends',
        sa.Column('id', postgresql.UUID(as_uuid=True), primary_key=True),
        sa.Column('patient_id', postgresql.UUID(as_uuid=True), sa.ForeignKey('patients.id'), nullable=False),
        sa.Column('test_code', sa.String(50), nullable=False),
        sa.Column('test_name', sa.String(200), nullable=False),
        sa.Column('values_count', sa.Integer, default=0),
        sa.Column('first_value', sa.Numeric(15, 6)),
        sa.Column('first_date', sa.DateTime),
        sa.Column('last_value', sa.Numeric(15, 6)),
        sa.Column('last_date', sa.DateTime),
        sa.Column('min_value', sa.Numeric(15, 6)),
        sa.Column('max_value', sa.Numeric(15, 6)),
        sa.Column('avg_value', sa.Numeric(15, 6)),
        sa.Column('trend_direction', sa.String(20)),
        sa.Column('trend_slope', sa.Numeric(10, 6)),
        sa.Column('updated_at', sa.DateTime, default=sa.func.now(), onupdate=sa.func.now()),
    )
    
    op.create_index('ix_test_trends_patient_test', 'test_trends', ['patient_id', 'test_code'])
    
    # ==================== Knowledge Base Tables ====================
    
    # Categories
    op.create_table(
        'kb_categories',
        sa.Column('id', postgresql.UUID(as_uuid=True), primary_key=True),
        sa.Column('parent_id', postgresql.UUID(as_uuid=True), sa.ForeignKey('kb_categories.id')),
        sa.Column('code', sa.String(50), unique=True, nullable=False, index=True),
        sa.Column('name', sa.String(200), nullable=False),
        sa.Column('name_en', sa.String(200)),
        sa.Column('description', sa.Text),
        sa.Column('level', sa.Integer, default=0),
        sa.Column('path', sa.String(500)),
        sa.Column('sort_order', sa.Integer, default=0),
        sa.Column('icon', sa.String(100)),
        sa.Column('color', sa.String(7)),
        sa.Column('is_active', sa.Boolean, default=True),
        sa.Column('is_visible', sa.Boolean, default=True),
        sa.Column('created_at', sa.DateTime, default=sa.func.now()),
        sa.Column('updated_at', sa.DateTime, default=sa.func.now(), onupdate=sa.func.now()),
    )
    
    # Tags
    op.create_table(
        'kb_tags',
        sa.Column('id', postgresql.UUID(as_uuid=True), primary_key=True),
        sa.Column('code', sa.String(50), unique=True, nullable=False, index=True),
        sa.Column('name', sa.String(100), nullable=False),
        sa.Column('description', sa.Text),
        sa.Column('synonyms', postgresql.ARRAY(sa.String), default=[]),
        sa.Column('usage_count', sa.Integer, default=0),
        sa.Column('is_active', sa.Boolean, default=True),
        sa.Column('created_at', sa.DateTime, default=sa.func.now()),
    )
    
    # Articles
    op.create_table(
        'kb_articles',
        sa.Column('id', postgresql.UUID(as_uuid=True), primary_key=True),
        sa.Column('code', sa.String(100), unique=True, nullable=False, index=True),
        sa.Column('title', sa.String(500), nullable=False),
        sa.Column('title_en', sa.String(500)),
        sa.Column('article_type', sa.String(50), nullable=False, index=True),
        sa.Column('summary', sa.Text),
        sa.Column('content', sa.Text),
        sa.Column('content_html', sa.Text),
        sa.Column('key_points', postgresql.ARRAY(sa.Text), default=[]),
        sa.Column('sections', postgresql.JSON(astext_type=sa.Text()), default={}),
        sa.Column('icd10_codes', postgresql.ARRAY(sa.String), default=[]),
        sa.Column('snomed_ct', postgresql.ARRAY(sa.String), default=[]),
        sa.Column('mesh_terms', postgresql.ARRAY(sa.String), default=[]),
        sa.Column('evidence_level', sa.String(10)),
        sa.Column('evidence_summary', sa.Text),
        sa.Column('sources', postgresql.JSON(astext_type=sa.Text()), default=[]),
        sa.Column('references', postgresql.JSON(astext_type=sa.Text()), default=[]),
        sa.Column('author_id', postgresql.UUID(as_uuid=True), sa.ForeignKey('users.id')),
        sa.Column('reviewer_id', postgresql.UUID(as_uuid=True), sa.ForeignKey('users.id')),
        sa.Column('status', sa.String(50), default='draft'),
        sa.Column('published_at', sa.DateTime),
        sa.Column('keywords', postgresql.ARRAY(sa.String), default=[]),
        sa.Column('search_text', sa.Text),
        sa.Column('view_count', sa.Integer, default=0),
        sa.Column('favorite_count', sa.Integer, default=0),
        sa.Column('version', sa.Integer, default=1),
        sa.Column('is_active', sa.Boolean, default=True),
        sa.Column('created_at', sa.DateTime, default=sa.func.now()),
        sa.Column('updated_at', sa.DateTime, default=sa.func.now(), onupdate=sa.func.now()),
    )
    
    op.create_index('ix_kb_articles_search', 'kb_articles', ['search_text'])
    op.create_index('ix_kb_articles_type_status', 'kb_articles', ['article_type', 'status'])
    
    # Article Categories (many-to-many)
    op.create_table(
        'article_categories',
        sa.Column('article_id', postgresql.UUID(as_uuid=True), sa.ForeignKey('kb_articles.id')),
        sa.Column('category_id', postgresql.UUID(as_uuid=True), sa.ForeignKey('kb_categories.id')),
        sa.PrimaryKeyConstraint('article_id', 'category_id')
    )
    
    # Article Tags (many-to-many)
    op.create_table(
        'article_tags',
        sa.Column('article_id', postgresql.UUID(as_uuid=True), sa.ForeignKey('kb_articles.id')),
        sa.Column('tag_id', postgresql.UUID(as_uuid=True), sa.ForeignKey('kb_tags.id')),
        sa.PrimaryKeyConstraint('article_id', 'tag_id')
    )
    
    # Article Related (many-to-many)
    op.create_table(
        'article_related',
        sa.Column('article_id', postgresql.UUID(as_uuid=True), sa.ForeignKey('kb_articles.id')),
        sa.Column('related_article_id', postgresql.UUID(as_uuid=True), sa.ForeignKey('kb_articles.id')),
        sa.PrimaryKeyConstraint('article_id', 'related_article_id')
    )
    
    # Medications
    op.create_table(
        'kb_medications',
        sa.Column('id', postgresql.UUID(as_uuid=True), primary_key=True),
        sa.Column('article_id', postgresql.UUID(as_uuid=True), sa.ForeignKey('kb_articles.id')),
        sa.Column('atc_code', sa.String(20), index=True),
        sa.Column('generic_name', sa.String(500), nullable=False),
        sa.Column('brand_names', postgresql.ARRAY(sa.String), default=[]),
        sa.Column('drug_class', sa.String(200)),
        sa.Column('drug_subclass', sa.String(200)),
        sa.Column('mechanism', sa.Text),
        sa.Column('pharmacokinetics', postgresql.JSON(astext_type=sa.Text()), default={}),
        sa.Column('indications', postgresql.ARRAY(sa.Text), default=[]),
        sa.Column('contraindications', postgresql.ARRAY(sa.Text), default=[]),
        sa.Column('dosage_adult', postgresql.JSON(astext_type=sa.Text()), default={}),
        sa.Column('dosage_pediatric', postgresql.JSON(astext_type=sa.Text()), default={}),
        sa.Column('dosage_elderly', postgresql.JSON(astext_type=sa.Text()), default={}),
        sa.Column('dosage_renal', postgresql.JSON(astext_type=sa.Text()), default={}),
        sa.Column('dosage_hepatic', postgresql.JSON(astext_type=sa.Text()), default={}),
        sa.Column('side_effects_common', postgresql.ARRAY(sa.Text), default=[]),
        sa.Column('side_effects_serious', postgresql.ARRAY(sa.Text), default=[]),
        sa.Column('drug_interactions', postgresql.JSON(astext_type=sa.Text()), default=[]),
        sa.Column('food_interactions', postgresql.ARRAY(sa.Text), default=[]),
        sa.Column('pregnancy_category', sa.String(10)),
        sa.Column('lactation_safety', sa.String(50)),
        sa.Column('monitoring_parameters', postgresql.ARRAY(sa.Text), default=[]),
        sa.Column('therapeutic_range', postgresql.JSON(astext_type=sa.Text()), default={}),
        sa.Column('is_active', sa.Boolean, default=True),
        sa.Column('created_at', sa.DateTime, default=sa.func.now()),
        sa.Column('updated_at', sa.DateTime, default=sa.func.now(), onupdate=sa.func.now()),
    )
    
    # Diseases
    op.create_table(
        'kb_diseases',
        sa.Column('id', postgresql.UUID(as_uuid=True), primary_key=True),
        sa.Column('article_id', postgresql.UUID(as_uuid=True), sa.ForeignKey('kb_articles.id')),
        sa.Column('disease_type', sa.String(100)),
        sa.Column('body_system', sa.String(100)),
        sa.Column('prevalence', sa.Text),
        sa.Column('risk_factors', postgresql.ARRAY(sa.Text), default=[]),
        sa.Column('symptoms', postgresql.JSON(astext_type=sa.Text()), default=[]),
        sa.Column('signs', postgresql.ARRAY(sa.Text), default=[]),
        sa.Column('diagnostic_criteria', sa.Text),
        sa.Column('diagnostic_tests', postgresql.JSON(astext_type=sa.Text()), default=[]),
        sa.Column('differential_diagnosis', postgresql.ARRAY(sa.Text), default=[]),
        sa.Column('treatment_overview', sa.Text),
        sa.Column('treatment_options', postgresql.JSON(astext_type=sa.Text()), default=[]),
        sa.Column('prognosis', sa.Text),
        sa.Column('complications', postgresql.ARRAY(sa.Text), default=[]),
        sa.Column('prevention', sa.Text),
        sa.Column('screening', sa.Text),
        sa.Column('is_active', sa.Boolean, default=True),
        sa.Column('created_at', sa.DateTime, default=sa.func.now()),
        sa.Column('updated_at', sa.DateTime, default=sa.func.now(), onupdate=sa.func.now()),
    )
    
    # Procedures
    op.create_table(
        'kb_procedures',
        sa.Column('id', postgresql.UUID(as_uuid=True), primary_key=True),
        sa.Column('article_id', postgresql.UUID(as_uuid=True), sa.ForeignKey('kb_articles.id')),
        sa.Column('procedure_type', sa.String(100)),
        sa.Column('specialty', sa.String(100)),
        sa.Column('indications', postgresql.ARRAY(sa.Text), default=[]),
        sa.Column('contraindications_absolute', postgresql.ARRAY(sa.Text), default=[]),
        sa.Column('contraindications_relative', postgresql.ARRAY(sa.Text), default=[]),
        sa.Column('preoperative_preparation', sa.Text),
        sa.Column('required_tests', postgresql.ARRAY(sa.Text), default=[]),
        sa.Column('technique_description', sa.Text),
        sa.Column('steps', postgresql.ARRAY(sa.Text), default=[]),
        sa.Column('duration', sa.String(50)),
        sa.Column('anesthesia_options', postgresql.ARRAY(sa.Text), default=[]),
        sa.Column('postoperative_care', sa.Text),
        sa.Column('recovery_time', sa.String(100)),
        sa.Column('follow_up', sa.Text),
        sa.Column('risks', postgresql.ARRAY(sa.Text), default=[]),
        sa.Column('complications', postgresql.JSON(astext_type=sa.Text()), default=[]),
        sa.Column('success_rate', sa.String(50)),
        sa.Column('outcomes', sa.Text),
        sa.Column('is_active', sa.Boolean, default=True),
        sa.Column('created_at', sa.DateTime, default=sa.func.now()),
        sa.Column('updated_at', sa.DateTime, default=sa.func.now(), onupdate=sa.func.now()),
    )
    
    # Guidelines
    op.create_table(
        'kb_guidelines',
        sa.Column('id', postgresql.UUID(as_uuid=True), primary_key=True),
        sa.Column('article_id', postgresql.UUID(as_uuid=True), sa.ForeignKey('kb_articles.id')),
        sa.Column('organization', sa.String(200)),
        sa.Column('guideline_year', sa.Integer),
        sa.Column('version', sa.String(50)),
        sa.Column('target_population', sa.Text),
        sa.Column('scope', sa.Text),
        sa.Column('recommendations', postgresql.JSON(astext_type=sa.Text()), default=[]),
        sa.Column('algorithms', postgresql.JSON(astext_type=sa.Text()), default=[]),
        sa.Column('key_recommendations', postgresql.ARRAY(sa.Text), default=[]),
        sa.Column('is_active', sa.Boolean, default=True),
        sa.Column('created_at', sa.DateTime, default=sa.func.now()),
        sa.Column('updated_at', sa.DateTime, default=sa.func.now(), onupdate=sa.func.now()),
    )
    
    # Article Versions
    op.create_table(
        'kb_article_versions',
        sa.Column('id', postgresql.UUID(as_uuid=True), primary_key=True),
        sa.Column('article_id', postgresql.UUID(as_uuid=True), sa.ForeignKey('kb_articles.id')),
        sa.Column('version', sa.Integer, nullable=False),
        sa.Column('content', sa.Text),
        sa.Column('changes_summary', sa.Text),
        sa.Column('changed_by', postgresql.UUID(as_uuid=True), sa.ForeignKey('users.id')),
        sa.Column('changed_at', sa.DateTime, default=sa.func.now()),
        sa.Column('change_reason', sa.Text),
    )
    
    # Article Favorites
    op.create_table(
        'kb_article_favorites',
        sa.Column('id', postgresql.UUID(as_uuid=True), primary_key=True),
        sa.Column('user_id', postgresql.UUID(as_uuid=True), sa.ForeignKey('users.id'), nullable=False),
        sa.Column('article_id', postgresql.UUID(as_uuid=True), sa.ForeignKey('kb_articles.id'), nullable=False),
        sa.Column('notes', sa.Text),
        sa.Column('created_at', sa.DateTime, default=sa.func.now()),
    )
    
    op.create_index('ix_kb_favorites_user_article', 'kb_article_favorites', 
                    ['user_id', 'article_id'], unique=True)
    
    # Search Logs
    op.create_table(
        'kb_search_logs',
        sa.Column('id', postgresql.UUID(as_uuid=True), primary_key=True),
        sa.Column('user_id', postgresql.UUID(as_uuid=True), sa.ForeignKey('users.id')),
        sa.Column('query', sa.String(500), nullable=False),
        sa.Column('results_count', sa.Integer),
        sa.Column('clicked_article_id', postgresql.UUID(as_uuid=True), sa.ForeignKey('kb_articles.id')),
        sa.Column('search_filters', postgresql.JSON(astext_type=sa.Text()), default={}),
        sa.Column('response_time_ms', sa.Integer),
        sa.Column('created_at', sa.DateTime, default=sa.func.now()),
    )
    
    op.create_index('ix_kb_search_logs_query', 'kb_search_logs', ['query'])
    op.create_index('ix_kb_search_logs_created', 'kb_search_logs', ['created_at'])


def downgrade():
    # Drop Knowledge Base tables
    op.drop_table('kb_search_logs')
    op.drop_table('kb_article_favorites')
    op.drop_table('kb_article_versions')
    op.drop_table('kb_guidelines')
    op.drop_table('kb_procedures')
    op.drop_table('kb_diseases')
    op.drop_table('kb_medications')
    op.drop_table('article_related')
    op.drop_table('article_tags')
    op.drop_table('article_categories')
    op.drop_table('kb_articles')
    op.drop_table('kb_tags')
    op.drop_table('kb_categories')
    
    # Drop Laboratory tables
    op.drop_table('test_trends')
    op.drop_table('critical_value_alerts')
    op.drop_table('test_results')
    op.drop_table('laboratory_tests')
    op.drop_table('test_panels')
    op.drop_table('laboratories')
    op.drop_table('reference_ranges')