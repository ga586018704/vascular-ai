"""
Tests for Knowledge Base Module
Тесты для модуля медицинского справочника
"""

import pytest
from datetime import datetime
from uuid import uuid4

from sqlalchemy.ext.asyncio import AsyncSession

from app.knowledge_base.models import (
    KBArticle, KBCategory, KBTag, KBMedication,
    KBDisease, KBProcedure, KBGuideline
)
from app.knowledge_base.service import KnowledgeBaseService
from app.knowledge_base.book_data import ScientificDataStore


@pytest.fixture
async def kb_service(db: AsyncSession):
    """Фикстура для сервиса справочника"""
    return KnowledgeBaseService(db)


@pytest.fixture
async def sample_category(db: AsyncSession):
    """Создать тестовую категорию"""
    category = KBCategory(
        id=uuid4(),
        code="vascular_surgery",
        name="Сосудистая хирургия",
        name_en="Vascular Surgery",
        level=0,
        is_active=True,
        is_visible=True
    )
    db.add(category)
    await db.commit()
    return category


@pytest.fixture
async def sample_tag(db: AsyncSession):
    """Создать тестовый тег"""
    tag = KBTag(
        id=uuid4(),
        code="aaa",
        name="AAA",
        synonyms=["aortic aneurysm", "аневризма аорты"],
        is_active=True
    )
    db.add(tag)
    await db.commit()
    return tag


@pytest.fixture
async def sample_article(db: AsyncSession, sample_category: KBCategory, sample_tag: KBTag):
    """Создать тестовую статью"""
    article = KBArticle(
        id=uuid4(),
        code="I71.4",
        title="Abdominal Aortic Aneurysm",
        article_type="disease",
        content="AAA is a localized dilation of the aorta...",
        summary="Abdominal aortic aneurysm overview",
        icd10_codes=["I71.4"],
        status="published",
        published_at=datetime.utcnow(),
        is_active=True,
        view_count=100
    )
    article.categories.append(sample_category)
    article.tags.append(sample_tag)
    db.add(article)
    await db.commit()
    return article


class TestArticleSearch:
    """Тесты для поиска статей"""
    
    async def test_search_articles(
        self, 
        kb_service: KnowledgeBaseService,
        sample_article: KBArticle
    ):
        """Тест поиска статей"""
        results = await kb_service.search_articles(
            query="aortic",
            page=1,
            limit=20
        )
        
        assert results["total"] >= 1
        assert len(results["items"]) >= 1
        assert any("aortic" in a.title.lower() for a in results["items"])
    
    async def test_search_by_type(
        self, 
        kb_service: KnowledgeBaseService,
        sample_article: KBArticle
    ):
        """Тест поиска по типу"""
        results = await kb_service.search_articles(
            query="",
            article_type="disease",
            page=1,
            limit=20
        )
        
        assert all(a.article_type == "disease" for a in results["items"])
    
    async def test_get_article(
        self, 
        kb_service: KnowledgeBaseService,
        sample_article: KBArticle
    ):
        """Тест получения статьи"""
        article = await kb_service.get_article(sample_article.id)
        
        assert article is not None
        assert article.id == sample_article.id
        assert article.title == "Abdominal Aortic Aneurysm"
    
    async def test_get_article_by_code(
        self, 
        kb_service: KnowledgeBaseService,
        sample_article: KBArticle
    ):
        """Тест получения статьи по коду"""
        article = await kb_service.get_article_by_code("I71.4")
        
        assert article is not None
        assert article.code == "I71.4"


class TestCategories:
    """Тесты для категорий"""
    
    async def test_get_categories(
        self, 
        kb_service: KnowledgeBaseService,
        sample_category: KBCategory
    ):
        """Тест получения категорий"""
        categories = await kb_service.get_categories()
        
        assert len(categories) >= 1
        assert any(c.code == "vascular_surgery" for c in categories)
    
    async def test_get_category_tree(
        self, 
        kb_service: KnowledgeBaseService
    ):
        """Тест получения дерева категорий"""
        tree = await kb_service.get_category_tree()
        
        assert isinstance(tree, list)
        # Дерево должно быть вложенной структурой


class TestMedications:
    """Тесты для лекарственных препаратов"""
    
    async def test_search_medications(
        self, 
        kb_service: KnowledgeBaseService
    ):
        """Тест поиска препаратов"""
        # Предполагается, что данные загружены из seed
        medications = await kb_service.search_medications(
            query="warfarin",
            limit=10
        )
        
        # Может быть пустым если данные не загружены
        assert isinstance(medications, list)
    
    async def test_check_drug_interactions(
        self, 
        kb_service: KnowledgeBaseService
    ):
        """Тест проверки взаимодействий"""
        interactions = await kb_service.check_drug_interactions(
            ["warfarin", "aspirin"]
        )
        
        assert isinstance(interactions, list)


class TestBookData:
    """Тесты для данных из книг"""
    
    def test_get_all_articles(self):
        """Тест получения всех статей из книг"""
        articles = ScientificDataStore.get_all_articles()
        
        assert len(articles) > 0
        assert all("title" in a for a in articles)
        assert all("content" in a for a in articles)
    
    def test_get_guidelines(self):
        """Тест получения клинических руководств"""
        guidelines = ScientificDataStore.get_guidelines()
        
        assert len(guidelines) > 0
        assert all("organization" in g for g in guidelines)
        assert all("recommendations" in g for g in guidelines)
    
    def test_get_book_reference(self):
        """Тест получения информации о книге"""
        book = ScientificDataStore.get_book_reference("chronic_venous_disorders")
        
        assert book is not None
        assert book["title"] == "Chronic Venous Disorders of the Lower Limbs: A Surgical Approach"
        assert "authors" in book
        assert book["year"] == 2015
    
    def test_search_content(self):
        """Тест поиска по содержимому книг"""
        results = ScientificDataStore.search_content("EVLA")
        
        assert len(results) > 0
        assert any("EVLA" in r.get("title", "") for r in results)


class TestFavorites:
    """Тесты для избранного"""
    
    async def test_add_to_favorites(
        self, 
        kb_service: KnowledgeBaseService,
        sample_article: KBArticle
    ):
        """Тест добавления в избранное"""
        user_id = uuid4()
        
        success = await kb_service.add_to_favorites(
            user_id=user_id,
            article_id=sample_article.id,
            notes="Important for AAA cases"
        )
        
        assert success is True
        
        # Проверить что добавлено
        favorites = await kb_service.get_user_favorites(user_id)
        assert favorites["total"] == 1
    
    async def test_remove_from_favorites(
        self, 
        kb_service: KnowledgeBaseService,
        sample_article: KBArticle
    ):
        """Тест удаления из избранного"""
        user_id = uuid4()
        
        # Добавить
        await kb_service.add_to_favorites(user_id, sample_article.id)
        
        # Удалить
        success = await kb_service.remove_from_favorites(
            user_id=user_id,
            article_id=sample_article.id
        )
        
        assert success is True
        
        # Проверить что удалено
        favorites = await kb_service.get_user_favorites(user_id)
        assert favorites["total"] == 0


class TestQuickReference:
    """Тесты для быстрого справочника"""
    
    async def test_get_quick_reference_vascular_emergency(
        self, 
        kb_service: KnowledgeBaseService
    ):
        """Тест получения справочника по сосудистым экстренным состояниям"""
        reference = await kb_service.get_quick_reference("vascular_emergency")
        
        assert reference["title"] == "Сосудистые экстренные состояния"
        assert len(reference["items"]) > 0
        assert any("Расслоение аорты" in i.get("condition", "") for i in reference["items"])
    
    async def test_get_quick_reference_anticoagulation(
        self, 
        kb_service: KnowledgeBaseService
    ):
        """Тест получения справочника по антикоагулянтам"""
        reference = await kb_service.get_quick_reference("anticoagulation")
        
        assert reference["title"] == "Антикоагулянтная терапия"
        assert len(reference["items"]) > 0
    
    async def test_get_quick_reference_aaa_sizes(
        self, 
        kb_service: KnowledgeBaseService
    ):
        """Тест получения справочника по размерам ААА"""
        reference = await kb_service.get_quick_reference("aaa_sizes")
        
        assert reference["title"] == "Размеры ААА и показания к лечению"
        assert len(reference["items"]) > 0


class TestGuidelines:
    """Тесты для клинических руководств"""
    
    async def test_get_guidelines(
        self, 
        kb_service: KnowledgeBaseService
    ):
        """Тест получения руководств"""
        results = await kb_service.get_guidelines()
        
        assert "items" in results
        assert "total" in results
    
    async def test_get_guideline_by_organization(
        self, 
        kb_service: KnowledgeBaseService
    ):
        """Тест фильтрации руководств по организации"""
        results = await kb_service.get_guidelines(organization="ESVS")
        
        # Может быть пустым если данные не загружены
        assert isinstance(results["items"], list)


class TestPopularArticles:
    """Тесты для популярных статей"""
    
    async def test_get_popular_articles(
        self, 
        kb_service: KnowledgeBaseService,
        sample_article: KBArticle
    ):
        """Тест получения популярных статей"""
        # Увеличить счетчик просмотров
        await kb_service.increment_view_count(sample_article.id)
        await kb_service.increment_view_count(sample_article.id)
        
        articles = await kb_service.get_popular_articles(limit=10)
        
        assert len(articles) >= 1
        assert articles[0].view_count >= 2


class TestTags:
    """Тесты для тегов"""
    
    async def test_get_tags(
        self, 
        kb_service: KnowledgeBaseService,
        sample_tag: KBTag
    ):
        """Тест получения тегов"""
        tags = await kb_service.get_tags(limit=50)
        
        assert len(tags) >= 1
        assert any(t.code == "aaa" for t in tags)
    
    async def test_search_tags(
        self, 
        kb_service: KnowledgeBaseService
    ):
        """Тест поиска тегов"""
        tags = await kb_service.get_tags(search="vascular", limit=10)
        
        assert isinstance(tags, list)