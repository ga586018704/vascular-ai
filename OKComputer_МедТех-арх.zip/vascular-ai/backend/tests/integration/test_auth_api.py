"""
VASCULAR.AI - Authentication API Integration Tests
Tests for login, registration, and token management
"""

import pytest
from httpx import AsyncClient
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select

from app.main import app
from app.models.database import User, get_db
from app.core.security import SecurityManager


@pytest.fixture
async def client():
    """Create test client"""
    async with AsyncClient(app=app, base_url="http://test") as ac:
        yield ac


@pytest.fixture
async def test_user(db: AsyncSession):
    """Create a test user"""
    user = User(
        email="test.surgeon@hospital.com",
        hashed_password=SecurityManager.get_password_hash("TestPass123!"),
        full_name="Test Surgeon",
        license_number="SURG-12345",
        is_active=True,
        is_superuser=False
    )
    db.add(user)
    await db.commit()
    await db.refresh(user)
    return user


class TestRegistration:
    """Tests for user registration"""
    
    @pytest.mark.asyncio
    async def test_successful_registration(self, client):
        """Test successful user registration"""
        response = await client.post(
            "/api/auth/register",
            params={
                "email": "new.surgeon@hospital.com",
                "password": "SecurePass123!",
                "full_name": "New Surgeon",
                "license_number": "SURG-99999"
            }
        )
        
        assert response.status_code == 200
        data = response.json()
        assert data["success"] is True
        assert "user_id" in data
    
    @pytest.mark.asyncio
    async def test_registration_invalid_email(self, client):
        """Test registration with invalid email"""
        response = await client.post(
            "/api/auth/register",
            params={
                "email": "invalid-email",
                "password": "SecurePass123!",
                "full_name": "Test User"
            }
        )
        
        assert response.status_code == 400
        assert "Invalid email" in response.json()["detail"]
    
    @pytest.mark.asyncio
    async def test_registration_weak_password(self, client):
        """Test registration with weak password"""
        response = await client.post(
            "/api/auth/register",
            params={
                "email": "test@hospital.com",
                "password": "123",  # Too short
                "full_name": "Test User"
            }
        )
        
        assert response.status_code == 400
        assert "at least 8 characters" in response.json()["detail"]
    
    @pytest.mark.asyncio
    async def test_registration_duplicate_email(self, client, test_user):
        """Test registration with duplicate email"""
        response = await client.post(
            "/api/auth/register",
            params={
                "email": "test.surgeon@hospital.com",  # Already exists
                "password": "SecurePass123!",
                "full_name": "Another Surgeon"
            }
        )
        
        assert response.status_code == 400
        assert "already registered" in response.json()["detail"]


class TestLogin:
    """Tests for user login"""
    
    @pytest.mark.asyncio
    async def test_successful_login(self, client, test_user):
        """Test successful login"""
        response = await client.post(
            "/api/auth/login",
            data={
                "username": "test.surgeon@hospital.com",
                "password": "TestPass123!"
            }
        )
        
        assert response.status_code == 200
        data = response.json()
        assert "access_token" in data
        assert "refresh_token" in data
        assert data["token_type"] == "bearer"
        assert "user" in data
        assert data["user"]["email"] == "test.surgeon@hospital.com"
    
    @pytest.mark.asyncio
    async def test_login_invalid_password(self, client, test_user):
        """Test login with invalid password"""
        response = await client.post(
            "/api/auth/login",
            data={
                "username": "test.surgeon@hospital.com",
                "password": "WrongPassword"
            }
        )
        
        assert response.status_code == 401
        assert "Incorrect" in response.json()["detail"]
    
    @pytest.mark.asyncio
    async def test_login_nonexistent_user(self, client):
        """Test login with non-existent user"""
        response = await client.post(
            "/api/auth/login",
            data={
                "username": "nonexistent@hospital.com",
                "password": "SomePass123!"
            }
        )
        
        assert response.status_code == 401
    
    @pytest.mark.asyncio
    async def test_login_inactive_user(self, client, db):
        """Test login with inactive user account"""
        # Create inactive user
        inactive_user = User(
            email="inactive@hospital.com",
            hashed_password=SecurityManager.get_password_hash("TestPass123!"),
            full_name="Inactive User",
            is_active=False
        )
        db.add(inactive_user)
        await db.commit()
        
        response = await client.post(
            "/api/auth/login",
            data={
                "username": "inactive@hospital.com",
                "password": "TestPass123!"
            }
        )
        
        assert response.status_code == 403
        assert "deactivated" in response.json()["detail"]


class TestTokenManagement:
    """Tests for token management"""
    
    @pytest.mark.asyncio
    async def test_refresh_token(self, client, test_user):
        """Test token refresh"""
        # First login to get tokens
        login_response = await client.post(
            "/api/auth/login",
            data={
                "username": "test.surgeon@hospital.com",
                "password": "TestPass123!"
            }
        )
        
        refresh_token = login_response.json()["refresh_token"]
        
        # Refresh the token
        response = await client.post(
            "/api/auth/refresh",
            params={"refresh_token": refresh_token}
        )
        
        assert response.status_code == 200
        data = response.json()
        assert "access_token" in data
        assert data["token_type"] == "bearer"
    
    @pytest.mark.asyncio
    async def test_refresh_invalid_token(self, client):
        """Test refresh with invalid token"""
        response = await client.post(
            "/api/auth/refresh",
            params={"refresh_token": "invalid.token.here"}
        )
        
        assert response.status_code == 401
    
    @pytest.mark.asyncio
    async def test_access_protected_endpoint(self, client, test_user):
        """Test accessing protected endpoint with valid token"""
        # Login first
        login_response = await client.post(
            "/api/auth/login",
            data={
                "username": "test.surgeon@hospital.com",
                "password": "TestPass123!"
            }
        )
        
        token = login_response.json()["access_token"]
        
        # Access protected endpoint
        response = await client.get(
            "/api/auth/me",
            headers={"Authorization": f"Bearer {token}"}
        )
        
        assert response.status_code == 200
        data = response.json()
        assert data["email"] == "test.surgeon@hospital.com"
    
    @pytest.mark.asyncio
    async def test_access_protected_no_token(self, client):
        """Test accessing protected endpoint without token"""
        response = await client.get("/api/auth/me")
        
        assert response.status_code == 401
    
    @pytest.mark.asyncio
    async def test_access_protected_invalid_token(self, client):
        """Test accessing protected endpoint with invalid token"""
        response = await client.get(
            "/api/auth/me",
            headers={"Authorization": "Bearer invalid.token.here"}
        )
        
        assert response.status_code == 401


class TestPasswordChange:
    """Tests for password change functionality"""
    
    @pytest.mark.asyncio
    async def test_successful_password_change(self, client, test_user):
        """Test successful password change"""
        # Login first
        login_response = await client.post(
            "/api/auth/login",
            data={
                "username": "test.surgeon@hospital.com",
                "password": "TestPass123!"
            }
        )
        
        token = login_response.json()["access_token"]
        
        # Change password
        response = await client.post(
            "/api/auth/change-password",
            params={
                "current_password": "TestPass123!",
                "new_password": "NewSecurePass456!"
            },
            headers={"Authorization": f"Bearer {token}"}
        )
        
        assert response.status_code == 200
        assert response.json()["success"] is True
        
        # Verify old password no longer works
        old_login = await client.post(
            "/api/auth/login",
            data={
                "username": "test.surgeon@hospital.com",
                "password": "TestPass123!"
            }
        )
        assert old_login.status_code == 401
        
        # Verify new password works
        new_login = await client.post(
            "/api/auth/login",
            data={
                "username": "test.surgeon@hospital.com",
                "password": "NewSecurePass456!"
            }
        )
        assert new_login.status_code == 200
    
    @pytest.mark.asyncio
    async def test_password_change_wrong_current(self, client, test_user):
        """Test password change with wrong current password"""
        # Login first
        login_response = await client.post(
            "/api/auth/login",
            data={
                "username": "test.surgeon@hospital.com",
                "password": "TestPass123!"
            }
        )
        
        token = login_response.json()["access_token"]
        
        # Try to change with wrong current password
        response = await client.post(
            "/api/auth/change-password",
            params={
                "current_password": "WrongPassword",
                "new_password": "NewSecurePass456!"
            },
            headers={"Authorization": f"Bearer {token}"}
        )
        
        assert response.status_code == 400
        assert "incorrect" in response.json()["detail"].lower()


class TestRateLimiting:
    """Tests for rate limiting"""
    
    @pytest.mark.asyncio
    async def test_login_rate_limit(self, client):
        """Test rate limiting on login endpoint"""
        # Make multiple rapid login attempts
        for i in range(7):  # Exceed the 5/minute limit
            response = await client.post(
                "/api/auth/login",
                data={
                    "username": f"user{i}@test.com",
                    "password": "wrong"
                }
            )
        
        # Should eventually get rate limited
        # Note: In actual tests, this depends on the rate limit implementation
        assert response.status_code in [401, 429]


if __name__ == "__main__":
    pytest.main([__file__, "-v"])
