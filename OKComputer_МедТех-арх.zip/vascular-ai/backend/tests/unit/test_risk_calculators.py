"""
VASCULAR.AI - Unit Tests for Risk Calculators
"""

import pytest
from app.services.surgeon_tools import VSGNECalculator, GASCalculator


class TestVSGNECalculator:
    """Test cases for VSGNE Risk Calculator"""
    
    def test_low_risk_patient(self):
        """Test calculation for low-risk patient"""
        calculator = VSGNECalculator()
        patient_data = {
            "age": 65,
            "gender": "male",
            "creatinine": 1.0,
            "cad": False,
            "chf": False,
            "copd": False,
            "urgency": "elective"
        }
        
        result = calculator.calculate(patient_data, "open")
        
        assert result["score"] <= 3
        assert result["risk_category"] == "Низкий риск"
        assert result["predicted_mortality"]["percentage"] < 2.0
    
    def test_high_risk_patient(self):
        """Test calculation for high-risk patient"""
        calculator = VSGNECalculator()
        patient_data = {
            "age": 82,
            "gender": "female",
            "creatinine": 2.5,
            "cad": True,
            "chf": True,
            "copd": True,
            "urgency": "emergent"
        }
        
        result = calculator.calculate(patient_data, "open")
        
        assert result["score"] >= 7
        assert result["risk_category"] == "Высокий риск"
        assert result["predicted_mortality"]["percentage"] > 9.0
    
    def test_age_scoring(self):
        """Test age-based scoring"""
        calculator = VSGNECalculator()
        
        # Age 70-74: +1
        result = calculator.calculate({"age": 72}, "open")
        assert any("70-74" in rf for rf in result["risk_factors"])
        
        # Age 75-79: +2
        result = calculator.calculate({"age": 77}, "open")
        assert any("75-79" in rf for rf in result["risk_factors"])
        
        # Age 80+: +3
        result = calculator.calculate({"age": 82}, "open")
        assert any("≥80" in rf for rf in result["risk_factors"])
    
    def test_creatinine_scoring(self):
        """Test creatinine-based scoring"""
        calculator = VSGNECalculator()
        
        # Normal creatinine
        result = calculator.calculate({"creatinine": 1.0}, "open")
        assert result["score"] == 0
        
        # Elevated creatinine 1.2-1.4: +1
        result = calculator.calculate({"creatinine": 1.3}, "open")
        assert result["score"] == 1
        
        # High creatinine 1.5-1.9: +2
        result = calculator.calculate({"creatinine": 1.7}, "open")
        assert result["score"] == 2
        
        # Very high creatinine >=2.0: +3
        result = calculator.calculate({"creatinine": 2.5}, "open")
        assert result["score"] == 3
    
    def test_urgency_scoring(self):
        """Test urgency-based scoring"""
        calculator = VSGNECalculator()
        
        # Elective: 0
        result = calculator.calculate({"urgency": "elective"}, "open")
        assert not any("операция" in rf for rf in result["risk_factors"])
        
        # Urgent: +3
        result = calculator.calculate({"urgency": "urgent"}, "open")
        assert any("Срочная" in rf for rf in result["risk_factors"])
        
        # Emergent: +5
        result = calculator.calculate({"urgency": "emergent"}, "open")
        assert any("Экстренная" in rf for rf in result["risk_factors"])
    
    def test_evar_vs_open(self):
        """Test EVAR vs open surgery scoring"""
        calculator = VSGNECalculator()
        patient_data = {"age": 70}
        
        open_result = calculator.calculate(patient_data, "open")
        evar_result = calculator.calculate(patient_data, "evar")
        
        assert open_result["score"] == evar_result["score"] + 2


class TestGASCalculator:
    """Test cases for GAS (Global Aneurysm Score) Calculator"""
    
    def test_low_gas_score(self):
        """Test low GAS score"""
        calculator = GASCalculator()
        patient_data = {
            "age": 60,
            "systolic_bp": 120,
            "loss_of_consciousness": False,
            "hemoglobin": 13,
            "creatinine": 1.0,
            "ischemia_time": 0
        }
        
        result = calculator.calculate(patient_data)
        
        assert result["gas_score"] <= 10
        assert result["predicted_mortality"]["percentage"] <= 15
    
    def test_high_gas_score(self):
        """Test high GAS score"""
        calculator = GASCalculator()
        patient_data = {
            "age": 80,
            "systolic_bp": 60,
            "loss_of_consciousness": True,
            "hemoglobin": 6,
            "creatinine": 3.0,
            "ischemia_time": 150
        }
        
        result = calculator.calculate(patient_data)
        
        assert result["gas_score"] > 30
        assert result["predicted_mortality"]["percentage"] > 75
    
    def test_age_scoring(self):
        """Test age-based scoring in GAS"""
        calculator = GASCalculator()
        
        test_cases = [
            (50, 0),   # <57
            (60, 2),   # 57-64
            (68, 4),   # 64-70
            (75, 7),   # 70-76
            (82, 11),  # >76
        ]
        
        for age, expected_score in test_cases:
            result = calculator.calculate({"age": age})
            assert result["gas_score"] == expected_score, f"Age {age} should score {expected_score}"
    
    def test_systolic_bp_scoring(self):
        """Test systolic BP scoring"""
        calculator = GASCalculator()
        
        test_cases = [
            (120, 0),   # Normal
            (95, 2),    # 90-100
            (85, 4),    # 80-90
            (75, 7),    # 70-80
            (65, 10),   # <70
        ]
        
        for bp, expected_score in test_cases:
            result = calculator.calculate({"systolic_bp": bp})
            assert result["gas_score"] == expected_score, f"BP {bp} should score {expected_score}"
    
    def test_hemoglobin_scoring(self):
        """Test hemoglobin scoring"""
        calculator = GASCalculator()
        
        test_cases = [
            (13, 0),   # Normal
            (11, 2),   # 11-12
            (9, 4),    # 9-11
            (7, 7),    # 7-9
            (6, 10),   # <7
        ]
        
        for hgb, expected_score in test_cases:
            result = calculator.calculate({"hemoglobin": hgb})
            assert result["gas_score"] == expected_score, f"Hgb {hgb} should score {expected_score}"


class TestInputValidation:
    """Test input validation for calculators"""
    
    def test_negative_age_raises_error(self):
        """Test that negative age is rejected"""
        calculator = VSGNECalculator()
        
        with pytest.raises(ValueError):
            calculator.calculate({"age": -5}, "open")
    
    def test_negative_creatinine_raises_error(self):
        """Test that negative creatinine is rejected"""
        calculator = VSGNECalculator()
        
        with pytest.raises(ValueError):
            calculator.calculate({"creatinine": -1.0}, "open")
    
    def test_invalid_procedure_type(self):
        """Test that invalid procedure type is rejected"""
        calculator = VSGNECalculator()
        
        with pytest.raises(ValueError):
            calculator.calculate({}, "invalid_procedure")


class TestEdgeCases:
    """Test edge cases and boundary conditions"""
    
    def test_exact_boundary_values(self):
        """Test exact boundary values"""
        calculator = VSGNECalculator()
        
        # Age exactly 70
        result = calculator.calculate({"age": 70}, "open")
        assert any("70-74" in rf for rf in result["risk_factors"])
        
        # Creatinine exactly 1.5
        result = calculator.calculate({"creatinine": 1.5}, "open")
        assert result["score"] == 2
    
    def test_missing_optional_fields(self):
        """Test with missing optional fields"""
        calculator = VSGNECalculator()
        
        # Only required fields
        result = calculator.calculate({"age": 65}, "open")
        assert result["score"] >= 0
        assert "risk_category" in result
    
    def test_extreme_values(self):
        """Test extreme but valid values"""
        calculator = VSGNECalculator()
        
        # Very old patient
        result = calculator.calculate({"age": 100}, "open")
        assert result["score"] >= 3
        
        # Very high creatinine
        result = calculator.calculate({"creatinine": 10.0}, "open")
        assert result["score"] >= 3
