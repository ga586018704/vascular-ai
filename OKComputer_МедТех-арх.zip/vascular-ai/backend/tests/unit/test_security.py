"""
VASCULAR.AI - Security Module Tests
Tests for authentication, encryption, and access control
"""

import pytest
from datetime import timedelta
from jose import jwt

from app.core.security import (
    SecurityManager, 
    RBAC, 
    InputValidator,
    RateLimitConfig
)
from app.core.config import settings


class TestSecurityManager:
    """Tests for SecurityManager class"""
    
    def test_password_hashing(self):
        """Test password hashing and verification"""
        password = "SecurePass123!"
        hashed = SecurityManager.get_password_hash(password)
        
        # Hash should be different from plaintext
        assert hashed != password
        # Verification should succeed
        assert SecurityManager.verify_password(password, hashed) is True
        # Wrong password should fail
        assert SecurityManager.verify_password("WrongPass", hashed) is False
    
    def test_password_hash_uniqueness(self):
        """Test that same password produces different hashes"""
        password = "TestPass123!"
        hash1 = SecurityManager.get_password_hash(password)
        hash2 = SecurityManager.get_password_hash(password)
        
        # Hashes should be different (due to salt)
        assert hash1 != hash2
        # Both should verify correctly
        assert SecurityManager.verify_password(password, hash1) is True
        assert SecurityManager.verify_password(password, hash2) is True
    
    def test_jwt_token_creation(self):
        """Test JWT token creation and verification"""
        data = {"sub": "123", "email": "test@example.com", "role": "surgeon"}
        token = SecurityManager.create_access_token(data)
        
        # Token should be a string
        assert isinstance(token, str)
        # Token should be verifiable
        payload = SecurityManager.verify_token(token)
        assert payload is not None
        assert payload["sub"] == "123"
        assert payload["email"] == "test@example.com"
        assert payload["role"] == "surgeon"
    
    def test_jwt_token_expiration(self):
        """Test JWT token expiration"""
        data = {"sub": "123"}
        # Create token that expires immediately
        token = SecurityManager.create_access_token(data, expires_delta=timedelta(seconds=-1))
        
        # Token should be invalid
        payload = SecurityManager.verify_token(token)
        assert payload is None
    
    def test_jwt_refresh_token(self):
        """Test refresh token creation"""
        data = {"sub": "123"}
        token = SecurityManager.create_refresh_token(data)
        
        payload = SecurityManager.verify_token(token)
        assert payload is not None
        assert payload["sub"] == "123"
        assert payload["type"] == "refresh"
    
    def test_invalid_token(self):
        """Test verification of invalid token"""
        # Invalid token
        payload = SecurityManager.verify_token("invalid.token.here")
        assert payload is None
        
        # Empty token
        payload = SecurityManager.verify_token("")
        assert payload is None
    
    def test_phi_encryption(self):
        """Test PHI encryption and decryption"""
        sensitive_data = "Patient: John Doe, SSN: 123-45-6789"
        
        encrypted = SecurityManager.encrypt_phi(sensitive_data)
        # Encrypted data should be bytes
        assert isinstance(encrypted, bytes)
        # Encrypted should be different from original
        assert encrypted != sensitive_data.encode()
        
        decrypted = SecurityManager.decrypt_phi(encrypted)
        # Decrypted should match original
        assert decrypted == sensitive_data
    
    def test_patient_id_hashing(self):
        """Test patient ID hashing"""
        patient_id = "PATIENT_12345"
        hash1 = SecurityManager.hash_patient_id(patient_id)
        hash2 = SecurityManager.hash_patient_id(patient_id)
        
        # Same ID should produce same hash
        assert hash1 == hash2
        # Hash should be fixed length
        assert len(hash1) == 16
        
        # Different ID should produce different hash
        different_hash = SecurityManager.hash_patient_id("PATIENT_99999")
        assert different_hash != hash1
    
    def test_secure_token_generation(self):
        """Test secure token generation"""
        token1 = SecurityManager.generate_secure_token()
        token2 = SecurityManager.generate_secure_token()
        
        # Tokens should be unique
        assert token1 != token2
        # Default length should be sufficient
        assert len(token1) >= 32
        
        # Custom length
        token_short = SecurityManager.generate_secure_token(length=16)
        assert len(token_short) >= 16


class TestRBAC:
    """Tests for Role-Based Access Control"""
    
    def test_admin_permissions(self):
        """Test admin has all permissions"""
        assert RBAC.has_permission("admin", "read:patient") is True
        assert RBAC.has_permission("admin", "write:patient") is True
        assert RBAC.has_permission("admin", "delete:patient") is True
        assert RBAC.has_permission("admin", "any:permission") is True
    
    def test_surgeon_permissions(self):
        """Test surgeon permissions"""
        assert RBAC.has_permission("surgeon", "read:patient") is True
        assert RBAC.has_permission("surgeon", "write:patient") is True
        assert RBAC.has_permission("surgeon", "read:study") is True
        assert RBAC.has_permission("surgeon", "execute:calculator") is True
        assert RBAC.has_permission("surgeon", "delete:patient") is False
        assert RBAC.has_permission("surgeon", "admin:settings") is False
    
    def test_resident_permissions(self):
        """Test resident permissions (read-only)"""
        assert RBAC.has_permission("resident", "read:patient") is True
        assert RBAC.has_permission("resident", "read:study") is True
        assert RBAC.has_permission("resident", "write:patient") is False
        assert RBAC.has_permission("resident", "write:study") is False
    
    def test_radiologist_permissions(self):
        """Test radiologist permissions"""
        assert RBAC.has_permission("radiologist", "read:study") is True
        assert RBAC.has_permission("radiologist", "write:study") is True
        assert RBAC.has_permission("radiologist", "read:patient") is True
        assert RBAC.has_permission("radiologist", "write:patient") is False
    
    def test_nurse_permissions(self):
        """Test nurse permissions"""
        assert RBAC.has_permission("nurse", "read:patient") is True
        assert RBAC.has_permission("nurse", "write:patient_vitals") is True
        assert RBAC.has_permission("nurse", "write:patient") is False
        assert RBAC.has_permission("nurse", "read:study") is False
    
    def test_researcher_permissions(self):
        """Test researcher permissions"""
        assert RBAC.has_permission("researcher", "read:anonymized_data") is True
        assert RBAC.has_permission("researcher", "read:patient") is False
        assert RBAC.has_permission("researcher", "write:study") is False
    
    def test_invalid_role(self):
        """Test invalid role handling"""
        assert RBAC.has_permission("invalid_role", "read:patient") is False
        assert RBAC.has_permission("", "read:patient") is False
    
    def test_get_role_permissions(self):
        """Test getting all permissions for a role"""
        admin_perms = RBAC.get_role_permissions("admin")
        assert "*" in admin_perms
        
        surgeon_perms = RBAC.get_role_permissions("surgeon")
        assert "read:patient" in surgeon_perms
        assert "write:patient" in surgeon_perms
        
        invalid_perms = RBAC.get_role_permissions("invalid")
        assert invalid_perms == []


class TestInputValidator:
    """Tests for input validation"""
    
    def test_valid_study_id(self):
        """Test valid study ID formats"""
        assert InputValidator.validate_study_id("STUDY_1234") is True
        assert InputValidator.validate_study_id("ABC-DEF-123") is True
        assert InputValidator.validate_study_id("A1B2C3D4E5F6") is True
    
    def test_invalid_study_id(self):
        """Test invalid study ID formats"""
        assert InputValidator.validate_study_id("short") is False  # Too short
        assert InputValidator.validate_study_id("a" * 33) is False  # Too long
        assert InputValidator.validate_study_id("study@123") is False  # Invalid chars
        assert InputValidator.validate_study_id("") is False  # Empty
    
    def test_valid_patient_id(self):
        """Test valid patient ID formats"""
        assert InputValidator.validate_patient_id("PATIENT123") is True
        assert InputValidator.validate_patient_id("ABC1234567") is True
    
    def test_invalid_patient_id(self):
        """Test invalid patient ID formats"""
        assert InputValidator.validate_patient_id("short") is False
        assert InputValidator.validate_patient_id("a" * 21) is False
        assert InputValidator.validate_patient_id("patient@123") is False
    
    def test_valid_mrn(self):
        """Test valid MRN formats"""
        assert InputValidator.validate_mrn("123456") is True
        assert InputValidator.validate_mrn("1234567890") is True
    
    def test_invalid_mrn(self):
        """Test invalid MRN formats"""
        assert InputValidator.validate_mrn("12345") is False  # Too short
        assert InputValidator.validate_mrn("12345678901") is False  # Too long
        assert InputValidator.validate_mrn("MRN123") is False  # Letters not allowed
    
    def test_valid_email(self):
        """Test valid email formats"""
        assert InputValidator.validate_email("test@example.com") is True
        assert InputValidator.validate_email("user.name@domain.co.uk") is True
        assert InputValidator.validate_email("user+tag@example.org") is True
    
    def test_invalid_email(self):
        """Test invalid email formats"""
        assert InputValidator.validate_email("invalid") is False
        assert InputValidator.validate_email("@example.com") is False
        assert InputValidator.validate_email("test@") is False
        assert InputValidator.validate_email("test@.com") is False
    
    def test_sanitize_filename(self):
        """Test filename sanitization"""
        # Path traversal attempts
        assert InputValidator.sanitize_filename("../../../etc/passwd") == "passwd"
        assert InputValidator.sanitize_filename("..\\..\\windows\\system32") == "system32"
        
        # Malicious characters
        assert ";" not in InputValidator.sanitize_filename("file;rm -rf /")
        assert "|" not in InputValidator.sanitize_filename("file|cat /etc/passwd")
        assert "&" not in InputValidator.sanitize_filename("file&&whoami")
        
        # Valid filenames should be preserved
        assert InputValidator.sanitize_filename("valid_file.dcm") == "valid_file.dcm"
        assert InputValidator.sanitize_filename("study-123_456.nii.gz") == "study-123_456.nii.gz"


class TestRateLimitConfig:
    """Tests for rate limiting configuration"""
    
    def test_rate_limits_defined(self):
        """Test that rate limits are defined for all categories"""
        assert "auth" in RateLimitConfig.LIMITS
        assert "dicom_upload" in RateLimitConfig.LIMITS
        assert "api_general" in RateLimitConfig.LIMITS
        assert "calculator" in RateLimitConfig.LIMITS
        assert "search" in RateLimitConfig.LIMITS
    
    def test_rate_limit_format(self):
        """Test that rate limits follow expected format"""
        for key, limit in RateLimitConfig.LIMITS.items():
            parts = limit.split("/")
            assert len(parts) == 2
            assert parts[0].isdigit()
            assert parts[1] in ["second", "minute", "hour", "day"]


class TestSecurityIntegration:
    """Integration tests for security features"""
    
    def test_full_auth_flow(self):
        """Test complete authentication flow"""
        # 1. Create password hash
        password = "MySecurePass123!"
        hashed = SecurityManager.get_password_hash(password)
        
        # 2. Verify password
        assert SecurityManager.verify_password(password, hashed) is True
        
        # 3. Create access token
        user_data = {"sub": "123", "email": "surgeon@hospital.com", "role": "surgeon"}
        token = SecurityManager.create_access_token(user_data)
        
        # 4. Verify token
        payload = SecurityManager.verify_token(token)
        assert payload is not None
        assert payload["sub"] == "123"
        
        # 5. Check permissions
        role = payload.get("role", "surgeon")
        assert RBAC.has_permission(role, "read:patient") is True
        assert RBAC.has_permission(role, "write:study") is True
    
    def test_phi_protection_flow(self):
        """Test PHI encryption in data flow"""
        # Sensitive patient data
        patient_name = "John Doe"
        patient_ssn = "123-45-6789"
        
        # Encrypt for storage
        encrypted_name = SecurityManager.encrypt_phi(patient_name)
        encrypted_ssn = SecurityManager.encrypt_phi(patient_ssn)
        
        # Store encrypted data (simulated)
        stored_data = {
            "name_encrypted": encrypted_name,
            "ssn_encrypted": encrypted_ssn
        }
        
        # Decrypt when needed
        decrypted_name = SecurityManager.decrypt_phi(stored_data["name_encrypted"])
        decrypted_ssn = SecurityManager.decrypt_phi(stored_data["ssn_encrypted"])
        
        assert decrypted_name == patient_name
        assert decrypted_ssn == patient_ssn


if __name__ == "__main__":
    pytest.main([__file__, "-v"])
