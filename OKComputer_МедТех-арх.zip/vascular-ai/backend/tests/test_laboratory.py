"""
Tests for Laboratory Module
Тесты для модуля лабораторных исследований
"""

import pytest
from datetime import datetime
from decimal import Decimal
from uuid import uuid4

from sqlalchemy.ext.asyncio import AsyncSession

from app.laboratory.models import (
    LaboratoryTest, TestResult, ReferenceRange, 
    TestPanel, Laboratory
)
from app.laboratory.schemas import (
    LaboratoryTestCreate, TestResultCreate, 
    ReferenceRangeCreate, TestPanelCreate
)
from app.laboratory.service import LaboratoryService


@pytest.fixture
async def lab_service(db: AsyncSession):
    """Фикстура для сервиса лаборатории"""
    return LaboratoryService(db)


@pytest.fixture
async def sample_reference_range(db: AsyncSession):
    """Создать тестовые референсные значения"""
    ref = ReferenceRange(
        id=uuid4(),
        test_code="CREATININE",
        test_name="Creatinine",
        category="kidney_function",
        unit="mg/dL",
        min_value=Decimal("0.7"),
        max_value=Decimal("1.3"),
        critical_high=Decimal("5.0"),
        is_active=True
    )
    db.add(ref)
    await db.commit()
    return ref


@pytest.fixture
async def sample_panel(db: AsyncSession):
    """Создать тестовую панель"""
    panel = TestPanel(
        id=uuid4(),
        code="BASIC_METABOLIC",
        name="Basic Metabolic Panel",
        category="biochemistry",
        test_codes=["SODIUM", "POTASSIUM", "GLUCOSE", "CREATININE"],
        is_active=True
    )
    db.add(panel)
    await db.commit()
    return panel


class TestReferenceRange:
    """Тесты для референсных значений"""
    
    async def test_create_reference_range(self, lab_service: LaboratoryService):
        """Тест создания референсных значений"""
        data = ReferenceRangeCreate(
            test_code="GLUCOSE",
            test_name="Glucose",
            category="biochemistry",
            unit="mg/dL",
            min_value=Decimal("70"),
            max_value=Decimal("100"),
            critical_low=Decimal("40"),
            critical_high=Decimal("400")
        )
        
        ref = await lab_service.create_reference_range(data)
        
        assert ref.test_code == "GLUCOSE"
        assert ref.min_value == Decimal("70")
        assert ref.max_value == Decimal("100")
        assert ref.is_active is True
    
    async def test_get_reference_range(
        self, 
        lab_service: LaboratoryService, 
        sample_reference_range: ReferenceRange
    ):
        """Тест получения референсных значений"""
        ref = await lab_service.get_reference_range("CREATININE")
        
        assert ref is not None
        assert ref.test_code == "CREATININE"
        assert ref.min_value == Decimal("0.7")
        assert ref.max_value == Decimal("1.3")


class TestLaboratoryTest:
    """Тесты для лабораторных исследований"""
    
    async def test_create_test(
        self, 
        lab_service: LaboratoryService,
        sample_panel: TestPanel
    ):
        """Тест создания исследования"""
        patient_id = uuid4()
        doctor_id = uuid4()
        
        data = LaboratoryTestCreate(
            patient_id=patient_id,
            test_codes=["CREATININE", "GLUCOSE"],
            panel_code="BASIC_METABOLIC",
            priority="routine"
        )
        
        test = await lab_service.create_test(data, doctor_id)
        
        assert test.patient_id == patient_id
        assert test.doctor_id == doctor_id
        assert test.status == "ordered"
        assert test.priority == "routine"
        assert test.order_number.startswith("LAB")
    
    async def test_add_result(
        self, 
        lab_service: LaboratoryService,
        sample_reference_range: ReferenceRange
    ):
        """Тест добавления результата"""
        # Создать тест
        patient_id = uuid4()
        doctor_id = uuid4()
        
        test_data = LaboratoryTestCreate(
            patient_id=patient_id,
            test_codes=["CREATININE"],
            priority="routine"
        )
        test = await lab_service.create_test(test_data, doctor_id)
        
        # Добавить результат
        result_data = TestResultCreate(
            test_code="CREATININE",
            test_name="Creatinine",
            category="kidney_function",
            value_numeric=Decimal("1.1"),
            unit="mg/dL",
            reference_min=Decimal("0.7"),
            reference_max=Decimal("1.3")
        )
        
        result = await lab_service.add_result(test.id, result_data)
        
        assert result.test_code == "CREATININE"
        assert result.value_numeric == Decimal("1.1")
        assert result.interpretation == "normal"
        assert result.is_critical is False
        assert result.is_abnormal is False
    
    async def test_critical_value_detection(
        self, 
        lab_service: LaboratoryService,
        sample_reference_range: ReferenceRange
    ):
        """Тест обнаружения критического значения"""
        patient_id = uuid4()
        doctor_id = uuid4()
        
        test_data = LaboratoryTestCreate(
            patient_id=patient_id,
            test_codes=["CREATININE"],
            priority="routine"
        )
        test = await lab_service.create_test(test_data, doctor_id)
        
        # Добавить критическое значение
        result_data = TestResultCreate(
            test_code="CREATININE",
            test_name="Creatinine",
            category="kidney_function",
            value_numeric=Decimal("6.0"),  # Критически высокое
            unit="mg/dL",
            reference_min=Decimal("0.7"),
            reference_max=Decimal("1.3")
        )
        
        result = await lab_service.add_result(test.id, result_data)
        
        assert result.interpretation == "critical_high"
        assert result.is_critical is True
        assert result.is_abnormal is True
    
    async def test_delta_check(
        self, 
        lab_service: LaboratoryService,
        sample_reference_range: ReferenceRange
    ):
        """Тест delta check"""
        patient_id = uuid4()
        doctor_id = uuid4()
        
        test_data = LaboratoryTestCreate(
            patient_id=patient_id,
            test_codes=["CREATININE"],
            priority="routine"
        )
        
        # Первое исследование
        test1 = await lab_service.create_test(test_data, doctor_id)
        result1_data = TestResultCreate(
            test_code="CREATININE",
            test_name="Creatinine",
            category="kidney_function",
            value_numeric=Decimal("1.0"),
            unit="mg/dL"
        )
        await lab_service.add_result(test1.id, result1_data)
        
        # Второе исследование с большим изменением
        test2 = await lab_service.create_test(test_data, doctor_id)
        result2_data = TestResultCreate(
            test_code="CREATININE",
            test_name="Creatinine",
            category="kidney_function",
            value_numeric=Decimal("1.5"),  # +50%
            unit="mg/dL"
        )
        result2 = await lab_service.add_result(test2.id, result2_data)
        
        assert result2.is_delta_check is True
        assert result2.delta_percent == Decimal("50.00")


class TestLabAnalysis:
    """Тесты для анализа лабораторных данных"""
    
    async def test_analyze_patient_labs(
        self, 
        lab_service: LaboratoryService,
        sample_reference_range: ReferenceRange
    ):
        """Тест анализа лабораторных данных пациента"""
        patient_id = uuid4()
        doctor_id = uuid4()
        
        # Создать несколько исследований
        for i in range(3):
            test_data = LaboratoryTestCreate(
                patient_id=patient_id,
                test_codes=["CREATININE"],
                priority="routine"
            )
            test = await lab_service.create_test(test_data, doctor_id)
            
            result_data = TestResultCreate(
                test_code="CREATININE",
                test_name="Creatinine",
                category="kidney_function",
                value_numeric=Decimal(f"{1.0 + i * 0.1}"),
                unit="mg/dL"
            )
            await lab_service.add_result(test.id, result_data)
        
        # Анализ
        from app.laboratory.schemas import LabAnalysisRequest
        request = LabAnalysisRequest(
            patient_id=patient_id,
            include_trends=True
        )
        
        analysis = await lab_service.analyze_patient_labs(request)
        
        assert analysis["patient_id"] == patient_id
        assert analysis["summary"]["total_tests"] == 3
        assert len(analysis["trends"]) > 0


class TestTestPanels:
    """Тесты для панелей тестов"""
    
    async def test_create_panel(self, lab_service: LaboratoryService):
        """Тест создания панели"""
        data = TestPanelCreate(
            code="LIPID_PANEL",
            name="Lipid Panel",
            category="biochemistry",
            test_codes=["CHOLESTEROL", "HDL", "LDL", "TRIGLYCERIDES"]
        )
        
        panel = await lab_service.create_panel(data)
        
        assert panel.code == "LIPID_PANEL"
        assert len(panel.test_codes) == 4
        assert panel.is_active is True
    
    async def test_get_panel_by_code(
        self, 
        lab_service: LaboratoryService,
        sample_panel: TestPanel
    ):
        """Тест получения панели по коду"""
        panel = await lab_service.get_panel_by_code("BASIC_METABOLIC")
        
        assert panel is not None
        assert panel.code == "BASIC_METABOLIC"
        assert "CREATININE" in panel.test_codes


class TestStatistics:
    """Тесты для статистики"""
    
    async def test_get_statistics(
        self, 
        lab_service: LaboratoryService,
        sample_reference_range: ReferenceRange
    ):
        """Тест получения статистики"""
        # Создать тестовые данные
        patient_id = uuid4()
        doctor_id = uuid4()
        
        for _ in range(5):
            test_data = LaboratoryTestCreate(
                patient_id=patient_id,
                test_codes=["CREATININE"],
                priority="routine"
            )
            test = await lab_service.create_test(test_data, doctor_id)
            
            result_data = TestResultCreate(
                test_code="CREATININE",
                test_name="Creatinine",
                category="kidney_function",
                value_numeric=Decimal("1.2"),
                unit="mg/dL"
            )
            await lab_service.add_result(test.id, result_data)
        
        # Получить статистику
        from datetime import datetime
        stats = await lab_service.get_statistics(
            laboratory_id=None,
            date_from=datetime.utcnow().replace(day=1),
            date_to=datetime.utcnow()
        )
        
        assert stats["total_tests"] >= 5
        assert "by_category" in stats
        assert "by_status" in stats