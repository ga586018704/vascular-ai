"""
Security tests for VASCULAR.AI
Tests authentication, authorization, and security features
"""

import pytest
from datetime import timedelta
from jose import jwt
from fastapi.testclient import TestClient
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.security import (
    SecurityManager,
    RBAC,
    AuditLogger,
    InputValidator,
    RateLimitConfig
)
from app.core.config import settings


class TestSecurityManager:
    """Test SecurityManager class"""
    
    def test_password_hashing(self):
        """Test password hashing and verification"""
        password = "SecurePass123!"
        hashed = SecurityManager.get_password_hash(password)
        
        # Verify correct password
        assert SecurityManager.verify_password(password, hashed) is True
        
        # Verify incorrect password
        assert SecurityManager.verify_password("wrongpassword", hashed) is False
    
    def test_password_hash_different_each_time(self):
        """Test that each hash is unique (salt is used)"""
        password = "SecurePass123!"
        hash1 = SecurityManager.get_password_hash(password)
        hash2 = SecurityManager.get_password_hash(password)
        
        assert hash1 != hash2
        assert SecurityManager.verify_password(password, hash1)
        assert SecurityManager.verify_password(password, hash2)
    
    def test_jwt_token_creation(self):
        """Test JWT token creation and verification"""
        data = {"sub": "123", "email": "test@example.com"}
        token = SecurityManager.create_access_token(data)
        
        assert token is not None
        assert isinstance(token, str)
        
        # Verify token
        payload = SecurityManager.verify_token(token)
        assert payload is not None
        assert payload["sub"] == "123"
        assert payload["email"] == "test@example.com"
    
    def test_jwt_token_expiration(self):
        """Test JWT token expiration"""
        data = {"sub": "123"}
        # Create token that expires immediately
        token = SecurityManager.create_access_token(
            data, 
            expires_delta=timedelta(seconds=-1)
        )
        
        # Should return None for expired token
        payload = SecurityManager.verify_token(token)
        assert payload is None
    
    def test_invalid_token(self):
        """Test verification of invalid token"""
        assert SecurityManager.verify_token("invalid.token.here") is None
        assert SecurityManager.verify_token("") is None
    
    def test_phi_encryption(self):
        """Test PHI encryption and decryption"""
        patient_data = "Patient: John Doe, SSN: 123-45-6789"
        
        encrypted = SecurityManager.encrypt_phi(patient_data)
        assert encrypted is not None
        assert isinstance(encrypted, bytes)
        
        decrypted = SecurityManager.decrypt_phi(encrypted)
        assert decrypted == patient_data
    
    def test_phi_encryption_different_each_time(self):
        """Test that PHI encryption uses IV (different output each time)"""
        data = "sensitive data"
        encrypted1 = SecurityManager.encrypt_phi(data)
        encrypted2 = SecurityManager.encrypt_phi(data)
        
        assert encrypted1 != encrypted2
        assert SecurityManager.decrypt_phi(encrypted1) == data
        assert SecurityManager.decrypt_phi(encrypted2) == data
    
    def test_patient_id_hashing(self):
        """Test patient ID hashing"""
        patient_id = "P123456"
        hash1 = SecurityManager.hash_patient_id(patient_id)
        hash2 = SecurityManager.hash_patient_id(patient_id)
        
        # Same input should produce same hash
        assert hash1 == hash2
        assert isinstance(hash1, str)
        assert len(hash1) == 16  # First 16 chars of hex digest
        
        # Different input should produce different hash
        different_hash = SecurityManager.hash_patient_id("P999999")
        assert different_hash != hash1


class TestRBAC:
    """Test Role-Based Access Control"""
    
    def test_role_permissions(self):
        """Test that roles have correct permissions"""
        # Surgeon should have read:study
        assert RBAC.has_permission("surgeon", "read:study") is True
        assert RBAC.has_permission("surgeon", "write:study") is True
        
        # Resident should have read but not admin
        assert RBAC.has_permission("resident", "read:study") is True
        assert RBAC.has_permission("resident", "admin:users") is False
        
        # Admin should have all permissions
        assert RBAC.has_permission("admin", "read:study") is True
        assert RBAC.has_permission("admin", "admin:users") is True
        assert RBAC.has_permission("admin", "write:system") is True
    
    def test_invalid_role(self):
        """Test invalid role handling"""
        assert RBAC.has_permission("invalid_role", "read:study") is False
    
    def test_invalid_permission(self):
        """Test invalid permission handling"""
        assert RBAC.has_permission("surgeon", "invalid:permission") is False
    
    def test_get_role_permissions(self):
        """Test getting all permissions for a role"""
        surgeon_perms = RBAC.get_role_permissions("surgeon")
        assert "read:study" in surgeon_perms
        assert "write:study" in surgeon_perms
        assert "admin:users" not in surgeon_perms


class TestInputValidator:
    """Test InputValidator class"""
    
    def test_valid_email(self):
        """Test valid email validation"""
        assert InputValidator.validate_email("user@example.com") is True
        assert InputValidator.validate_email("user.name@hospital.org") is True
        assert InputValidator.validate_email("user+tag@domain.co.uk") is True
    
    def test_invalid_email(self):
        """Test invalid email validation"""
        assert InputValidator.validate_email("invalid") is False
        assert InputValidator.validate_email("@example.com") is False
        assert InputValidator.validate_email("user@") is False
        assert InputValidator.validate_email("") is False
    
    def test_valid_study_id(self):
        """Test valid study ID validation"""
        assert InputValidator.validate_study_id("STUDY_12345") is True
        assert InputValidator.validate_study_id("study-abc-123") is True
    
    def test_invalid_study_id(self):
        """Test invalid study ID validation"""
        assert InputValidator.validate_study_id("") is False
        assert InputValidator.validate_study_id("study<id>") is False
        assert InputValidator.validate_study_id("study;drop") is False
    
    def test_valid_mrn(self):
        """Test valid MRN validation"""
        assert InputValidator.validate_mrn("12345678") is True
        assert InputValidator.validate_mrn("MRN-12345") is True
    
    def test_invalid_mrn(self):
        """Test invalid MRN validation"""
        assert InputValidator.validate_mrn("") is False
        assert InputValidator.validate_mrn("mrn<script>") is False
    
    def test_sanitize_filename(self):
        """Test filename sanitization"""
        assert InputValidator.sanitize_filename("../etc/passwd") == "etcpasswd"
        assert InputValidator.sanitize_filename("file.dcm") == "file.dcm"
        assert InputValidator.sanitize_filename("path/to/file.nii") == "pathtofile.nii"
    
    def test_sanitize_string(self):
        """Test string sanitization"""
        assert InputValidator.sanitize_string("<script>alert('xss')</script>") == "scriptalert('xss')/script"
        assert InputValidator.sanitize_string("normal text") == "normal text"


class TestRateLimitConfig:
    """Test Rate Limit Configuration"""
    
    def test_rate_limits_defined(self):
        """Test that rate limits are defined"""
        assert "auth" in RateLimitConfig.LIMITS
        assert "dicom_upload" in RateLimitConfig.LIMITS
        assert "api_general" in RateLimitConfig.LIMITS
    
    def test_rate_limit_format(self):
        """Test rate limit format"""
        for key, limit in RateLimitConfig.LIMITS.items():
            parts = limit.split("/")
            assert len(parts) == 2
            assert parts[0].isdigit()
            assert parts[1] in ["second", "minute", "hour", "day"]


class TestAuditLogger:
    """Test AuditLogger class"""
    
    def test_log_authentication(self, caplog):
        """Test authentication logging"""
        import logging
        
        with caplog.at_level(logging.INFO):
            AuditLogger.log_authentication(
                user_id="123",
                success=True,
                ip_address="127.0.0.1",
                user_agent="test"
            )
        
        assert "AUTHENTICATION" in caplog.text
        assert "user_id" in caplog.text
    
    def test_log_dicom_access(self, caplog):
        """Test DICOM access logging"""
        import logging
        
        with caplog.at_level(logging.INFO):
            AuditLogger.log_dicom_access(
                user_id="123",
                study_id="study_456",
                action="view",
                ip_address="127.0.0.1"
            )
        
        assert "DICOM_ACCESS" in caplog.text
        assert "study_456" in caplog.text
    
    def test_log_data_modification(self, caplog):
        """Test data modification logging"""
        import logging
        
        with caplog.at_level(logging.INFO):
            AuditLogger.log_data_modification(
                user_id="123",
                table="studies",
                record_id="456",
                action="update",
                changes={"status": "processed"},
                ip_address="127.0.0.1"
            )
        
        assert "DATA_MODIFICATION" in caplog.text
        assert "studies" in caplog.text


@pytest.mark.asyncio
class TestAPIAuthentication:
    """Test API endpoint authentication"""
    
    async def test_protected_endpoint_without_token(self, client: TestClient):
        """Test accessing protected endpoint without token"""
        response = client.get("/api/dicom/studies")
        assert response.status_code == 401
    
    async def test_protected_endpoint_with_invalid_token(self, client: TestClient):
        """Test accessing protected endpoint with invalid token"""
        response = client.get(
            "/api/dicom/studies",
            headers={"Authorization": "Bearer invalid_token"}
        )
        assert response.status_code == 401
    
    async def test_login_with_valid_credentials(self, client: TestClient):
        """Test login with valid credentials"""
        # First register a user
        client.post(
            "/api/auth/register",
            data={
                "email": "test@example.com",
                "password": "SecurePass123!",
                "full_name": "Test User"
            }
        )
        
        # Then login
        response = client.post(
            "/api/auth/login",
            data={
                "username": "test@example.com",
                "password": "SecurePass123!"
            }
        )
        
        assert response.status_code == 200
        data = response.json()
        assert "access_token" in data
        assert "token_type" in data
        assert data["token_type"] == "bearer"
    
    async def test_login_with_invalid_credentials(self, client: TestClient):
        """Test login with invalid credentials"""
        response = client.post(
            "/api/auth/login",
            data={
                "username": "nonexistent@example.com",
                "password": "wrongpassword"
            }
        )
        
        assert response.status_code == 401


class TestSecurityHeaders:
    """Test security headers in responses"""
    
    def test_security_headers_present(self, client: TestClient):
        """Test that security headers are present"""
        response = client.get("/health")
        
        assert "X-Content-Type-Options" in response.headers
        assert response.headers["X-Content-Type-Options"] == "nosniff"
        
        assert "X-Frame-Options" in response.headers
        assert response.headers["X-Frame-Options"] == "DENY"
        
        assert "Strict-Transport-Security" in response.headers


class TestPHIProtection:
    """Test PHI (Protected Health Information) protection"""
    
    def test_phi_not_in_logs(self, caplog):
        """Test that PHI is not logged in plain text"""
        import logging
        
        sensitive_data = "Patient SSN: 123-45-6789"
        encrypted = SecurityManager.encrypt_phi(sensitive_data)
        
        # Log should not contain plain text SSN
        with caplog.at_level(logging.INFO):
            logging.info(f"Processing patient data: {encrypted}")
        
        assert "123-45-6789" not in caplog.text
