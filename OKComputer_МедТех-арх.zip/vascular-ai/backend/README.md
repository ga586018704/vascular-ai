# VASCULAR.AI Backend

FastAPI-based backend for VASCULAR.AI - AI-powered vascular surgery planning platform.

## Features

- **Authentication**: JWT-based auth with role-based access control (RBAC)
- **DICOM Processing**: Upload, store, and process medical imaging studies
- **AI Segmentation**: Integration with AI service for vessel segmentation
- **Risk Calculators**: VSGNE, GAS, Stroke risk assessment
- **Clinical Guidelines**: ESVS, SVS, ACC/AHA guidelines integration
- **AI Agents**: Specialized medical agents for vascular surgery, phlebology, neurointervention
- **Voice-to-Text**: Medical dictation support
- **HIPAA Compliance**: Audit logging, PHI encryption, security headers

## Quick Start

### 1. Install Dependencies

```bash
cd backend
pip install -r requirements.txt
```

### 2. Configure Environment

```bash
# Copy example config
cp .env.example .env

# Edit .env with your settings
# IMPORTANT: Change SECRET_KEY and ENCRYPTION_KEY!
```

### 3. Run the Server

```bash
# Development mode with auto-reload
uvicorn app.main:app --reload --host 0.0.0.0 --port 8000

# Or using Python directly
python -m app.main
```

### 4. Access API Documentation

- **Swagger UI**: http://localhost:8000/docs
- **ReDoc**: http://localhost:8000/redoc
- **Health Check**: http://localhost:8000/health

## Project Structure

```
backend/
├── app/
│   ├── api/              # API endpoints
│   │   ├── auth.py       # Authentication
│   │   ├── dicom.py      # DICOM operations
│   │   ├── agents.py     # AI Agents
│   │   └── ...
│   ├── core/             # Core functionality
│   │   ├── config.py     # Configuration
│   │   ├── security.py   # Security utilities
│   │   ├── logging.py    # Logging setup
│   │   └── middleware.py # Custom middleware
│   ├── models/           # Database models
│   ├── services/         # Business logic
│   └── agents/           # AI Agents system
├── data/                 # Data storage (created automatically)
├── logs/                 # Log files (created automatically)
├── requirements.txt      # Python dependencies
└── .env                  # Environment variables
```

## Environment Variables

| Variable | Description | Default |
|----------|-------------|---------|
| `ENVIRONMENT` | Environment mode | `development` |
| `DEBUG` | Debug mode | `true` |
| `DATABASE_URL` | Database connection string | `sqlite+aiosqlite:///./data/vascular_ai.db` |
| `SECRET_KEY` | JWT secret key (min 32 chars) | Required |
| `ENCRYPTION_KEY` | PHI encryption key | Required |
| `ALLOWED_ORIGINS` | CORS allowed origins | `http://localhost:3000,http://localhost:5173` |
| `AI_SERVICE_URL` | AI service URL | `http://localhost:8001` |

## API Endpoints

### Authentication
- `POST /api/auth/register` - Register new user
- `POST /api/auth/login` - Login and get token
- `GET /api/auth/me` - Get current user info

### DICOM
- `POST /api/dicom/upload` - Upload DICOM files
- `GET /api/dicom/studies` - List studies
- `GET /api/dicom/studies/{id}` - Get study details

### Segmentation
- `POST /api/segmentation/start/{study_id}` - Start segmentation
- `GET /api/segmentation/status/{id}` - Check status

### AI Agents
- `GET /api/agents/available` - List available agents
- `POST /api/agents/analyze` - Run agent analysis

### Surgeon Tools
- `POST /api/surgeon-tools/risk-calculator/vsgne` - VSGNE risk score
- `POST /api/surgeon-tools/risk-calculator/gas` - GAS risk score

## Testing

```bash
# Run tests
pytest tests/ -v

# Run with coverage
pytest tests/ --cov=app --cov-report=html

# Security scan
bandit -r app/
safety check -r requirements.txt
```

## Security

- JWT authentication with refresh tokens
- Role-based access control (RBAC)
- PHI encryption with Fernet (AES-128)
- HIPAA-compliant audit logging
- Rate limiting
- Security headers (CSP, HSTS, etc.)

## License

Medical Device Software - Requires FDA/CE marking for clinical use.
