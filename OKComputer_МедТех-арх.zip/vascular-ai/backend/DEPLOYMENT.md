# VASCULAR.AI - Руководство по развертыванию

## Быстрый старт

### Локальная разработка

```bash
cd backend

# Создать виртуальное окружение
python -m venv venv
source venv/bin/activate  # Linux/Mac
# или: venv\Scripts\activate  # Windows

# Установить зависимости
pip install -r requirements.txt

# Создать .env файл
cat > .env << EOF
SECRET_KEY=$(python -c "import secrets; print(secrets.token_urlsafe(32))")
ENCRYPTION_KEY=$(python -c "from cryptography.fernet import Fernet; print(Fernet.generate_key().decode())")
ENVIRONMENT=development
DEBUG=true
DATABASE_URL=sqlite+aiosqlite:///./vascular.db
UPLOAD_DIR=./uploads
PROCESSED_DIR=./processed
EOF

# Запустить
cd app
python main.py
```

### Проверка работоспособности

```bash
# Health check
curl http://localhost:8000/health

# Регистрация пользователя
curl -X POST "http://localhost:8000/api/auth/register" \
  -H "Content-Type: application/x-www-form-urlencoded" \
  -d "email=surgeon@hospital.com" \
  -d "password=SecurePass123!" \
  -d "full_name=Dr. Smith"

# Логин
curl -X POST "http://localhost:8000/api/auth/login" \
  -H "Content-Type: application/x-www-form-urlencoded" \
  -d "username=surgeon@hospital.com" \
  -d "password=SecurePass123!"
```

---

## Production Deployment

### Требования

- Python 3.9+
- PostgreSQL 13+ (рекомендуется)
- Redis (опционально, для кеширования)
- Nginx (reverse proxy)
- SSL certificate

### Шаг 1: Подготовка сервера

```bash
# Обновление системы
sudo apt update && sudo apt upgrade -y

# Установка зависимостей
sudo apt install -y python3-pip python3-venv postgresql nginx

# Создание пользователя
sudo useradd -m -s /bin/bash vascular
sudo usermod -aG sudo vascular
```

### Шаг 2: Настройка PostgreSQL

```bash
# Установка PostgreSQL
sudo apt install -y postgresql postgresql-contrib

# Создание базы данных и пользователя
sudo -u postgres psql << EOF
CREATE DATABASE vascular;
CREATE USER vascular WITH ENCRYPTED PASSWORD 'strong_password_here';
GRANT ALL PRIVILEGES ON DATABASE vascular TO vascular;
EOF

# Проверка подключения
psql -h localhost -U vascular -d vascular -c "SELECT 1;"
```

### Шаг 3: Развертывание приложения

```bash
# Клонирование репозитория
cd /opt
sudo git clone <repository-url> vascular-ai
sudo chown -R vascular:vascular vascular-ai

# Настройка виртуального окружения
cd vascular-ai/backend
sudo -u vascular python3 -m venv venv
sudo -u vascular venv/bin/pip install -r requirements.txt

# Дополнительные зависимости для PostgreSQL
sudo -u vascular venv/bin/pip install asyncpg
```

### Шаг 4: Конфигурация

```bash
# Создание production .env
sudo -u vascular tee /opt/vascular-ai/backend/.env << 'EOF'
# Security (ОБЯЗАТЕЛЬНО сгенерировать новые ключи!)
SECRET_KEY=<generate-32-char-secret>
ENCRYPTION_KEY=<generate-fernet-key>

# Application
ENVIRONMENT=production
DEBUG=false
APP_NAME=VASCULAR.AI
APP_VERSION=5.1.0

# Database
DATABASE_URL=postgresql+asyncpg://vascular:strong_password@localhost/vascular

# File Storage
UPLOAD_DIR=/var/lib/vascular/uploads
PROCESSED_DIR=/var/lib/vascular/processed
MAX_FILE_SIZE=52428800

# Security
ACCESS_TOKEN_EXPIRE_MINUTES=30
REFRESH_TOKEN_EXPIRE_DAYS=7
ALGORITHM=HS256

# CORS (указать production домены)
CORS_ORIGINS=["https://vascular.yourdomain.com"]
EOF

# Создание директорий
sudo mkdir -p /var/lib/vascular/uploads /var/lib/vascular/processed
sudo chown -R vascular:vascular /var/lib/vascular
```

### Шаг 5: Systemd сервис

```bash
sudo tee /etc/systemd/system/vascular-ai.service << 'EOF'
[Unit]
Description=VASCULAR.AI API
After=network.target postgresql.service

[Service]
Type=simple
User=vascular
Group=vascular
WorkingDirectory=/opt/vascular-ai/backend/app
Environment=PYTHONPATH=/opt/vascular-ai/backend
EnvironmentFile=/opt/vascular-ai/backend/.env
ExecStart=/opt/vascular-ai/backend/venv/bin/uvicorn main:app --host 127.0.0.1 --port 8000 --workers 4
Restart=always
RestartSec=5

[Install]
WantedBy=multi-user.target
EOF

sudo systemctl daemon-reload
sudo systemctl enable vascular-ai
sudo systemctl start vascular-ai
```

### Шаг 6: Nginx конфигурация

```bash
# Установка SSL сертификата (Let's Encrypt)
sudo apt install -y certbot python3-certbot-nginx
sudo certbot --nginx -d vascular.yourdomain.com

# Nginx конфигурация
sudo tee /etc/nginx/sites-available/vascular-ai << 'EOF'
upstream vascular_backend {
    server 127.0.0.1:8000;
    keepalive 64;
}

server {
    listen 80;
    server_name vascular.yourdomain.com;
    return 301 https://$server_name$request_uri;
}

server {
    listen 443 ssl http2;
    server_name vascular.yourdomain.com;

    ssl_certificate /etc/letsencrypt/live/vascular.yourdomain.com/fullchain.pem;
    ssl_certificate_key /etc/letsencrypt/live/vascular.yourdomain.com/privkey.pem;

    # Security headers
    add_header X-Frame-Options "SAMEORIGIN" always;
    add_header X-Content-Type-Options "nosniff" always;
    add_header X-XSS-Protection "1; mode=block" always;
    add_header Referrer-Policy "strict-origin-when-cross-origin" always;

    # Client max body size (50MB for DICOM uploads)
    client_max_body_size 50M;

    location / {
        proxy_pass http://vascular_backend;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
        proxy_cache_bypass $http_upgrade;
        proxy_read_timeout 300s;
        proxy_connect_timeout 75s;
    }

    # Static files
    location /processed {
        alias /var/lib/vascular/processed;
        expires 1d;
        add_header Cache-Control "public, immutable";
    }
}
EOF

sudo ln -sf /etc/nginx/sites-available/vascular-ai /etc/nginx/sites-enabled/
sudo nginx -t
sudo systemctl reload nginx
```

### Шаг 7: Мониторинг

```bash
# Установка monitoring tools
sudo apt install -y htop iotop

# Логирование
sudo mkdir -p /var/log/vascular
sudo chown vascular:vascular /var/log/vascular

# Log rotation
sudo tee /etc/logrotate.d/vascular-ai << 'EOF'
/var/log/vascular/*.log {
    daily
    rotate 30
    compress
    delaycompress
    missingok
    notifempty
    create 0644 vascular vascular
}
EOF
```

---

## Docker Deployment

### Dockerfile

```dockerfile
FROM python:3.11-slim

WORKDIR /app

# Install system dependencies
RUN apt-get update && apt-get install -y \
    gcc \
    libpq-dev \
    && rm -rf /var/lib/apt/lists/*

# Install Python dependencies
COPY requirements.txt .
RUN pip install --no-cache-dir -r requirements.txt

# Copy application
COPY app/ ./app/
COPY .env .

# Create upload directories
RUN mkdir -p /app/uploads /app/processed

# Run as non-root user
RUN useradd -m -u 1000 vascular
RUN chown -R vascular:vascular /app
USER vascular

EXPOSE 8000

CMD ["uvicorn", "app.main:app", "--host", "0.0.0.0", "--port", "8000"]
```

### Docker Compose

```yaml
version: '3.8'

services:
  api:
    build: .
    ports:
      - "8000:8000"
    environment:
      - DATABASE_URL=postgresql+asyncpg://vascular:password@db:5432/vascular
    volumes:
      - uploads:/app/uploads
      - processed:/app/processed
    depends_on:
      - db
      - redis
    restart: unless-stopped

  db:
    image: postgres:15-alpine
    environment:
      - POSTGRES_USER=vascular
      - POSTGRES_PASSWORD=password
      - POSTGRES_DB=vascular
    volumes:
      - postgres_data:/var/lib/postgresql/data
    restart: unless-stopped

  redis:
    image: redis:7-alpine
    restart: unless-stopped

  nginx:
    image: nginx:alpine
    ports:
      - "80:80"
      - "443:443"
    volumes:
      - ./nginx.conf:/etc/nginx/nginx.conf
      - ./ssl:/etc/nginx/ssl
    depends_on:
      - api
    restart: unless-stopped

volumes:
  postgres_data:
  uploads:
  processed:
```

---

## Проверка развертывания

### Health Checks

```bash
# API health
curl https://vascular.yourdomain.com/health

# Authentication
curl -X POST https://vascular.yourdomain.com/api/auth/login \
  -d "username=test@example.com" \
  -d "password=testpass"

# Protected endpoint (with token)
curl https://vascular.yourdomain.com/api/auth/me \
  -H "Authorization: Bearer <token>"
```

### Логи

```bash
# Application logs
sudo journalctl -u vascular-ai -f

# Nginx logs
sudo tail -f /var/log/nginx/access.log
sudo tail -f /var/log/nginx/error.log

# Database logs
sudo tail -f /var/log/postgresql/postgresql-*.log
```

---

## Backup Strategy

### Database Backup

```bash
#!/bin/bash
# /opt/vascular-ai/scripts/backup.sh

BACKUP_DIR="/var/backups/vascular"
DATE=$(date +%Y%m%d_%H%M%S)

# PostgreSQL backup
sudo -u postgres pg_dump vascular > "$BACKUP_DIR/vascular_$DATE.sql"

# Uploads backup
tar -czf "$BACKUP_DIR/uploads_$DATE.tar.gz" /var/lib/vascular/uploads

# Keep only last 30 days
find $BACKUP_DIR -name "*.sql" -mtime +30 -delete
find $BACKUP_DIR -name "*.tar.gz" -mtime +30 -delete
```

### Cron

```bash
# Daily backup at 2 AM
0 2 * * * /opt/vascular-ai/scripts/backup.sh
```

---

## Troubleshooting

### Проблема: Приложение не запускается

```bash
# Проверка логов
sudo journalctl -u vascular-ai -n 100

# Проверка конфигурации
cd /opt/vascular-ai/backend
sudo -u vascular venv/bin/python -c "from app.core.config import settings; print(settings)"
```

### Проблема: Ошибки базы данных

```bash
# Проверка подключения
sudo -u vascular venv/bin/python -c "
import asyncio
from app.models.database import init_db
asyncio.run(init_db())
print('Database OK')
"
```

### Проблема: 502 Bad Gateway

```bash
# Проверка API
sudo systemctl status vascular-ai
curl http://127.0.0.1:8000/health

# Проверка Nginx
sudo nginx -t
sudo systemctl status nginx
```

---

## Обновление

```bash
# Остановка сервиса
sudo systemctl stop vascular-ai

# Обновление кода
cd /opt/vascular-ai
sudo -u vascular git pull

# Обновление зависимостей
cd backend
sudo -u vascular venv/bin/pip install -r requirements.txt

# Миграция базы данных (если нужно)
sudo -u vascular venv/bin/alembic upgrade head

# Перезапуск
sudo systemctl start vascular-ai

# Проверка
sudo systemctl status vascular-ai
curl http://localhost:8000/health
```

---

## Контакты поддержки

- Technical Support: support@vascular.ai
- Security Issues: security@vascular.ai
- Emergency: +1-800-VASCULAR
