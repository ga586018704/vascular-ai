"""
API endpoints для инструментов хирурга
Калькуляторы риска, протоколы, алгоритмы
"""

from typing import Optional, List
from fastapi import APIRouter, HTTPException, Depends, Body
from pydantic import BaseModel
from sqlalchemy.ext.asyncio import AsyncSession

from app.services.surgeon_tools import (
    VSGNECalculator,
    GASCalculator,
    StrokeRiskCalculator,
    MajorAmputationRiskCalculator,
    get_anticoagulation_protocol,
    check_laboratory_readiness,
    get_risk_calculator,
    get_complication_algorithm,
    get_urgency_criteria,
    get_postoperative_protocol,
    COMPLICATION_ALGORITHMS,
    URGENCY_CRITERIA,
    POSTOPERATIVE_PROTOCOLS,
    LABORATORY_THRESHOLDS
)
from app.api.auth import get_current_active_user, get_current_user, require_permission
from app.models.database import User
from app.core.security import AuditLogger

router = APIRouter(prefix="/api/surgeon-tools", tags=["Surgeon Tools"])


# ==================== КАЛЬКУЛЯТОРЫ РИСКА ====================

class VSGNERequest(BaseModel):
    age: int
    gender: str
    creatinine: float
    cad: bool = False
    chf: bool = False
    copd: bool = False
    urgency: str = "elective"  # elective, urgent, emergent


@router.post("/risk-calculator/vsgne")
async def calculate_vsgne_risk(
    request: VSGNERequest,
    procedure_type: str = "open",  # open, evar
    current_user: User = Depends(require_permission("read:calculator")),
    http_request = None
):
    """
    VSGNE Risk Calculator - предсказание смертности при операциях на ААА
    
    Используется для оценки риска перед операцией на аневризме брюшной аорты
    """
    from fastapi import Request
    
    calculator = VSGNECalculator()
    
    patient_data = {
        "age": request.age,
        "gender": request.gender,
        "creatinine": request.creatinine,
        "cad": request.cad,
        "chf": request.chf,
        "copd": request.copd,
        "urgency": request.urgency
    }
    
    result = calculator.calculate(patient_data, procedure_type)
    
    return {
        "success": True,
        "calculator": "VSGNE",
        "procedure_type": procedure_type,
        "result": result
    }


class GASRequest(BaseModel):
    age: int
    systolic_bp: float
    loss_of_consciousness: bool = False
    hemoglobin: float
    creatinine: float
    ischemia_time: int = 0  # минуты


@router.post("/risk-calculator/gas")
async def calculate_gas_risk(
    request: GASRequest,
    current_user: User = Depends(require_permission("read:calculator"))
):
    """
    Global Aneurysm Score (GAS) - для рваных ААА
    
    Предсказание смертности при экстренных операциях на рваных аневризмах
    """
    calculator = GASCalculator()
    
    patient_data = {
        "age": request.age,
        "systolic_bp": request.systolic_bp,
        "loss_of_consciousness": request.loss_of_consciousness,
        "hemoglobin": request.hemoglobin,
        "creatinine": request.creatinine,
        "ischemia_time": request.ischemia_time
    }
    
    result = calculator.calculate(patient_data)
    
    return {
        "success": True,
        "calculator": "GAS",
        "result": result
    }


class StrokeRiskRequest(BaseModel):
    age: int
    gender: str
    symptomatic: bool = False
    cad: bool = False
    diabetes: bool = False
    renal_failure: bool = False
    contralateral_occlusion: bool = False


@router.post("/risk-calculator/stroke-cea")
async def calculate_stroke_risk(
    request: StrokeRiskRequest,
    current_user: User = Depends(require_permission("read:calculator"))
):
    """
    Калькулятор риска инсульта/смерти при каротидной эндартерэктомии
    """
    calculator = StrokeRiskCalculator()
    
    patient_data = {
        "age": request.age,
        "gender": request.gender,
        "symptomatic": request.symptomatic,
        "cad": request.cad,
        "diabetes": request.diabetes,
        "renal_failure": request.renal_failure,
        "contralateral_occlusion": request.contralateral_occlusion
    }
    
    result = calculator.calculate(patient_data)
    
    return {
        "success": True,
        "calculator": "Stroke Risk (CEA)",
        "result": result
    }


class AmputationRiskRequest(BaseModel):
    rutherford_class: int = 4
    anemia: bool = False
    hypoalbuminemia: bool = False
    infection: bool = False
    unreconstructible: bool = False
    diabetes: bool = False
    dialysis: bool = False


@router.post("/risk-calculator/amputation")
async def calculate_amputation_risk(
    request: AmputationRiskRequest,
    current_user: User = Depends(require_permission("read:calculator"))
):
    """
    Калькулятор риска мажорной ампутации при критической ишемии
    """
    calculator = MajorAmputationRiskCalculator()
    
    patient_data = {
        "rutherford_class": request.rutherford_class,
        "anemia": request.anemia,
        "hypoalbuminemia": request.hypoalbuminemia,
        "infection": request.infection,
        "unreconstructible": request.unreconstructible,
        "diabetes": request.diabetes,
        "dialysis": request.dialysis
    }
    
    result = calculator.calculate(patient_data)
    
    return {
        "success": True,
        "calculator": "Amputation Risk",
        "result": result
    }


@router.get("/risk-calculators")
async def list_risk_calculators(user=Depends(get_current_user)):
    """Список доступных калькуляторов риска"""
    
    return {
        "calculators": [
            {
                "id": "vsgne",
                "name": "VSGNE Risk Score",
                "description": "Предсказание смертности при операциях на ААА",
                "indications": ["Плановая операция на ААА", "Выбор между open и EVAR"],
                "parameters": ["Возраст", "Пол", "Креатинин", "ИБС", "ХСН", "ХОБЛ", "Срочность"]
            },
            {
                "id": "gas",
                "name": "Global Aneurysm Score (GAS)",
                "description": "Для рваных аневризм аорты",
                "indications": ["Экстренная операция на рваной ААА"],
                "parameters": ["Возраст", "АД", "Потеря сознания", "Гемоглобин", "Креатинин", "Время ишемии"]
            },
            {
                "id": "stroke-cea",
                "name": "Stroke Risk (CEA)",
                "description": "Риск инсульта при каротидной эндартерэктомии",
                "indications": ["Планирование КЭА", "Выбор между CEA и CAS"],
                "parameters": ["Возраст", "Пол", "Симптоматичность", "ИБС", "Диабет", "ХПН", "Окклюзия противоположной ОСА"]
            },
            {
                "id": "amputation",
                "name": "Major Amputation Risk",
                "description": "Риск ампутации при критической ишемии",
                "indications": ["Критическая ишемия", "Планирование реваскуляризации"],
                "parameters": ["Rutherford класс", "Анемия", "Гипоальбуминемия", "Инфекция", "Невозможность реваскуляризации", "Диабет", "Диализ"]
            }
        ]
    }


# ==================== УПРАВЛЕНИЕ АНТИКОАГУЛЯНТАМИ ====================

class AnticoagulationRequest(BaseModel):
    agent: str  # варфарин, дабигатран, ривароксабан, апиксабан, аспирин, клопидогрель
    procedure_bleeding_risk: str = "moderate"  # low, moderate, high
    creatinine_clearance: Optional[float] = None
    urgency: str = "elective"  # elective, urgent, emergency
    current_inr: Optional[float] = None


@router.post("/anticoagulation/protocol")
async def get_anticoagulation_management(
    request: AnticoagulationRequest,
    current_user: User = Depends(require_permission("read:calculator"))
):
    """
    Получение протокола управления антикоагулянтами
    
    Возвращает рекомендации по отмене и возобновлению антикоагулянтов
    """
    protocol = get_anticoagulation_protocol(
        agent=request.agent,
        procedure_bleeding_risk=request.procedure_bleeding_risk,
        creatinine_clearance=request.creatinine_clearance,
        urgency=request.urgency
    )
    
    return {
        "success": True,
        "agent": request.agent,
        "protocol": protocol
    }


@router.get("/anticoagulation/agents")
async def list_anticoagulation_agents(user=Depends(get_current_user)):
    """Список антикоагулянтов и антиагрегантов"""
    
    return {
        "agents": {
            "anticoagulants": [
                {"id": "warfarin", "name": "Варфарин", "type": "Витамин К антагонист"},
                {"id": "dabigatran", "name": "Дабигатран (Прадакса)", "type": "Прямой тромбиновый ингибитор"},
                {"id": "rivaroxaban", "name": "Ривароксабан (Ксарелто)", "type": "Ингибитор фактора Xa"},
                {"id": "apixaban", "name": "Апиксабан (Элиquis)", "type": "Ингибитор фактора Xa"},
                {"id": "edoxaban", "name": "Эдоксабан (Ликвиус)", "type": "Ингибитор фактора Xa"}
            ],
            "antiplatelet": [
                {"id": "aspirin", "name": "Аспирин", "type": "Необратимый ингибитор COX"},
                {"id": "clopidogrel", "name": "Клопидогрель (Плавикс)", "type": "Блокатор P2Y12"},
                {"id": "ticagrelor", "name": "Тикагрелор (Брилинта)", "type": "Блокатор P2Y12"}
            ]
        }
    }


# ==================== ОСЛОЖНЕНИЯ ====================

@router.get("/complications")
async def list_complications(user=Depends(get_current_user)):
    """Список осложнений с алгоритмами управления"""
    
    return {
        "complications": [
            {
                "id": "endoleak",
                "name": "Endoleak после EVAR",
                "types": ["Type I", "Type II", "Type III", "Type IV", "Type V"],
                "severity": "variable"
            },
            {
                "id": "graft_thrombosis",
                "name": "Тромбоз шунта/протеза",
                "types": ["Острый", "Хронический"],
                "severity": "high"
            },
            {
                "id": "graft_infection",
                "name": "Инфекция протеза",
                "severity": "extreme"
            },
            {
                "id": "lymphatic_fistula",
                "name": "Лимфная фистула",
                "severity": "moderate"
            },
            {
                "id": "compartment_syndrome",
                "name": "Синдром компартмент-синдрома",
                "severity": "extreme"
            }
        ]
    }


@router.get("/complications/{complication_type}")
async def get_complication_management(
    complication_type: str,
    current_user: User = Depends(require_permission("read:calculator"))
):
    """
    Получение алгоритма действий при осложнении
    
    complication_type: endoleak, graft_thrombosis, graft_infection, lymphatic_fistula, compartment_syndrome
    """
    algorithm = get_complication_algorithm(complication_type)
    
    if not algorithm:
        raise HTTPException(
            status_code=404,
            detail=f"Complication type not found. Available: {', '.join(COMPLICATION_ALGORITHMS.keys())}"
        )
    
    return {
        "success": True,
        "complication": complication_type,
        "algorithm": algorithm
    }


# ==================== СРОЧНОСТЬ ====================

@router.get("/urgency")
async def get_urgency_criteria_all(user=Depends(get_current_user)):
    """Критерии срочности операций"""
    
    return {
        "urgency_levels": URGENCY_CRITERIA
    }


@router.get("/urgency/{level}")
async def get_urgency_level(
    level: str,  # emergency, urgent, elective
    current_user: User = Depends(require_permission("read:calculator"))
):
    """Критерии конкретного уровня срочности"""
    
    criteria = get_urgency_criteria(level)
    
    if not criteria:
        raise HTTPException(
            status_code=404,
            detail=f"Urgency level not found. Available: {', '.join(URGENCY_CRITERIA.keys())}"
        )
    
    return {
        "success": True,
        "level": level,
        "criteria": criteria
    }


# ==================== ЛАБОРАТОРНЫЕ ====================

class LaboratoryCheckRequest(BaseModel):
    hemoglobin: float
    platelets: float
    inr: float
    creatinine: float
    glucose: float
    urgency: str = "elective"


@router.post("/laboratory/check-readiness")
async def check_laboratory(
    request: LaboratoryCheckRequest,
    current_user: User = Depends(require_permission("read:calculator"))
):
    """
    Проверка готовности к операции на основе лабораторных данных
    
    Возвращает предупреждения и противопоказания
    """
    labs = {
        "hemoglobin": request.hemoglobin,
        "platelets": request.platelets,
        "inr": request.inr,
        "creatinine": request.creatinine,
        "glucose": request.glucose
    }
    
    result = check_laboratory_readiness(labs, request.urgency)
    
    return {
        "success": True,
        "result": result
    }


@router.get("/laboratory/thresholds")
async def get_laboratory_thresholds(user=Depends(get_current_user)):
    """Лабораторные пороговые значения"""
    
    return {
        "thresholds": LABORATORY_THRESHOLDS
    }


# ==================== ПОСЛЕОПЕРАТИВНЫЕ ПРОТОКОЛЫ ====================

@router.get("/postoperative-protocols")
async def list_postoperative_protocols(user=Depends(get_current_user)):
    """Список послеоперационных протоколов"""
    
    return {
        "protocols": [
            {"id": "evar_surveillance", "name": "Наблюдение после EVAR"},
            {"id": "open_aaa_surveillance", "name": "Наблюдение после открытой операции на ААА"},
            {"id": "carotid_surveillance", "name": "Наблюдение после КЭА"},
            {"id": "bypass_surveillance", "name": "Наблюдение после шунтирования"},
            {"id": "drain_management", "name": "Управление дренажами"},
            {"id": "anticoagulation_postop", "name": "Антикоагуляция после операции"}
        ]
    }


@router.get("/postoperative-protocols/{protocol_type}")
async def get_postoperative_protocol_detail(
    protocol_type: str,
    current_user: User = Depends(require_permission("read:calculator"))
):
    """Детальный послеоперационный протокол"""
    
    protocol = get_postoperative_protocol(protocol_type)
    
    if not protocol:
        raise HTTPException(
            status_code=404,
            detail=f"Protocol not found. Available: {', '.join(POSTOPERATIVE_PROTOCOLS.keys())}"
        )
    
    return {
        "success": True,
        "protocol_type": protocol_type,
        "protocol": protocol
    }


# ==================== ИНТЕГРИРОВАННЫЙ РАСЧЕТ ====================

class ComprehensiveRiskRequest(BaseModel):
    # Основные параметры
    age: int
    gender: str
    procedure_type: str  # aaa_open, aaa_evar, carotid_cea, femoropopliteal_bypass
    
    # Лаборатория
    creatinine: float
    hemoglobin: float
    
    # Сопутствующие заболевания
    cad: bool = False
    chf: bool = False
    copd: bool = False
    diabetes: bool = False
    
    # Срочность
    urgency: str = "elective"
    
    # Для GAS (если рваная ААА)
    systolic_bp: Optional[float] = None
    loss_of_consciousness: Optional[bool] = None
    ischemia_time: Optional[int] = None
    
    # Для КЭА
    symptomatic: Optional[bool] = None
    contralateral_occlusion: Optional[bool] = None


@router.post("/comprehensive-risk-assessment")
async def comprehensive_risk_assessment(
    request: ComprehensiveRiskRequest,
    current_user: User = Depends(require_permission("read:calculator"))
):
    """
    Комплексная оценка риска
    
    Выполняет все подходящие калькуляторы риска для данного типа операции
    """
    results = {
        "procedure_type": request.procedure_type,
        "patient_summary": {
            "age": request.age,
            "gender": request.gender,
            "urgency": request.urgency
        },
        "risk_assessments": {}
    }
    
    # VSGNE для всех операций на ААА
    if "aaa" in request.procedure_type:
        vsgne_calc = VSGNECalculator()
        vsgne_data = {
            "age": request.age,
            "gender": request.gender,
            "creatinine": request.creatinine,
            "cad": request.cad,
            "chf": request.chf,
            "copd": request.copd,
            "urgency": request.urgency
        }
        results["risk_assessments"]["vsgne"] = vsgne_calc.calculate(vsgne_data, "open" if "open" in request.procedure_type else "evar")
    
    # GAS для рваных ААА
    if request.urgency == "emergency" and "aaa" in request.procedure_type:
        if all(v is not None for v in [request.systolic_bp, request.loss_of_consciousness, request.ischemia_time]):
            gas_calc = GASCalculator()
            gas_data = {
                "age": request.age,
                "systolic_bp": request.systolic_bp,
                "loss_of_consciousness": request.loss_of_consciousness,
                "hemoglobin": request.hemoglobin,
                "creatinine": request.creatinine,
                "ischemia_time": request.ischemia_time
            }
            results["risk_assessments"]["gas"] = gas_calc.calculate(gas_data)
    
    # Stroke risk для КЭА
    if "carotid" in request.procedure_type:
        stroke_calc = StrokeRiskCalculator()
        stroke_data = {
            "age": request.age,
            "gender": request.gender,
            "symptomatic": request.symptomatic or False,
            "cad": request.cad,
            "diabetes": request.diabetes,
            "renal_failure": request.creatinine > 2.0,
            "contralateral_occlusion": request.contralateral_occlusion or False
        }
        results["risk_assessments"]["stroke_cea"] = stroke_calc.calculate(stroke_data)
    
    # Общие рекомендации
    recommendations = []
    
    if request.urgency == "emergency":
        recommendations.append("Экстренная операция - минимальная подготовка")
    elif request.urgency == "urgent":
        recommendations.append("Срочная операция - сокращенная подготовка")
    else:
        recommendations.append("Плановая операция - полная предоперационная подготовка")
    
    if request.creatinine > 2.0:
        recommendations.append("ХПН - консультация нефролога, контрастная защита")
    
    if request.chf:
        recommendations.append("ХСН - оптимизация терапии, ЭхоКГ")
    
    if request.cad:
        recommendations.append("ИБС - оценка риска, возможно стресс-тест")
    
    results["general_recommendations"] = recommendations
    
    return {
        "success": True,
        "assessment": results
    }
