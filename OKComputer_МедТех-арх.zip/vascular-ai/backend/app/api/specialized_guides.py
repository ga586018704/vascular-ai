"""
API endpoints для специализированных руководств VASCULAR.AI
"""

from typing import Optional, List
from fastapi import APIRouter, HTTPException, Body
from pydantic import BaseModel

from app.services.lymphedema_guide import (
    classify_lymphedema,
    get_cdt_protocol,
    get_cellulitis_protocol,
    LYMPHEDEMA_CLASSIFICATION,
    ISL_STAGING,
    LYMPHEDEMA_TREATMENT,
    LYMPHEDEMA_COMPLICATIONS
)

from app.services.contrast_media_guide import (
    assess_cin_risk,
    get_cin_prevention,
    get_premedication_protocol,
    CONTRAST_MEDIA_TYPES,
    CONTRAST_INDUCED_NEPHROPATHY,
    ALLERGIC_REACTIONS,
    NSF_GUIDELINES
)

from app.services.endovascular_complications import (
    get_complication_management,
    assess_procedure_risk,
    ACCESS_COMPLICATIONS,
    ANGIOPLASTY_COMPLICATIONS,
    STENT_COMPLICATIONS,
    EVAR_TEVAR_COMPLICATIONS
)

from app.services.vascular_ultrasound_guide import (
    interpret_carotid_stenosis,
    interpret_bypass_graft,
    get_dvt_probability,
    CAROTID_ULTRASOUND,
    PERIPHERAL_ULTRASOUND,
    VENOUS_ULTRASOUND
)

from app.services.neurointerventional_guide import (
    get_stroke_treatment_window,
    calculate_spetzler_martin,
    get_aneurysm_treatment_recommendation,
    ISCHEMIC_STROKE,
    INTRACRANIAL_ANEURYSMS,
    AVM
)

from app.services.hybrid_aortic_surgery import (
    get_dissection_management,
    get_hybrid_procedure_indication,
    get_tevar_planning,
    AORTIC_DISSECTION,
    HYBRID_PROCEDURES
)

router = APIRouter(prefix="/api/specialized", tags=["Specialized Guides"])


# ==================== LYMPHEDEMA ====================

class LymphedemaClassificationRequest(BaseModel):
    onset_age: int
    family_history: bool = False
    triggers: List[str] = []


@router.post("/lymphedema/classify")
async def lymphedema_classification(request: LymphedemaClassificationRequest):
    """
    Классификация лимфедемы
    """
    result = classify_lymphedema(
        request.onset_age,
        request.family_history,
        request.triggers
    )
    return {"success": True, "result": result}


@router.get("/lymphedema/staging/{stage}")
async def lymphedema_staging(stage: str):
    """
    Информация о стадии лимфедемы (ISL)
    """
    staging = ISL_STAGING.get(stage)
    if not staging:
        raise HTTPException(status_code=404, detail=f"Stage {stage} not found")
    return {"success": True, "staging": staging}


@router.get("/lymphedema/cdt-protocol/{stage}")
async def cdt_protocol(stage: str):
    """
    Протокол CDT для стадии лимфедемы
    """
    protocol = get_cdt_protocol(stage, 0)
    return {"success": True, "protocol": protocol}


@router.get("/lymphedema/cellulitis/{severity}")
async def cellulitis_protocol(severity: str):
    """
    Протокол лечения целлюлита
    """
    protocol = get_cellulitis_protocol(severity)
    return {"success": True, "protocol": protocol}


@router.get("/lymphedema/guide")
async def lymphedema_full_guide():
    """
    Полное руководство по лимфедеме
    """
    return {
        "classification": LYMPHEDEMA_CLASSIFICATION,
        "staging": ISL_STAGING,
        "treatment": LYMPHEDEMA_TREATMENT,
        "complications": LYMPHEDEMA_COMPLICATIONS
    }


# ==================== CONTRAST MEDIA ====================

class CINRiskRequest(BaseModel):
    egfr: float
    diabetes: bool = False
    age: int = 65
    volume: float = 100
    intraarterial: bool = False


@router.post("/contrast/cin-risk")
async def cin_risk_assessment(request: CINRiskRequest):
    """
    Оценка риска контраст-индуцированной нефропатии
    """
    result = assess_cin_risk(
        request.egfr,
        request.diabetes,
        request.age,
        request.volume,
        request.intraarterial
    )
    return {"success": True, "result": result}


@router.get("/contrast/types")
async def contrast_media_types():
    """
    Типы контрастных веществ
    """
    return {"types": CONTRAST_MEDIA_TYPES}


@router.get("/contrast/nephropathy-guide")
async def cin_guide():
    """
    Руководство по CIN
    """
    return {"guide": CONTRAST_INDUCED_NEPHROPATHY}


@router.get("/contrast/allergic-reactions")
async def allergic_reactions_guide():
    """
    Руководство по аллергическим реакциям
    """
    return {"reactions": ALLERGIC_REACTIONS}


@router.get("/contrast/nsf-guide")
async def nsf_guide():
    """
    Руководство по NSF
    """
    return {"nsf": NSF_GUIDELINES}


# ==================== ENDOVASCULAR COMPLICATIONS ====================

@router.get("/endovascular/complications/{complication_type}")
async def endovascular_complication(complication_type: str, severity: str = "moderate"):
    """
    Управление осложнением эндоваскулярного вмешательства
    """
    result = get_complication_management(complication_type, severity)
    if "error" in result:
        raise HTTPException(status_code=404, detail=result["error"])
    return {"success": True, "result": result}


class ProcedureRiskRequest(BaseModel):
    procedure: str
    age: int = 65
    diabetes: bool = False
    renal_insufficiency: bool = False
    anticoagulation: bool = False


@router.post("/endovascular/procedure-risk")
async def procedure_risk_assessment(request: ProcedureRiskRequest):
    """
    Оценка риска осложнений для процедуры
    """
    patient_factors = {
        "age": request.age,
        "diabetes": request.diabetes,
        "renal_insufficiency": request.renal_insufficiency,
        "anticoagulation": request.anticoagulation
    }
    result = assess_procedure_risk(request.procedure, patient_factors)
    return {"success": True, "result": result}


@router.get("/endovascular/complications-list")
async def complications_list():
    """
    Список осложнений
    """
    return {
        "access": list(ACCESS_COMPLICATIONS.keys()),
        "angioplasty": list(ANGIOPLASTY_COMPLICATIONS.keys()),
        "stent": list(STENT_COMPLICATIONS.keys()),
        "evar_tevar": list(EVAR_TEVAR_COMPLICATIONS.keys())
    }


# ==================== VASCULAR ULTRASOUND ====================

class CarotidInterpretationRequest(BaseModel):
    psv_ica: float
    edv_ica: float
    ratio: float


@router.post("/ultrasound/carotid-interpretation")
async def carotid_ultrasound_interpretation(request: CarotidInterpretationRequest):
    """
    Интерпретация УЗИ сонных артерий
    """
    result = interpret_carotid_stenosis(
        request.psv_ica,
        request.edv_ica,
        request.ratio
    )
    return {"success": True, "result": result}


class BypassGraftRequest(BaseModel):
    psv: float
    graft_type: str  # "vein" или "prosthetic"


@router.post("/ultrasound/bypass-graft")
async def bypass_graft_interpretation(request: BypassGraftRequest):
    """
    Интерпретация УЗИ шунта
    """
    result = interpret_bypass_graft(request.psv, request.graft_type)
    return {"success": True, "result": result}


@router.get("/ultrasound/dvt-probability/{wells_score}")
async def dvt_probability(wells_score: int):
    """
    Оценка вероятности ТГВ по шкале Wells
    """
    result = get_dvt_probability(wells_score)
    return {"success": True, "result": result}


@router.get("/ultrasound/guide/{topic}")
async def ultrasound_guide(topic: str):
    """
    Руководство по УЗИ (carotid, peripheral, venous)
    """
    guides = {
        "carotid": CAROTID_ULTRASOUND,
        "peripheral": PERIPHERAL_ULTRASOUND,
        "venous": VENOUS_ULTRASOUND
    }
    guide = guides.get(topic)
    if not guide:
        raise HTTPException(status_code=404, detail=f"Guide {topic} not found")
    return {"success": True, "guide": guide}


# ==================== NEUROINTERVENTIONAL ====================

class StrokeTreatmentRequest(BaseModel):
    onset_time_hours: float
    nihss: int
    large_vessel_occlusion: bool


@router.post("/neuro/stroke-treatment")
async def stroke_treatment_options(request: StrokeTreatmentRequest):
    """
    Опции лечения ишемического инсульта
    """
    result = get_stroke_treatment_window(
        request.onset_time_hours,
        request.nihss,
        request.large_vessel_occlusion
    )
    return {"success": True, "result": result}


class AVMGradingRequest(BaseModel):
    size_cm: float
    eloquent: bool
    deep_drainage: bool


@router.post("/neuro/avm-grading")
async def avm_grading(request: AVMGradingRequest):
    """
    Расчет градации Spetzler-Martin для AVM
    """
    result = calculate_spetzler_martin(
        request.size_cm,
        request.eloquent,
        request.deep_drainage
    )
    return {"success": True, "result": result}


class AneurysmRequest(BaseModel):
    size_mm: float
    location: str
    shape: str = "saccular"
    ruptured: bool = False


@router.post("/neuro/aneurysm-recommendation")
async def aneurysm_recommendation(request: AneurysmRequest):
    """
    Рекомендация по лечению внутричерепной аневризмы
    """
    result = get_aneurysm_treatment_recommendation(
        request.size_mm,
        request.location,
        request.shape,
        request.ruptured
    )
    return {"success": True, "result": result}


@router.get("/neuro/guide/{topic}")
async def neuro_guide(topic: str):
    """
    Руководство по нейроинтервенциям
    """
    guides = {
        "stroke": ISCHEMIC_STROKE,
        "aneurysm": INTRACRANIAL_ANEURYSMS,
        "avm": AVM
    }
    guide = guides.get(topic)
    if not guide:
        raise HTTPException(status_code=404, detail=f"Guide {topic} not found")
    return {"success": True, "guide": guide}


# ==================== HYBRID AORTIC SURGERY ====================

class DissectionRequest(BaseModel):
    stanford_type: str  # "A" или "B"
    complicated: bool = False
    malperfusion: List[str] = []


@router.post("/hybrid-aortic/dissection-management")
async def dissection_management(request: DissectionRequest):
    """
    Управление расслоением аорты
    """
    result = get_dissection_management(
        request.stanford_type,
        request.complicated,
        request.malperfusion
    )
    return {"success": True, "result": result}


class HybridProcedureRequest(BaseModel):
    aneurysm_extent: str
    patient_risk: str


@router.post("/hybrid-aortic/procedure-indication")
async def hybrid_procedure_indication(request: HybridProcedureRequest):
    """
    Показания к гибридной процедуре
    """
    result = get_hybrid_procedure_indication(
        request.aneurysm_extent,
        request.patient_risk
    )
    return {"success": True, "result": result}


class TEVARPlanningRequest(BaseModel):
    proximal_landing_zone: str
    need_debranching: bool


@router.post("/hybrid-aortic/tevar-planning")
async def tevar_planning(request: TEVARPlanningRequest):
    """
    Планирование TEVAR
    """
    result = get_tevar_planning(
        request.proximal_landing_zone,
        request.need_debranching
    )
    return {"success": True, "result": result}


@router.get("/hybrid-aortic/guide/{topic}")
async def hybrid_aortic_guide(topic: str):
    """
    Руководство по гибридной хирургии аорты
    """
    guides = {
        "dissection": AORTIC_DISSECTION,
        "procedures": HYBRID_PROCEDURES
    }
    guide = guides.get(topic)
    if not guide:
        raise HTTPException(status_code=404, detail=f"Guide {topic} not found")
    return {"success": True, "guide": guide}


# ==================== QUICK REFERENCE ====================

@router.get("/quick-reference/all")
async def all_quick_references():
    """
    Все быстрые справки
    """
    return {
        "lymphedema": {
            "staging": ISL_STAGING,
            "cellulitis_antibiotics": "Амоксициллин/клавуланат 875/125 мг 2x/день, 10-14 дней"
        },
        "contrast": {
            "cin_prevention": "IV гидратация (изотонический NaCl), N-ацетилцистеин",
            "premedication": "Преднизолон 50 мг per os за 13, 7, 1 час до + димедрол 50 мг"
        },
        "dissection": {
            "type_a": "Срочная операция (1-2% смертность в час)",
            "type_b_uncomplicated": "Медикаментозная терапия",
            "type_b_complicated": "TEVAR"
        },
        "stroke": {
            "iv_tpa": "4.5 часов",
            "mechanical_thrombectomy": "До 24 часов (при LVO)"
        }
    }
