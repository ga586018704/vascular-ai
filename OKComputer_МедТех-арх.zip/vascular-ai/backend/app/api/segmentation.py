import httpx
from typing import List, Dict, Any
from datetime import datetime
from fastapi import APIRouter, HTTPException, Depends, BackgroundTasks, Request
from sqlalchemy.ext.asyncio import AsyncSession

from app.models.database import get_db, DicomStudy, Segmentation, VesselMeasurement
from app.core.config import get_settings
from app.api.auth import get_current_active_user, require_permission
from app.core.security import SecurityManager, AuditLogger
from app.models.database import User

router = APIRouter(prefix="/api/segmentation", tags=["Segmentation"])
settings = get_settings()


# Vessel class mapping
VESSEL_CLASSES = {
    1: {"name": "aorta", "display_name": "Аорта", "type": "artery"},
    2: {"name": "iliac_right", "display_name": "Правая подвздошная артерия", "type": "artery"},
    3: {"name": "iliac_left", "display_name": "Левая подвздошная артерия", "type": "artery"},
    4: {"name": "femoral_right", "display_name": "Правая бедренная артерия", "type": "artery"},
    5: {"name": "femoral_left", "display_name": "Левая бедренная артерия", "type": "artery"},
    6: {"name": "carotid_right", "display_name": "Правая сонная артерия", "type": "artery"},
    7: {"name": "carotid_left", "display_name": "Левая сонная артерия", "type": "artery"},
    8: {"name": "subclavian_right", "display_name": "Правая подключичная артерия", "type": "artery"},
}


async def call_ai_service(study_uid: str, nifti_path: str) -> Dict[str, Any]:
    """Call AI service for segmentation"""
    
    async with httpx.AsyncClient() as client:
        try:
            response = await client.post(
                f"{settings.AI_SERVICE_URL}/segment",
                json={
                    "study_uid": study_uid,
                    "nifti_path": nifti_path
                },
                timeout=300.0
            )
            
            if response.status_code == 200:
                return response.json()
            else:
                print(f"AI service error: {response.status_code} - {response.text}")
                # Return mock result for development
                return get_mock_segmentation_result(study_uid)
        
        except httpx.ConnectError:
            print("AI service not available, using mock result")
            return get_mock_segmentation_result(study_uid)
        except Exception as e:
            print(f"Error calling AI service: {e}")
            return get_mock_segmentation_result(study_uid)


def get_mock_segmentation_result(study_uid: str) -> Dict[str, Any]:
    """Generate mock segmentation result for development"""
    return {
        "success": True,
        "study_uid": study_uid,
        "classes": [1, 2, 3],
        "dice_scores": {
            "aorta": 0.89,
            "iliac_right": 0.85,
            "iliac_left": 0.84,
            "background": 0.98
        },
        "mask_path": f"/app/processed/{study_uid}_mask.nii.gz",
        "measurements": {
            "aorta": {
                "diameter_max": 45.2,
                "diameter_mean": 38.5,
                "diameter_min": 32.1,
                "length": 125.0,
                "volume": 145.8,
                "has_pathology": True,
                "pathology_type": "aneurysm",
                "pathology_severity": "moderate"
            },
            "iliac_right": {
                "diameter_max": 18.5,
                "diameter_mean": 15.2,
                "diameter_min": 12.8,
                "length": 85.0,
                "volume": 28.4,
                "has_pathology": False,
                "pathology_type": None,
                "pathology_severity": None
            },
            "iliac_left": {
                "diameter_max": 19.2,
                "diameter_mean": 16.1,
                "diameter_min": 13.5,
                "length": 82.0,
                "volume": 30.1,
                "has_pathology": False,
                "pathology_type": None,
                "pathology_severity": None
            }
        }
    }


@router.post("/start/{study_id}")
async def start_segmentation(
    request: Request,
    study_id: int,
    background_tasks: BackgroundTasks,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(require_permission("write:study"))
):
    """Start AI segmentation for a study (requires authentication)"""
    
    from sqlalchemy import select
    
    # Get study
    result = await db.execute(
        select(DicomStudy).where(DicomStudy.id == study_id)
    )
    
    study = result.scalar_one_or_none()
    
    if not study:
        raise HTTPException(status_code=404, detail="Study not found")
    
    if study.status == "processing":
        raise HTTPException(status_code=400, detail="Segmentation already in progress")
    
    # Update study status
    study.status = "processing"
    await db.commit()
    
    # Create segmentation record
    segmentation = Segmentation(
        study_id=study_id,
        status="processing",
        user_id=current_user.id
    )
    db.add(segmentation)
    await db.commit()
    await db.refresh(segmentation)
    
    # Start segmentation in background
    background_tasks.add_task(
        process_segmentation,
        study_id,
        study.study_uid,
        study.nifti_path or f"/app/processed/{study.study_uid}.nii.gz",
        segmentation.id
    )
    
    # Log segmentation start
    AuditLogger.log_data_modification(
        user_id=str(current_user.id),
        table="segmentations",
        record_id=str(segmentation.id),
        action="start_segmentation",
        changes={"study_id": study_id, "status": "processing"},
        ip_address=request.client.host if request.client else "unknown"
    )
    
    return {
        "success": True,
        "segmentation_id": segmentation.id,
        "status": "processing",
        "message": "Segmentation started"
    }


async def process_segmentation(
    study_id: int,
    study_uid: str,
    nifti_path: str,
    segmentation_id: int
):
    """Process segmentation in background"""
    
    from sqlalchemy import select
    from app.models.database import AsyncSessionLocal
    
    async with AsyncSessionLocal() as db:
        try:
            # Call AI service
            result = await call_ai_service(study_uid, nifti_path)
            
            # Get segmentation record
            seg_result = await db.execute(
                select(Segmentation).where(Segmentation.id == segmentation_id)
            )
            segmentation = seg_result.scalar_one()
            
            if result.get("success"):
                # Update segmentation
                segmentation.status = "completed"
                segmentation.classes = result.get("classes", [])
                segmentation.dice_scores = result.get("dice_scores", {})
                segmentation.mask_path = result.get("mask_path")
                segmentation.measurements = result.get("measurements", {})
                segmentation.completed_at = datetime.utcnow()
                
                # Add vessel measurements
                measurements = result.get("measurements", {})
                for vessel_key, vessel_data in measurements.items():
                    measurement = VesselMeasurement(
                        segmentation_id=segmentation_id,
                        vessel_name=vessel_key,
                        vessel_class="artery",
                        diameter_max=vessel_data.get("diameter_max"),
                        diameter_mean=vessel_data.get("diameter_mean"),
                        diameter_min=vessel_data.get("diameter_min"),
                        length=vessel_data.get("length"),
                        volume=vessel_data.get("volume"),
                        has_pathology=vessel_data.get("has_pathology", False),
                        pathology_type=vessel_data.get("pathology_type"),
                        pathology_severity=vessel_data.get("pathology_severity"),
                    )
                    db.add(measurement)
                
                # Update study status
                study_result = await db.execute(
                    select(DicomStudy).where(DicomStudy.id == study_id)
                )
                study = study_result.scalar_one()
                study.status = "segmented"
                
            else:
                segmentation.status = "error"
                segmentation.error_message = result.get("error", "Unknown error")
                
                study_result = await db.execute(
                    select(DicomStudy).where(DicomStudy.id == study_id)
                )
                study = study_result.scalar_one()
                study.status = "error"
            
            await db.commit()
        
        except Exception as e:
            print(f"Error in process_segmentation: {e}")
            # Handle error
            try:
                seg_result = await db.execute(
                    select(Segmentation).where(Segmentation.id == segmentation_id)
                )
                segmentation = seg_result.scalar_one()
                segmentation.status = "error"
                segmentation.error_message = str(e)
                
                study_result = await db.execute(
                    select(DicomStudy).where(DicomStudy.id == study_id)
                )
                study = study_result.scalar_one()
                study.status = "error"
                
                await db.commit()
            except Exception as e2:
                print(f"Error handling segmentation failure: {e2}")


@router.get("/status/{segmentation_id}")
async def get_segmentation_status(
    request: Request,
    segmentation_id: int,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(require_permission("read:study"))
):
    """Get segmentation status and results (requires authentication)"""
    
    from sqlalchemy import select
    
    result = await db.execute(
        select(Segmentation).where(Segmentation.id == segmentation_id)
    )
    
    segmentation = result.scalar_one_or_none()
    
    if not segmentation:
        raise HTTPException(status_code=404, detail="Segmentation not found")
    
    response = {
        "id": segmentation.id,
        "study_id": segmentation.study_id,
        "status": segmentation.status,
        "created_at": segmentation.created_at.isoformat() if segmentation.created_at else None,
    }
    
    if segmentation.status == "completed":
        response.update({
            "classes": segmentation.classes,
            "dice_scores": segmentation.dice_scores,
            "measurements": segmentation.measurements,
            "completed_at": segmentation.completed_at.isoformat() if segmentation.completed_at else None,
        })
    
    if segmentation.status == "error":
        response["error"] = segmentation.error_message
    
    # Log access
    AuditLogger.log_dicom_access(
        user_id=str(current_user.id),
        study_id=str(segmentation.study_id),
        action="view_segmentation",
        ip_address=request.client.host if request.client else "unknown"
    )
    
    return response


@router.get("/study/{study_id}")
async def get_study_segmentation(
    request: Request,
    study_id: int,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(require_permission("read:study"))
):
    """Get segmentation for a study (requires authentication)"""
    
    from sqlalchemy import select
    
    result = await db.execute(
        select(Segmentation).where(Segmentation.study_id == study_id)
        .order_by(Segmentation.created_at.desc())
    )
    
    segmentation = result.scalars().first()
    
    if not segmentation:
        raise HTTPException(status_code=404, detail="No segmentation found for this study")
    
    # Get vessel measurements
    measurements_result = await db.execute(
        select(VesselMeasurement).where(VesselMeasurement.segmentation_id == segmentation.id)
    )
    
    measurements = measurements_result.scalars().all()
    
    # Log access
    AuditLogger.log_dicom_access(
        user_id=str(current_user.id),
        study_id=str(study_id),
        action="view_segmentation_details",
        ip_address=request.client.host if request.client else "unknown"
    )
    
    return {
        "id": segmentation.id,
        "study_id": segmentation.study_id,
        "status": segmentation.status,
        "classes": segmentation.classes,
        "dice_scores": segmentation.dice_scores,
        "measurements": segmentation.measurements,
        "vessel_details": [
            {
                "vessel_name": m.vessel_name,
                "diameter_max": m.diameter_max,
                "diameter_mean": m.diameter_mean,
                "length": m.length,
                "volume": m.volume,
                "has_pathology": m.has_pathology,
                "pathology_type": m.pathology_type,
                "pathology_severity": m.pathology_severity,
            }
            for m in measurements
        ],
        "created_at": segmentation.created_at.isoformat() if segmentation.created_at else None,
        "completed_at": segmentation.completed_at.isoformat() if segmentation.completed_at else None,
    }


@router.get("/vessel-classes")
async def get_vessel_classes(
    current_user: User = Depends(get_current_active_user)
):
    """Get available vessel classes (requires authentication)"""
    
    return {
        "classes": [
            {
                "id": class_id,
                "name": info["name"],
                "display_name": info["display_name"],
                "type": info["type"]
            }
            for class_id, info in VESSEL_CLASSES.items()
        ]
    }
