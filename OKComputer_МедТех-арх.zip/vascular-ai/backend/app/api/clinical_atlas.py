"""
API endpoints для клинического атласа VASCULAR.AI
Интеграция знаний из Medscape, First Aid USMLE, Netter Atlas, Sabiston
"""

from typing import Optional, List
from fastapi import APIRouter, HTTPException, Body
from pydantic import BaseModel

from app.services.clinical_atlas import (
    get_clinical_algorithm,
    get_surgical_anatomy,
    get_operative_technique,
    get_pharmacotherapy_guideline,
    search_atlas,
    CLINICAL_ALGORITHMS,
    SURGICAL_ANATOMY,
    OPERATIVE_TECHNIQUES,
    PHARMACOTHERAPY
)

router = APIRouter(prefix="/api/atlas", tags=["Clinical Atlas"])


# ==================== CLINICAL ALGORITHMS ====================

class AlgorithmRequest(BaseModel):
    condition: str
    patient_data: Optional[dict] = None


@router.post("/algorithm")
async def clinical_algorithm(request: AlgorithmRequest):
    """
    Получить клинический алгоритм для состояния
    
    Доступные алгоритмы:
    - acute_limb_ischemia (острая ишемия конечности)
    - carotid_stenosis (стеноз сонной артерии)
    - aaa_management (аневризма брюшной аорты)
    - claudication_workup (клаудикация)
    - clti_management (CLTI - критическая ишемия)
    """
    result = get_clinical_algorithm(request.condition, request.patient_data)
    
    if "error" in result:
        raise HTTPException(status_code=404, detail=result["error"])
    
    return {
        "success": True,
        "result": result
    }


@router.get("/algorithms/list")
async def list_algorithms():
    """
    Список доступных клинических алгоритмов
    """
    return {
        "algorithms": [
            {
                "id": "acute_limb_ischemia",
                "name": "Острая ишемия конечности",
                "description": "6 P's, классификация, алгоритм лечения"
            },
            {
                "id": "carotid_stenosis",
                "name": "Стеноз сонной артерии",
                "description": "Градация, CEA vs CAS, показания"
            },
            {
                "id": "aaa_management",
                "name": "Аневризма брюшной аорты",
                "description": "Скрининг, критерии лечения, EVAR vs открытая"
            },
            {
                "id": "claudication_workup",
                "name": "Клаудикация",
                "description": "Обследование, консервативное лечение, реваскуляризация"
            },
            {
                "id": "clti_management",
                "name": "CLTI",
                "description": "WIfI классификация, реваскуляризация, ампутация"
            }
        ]
    }


# ==================== SURGICAL ANATOMY ====================

@router.get("/anatomy/{region}")
async def surgical_anatomy(region: str):
    """
    Получить анатомические детали для региона
    
    Доступные регионы:
    - carotid_bifurcation (бифуркация сонной артерии)
    - aorta_abdominal (брюшная аорта)
    - femoral_triangle (паховый треугольник)
    - popliteal_fossa (подколенная ямка)
    - aortic_arch_branches (ветви дуги аорты)
    - venous_anatomy (венозная анатомия)
    """
    result = get_surgical_anatomy(region)
    
    if "error" in result:
        raise HTTPException(status_code=404, detail=result["error"])
    
    return {
        "success": True,
        "result": result
    }


@router.get("/anatomy/list")
async def list_anatomy_regions():
    """
    Список доступных анатомических регионов
    """
    return {
        "regions": list(SURGICAL_ANATOMY.keys())
    }


# ==================== OPERATIVE TECHNIQUES ====================

class TechniqueRequest(BaseModel):
    procedure: str
    step_number: Optional[int] = None


@router.post("/technique")
async def operative_technique(request: TechniqueRequest):
    """
    Получить оперативную технику
    
    Доступные процедуры:
    - carotid_endarterectomy_detailed (КЭА подробно)
    - aortobifemoral_bypass (Аорто-бифеморальное шунтирование)
    - femoropopliteal_bypass_detailed (Бедренно-подколенное шунтирование)
    - evar_step_by_step (EVAR пошагово)
    - varicose_vein_surgery (Операция при варикозе)
    """
    result = get_operative_technique(request.procedure, request.step_number)
    
    if "error" in result:
        raise HTTPException(status_code=404, detail=result["error"])
    
    return {
        "success": True,
        "result": result
    }


@router.get("/techniques/list")
async def list_techniques():
    """
    Список доступных оперативных техник
    """
    techniques = []
    for key, value in OPERATIVE_TECHNIQUES.items():
        techniques.append({
            "id": key,
            "name": value.get("name", key)
        })
    
    return {
        "techniques": techniques
    }


# ==================== PHARMACOTHERAPY ====================

@router.get("/pharmacotherapy/{medication_class}")
async def pharmacotherapy_guideline(medication_class: str):
    """
    Получить руководство по фармакотерапии
    
    Доступные классы:
    - antiplatelet_therapy (антиагреганты)
    - statins (статины)
    - antihypertensives (антигипертензивные)
    - diabetes_management (диабет)
    - cilostazol (цилостазол)
    - anticoagulation (антикоагулянты)
    """
    result = get_pharmacotherapy_guideline(medication_class)
    
    if "error" in result:
        raise HTTPException(status_code=404, detail=result["error"])
    
    return {
        "success": True,
        "result": result
    }


@router.get("/pharmacotherapy/list")
async def list_pharmacotherapy():
    """
    Список доступных классов фармакотерапии
    """
    return {
        "classes": list(PHARMACOTHERAPY.keys())
    }


# ==================== SEARCH ====================

class SearchRequest(BaseModel):
    query: str


@router.post("/search")
async def search_clinical_atlas(request: SearchRequest):
    """
    Поиск по клиническому атласу
    """
    results = search_atlas(request.query)
    
    return {
        "success": True,
        "query": request.query,
        "results": results
    }


# ==================== QUICK REFERENCE ====================

@router.get("/quick-reference/acls-vascular")
async def acls_vascular():
    """
    Быстрая справка по сосудистым экстренным ситуациям
    """
    return {
        "ruptured_aaa": {
            "signs": ["Боль в животе/спине", "Гипотензия", "Пульсирующая масса"],
            "immediate": ["Массивное переливание", "Немедленная операция"],
            "mortality": "80-90% без операции, 30-50% с операцией"
        },
        "acute_limb_ischemia": {
            "six_ps": ["Pain", "Pallor", "Pulselessness", "Paresthesia", "Paralysis", "Poikilothermia"],
            "immediate": ["Гепарин 5000 ЕД", "Анальгезия", "Срочная реваскуляризация"],
            "golden_hours": "6 часов"
        },
        "carotid_stroke": {
            "signs": ["Внезапный неврологический дефицит", "Афазия", "Гемипарез"],
            "immediate": ["КТ головы", "Оценка для тромболизиса/тромбэктомии"],
            "window": "4.5 часов для тромболизиса, 24 часа для тромбэктомии"
        }
    }


@router.get("/quick-reference/medications")
async def quick_medications():
    """
    Быстрая справка по лекарствам
    """
    return {
        "aspirin": {"dose": "75-325 мг/сут", "indication": "Все PAD пациенты"},
        "clopidogrel": {"dose": "75 мг/сут", "indication": "Альтернатива аспирину"},
        "atorvastatin": {"dose": "40-80 мг/сут", "indication": "Все PAD пациенты"},
        "cilostazol": {"dose": "100 мг 2x/день", "indication": "Клаудикация"},
        "heparin": {"dose": "5000 ЕД в/в", "indication": "Перед пережатием"},
        "warfarin": {"target_inr": "2.0-3.0", "indication": "ТГВ, ФП, механические клапаны"}
    }


@router.get("/quick-reference/classifications")
async def quick_classifications():
    """
    Быстрая справка по классификациям
    """
    return {
        "rutherford": {
            "0": "Асимптоматический",
            "1": "Легкая клаудикация",
            "2": "Умеренная клаудикация",
            "3": "Тяжелая клаудикация",
            "4": "Покойная боль",
            "5": "Минорная тканевая потеря",
            "6": "Major тканевая потеря"
        },
        "fontaine": {
            "I": "Асимптоматический",
            "IIa": "Клаудикация >200м",
            "IIb": "Клаудикация <200м",
            "III": "Покойная боль",
            "IV": "Трофические язвы/гангрена"
        },
        "abi": {
            "normal": ">1.40",
            "borderline": "0.91-1.00",
            "mild": "0.70-0.90",
            "moderate": "0.40-0.69",
            "severe": "<0.40"
        },
        "carotid_stenosis": {
            "mild": "<50% (PSV <125)",
            "moderate": "50-69% (PSV 125-230)",
            "severe": ">70% (PSV >230)"
        }
    }
