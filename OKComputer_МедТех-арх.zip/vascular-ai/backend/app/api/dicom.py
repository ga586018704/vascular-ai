import uuid
import shutil
from typing import List, Optional
from pathlib import Path

from fastapi import APIRouter, UploadFile, File, Form, HTTPException, Depends, BackgroundTasks, Request
from fastapi.responses import FileResponse, JSONResponse
from sqlalchemy.ext.asyncio import AsyncSession

from app.models.database import get_db, DicomStudy, Segmentation, User
from app.services.dicom_service import dicom_service
from app.core.config import get_settings
from app.api.auth import get_current_active_user, require_permission
from app.core.security import SecurityManager, AuditLogger

router = APIRouter(prefix="/api/dicom", tags=["DICOM"])
settings = get_settings()


@router.post("/upload")
async def upload_dicom(
    request: Request,
    background_tasks: BackgroundTasks,
    files: List[UploadFile] = File(...),
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(require_permission("write:study"))
):
    """Upload DICOM files for a study (requires authentication)"""
    
    if not files:
        raise HTTPException(status_code=400, detail="No files uploaded")
    
    # Validate file count
    if len(files) > 1000:
        raise HTTPException(status_code=400, detail="Maximum 1000 files allowed per upload")
    
    # Validate DICOM files
    for file in files:
        if not file.filename.endswith(('.dcm', '.DCM')):
            raise HTTPException(
                status_code=400, 
                detail=f"Invalid file format: {file.filename}. Only .dcm files allowed"
            )
        # Check file size (max 50MB per file)
        content = await file.read()
        if len(content) > 50 * 1024 * 1024:
            raise HTTPException(
                status_code=400,
                detail=f"File {file.filename} exceeds 50MB limit"
            )
        await file.seek(0)
    
    # Generate study UID
    study_uid = str(uuid.uuid4())
    
    # Read file contents
    file_contents = []
    filenames = []
    
    for file in files:
        content = await file.read()
        file_contents.append(content)
        filenames.append(file.filename)
    
    # Save DICOM files
    result = await dicom_service.save_dicom_files(file_contents, filenames, study_uid)
    
    # Convert to NIfTI in background
    background_tasks.add_task(dicom_service.convert_to_nifti, study_uid)
    
    # Encrypt patient_id for storage
    encrypted_patient_id = SecurityManager.encrypt_phi(f"ANON_{study_uid[:8]}")
    
    # Save to database
    study = DicomStudy(
        user_id=current_user.id,
        patient_id=encrypted_patient_id.decode(),  # Store encrypted
        study_uid=study_uid,
        study_description=result["metadata"].get("study_description", ""),
        modality=result["metadata"].get("modality", "CT"),
        num_slices=result["num_files"],
        dicom_path=result["study_path"],
        status="uploaded",
        voxel_spacing=result["metadata"].get("pixel_spacing"),
        image_size=result["metadata"].get("image_size"),
    )
    
    db.add(study)
    await db.commit()
    await db.refresh(study)
    
    # Log DICOM access
    AuditLogger.log_dicom_access(
        user_id=str(current_user.id),
        study_id=study_uid,
        action="upload",
        ip_address=request.client.host if request.client else "unknown"
    )
    
    return {
        "success": True,
        "study_id": study.id,
        "study_uid": study_uid,
        "num_files": result["num_files"],
        "metadata": result["metadata"]
    }


@router.get("/studies")
async def get_studies(
    request: Request,
    skip: int = 0,
    limit: int = 10,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(require_permission("read:study"))
):
    """Get list of DICOM studies (requires authentication)"""
    
    from sqlalchemy import select
    
    # Limit max results
    limit = min(limit, 100)
    
    result = await db.execute(
        select(DicomStudy)
        .order_by(DicomStudy.created_at.desc())
        .offset(skip)
        .limit(limit)
    )
    
    studies = result.scalars().all()
    
    # Log access
    AuditLogger.log_dicom_access(
        user_id=str(current_user.id),
        study_id="list",
        action="list",
        ip_address=request.client.host if request.client else "unknown"
    )
    
    return {
        "studies": [
            {
                "id": s.id,
                "study_uid": s.study_uid,
                "patient_id": SecurityManager.hash_patient_id(s.patient_id),  # Return hash only
                "description": s.study_description,
                "modality": s.modality,
                "num_slices": s.num_slices,
                "status": s.status,
                "created_at": s.created_at.isoformat() if s.created_at else None,
            }
            for s in studies
        ]
    }


@router.get("/studies/{study_id}")
async def get_study(
    request: Request,
    study_id: int,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(require_permission("read:study"))
):
    """Get study details (requires authentication)"""
    
    from sqlalchemy import select
    
    result = await db.execute(
        select(DicomStudy).where(DicomStudy.id == study_id)
    )
    
    study = result.scalar_one_or_none()
    
    if not study:
        raise HTTPException(status_code=404, detail="Study not found")
    
    # Log access
    AuditLogger.log_dicom_access(
        user_id=str(current_user.id),
        study_id=study.study_uid,
        action="view",
        ip_address=request.client.host if request.client else "unknown"
    )
    
    return {
        "id": study.id,
        "study_uid": study.study_uid,
        "patient_id": SecurityManager.hash_patient_id(study.patient_id),  # Return hash only
        "description": study.study_description,
        "modality": study.modality,
        "num_slices": study.num_slices,
        "status": study.status,
        "voxel_spacing": study.voxel_spacing,
        "image_size": study.image_size,
        "created_at": study.created_at.isoformat() if study.created_at else None,
    }


@router.get("/studies/{study_id}/files")
async def get_study_files(
    request: Request,
    study_id: int,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(require_permission("read:study"))
):
    """Get list of DICOM files in a study (requires authentication)"""
    
    from sqlalchemy import select
    
    result = await db.execute(
        select(DicomStudy).where(DicomStudy.id == study_id)
    )
    
    study = result.scalar_one_or_none()
    
    if not study:
        raise HTTPException(status_code=404, detail="Study not found")
    
    study_path = Path(study.dicom_path)
    
    if not study_path.exists():
        raise HTTPException(status_code=404, detail="Study directory not found")
    
    # Get all DICOM files
    dicom_files = sorted([f.name for f in study_path.glob('*.dcm')])
    
    # Log access
    AuditLogger.log_dicom_access(
        user_id=str(current_user.id),
        study_id=study.study_uid,
        action="list_files",
        ip_address=request.client.host if request.client else "unknown"
    )
    
    return {
        "study_id": study_id,
        "study_uid": study.study_uid,
        "files": dicom_files,
        "count": len(dicom_files)
    }


@router.get("/studies/{study_uid}/file/{filename}")
async def get_dicom_file(
    request: Request,
    study_uid: str,
    filename: str,
    current_user: User = Depends(require_permission("read:study"))
):
    """Get a specific DICOM file (requires authentication)"""
    
    # Sanitize filename to prevent path traversal
    from app.core.security import InputValidator
    safe_filename = InputValidator.sanitize_filename(filename)
    
    file_path = Path(settings.UPLOAD_DIR) / study_uid / safe_filename
    
    if not file_path.exists():
        raise HTTPException(status_code=404, detail="File not found")
    
    # Log access
    AuditLogger.log_dicom_access(
        user_id=str(current_user.id),
        study_id=study_uid,
        action="download_file",
        ip_address=request.client.host if request.client else "unknown"
    )
    
    return FileResponse(
        file_path,
        media_type="application/dicom",
        filename=safe_filename
    )


@router.get("/studies/{study_uid}/slice/{slice_idx}")
async def get_slice(
    request: Request,
    study_uid: str,
    slice_idx: int,
    current_user: User = Depends(require_permission("read:study"))
):
    """Get a specific slice from a study (requires authentication)"""
    
    slice_data = dicom_service.get_slice(study_uid, slice_idx)
    
    if slice_data is None:
        raise HTTPException(status_code=404, detail="Slice not found")
    
    # Log access
    AuditLogger.log_dicom_access(
        user_id=str(current_user.id),
        study_id=study_uid,
        action="view_slice",
        ip_address=request.client.host if request.client else "unknown"
    )
    
    return slice_data


@router.get("/studies/{study_uid}/preview")
async def get_preview(
    request: Request,
    study_uid: str,
    slice_idx: Optional[int] = None,
    current_user: User = Depends(require_permission("read:study"))
):
    """Get preview image of a study (middle slice by default) (requires authentication)"""
    
    # Get image array to determine number of slices
    image_array = dicom_service.get_image_array(study_uid)
    
    if image_array is None:
        raise HTTPException(status_code=404, detail="Study not found")
    
    if slice_idx is None:
        slice_idx = len(image_array) // 2
    
    # Validate slice index
    if slice_idx < 0 or slice_idx >= len(image_array):
        raise HTTPException(status_code=400, detail="Invalid slice index")
    
    slice_data = dicom_service.get_slice(study_uid, slice_idx)
    
    if slice_data is None:
        raise HTTPException(status_code=404, detail="Slice not found")
    
    # Log access
    AuditLogger.log_dicom_access(
        user_id=str(current_user.id),
        study_id=study_uid,
        action="preview",
        ip_address=request.client.host if request.client else "unknown"
    )
    
    return slice_data


@router.delete("/studies/{study_id}")
async def delete_study(
    request: Request,
    study_id: int,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(require_permission("write:study"))
):
    """Delete a study and all associated data (requires authentication)"""
    
    from sqlalchemy import select
    
    result = await db.execute(
        select(DicomStudy).where(DicomStudy.id == study_id)
    )
    
    study = result.scalar_one_or_none()
    
    if not study:
        raise HTTPException(status_code=404, detail="Study not found")
    
    study_uid = study.study_uid
    
    # Delete files
    study_path = Path(study.dicom_path)
    if study_path.exists():
        shutil.rmtree(study_path)
    
    # Delete from database
    await db.delete(study)
    await db.commit()
    
    # Log deletion
    AuditLogger.log_dicom_access(
        user_id=str(current_user.id),
        study_id=study_uid,
        action="delete",
        ip_address=request.client.host if request.client else "unknown"
    )
    
    return {"success": True, "message": "Study deleted"}
