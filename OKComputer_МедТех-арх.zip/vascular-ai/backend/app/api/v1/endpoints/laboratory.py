"""
Laboratory Tests API Endpoints
API для работы с лабораторными исследованиями
"""

from datetime import datetime
from typing import List, Optional
from uuid import UUID

from fastapi import APIRouter, Depends, HTTPException, Query, status
from sqlalchemy.ext.asyncio import AsyncSession

from app.api.deps import get_db, get_current_user, require_permissions
from app.laboratory.service import LaboratoryService
from app.laboratory.schemas import (
    LaboratoryTestCreate, LaboratoryTestUpdate, LaboratoryTestResponse,
    LaboratoryTestDetail, LaboratoryTestList, TestResultCreate, TestResultResponse,
    TestResultWithTrend, ReferenceRangeCreate, ReferenceRangeResponse,
    TestPanelCreate, TestPanelResponse, LaboratoryCreate, LaboratoryResponse,
    CriticalValueAlertResponse, CriticalValueAlertAcknowledge,
    LabAnalysisRequest, LabAnalysisResponse, LabComparisonRequest, LabComparisonResponse,
    LabTestSearchParams, TestResultSearchParams, LabStatisticsResponse
)
from app.models import User

router = APIRouter()


# ==================== Laboratory Tests ====================

@router.post(
    "/tests",
    response_model=LaboratoryTestResponse,
    status_code=status.HTTP_201_CREATED,
    summary="Создать лабораторное исследование",
    description="Создание нового заказа на лабораторное исследование"
)
async def create_laboratory_test(
    data: LaboratoryTestCreate,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(require_permissions(["write:laboratory"]))
):
    """
    Создание нового лабораторного исследования.
    
    - **patient_id**: ID пациента
    - **test_codes**: Список кодов тестов
    - **panel_code**: Код панели тестов (опционально)
    - **priority**: Приоритет (routine, urgent, stat)
    - **clinical_indication**: Клинические показания
    """
    service = LaboratoryService(db)
    test = await service.create_test(data, current_user.id)
    return test


@router.get(
    "/tests",
    response_model=LaboratoryTestList,
    summary="Получить список исследований",
    description="Получение списка лабораторных исследований с фильтрацией"
)
async def list_laboratory_tests(
    patient_id: Optional[UUID] = None,
    status: Optional[str] = None,
    date_from: Optional[datetime] = None,
    date_to: Optional[datetime] = None,
    has_critical: Optional[bool] = None,
    page: int = Query(1, ge=1),
    limit: int = Query(20, ge=1, le=100),
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(require_permissions(["read:laboratory"]))
):
    """
    Получение списка лабораторных исследований.
    
    - **patient_id**: Фильтр по пациенту
    - **status**: Фильтр по статусу (ordered, collected, processing, completed, cancelled)
    - **date_from**: Начальная дата
    - **date_to**: Конечная дата
    - **page**: Номер страницы
    - **limit**: Количество на странице
    """
    service = LaboratoryService(db)
    params = LabTestSearchParams(
        patient_id=patient_id,
        status=status,
        date_from=date_from,
        date_to=date_to,
        has_critical=has_critical,
        page=page,
        limit=limit
    )
    tests, total = await service.search_tests(params)
    
    pages = (total + limit - 1) // limit
    
    return LaboratoryTestList(
        items=tests,
        total=total,
        page=page,
        pages=pages
    )


@router.get(
    "/tests/{test_id}",
    response_model=LaboratoryTestDetail,
    summary="Получить детали исследования",
    description="Получение полной информации о лабораторном исследовании"
)
async def get_laboratory_test(
    test_id: UUID,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(require_permissions(["read:laboratory"]))
):
    """Получение детальной информации о лабораторном исследовании."""
    service = LaboratoryService(db)
    detail = await service.get_test_detail(test_id)
    
    if not detail:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Laboratory test not found"
        )
    
    return detail


@router.put(
    "/tests/{test_id}",
    response_model=LaboratoryTestResponse,
    summary="Обновить исследование",
    description="Обновление информации о лабораторном исследовании"
)
async def update_laboratory_test(
    test_id: UUID,
    data: LaboratoryTestUpdate,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(require_permissions(["write:laboratory"]))
):
    """Обновление лабораторного исследования."""
    service = LaboratoryService(db)
    test = await service.update_test(test_id, data)
    
    if not test:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Laboratory test not found"
        )
    
    return test


@router.post(
    "/tests/{test_id}/cancel",
    summary="Отменить исследование",
    description="Отмена лабораторного исследования"
)
async def cancel_laboratory_test(
    test_id: UUID,
    reason: str,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(require_permissions(["write:laboratory"]))
):
    """Отмена лабораторного исследования."""
    service = LaboratoryService(db)
    success = await service.cancel_test(test_id, reason)
    
    if not success:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Cannot cancel this test"
        )
    
    return {"message": "Test cancelled successfully"}


@router.post(
    "/tests/{test_id}/verify",
    summary="Верифицировать результаты",
    description="Подтверждение и верификация результатов исследования"
)
async def verify_test_results(
    test_id: UUID,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(require_permissions(["verify:laboratory"]))
):
    """Верификация результатов лабораторного исследования."""
    service = LaboratoryService(db)
    success = await service.verify_results(test_id, current_user.id)
    
    if not success:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Cannot verify this test"
        )
    
    return {"message": "Results verified successfully"}


# ==================== Test Results ====================

@router.post(
    "/tests/{test_id}/results",
    response_model=TestResultResponse,
    status_code=status.HTTP_201_CREATED,
    summary="Добавить результат",
    description="Добавление результата отдельного теста"
)
async def add_test_result(
    test_id: UUID,
    data: TestResultCreate,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(require_permissions(["write:laboratory"]))
):
    """
    Добавление результата теста.
    
    - **test_code**: Код теста
    - **value_numeric**: Числовое значение
    - **value_text**: Текстовое значение
    - **unit**: Единицы измерения
    """
    service = LaboratoryService(db)
    result = await service.add_result(test_id, data)
    return result


@router.get(
    "/results",
    response_model=List[TestResultResponse],
    summary="Получить результаты пациента",
    description="Получение истории результатов тестов пациента"
)
async def get_patient_results(
    patient_id: UUID,
    test_code: Optional[str] = None,
    category: Optional[str] = None,
    interpretation: Optional[str] = None,
    date_from: Optional[datetime] = None,
    date_to: Optional[datetime] = None,
    limit: int = Query(50, ge=1, le=200),
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(require_permissions(["read:laboratory"]))
):
    """
    Получение результатов тестов пациента.
    
    - **patient_id**: ID пациента
    - **test_code**: Фильтр по коду теста
    - **category**: Фильтр по категории
    - **interpretation**: Фильтр по интерпретации (normal, low, high, critical)
    """
    service = LaboratoryService(db)
    params = TestResultSearchParams(
        patient_id=patient_id,
        test_code=test_code,
        category=category,
        interpretation=interpretation,
        date_from=date_from,
        date_to=date_to,
        limit=limit
    )
    results = await service.get_patient_results(params)
    return results


@router.get(
    "/results/{result_id}",
    response_model=TestResultWithTrend,
    summary="Получить результат с трендом",
    description="Получение результата с историей и трендом"
)
async def get_result_with_trend(
    result_id: UUID,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(require_permissions(["read:laboratory"]))
):
    """Получение результата с историей изменений."""
    # TODO: Реализовать получение результата с трендом
    pass


@router.get(
    "/patients/{patient_id}/history/{test_code}",
    response_model=List[dict],
    summary="Получить историю показателя",
    description="Получение истории значений конкретного показателя"
)
async def get_test_history(
    patient_id: UUID,
    test_code: str,
    limit: int = Query(20, ge=1, le=100),
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(require_permissions(["read:laboratory"]))
):
    """Получение истории значений показателя."""
    service = LaboratoryService(db)
    history = await service.get_result_history(patient_id, test_code, limit)
    return history


# ==================== Reference Ranges ====================

@router.post(
    "/reference-ranges",
    response_model=ReferenceRangeResponse,
    status_code=status.HTTP_201_CREATED,
    summary="Создать референсные значения",
    description="Создание новых референсных значений для теста"
)
async def create_reference_range(
    data: ReferenceRangeCreate,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(require_permissions(["admin:laboratory"]))
):
    """Создание референсных значений."""
    service = LaboratoryService(db)
    ref_range = await service.create_reference_range(data)
    return ref_range


@router.get(
    "/reference-ranges/{test_code}",
    response_model=ReferenceRangeResponse,
    summary="Получить референсные значения",
    description="Получение референсных значений для теста"
)
async def get_reference_range(
    test_code: str,
    gender: Optional[str] = None,
    age_months: Optional[int] = None,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(require_permissions(["read:laboratory"]))
):
    """Получение референсных значений для теста."""
    service = LaboratoryService(db)
    ref_range = await service.get_reference_range(test_code, gender=gender, age_months=age_months)
    
    if not ref_range:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Reference range not found"
        )
    
    return ref_range


# ==================== Test Panels ====================

@router.post(
    "/panels",
    response_model=TestPanelResponse,
    status_code=status.HTTP_201_CREATED,
    summary="Создать панель тестов",
    description="Создание новой панели лабораторных тестов"
)
async def create_test_panel(
    data: TestPanelCreate,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(require_permissions(["admin:laboratory"]))
):
    """Создание панели тестов."""
    service = LaboratoryService(db)
    panel = await service.create_panel(data)
    return panel


@router.get(
    "/panels",
    response_model=List[TestPanelResponse],
    summary="Получить список панелей",
    description="Получение списка доступных панелей тестов"
)
async def list_test_panels(
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(require_permissions(["read:laboratory"]))
):
    """Получение списка панелей тестов."""
    service = LaboratoryService(db)
    panels = await service.get_all_panels()
    return panels


@router.get(
    "/panels/{code}",
    response_model=TestPanelResponse,
    summary="Получить панель",
    description="Получение информации о панели тестов"
)
async def get_test_panel(
    code: str,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(require_permissions(["read:laboratory"]))
):
    """Получение панели тестов по коду."""
    service = LaboratoryService(db)
    panel = await service.get_panel_by_code(code)
    
    if not panel:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Test panel not found"
        )
    
    return panel


# ==================== Analysis ====================

@router.post(
    "/analyze",
    response_model=LabAnalysisResponse,
    summary="Анализ лабораторных данных",
    description="Комплексный анализ лабораторных данных пациента"
)
async def analyze_laboratory_data(
    request: LabAnalysisRequest,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(require_permissions(["read:laboratory"]))
):
    """
    Комплексный анализ лабораторных данных.
    
    - **patient_id**: ID пациента
    - **test_codes**: Список кодов тестов для анализа
    - **date_from**: Начальная дата периода
    - **date_to**: Конечная дата периода
    - **include_trends**: Включить анализ трендов
    - **include_ai_analysis**: Включить AI анализ
    """
    service = LaboratoryService(db)
    analysis = await service.analyze_patient_labs(request)
    return analysis


@router.post(
    "/compare",
    response_model=LabComparisonResponse,
    summary="Сравнить результаты",
    description="Сравнение лабораторных данных на разные даты"
)
async def compare_laboratory_results(
    request: LabComparisonRequest,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(require_permissions(["read:laboratory"]))
):
    """Сравнение лабораторных данных на разные даты."""
    service = LaboratoryService(db)
    comparison = await service.compare_lab_results(request)
    return comparison


# ==================== Statistics ====================

@router.get(
    "/statistics",
    response_model=LabStatisticsResponse,
    summary="Получить статистику",
    description="Получение статистики лабораторных исследований"
)
async def get_laboratory_statistics(
    date_from: datetime,
    date_to: datetime,
    laboratory_id: Optional[UUID] = None,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(require_permissions(["admin:laboratory"]))
):
    """
    Получение статистики лабораторных исследований.
    
    - **date_from**: Начальная дата
    - **date_to**: Конечная дата
    - **laboratory_id**: ID лаборатории (опционально)
    """
    service = LaboratoryService(db)
    stats = await service.get_statistics(laboratory_id, date_from, date_to)
    return stats


# ==================== Critical Values ====================

@router.get(
    "/critical-values",
    response_model=List[CriticalValueAlertResponse],
    summary="Получить критические значения",
    description="Получение списка критических значений"
)
async def list_critical_values(
    patient_id: Optional[UUID] = None,
    status: Optional[str] = "pending",
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(require_permissions(["read:laboratory"]))
):
    """Получение списка критических значений."""
    # TODO: Реализовать получение критических значений
    pass


@router.post(
    "/critical-values/{alert_id}/acknowledge",
    summary="Подтвердить критическое значение",
    description="Подтверждение получения уведомления о критическом значении"
)
async def acknowledge_critical_value(
    alert_id: UUID,
    data: CriticalValueAlertAcknowledge,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(require_permissions(["write:laboratory"]))
):
    """Подтверждение критического значения."""
    # TODO: Реализовать подтверждение
    pass


# ==================== Laboratories ====================

@router.post(
    "/laboratories",
    response_model=LaboratoryResponse,
    status_code=status.HTTP_201_CREATED,
    summary="Создать лабораторию",
    description="Создание новой лаборатории"
)
async def create_laboratory(
    data: LaboratoryCreate,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(require_permissions(["admin:laboratory"]))
):
    """Создание лаборатории."""
    service = LaboratoryService(db)
    lab = await service.create_laboratory(data)
    return lab


@router.get(
    "/laboratories",
    response_model=List[LaboratoryResponse],
    summary="Получить список лабораторий",
    description="Получение списка лабораторий"
)
async def list_laboratories(
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(require_permissions(["read:laboratory"]))
):
    """Получение списка лабораторий."""
    service = LaboratoryService(db)
    labs = await service.get_all_laboratories()
    return labs