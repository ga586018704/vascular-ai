"""
Medical Knowledge Base API Endpoints
API для работы с медицинским справочником
"""

from typing import List, Optional
from uuid import UUID

from fastapi import APIRouter, Depends, HTTPException, Query, status
from sqlalchemy.ext.asyncio import AsyncSession

from app.api.deps import get_db, get_current_user, require_permissions
from app.knowledge_base.service import KnowledgeBaseService
from app.models import User

router = APIRouter()


# ==================== Search ====================

@router.get(
    "/search",
    summary="Поиск в справочнике",
    description="Полнотекстовый поиск по медицинскому справочнику"
)
async def search_knowledge_base(
    q: str = Query(..., min_length=2, description="Поисковый запрос"),
    type: Optional[str] = Query(None, description="Тип статьи (disease, medication, procedure, guideline)"),
    category_id: Optional[UUID] = Query(None, description="ID категории"),
    tags: Optional[List[str]] = Query(None, description="Теги"),
    page: int = Query(1, ge=1),
    limit: int = Query(20, ge=1, le=100),
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(require_permissions(["read:knowledge_base"]))
):
    """
    Поиск по медицинскому справочнику.
    
    - **q**: Поисковый запрос
    - **type**: Фильтр по типу статьи
    - **category_id**: Фильтр по категории
    - **tags**: Фильтр по тегам
    - **page**: Номер страницы
    - **limit**: Количество результатов
    """
    import time
    start_time = time.time()
    
    service = KnowledgeBaseService(db)
    results = await service.search_articles(
        query=q,
        article_type=type,
        category_id=category_id,
        tags=tags,
        page=page,
        limit=limit
    )
    
    response_time = int((time.time() - start_time) * 1000)
    
    # Логирование поиска
    await service.log_search(
        query=q,
        user_id=current_user.id,
        results_count=results["total"],
        response_time_ms=response_time,
        filters={"type": type, "category_id": str(category_id) if category_id else None}
    )
    
    return results


# ==================== Articles ====================

@router.get(
    "/articles/{article_id}",
    summary="Получить статью",
    description="Получение полной информации о статье справочника"
)
async def get_article(
    article_id: UUID,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(require_permissions(["read:knowledge_base"]))
):
    """Получение статьи по ID."""
    service = KnowledgeBaseService(db)
    article = await service.get_article(article_id)
    
    if not article:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Article not found"
        )
    
    # Увеличить счетчик просмотров
    await service.increment_view_count(article_id)
    
    return article


@router.get(
    "/articles/by-code/{code}",
    summary="Получить статью по коду",
    description="Получение статьи по уникальному коду"
)
async def get_article_by_code(
    code: str,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(require_permissions(["read:knowledge_base"]))
):
    """Получение статьи по коду (например, ICD-10)."""
    service = KnowledgeBaseService(db)
    article = await service.get_article_by_code(code)
    
    if not article:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Article not found"
        )
    
    return article


@router.get(
    "/articles/popular",
    summary="Популярные статьи",
    description="Получение списка популярных статей"
)
async def get_popular_articles(
    type: Optional[str] = Query(None, description="Тип статьи"),
    limit: int = Query(10, ge=1, le=50),
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(require_permissions(["read:knowledge_base"]))
):
    """Получение популярных статей."""
    service = KnowledgeBaseService(db)
    articles = await service.get_popular_articles(
        article_type=type,
        limit=limit
    )
    return {"items": articles, "total": len(articles)}


@router.get(
    "/articles/recent",
    summary="Новые статьи",
    description="Получение списка недавно добавленных статей"
)
async def get_recent_articles(
    limit: int = Query(10, ge=1, le=50),
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(require_permissions(["read:knowledge_base"]))
):
    """Получение недавно добавленных статей."""
    service = KnowledgeBaseService(db)
    articles = await service.get_recent_articles(limit=limit)
    return {"items": articles, "total": len(articles)}


# ==================== Categories ====================

@router.get(
    "/categories",
    summary="Категории справочника",
    description="Получение списка категорий медицинского справочника"
)
async def get_categories(
    parent_id: Optional[UUID] = Query(None, description="ID родительской категории"),
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(require_permissions(["read:knowledge_base"]))
):
    """Получение категорий справочника."""
    service = KnowledgeBaseService(db)
    categories = await service.get_categories(parent_id=parent_id)
    return {"items": categories}


@router.get(
    "/categories/tree",
    summary="Дерево категорий",
    description="Получение дерева категорий"
)
async def get_category_tree(
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(require_permissions(["read:knowledge_base"]))
):
    """Получение дерева категорий."""
    service = KnowledgeBaseService(db)
    tree = await service.get_category_tree()
    return {"tree": tree}


@router.get(
    "/categories/{category_id}/articles",
    summary="Статьи категории",
    description="Получение статей по категории"
)
async def get_articles_by_category(
    category_id: UUID,
    page: int = Query(1, ge=1),
    limit: int = Query(20, ge=1, le=100),
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(require_permissions(["read:knowledge_base"]))
):
    """Получение статей по категории."""
    service = KnowledgeBaseService(db)
    results = await service.get_articles_by_category(
        category_id=category_id,
        page=page,
        limit=limit
    )
    return results


# ==================== Tags ====================

@router.get(
    "/tags",
    summary="Теги",
    description="Получение списка тегов"
)
async def get_tags(
    search: Optional[str] = Query(None, description="Поиск тегов"),
    limit: int = Query(50, ge=1, le=100),
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(require_permissions(["read:knowledge_base"]))
):
    """Получение списка тегов."""
    service = KnowledgeBaseService(db)
    tags = await service.get_tags(search=search, limit=limit)
    return {"items": tags}


@router.get(
    "/tags/{tag_code}/articles",
    summary="Статьи по тегу",
    description="Получение статей по тегу"
)
async def get_articles_by_tag(
    tag_code: str,
    page: int = Query(1, ge=1),
    limit: int = Query(20, ge=1, le=100),
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(require_permissions(["read:knowledge_base"]))
):
    """Получение статей по тегу."""
    service = KnowledgeBaseService(db)
    results = await service.get_articles_by_tag(
        tag_code=tag_code,
        page=page,
        limit=limit
    )
    return results


# ==================== Medications ====================

@router.get(
    "/medications/search",
    summary="Поиск препаратов",
    description="Поиск лекарственных препаратов"
)
async def search_medications(
    q: str = Query(..., min_length=2, description="Название препарата"),
    drug_class: Optional[str] = Query(None, description="Класс препарата"),
    limit: int = Query(20, ge=1, le=50),
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(require_permissions(["read:knowledge_base"]))
):
    """Поиск лекарственных препаратов."""
    service = KnowledgeBaseService(db)
    medications = await service.search_medications(
        query=q,
        drug_class=drug_class,
        limit=limit
    )
    return {"items": medications, "total": len(medications)}


@router.get(
    "/medications/{article_id}",
    summary="Информация о препарате",
    description="Получение подробной информации о препарате"
)
async def get_medication(
    article_id: UUID,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(require_permissions(["read:knowledge_base"]))
):
    """Получение информации о препарате."""
    service = KnowledgeBaseService(db)
    medication = await service.get_medication(article_id)
    
    if not medication:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Medication not found"
        )
    
    return medication


@router.post(
    "/medications/check-interactions",
    summary="Проверка взаимодействий",
    description="Проверка лекарственных взаимодействий"
)
async def check_drug_interactions(
    drugs: List[str],
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(require_permissions(["read:knowledge_base"]))
):
    """
    Проверка лекарственных взаимодействий.
    
    - **drugs**: Список кодов препаратов
    """
    service = KnowledgeBaseService(db)
    interactions = await service.check_drug_interactions(drugs)
    return {
        "interactions": interactions,
        "count": len(interactions),
        "has_major_interactions": any(
            i.get("severity") == "major" for i in interactions
        )
    }


# ==================== Diseases ====================

@router.get(
    "/diseases/search",
    summary="Поиск заболеваний",
    description="Поиск заболеваний по названию или ICD-10"
)
async def search_diseases(
    q: str = Query(..., min_length=2, description="Название или код заболевания"),
    body_system: Optional[str] = Query(None, description="Система органов"),
    limit: int = Query(20, ge=1, le=50),
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(require_permissions(["read:knowledge_base"]))
):
    """Поиск заболеваний."""
    service = KnowledgeBaseService(db)
    diseases = await service.search_diseases(
        query=q,
        body_system=body_system,
        limit=limit
    )
    return {"items": diseases, "total": len(diseases)}


@router.get(
    "/diseases/{article_id}",
    summary="Информация о заболевании",
    description="Получение подробной информации о заболевании"
)
async def get_disease(
    article_id: UUID,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(require_permissions(["read:knowledge_base"]))
):
    """Получение информации о заболевании."""
    service = KnowledgeBaseService(db)
    disease = await service.get_disease(article_id)
    
    if not disease:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Disease not found"
        )
    
    return disease


# ==================== Procedures ====================

@router.get(
    "/procedures/search",
    summary="Поиск процедур",
    description="Поиск медицинских процедур"
)
async def search_procedures(
    q: str = Query(..., min_length=2, description="Название процедуры"),
    specialty: Optional[str] = Query(None, description="Специальность"),
    limit: int = Query(20, ge=1, le=50),
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(require_permissions(["read:knowledge_base"]))
):
    """Поиск медицинских процедур."""
    service = KnowledgeBaseService(db)
    procedures = await service.search_procedures(
        query=q,
        specialty=specialty,
        limit=limit
    )
    return {"items": procedures, "total": len(procedures)}


@router.get(
    "/procedures/{article_id}",
    summary="Информация о процедуре",
    description="Получение подробной информации о процедуре"
)
async def get_procedure(
    article_id: UUID,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(require_permissions(["read:knowledge_base"]))
):
    """Получение информации о процедуре."""
    service = KnowledgeBaseService(db)
    procedure = await service.get_procedure(article_id)
    
    if not procedure:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Procedure not found"
        )
    
    return procedure


# ==================== Guidelines ====================

@router.get(
    "/guidelines",
    summary="Клинические руководства",
    description="Получение списка клинических руководств"
)
async def get_guidelines(
    organization: Optional[str] = Query(None, description="Организация (ESVS, SVS, ACC/AHA)"),
    year: Optional[int] = Query(None, description="Год выпуска"),
    page: int = Query(1, ge=1),
    limit: int = Query(20, ge=1, le=100),
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(require_permissions(["read:knowledge_base"]))
):
    """Получение клинических руководств."""
    service = KnowledgeBaseService(db)
    results = await service.get_guidelines(
        organization=organization,
        year=year,
        page=page,
        limit=limit
    )
    return results


@router.get(
    "/guidelines/{article_id}",
    summary="Информация о руководстве",
    description="Получение подробной информации о клиническом руководстве"
)
async def get_guideline(
    article_id: UUID,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(require_permissions(["read:knowledge_base"]))
):
    """Получение информации о клиническом руководстве."""
    service = KnowledgeBaseService(db)
    guideline = await service.get_guideline(article_id)
    
    if not guideline:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Guideline not found"
        )
    
    return guideline


# ==================== Favorites ====================

@router.post(
    "/favorites/{article_id}",
    summary="Добавить в избранное",
    description="Добавление статьи в избранное"
)
async def add_to_favorites(
    article_id: UUID,
    notes: Optional[str] = None,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(require_permissions(["read:knowledge_base"]))
):
    """Добавление статьи в избранное."""
    service = KnowledgeBaseService(db)
    success = await service.add_to_favorites(
        user_id=current_user.id,
        article_id=article_id,
        notes=notes
    )
    
    if not success:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Article already in favorites"
        )
    
    return {"message": "Added to favorites"}


@router.delete(
    "/favorites/{article_id}",
    summary="Удалить из избранного",
    description="Удаление статьи из избранного"
)
async def remove_from_favorites(
    article_id: UUID,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(require_permissions(["read:knowledge_base"]))
):
    """Удаление статьи из избранного."""
    service = KnowledgeBaseService(db)
    success = await service.remove_from_favorites(
        user_id=current_user.id,
        article_id=article_id
    )
    
    if not success:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Article not in favorites"
        )
    
    return {"message": "Removed from favorites"}


@router.get(
    "/favorites",
    summary="Избранные статьи",
    description="Получение избранных статей пользователя"
)
async def get_user_favorites(
    page: int = Query(1, ge=1),
    limit: int = Query(20, ge=1, le=100),
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(require_permissions(["read:knowledge_base"]))
):
    """Получение избранных статей пользователя."""
    service = KnowledgeBaseService(db)
    results = await service.get_user_favorites(
        user_id=current_user.id,
        page=page,
        limit=limit
    )
    return results


# ==================== Quick Reference ====================

@router.get(
    "/quick-reference/{category}",
    summary="Быстрый справочник",
    description="Получение краткого справочника по категории"
)
async def get_quick_reference(
    category: str = Query(..., description="Категория (vascular_emergency, anticoagulation, aaa_sizes)"),
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(require_permissions(["read:knowledge_base"]))
):
    """
    Получение краткого справочника.
    
    Доступные категории:
    - **vascular_emergency**: Сосудистые экстренные состояния
    - **anticoagulation**: Антикоагулянтная терапия
    - **aaa_sizes**: Размеры ААА и показания к лечению
    """
    service = KnowledgeBaseService(db)
    reference = await service.get_quick_reference(category)
    return reference


# ==================== Analytics ====================

@router.get(
    "/analytics/popular-searches",
    summary="Популярные поиски",
    description="Получение статистики популярных поисковых запросов"
)
async def get_popular_searches(
    days: int = Query(30, ge=1, le=365),
    limit: int = Query(20, ge=1, le=100),
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(require_permissions(["admin:knowledge_base"]))
):
    """Получение популярных поисковых запросов."""
    service = KnowledgeBaseService(db)
    searches = await service.get_popular_searches(days=days, limit=limit)
    return {"items": searches}