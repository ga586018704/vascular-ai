"""
VASCULAR.AI - AI Agents API
API endpoints для работы с медицинскими AI-агентами
"""

from typing import List, Optional, Dict, Any
from fastapi import APIRouter, HTTPException, Depends, BackgroundTasks, Request
from pydantic import BaseModel, Field
from sqlalchemy.ext.asyncio import AsyncSession

from app.agents import (
    get_agent,
    get_validator,
    get_consensus_engine,
    analyze_with_agents,
    AgentAnalysis
)
from app.agents.base.medical_agent import EvidenceLevel
from app.api.auth import get_current_active_user, require_permission
from app.models.database import User
from app.core.security import AuditLogger
from app.core.logging import app_logger

router = APIRouter(prefix="/api/agents", tags=["AI Agents"])


# ============== Pydantic Models ==============

class AgentQueryRequest(BaseModel):
    """Запрос к AI-агенту"""
    query: str = Field(..., min_length=10, description="Медицинский запрос/сценарий")
    agent_type: str = Field(default="vascular", description="Тип агента: vascular, phlebology, neuro, endovascular")
    patient_context: Optional[Dict[str, Any]] = Field(default=None, description="Дополнительный контекст пациента")
    include_sources: bool = Field(default=True, description="Включать научные источники")
    min_evidence_level: str = Field(default="IV", description="Минимальный уровень доказательности (Ia, Ib, IIa, IIb, IIIa, IIIb, IV, V)")


class MultiAgentQueryRequest(BaseModel):
    """Запрос к нескольким AI-агентам"""
    query: str = Field(..., min_length=10, description="Медицинский запрос/сценарий")
    agent_types: List[str] = Field(default=["vascular"], description="Список типов агентов")
    patient_context: Optional[Dict[str, Any]] = Field(default=None, description="Дополнительный контекст пациента")
    require_consensus: bool = Field(default=False, description="Требовать консенсус между агентами")


class AgentAnalysisResponse(BaseModel):
    """Ответ с результатом анализа"""
    query: str
    analysis: str
    recommendations: List[str]
    sources: List[Dict[str, Any]]
    confidence_score: float
    evidence_summary: str
    contraindications: List[str]
    alternative_approaches: List[str]
    follow_up_recommendations: List[str]
    agent_type: str
    version: str
    timestamp: str
    validation: Optional[Dict[str, Any]] = None


class MultiAgentResponse(BaseModel):
    """Ответ от нескольких агентов"""
    query: str
    agent_results: List[Dict[str, Any]]
    consensus: Optional[Dict[str, Any]] = None
    total_agents: int
    successful_analyses: int
    requires_human_review: bool


class AvailableAgentInfo(BaseModel):
    """Информация о доступном агенте"""
    id: str
    name: str
    specialty: str
    description: str
    version: str
    capabilities: List[str]


# ============== Endpoints ==============

@router.get("/available", response_model=List[AvailableAgentInfo])
async def get_available_agents(
    current_user: User = Depends(get_current_active_user)
):
    """Получить список доступных AI-агентов"""
    
    agents = [
        AvailableAgentInfo(
            id="vascular",
            name="Vascular Surgery Agent",
            specialty="Сосудистая хирургия",
            description="Анализ случаев сосудистой хирургии: аневризмы, каротидная патология, PAD, мезентериальная ишемия",
            version="1.0.0",
            capabilities=[
                "Анализ ААА (плановые и экстренные)",
                "Оценка каротидного стеноза",
                "Классификация PAD",
                "Расчет риска (VSGNE, GAS)",
                "Рекомендации по лечению"
            ]
        ),
        AvailableAgentInfo(
            id="phlebology",
            name="Phlebology Agent",
            specialty="Флебология",
            description="Анализ венозных заболеваний: варикоз, ДВТ, ТЭЛА, лимфедема",
            version="1.0.0",
            capabilities=[
                "CEAP классификация",
                "Оценка ДВТ (Wells score)",
                "Риск-стратификация ТЭЛА",
                "Рекомендации по антикоагуляции",
                "Управление лимфедемой"
            ]
        ),
        AvailableAgentInfo(
            id="neuro",
            name="Neurointervention Agent",
            specialty="Нейроинтервенция",
            description="Анализ нейроинтервенционных случаев: инсульт, аневризмы, АВМ",
            version="1.0.0",
            capabilities=[
                "Оценка острого инсульта (NIHSS, ASPECTS)",
                "Индикация к тромбэктомии",
                "Оценка внутричерепных аневризм",
                "Spetzler-Martin для АВМ",
                "Рекомендации по CAS"
            ]
        ),
        AvailableAgentInfo(
            id="endovascular",
            name="Endovascular Agent",
            specialty="Эндоваскулярная хирургия",
            description="Анализ эндоваскулярных процедур: EVAR, TEVAR, периферические интервенции",
            version="1.0.0",
            capabilities=[
                "Оценка пригодности EVAR",
                "TASC классификация",
                "Управление endoleak",
                "Планирование доступа",
                "Выбор endograft"
            ]
        )
    ]
    
    return agents


@router.post("/analyze", response_model=AgentAnalysisResponse)
async def analyze_with_agent(
    request: Request,
    query_request: AgentQueryRequest,
    current_user: User = Depends(require_permission("read:ai_agent"))
):
    """
    Анализ медицинского случая с помощью AI-агента
    
    Агент проанализирует запрос и предоставит рекомендации
    на основе актуальных научных данных и клинических guidelines.
    """
    
    # Получаем агента
    try:
        agent = get_agent(query_request.agent_type)
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))
    
    # Преобразуем уровень доказательности
    evidence_level_map = {
        "Ia": EvidenceLevel.IA, "Ib": EvidenceLevel.IB,
        "IIa": EvidenceLevel.IIA, "IIb": EvidenceLevel.IIB,
        "IIIa": EvidenceLevel.IIIA, "IIIb": EvidenceLevel.IIIB,
        "IV": EvidenceLevel.IV, "V": EvidenceLevel.V
    }
    min_evidence = evidence_level_map.get(query_request.min_evidence_level, EvidenceLevel.IV)
    
    # Выполняем анализ
    try:
        analysis = await agent.analyze(
            query=query_request.query,
            patient_context=query_request.patient_context,
            include_sources=query_request.include_sources,
            min_evidence_level=min_evidence
        )
    except Exception as e:
        app_logger.error(f"Agent analysis error: {e}")
        raise HTTPException(status_code=500, detail=f"Analysis failed: {str(e)}")
    
    # Валидация результата
    validator = get_validator()
    validation = await validator.validate(analysis)
    
    # Логирование
    AuditLogger.log_data_modification(
        user_id=str(current_user.id),
        table="agent_analysis",
        record_id=f"{query_request.agent_type}_{hash(query_request.query) & 0xFFFFFFFF}",
        action="analyze",
        changes={
            "agent_type": query_request.agent_type,
            "confidence": analysis.confidence_score,
            "validation_status": validation.is_valid
        },
        ip_address=request.client.host if request.client else "unknown"
    )
    
    return AgentAnalysisResponse(
        query=analysis.query,
        analysis=analysis.analysis,
        recommendations=analysis.recommendations,
        sources=[s.to_dict() for s in analysis.sources],
        confidence_score=analysis.confidence_score,
        evidence_summary=analysis.evidence_summary,
        contraindications=analysis.contraindications,
        alternative_approaches=analysis.alternative_approaches,
        follow_up_recommendations=analysis.follow_up_recommendations,
        agent_type=analysis.agent_type,
        version=analysis.version,
        timestamp=analysis.timestamp.isoformat(),
        validation=validation.to_dict()
    )


@router.post("/analyze-multi", response_model=MultiAgentResponse)
async def analyze_with_multiple_agents(
    request: Request,
    query_request: MultiAgentQueryRequest,
    current_user: User = Depends(require_permission("read:ai_agent"))
):
    """
    Анализ медицинского случая с помощью нескольких AI-агентов
    
    Полезно для сложных случаев, требующих многодисциплинарного подхода.
    """
    
    # Выполняем множественный анализ
    try:
        result = await analyze_with_agents(
            query=query_request.query,
            agent_types=query_request.agent_types,
            patient_context=query_request.patient_context,
            require_consensus=query_request.require_consensus
        )
    except Exception as e:
        app_logger.error(f"Multi-agent analysis error: {e}")
        raise HTTPException(status_code=500, detail=f"Analysis failed: {str(e)}")
    
    # Логирование
    AuditLogger.log_data_modification(
        user_id=str(current_user.id),
        table="agent_analysis",
        record_id=f"multi_{hash(query_request.query) & 0xFFFFFFFF}",
        action="analyze_multi",
        changes={
            "agent_types": query_request.agent_types,
            "require_consensus": query_request.require_consensus
        },
        ip_address=request.client.host if request.client else "unknown"
    )
    
    # Определяем необходимость человеческой проверки
    requires_human_review = False
    if result.get("consensus"):
        requires_human_review = result["consensus"].get("requires_human_review", False)
    
    return MultiAgentResponse(
        query=result["query"],
        agent_results=result["agent_results"],
        consensus=result.get("consensus"),
        total_agents=result["total_agents"],
        successful_analyses=result["successful_analyses"],
        requires_human_review=requires_human_review
    )


@router.post("/validate")
async def validate_agent_output(
    request: Request,
    analysis_data: Dict[str, Any],
    current_user: User = Depends(require_permission("read:ai_agent"))
):
    """
    Валидация вывода AI-агента
    
    Проверяет корректность рекомендаций и выявляет потенциальные проблемы.
    """
    
    from app.agents.base.medical_agent import AgentAnalysis, ScientificSource
    
    # Восстанавливаем объект анализа
    try:
        sources = [ScientificSource(**s) for s in analysis_data.get("sources", [])]
        analysis = AgentAnalysis(
            query=analysis_data["query"],
            analysis=analysis_data["analysis"],
            recommendations=analysis_data["recommendations"],
            sources=sources,
            confidence_score=analysis_data["confidence_score"],
            evidence_summary=analysis_data.get("evidence_summary", ""),
            contraindications=analysis_data.get("contraindications", []),
            alternative_approaches=analysis_data.get("alternative_approaches", []),
            follow_up_recommendations=analysis_data.get("follow_up_recommendations", []),
            agent_type=analysis_data.get("agent_type", "unknown"),
            version=analysis_data.get("version", "1.0")
        )
    except Exception as e:
        raise HTTPException(status_code=400, detail=f"Invalid analysis data: {str(e)}")
    
    # Валидация
    validator = get_validator()
    validation = await validator.validate(analysis)
    
    return validation.to_dict()


@router.get("/statistics")
async def get_agent_statistics(
    current_user: User = Depends(get_current_active_user)
):
    """Получить статистику использования агентов"""
    
    # Собираем статистику от всех агентов
    stats = {
        "agents": {},
        "validation": {},
        "timestamp": datetime.utcnow().isoformat()
    }
    
    for agent_type in ["vascular", "phlebology", "neuro", "endovascular"]:
        try:
            agent = get_agent(agent_type)
            stats["agents"][agent_type] = agent.get_analysis_statistics()
        except Exception as e:
            stats["agents"][agent_type] = {"error": str(e)}
    
    # Статистика валидации
    validator = get_validator()
    stats["validation"] = validator.get_validation_statistics()
    
    return stats


@router.post("/update-knowledge")
async def update_agent_knowledge(
    request: Request,
    background_tasks: BackgroundTasks,
    agent_type: Optional[str] = None,
    current_user: User = Depends(require_permission("write:system"))
):
    """
    Обновить базу знаний агентов
    
    Требует прав администратора. Обновление выполняется в фоновом режиме.
    """
    
    async def update_knowledge_task(agent_types: List[str]):
        """Фоновая задача обновления"""
        for at in agent_types:
            try:
                agent = get_agent(at)
                await agent.update_knowledge_base()
                app_logger.info(f"Updated knowledge base for {at} agent")
            except Exception as e:
                app_logger.error(f"Failed to update {at} agent: {e}")
    
    agent_types = [agent_type] if agent_type else ["vascular", "phlebology", "neuro", "endovascular"]
    
    background_tasks.add_task(update_knowledge_task, agent_types)
    
    return {
        "message": "Knowledge base update started",
        "agents": agent_types,
        "status": "processing"
    }


@router.get("/guidelines/{condition}")
async def get_clinical_guidelines(
    condition: str,
    source: Optional[str] = None,
    current_user: User = Depends(get_current_active_user)
):
    """
    Получить клинические рекомендации по заболеванию
    
    Args:
        condition: Заболевание (например, aortic-aneurysm, dvt, stroke)
        source: Источник (ESVS, SVS, ACC/AHA) - если не указан, возвращает все
    """
    
    from app.agents.knowledge.scientific_integrator import ClinicalGuidelinesIntegrator
    
    integrator = ClinicalGuidelinesIntegrator()
    
    sources = [source] if source else ["ESVS", "SVS", "ACC_AHA"]
    
    guidelines = await integrator.get_guidelines(condition, sources)
    
    return {
        "condition": condition,
        "sources": sources,
        "guidelines": guidelines,
        "timestamp": datetime.utcnow().isoformat()
    }


@router.post("/search-literature")
async def search_scientific_literature(
    request: Request,
    query: str,
    max_results: int = 10,
    min_year: Optional[int] = None,
    include_guidelines: bool = True,
    current_user: User = Depends(get_current_active_user)
):
    """
    Поиск в научной литературе
    
    Выполняет поиск в PubMed и клинических guidelines.
    """
    
    from app.agents.knowledge.scientific_integrator import ScientificKnowledgeManager
    
    manager = ScientificKnowledgeManager()
    
    try:
        results = await manager.search_literature(
            query=query,
            max_results=max_results,
            min_year=min_year,
            include_guidelines=include_guidelines
        )
    except Exception as e:
        app_logger.error(f"Literature search error: {e}")
        raise HTTPException(status_code=500, detail=f"Search failed: {str(e)}")
    
    return {
        "query": query,
        "pubmed_results": [s.to_dict() for s in results.get("pubmed", [])],
        "guidelines": results.get("guidelines", []),
        "total_results": len(results.get("pubmed", [])) + len(results.get("guidelines", []))
    }
