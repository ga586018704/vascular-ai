"""
API endpoints для TASC классификации и выбора протеза/шунта
"""

from typing import Optional, List
from fastapi import APIRouter, HTTPException, Depends, Body
from sqlalchemy.ext.asyncio import AsyncSession
from pydantic import BaseModel

from app.models.database import get_db, TASCEvaluation, GraftSelection
from app.services.clinical_guidelines_ru import (
    TASC_II_CLASSIFICATION,
    GRAFT_SELECTION_GUIDE,
    get_tasc_classification,
    recommend_graft
)
from app.api.auth import get_current_user

router = APIRouter(prefix="/api/clinical", tags=["TASC & Graft Selection"])


# ==================== TASC CLASSIFICATION ====================

class TASCEvaluationRequest(BaseModel):
    lesion_type: str  # aortoiliac, femoropopliteal, infrapopliteal
    lesion_description: str
    study_id: Optional[int] = None


class TASCEvaluationResponse(BaseModel):
    lesion_type: str
    lesion_description: str
    tasc_class: str
    treatment_recommendation: str
    alternative_treatment: Optional[str]
    evidence: Optional[str]
    indications: Optional[List[str]]
    contraindications: Optional[List[str]]


@router.post("/tasc/evaluate", response_model=TASCEvaluationResponse)
async def evaluate_tasc(
    request: TASCEvaluationRequest,
    user=Depends(get_current_user),
    db: AsyncSession = Depends(get_db)
):
    """
    Оценка по классификации TASC II
    
    Параметры:
    - lesion_type: тип поражения (aortoiliac, femoropopliteal, infrapopliteal)
    - lesion_description: описание поражения
    - study_id: ID исследования (опционально)
    """
    
    # Валидация типа поражения
    valid_types = ["aortoiliac", "femoropopliteal", "infrapopliteal"]
    if request.lesion_type not in valid_types:
        raise HTTPException(
            status_code=400,
            detail=f"Invalid lesion type. Must be one of: {', '.join(valid_types)}"
        )
    
    # Получение классификации
    result = get_tasc_classification(request.lesion_type, request.lesion_description)
    
    # Получение подробной информации из справочника
    tasc_data = TASC_II_CLASSIFICATION.get(request.lesion_type, {})
    class_data = tasc_data.get(f"type_{result['tasc_class'].lower()}", {}) if result['tasc_class'] else {}
    
    # Формирование ответа
    response = TASCEvaluationResponse(
        lesion_type=request.lesion_type,
        lesion_description=request.lesion_description,
        tasc_class=result.get("tasc_class", "Unknown"),
        treatment_recommendation=result.get("treatment_recommendation") or class_data.get("treatment", "Требуется индивидуальная оценка"),
        alternative_treatment=class_data.get("alternative"),
        evidence=result.get("evidence") or class_data.get("recommendation"),
        indications=class_data.get("description") if isinstance(class_data.get("description"), list) else None,
        contraindications=None
    )
    
    # Сохранение в БД если указан study_id
    if request.study_id:
        tasc_eval = TASCEvaluation(
            study_id=request.study_id,
            lesion_type=request.lesion_type,
            tasc_class=response.tasc_class,
            lesion_description=request.lesion_description,
            treatment_recommendation=response.treatment_recommendation,
            alternative_treatment=response.alternative_treatment,
            evidence_level=response.evidence
        )
        db.add(tasc_eval)
        await db.commit()
    
    return response


@router.get("/tasc/classification/{lesion_type}")
async def get_tasc_details(lesion_type: str):
    """
    Получение подробной информации о TASC классификации для типа поражения
    
    lesion_type: aortoiliac, femoropopliteal, infrapopliteal
    """
    
    valid_types = ["aortoiliac", "femoropopliteal", "infrapopliteal"]
    if lesion_type not in valid_types:
        raise HTTPException(
            status_code=400,
            detail=f"Invalid lesion type. Must be one of: {', '.join(valid_types)}"
        )
    
    tasc_data = TASC_II_CLASSIFICATION.get(lesion_type, {})
    
    return {
        "lesion_type": lesion_type,
        "name": tasc_data.get("name"),
        "classes": {
            "A": tasc_data.get("type_a"),
            "B": tasc_data.get("type_b"),
            "C": tasc_data.get("type_c"),
            "D": tasc_data.get("type_d")
        }
    }


@router.get("/tasc/all")
async def get_all_tasc_classifications():
    """Получение полной классификации TASC II"""
    
    return {
        "tasc_ii": TASC_II_CLASSIFICATION,
        "note": "TASC II - TransAtlantic Inter-Society Consensus II Classification"
    }


# ==================== GRAFT SELECTION ====================

class GraftSelectionRequest(BaseModel):
    procedure_type: str
    patient_age: int
    expected_survival: str  # long, moderate, short
    vein_available: bool
    vein_diameter: Optional[float] = None
    vein_quality: Optional[str] = None  # good, varicose, thrombosed
    urgency: str = "elective"  # elective, urgent, emergency
    study_id: Optional[int] = None


class GraftSelectionResponse(BaseModel):
    primary_recommendation: str
    alternatives: List[str]
    rationale: List[str]
    patency_expectations: dict
    special_considerations: List[str]


@router.post("/graft/recommend", response_model=GraftSelectionResponse)
async def recommend_graft_endpoint(
    request: GraftSelectionRequest,
    user=Depends(get_current_user),
    db: AsyncSession = Depends(get_db)
):
    """
    Рекомендация по выбору протеза/шунта
    
    Параметры:
    - procedure_type: тип процедуры (femoropopliteal, aortobifemoral, carotid, etc.)
    - patient_age: возраст пациента
    - expected_survival: ожидаемая выживаемость (long, moderate, short)
    - vein_available: доступность вены
    - vein_diameter: диаметр вены (мм)
    - vein_quality: качество вены (good, varicose, thrombosed)
    - urgency: срочность (elective, urgent, emergency)
    """
    
    # Получение рекомендации
    result = recommend_graft(
        procedure_type=request.procedure_type,
        patient_age=request.patient_age,
        expected_survival=request.expected_survival,
        vein_available=request.vein_available,
        vein_diameter=request.vein_diameter,
        vein_quality=request.vein_quality,
        urgency=request.urgency
    )
    
    # Сохранение в БД если указан study_id
    if request.study_id:
        graft_sel = GraftSelection(
            study_id=request.study_id,
            procedure_type=request.procedure_type,
            primary_graft=result["primary_recommendation"],
            alternative_grafts=result.get("alternatives"),
            rationale=result.get("rationale"),
            patency_expectations=result.get("patency_expectations"),
            special_considerations=result.get("special_considerations")
        )
        db.add(graft_sel)
        await db.commit()
    
    return GraftSelectionResponse(
        primary_recommendation=result["primary_recommendation"],
        alternatives=result.get("alternatives", []),
        rationale=result.get("rationale", []),
        patency_expectations=result.get("patency_expectations", {}),
        special_considerations=result.get("special_considerations", [])
    )


@router.get("/graft/prostheses")
async def get_prosthesis_guide():
    """Получение справочника по протезам"""
    
    return {
        "aortic_prostheses": GRAFT_SELECTION_GUIDE["aortic_prostheses"],
        "comparison": GRAFT_SELECTION_GUIDE["aortic_prostheses"]["comparison"]
    }


@router.get("/graft/venous-vs-prosthetic")
async def get_venous_vs_prosthetic_guide():
    """Сравнение венозных и протетических шунтов"""
    
    return GRAFT_SELECTION_GUIDE["venous_vs_prosthetic"]


@router.get("/graft/patches")
async def get_patch_guide():
    """Справочник по заплатам"""
    
    return GRAFT_SELECTION_GUIDE["patch_selection"]


@router.get("/graft/all")
async def get_complete_graft_guide():
    """Полный справочник по выбору протезов/шунтов"""
    
    return GRAFT_SELECTION_GUIDE


# ==================== RUSSIAN CLINICAL GUIDELINES ====================

@router.get("/russian-guidelines")
async def get_russian_clinical_guidelines():
    """Получение российских клинических рекомендаций"""
    
    from app.services.clinical_guidelines_ru import RUSSIAN_CLINICAL_GUIDELINES
    
    return {
        "russian_guidelines": RUSSIAN_CLINICAL_GUIDELINES,
        "source": "Клинические рекомендации РФ 2025"
    }


@router.get("/russian-guidelines/{condition}")
async def get_russian_guideline_detail(condition: str):
    """Получение конкретной российской клинической рекомендации"""
    
    from app.services.clinical_guidelines_ru import RUSSIAN_CLINICAL_GUIDELINES
    
    if condition not in RUSSIAN_CLINICAL_GUIDELINES:
        raise HTTPException(
            status_code=404,
            detail=f"Guideline not found. Available: {', '.join(RUSSIAN_CLINICAL_GUIDELINES.keys())}"
        )
    
    return {
        "condition": condition,
        "guideline": RUSSIAN_CLINICAL_GUIDELINES[condition]
    }


# ==================== PHLEBOLOGY ====================

@router.get("/phlebology/ceap")
async def get_ceap_classification():
    """Получение классификации CEAP"""
    
    from app.services.clinical_guidelines_ru import PHLEBOLOGY_GUIDE
    
    return {
        "ceap_classification": PHLEBOLOGY_GUIDE["ceap_classification"],
        "note": "CEAP - Clinical, Etiological, Anatomical, Pathophysiological"
    }


@router.get("/phlebology/treatment")
async def get_phlebology_treatment_methods():
    """Методы лечения в флебологии"""
    
    from app.services.clinical_guidelines_ru import PHLEBOLOGY_GUIDE
    
    return {
        "treatment_methods": PHLEBOLOGY_GUIDE["treatment_methods"],
        "compression_therapy": PHLEBOLOGY_GUIDE["compression_therapy"],
        "pharmacotherapy": PHLEBOLOGY_GUIDE["pharmacotherapy"]
    }


@router.get("/phlebology/dvt")
async def get_dvt_management():
    """Управление тромбозом глубоких вен"""
    
    from app.services.clinical_guidelines_ru import PHLEBOLOGY_GUIDE
    
    return {
        "deep_vein_thrombosis": PHLEBOLOGY_GUIDE["deep_vein_thrombosis"],
        "post_thrombotic_syndrome": PHLEBOLOGY_GUIDE["post_thrombotic_syndrome"]
    }


@router.get("/phlebology/all")
async def get_complete_phlebology_guide():
    """Полный справочник по флебологии"""
    
    from app.services.clinical_guidelines_ru import PHLEBOLOGY_GUIDE
    
    return PHLEBOLOGY_GUIDE


# ==================== STUDY TYPES ====================

@router.get("/study-types")
async def get_study_types_guide():
    """Справочник по типам исследований"""
    
    from app.services.clinical_guidelines_ru import STUDY_TYPES
    
    return {
        "study_types": STUDY_TYPES,
        "recommendations": {
            "aortic_pathology": ["ct_angio", "mra", "echo"],
            "peripheral_arterial": ["duplex_us", "ct_angio"],
            "varicose_veins": ["duplex_us"],
            "carotid_stenosis": ["duplex_us"],
            "dissection": ["ct_angio", "mra", "echo"]
        }
    }
