"""
VASCULAR.AI - Voice API
API endpoints for voice-to-text and medical dictation
"""

from typing import Optional
from fastapi import APIRouter, WebSocket, WebSocketDisconnect, UploadFile, File, Form, HTTPException
from fastapi.responses import JSONResponse

from app.services.voice_service import get_voice_service, get_dictation_processor
from app.agents.llm_integration import get_llm_analyzer, StreamingMedicalAnalyzer
from app.api.auth import get_current_active_user
from app.models.database import User

router = APIRouter(prefix="/api/voice", tags=["Voice"])


@router.post("/transcribe")
async def transcribe_audio(
    audio: UploadFile = File(...),
    language: str = Form(default="ru"),
    report_type: Optional[str] = Form(default=None),
    current_user: User = Depends(get_current_active_user)
):
    """
    Transcribe audio file to text
    
    Args:
        audio: Audio file (WAV, MP3, M4A)
        language: Language code (ru, en)
        report_type: Type of medical report (optional)
    
    Returns:
        Transcription result
    """
    
    try:
        # Read audio file
        audio_bytes = await audio.read()
        
        # Get transcription service
        voice_service = get_voice_service()
        
        if report_type:
            # Use medical dictation processor
            dictation_processor = get_dictation_processor()
            
            # Save to temp file
            import tempfile
            import os
            
            with tempfile.NamedTemporaryFile(delete=False, suffix='.wav') as tmp:
                tmp.write(audio_bytes)
                tmp_path = tmp.name
            
            try:
                result = await dictation_processor.dictate_report(
                    tmp_path,
                    report_type=report_type,
                    language=language
                )
                return result
            finally:
                os.unlink(tmp_path)
        else:
            # Simple transcription
            result = await voice_service.transcribe_bytes(
                audio_bytes,
                filename=audio.filename,
                language=language
            )
            
            return {
                "transcription": result.text,
                "confidence": result.confidence,
                "language": result.language,
                "duration_seconds": result.duration_seconds,
                "timestamp": result.timestamp.isoformat()
            }
            
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Transcription failed: {str(e)}")


@router.websocket("/dictate")
async def dictate_websocket(websocket: WebSocket):
    """
    WebSocket endpoint for real-time dictation
    
    Connect to this endpoint to stream audio for real-time transcription.
    
    Protocol:
    - Send audio chunks as binary messages
    - Send JSON control messages: {"action": "finalize"} to get final result
    - Receive JSON responses: {"type": "partial|final", "text": "..."}
    """
    
    await websocket.accept()
    
    try:
        dictation_processor = get_dictation_processor()
        await dictation_processor.dictate_realtime(websocket)
    except WebSocketDisconnect:
        pass
    except Exception as e:
        await websocket.send_json({"type": "error", "message": str(e)})


@router.post("/analyze")
async def analyze_with_llm(
    case_description: str,
    patient_data: Optional[dict] = None,
    provider: str = "openai",
    current_user: User = Depends(get_current_active_user)
):
    """
    Analyze medical case using LLM (GPT-4/Claude)
    
    Args:
        case_description: Description of the clinical case
        patient_data: Additional patient information
        provider: LLM provider (openai, anthropic)
    
    Returns:
        Structured analysis results
    """
    
    try:
        analyzer = get_llm_analyzer(provider)
        result = await analyzer.analyze_case(case_description, patient_data)
        return result
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Analysis failed: {str(e)}")


@router.websocket("/analyze-stream")
async def analyze_streaming_websocket(websocket: WebSocket):
    """
    WebSocket endpoint for streaming LLM analysis
    
    Send: {"case_description": "...", "patient_data": {...}, "provider": "openai"}
    Receive: Stream of analysis text chunks
    """
    
    await websocket.accept()
    
    try:
        # Receive initial message
        data = await websocket.receive_json()
        case_description = data.get("case_description", "")
        patient_data = data.get("patient_data")
        provider = data.get("provider", "openai")
        
        # Create streaming analyzer
        streaming_analyzer = StreamingMedicalAnalyzer(provider)
        
        # Stream results
        async for chunk in streaming_analyzer.analyze_case_streaming(
            case_description, patient_data
        ):
            await websocket.send_text(chunk)
        
        # Send completion signal
        await websocket.send_json({"type": "complete"})
        
    except WebSocketDisconnect:
        pass
    except Exception as e:
        await websocket.send_json({"type": "error", "message": str(e)})


@router.post("/generate-report")
async def generate_report_with_llm(
    study_data: dict,
    findings: list,
    template: str = "standard",
    provider: str = "openai",
    current_user: User = Depends(get_current_active_user)
):
    """
    Generate structured medical report using LLM
    
    Args:
        study_data: Study information
        findings: List of findings
        template: Report template (standard, detailed, brief)
        provider: LLM provider
    
    Returns:
        Generated report text
    """
    
    try:
        analyzer = get_llm_analyzer(provider)
        report = await analyzer.generate_report(study_data, findings, template)
        return {"report": report}
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Report generation failed: {str(e)}")


@router.post("/ask")
async def ask_medical_question(
    question: str,
    context: Optional[str] = None,
    provider: str = "openai",
    current_user: User = Depends(get_current_active_user)
):
    """
    Ask a medical question to the AI
    
    Args:
        question: The question to answer
        context: Additional context
        provider: LLM provider
    
    Returns:
        Answer text
    """
    
    try:
        analyzer = get_llm_analyzer(provider)
        answer = await analyzer.answer_question(question, context)
        return {"answer": answer}
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Question answering failed: {str(e)}")
