"""
API endpoints для работы с медицинскими исследованиями разных типов
"""

from typing import List, Optional
from fastapi import APIRouter, UploadFile, File, Form, HTTPException, Depends, Query
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, desc
import shutil
import os
from datetime import datetime
from pathlib import Path

from app.models.database import get_db, MedicalStudy, UltrasoundMeasurement, EchocardiographyMeasurement, TASCEvaluation
from app.core.config import get_settings
from app.api.auth import get_current_user

router = APIRouter(prefix="/api/studies", tags=["Studies"])
settings = get_settings()


@router.post("/upload")
async def upload_study(
    file: UploadFile = File(...),
    study_type: str = Form(...),  # ct_angio, mra, duplex_us, echo, dicom_legacy
    patient_id: str = Form(...),
    study_description: Optional[str] = Form(None),
    study_date: Optional[str] = Form(None),
    user=Depends(get_current_user),
    db: AsyncSession = Depends(get_db)
):
    """
    Загрузка медицинского исследования любого типа
    
    Поддерживаемые типы:
    - ct_angio: КТ-ангиография
    - mra: МР-ангиография
    - duplex_us: Дуплексное УЗИ
    - echo: Эхокардиография
    - dicom_legacy: DICOM (обратная совместимость)
    """
    
    # Проверка типа исследования
    valid_types = ["ct_angio", "mra", "duplex_us", "echo", "dicom_legacy"]
    if study_type not in valid_types:
        raise HTTPException(
            status_code=400, 
            detail=f"Invalid study type. Must be one of: {', '.join(valid_types)}"
        )
    
    # Определение модальности
    modality_map = {
        "ct_angio": "CT",
        "mra": "MRI",
        "duplex_us": "US",
        "echo": "Echo",
        "dicom_legacy": "CT"
    }
    modality = modality_map.get(study_type, "CT")
    
    # Создание директории для хранения
    upload_dir = Path(settings.UPLOAD_DIR) / study_type / str(user.id)
    upload_dir.mkdir(parents=True, exist_ok=True)
    
    # Генерация уникального имени файла
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    file_ext = Path(file.filename).suffix
    unique_filename = f"{patient_id}_{timestamp}{file_ext}"
    file_path = upload_dir / unique_filename
    
    # Сохранение файла
    try:
        with open(file_path, "wb") as buffer:
            shutil.copyfileobj(file.file, buffer)
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Failed to save file: {str(e)}")
    
    # Парсинг даты исследования
    parsed_date = None
    if study_date:
        try:
            parsed_date = datetime.fromisoformat(study_date)
        except:
            pass
    
    # Создание записи в БД
    study = MedicalStudy(
        user_id=user.id,
        patient_id=patient_id,
        study_uid=f"{study_type}_{patient_id}_{timestamp}",
        study_date=parsed_date,
        study_description=study_description,
        study_type=study_type,
        modality=modality,
        file_path=str(file_path),
        status="uploaded"
    )
    
    db.add(study)
    await db.commit()
    await db.refresh(study)
    
    return {
        "success": True,
        "study_id": study.id,
        "study_type": study_type,
        "modality": modality,
        "file_path": str(file_path),
        "message": "Study uploaded successfully"
    }


@router.get("/")
async def list_studies(
    study_type: Optional[str] = Query(None),
    modality: Optional[str] = Query(None),
    patient_id: Optional[str] = Query(None),
    limit: int = Query(50, ge=1, le=100),
    offset: int = Query(0, ge=0),
    user=Depends(get_current_user),
    db: AsyncSession = Depends(get_db)
):
    """Получение списка исследований с фильтрацией"""
    
    query = select(MedicalStudy).where(MedicalStudy.user_id == user.id)
    
    if study_type:
        query = query.where(MedicalStudy.study_type == study_type)
    if modality:
        query = query.where(MedicalStudy.modality == modality)
    if patient_id:
        query = query.where(MedicalStudy.patient_id == patient_id)
    
    query = query.order_by(desc(MedicalStudy.created_at)).offset(offset).limit(limit)
    
    result = await db.execute(query)
    studies = result.scalars().all()
    
    return {
        "studies": [
            {
                "id": s.id,
                "patient_id": s.patient_id,
                "study_type": s.study_type,
                "modality": s.modality,
                "study_description": s.study_description,
                "study_date": s.study_date.isoformat() if s.study_date else None,
                "status": s.status,
                "num_images": s.num_images,
                "created_at": s.created_at.isoformat()
            }
            for s in studies
        ],
        "total": len(studies),
        "offset": offset,
        "limit": limit
    }


@router.get("/{study_id}")
async def get_study(
    study_id: int,
    user=Depends(get_current_user),
    db: AsyncSession = Depends(get_db)
):
    """Получение детальной информации об исследовании"""
    
    result = await db.execute(
        select(MedicalStudy).where(
            MedicalStudy.id == study_id,
            MedicalStudy.user_id == user.id
        )
    )
    study = result.scalar_one_or_none()
    
    if not study:
        raise HTTPException(status_code=404, detail="Study not found")
    
    # Получение специфичных измерений в зависимости от типа
    measurements = {}
    
    if study.study_type == "duplex_us":
        us_result = await db.execute(
            select(UltrasoundMeasurement).where(UltrasoundMeasurement.study_id == study_id)
        )
        us_measurements = us_result.scalars().all()
        measurements["ultrasound"] = [
            {
                "vessel_name": m.vessel_name,
                "vessel_side": m.vessel_side,
                "diameter_mm": m.diameter_mm,
                "stenosis_percent": m.stenosis_percent,
                "peak_systolic_velocity": m.peak_systolic_velocity,
                "reflux_present": m.reflux_present,
                "abi": m.abi
            }
            for m in us_measurements
        ]
    
    elif study.study_type == "echo":
        echo_result = await db.execute(
            select(EchocardiographyMeasurement).where(EchocardiographyMeasurement.study_id == study_id)
        )
        echo_measurements = echo_result.scalars().all()
        measurements["echocardiography"] = [
            {
                "echo_type": m.echo_type,
                "aortic_root_diameter": m.aortic_root_diameter,
                "ascending_aorta_diameter": m.ascending_aorta_diameter,
                "lvef": m.lvef,
                "dissection_present": m.dissection_present,
                "dissection_type": m.dissection_type
            }
            for m in echo_measurements
        ]
    
    return {
        "id": study.id,
        "patient_id": study.patient_id,
        "study_type": study.study_type,
        "modality": study.modality,
        "study_description": study.study_description,
        "study_date": study.study_date.isoformat() if study.study_date else None,
        "status": study.status,
        "num_images": study.num_images,
        "metadata": study.metadata,
        "measurements": measurements,
        "created_at": study.created_at.isoformat(),
        "updated_at": study.updated_at.isoformat()
    }


@router.post("/{study_id}/measurements/ultrasound")
async def add_ultrasound_measurements(
    study_id: int,
    measurements: List[dict],
    user=Depends(get_current_user),
    db: AsyncSession = Depends(get_db)
):
    """Добавление измерений УЗИ"""
    
    # Проверка существования исследования
    result = await db.execute(
        select(MedicalStudy).where(
            MedicalStudy.id == study_id,
            MedicalStudy.user_id == user.id
        )
    )
    study = result.scalar_one_or_none()
    
    if not study:
        raise HTTPException(status_code=404, detail="Study not found")
    
    # Добавление измерений
    for m in measurements:
        us_measurement = UltrasoundMeasurement(
            study_id=study_id,
            us_type=m.get("us_type", "carotid"),
            vessel_name=m.get("vessel_name"),
            vessel_side=m.get("vessel_side"),
            diameter_mm=m.get("diameter_mm"),
            imt_mm=m.get("imt_mm"),
            peak_systolic_velocity=m.get("peak_systolic_velocity"),
            end_diastolic_velocity=m.get("end_diastolic_velocity"),
            mean_velocity=m.get("mean_velocity"),
            abi=m.get("abi"),
            pi=m.get("pi"),
            ri=m.get("ri"),
            stenosis_percent=m.get("stenosis_percent"),
            stenosis_type=m.get("stenosis_type"),
            reflux_duration_sec=m.get("reflux_duration_sec"),
            reflux_present=m.get("reflux_present", False),
            vein_diameter_mm=m.get("vein_diameter_mm"),
            pathology=m.get("pathology")
        )
        db.add(us_measurement)
    
    await db.commit()
    
    return {
        "success": True,
        "message": f"Added {len(measurements)} ultrasound measurements"
    }


@router.post("/{study_id}/measurements/echo")
async def add_echo_measurements(
    study_id: int,
    measurements: dict,
    user=Depends(get_current_user),
    db: AsyncSession = Depends(get_db)
):
    """Добавление измерений ЭхоКГ"""
    
    # Проверка существования исследования
    result = await db.execute(
        select(MedicalStudy).where(
            MedicalStudy.id == study_id,
            MedicalStudy.user_id == user.id
        )
    )
    study = result.scalar_one_or_none()
    
    if not study:
        raise HTTPException(status_code=404, detail="Study not found")
    
    echo_measurement = EchocardiographyMeasurement(
        study_id=study_id,
        echo_type=measurements.get("echo_type", "TTE"),
        aortic_root_diameter=measurements.get("aortic_root_diameter"),
        ascending_aorta_diameter=measurements.get("ascending_aorta_diameter"),
        aortic_arch_diameter=measurements.get("aortic_arch_diameter"),
        descending_aorta_diameter=measurements.get("descending_aorta_diameter"),
        aortic_valve_area=measurements.get("aortic_valve_area"),
        aortic_regurgitation_grade=measurements.get("aortic_regurgitation_grade"),
        lvedd=measurements.get("lvedd"),
        lvesd=measurements.get("lvesd"),
        lvef=measurements.get("lvef"),
        dissection_present=measurements.get("dissection_present", False),
        dissection_type=measurements.get("dissection_type"),
        intimal_flap=measurements.get("intimal_flap", False),
        false_lumen=measurements.get("false_lumen", False),
        pericardial_effusion=measurements.get("pericardial_effusion", False),
        additional_findings=measurements.get("additional_findings")
    )
    
    db.add(echo_measurement)
    await db.commit()
    
    return {
        "success": True,
        "message": "Echocardiography measurements added"
    }


@router.get("/types/list")
async def get_study_types():
    """Получение списка поддерживаемых типов исследований"""
    
    return {
        "study_types": [
            {
                "id": "ct_angio",
                "name": "КТ-ангиография",
                "modality": "CT",
                "description": "Компьютерная томография с контрастированием сосудов",
                "best_for": [
                    "Аневризмы аорты",
                    "Расслоение аорты",
                    "Окклюзии артерий",
                    "Планирование EVAR/TEVAR"
                ]
            },
            {
                "id": "mra",
                "name": "МР-ангиография",
                "modality": "MRI",
                "description": "Магнитно-резонансная ангиография",
                "best_for": [
                    "Расслоение аорты",
                    "Интрамуральная гематома",
                    "Повторные исследования",
                    "Молодые пациенты"
                ]
            },
            {
                "id": "duplex_us",
                "name": "Дуплексное УЗИ",
                "modality": "US",
                "description": "Ультразвуковое дуплексное сканирование",
                "best_for": [
                    "Каротидные артерии",
                    "Варикозная болезнь",
                    "Диагностика ТГВ",
                    "Контроль после операций",
                    "АКШ (ABI)"
                ]
            },
            {
                "id": "echo",
                "name": "Эхокардиография",
                "modality": "Echo",
                "description": "Ультразвуковое исследование сердца и аорты",
                "best_for": [
                    "Аортальный клапан",
                    "Восходящая аорта",
                    "Дуга аорты",
                    "Корень аорты",
                    "Функция ЛЖ"
                ],
                "types": ["TTE - трансторакальная", "TEE - трансэзофагеальная"]
            }
        ]
    }


# Импорт зависимости auth
from app.api.auth import get_current_user
