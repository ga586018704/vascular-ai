import os
from datetime import datetime
from typing import List, Optional
from fastapi import APIRouter, HTTPException, Depends, Body
from fastapi.responses import FileResponse
from sqlalchemy.ext.asyncio import AsyncSession

from app.models.database import get_db, DicomStudy, Segmentation, OperationProtocol
from app.services.protocol_service import protocol_service

router = APIRouter(prefix="/api/protocols", tags=["Protocols"])


@router.get("/types")
async def get_protocol_types():
    """Get all available operation protocol types"""
    
    return {
        "types": protocol_service.get_available_protocols()
    }


@router.get("/categories")
async def get_protocol_categories():
    """Get protocols grouped by categories"""
    
    categories = {
        "open_surgery": "Открытые операции",
        "endovascular": "Эндоваскулярные операции"
    }
    
    result = {}
    for cat_id, cat_name in categories.items():
        result[cat_id] = {
            "name": cat_name,
            "protocols": protocol_service.get_protocols_by_category(cat_id)
        }
    
    return result


@router.get("/category/{category}")
async def get_protocols_by_category(category: str):
    """Get protocols by category"""
    
    valid_categories = ["open_surgery", "endovascular"]
    
    if category not in valid_categories:
        raise HTTPException(status_code=400, detail=f"Invalid category. Valid: {valid_categories}")
    
    return {
        "category": category,
        "protocols": protocol_service.get_protocols_by_category(category)
    }


@router.post("/generate")
async def generate_protocol(
    data: dict = Body(...),
    db: AsyncSession = Depends(get_db)
):
    """Generate operation protocol"""
    
    from sqlalchemy import select
    
    study_id = data.get("study_id")
    protocol_type = data.get("protocol_type")
    surgeon_name = data.get("surgeon_name", "Хирург")
    notes = data.get("notes", "")
    
    if not study_id or not protocol_type:
        raise HTTPException(status_code=400, detail="study_id and protocol_type required")
    
    # Get study
    result = await db.execute(
        select(DicomStudy).where(DicomStudy.id == study_id)
    )
    study = result.scalar_one_or_none()
    
    if not study:
        raise HTTPException(status_code=404, detail="Study not found")
    
    # Get segmentation measurements
    seg_result = await db.execute(
        select(Segmentation).where(Segmentation.study_id == study_id)
        .order_by(Segmentation.created_at.desc())
    )
    segmentation = seg_result.scalars().first()
    
    measurements = segmentation.measurements if segmentation else {}
    
    # Prepare patient data
    patient_data = {
        "id": study.patient_id,
        "study_uid": study.study_uid,
        "modality": study.modality,
        "num_slices": study.num_slices,
    }
    
    # Generate protocol
    try:
        protocol_content = protocol_service.generate_protocol(
            protocol_type=protocol_type,
            patient_data=patient_data,
            measurements=measurements,
            surgeon_name=surgeon_name,
            notes=notes
        )
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))
    
    # Save to database
    protocol = OperationProtocol(
        user_id=1,  # TODO: Get from auth
        study_id=study_id,
        segmentation_id=segmentation.id if segmentation else None,
        protocol_type=protocol_type,
        title=protocol_content["title"],
        content=protocol_content,
        status="generated"
    )
    
    db.add(protocol)
    await db.commit()
    await db.refresh(protocol)
    
    # Generate HTML
    html_filename = f"protocol_{protocol.id}_{datetime.now().strftime('%Y%m%d_%H%M%S')}.html"
    html_path = await protocol_service.generate_pdf(protocol_content, html_filename)
    
    protocol.pdf_path = html_path
    await db.commit()
    
    return {
        "success": True,
        "protocol_id": protocol.id,
        "protocol": protocol_content,
        "download_url": f"/api/protocols/{protocol.id}/download"
    }


@router.get("/list")
async def list_protocols(
    skip: int = 0,
    limit: int = 10,
    db: AsyncSession = Depends(get_db)
):
    """List generated protocols"""
    
    from sqlalchemy import select
    
    result = await db.execute(
        select(OperationProtocol)
        .order_by(OperationProtocol.created_at.desc())
        .offset(skip)
        .limit(limit)
    )
    
    protocols = result.scalars().all()
    
    return {
        "protocols": [
            {
                "id": p.id,
                "title": p.title,
                "protocol_type": p.protocol_type,
                "study_id": p.study_id,
                "status": p.status,
                "created_at": p.created_at.isoformat() if p.created_at else None,
                "download_url": f"/api/protocols/{p.id}/download" if p.pdf_path else None
            }
            for p in protocols
        ]
    }


@router.get("/{protocol_id}")
async def get_protocol(
    protocol_id: int,
    db: AsyncSession = Depends(get_db)
):
    """Get protocol details"""
    
    from sqlalchemy import select
    
    result = await db.execute(
        select(OperationProtocol).where(OperationProtocol.id == protocol_id)
    )
    
    protocol = result.scalar_one_or_none()
    
    if not protocol:
        raise HTTPException(status_code=404, detail="Protocol not found")
    
    return {
        "id": protocol.id,
        "title": protocol.title,
        "protocol_type": protocol.protocol_type,
        "content": protocol.content,
        "status": protocol.status,
        "surgeon_notes": protocol.surgeon_notes,
        "created_at": protocol.created_at.isoformat() if protocol.created_at else None,
        "updated_at": protocol.updated_at.isoformat() if protocol.updated_at else None,
        "download_url": f"/api/protocols/{protocol.id}/download" if protocol.pdf_path else None
    }


@router.get("/{protocol_id}/download")
async def download_protocol(
    protocol_id: int,
    db: AsyncSession = Depends(get_db)
):
    """Download protocol HTML"""
    
    from sqlalchemy import select
    
    result = await db.execute(
        select(OperationProtocol).where(OperationProtocol.id == protocol_id)
    )
    
    protocol = result.scalar_one_or_none()
    
    if not protocol:
        raise HTTPException(status_code=404, detail="Protocol not found")
    
    if not protocol.pdf_path or not os.path.exists(protocol.pdf_path):
        raise HTTPException(status_code=404, detail="Protocol file not found")
    
    return FileResponse(
        protocol.pdf_path,
        media_type="text/html",
        filename=f"protocol_{protocol.id}.html"
    )


@router.put("/{protocol_id}")
async def update_protocol(
    protocol_id: int,
    data: dict = Body(...),
    db: AsyncSession = Depends(get_db)
):
    """Update protocol (add surgeon notes, etc.)"""
    
    from sqlalchemy import select
    
    result = await db.execute(
        select(OperationProtocol).where(OperationProtocol.id == protocol_id)
    )
    
    protocol = result.scalar_one_or_none()
    
    if not protocol:
        raise HTTPException(status_code=404, detail="Protocol not found")
    
    # Update fields
    if "surgeon_notes" in data:
        protocol.surgeon_notes = data["surgeon_notes"]
    
    if "status" in data:
        protocol.status = data["status"]
    
    # Update content if provided
    if "content" in data:
        protocol.content = {**protocol.content, **data["content"]}
    
    await db.commit()
    await db.refresh(protocol)
    
    return {
        "success": True,
        "protocol_id": protocol.id,
        "status": protocol.status
    }


@router.delete("/{protocol_id}")
async def delete_protocol(
    protocol_id: int,
    db: AsyncSession = Depends(get_db)
):
    """Delete protocol"""
    
    from sqlalchemy import select
    
    result = await db.execute(
        select(OperationProtocol).where(OperationProtocol.id == protocol_id)
    )
    
    protocol = result.scalar_one_or_none()
    
    if not protocol:
        raise HTTPException(status_code=404, detail="Protocol not found")
    
    # Delete HTML file if exists
    if protocol.pdf_path and os.path.exists(protocol.pdf_path):
        os.remove(protocol.pdf_path)
    
    await db.delete(protocol)
    await db.commit()
    
    return {"success": True, "message": "Protocol deleted"}
