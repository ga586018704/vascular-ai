from typing import Dict, Any, List, Optional
from fastapi import APIRouter, HTTPException, Depends, Body
from sqlalchemy.ext.asyncio import AsyncSession

from app.models.database import get_db, DicomStudy, Segmentation
from app.services.ai_decision_support import get_ai_decision_support

router = APIRouter(prefix="/api/ai", tags=["AI Recommendations"])


@router.post("/analyze-case/{study_id}")
async def analyze_case(
    study_id: int,
    patient_data: Dict[str, Any] = Body(...),
    pathology_type: str = Body("aortic_aneurysm"),
    db: AsyncSession = Depends(get_db)
):
    """
    Полный AI-анализ случая с рекомендациями на основе ESVS 2024 Guidelines
    """
    from sqlalchemy import select
    
    # Получаем исследование
    result = await db.execute(
        select(DicomStudy).where(DicomStudy.id == study_id)
    )
    study = result.scalar_one_or_none()
    
    if not study:
        raise HTTPException(status_code=404, detail="Study not found")
    
    # Получаем результаты сегментации
    seg_result = await db.execute(
        select(Segmentation).where(Segmentation.study_id == study_id)
        .order_by(Segmentation.created_at.desc())
    )
    segmentation = seg_result.scalars().first()
    
    # Формируем данные измерений
    ct_measurements = segmentation.measurements if segmentation else {}
    
    # Добавляем данные пациента в измерения для полного анализа
    ct_measurements["patient"] = {
        "gender": patient_data.get("gender", "male"),
        "age": patient_data.get("age", 65)
    }
    
    # Получаем AI сервис
    ai_service = get_ai_decision_support()
    
    # Запускаем AI-анализ
    analysis = ai_service.analyze_case(
        patient_data=patient_data,
        ct_measurements=ct_measurements,
        pathology_type=pathology_type
    )
    
    return {
        "success": True,
        "study_id": study_id,
        "pathology_type": pathology_type,
        "analysis": analysis,
        "esvs_compliance": analysis.get("esvs_2024_compliance", {}),
        "evidence_base": analysis.get("evidence_base", {})
    }


@router.post("/analyze-case-direct")
async def analyze_case_direct(
    patient_data: Dict[str, Any] = Body(...),
    ct_measurements: Dict[str, Any] = Body({}),
    pathology_type: str = Body("aortic_aneurysm")
):
    """
    Прямой AI-анализ без привязки к исследованию
    """
    ai_service = get_ai_decision_support()
    
    analysis = ai_service.analyze_case(
        patient_data=patient_data,
        ct_measurements=ct_measurements,
        pathology_type=pathology_type
    )
    
    return {
        "success": True,
        "pathology_type": pathology_type,
        "analysis": analysis
    }


@router.post("/risk-assessment")
async def calculate_risk(
    patient_data: Dict[str, Any] = Body(...),
    pathology_type: str = Body("aortic_aneurysm")
):
    """
    Расчет хирургических рисков с учетом ACC/AHA 2024
    """
    from app.services.ai_decision_support import (
        PatientRiskProfile, SurgicalRiskCalculator, RiskLevel
    )
    
    # Определяем уровень сердечного риска
    cardiac_risk_str = patient_data.get("cardiac_risk", "low")
    try:
        cardiac_risk = RiskLevel(cardiac_risk_str)
    except:
        cardiac_risk = RiskLevel.LOW
    
    # Создаем профиль риска с расширенными параметрами
    risk_profile = PatientRiskProfile(
        age=patient_data.get("age", 65),
        bmi=patient_data.get("bmi", 25.0),
        comorbidities=patient_data.get("comorbidities", []),
        cardiac_risk=cardiac_risk,
        renal_function=patient_data.get("renal_function", "normal"),
        egfr=patient_data.get("egfr"),
        pulmonary_status=patient_data.get("pulmonary_status", "normal"),
        previous_surgeries=patient_data.get("previous_surgeries", []),
        medications=patient_data.get("medications", []),
        allergies=patient_data.get("allergies", []),
        functional_status=patient_data.get("functional_status", "independent"),
        frailty_score=patient_data.get("frailty_score"),
        das_score=patient_data.get("das_score"),
        smoking_status=patient_data.get("smoking_status", "never"),
        family_history_aaa=patient_data.get("family_history_aaa", False),
        genetic_syndrome=patient_data.get("genetic_syndrome")
    )
    
    # Расчет рисков
    calculator = SurgicalRiskCalculator()
    risks = calculator.calculate(risk_profile, pathology_type)
    
    return {
        "success": True,
        "risk_assessment": risks,
        "overall_risk_score": risks.get("overall_score"),
        "risk_stratification": risks.get("risk_stratification"),
        "risk_modification": risks.get("risk_modification_suggestions", [])
    }


@router.post("/approach-recommendation")
async def recommend_approach(
    patient_data: Dict[str, Any] = Body(...),
    ct_measurements: Dict[str, Any] = Body({}),
    pathology_type: str = Body("aortic_aneurysm")
):
    """
    Рекомендация по выбору метода операции с учетом ESVS 2024 критериев
    """
    from app.services.ai_decision_support import (
        PatientRiskProfile, AnatomicalFeatures, ApproachSelector, 
        RiskLevel, ESVS_2024_RECOMMENDATIONS
    )
    
    # Определяем уровень сердечного риска
    cardiac_risk_str = patient_data.get("cardiac_risk", "low")
    try:
        cardiac_risk = RiskLevel(cardiac_risk_str)
    except:
        cardiac_risk = RiskLevel.LOW
    
    # Создаем профили
    risk_profile = PatientRiskProfile(
        age=patient_data.get("age", 65),
        bmi=patient_data.get("bmi", 25.0),
        comorbidities=patient_data.get("comorbidities", []),
        cardiac_risk=cardiac_risk,
        renal_function=patient_data.get("renal_function", "normal"),
        egfr=patient_data.get("egfr"),
        pulmonary_status=patient_data.get("pulmonary_status", "normal"),
        previous_surgeries=patient_data.get("previous_surgeries", []),
        medications=patient_data.get("medications", []),
        allergies=patient_data.get("allergies", []),
        functional_status=patient_data.get("functional_status", "independent"),
        frailty_score=patient_data.get("frailty_score"),
        das_score=patient_data.get("das_score"),
        smoking_status=patient_data.get("smoking_status", "never"),
        family_history_aaa=patient_data.get("family_history_aaa", False),
        genetic_syndrome=patient_data.get("genetic_syndrome")
    )
    
    anatomical = AnatomicalFeatures(
        vessel_diameter_mm=ct_measurements.get("vessel_diameter_mm", 0),
        vessel_tortuosity=ct_measurements.get("vessel_tortuosity", "straight"),
        calcification_degree=ct_measurements.get("calcification_degree", "none"),
        thrombus_presence=ct_measurements.get("thrombus_presence", False),
        aneurysm_neck_length_mm=ct_measurements.get("aneurysm_neck_length_mm"),
        aneurysm_angulation=ct_measurements.get("aneurysm_angulation"),
        landing_zone_quality=ct_measurements.get("landing_zone_quality", "good"),
        access_vessel_quality=ct_measurements.get("access_vessel_quality", "good"),
        neck_diameter_mm=ct_measurements.get("neck_diameter_mm"),
        neck_angulation=ct_measurements.get("neck_angulation"),
        iliac_artery_diameter_mm=ct_measurements.get("iliac_artery_diameter_mm"),
        iliac_artery_tortuosity=ct_measurements.get("iliac_artery_tortuosity", "straight"),
        infrarenal_neck_length=ct_measurements.get("infrarenal_neck_length"),
        suprarenal_neck_angle=ct_measurements.get("suprarenal_neck_angle"),
        aortic_bifurcation_diameter=ct_measurements.get("aortic_bifurcation_diameter")
    )
    
    # Выбор подхода с учетом ESVS 2024
    selector = ApproachSelector()
    recommendation = selector.select(
        risk_profile, anatomical, pathology_type, ESVS_2024_RECOMMENDATIONS
    )
    
    # Проверка соответствия ESVS критериям для EVAR
    evar_criteria = ESVS_2024_RECOMMENDATIONS.get("evar_anatomical_criteria", {})
    evar_suitability = {
        "neck_length_ok": (anatomical.infrarenal_neck_length or 0) >= evar_criteria.get("infrarenal_neck_length_min", 10),
        "neck_angle_ok": (anatomical.neck_angulation or 0) <= evar_criteria.get("neck_angulation_max", 60),
        "neck_diameter_ok": (anatomical.neck_diameter_mm or 0) <= evar_criteria.get("infrarenal_neck_diameter_max", 32),
        "access_vessel_ok": anatomical.vessel_diameter_mm >= evar_criteria.get("access_artery_diameter_min", 6)
    }
    
    return {
        "success": True,
        "recommendation": recommendation,
        "evar_anatomical_suitability": evar_suitability,
        "esvs_criteria": evar_criteria
    }


@router.post("/access-plan")
async def plan_access(
    pathology_type: str = Body(...),
    approach_type: str = Body(...),
    ct_measurements: Dict[str, Any] = Body({})
):
    """
    Планирование хирургического доступа
    """
    from app.services.ai_decision_support import (
        AnatomicalFeatures, AccessPlanner
    )
    
    anatomical = AnatomicalFeatures(
        vessel_diameter_mm=ct_measurements.get("vessel_diameter_mm", 0),
        vessel_tortuosity=ct_measurements.get("vessel_tortuosity", "straight"),
        calcification_degree=ct_measurements.get("calcification_degree", "none"),
        thrombus_presence=ct_measurements.get("thrombus_presence", False),
        aneurysm_neck_length_mm=ct_measurements.get("aneurysm_neck_length_mm"),
        aneurysm_angulation=ct_measurements.get("aneurysm_angulation"),
        landing_zone_quality=ct_measurements.get("landing_zone_quality", "good"),
        access_vessel_quality=ct_measurements.get("access_vessel_quality", "good"),
        neck_diameter_mm=ct_measurements.get("neck_diameter_mm"),
        neck_angulation=ct_measurements.get("neck_angulation"),
        iliac_artery_diameter_mm=ct_measurements.get("iliac_artery_diameter_mm"),
        iliac_artery_tortuosity=ct_measurements.get("iliac_artery_tortuosity", "straight"),
        infrarenal_neck_length=ct_measurements.get("infrarenal_neck_length"),
        suprarenal_neck_angle=ct_measurements.get("suprarenal_neck_angle"),
        aortic_bifurcation_diameter=ct_measurements.get("aortic_bifurcation_diameter")
    )
    
    approach = {"type": approach_type}
    
    planner = AccessPlanner()
    access_plan = planner.plan(anatomical, approach, pathology_type)
    
    return {
        "success": True,
        "access_plan": access_plan
    }


@router.post("/outcome-prediction")
async def predict_outcome(
    patient_data: Dict[str, Any] = Body(...),
    ct_measurements: Dict[str, Any] = Body({}),
    approach_type: str = Body("open")
):
    """
    Прогнозирование исходов операции
    """
    from app.services.ai_decision_support import (
        PatientRiskProfile, AnatomicalFeatures, OutcomePredictor, RiskLevel
    )
    
    cardiac_risk_str = patient_data.get("cardiac_risk", "low")
    try:
        cardiac_risk = RiskLevel(cardiac_risk_str)
    except:
        cardiac_risk = RiskLevel.LOW
    
    risk_profile = PatientRiskProfile(
        age=patient_data.get("age", 65),
        bmi=patient_data.get("bmi", 25.0),
        comorbidities=patient_data.get("comorbidities", []),
        cardiac_risk=cardiac_risk,
        renal_function=patient_data.get("renal_function", "normal"),
        egfr=patient_data.get("egfr"),
        pulmonary_status=patient_data.get("pulmonary_status", "normal"),
        previous_surgeries=patient_data.get("previous_surgeries", []),
        medications=patient_data.get("medications", []),
        allergies=patient_data.get("allergies", []),
        functional_status=patient_data.get("functional_status", "independent"),
        frailty_score=patient_data.get("frailty_score"),
        das_score=patient_data.get("das_score"),
        smoking_status=patient_data.get("smoking_status", "never"),
        family_history_aaa=patient_data.get("family_history_aaa", False),
        genetic_syndrome=patient_data.get("genetic_syndrome")
    )
    
    anatomical = AnatomicalFeatures(
        vessel_diameter_mm=ct_measurements.get("vessel_diameter_mm", 0),
        vessel_tortuosity=ct_measurements.get("vessel_tortuosity", "straight"),
        calcification_degree=ct_measurements.get("calcification_degree", "none"),
        thrombus_presence=ct_measurements.get("thrombus_presence", False),
        aneurysm_neck_length_mm=ct_measurements.get("aneurysm_neck_length_mm"),
        aneurysm_angulation=ct_measurements.get("aneurysm_angulation"),
        landing_zone_quality=ct_measurements.get("landing_zone_quality", "good"),
        access_vessel_quality=ct_measurements.get("access_vessel_quality", "good"),
        neck_diameter_mm=ct_measurements.get("neck_diameter_mm"),
        neck_angulation=ct_measurements.get("neck_angulation"),
        iliac_artery_diameter_mm=ct_measurements.get("iliac_artery_diameter_mm"),
        iliac_artery_tortuosity=ct_measurements.get("iliac_artery_tortuosity", "straight"),
        infrarenal_neck_length=ct_measurements.get("infrarenal_neck_length"),
        suprarenal_neck_angle=ct_measurements.get("suprarenal_neck_angle"),
        aortic_bifurcation_diameter=ct_measurements.get("aortic_bifurcation_diameter")
    )
    
    approach = {"type": approach_type}
    
    predictor = OutcomePredictor()
    prediction = predictor.predict(risk_profile, anatomical, approach)
    
    return {
        "success": True,
        "prediction": prediction
    }


@router.post("/check-rare-pathology")
async def check_rare_pathology(
    patient_data: Dict[str, Any] = Body(...),
    ct_measurements: Dict[str, Any] = Body({})
):
    """
    Проверка на редкие патологии (микотические аневризмы, vEDS, и т.д.)
    """
    from app.services.ai_decision_support import get_ai_decision_support
    
    ai_service = get_ai_decision_support()
    rare_pathology_check = ai_service._check_rare_pathologies(patient_data, ct_measurements)
    
    return {
        "success": True,
        "rare_pathology_alerts": rare_pathology_check or [],
        "requires_special_attention": len(rare_pathology_check or []) > 0
    }


@router.get("/pathology-types")
async def get_pathology_types():
    """
    Получение списка типов патологий с классами срочности
    """
    return {
        "pathologies": [
            # Аортальные
            {"id": "aortic_aneurysm", "name": "Аневризма брюшной аорты", "urgency": "Элективная", "esvs_class": "Class I, Level A"},
            {"id": "aortic_aneurysm_rupture", "name": "Разрыв аневризмы аорты", "urgency": "Экстренная", "esvs_class": "Class I, Level A"},
            {"id": "mycotic_aneurysm", "name": "Микотическая аневризма", "urgency": "Срочная", "esvs_class": "Class I, Level C"},
            {"id": "inflammatory_aaa", "name": "Воспалительная ААА", "urgency": "Элективная", "esvs_class": "Class IIa, Level B"},
            
            # Сонные артерии
            {"id": "carotid_stenosis", "name": "Асимптоматический стеноз сонной артерии", "urgency": "Элективная", "esvs_class": "Class IIa, Level A"},
            {"id": "carotid_stenosis_symptomatic", "name": "Симптоматический стеноз сонной артерии", "urgency": "Срочная", "esvs_class": "Class I, Level A"},
            
            # Периферические артерии
            {"id": "femoropopliteal_occlusion", "name": "Окклюзия бедренно-подколенного сегмента", "urgency": "Элективная", "esvs_class": "Class I, Level A"},
            {"id": "femoropopliteal_occlusion_critical", "name": "Критическая ишемия нижней конечности", "urgency": "Срочная", "esvs_class": "Class I, Level A"},
            {"id": "acute_arterial_thrombosis", "name": "Острый артериальный тромбоз", "urgency": "Экстренная", "esvs_class": "Class I, Level A"},
            
            # Венозные
            {"id": "acute_deep_vein_thrombosis", "name": "Острый тромбоз глубоких вен", "urgency": "Срочная", "esvs_class": "Class I, Level A"},
            {"id": "varicose_veins", "name": "Варикозная болезнь", "urgency": "Элективная", "esvs_class": "Class I, Level A"},
            
            # Диализный доступ
            {"id": "av_fistula_failure", "name": "Тромбоз АВ-фистулы", "urgency": "Срочная", "esvs_class": "Class I, Level A"},
            {"id": "av_fistula_creation", "name": "Создание АВ-фистулы", "urgency": "Элективная", "esvs_class": "Class I, Level A"},
            
            # Редкие патологии
            {"id": "marfan_aorta", "name": "Аневризма аорты при синдроме Марфана", "urgency": "Элективная", "esvs_class": "Class I, Level B"},
            {"id": "veds_aorta", "name": "Аневризма аорты при vEDS", "urgency": "Элективная", "esvs_class": "Class IIa, Level C"},
        ]
    }


@router.get("/esvs-2024-criteria")
async def get_esvs_2024_criteria():
    """
    Получение критериев ESVS 2024 для различных патологий
    """
    from app.services.ai_decision_support import ESVS_2024_RECOMMENDATIONS
    
    return {
        "esvs_2024": ESVS_2024_RECOMMENDATIONS,
        "key_points": [
            "Порог для операции на ААА: 55 мм (мужчины), 50 мм (женщины) - Class I, Level A",
            "EVAR предпочтительно для рваных ААА при подходящей анатомии - Class I, Level A",
            "Минимальный объем центра: 30 операций на ААА в год - Class I, Level B",
            "Симптоматический стеноз сонной артерии >70% - показание к CEA - Class I, Level A",
            "Двойная антиагрегация после стентирования минимум 1 месяц - Class I, Level A"
        ]
    }


@router.get("/rare-pathologies")
async def get_rare_pathologies():
    """
    Получение информации о редких патологиях
    """
    from app.services.ai_decision_support import RARE_PATHOLOGIES
    
    return {
        "rare_pathologies": RARE_PATHOLOGIES,
        "genetic_syndromes": [
            {
                "id": "marfan",
                "name": "Синдром Марфана",
                "gene": "FBN1",
                "aortic_threshold": 50,
                "surgical_risk": "Повышенный"
            },
            {
                "id": "vascular_ehlers_danlos",
                "name": "Сосудистый синдром Элерса-Данло",
                "gene": "COL3A1",
                "aortic_threshold": None,
                "surgical_risk": "Очень высокий (50-70%)"
            },
            {
                "id": "loeyes_dietz",
                "name": "Синдром Лойса-Дитца",
                "gene": "TGFBR1/2",
                "aortic_threshold": 42,
                "surgical_risk": "Очень высокий"
            }
        ]
    }


@router.post("/preoperative-plan")
async def generate_preoperative_plan(
    patient_data: Dict[str, Any] = Body(...),
    pathology_type: str = Body("aortic_aneurysm")
):
    """
    Генерация плана предоперационной подготовки
    """
    from app.services.ai_decision_support import (
        PatientRiskProfile, RiskLevel, get_ai_decision_support
    )
    
    cardiac_risk_str = patient_data.get("cardiac_risk", "low")
    try:
        cardiac_risk = RiskLevel(cardiac_risk_str)
    except:
        cardiac_risk = RiskLevel.LOW
    
    risk_profile = PatientRiskProfile(
        age=patient_data.get("age", 65),
        bmi=patient_data.get("bmi", 25.0),
        comorbidities=patient_data.get("comorbidities", []),
        cardiac_risk=cardiac_risk,
        renal_function=patient_data.get("renal_function", "normal"),
        egfr=patient_data.get("egfr"),
        pulmonary_status=patient_data.get("pulmonary_status", "normal"),
        previous_surgeries=patient_data.get("previous_surgeries", []),
        medications=patient_data.get("medications", []),
        allergies=patient_data.get("allergies", []),
        functional_status=patient_data.get("functional_status", "independent"),
        frailty_score=patient_data.get("frailty_score"),
        das_score=patient_data.get("das_score"),
        smoking_status=patient_data.get("smoking_status", "never"),
        family_history_aaa=patient_data.get("family_history_aaa", False),
        genetic_syndrome=patient_data.get("genetic_syndrome")
    )
    
    ai_service = get_ai_decision_support()
    preop_plan = ai_service._generate_preop_plan(risk_profile, pathology_type)
    
    return {
        "success": True,
        "preoperative_plan": preop_plan
    }


@router.post("/surveillance-plan")
async def generate_surveillance_plan(
    pathology_type: str = Body(...),
    measurements: Dict[str, Any] = Body({})
):
    """
    Генерация плана наблюдения согласно ESVS 2024
    """
    from app.services.ai_decision_support import get_ai_decision_support
    
    ai_service = get_ai_decision_support()
    surveillance = ai_service._generate_surveillance_plan(pathology_type, measurements)
    
    return {
        "success": True,
        "surveillance_plan": surveillance
    }
