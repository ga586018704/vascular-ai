"""
API endpoints для расширенных инструментов VASCULAR.AI
Включает vascular access, 3D measurements, vascular lab, trauma, pediatric, checklists
"""

from typing import Optional, List
from fastapi import APIRouter, HTTPException, Depends, Body
from pydantic import BaseModel

from app.services.vascular_access import (
    get_dialysis_access_recommendation,
    get_endovascular_access_plan,
    DIALYSIS_ACCESS_GUIDE,
    ENDOVASCULAR_ACCESS_GUIDE,
    TEVAR_EVAR_ACCESS
)
from app.services.measurements_3d import (
    calculate_evar_sizing,
    calculate_tevAR_sizing,
    get_measurement_checklist,
    EVAR_MEASUREMENTS,
    TEVAR_MEASUREMENTS
)
from app.services.vascular_lab import (
    interpret_abi,
    interpret_segmental_pressures,
    interpret_doppler_velocities,
    get_vascular_lab_checklist,
    ABI_INTERPRETATION,
    DOPPLER_VELOCIMETRY
)
from app.services.trauma_protocols import (
    assess_neck_trauma,
    manage_extremity_vascular_trauma,
    get_trauma_checklist,
    VASCULAR_TRAUMA_CLASSIFICATION,
    NECK_TRAUMA,
    EXTREMITY_VASCULAR_TRAUMA
)
from app.services.pediatric_vascular import (
    calculate_pediatric_aortic_diameter,
    assess_coarctation,
    get_pediatric_vascular_access_recommendation,
    PEDIATRIC_NORMAL_VALUES,
    CONGENITAL_VASCULAR_ANOMALIES
)
from app.services.preop_checklist import (
    get_preop_checklist,
    get_sign_in_checklist,
    get_time_out_checklist,
    get_sign_out_checklist,
    WHO_SAFETY_CHECKLIST,
    PROCEDURE_SPECIFIC_CHECKLISTS
)

router = APIRouter(prefix="/api/advanced", tags=["Advanced Tools"])


# ==================== VASCULAR ACCESS ====================

class DialysisAccessRequest(BaseModel):
    cephalic_vein_diameter: float
    basilic_vein_diameter: float
    radial_artery_diameter: float
    brachial_artery_diameter: float
    previous_accesses: List[str] = []
    age: int
    diabetes: bool = False


@router.post("/vascular-access/dialysis")
async def dialysis_access_recommendation(request: DialysisAccessRequest):
    """
    Рекомендация по выбору диализного доступа
    """
    patient_data = {
        "cephalic_vein_diameter": request.cephalic_vein_diameter,
        "basilic_vein_diameter": request.basilic_vein_diameter,
        "radial_artery_diameter": request.radial_artery_diameter,
        "brachial_artery_diameter": request.brachial_artery_diameter,
        "previous_accesses": request.previous_accesses
    }
    
    result = get_dialysis_access_recommendation(patient_data)
    
    return {
        "success": True,
        "recommendation": result
    }


@router.get("/vascular-access/dialysis/guide")
async def dialysis_access_guide():
    """
    Полное руководство по диализному доступу
    """
    return {
        "guide": DIALYSIS_ACCESS_GUIDE
    }


class EndovascularAccessRequest(BaseModel):
    procedure_type: str
    radial_suitable: bool = True
    femoral_suitable: bool = True


@router.post("/vascular-access/endovascular")
async def endovascular_access_plan(request: EndovascularAccessRequest):
    """
    Планирование доступа для эндоваскулярной процедуры
    """
    patient_data = {
        "radial_suitable": request.radial_suitable,
        "femoral_suitable": request.femoral_suitable
    }
    
    result = get_endovascular_access_plan(request.procedure_type, patient_data)
    
    return {
        "success": True,
        "plan": result
    }


@router.get("/vascular-access/endovascular/guide")
async def endovascular_access_guide():
    """
    Руководство по эндоваскулярному доступу
    """
    return {
        "guide": ENDOVASCULAR_ACCESS_GUIDE,
        "tevar_evar": TEVAR_EVAR_ACCESS
    }


# ==================== 3D MEASUREMENTS ====================

class EVARSizingRequest(BaseModel):
    neck_diameter: float
    neck_length: float
    aneurysm_length: float
    common_iliac_diameter: float
    external_iliac_diameter: float


@router.post("/measurements/evar-sizing")
async def evar_sizing(request: EVARSizingRequest):
    """
    Расчет размеров стент-графта для EVAR
    """
    measurements = {
        "neck_diameter": request.neck_diameter,
        "neck_length": request.neck_length,
        "aneurysm_length": request.aneurysm_length,
        "common_iliac_diameter": request.common_iliac_diameter,
        "external_iliac_diameter": request.external_iliac_diameter
    }
    
    result = calculate_evar_sizing(measurements)
    
    return {
        "success": True,
        "sizing": result
    }


class TEVARSizingRequest(BaseModel):
    proximal_diameter: float
    distal_diameter: float
    coverage_length: float
    left_subclavian_distance: float


@router.post("/measurements/tevar-sizing")
async def tevar_sizing(request: TEVARSizingRequest):
    """
    Расчет размеров стент-графта для TEVAR
    """
    measurements = {
        "proximal_diameter": request.proximal_diameter,
        "distal_diameter": request.distal_diameter,
        "coverage_length": request.coverage_length,
        "left_subclavian_distance": request.left_subclavian_distance
    }
    
    result = calculate_tevAR_sizing(measurements)
    
    return {
        "success": True,
        "sizing": result
    }


@router.get("/measurements/checklist/{procedure_type}")
async def measurement_checklist(procedure_type: str):
    """
    Чек-лист измерений для процедуры (evar, tevar)
    """
    result = get_measurement_checklist(procedure_type)
    
    if "error" in result:
        raise HTTPException(status_code=400, detail=result["error"])
    
    return result


@router.get("/measurements/evar-guide")
async def evar_measurement_guide():
    """
    Руководство по измерениям для EVAR
    """
    return {
        "guide": EVAR_MEASUREMENTS
    }


@router.get("/measurements/tevar-guide")
async def tevar_measurement_guide():
    """
    Руководство по измерениям для TEVAR
    """
    return {
        "guide": TEVAR_MEASUREMENTS
    }


# ==================== VASCULAR LAB ====================

class ABIRequest(BaseModel):
    right_ankle_pressure: float
    left_ankle_pressure: float
    brachial_pressure: float


@router.post("/vascular-lab/abi")
async def abi_interpretation(request: ABIRequest):
    """
    Интерпретация АКШ
    """
    result = interpret_abi(
        request.right_ankle_pressure,
        request.left_ankle_pressure,
        request.brachial_pressure
    )
    
    return {
        "success": True,
        "interpretation": result
    }


class SegmentalPressureRequest(BaseModel):
    brachial: float
    high_thigh: float
    low_thigh: float
    calf: float
    ankle: float


@router.post("/vascular-lab/segmental-pressures")
async def segmental_pressures(request: SegmentalPressureRequest):
    """
    Интерпретация сегментарных давлений
    """
    pressures = {
        "brachial": request.brachial,
        "high_thigh": request.high_thigh,
        "low_thigh": request.low_thigh,
        "calf": request.calf,
        "ankle": request.ankle
    }
    
    result = interpret_segmental_pressures(pressures)
    
    return {
        "success": True,
        "interpretation": result
    }


class DopplerVelocityRequest(BaseModel):
    site: str  # carotid, bypass_graft, etc.
    psv: float
    edv: Optional[float] = None
    ratio: Optional[float] = None


@router.post("/vascular-lab/doppler")
async def doppler_interpretation(request: DopplerVelocityRequest):
    """
    Интерпретация допплеровских скоростей
    """
    result = interpret_doppler_velocities(
        request.site,
        request.psv,
        request.edv,
        request.ratio
    )
    
    return {
        "success": True,
        "interpretation": result
    }


@router.get("/vascular-lab/guide")
async def vascular_lab_guide():
    """
    Полное руководство по сосудистой лаборатории
    """
    return {
        "guide": get_vascular_lab_checklist()
    }


@router.get("/vascular-lab/abi-guide")
async def abi_guide():
    """
    Руководство по АКШ
    """
    return {
        "guide": ABI_INTERPRETATION
    }


@router.get("/vascular-lab/doppler-guide")
async def doppler_guide():
    """
    Руководство по допплеровской велосиметрии
    """
    return {
        "guide": DOPPLER_VELOCIMETRY
    }


# ==================== TRAUMA ====================

class NeckTraumaRequest(BaseModel):
    zone: str  # 1, 2, 3
    signs: List[str]
    hemodynamic_status: str  # stable, unstable


@router.post("/trauma/neck-assessment")
async def neck_trauma_assessment(request: NeckTraumaRequest):
    """
    Оценка травмы шеи
    """
    result = assess_neck_trauma(
        request.zone,
        request.signs,
        request.hemodynamic_status
    )
    
    return {
        "success": True,
        "assessment": result
    }


class ExtremityTraumaRequest(BaseModel):
    hard_signs: bool
    injury_location: str
    ischemia_time: int


@router.post("/trauma/extremity-management")
async def extremity_trauma_management(request: ExtremityTraumaRequest):
    """
    Управление травмой сосудов конечности
    """
    result = manage_extremity_vascular_trauma(
        request.hard_signs,
        request.injury_location,
        request.ischemia_time
    )
    
    return {
        "success": True,
        "management": result
    }


@router.get("/trauma/checklist")
async def trauma_checklist():
    """
    Чек-лист для травмы сосудов
    """
    return {
        "checklist": get_trauma_checklist("general"),
        "classification": VASCULAR_TRAUMA_CLASSIFICATION,
        "neck": NECK_TRAUMA,
        "extremity": EXTREMITY_VASCULAR_TRAUMA
    }


# ==================== PEDIATRIC ====================

class PediatricAorticRequest(BaseModel):
    body_surface_area: float


@router.post("/pediatric/aortic-diameter")
async def pediatric_aortic_diameter(request: PediatricAorticRequest):
    """
    Расчет нормального диаметра аорты у ребенка
    """
    result = calculate_pediatric_aortic_diameter(request.body_surface_area)
    
    return {
        "success": True,
        "calculation": result
    }


class CoarctationRequest(BaseModel):
    upper_extremity_bp: float
    lower_extremity_bp: float
    age_months: int


@router.post("/pediatric/coarctation-assessment")
async def coarctation_assessment(request: CoarctationRequest):
    """
    Оценка коарктации аорты
    """
    result = assess_coarctation(
        request.upper_extremity_bp,
        request.lower_extremity_bp,
        request.age_months
    )
    
    return {
        "success": True,
        "assessment": result
    }


@router.get("/pediatric/guide")
async def pediatric_guide():
    """
    Руководство по педиатрической сосудистой хирургии
    """
    return {
        "normal_values": PEDIATRIC_NORMAL_VALUES,
        "congenital_anomalies": CONGENITAL_VASCULAR_ANOMALIES
    }


# ==================== PREOPERATIVE CHECKLISTS ====================

class PreopChecklistRequest(BaseModel):
    procedure: str
    on_aspirin: bool = False
    on_warfarin: bool = False
    on_metformin: bool = False


@router.post("/checklists/preoperative")
async def preoperative_checklist(request: PreopChecklistRequest):
    """
    Получить предоперационный чек-лист
    """
    patient_data = {
        "on_aspirin": request.on_aspirin,
        "on_warfarin": request.on_warfarin,
        "on_metformin": request.on_metformin
    }
    
    result = get_preop_checklist(request.procedure, patient_data)
    
    return {
        "success": True,
        "checklist": result
    }


class SignInRequest(BaseModel):
    patient_id: str
    procedure: str
    site: str


@router.post("/checklists/sign-in")
async def sign_in_checklist(request: SignInRequest):
    """
    WHO Sign In чек-лист
    """
    result = get_sign_in_checklist(
        request.patient_id,
        request.procedure,
        request.site
    )
    
    return {
        "success": True,
        "checklist": result
    }


class TimeOutRequest(BaseModel):
    team_members: List[str]
    critical_steps: List[str]


@router.post("/checklists/time-out")
async def time_out_checklist(request: TimeOutRequest):
    """
    WHO Time Out чек-лист
    """
    result = get_time_out_checklist(
        request.team_members,
        request.critical_steps
    )
    
    return {
        "success": True,
        "checklist": result
    }


class SignOutRequest(BaseModel):
    specimens: List[str]
    equipment_issues: List[str] = []


@router.post("/checklists/sign-out")
async def sign_out_checklist(request: SignOutRequest):
    """
    WHO Sign Out чек-лист
    """
    result = get_sign_out_checklist(
        request.specimens,
        request.equipment_issues
    )
    
    return {
        "success": True,
        "checklist": result
    }


@router.get("/checklists/who-safety")
async def who_safety_checklist():
    """
    Полный WHO Surgical Safety Checklist
    """
    return {
        "checklist": WHO_SAFETY_CHECKLIST
    }


@router.get("/checklists/procedures")
async def available_procedure_checklists():
    """
    Список доступных процедурных чек-листов
    """
    return {
        "procedures": list(PROCEDURE_SPECIFIC_CHECKLISTS.keys())
    }
