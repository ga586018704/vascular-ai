"""
VASCULAR.AI - Phlebology AI Agent
Специализированный агент для флебологии и венозных заболеваний
"""

from typing import Dict, List, Any, Optional
from datetime import datetime
import re

from app.agents.base.medical_agent import (
    MedicalAIAgent, AgentAnalysis, ScientificSource,
    EvidenceLevel, RecommendationClass
)
from app.agents.knowledge.scientific_integrator import ScientificKnowledgeManager
from app.core.logging import app_logger


class PhlebologyAgent(MedicalAIAgent):
    """
    AI-агент для флебологии
    
    Специализации:
    - Варикозная болезнь (CEAP классификация)
    - Хроническая венозная недостаточность
    - Тромбоз глубоких вен (DVT)
    - Тромбоэмболия легочной артерии (PE)
    - Посттромботический синдром
    - Лимфедема
    """
    
    def __init__(self, pubmed_api_key: Optional[str] = None):
        super().__init__(
            agent_name="PhlebologyAgent",
            agent_version="1.0.0",
            specialty="Phlebology",
            knowledge_sources=["PubMed", "ESVS", "AVF", "ACCP"]
        )
        
        self.knowledge_manager = ScientificKnowledgeManager(pubmed_api_key)
        
        # CEAP классификация
        self.ceap_classification = {
            "C0": "Нет видимых или palpable признаков венозной болезни",
            "C1": "Телеангиэктазии или ретикулярные вены",
            "C2": "Варикозные вены",
            "C3": "Отеки",
            "C4a": "Пигментация или экзема",
            "C4b": "Липодерматосклероз или атрофия белой кожи",
            "C5": "Зажившие язвы",
            "C6": "Активные язвы"
        }
        
        # Специализированные запросы
        self.pathology_queries = {
            "varicose_veins": {
                "pubmed_query": "(varicose veins[Title/Abstract] OR chronic venous insufficiency[Title/Abstract]) AND (treatment[Title/Abstract] OR endovenous[Title/Abstract] OR sclerotherapy[Title/Abstract])",
                "guideline_topics": ["venous", "varicose"],
                "key_journals": ["Phlebology", "Journal of Vascular Surgery: Venous and Lymphatic Disorders", "Dermatologic Surgery"]
            },
            "dvt": {
                "pubmed_query": "(deep vein thrombosis[Title/Abstract] OR DVT[Title/Abstract]) AND (treatment[Title/Abstract] OR anticoagulation[Title/Abstract] OR thrombolysis[Title/Abstract])",
                "guideline_topics": ["venous", "dvt"],
                "key_journals": ["Journal of Thrombosis and Haemostasis", "Blood", "Circulation"]
            },
            "pe": {
                "pubmed_query": "(pulmonary embolism[Title/Abstract] OR PE[Title/Abstract]) AND (treatment[Title/Abstract] OR anticoagulation[Title/Abstract])",
                "guideline_topics": ["venous", "pe"],
                "key_journals": ["European Respiratory Journal", "Chest", "Thrombosis Research"]
            },
            "lymphedema": {
                "pubmed_query": "(lymphedema[Title/Abstract] OR lymphatic[Title/Abstract]) AND (treatment[Title/Abstract] OR compression[Title/Abstract] OR CDT[Title/Abstract])",
                "guideline_topics": ["lymphatic", "lymphedema"],
                "key_journals": ["Lymphatic Research and Biology", "Phlebology", "Journal of Vascular Surgery"]
            }
        }
    
    def _detect_pathology(self, query: str) -> Optional[str]:
        """Определение патологии из запроса"""
        
        query_lower = query.lower()
        
        pathology_keywords = {
            "varicose_veins": ["varicose", "варикоз", "венозная недостаточность", "cvvi", "ceap"],
            "dvt": ["dvt", "тромбоз", "тромбофлебит", "deep vein", "глубоких вен"],
            "pe": ["pe", "тромбоэмболия", "легочная артерия", "pulmonary embolism", "вте"],
            "lymphedema": ["lymphedema", "лимфедема", "лимфостаз", "elephantiasis"],
            "venous_ulcer": ["venous ulcer", "венозная язва", "трофическая язва"]
        }
        
        for pathology, keywords in pathology_keywords.items():
            if any(kw in query_lower for kw in keywords):
                return pathology
        
        return None
    
    def _extract_ceap_class(self, query: str) -> Optional[str]:
        """Извлечение CEAP классификации из запроса"""
        
        ceap_match = re.search(r'C[0-6][a-b]?', query.upper())
        if ceap_match:
            return ceap_match.group(0)
        
        # Определение по описанию
        query_lower = query.lower()
        
        if "телеангиэктазии" in query_lower or "сосудистые звездочки" in query_lower:
            return "C1"
        elif "варикоз" in query_lower and "отек" not in query_lower:
            return "C2"
        elif "отек" in query_lower and "пигментация" not in query_lower:
            return "C3"
        elif "пигментация" in query_lower or "экзема" in query_lower:
            return "C4a"
        elif "липодерматосклероз" in query_lower:
            return "C4b"
        elif "язва" in query_lower and "заживш" in query_lower:
            return "C5"
        elif "язва" in query_lower:
            return "C6"
        
        return None
    
    def _extract_patient_factors(self, query: str) -> Dict[str, Any]:
        """Извлечение факторов пациента"""
        
        factors = {
            "age": None,
            "gender": None,
            "pregnancy": False,
            "previous_dvt": False,
            "cancer": False,
            "immobility": False,
            "hormonal_therapy": False,
            "obesity": False,
            "ceap_class": None
        }
        
        query_lower = query.lower()
        
        # Возраст
        age_match = re.search(r'(\d+)\s*(?:лет|years?)', query_lower)
        if age_match:
            factors["age"] = int(age_match.group(1))
        
        # Беременность
        if any(kw in query_lower for kw in ["беременн", "pregnant", "pregnancy"]):
            factors["pregnancy"] = True
        
        # Онкология
        if any(kw in query_lower for kw in ["рак", "cancer", "oncology", "опухоль"]):
            factors["cancer"] = True
        
        # Иммобилизация
        if any(kw in query_lower for kw in ["иммобилизация", "immobilization", "постельный", "bedridden"]):
            factors["immobility"] = True
        
        # Гормональная терапия
        if any(kw in query_lower for kw in ["ок", "oral contraceptive", "hormone", "гормон"]):
            factors["hormonal_therapy"] = True
        
        # Ожирение
        if any(kw in query_lower for kw in ["ожирение", "obesity", "obese", "bmi"]):
            factors["obesity"] = True
        
        # CEAP класс
        factors["ceap_class"] = self._extract_ceap_class(query)
        
        return factors
    
    async def analyze(
        self,
        query: str,
        patient_context: Optional[Dict[str, Any]] = None,
        include_sources: bool = True,
        min_evidence_level: EvidenceLevel = EvidenceLevel.IV
    ) -> AgentAnalysis:
        """Анализ флебологического случая"""
        
        app_logger.info(f"PhlebologyAgent analyzing: {query[:100]}...")
        
        pathology = self._detect_pathology(query)
        patient_factors = self._extract_patient_factors(query)
        
        if patient_context:
            patient_factors.update(patient_context)
        
        # Поиск литературы
        sources = []
        if include_sources and pathology:
            pathology_info = self.pathology_queries.get(pathology, {})
            pubmed_query = pathology_info.get("pubmed_query", query)
            
            search_results = await self.knowledge_manager.search_literature(
                query=pubmed_query,
                max_results=15,
                min_year=2015,
                include_guidelines=True
            )
            
            sources = search_results.get("pubmed", [])
        
        # Генерация анализа
        analysis_text = await self._generate_analysis(pathology, patient_factors, query)
        recommendations = await self._generate_recommendations(pathology, patient_factors)
        contraindications = await self._identify_contraindications(pathology, patient_factors)
        alternatives = await self._suggest_alternatives(pathology, patient_factors)
        follow_up = await self._generate_follow_up(pathology, patient_factors)
        
        confidence = self.calculate_confidence_score(sources, query_complexity=2 if pathology else 3)
        evidence_summary = self.knowledge_manager.get_evidence_summary(sources)
        
        analysis = AgentAnalysis(
            query=query,
            analysis=analysis_text,
            recommendations=recommendations,
            sources=sources,
            confidence_score=confidence,
            evidence_summary=str(evidence_summary),
            contraindications=contraindications,
            alternative_approaches=alternatives,
            follow_up_recommendations=follow_up,
            agent_type="phlebology",
            version=self.agent_version
        )
        
        self.log_analysis(query, analysis)
        
        return analysis
    
    async def _generate_analysis(
        self,
        pathology: Optional[str],
        patient_factors: Dict[str, Any],
        original_query: str
    ) -> str:
        """Генерация текстового анализа"""
        
        analysis_parts = []
        
        if pathology == "varicose_veins":
            analysis_parts.append("Анализ случая варикозной болезни:")
            analysis_parts.append("")
            
            ceap = patient_factors.get("ceap_class")
            if ceap:
                analysis_parts.append(f"CEAP классификация: {ceap}")
                analysis_parts.append(f"- {self.ceap_classification.get(ceap, 'Неизвестный класс')}")
                analysis_parts.append("")
            
            analysis_parts.append("Диагностическая оценка:")
            analysis_parts.append("- Дуплексное УЗИ вен нижних конечностей")
            analysis_parts.append("- Оценка гемодинамики (Venenix, Vivid)")
            analysis_parts.append("- Исключение глубокой венозной недостаточности")
            
            if patient_factors.get("pregnancy"):
                analysis_parts.append("")
                analysis_parts.append("⚠️ Беременность: консервативное лечение, отсрочка операции")
        
        elif pathology == "dvt":
            analysis_parts.append("Анализ случая тромбоза глубоких вен:")
            analysis_parts.append("")
            
            # Оценка риска по Wells score
            analysis_parts.append("Оценка предтестовой вероятности:")
            analysis_parts.append("- Wells score для DVT")
            analysis_parts.append("- D-dimer при низкой/умеренной вероятности")
            analysis_parts.append("- Дуплексное УЗИ при высокой вероятности")
            
            analysis_parts.append("")
            analysis_parts.append("Немедленные действия:")
            analysis_parts.append("- Начало антикоагулянтной терапии (LMWH или DOAC)")
            analysis_parts.append("- Компрессионная терапия (30-40 мм рт.ст.)")
            analysis_parts.append("- Ранняя мобилизация")
            
            if patient_factors.get("cancer"):
                analysis_parts.append("")
                analysis_parts.append("⚠️ Активный рак: LMWH предпочтительнее DOAC")
        
        elif pathology == "pe":
            analysis_parts.append("Анализ случая тромбоэмболии легочной артерии:")
            analysis_parts.append("")
            
            analysis_parts.append("⚠️ ЖИЗНЕУГРОЖАЮЩЕЕ СОСТОЯНИЕ")
            analysis_parts.append("- Оценка гемодинамики (АД, ЧСС, Shock Index)")
            analysis_parts.append("- КТ-ангиография легочных артерий")
            analysis_parts.append("- Начало антикоагулянтной терапии немедленно")
            
            analysis_parts.append("")
            analysis_parts.append("Риск-стратификация:")
            analysis_parts.append("- Массивная PE: гемодинамическая нестабильность → системная тромболиза")
            analysis_parts.append("- Субмассивная PE: RV dysfunction → рассмотреть тромболизу")
            analysis_parts.append("- Немассивная PE: антикоагуляция")
        
        elif pathology == "lymphedema":
            analysis_parts.append("Анализ случая лимфедемы:")
            analysis_parts.append("")
            
            analysis_parts.append("Стадирование по ISL (International Society of Lymphology):")
            analysis_parts.append("- Stage 0: Субклиническая лимфедема")
            analysis_parts.append("- Stage I: Обратимый отек (утреннее улучшение)")
            analysis_parts.append("- Stage II: Необратимый отек (без улучшения)")
            analysis_parts.append("- Stage III: Лимфостатический элефантиаз")
            
            analysis_parts.append("")
            analysis_parts.append("Комплексная деконгестивная терапия (CDT):")
            analysis_parts.append("- Ручной лимфодренаж")
            analysis_parts.append("- Многослойная компрессионная повязка")
            analysis_parts.append("- Физические упражнения")
            analysis_parts.append("- Гигиена кожи")
        
        else:
            analysis_parts.append("Общий флебологический анализ:")
            analysis_parts.append("- Требуется детальная клиническая оценка")
            analysis_parts.append("- Рекомендуется консультация флеболога")
        
        return "\n".join(analysis_parts)
    
    async def _generate_recommendations(
        self,
        pathology: Optional[str],
        patient_factors: Dict[str, Any]
    ) -> List[str]:
        """Генерация рекомендаций"""
        
        recommendations = []
        
        if pathology == "varicose_veins":
            ceap = patient_factors.get("ceap_class")
            
            if ceap in ["C0", "C1"]:
                recommendations.extend([
                    "Консервативное лечение: компрессионный трикотаж 15-20 мм рт.ст.",
                    "Склеротерапия для эстетического результата"
                ])
            elif ceap in ["C2", "C3"]:
                recommendations.extend([
                    "Эндовенозная лазерная/радиочастотная абляция (ELA/RFA)",
                    "Компрессионный трикотаж 20-30 мм рт.ст. класса II",
                    "Минифлебэктомия при необходимости"
                ])
            elif ceap in ["C4a", "C4b", "C5", "C6"]:
                recommendations.extend([
                    "Обязательное хирургическое лечение",
                    "Компрессионный трикотаж 30-40 мм рт.ст. класса III",
                    "Лечение венозной язвы (при C5-C6)"
                ])
        
        elif pathology == "dvt":
            recommendations.extend([
                "Антикоагулянтная терапия минимум 3 месяца",
                "LMWH (эноксапарин 1 мг/кг 2 раза в день) или DOAC",
                "Компрессионный трикотаж 30-40 мм рт.ст.",
                "Ранняя мобилизация (противопоказана при массивном тромбозе)"
            ])
            
            if patient_factors.get("cancer"):
                recommendations.append("При активном раке: LMWH предпочтительнее (до 6 месяцев)")
        
        elif pathology == "pe":
            recommendations.extend([
                "Немедленная антикоагулянтная терапия",
                "КТ-ангиография для подтверждения диагноза",
                "При массивной PE: системная тромболиза (алтеплаза)"
            ])
        
        elif pathology == "lymphedema":
            recommendations.extend([
                "Комплексная деконгестивная терапия (CDT)",
                "Многослойная компрессионная повязка",
                "Ручной лимфодренаж",
                "Физические упражнения с компрессией",
                "Тщательная гигиена кожи"
            ])
        
        return recommendations
    
    async def _identify_contraindications(
        self,
        pathology: Optional[str],
        patient_factors: Dict[str, Any]
    ) -> List[str]:
        """Выявление противопоказаний"""
        
        contraindications = []
        
        if pathology == "varicose_veins":
            if patient_factors.get("pregnancy"):
                contraindications.append("Беременность: отсрочка оперативного лечения")
            
            if patient_factors.get("age", 0) > 80:
                contraindications.append("Возраст >80 лет: консервативное лечение предпочтительнее")
        
        elif pathology == "dvt":
            if any(kw in str(patient_factors) for kw in ["bleeding", "кровотечение", "hemorrhage"]):
                contraindications.append("Активное кровотечение: противопоказание к антикоагуляции")
        
        return contraindications
    
    async def _suggest_alternatives(
        self,
        pathology: Optional[str],
        patient_factors: Dict[str, Any]
    ) -> List[str]:
        """Альтернативные подходы"""
        
        alternatives = []
        
        if pathology == "varicose_veins":
            alternatives.extend([
                "Лазерная абляция (EVLA) - золотой стандарт",
                "Радиочастотная абляция (RFA)",
                "Клеевая облитерация (VenaSeal)",
                "Склеротерапия пены (foam sclerotherapy)",
                "Традиционное хирургическое удаление (stripping)"
            ])
        
        return alternatives
    
    async def _generate_follow_up(
        self,
        pathology: Optional[str],
        patient_factors: Dict[str, Any]
    ) -> List[str]:
        """Рекомендации по наблюдению"""
        
        follow_up = []
        
        if pathology == "varicose_veins":
            follow_up.extend([
                "Контрольное УЗИ через 1 неделю, 1 месяц, 6 месяцев",
                "Ношение компрессионного трикотажа 2-4 недели после процедуры",
                "Избегание подъема тяжестей 2 недели"
            ])
        
        elif pathology == "dvt":
            follow_up.extend([
                "Контроль INR (при варфарине) или функции почек (при DOAC)",
                "Оценка риска рецидива тромбоза",
                "Вопрос о продлении антикоагуляции при постоянных факторах риска"
            ])
        
        return follow_up
    
    async def update_knowledge_base(self) -> bool:
        """Обновление базы знаний"""
        
        app_logger.info("Updating PhlebologyAgent knowledge base...")
        success = await self.knowledge_manager.update_knowledge_base()
        
        if success:
            self.last_knowledge_update = datetime.utcnow()
            app_logger.info("PhlebologyAgent knowledge base updated")
        
        return success
    
    def get_ceap_description(self, ceap_class: str) -> str:
        """Получение описания CEAP класса"""
        return self.ceap_classification.get(ceap_class, "Неизвестный класс")
    
    def calculate_well_score(self, factors: Dict[str, Any]) -> int:
        """Расчет Wells score для DVT"""
        
        score = 0
        
        # Клинические признаки (пример)
        if factors.get("cancer"):
            score += 1
        if factors.get("immobility"):
            score += 1
        if factors.get("previous_dvt"):
            score += 1
        
        return score
