"""
VASCULAR.AI - Endovascular Surgery AI Agent
Специализированный агент для эндоваскулярной хирургии
"""

from typing import Dict, List, Any, Optional
from datetime import datetime
import re

from app.agents.base.medical_agent import (
    MedicalAIAgent, AgentAnalysis, ScientificSource,
    EvidenceLevel, RecommendationClass
)
from app.agents.knowledge.scientific_integrator import ScientificKnowledgeManager
from app.core.logging import app_logger


class EndovascularAgent(MedicalAIAgent):
    """
    AI-агент для эндоваскулярной хирургии
    
    Специализации:
    - EVAR/TEVAR (эндоваскулярный ремонт аневризм)
    - Нижние конечности (fem-pop, tibial)
    - Висцеральные артерии
    - Диализный доступ
    - Комплексные эндоваскулярные процедуры
    """
    
    def __init__(self, pubmed_api_key: Optional[str] = None):
        super().__init__(
            agent_name="EndovascularAgent",
            agent_version="1.0.0",
            specialty="Endovascular Surgery",
            knowledge_sources=["PubMed", "ESVS", "SVS", "VEITH"]
        )
        
        self.knowledge_manager = ScientificKnowledgeManager(pubmed_api_key)
        
        # TASC II классификация
        self.tasc_classification = {
            "aortoiliac": {
                "A": "Односторонние стенозы <10 см или окклюзии <5 см",
                "B": "Множественные стенозы/окклюзии 5-15 см; односторонние окклюзии >15 см",
                "C": "Двусторонние стенозы/окклюзии 5-15 см; односторонние окклюзии с двусторонним поражением",
                "D": "Хроническая тотальная окклюзия аорты или общих подвздошных артерий"
            },
            "femoropopliteal": {
                "A": "Одиночный стеноз <10 см или окклюзия <5 см",
                "B": "Множественные стенозы/окклюзии <15 см; после стентирования или бифуркации",
                "C": "Множественные стенозы/окклюзии >15 см; после перенесенной артериальной реконструкции",
                "D": "Хронические окклюзии общей бедренной или поверхностной артерии"
            }
        }
        
        # Специализированные запросы
        self.pathology_queries = {
            "evar": {
                "pubmed_query": "(EVAR[Title/Abstract] OR endovascular aneurysm repair[Title/Abstract]) AND (outcomes[Title/Abstract] OR complications[Title/Abstract])",
                "guideline_topics": ["aortic-aneurysm", "evar"],
                "key_journals": ["Journal of Vascular Surgery", "European Journal of Vascular and Endovascular Surgery"]
            },
            "tevar": {
                "pubmed_query": "(TEVAR[Title/Abstract] OR thoracic endovascular[Title/Abstract]) AND (aortic dissection[Title/Abstract] OR aneurysm[Title/Abstract])",
                "guideline_topics": ["aortic-aneurysm", "tevar"],
                "key_journals": ["Journal of Vascular Surgery", "Journal of Thoracic and Cardiovascular Surgery"]
            },
            "femoropopliteal_intervention": {
                "pubmed_query": "(femoropopliteal[Title/Abstract] OR superficial femoral artery[Title/Abstract]) AND (stenting[Title/Abstract] OR angioplasty[Title/Abstract])",
                "guideline_topics": ["lower-limb", "pad"],
                "key_journals": ["Journal of Vascular Surgery", "Circulation: Cardiovascular Interventions"]
            },
            "below_knee_intervention": {
                "pubmed_query": "(below knee[Title/Abstract] OR tibial artery[Title/Abstract] OR infrapopliteal[Title/Abstract]) AND (angioplasty[Title/Abstract] OR intervention[Title/Abstract])",
                "guideline_topics": ["lower-limb", "infrapopliteal"],
                "key_journals": ["Journal of Vascular Surgery", "Journal of Endovascular Therapy"]
            },
            "dialysis_access": {
                "pubmed_query": "(dialysis access[Title/Abstract] OR AV fistula[Title/Abstract] OR arteriovenous fistula[Title/Abstract]) AND (endovascular[Title/Abstract] OR intervention[Title/Abstract])",
                "guideline_topics": ["access", "dialysis"],
                "key_journals": ["Journal of Vascular Surgery", "Journal of Vascular Access"]
            }
        }
    
    def _detect_pathology(self, query: str) -> Optional[str]:
        """Определение патологии"""
        
        query_lower = query.lower()
        
        pathology_keywords = {
            "evar": ["evar", "эндопротезирование", "endovascular aneurysm", "аневризма брюшной аорты"],
            "tevar": ["tevar", "грудная аорта", "thoracic endovascular", "диссекция"],
            "femoropopliteal_intervention": ["fem-pop", "бедренная", "поверхностная артерия", "sfa"],
            "below_knee_intervention": ["below knee", "тибиальные", "infrapopliteal", "подколенная"],
            "dialysis_access": ["диализ", "dialysis", "фистула", "fistula", "av fistula"],
            "visceral_intervention": ["visceral", "висцеральные", "почечная", "чревные"],
            "endoleak": ["endoleak", "эндолик", "endoleak"]
        }
        
        for pathology, keywords in pathology_keywords.items():
            if any(kw in query_lower for kw in keywords):
                return pathology
        
        return None
    
    def _extract_anatomical_measurements(self, query: str) -> Dict[str, Any]:
        """Извлечение анатомических измерений"""
        
        measurements = {
            "aneurysm_diameter": None,
            "neck_diameter": None,
            "neck_length": None,
            "iliac_diameter": None,
            "access_vessel_diameter": None,
            "angulation": None
        }
        
        # Диаметр аневризмы
        aneurysm_match = re.search(r'(?:аневризма|aneurysm|aaa).*?(\d+)\s*м?м', query.lower())
        if aneurysm_match:
            measurements["aneurysm_diameter"] = int(aneurysm_match.group(1))
        
        # Диаметр шейки
        neck_match = re.search(r'(?:шея|neck|proximal).*?(\d+)\s*м?м', query.lower())
        if neck_match:
            measurements["neck_diameter"] = int(neck_match.group(1))
        
        # Длина шейки
        neck_len_match = re.search(r'(?:длина шеи|neck length).*?(\d+)\s*м?м', query.lower())
        if neck_len_match:
            measurements["neck_length"] = int(neck_len_match.group(1))
        
        return measurements
    
    def _extract_patient_factors(self, query: str) -> Dict[str, Any]:
        """Извлечение факторов пациента"""
        
        factors = {
            "age": None,
            "surgical_risk": "intermediate",  # low, intermediate, high
            "anesthesia_risk": None,
            "previous_evar": False,
            "hostile_neck": False,
            "access_issues": False,
            "renal_function": "normal",  # normal, impaired, esrd
            "anticoagulation": False
        }
        
        query_lower = query.lower()
        
        # Возраст
        age_match = re.search(r'(\d+)\s*(?:лет|years?)', query_lower)
        if age_match:
            factors["age"] = int(age_match.group(1))
        
        # Хирургический риск
        if any(kw in query_lower for kw in ["высокий риск", "high risk", "тяжелый"]):
            factors["surgical_risk"] = "high"
        elif any(kw in query_lower for kw in ["низкий риск", "low risk", "легкий"]):
            factors["surgical_risk"] = "low"
        
        # Почечная функция
        if any(kw in query_lower for kw in ["хпн", "ckd", "почечная недостаточность"]):
            factors["renal_function"] = "impaired"
        
        # Проблемы с доступом
        if any(kw in query_lower for kw in ["кальцификация", "calcification", "узкие сосуды"]):
            factors["access_issues"] = True
        
        # Hostile neck
        if any(kw in query_lower for kw in ["короткая шея", "short neck", "широкая шея", "wide neck", "кальцификация шеи"]):
            factors["hostile_neck"] = True
        
        return factors
    
    async def analyze(
        self,
        query: str,
        patient_context: Optional[Dict[str, Any]] = None,
        include_sources: bool = True,
        min_evidence_level: EvidenceLevel = EvidenceLevel.IB
    ) -> AgentAnalysis:
        """Анализ эндоваскулярного случая"""
        
        app_logger.info(f"EndovascularAgent analyzing: {query[:100]}...")
        
        pathology = self._detect_pathology(query)
        patient_factors = self._extract_patient_factors(query)
        anatomical_data = self._extract_anatomical_measurements(query)
        
        if patient_context:
            patient_factors.update(patient_context)
        
        # Поиск литературы
        sources = []
        if include_sources and pathology:
            pathology_info = self.pathology_queries.get(pathology, {})
            pubmed_query = pathology_info.get("pubmed_query", query)
            
            search_results = await self.knowledge_manager.search_literature(
                query=pubmed_query,
                max_results=15,
                min_year=2015,
                include_guidelines=True
            )
            
            sources = search_results.get("pubmed", [])
        
        # Генерация анализа
        analysis_text = await self._generate_analysis(pathology, patient_factors, anatomical_data, query)
        recommendations = await self._generate_recommendations(pathology, patient_factors, anatomical_data)
        contraindications = await self._identify_contraindications(pathology, patient_factors, anatomical_data)
        alternatives = await self._suggest_alternatives(pathology, patient_factors, anatomical_data)
        follow_up = await self._generate_follow_up(pathology, patient_factors)
        
        confidence = self.calculate_confidence_score(sources, query_complexity=3 if pathology else 4)
        evidence_summary = self.knowledge_manager.get_evidence_summary(sources)
        
        analysis = AgentAnalysis(
            query=query,
            analysis=analysis_text,
            recommendations=recommendations,
            sources=sources,
            confidence_score=confidence,
            evidence_summary=str(evidence_summary),
            contraindications=contraindications,
            alternative_approaches=alternatives,
            follow_up_recommendations=follow_up,
            agent_type="endovascular",
            version=self.agent_version
        )
        
        self.log_analysis(query, analysis)
        
        return analysis
    
    async def _generate_analysis(
        self,
        pathology: Optional[str],
        patient_factors: Dict[str, Any],
        anatomical_data: Dict[str, Any],
        original_query: str
    ) -> str:
        """Генерация текстового анализа"""
        
        analysis_parts = []
        
        if pathology == "evar":
            analysis_parts.append("Анализ случая для EVAR (эндоваскулярный ремонт ААА):")
            analysis_parts.append("")
            
            # Анатомические критерии
            aneurysm_d = anatomical_data.get("aneurysm_diameter")
            neck_d = anatomical_data.get("neck_diameter")
            neck_l = anatomical_data.get("neck_length")
            
            analysis_parts.append("Анатомические критерии пригодности:")
            
            if aneurysm_d:
                analysis_parts.append(f"- Диаметр аневризмы: {aneurysm_d} мм")
                if aneurysm_d >= 55:
                    analysis_parts.append("  ⚠️ Диаметр ≥55 мм: показание к лечению")
            
            if neck_d:
                analysis_parts.append(f"- Диаметр шейки: {neck_d} мм")
                if neck_d > 32:
                    analysis_parts.append("  ⚠️ Шейка >32 мм: может потребоваться fenestrated graft")
            
            if neck_l:
                analysis_parts.append(f"- Длина шейки: {neck_l} мм")
                if neck_l < 10:
                    analysis_parts.append("  ⚠️ Короткая шейка (<10 мм): повышенный риск миграции")
            
            # Факторы риска
            analysis_parts.append("")
            analysis_parts.append("Оценка риска:")
            
            if patient_factors.get("hostile_neck"):
                analysis_parts.append("- Hostile neck anatomy: рассмотреть fenestrated/branched graft")
            
            if patient_factors.get("access_issues"):
                analysis_parts.append("- Проблемы с доступом: рассмотреть альтернативные точки доступа")
            
            if patient_factors.get("renal_function") == "impaired":
                analysis_parts.append("- Нарушение функции почек: защита от контраста, CO2-ангиография")
        
        elif pathology == "tevar":
            analysis_parts.append("Анализ случая для TEVAR (эндоваскулярный ремонт грудной аорты):")
            analysis_parts.append("")
            
            analysis_parts.append("Показания:")
            analysis_parts.append("- Диссекция с осложнениями (органная ишемия, расширение)")
            analysis_parts.append("- Травматическая повреждение аорты")
            analysis_parts.append("- Аневризма грудной аорты ≥55 мм")
            
            analysis_parts.append("")
            analysis_parts.append("Особенности:")
            analysis_parts.append("- Требуется адекватная landing zone (>2 см)")
            analysis_parts.append("- Риск покрытия левой подключичной артерии")
            analysis_parts.append("- Возможна реваскуляризация ЛПА перед TEVAR")
        
        elif pathology == "femoropopliteal_intervention":
            analysis_parts.append("Анализ случая для интервенции на femoro-popliteal сегменте:")
            analysis_parts.append("")
            
            analysis_parts.append("Выбор метода:")
            analysis_parts.append("- TASC A/B: предпочтительно PTA ± stenting")
            analysis_parts.append("- TASC C/D: рассмотреть bypass surgery")
            analysis_parts.append("- Drug-eluting stents: улучшенная проходимость")
            analysis_parts.append("- Drug-coated balloons: альтернатива stenting")
        
        elif pathology == "endoleak":
            analysis_parts.append("Анализ эндолика после EVAR:")
            analysis_parts.append("")
            
            analysis_parts.append("Классификация эндоликов:")
            analysis_parts.append("- Type IA: Проксимальная негерметичность")
            analysis_parts.append("- Type IB: Дистальная негерметичность")
            analysis_parts.append("- Type II: Обратный ток (Lumbar/IMA)")
            analysis_parts.append("- Type III: Нарушение целостности graft")
            analysis_parts.append("- Type IV: Пора графта")
            analysis_parts.append("- Type V: Эндотензия (расширение аневризмы без видимого leak)")
            
            analysis_parts.append("")
            analysis_parts.append("Лечение:")
            analysis_parts.append("- Type I/III: срочная коррекция")
            analysis_parts.append("- Type II: наблюдение при <5 мм расширении")
        
        else:
            analysis_parts.append("Эндоваскулярный анализ:")
            analysis_parts.append("- Требуется детальная анатомическая оценка")
            analysis_parts.append("- CTA с тонкими срезами (≤1 мм)")
            analysis_parts.append("- 3D реконструкция для планирования")
        
        return "\n".join(analysis_parts)
    
    async def _generate_recommendations(
        self,
        pathology: Optional[str],
        patient_factors: Dict[str, Any],
        anatomical_data: Dict[str, Any]
    ) -> List[str]:
        """Генерация рекомендаций"""
        
        recommendations = []
        
        if pathology == "evar":
            recommendations.extend([
                "КТ-ангиография с тонкими срезами (≤1 мм)",
                "3D реконструкция и планирование",
                "Оценка пригодности landing zones",
                "Выбор endograft (стандартный/fenestrated/branched)",
                "Планирование точки доступа"
            ])
        
        elif pathology == "tevar":
            recommendations.extend([
                "КТ-ангиография грудной аорты",
                "Оценка landing zone (>2 см от ЛПА)",
                "Планирование покрытия ЛПА",
                "Подготовка к carotid-subclavian bypass"
            ])
        
        elif pathology == "femoropopliteal_intervention":
            recommendations.extend([
                "Дуплексное УЗИ для оценки стеноза",
                "КТ/МРТ-ангиография при сложной анатомии",
                "Антиагрегантная терапия (аспирин + клопидогрель)",
                "Выбор между DES, DCB, или bare metal stent"
            ])
        
        elif pathology == "dialysis_access": {
            recommendations.extend([
                "Дуплексное УЗИ для оценки flow",
                "Ангиография при подозрении на стеноз",
                "PTA при стенозе >50% с гемодинамическим значением",
                "Рассмотреть stent при эластичном стенозе"
            ])
        }
        
        return recommendations
    
    async def _identify_contraindications(
        self,
        pathology: Optional[str],
        patient_factors: Dict[str, Any],
        anatomical_data: Dict[str, Any]
    ) -> List[str]:
        """Выявление противопоказаний"""
        
        contraindications = []
        
        if pathology == "evar":
            if anatomical_data.get("neck_length", 999) < 10:
                contraindications.append("Короткая шейка (<10 мм): высокий риск миграции")
            
            if anatomical_data.get("neck_diameter", 0) > 32:
                contraindications.append("Широкая шейка (>32 мм): требуется fenestrated graft")
            
            if patient_factors.get("access_issues"):
                contraindications.append("Проблемы с доступом: альтернативные подходы")
        
        return contraindications
    
    async def _suggest_alternatives(
        self,
        pathology: Optional[str],
        patient_factors: Dict[str, Any],
        anatomical_data: Dict[str, Any]
    ) -> List[str]:
        """Альтернативные подходы"""
        
        alternatives = []
        
        if pathology == "evar":
            alternatives.extend([
                "Стандартный EVAR (при пригодной анатомии)",
                "Fenestrated EVAR (при короткой/широкой шейке)",
                "Branched EVAR (при поражении висцеральных артерий)",
                "Open repair (при непригодности эндоваскулярного)",
                "Консервативное наблюдение (при <55 мм)"
            ])
        
        elif pathology == "femoropopliteal_intervention":
            alternatives.extend([
                "Drug-eluting stents (DES)",
                "Drug-coated balloons (DCB)",
                "Bare metal stents",
                "Plain balloon angioplasty",
                "Bypass surgery (при TASC C/D)"
            ])
        
        return alternatives
    
    async def _generate_follow_up(
        self,
        pathology: Optional[str],
        patient_factors: Dict[str, Any]
    ) -> List[str]:
        """Рекомендации по наблюдению"""
        
        follow_up = []
        
        if pathology == "evar":
            follow_up.extend([
                "КТ-ангиография через 1 месяц (базовая)",
                "КТ-ангиография через 6 месяцев",
                "Затем ежегодно (или УЗИ + КТ через год)",
                "Контроль диаметра аневризмы",
                "Оценка endoleak на каждом визите"
            ])
        
        elif pathology == "femoropopliteal_intervention":
            follow_up.extend([
                "Дуплексное УЗИ через 1, 3, 6, 12 месяцев",
                "Анкл-брахиальный индекс (ABI)",
                "Антиагрегантная терапия пожизненно"
            ])
        
        return follow_up
    
    async def update_knowledge_base(self) -> bool:
        """Обновление базы знаний"""
        
        app_logger.info("Updating EndovascularAgent knowledge base...")
        success = await self.knowledge_manager.update_knowledge_base()
        
        if success:
            self.last_knowledge_update = datetime.utcnow()
            app_logger.info("EndovascularAgent knowledge base updated")
        
        return success
    
    def get_tasc_description(self, segment: str, tasc_class: str) -> str:
        """Получение описания TASC классификации"""
        
        segment_data = self.tasc_classification.get(segment, {})
        return segment_data.get(tasc_class, "Неизвестный класс")
