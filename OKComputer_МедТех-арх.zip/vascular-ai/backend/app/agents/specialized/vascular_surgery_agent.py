"""
VASCULAR.AI - Vascular Surgery AI Agent
Специализированный агент для сосудистой хирургии
"""

from typing import Dict, List, Any, Optional
from datetime import datetime
import re

from app.agents.base.medical_agent import (
    MedicalAIAgent, AgentAnalysis, ScientificSource, 
    EvidenceLevel, RecommendationClass
)
from app.agents.knowledge.scientific_integrator import ScientificKnowledgeManager
from app.core.logging import app_logger


class VascularSurgeryAgent(MedicalAIAgent):
    """
    AI-агент для сосудистой хирургии
    
    Специализации:
    - Аневризмы аорты (ААА, ТАА)
    - Каротидная патология
    - Облитерирующие заболевания артерий
    - Мезентериальная ишемия
    - Почечные артерии
    """
    
    def __init__(self, pubmed_api_key: Optional[str] = None):
        super().__init__(
            agent_name="VascularSurgeryAgent",
            agent_version="1.0.0",
            specialty="Vascular Surgery",
            knowledge_sources=["PubMed", "ESVS", "SVS", "ACC/AHA"]
        )
        
        self.knowledge_manager = ScientificKnowledgeManager(pubmed_api_key)
        
        # Специализированные запросы для разных патологий
        self.pathology_queries = {
            "aortic_aneurysm": {
                "pubmed_query": "(aortic aneurysm[Title/Abstract] OR abdominal aortic aneurysm[Title/Abstract]) AND (treatment[Title/Abstract] OR management[Title/Abstract] OR surgery[Title/Abstract])",
                "guideline_topics": ["aortic-aneurysm", "aaa"],
                "key_journals": ["Journal of Vascular Surgery", "European Journal of Vascular and Endovascular Surgery", "Annals of Surgery"]
            },
            "carotid_stenosis": {
                "pubmed_query": "(carotid stenosis[Title/Abstract] OR carotid artery stenosis[Title/Abstract]) AND (endarterectomy[Title/Abstract] OR stenting[Title/Abstract] OR treatment[Title/Abstract])",
                "guideline_topics": ["carotid"],
                "key_journals": ["Stroke", "Journal of Vascular Surgery", "European Journal of Vascular and Endovascular Surgery"]
            },
            "pad": {
                "pubmed_query": "(peripheral arterial disease[Title/Abstract] OR peripheral artery disease[Title/Abstract] OR claudication[Title/Abstract]) AND (treatment[Title/Abstract] OR revascularization[Title/Abstract])",
                "guideline_topics": ["lower-limb", "pad"],
                "key_journals": ["Circulation", "Journal of Vascular Surgery", "European Heart Journal"]
            },
            "mesenteric_ischemia": {
                "pubmed_query": "(mesenteric ischemia[Title/Abstract] OR mesenteric artery[Title/Abstract]) AND (treatment[Title/Abstract] OR revascularization[Title/Abstract])",
                "guideline_topics": ["mesenteric"],
                "key_journals": ["Journal of Vascular Surgery", "Annals of Vascular Surgery"]
            },
            "renal_artery_stenosis": {
                "pubmed_query": "(renal artery stenosis[Title/Abstract] OR renal artery[Title/Abstract]) AND (treatment[Title/Abstract] OR stenting[Title/Abstract] OR angioplasty[Title/Abstract])",
                "guideline_topics": ["renal"],
                "key_journals": ["Journal of Vascular Surgery", "Hypertension", "Nephrology Dialysis Transplantation"]
            }
        }
    
    def _detect_pathology(self, query: str) -> Optional[str]:
        """Определение патологии из запроса"""
        
        query_lower = query.lower()
        
        pathology_keywords = {
            "aortic_aneurysm": ["aaa", "aortic aneurysm", "abdominal aortic aneurysm", "aneurysm aorta", "трехсосудистый", "аневризма аорты"],
            "carotid_stenosis": ["carotid", "каротид", "сонная артерия", "carotid stenosis", "carotid artery"],
            "pad": ["pad", "peripheral arterial disease", "claudication", "периферическое", "клаудикация", "облитерирующий"],
            "mesenteric_ischemia": ["mesenteric", "мезентериальная", "кишечная ишемия", "mesenteric ischemia"],
            "renal_artery_stenosis": ["renal artery", "почечная артерия", "renal stenosis", "reno vascular"]
        }
        
        for pathology, keywords in pathology_keywords.items():
            if any(kw in query_lower for kw in keywords):
                return pathology
        
        return None
    
    def _extract_patient_factors(self, query: str) -> Dict[str, Any]:
        """Извлечение факторов пациента из запроса"""
        
        factors = {
            "age": None,
            "gender": None,
            "comorbidities": [],
            "urgency": "elective",  # elective, urgent, emergent
            "previous_surgeries": [],
            "anatomy_features": []
        }
        
        # Извлечение возраста
        age_match = re.search(r'(\d+)\s*(?:лет|years?|y/o|yo)', query.lower())
        if age_match:
            factors["age"] = int(age_match.group(1))
        
        # Извлечение сопутствующих заболеваний
        comorbidity_keywords = {
            "cad": ["cad", "coronary", "ишемическая болезнь", "иабс"],
            "chf": ["chf", "heart failure", "хсн", "сердечная недостаточность"],
            "copd": ["copd", "хобл", "бронхит"],
            "diabetes": ["diabetes", "диабет", "сахарный"],
            "ckd": ["ckd", "хпн", "chronic kidney", "почечная недостаточность"],
            "hypertension": ["hypertension", "гипертензия", "давление"]
        }
        
        query_lower = query.lower()
        for condition, keywords in comorbidity_keywords.items():
            if any(kw in query_lower for kw in keywords):
                factors["comorbidities"].append(condition)
        
        # Определение срочности
        if any(kw in query_lower for kw in ["emergency", "emergent", "экстренно", "разрыв", "rupture"]):
            factors["urgency"] = "emergent"
        elif any(kw in query_lower for kw in ["urgent", "срочно", "нестабильный", "unstable"]):
            factors["urgency"] = "urgent"
        
        return factors
    
    async def analyze(
        self,
        query: str,
        patient_context: Optional[Dict[str, Any]] = None,
        include_sources: bool = True,
        min_evidence_level: EvidenceLevel = EvidenceLevel.IV
    ) -> AgentAnalysis:
        """
        Анализ сосудистого случая
        
        Args:
            query: Описание клинического случая
            patient_context: Дополнительный контекст пациента
            include_sources: Включать научные источники
            min_evidence_level: Минимальный уровень доказательности
        """
        
        app_logger.info(f"VascularSurgeryAgent analyzing: {query[:100]}...")
        
        # Определение патологии
        pathology = self._detect_pathology(query)
        patient_factors = self._extract_patient_factors(query)
        
        if patient_context:
            patient_factors.update(patient_context)
        
        # Поиск научной литературы
        sources = []
        if include_sources and pathology:
            pathology_info = self.pathology_queries.get(pathology, {})
            pubmed_query = pathology_info.get("pubmed_query", query)
            
            search_results = await self.knowledge_manager.search_literature(
                query=pubmed_query,
                max_results=15,
                min_year=2015,
                include_guidelines=True
            )
            
            sources = search_results.get("pubmed", [])
        
        # Формирование анализа
        analysis_text = await self._generate_analysis(pathology, patient_factors, query)
        
        # Генерация рекомендаций
        recommendations = await self._generate_recommendations(pathology, patient_factors)
        
        # Выявление противопоказаний
        contraindications = await self._identify_contraindications(pathology, patient_factors)
        
        # Альтернативные подходы
        alternatives = await self._suggest_alternatives(pathology, patient_factors)
        
        # Рекомендации по наблюдению
        follow_up = await self._generate_follow_up(pathology, patient_factors)
        
        # Расчет уверенности
        confidence = self.calculate_confidence_score(sources, query_complexity=3 if pathology else 4)
        
        # Сводка доказательств
        evidence_summary = self.knowledge_manager.get_evidence_summary(sources)
        
        analysis = AgentAnalysis(
            query=query,
            analysis=analysis_text,
            recommendations=recommendations,
            sources=sources,
            confidence_score=confidence,
            evidence_summary=str(evidence_summary),
            contraindications=contraindications,
            alternative_approaches=alternatives,
            follow_up_recommendations=follow_up,
            agent_type="vascular_surgery",
            version=self.agent_version
        )
        
        # Логирование
        self.log_analysis(query, analysis)
        
        return analysis
    
    async def _generate_analysis(
        self,
        pathology: Optional[str],
        patient_factors: Dict[str, Any],
        original_query: str
    ) -> str:
        """Генерация текстового анализа"""
        
        analysis_parts = []
        
        if pathology == "aortic_aneurysm":
            analysis_parts.append("Анализ случая с аневризмой аорты:")
            analysis_parts.append("")
            
            if patient_factors.get("urgency") == "emergent":
                analysis_parts.append("⚠️ ЭКСТРЕННАЯ СИТУАЦИЯ: Подозрение на рваную аневризму аорты")
                analysis_parts.append("- Немедленная госпитализация в отделение сосудистой хирургии")
                analysis_parts.append("- Контроль АД (цель: систола <100-120 мм рт.ст.)")
                analysis_parts.append("- Подготовка к экстренной операции (open или EVAR)")
            else:
                analysis_parts.append("Плановое наблюдение/лечение аневризмы аорты:")
                analysis_parts.append("- Оценка размера аневризмы (КТ-ангиография)")
                analysis_parts.append("- Расчет риска операции (VSGNE score)")
                
                if patient_factors.get("age", 0) > 75:
                    analysis_parts.append("- Возраст >75 лет: предпочтение EVAR при анатомической пригодности")
        
        elif pathology == "carotid_stenosis":
            analysis_parts.append("Анализ случая со стенозом сонной артерии:")
            analysis_parts.append("")
            
            analysis_parts.append("- Оценка степени стеноза (duplex УЗИ, КТ/МРТ-ангиография)")
            analysis_parts.append("- Определение симптоматичности (инсульт/TIA в анамнезе)")
            
            if "symptomatic" in original_query.lower():
                analysis_parts.append("- Симптоматичный стеноз >50%: показание к реваскуляризации")
                analysis_parts.append("- Выбор метода: CEA предпочтительнее CAS при низком риске")
            else:
                analysis_parts.append("- Бессимптомный стеноз: хирургия при >70% и низком риске")
        
        elif pathology == "pad":
            analysis_parts.append("Анализ случая с периферическим атеросклерозом:")
            analysis_parts.append("")
            
            analysis_parts.append("- Определение стадии по Fontaine/Rutherford")
            analysis_parts.append("- Консервативная терапия: статины, антиагреганты, антигипертензивные")
            
            if any(kw in original_query.lower() for kw in ["claudication", "клаудикация"]):
                analysis_parts.append("- Клаудикация: программа физической реабилитации")
                analysis_parts.append("- Реваскуляризация при неэффективности консервативной терапии")
        
        else:
            analysis_parts.append("Общий анализ сосудистого случая:")
            analysis_parts.append("- Требуется детальная оценка клинической картины")
            analysis_parts.append("- Рекомендуется консультация сосудистого хирурга")
        
        # Добавление информации о сопутствующих заболеваниях
        if patient_factors.get("comorbidities"):
            analysis_parts.append("")
            analysis_parts.append("Учет сопутствующей патологии:")
            for comorbidity in patient_factors["comorbidities"]:
                if comorbidity == "cad":
                    analysis_parts.append("- ИБС: требуется оценка сердечно-сосудистого риска")
                elif comorbidity == "chf":
                    analysis_parts.append("- ХСН: оптимизация терапии перед операцией")
                elif comorbidity == "ckd":
                    analysis_parts.append("- ХПН: защита почек от контрастного вещества")
        
        return "\n".join(analysis_parts)
    
    async def _generate_recommendations(
        self,
        pathology: Optional[str],
        patient_factors: Dict[str, Any]
    ) -> List[str]:
        """Генерация клинических рекомендаций"""
        
        recommendations = []
        
        if pathology == "aortic_aneurysm":
            if patient_factors.get("urgency") == "emergent":
                recommendations.extend([
                    "Немедленная операция (open repair или EVAR)",
                    "Контроль АД нитропруссидом/эсмололом",
                    "Подготовка к массивной кровопотере"
                ])
            else:
                recommendations.extend([
                    "КТ-ангиография для оценки анатомии",
                    "Расчет VSGNE score",
                    "Выбор между open repair и EVAR",
                    "Предоперационная оценка (КТ коронарных артерий при ИБС)"
                ])
        
        elif pathology == "carotid_stenosis":
            recommendations.extend([
                "Duplex УЗИ сосудов шеи",
                "КТ/МРТ-ангиография при неопределенности",
                "Консультация невролога при симптоматичном стенозе",
                "Антиагрегантная терапия (аспирин 75-100 мг/сут)"
            ])
        
        elif pathology == "pad":
            recommendations.extend([
                "Определение АЛИ (лодыжечно-плечевой индекс)",
                "Duplex УЗИ артерий конечностей",
                "Медикаментозная терапия: статины, аспирин/клопидогрель",
                "Отказ от курения (критически важно)"
            ])
        
        else:
            recommendations.extend([
                "Детальная диагностическая оценка",
                "Консультация специалиста",
                "Индивидуальный подход к лечению"
            ])
        
        return recommendations
    
    async def _identify_contraindications(
        self,
        pathology: Optional[str],
        patient_factors: Dict[str, Any]
    ) -> List[str]:
        """Выявление противопоказаний"""
        
        contraindications = []
        
        if patient_factors.get("age", 0) > 85:
            contraindications.append("Возраст >85 лет: повышенный риск операции")
        
        if "ckd" in patient_factors.get("comorbidities", []):
            contraindications.append("ХПН: ограничение использования контрастного вещества")
        
        if pathology == "aortic_aneurysm":
            if patient_factors.get("urgency") != "emergent":
                contraindications.append("Аневризма <5 см: наблюдение предпочтительнее операции")
        
        return contraindications
    
    async def _suggest_alternatives(
        self,
        pathology: Optional[str],
        patient_factors: Dict[str, Any]
    ) -> List[str]:
        """Предложение альтернативных подходов"""
        
        alternatives = []
        
        if pathology == "aortic_aneurysm":
            if patient_factors.get("urgency") != "emergent":
                alternatives.extend([
                    "EVAR (эндоваскулярный) при анатомической пригодности",
                    "Open repair при непригодности анатомии для EVAR",
                    "Консервативное наблюдение при аневризме <5 см"
                ])
        
        elif pathology == "carotid_stenosis":
            alternatives.extend([
                "CAS (каротидное стентирование) при высоком риске CEA",
                "Медикаментозная терапия при низком риске инсульта"
            ])
        
        return alternatives
    
    async def _generate_follow_up(
        self,
        pathology: Optional[str],
        patient_factors: Dict[str, Any]
    ) -> List[str]:
        """Рекомендации по наблюдению"""
        
        follow_up = []
        
        if pathology == "aortic_aneurysm":
            follow_up.extend([
                "После EVAR: КТ-ангиография через 1, 6, 12 месяцев, затем ежегодно",
                "После open repair: УЗИ/КТ через 6 месяцев, затем ежегодно",
                "Контроль АД (цель <130/80 мм рт.ст.)"
            ])
        
        elif pathology == "carotid_stenosis":
            follow_up.extend([
                "Duplex УЗИ через 1, 6, 12 месяцев",
                "Контроль риск-факторов (АД, липиды, глюкоза)"
            ])
        
        return follow_up
    
    async def update_knowledge_base(self) -> bool:
        """Обновление базы знаний агента"""
        
        app_logger.info("Updating VascularSurgeryAgent knowledge base...")
        
        success = await self.knowledge_manager.update_knowledge_base()
        
        if success:
            self.last_knowledge_update = datetime.utcnow()
            app_logger.info("VascularSurgeryAgent knowledge base updated successfully")
        
        return success
    
    async def get_treatment_guidelines(
        self,
        condition: str,
        patient_profile: Optional[Dict[str, Any]] = None
    ) -> Dict[str, Any]:
        """
        Получение клинических рекомендаций по лечению
        
        Args:
            condition: Заболевание
            patient_profile: Профиль пациента (возраст, сопутствующие и т.д.)
        
        Returns:
            Структурированные рекомендации
        """
        
        guidelines = await self.knowledge_manager.guidelines.get_guidelines(
            condition=condition,
            sources=["ESVS", "SVS", "ACC_AHA"]
        )
        
        return {
            "condition": condition,
            "guidelines": guidelines,
            "patient_profile": patient_profile,
            "sources": ["ESVS", "SVS", "ACC/AHA"]
        }
