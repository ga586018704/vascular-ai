"""
VASCULAR.AI - Neurointerventional Surgery AI Agent
Специализированный агент для нейроинтервенционной хирургии
"""

from typing import Dict, List, Any, Optional
from datetime import datetime
import re

from app.agents.base.medical_agent import (
    MedicalAIAgent, AgentAnalysis, ScientificSource,
    EvidenceLevel, RecommendationClass
)
from app.agents.knowledge.scientific_integrator import ScientificKnowledgeManager
from app.core.logging import app_logger


class NeurointerventionAgent(MedicalAIAgent):
    """
    AI-агент для нейроинтервенционной хирургии
    
    Специализации:
    - Ишемический инсульт (механическая тромбэктомия)
    - Внутричерепные аневризмы (клипирование/эндоваскулярно)
    - АВМ (артериовенозные мальформации)
    - Стенозы экстракраниальных артерий (CAS)
    - Внутричерепный стеноз
    """
    
    def __init__(self, pubmed_api_key: Optional[str] = None):
        super().__init__(
            agent_name="NeurointerventionAgent",
            agent_version="1.0.0",
            specialty="Neurointerventional Surgery",
            knowledge_sources=["PubMed", "SNIS", "ESMINT", "AHA/ASA"]
        )
        
        self.knowledge_manager = ScientificKnowledgeManager(pubmed_api_key)
        
        # NIHSS scale reference
        self.nihss_components = {
            "1a": "Уровень сознания",
            "1b": "Вопросы (месяц, возраст)",
            "1c": "Команды (открыть/закрыть глаза, сжать/разжать кулак)",
            "2": "Взгляд",
            "3": "Зрительные поля",
            "4": "Параличи черепных нервов (лицо)",
            "5a": "Двигательная функция - левая рука",
            "5b": "Двигательная функция - правая рука",
            "6a": "Двигательная функция - левая нога",
            "6b": "Двигательная функция - правая нога",
            "7": "Атаксия конечностей",
            "8": "Сенсорные нарушения",
            "9": "Язык (афазия)",
            "10": "Дизартрия",
            "11": "Игнорирование/экстинкция"
        }
        
        # Специализированные запросы
        self.pathology_queries = {
            "acute_stroke": {
                "pubmed_query": "(acute ischemic stroke[Title/Abstract] OR mechanical thrombectomy[Title/Abstract]) AND (treatment[Title/Abstract] OR endovascular[Title/Abstract])",
                "guideline_topics": ["stroke", "thrombectomy"],
                "key_journals": ["New England Journal of Medicine", "Lancet", "Stroke", "JAMA Neurology"]
            },
            "intracranial_aneurysm": {
                "pubmed_query": "(intracranial aneurysm[Title/Abstract] OR cerebral aneurysm[Title/Abstract]) AND (coiling[Title/Abstract] OR clipping[Title/Abstract] OR flow diverter[Title/Abstract])",
                "guideline_topics": ["aneurysm", "subarachnoid"],
                "key_journals": ["Journal of Neurosurgery", "Stroke", "Neurosurgery"]
            },
            "avm": {
                "pubmed_query": "(arteriovenous malformation[Title/Abstract] OR AVM[Title/Abstract]) AND (brain[Title/Abstract] OR cerebral[Title/Abstract]) AND (embolization[Title/Abstract] OR treatment[Title/Abstract])",
                "guideline_topics": ["avm"],
                "key_journals": ["Journal of Neurosurgery", "Stroke", "Neuroradiology"]
            },
            "carotid_stenting": {
                "pubmed_query": "(carotid artery stenting[Title/Abstract] OR CAS[Title/Abstract]) AND (stroke[Title/Abstract] OR protection[Title/Abstract])",
                "guideline_topics": ["carotid", "stenting"],
                "key_journals": ["Stroke", "Journal of Vascular Surgery", "Circulation"]
            }
        }
    
    def _detect_pathology(self, query: str) -> Optional[str]:
        """Определение патологии"""
        
        query_lower = query.lower()
        
        pathology_keywords = {
            "acute_stroke": ["stroke", "инсульт", "thrombectomy", "тромбэктомия", "nihss", "ischemic"],
            "intracranial_aneurysm": ["aneurysm", "аневризма", "coiling", "клипирование", "subarachnoid", "субарахноид"],
            "avm": ["avm", "мальформация", "malformation", "arteriovenous", "артериовенозная"],
            "carotid_stenting": ["carotid stent", "стентирование сонной", "cas", "embolic protection"],
            "intracranial_stenosis": ["intracranial stenosis", "стеноз внутричерепных", "intracranial atherosclerosis"]
        }
        
        for pathology, keywords in pathology_keywords.items():
            if any(kw in query_lower for kw in keywords):
                return pathology
        
        return None
    
    def _extract_nihss_score(self, query: str) -> Optional[int]:
        """Извлечение NIHSS score из запроса"""
        
        # Поиск NIHSS
        nihss_match = re.search(r'NIHSS[:\s]*(\d+)', query, re.IGNORECASE)
        if nihss_match:
            return int(nihss_match.group(1))
        
        # Поиск просто числа с контекстом
        score_match = re.search(r'(?:score|шкала|балл)[\s:]*(\d+)', query.lower())
        if score_match:
            return int(score_match.group(1))
        
        return None
    
    def _extract_onset_time(self, query: str) -> Optional[int]:
        """Извлечение времени от начала симптомов (в часах)"""
        
        query_lower = query.lower()
        
        # Поиск времени
        time_match = re.search(r'(\d+)\s*(?:час|hour|h)\s*(?:ов|ов)?', query_lower)
        if time_match:
            return int(time_match.group(1))
        
        # Поиск "окно" или "window"
        if "окно" in query_lower or "window" in query_lower:
            window_match = re.search(r'(\d+)\s*(?:ч|h)', query_lower)
            if window_match:
                return int(window_match.group(1))
        
        return None
    
    def _extract_patient_factors(self, query: str) -> Dict[str, Any]:
        """Извлечение факторов пациента"""
        
        factors = {
            "age": None,
            "nihss_score": None,
            "onset_time_hours": None,
            "aspects_score": None,
            "occlusion_site": None,
            "hypertension": False,
            "diabetes": False,
            "atrial_fibrillation": False,
            "previous_stroke": False,
            "anticoagulation": False,
            "ich_history": False
        }
        
        query_lower = query.lower()
        
        # Возраст
        age_match = re.search(r'(\d+)\s*(?:лет|years?)', query_lower)
        if age_match:
            factors["age"] = int(age_match.group(1))
        
        # NIHSS
        factors["nihss_score"] = self._extract_nihss_score(query)
        
        # Время от начала
        factors["onset_time_hours"] = self._extract_onset_time(query)
        
        # ASPECTS
        aspects_match = re.search(r'ASPECTS[:\s]*(\d+)', query, re.IGNORECASE)
        if aspects_match:
            factors["aspects_score"] = int(aspects_match.group(1))
        
        # Сайт окклюзии
        occlusion_keywords = {
            "mca": ["mca", "средней мозговой", "middle cerebral"],
            "ica": ["ica", "внутренней сонной", "internal carotid"],
            "basilar": ["basilar", "базилярная", "позвоночная"],
            "aca": ["aca", "передней мозговой", "anterior cerebral"]
        }
        
        for site, keywords in occlusion_keywords.items():
            if any(kw in query_lower for kw in keywords):
                factors["occlusion_site"] = site
                break
        
        # Сопутствующие заболевания
        if any(kw in query_lower for kw in ["гипертензия", "hypertension", "давление"]):
            factors["hypertension"] = True
        if any(kw in query_lower for kw in ["диабет", "diabetes", "сахарный"]):
            factors["diabetes"] = True
        if any(kw in query_lower for kw in ["фибрилляция", "fibrillation", "мерцательная"]):
            factors["atrial_fibrillation"] = True
        if any(kw in query_lower for kw in ["инсульт", "stroke"]):
            factors["previous_stroke"] = True
        
        return factors
    
    async def analyze(
        self,
        query: str,
        patient_context: Optional[Dict[str, Any]] = None,
        include_sources: bool = True,
        min_evidence_level: EvidenceLevel = EvidenceLevel.IB
    ) -> AgentAnalysis:
        """Анализ нейроинтервенционного случая"""
        
        app_logger.info(f"NeurointerventionAgent analyzing: {query[:100]}...")
        
        pathology = self._detect_pathology(query)
        patient_factors = self._extract_patient_factors(query)
        
        if patient_context:
            patient_factors.update(patient_context)
        
        # Поиск литературы
        sources = []
        if include_sources and pathology:
            pathology_info = self.pathology_queries.get(pathology, {})
            pubmed_query = pathology_info.get("pubmed_query", query)
            
            search_results = await self.knowledge_manager.search_literature(
                query=pubmed_query,
                max_results=15,
                min_year=2015,
                include_guidelines=True
            )
            
            sources = search_results.get("pubmed", [])
        
        # Генерация анализа
        analysis_text = await self._generate_analysis(pathology, patient_factors, query)
        recommendations = await self._generate_recommendations(pathology, patient_factors)
        contraindications = await self._identify_contraindications(pathology, patient_factors)
        alternatives = await self._suggest_alternatives(pathology, patient_factors)
        follow_up = await self._generate_follow_up(pathology, patient_factors)
        
        confidence = self.calculate_confidence_score(sources, query_complexity=3 if pathology else 4)
        evidence_summary = self.knowledge_manager.get_evidence_summary(sources)
        
        analysis = AgentAnalysis(
            query=query,
            analysis=analysis_text,
            recommendations=recommendations,
            sources=sources,
            confidence_score=confidence,
            evidence_summary=str(evidence_summary),
            contraindications=contraindications,
            alternative_approaches=alternatives,
            follow_up_recommendations=follow_up,
            agent_type="neurointervention",
            version=self.agent_version
        )
        
        self.log_analysis(query, analysis)
        
        return analysis
    
    async def _generate_analysis(
        self,
        pathology: Optional[str],
        patient_factors: Dict[str, Any],
        original_query: str
    ) -> str:
        """Генерация текстового анализа"""
        
        analysis_parts = []
        
        if pathology == "acute_stroke":
            analysis_parts.append("Анализ случая острого ишемического инсульта:")
            analysis_parts.append("")
            
            nihss = patient_factors.get("nihss_score")
            onset_time = patient_factors.get("onset_time_hours")
            aspects = patient_factors.get("aspects_score")
            occlusion = patient_factors.get("occlusion_site")
            
            # Критическая информация
            analysis_parts.append("⚠️ НЕЙРОЛОГИЧЕСКАЯ ЭКСТРЕННОСТЬ")
            analysis_parts.append("")
            
            if nihss is not None:
                analysis_parts.append(f"NIHSS: {nihss}")
                if nihss >= 6:
                    analysis_parts.append("- Тяжелый инсульт: показана механическая тромбэктомия")
                elif nihss >= 4:
                    analysis_parts.append("- Умеренно тяжелый инсульт: рассмотреть тромбэктомию")
            
            if onset_time is not None:
                analysis_parts.append(f"Время от начала: {onset_time} часов")
                if onset_time <= 4.5:
                    analysis_parts.append("- В терапевтическом окне для ИВТ (алтеплаза)")
                if onset_time <= 6:
                    analysis_parts.append("- Показана механическая тромбэктомия (DAWN/DEFUSE 3)")
                elif onset_time <= 24:
                    analysis_parts.append("- Рассмотреть тромбэктомию по критериям DAWN/DEFUSE 3")
            
            if aspects is not None:
                analysis_parts.append(f"ASPECTS: {aspects}")
                if aspects >= 6:
                    analysis_parts.append("- Хороший коллатеральный кровоток")
                else:
                    analysis_parts.append("- Ограниченный коллатеральный кровоток: осторожность")
            
            if occlusion:
                analysis_parts.append(f"Сайт окклюзии: {occlusion.upper()}")
        
        elif pathology == "intracranial_aneurysm":
            analysis_parts.append("Анализ случая внутричерепной аневризмы:")
            analysis_parts.append("")
            
            analysis_parts.append("Оценка риска разрыва:")
            analysis_parts.append("- Размер аневризмы (<7 мм - низкий риск)")
            analysis_parts.append("- Локализация (ПКА - высокий риск)")
            analysis_parts.append("- Форма (неправильная - высокий риск)")
            analysis_parts.append("- Факторы риска (курение, гипертензия)")
            
            analysis_parts.append("")
            analysis_parts.append("Выбор метода лечения:")
            analysis_parts.append("- Эндоваскулярное (coiling/flow diverter): предпочтительно")
            analysis_parts.append("- Хирургическое (клипирование): при непригодности эндоваскулярного")
        
        elif pathology == "avm":
            analysis_parts.append("Анализ случая АВМ головного мозга:")
            analysis_parts.append("")
            
            analysis_parts.append("Оценка по шкале Spetzler-Martin:")
            analysis_parts.append("- Размер (<3 см=1, 3-6 см=2, >6 см=3)")
            analysis_parts.append("- Элоквентная зона (да=1, нет=0)")
            analysis_parts.append("- Венозный дренаж (глубокий=1, поверхностный=0)")
            
            analysis_parts.append("")
            analysis_parts.append("Лечение:")
            analysis_parts.append("- Эмболизация: часто как часть комбинированного лечения")
            analysis_parts.append("- Хирургическое удаление: при Spetzler-Martin I-II")
            analysis_parts.append("- Лучевая терапия: при труднодоступных АВМ")
        
        else:
            analysis_parts.append("Нейроинтервенционный анализ:")
            analysis_parts.append("- Требуется детальная неврологическая оценка")
            analysis_parts.append("- Срочная консультация нейроинтервенциониста")
        
        return "\n".join(analysis_parts)
    
    async def _generate_recommendations(
        self,
        pathology: Optional[str],
        patient_factors: Dict[str, Any]
    ) -> List[str]:
        """Генерация рекомендаций"""
        
        recommendations = []
        
        if pathology == "acute_stroke":
            onset_time = patient_factors.get("onset_time_hours", 999)
            nihss = patient_factors.get("nihss_score", 0)
            
            if onset_time <= 4.5:
                recommendations.append("ИВТ (алтеплаза 0.9 мг/кг) - если нет противопоказаний")
            
            if nihss >= 6 and onset_time <= 24:
                recommendations.append("Механическая тромбэктомия (стент-ретривер)")
            
            recommendations.extend([
                "КТ/МРТ головного мозга немедленно",
                "КТ-ангиография сосудов головы и шеи",
                "Перфузионное исследование (при >6 часов)"
            ])
        
        elif pathology == "intracranial_aneurysm":
            recommendations.extend([
                "КТ/МРТ-ангиография для оценки анатомии",
                "DSA (цифровая субтракционная ангиография) - золотой стандарт",
                "Эндоваскулярное лечение (coiling/flow diverter) - предпочтительно",
                "Регулярный контроль (MRA каждые 6-12 месяцев)"
            ])
        
        elif pathology == "avm":
            recommendations.extend([
                "DSA для детальной оценки ангиоархитектоники",
                "Расчет Spetzler-Martin score",
                "Мультидисциплинарное обсуждение (MDT)",
                "Индивидуальный подход к лечению"
            ])
        
        return recommendations
    
    async def _identify_contraindications(
        self,
        pathology: Optional[str],
        patient_factors: Dict[str, Any]
    ) -> List[str]:
        """Выявление противопоказаний"""
        
        contraindications = []
        
        if pathology == "acute_stroke":
            if patient_factors.get("onset_time_hours", 0) > 24:
                contraindications.append("Время от начала >24 часов: тромбэктомия не показана")
            
            if patient_factors.get("aspects_score", 10) < 3:
                contraindications.append("ASPECTS <3: высокий риск злокачественного отека")
            
            if patient_factors.get("ich_history"):
                contraindications.append("Анамнез ВКГ: осторожность с ИВТ")
        
        return contraindications
    
    async def _suggest_alternatives(
        self,
        pathology: Optional[str],
        patient_factors: Dict[str, Any]
    ) -> List[str]:
        """Альтернативные подходы"""
        
        alternatives = []
        
        if pathology == "acute_stroke":
            alternatives.extend([
                "Аспирационная тромбэктомия (ADAPT)",
                "Комбинированный подход (стент-ретривер + аспирация)",
                "Интра-артериальная тромболиза (редко используется)"
            ])
        
        elif pathology == "intracranial_aneurysm":
            alternatives.extend([
                "Эндоваскулярное укладывание (coiling)",
                "Flow diverter (при сложной анатомии)",
                "Хирургическое клипирование",
                "Наблюдение (при <7 мм и низком риске)"
            ])
        
        return alternatives
    
    async def _generate_follow_up(
        self,
        pathology: Optional[str],
        patient_factors: Dict[str, Any]
    ) -> List[str]:
        """Рекомендации по наблюдению"""
        
        follow_up = []
        
        if pathology == "acute_stroke":
            follow_up.extend([
                "Нейровизуализация через 24 часа (исключение кровоизлияния)",
                "Антитромботическая терапия через 24 часа после тромбэктомии",
                "Реабилитация с первых дней"
            ])
        
        elif pathology == "intracranial_aneurysm":
            follow_up.extend([
                "MRA через 3, 6, 12 месяцев после лечения",
                "Затем ежегодно",
                "Контроль АД (цель <130/80)"
            ])
        
        return follow_up
    
    async def update_knowledge_base(self) -> bool:
        """Обновление базы знаний"""
        
        app_logger.info("Updating NeurointerventionAgent knowledge base...")
        success = await self.knowledge_manager.update_knowledge_base()
        
        if success:
            self.last_knowledge_update = datetime.utcnow()
            app_logger.info("NeurointerventionAgent knowledge base updated")
        
        return success
    
    def interpret_nihss(self, score: int) -> str:
        """Интерпретация NIHSS score"""
        
        if score == 0:
            return "Нет неврологического дефицита"
        elif score <= 4:
            return "Легкий инсульт"
        elif score <= 15:
            return "Умеренно тяжелый инсульт"
        elif score <= 20:
            return "Тяжелый инсульт"
        else:
            return "Очень тяжелый инсульт"
