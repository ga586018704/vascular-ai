"""
VASCULAR.AI - LLM Integration for AI Agents
Integration with GPT-4/Claude for enhanced medical analysis
"""

import os
from typing import Dict, List, Any, Optional, AsyncGenerator
from dataclasses import dataclass
from datetime import datetime
import json
import asyncio

import httpx
from app.core.logging import app_logger


@dataclass
class LLMResponse:
    """Response from LLM"""
    content: str
    model: str
    tokens_used: int
    finish_reason: str
    timestamp: datetime
    sources_cited: List[str] = None
    confidence: float = 0.0


class LLMProvider:
    """Base class for LLM providers"""
    
    def __init__(self, api_key: str, model: str):
        self.api_key = api_key
        self.model = model
    
    async def generate(
        self,
        prompt: str,
        system_message: Optional[str] = None,
        temperature: float = 0.3,
        max_tokens: int = 2000
    ) -> LLMResponse:
        raise NotImplementedError
    
    async def stream(
        self,
        prompt: str,
        system_message: Optional[str] = None,
        temperature: float = 0.3,
        max_tokens: int = 2000
    ) -> AsyncGenerator[str, None]:
        raise NotImplementedError


class OpenAIProvider(LLMProvider):
    """OpenAI GPT-4 provider"""
    
    API_URL = "https://api.openai.com/v1/chat/completions"
    
    def __init__(self, api_key: str, model: str = "gpt-4-turbo-preview"):
        super().__init__(api_key, model)
        self.client = httpx.AsyncClient(
            headers={
                "Authorization": f"Bearer {api_key}",
                "Content-Type": "application/json"
            },
            timeout=60.0
        )
    
    async def generate(
        self,
        prompt: str,
        system_message: Optional[str] = None,
        temperature: float = 0.3,
        max_tokens: int = 2000
    ) -> LLMResponse:
        """Generate response from GPT-4"""
        
        messages = []
        if system_message:
            messages.append({"role": "system", "content": system_message})
        messages.append({"role": "user", "content": prompt})
        
        payload = {
            "model": self.model,
            "messages": messages,
            "temperature": temperature,
            "max_tokens": max_tokens,
            "top_p": 0.9
        }
        
        try:
            response = await self.client.post(self.API_URL, json=payload)
            response.raise_for_status()
            data = response.json()
            
            return LLMResponse(
                content=data["choices"][0]["message"]["content"],
                model=self.model,
                tokens_used=data["usage"]["total_tokens"],
                finish_reason=data["choices"][0]["finish_reason"],
                timestamp=datetime.utcnow()
            )
        except Exception as e:
            app_logger.error(f"OpenAI API error: {e}")
            raise
    
    async def stream(
        self,
        prompt: str,
        system_message: Optional[str] = None,
        temperature: float = 0.3,
        max_tokens: int = 2000
    ) -> AsyncGenerator[str, None]:
        """Stream response from GPT-4"""
        
        messages = []
        if system_message:
            messages.append({"role": "system", "content": system_message})
        messages.append({"role": "user", "content": prompt})
        
        payload = {
            "model": self.model,
            "messages": messages,
            "temperature": temperature,
            "max_tokens": max_tokens,
            "stream": True
        }
        
        try:
            async with self.client.stream("POST", self.API_URL, json=payload) as response:
                response.raise_for_status()
                async for line in response.aiter_lines():
                    if line.startswith("data: "):
                        data = line[6:]
                        if data == "[DONE]":
                            break
                        try:
                            chunk = json.loads(data)
                            if chunk["choices"][0]["delta"].get("content"):
                                yield chunk["choices"][0]["delta"]["content"]
                        except json.JSONDecodeError:
                            continue
        except Exception as e:
            app_logger.error(f"OpenAI streaming error: {e}")
            raise


class AnthropicProvider(LLMProvider):
    """Anthropic Claude provider"""
    
    API_URL = "https://api.anthropic.com/v1/messages"
    
    def __init__(self, api_key: str, model: str = "claude-3-opus-20240229"):
        super().__init__(api_key, model)
        self.client = httpx.AsyncClient(
            headers={
                "x-api-key": api_key,
                "anthropic-version": "2023-06-01",
                "Content-Type": "application/json"
            },
            timeout=60.0
        )
    
    async def generate(
        self,
        prompt: str,
        system_message: Optional[str] = None,
        temperature: float = 0.3,
        max_tokens: int = 2000
    ) -> LLMResponse:
        """Generate response from Claude"""
        
        payload = {
            "model": self.model,
            "max_tokens": max_tokens,
            "temperature": temperature,
            "messages": [{"role": "user", "content": prompt}]
        }
        
        if system_message:
            payload["system"] = system_message
        
        try:
            response = await self.client.post(self.API_URL, json=payload)
            response.raise_for_status()
            data = response.json()
            
            return LLMResponse(
                content=data["content"][0]["text"],
                model=self.model,
                tokens_used=data["usage"]["input_tokens"] + data["usage"]["output_tokens"],
                finish_reason=data["stop_reason"],
                timestamp=datetime.utcnow()
            )
        except Exception as e:
            app_logger.error(f"Anthropic API error: {e}")
            raise
    
    async def stream(
        self,
        prompt: str,
        system_message: Optional[str] = None,
        temperature: float = 0.3,
        max_tokens: int = 2000
    ) -> AsyncGenerator[str, None]:
        """Stream response from Claude"""
        
        payload = {
            "model": self.model,
            "max_tokens": max_tokens,
            "temperature": temperature,
            "messages": [{"role": "user", "content": prompt}],
            "stream": True
        }
        
        if system_message:
            payload["system"] = system_message
        
        try:
            async with self.client.stream("POST", self.API_URL, json=payload) as response:
                response.raise_for_status()
                async for line in response.aiter_lines():
                    if line.startswith("data: "):
                        data = line[6:]
                        try:
                            chunk = json.loads(data)
                            if chunk["type"] == "content_block_delta":
                                yield chunk["delta"]["text"]
                        except json.JSONDecodeError:
                            continue
        except Exception as e:
            app_logger.error(f"Anthropic streaming error: {e}")
            raise


class MedicalLLMAnalyzer:
    """
    Medical analyzer powered by LLM
    Combines traditional analysis with LLM insights
    """
    
    SYSTEM_PROMPT = """You are an expert vascular surgeon AI assistant. Your role is to:
1. Analyze medical cases based on provided clinical data
2. Suggest differential diagnoses
3. Recommend appropriate investigations
4. Propose treatment options based on current guidelines
5. Highlight red flags and urgent situations

Important guidelines:
- Always cite evidence-based recommendations
- Include confidence levels for your suggestions
- Highlight when urgent intervention is needed
- Consider patient comorbidities and contraindications
- Suggest alternative approaches when appropriate
- Include follow-up recommendations

Format your response with clear sections:
- ANALYSIS
- DIFFERENTIAL DIAGNOSES (with confidence)
- RECOMMENDED INVESTIGATIONS
- TREATMENT OPTIONS
- RED FLAGS / URGENT CONCERNS
- FOLLOW-UP PLAN"""

    def __init__(self, provider: str = "openai"):
        if provider == "openai":
            api_key = os.getenv("OPENAI_API_KEY")
            if not api_key:
                raise ValueError("OPENAI_API_KEY environment variable not set")
            self.llm = OpenAIProvider(api_key)
        elif provider == "anthropic":
            api_key = os.getenv("ANTHROPIC_API_KEY")
            if not api_key:
                raise ValueError("ANTHROPIC_API_KEY environment variable not set")
            self.llm = AnthropicProvider(api_key)
        else:
            raise ValueError(f"Unknown provider: {provider}")
    
    async def analyze_case(
        self,
        case_description: str,
        patient_data: Optional[Dict[str, Any]] = None,
        include_sources: bool = True
    ) -> Dict[str, Any]:
        """
        Analyze a medical case using LLM
        
        Args:
            case_description: Description of the clinical case
            patient_data: Additional patient information
            include_sources: Whether to include source citations
        
        Returns:
            Structured analysis results
        """
        
        # Build prompt
        prompt = self._build_analysis_prompt(case_description, patient_data)
        
        # Generate response
        response = await self.llm.generate(
            prompt=prompt,
            system_message=self.SYSTEM_PROMPT,
            temperature=0.3,
            max_tokens=3000
        )
        
        # Parse response
        analysis = self._parse_analysis_response(response.content)
        
        return {
            "analysis": analysis,
            "raw_response": response.content,
            "model": response.model,
            "tokens_used": response.tokens_used,
            "timestamp": response.timestamp.isoformat()
        }
    
    async def generate_report(
        self,
        study_data: Dict[str, Any],
        findings: List[str],
        template: str = "standard"
    ) -> str:
        """
        Generate a structured medical report
        
        Args:
            study_data: Study information
            findings: List of findings
            template: Report template type
        
        Returns:
            Generated report text
        """
        
        prompt = f"""Generate a professional vascular imaging report based on the following:

STUDY INFORMATION:
{json.dumps(study_data, indent=2)}

FINDINGS:
{chr(10).join(f"- {f}" for f in findings)}

TEMPLATE: {template}

Generate a complete report with:
1. CLINICAL INDICATION
2. TECHNIQUE
3. COMPARISON
4. FINDINGS (detailed)
5. IMPRESSION/CONCLUSION
6. RECOMMENDATIONS"""

        response = await self.llm.generate(
            prompt=prompt,
            system_message="You are an expert radiologist specializing in vascular imaging.",
            temperature=0.2,
            max_tokens=2500
        )
        
        return response.content
    
    async def answer_question(
        self,
        question: str,
        context: Optional[str] = None
    ) -> str:
        """
        Answer a medical question
        
        Args:
            question: The question to answer
            context: Additional context
        
        Returns:
            Answer text
        """
        
        prompt = question
        if context:
            prompt = f"Context:\n{context}\n\nQuestion: {question}"
        
        response = await self.llm.generate(
            prompt=prompt,
            system_message=self.SYSTEM_PROMPT,
            temperature=0.3,
            max_tokens=1500
        )
        
        return response.content
    
    def _build_analysis_prompt(
        self,
        case_description: str,
        patient_data: Optional[Dict[str, Any]]
    ) -> str:
        """Build analysis prompt"""
        
        prompt = f"""Please analyze the following clinical case:

CASE DESCRIPTION:
{case_description}
"""
        
        if patient_data:
            prompt += f"""
PATIENT DATA:
{json.dumps(patient_data, indent=2)}
"""
        
        prompt += """
Please provide a comprehensive analysis following the format specified in your instructions."""
        
        return prompt
    
    def _parse_analysis_response(self, content: str) -> Dict[str, Any]:
        """Parse LLM analysis response into structured format"""
        
        sections = {
            "analysis": "",
            "differential_diagnoses": [],
            "investigations": [],
            "treatment_options": [],
            "red_flags": [],
            "follow_up": ""
        }
        
        current_section = None
        lines = content.split('\n')
        
        for line in lines:
            line_upper = line.upper().strip()
            
            if 'ANALYSIS' in line_upper and len(line_upper) < 20:
                current_section = "analysis"
            elif 'DIFFERENTIAL' in line_upper:
                current_section = "differential_diagnoses"
            elif 'INVESTIGATION' in line_upper:
                current_section = "investigations"
            elif 'TREATMENT' in line_upper or 'OPTIONS' in line_upper:
                current_section = "treatment_options"
            elif 'RED FLAG' in line_upper or 'URGENT' in line_upper:
                current_section = "red_flags"
            elif 'FOLLOW' in line_upper:
                current_section = "follow_up"
            elif current_section and line.strip():
                if current_section in ["differential_diagnoses", "investigations", "treatment_options", "red_flags"]:
                    if line.strip().startswith('-') or line.strip().startswith('•'):
                        sections[current_section].append(line.strip()[1:].strip())
                    elif line.strip()[0].isdigit():
                        sections[current_section].append(line.strip())
                else:
                    sections[current_section] += line + '\n'
        
        return sections


class StreamingMedicalAnalyzer:
    """Streaming version of medical analyzer"""
    
    def __init__(self, provider: str = "openai"):
        self.analyzer = MedicalLLMAnalyzer(provider)
    
    async def analyze_case_streaming(
        self,
        case_description: str,
        patient_data: Optional[Dict[str, Any]] = None
    ) -> AsyncGenerator[str, None]:
        """Stream analysis results"""
        
        prompt = self.analyzer._build_analysis_prompt(case_description, patient_data)
        
        async for chunk in self.analyzer.llm.stream(
            prompt=prompt,
            system_message=self.analyzer.SYSTEM_PROMPT,
            temperature=0.3,
            max_tokens=3000
        ):
            yield chunk


# Factory function
def get_llm_analyzer(provider: str = "openai") -> MedicalLLMAnalyzer:
    """Get LLM analyzer instance"""
    return MedicalLLMAnalyzer(provider)
