# Agent Integrations
from .lab_integration import LaboratoryAgentIntegration

__all__ = ["LaboratoryAgentIntegration"]
