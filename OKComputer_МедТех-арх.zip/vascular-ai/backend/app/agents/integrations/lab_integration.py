"""
AI Agent Integration with Laboratory Data
Интеграция AI агентов с лабораторными данными
"""

from typing import Dict, List, Any, Optional
from datetime import datetime, timedelta
from uuid import UUID

from sqlalchemy.ext.asyncio import AsyncSession

from app.laboratory.service import LaboratoryService
from app.laboratory.models import TestResult
from app.agents.specialized.vascular_surgery_agent import VascularSurgeryAgent
from app.agents.specialized.phlebology_agent import PhlebologyAgent


class LabAIIntegration:
    """Интеграция лабораторных данных с AI агентами"""
    
    def __init__(self, db: AsyncSession):
        self.db = db
        self.lab_service = LaboratoryService(db)
    
    async def analyze_patient_with_labs(
        self,
        patient_id: UUID,
        query: str,
        agent_type: str = "vascular_surgery",
        date_range_days: int = 30
    ) -> Dict[str, Any]:
        """
        Анализ пациента с учетом лабораторных данных
        
        Args:
            patient_id: ID пациента
            query: Клинический запрос
            agent_type: Тип AI агента
            date_range_days: Диапазон дат для лабораторных данных
        """
        # Получить лабораторные данные
        date_from = datetime.utcnow() - timedelta(days=date_range_days)
        
        from app.laboratory.schemas import TestResultSearchParams
        lab_results = await self.lab_service.get_patient_results(
            TestResultSearchParams(
                patient_id=patient_id,
                date_from=date_from,
                limit=100
            )
        )
        
        # Структурировать лабораторные данные
        lab_summary = self._summarize_lab_results(lab_results)
        
        # Получить критические значения
        critical_results = [r for r in lab_results if r.is_critical]
        abnormal_results = [r for r in lab_results if r.is_abnormal and not r.is_critical]
        
        # Сформировать контекст для AI агента
        lab_context = self._format_lab_context(lab_summary, critical_results, abnormal_results)
        
        # Выбрать и вызвать AI агента
        agent = self._get_agent(agent_type)
        
        analysis = await agent.analyze(
            query=query,
            patient_context={
                "patient_id": str(patient_id),
                "lab_data": lab_context,
                "critical_values": len(critical_results),
                "abnormal_values": len(abnormal_results)
            },
            include_literature=True,
            include_guidelines=True
        )
        
        # Добавить лабораторный контекст к результату
        analysis["lab_summary"] = lab_summary
        analysis["critical_results"] = [
            {
                "test_name": r.test_name,
                "value": float(r.value_numeric) if r.value_numeric else None,
                "unit": r.unit,
                "interpretation": r.interpretation,
                "date": r.created_at.isoformat()
            }
            for r in critical_results
        ]
        
        return analysis
    
    async def preoperative_lab_assessment(
        self,
        patient_id: UUID,
        procedure_type: str
    ) -> Dict[str, Any]:
        """
        Дооперационная оценка на основе лабораторных данных
        
        Args:
            patient_id: ID пациента
            procedure_type: Тип процедуры (evar, open_surgery, etc.)
        """
        # Получить релевантные лабораторные тесты
        relevant_tests = self._get_preop_tests(procedure_type)
        
        from app.laboratory.schemas import TestResultSearchParams
        results = await self.lab_service.get_patient_results(
            TestResultSearchParams(
                patient_id=patient_id,
                limit=50
            )
        )
        
        # Отфильтровать релевантные тесты
        relevant_results = [
            r for r in results 
            if r.test_code in relevant_tests
        ]
        
        # Оценить риски
        risk_assessment = self._assess_surgical_risks(relevant_results, procedure_type)
        
        # Сформировать рекомендации
        recommendations = self._generate_preop_recommendations(
            relevant_results, risk_assessment, procedure_type
        )
        
        return {
            "procedure_type": procedure_type,
            "lab_results": [
                {
                    "test_code": r.test_code,
                    "test_name": r.test_name,
                    "value": float(r.value_numeric) if r.value_numeric else None,
                    "unit": r.unit,
                    "interpretation": r.interpretation,
                    "is_critical": r.is_critical
                }
                for r in relevant_results
            ],
            "risk_assessment": risk_assessment,
            "recommendations": recommendations,
            "clearance": risk_assessment["overall_risk"] not in ["high", "prohibitive"]
        }
    
    async def monitor_postoperative_labs(
        self,
        patient_id: UUID,
        procedure_type: str,
        days_postop: int
    ) -> Dict[str, Any]:
        """
        Мониторинг послеоперационных лабораторных показателей
        """
        # Получить данные за период после операции
        date_from = datetime.utcnow() - timedelta(days=days_postop + 1)
        date_to = datetime.utcnow() - timedelta(days=days_postop - 1)
        
        from app.laboratory.schemas import TestResultSearchParams
        results = await self.lab_service.get_patient_results(
            TestResultSearchParams(
                patient_id=patient_id,
                date_from=date_from,
                date_to=date_to,
                limit=50
            )
        )
        
        # Определить ожидаемые изменения
        expected_changes = self._get_expected_postop_changes(procedure_type, days_postop)
        
        # Выявить отклонения
        concerns = []
        for result in results:
            if result.is_critical:
                concerns.append({
                    "test": result.test_name,
                    "value": float(result.value_numeric) if result.value_numeric else None,
                    "concern": "Critical value",
                    "action": "Immediate attention required"
                })
            elif result.test_code in expected_changes:
                expected = expected_changes[result.test_code]
                if not expected["range"][0] <= (result.value_numeric or 0) <= expected["range"][1]:
                    concerns.append({
                        "test": result.test_name,
                        "value": float(result.value_numeric) if result.value_numeric else None,
                        "concern": f"Outside expected range ({expected['range'][0]}-{expected['range'][1]})",
                        "action": expected.get("action", "Monitor closely")
                    })
        
        return {
            "days_postop": days_postop,
            "procedure_type": procedure_type,
            "total_tests": len(results),
            "critical_count": len([r for r in results if r.is_critical]),
            "abnormal_count": len([r for r in results if r.is_abnormal]),
            "concerns": concerns,
            "status": "stable" if not concerns else "requires_attention"
        }
    
    async def drug_dosing_adjustment(
        self,
        patient_id: UUID,
        drug_name: str,
        standard_dose: float
    ) -> Dict[str, Any]:
        """
        Рекомендации по корректировке дозировки на основе лабораторных данных
        """
        # Получить релевантные показатели
        from app.laboratory.schemas import TestResultSearchParams
        
        # Функция почек
        creatinine_results = await self.lab_service.get_patient_results(
            TestResultSearchParams(
                patient_id=patient_id,
                test_code="CREATININE",
                limit=1
            )
        )
        
        # Функция печени
        liver_results = await self.lab_service.get_patient_results(
            TestResultSearchParams(
                patient_id=patient_id,
                test_codes=["ALT", "AST", "BILIRUBIN", "ALBUMIN"],
                limit=5
            )
        )
        
        # Рассчитать СКФ
        egfr = None
        if creatinine_results:
            latest_creatinine = creatinine_results[0]
            egfr = self._calculate_egfr(latest_creatinine)
        
        # Оценить функцию печени
        liver_status = self._assess_liver_function(liver_results)
        
        # Рассчитать скорректированную дозу
        adjusted_dose = self._calculate_adjusted_dose(
            drug_name, standard_dose, egfr, liver_status
        )
        
        return {
            "drug": drug_name,
            "standard_dose": standard_dose,
            "adjusted_dose": adjusted_dose["dose"],
            "adjustment_factor": adjusted_dose["factor"],
            "reason": adjusted_dose["reason"],
            "renal_function": {
                "creatinine": float(latest_creatinine.value_numeric) if creatinine_results else None,
                "egfr": egfr,
                "status": self._classify_egfr(egfr)
            },
            "hepatic_function": liver_status,
            "monitoring": adjusted_dose["monitoring"]
        }
    
    def _summarize_lab_results(self, results: List[TestResult]) -> Dict[str, Any]:
        """Создать сводку лабораторных результатов"""
        summary = {
            "total_tests": len(results),
            "by_category": {},
            "abnormal": [],
            "critical": [],
            "recent_values": {}
        }
        
        for result in results:
            # По категориям
            cat = result.category
            if cat not in summary["by_category"]:
                summary["by_category"][cat] = []
            summary["by_category"][cat].append({
                "test": result.test_name,
                "value": float(result.value_numeric) if result.value_numeric else None,
                "unit": result.unit,
                "interpretation": result.interpretation
            })
            
            # Критические и отклоненные
            if result.is_critical:
                summary["critical"].append({
                    "test": result.test_name,
                    "value": float(result.value_numeric) if result.value_numeric else None,
                    "interpretation": result.interpretation
                })
            elif result.is_abnormal:
                summary["abnormal"].append({
                    "test": result.test_name,
                    "value": float(result.value_numeric) if result.value_numeric else None,
                    "interpretation": result.interpretation
                })
            
            # Последние значения по тестам
            if result.test_code not in summary["recent_values"]:
                summary["recent_values"][result.test_code] = {
                    "name": result.test_name,
                    "value": float(result.value_numeric) if result.value_numeric else None,
                    "unit": result.unit,
                    "date": result.created_at.isoformat()
                }
        
        return summary
    
    def _format_lab_context(
        self, 
        summary: Dict[str, Any], 
        critical: List[TestResult],
        abnormal: List[TestResult]
    ) -> str:
        """Форматировать лабораторный контекст для AI"""
        context_parts = []
        
        # Критические значения
        if critical:
            context_parts.append("CRITICAL VALUES:")
            for r in critical:
                context_parts.append(f"- {r.test_name}: {r.value_numeric} {r.unit} ({r.interpretation})")
        
        # Отклоненные значения
        if abnormal:
            context_parts.append("\nABNORMAL VALUES:")
            for r in abnormal:
                context_parts.append(f"- {r.test_name}: {r.value_numeric} {r.unit} ({r.interpretation})")
        
        # Ключевые показатели
        key_tests = ["CREATININE", "EGFR", "HEMOGLOBIN", "GLUCOSE", "INR", "PLATELETS"]
        context_parts.append("\nKEY VALUES:")
        for test_code in key_tests:
            if test_code in summary["recent_values"]:
                v = summary["recent_values"][test_code]
                context_parts.append(f"- {v['name']}: {v['value']} {v['unit']}")
        
        return "\n".join(context_parts)
    
    def _get_agent(self, agent_type: str):
        """Получить AI агента по типу"""
        agents = {
            "vascular_surgery": VascularSurgeryAgent(),
            "phlebology": PhlebologyAgent()
        }
        return agents.get(agent_type, VascularSurgeryAgent())
    
    def _get_preop_tests(self, procedure_type: str) -> List[str]:
        """Получить список дооперационных тестов"""
        common_tests = [
            "HEMOGLOBIN", "HEMATOCRIT", "WBC", "PLATELETS",
            "CREATININE", "BUN", "EGFR",
            "GLUCOSE", "HBA1C",
            "PT", "INR", "PTT"
        ]
        
        procedure_specific = {
            "evar": ["D_DIMER", "FIBRINOGEN"],
            "open_surgery": ["ALBUMIN", "BILIRUBIN", "ALT", "AST"],
            "carotid": ["CHOLESTEROL", "LDL", "HDL"]
        }
        
        return common_tests + procedure_specific.get(procedure_type, [])
    
    def _assess_surgical_risks(
        self, 
        results: List[TestResult], 
        procedure_type: str
    ) -> Dict[str, Any]:
        """Оценить хирургические риски"""
        risks = {
            "cardiac": "low",
            "renal": "low",
            "bleeding": "low",
            "infection": "low",
            "overall_risk": "low"
        }
        
        for result in results:
            if result.test_code == "CREATININE" and result.value_numeric:
                if result.value_numeric > 2.0:
                    risks["renal"] = "high"
                elif result.value_numeric > 1.5:
                    risks["renal"] = "moderate"
            
            if result.test_code == "HEMOGLOBIN" and result.value_numeric:
                if result.value_numeric < 8:
                    risks["bleeding"] = "high"
                elif result.value_numeric < 10:
                    risks["bleeding"] = "moderate"
            
            if result.test_code == "GLUCOSE" and result.value_numeric:
                if result.value_numeric > 200:
                    risks["infection"] = "high"
                elif result.value_numeric > 180:
                    risks["infection"] = "moderate"
        
        # Определить общий риск
        risk_scores = {"low": 1, "moderate": 2, "high": 3}
        max_score = max(risk_scores.get(r, 1) for r in risks.values() if r != "overall_risk")
        
        if max_score >= 3:
            risks["overall_risk"] = "high"
        elif max_score >= 2:
            risks["overall_risk"] = "moderate"
        
        return risks
    
    def _generate_preop_recommendations(
        self,
        results: List[TestResult],
        risk_assessment: Dict[str, Any],
        procedure_type: str
    ) -> List[str]:
        """Сгенерировать дооперационные рекомендации"""
        recommendations = []
        
        if risk_assessment["renal"] in ["moderate", "high"]:
            recommendations.append("Nephrology consultation recommended")
            recommendations.append("Avoid nephrotoxic agents")
        
        if risk_assessment["bleeding"] in ["moderate", "high"]:
            recommendations.append("Type and crossmatch blood products")
            recommendations.append("Consider preoperative transfusion if Hgb <8")
        
        if risk_assessment["infection"] == "high":
            recommendations.append("Optimize glucose control before surgery")
            recommendations.append("Consider endocrinology consultation")
        
        recommendations.append("Continue antihypertensive medications")
        recommendations.append("Hold anticoagulants per protocol")
        
        return recommendations
    
    def _get_expected_postop_changes(
        self, 
        procedure_type: str, 
        days_postop: int
    ) -> Dict[str, Any]:
        """Получить ожидаемые послеоперационные изменения"""
        # Упрощенная логика
        if days_postop <= 1:
            return {
                "WBC": {"range": [10000, 15000], "action": "Normal postoperative leukocytosis"},
                "CREATININE": {"range": [0.5, 1.5], "action": "Monitor for AKI"}
            }
        elif days_postop <= 3:
            return {
                "WBC": {"range": [8000, 12000], "action": "Should be trending down"},
                "CREATININE": {"range": [0.5, 1.3], "action": "Should normalize"}
            }
        else:
            return {
                "WBC": {"range": [4000, 10000], "action": "Should normalize"},
                "CREATININE": {"range": [0.5, 1.2], "action": "Should normalize"}
            }
    
    def _calculate_egfr(self, creatinine_result: TestResult) -> Optional[float]:
        """Рассчитать СКФ по CKD-EPI"""
        if not creatinine_result.value_numeric:
            return None
        
        creatinine = float(creatinine_result.value_numeric)
        # Упрощенная формула (без возраста и пола)
        # В реальности нужны дополнительные данные пациента
        egfr = 175 * (creatinine ** -1.154) * (70 ** -0.203)  # Для возраста 70
        return round(egfr, 1)
    
    def _assess_liver_function(self, results: List[TestResult]) -> Dict[str, Any]:
        """Оценить функцию печени"""
        status = {
            "status": "normal",
            "child_pugh": "A",
            "factors": []
        }
        
        for result in results:
            if result.test_code == "ALBUMIN" and result.value_numeric:
                if result.value_numeric < 2.8:
                    status["factors"].append("Low albumin")
                elif result.value_numeric < 3.5:
                    status["factors"].append("Borderline albumin")
            
            if result.test_code == "BILIRUBIN" and result.value_numeric:
                if result.value_numeric > 3:
                    status["factors"].append("Elevated bilirubin")
        
        if len(status["factors"]) >= 2:
            status["status"] = "impaired"
        elif len(status["factors"]) == 1:
            status["status"] = "borderline"
        
        return status
    
    def _calculate_adjusted_dose(
        self,
        drug_name: str,
        standard_dose: float,
        egfr: Optional[float],
        liver_status: Dict[str, Any]
    ) -> Dict[str, Any]:
        """Рассчитать скорректированную дозу"""
        result = {
            "dose": standard_dose,
            "factor": 1.0,
            "reason": "No adjustment needed",
            "monitoring": []
        }
        
        # Примеры корректировок
        renal_drugs = {
            "metformin": {"threshold": 30, "factor": 0.5, "contraindicated": 15},
            "vancomycin": {"threshold": 50, "factor": 0.75},
            "enoxaparin": {"threshold": 30, "factor": 0.5}
        }
        
        drug_lower = drug_name.lower()
        if drug_lower in renal_drugs and egfr:
            config = renal_drugs[drug_lower]
            if egfr < config.get("contraindicated", 0):
                result["dose"] = 0
                result["factor"] = 0
                result["reason"] = f"Contraindicated with eGFR < {config['contraindicated']}"
            elif egfr < config["threshold"]:
                result["dose"] = standard_dose * config["factor"]
                result["factor"] = config["factor"]
                result["reason"] = f"Reduced dose due to renal impairment (eGFR {egfr})"
                result["monitoring"].append("Monitor drug levels")
        
        return result
    
    def _classify_egfr(self, egfr: Optional[float]) -> str:
        """Классифицировать СКФ по CKD stages"""
        if egfr is None:
            return "unknown"
        if egfr >= 90:
            return "normal"
        elif egfr >= 60:
            return "mildly_decreased"
        elif egfr >= 30:
            return "moderately_decreased"
        elif egfr >= 15:
            return "severely_decreased"
        else:
            return "kidney_failure"