"""
VASCULAR.AI - Scientific Knowledge Integrator
Интеграция с научными источниками: PubMed, Google Scholar, Clinical Guidelines
"""

import asyncio
import aiohttp
from typing import Dict, List, Any, Optional
from datetime import datetime, timedelta
from dataclasses import dataclass
import xml.etree.ElementTree as ET
import json
import re

from app.core.logging import app_logger
from app.agents.base.medical_agent import ScientificSource, EvidenceLevel, RecommendationClass


@dataclass
class PubMedArticle:
    """Статья из PubMed"""
    pmid: str
    title: str
    abstract: str
    authors: List[str]
    journal: str
    publication_date: datetime
    doi: Optional[str] = None
    mesh_terms: List[str] = None
    keywords: List[str] = None
    citations: int = 0
    
    def to_scientific_source(self) -> ScientificSource:
        return ScientificSource(
            title=self.title,
            authors=self.authors,
            journal=self.journal,
            year=self.publication_date.year,
            doi=self.doi or "",
            pmid=self.pmid,
            evidence_level=self._determine_evidence_level(),
            abstract=self.abstract,
            key_findings=self._extract_key_findings(),
            citations=self.citations,
            url=f"https://pubmed.ncbi.nlm.nih.gov/{self.pmid}/"
        )
    
    def _determine_evidence_level(self) -> EvidenceLevel:
        """Определение уровня доказательности на основе MeSH терминов"""
        mesh_lower = [m.lower() for m in (self.mesh_terms or [])]
        
        if any(term in mesh_lower for term in ["randomized controlled trial", "systematic review"]):
            return EvidenceLevel.IB
        elif any(term in mesh_lower for term in ["meta-analysis", "systematic review"]):
            return EvidenceLevel.IA
        elif any(term in mesh_lower for term in ["cohort studies", "prospective studies"]):
            return EvidenceLevel.IIB
        elif any(term in mesh_lower for term in ["case-control studies"]):
            return EvidenceLevel.IIIB
        elif any(term in mesh_lower for term in ["case reports", "case series"]):
            return EvidenceLevel.IV
        
        return EvidenceLevel.V
    
    def _extract_key_findings(self) -> List[str]:
        """Извлечение ключевых выводов из abstract"""
        findings = []
        
        # Ищем предложения с ключевыми словами
        conclusion_patterns = [
            r'conclusion[s]?[:;]\s*([^\.]+\.[^\.]+)',
            r'result[s]?[:;]\s*([^\.]+\.[^\.]+)',
            r'we found that\s+([^\.]+)',
            r'this study demonstrates?\s+([^\.]+)',
            r'these findings suggest\s+([^\.]+)',
        ]
        
        for pattern in conclusion_patterns:
            matches = re.findall(pattern, self.abstract.lower())
            for match in matches[:2]:  # Берем первые 2 совпадения
                finding = match[0] if isinstance(match, tuple) else match
                finding = finding.strip().capitalize()
                if len(finding) > 20:
                    findings.append(finding)
        
        return findings[:3]  # Максимум 3 ключевых вывода


class PubMedIntegrator:
    """Интеграция с PubMed/NCBI E-utilities API"""
    
    BASE_URL = "https://eutils.ncbi.nlm.nih.gov/entrez/eutils"
    
    def __init__(self, api_key: Optional[str] = None):
        self.api_key = api_key
        self.rate_limit_delay = 0.34 if api_key else 1.0  # NCBI rate limits
        self.last_request_time: Optional[datetime] = None
    
    async def _make_request(self, endpoint: str, params: Dict[str, Any]) -> str:
        """Выполнение запроса к NCBI API с учетом rate limiting"""
        
        # Rate limiting
        if self.last_request_time:
            elapsed = (datetime.utcnow() - self.last_request_time).total_seconds()
            if elapsed < self.rate_limit_delay:
                await asyncio.sleep(self.rate_limit_delay - elapsed)
        
        url = f"{self.BASE_URL}/{endpoint}"
        if self.api_key:
            params["api_key"] = self.api_key
        
        async with aiohttp.ClientSession() as session:
            async with session.get(url, params=params) as response:
                self.last_request_time = datetime.utcnow()
                if response.status == 200:
                    return await response.text()
                else:
                    app_logger.error(f"PubMed API error: {response.status}")
                    return ""
    
    async def search(
        self,
        query: str,
        max_results: int = 20,
        sort_by: str = "relevance",
        publication_date_filter: Optional[str] = None,
        article_types: List[str] = None
    ) -> List[str]:
        """
        Поиск статей в PubMed
        
        Args:
            query: Поисковый запрос
            max_results: Максимальное количество результатов
            sort_by: Сортировка (relevance, date)
            publication_date_filter: Фильтр по дате (например, "2020:2024[dp]")
            article_types: Типы статей ("Clinical Trial", "Review", etc.)
        
        Returns:
            Список PMIDs
        """
        # Формируем запрос
        search_query = query
        
        if publication_date_filter:
            search_query += f" AND {publication_date_filter}"
        
        if article_types:
            types_filter = " OR ".join([f'"{t}"[pt]' for t in article_types])
            search_query += f" AND ({types_filter})"
        
        params = {
            "db": "pubmed",
            "term": search_query,
            "retmax": max_results,
            "sort": sort_by,
            "retmode": "json",
            "usehistory": "y"
        }
        
        response = await self._make_request("esearch.fcgi", params)
        
        if not response:
            return []
        
        try:
            data = json.loads(response)
            idlist = data.get("esearchresult", {}).get("idlist", [])
            return idlist
        except json.JSONDecodeError:
            app_logger.error("Failed to parse PubMed search response")
            return []
    
    async def fetch_article_details(self, pmids: List[str]) -> List[PubMedArticle]:
        """
        Получение деталей статей по PMIDs
        
        Args:
            pmids: Список PubMed IDs
        
        Returns:
            Список PubMedArticle
        """
        if not pmids:
            return []
        
        params = {
            "db": "pubmed",
            "id": ",".join(pmids),
            "retmode": "xml"
        }
        
        response = await self._make_request("efetch.fcgi", params)
        
        if not response:
            return []
        
        return self._parse_pubmed_xml(response)
    
    def _parse_pubmed_xml(self, xml_content: str) -> List[PubMedArticle]:
        """Парсинг XML ответа PubMed"""
        
        articles = []
        
        try:
            root = ET.fromstring(xml_content)
            
            for article_elem in root.findall(".//PubmedArticle"):
                try:
                    # PMID
                    pmid_elem = article_elem.find(".//PMID")
                    pmid = pmid_elem.text if pmid_elem is not None else ""
                    
                    # Title
                    title_elem = article_elem.find(".//ArticleTitle")
                    title = title_elem.text if title_elem is not None else ""
                    
                    # Abstract
                    abstract_elems = article_elem.findall(".//AbstractText")
                    abstract = " ".join([e.text or "" for e in abstract_elems])
                    
                    # Authors
                    authors = []
                    for author_elem in article_elem.findall(".//Author"):
                        lastname = author_elem.findtext("LastName", "")
                        forename = author_elem.findtext("ForeName", "")
                        if lastname:
                            authors.append(f"{lastname} {forename}".strip())
                    
                    # Journal
                    journal_elem = article_elem.find(".//Journal/Title")
                    journal = journal_elem.text if journal_elem is not None else ""
                    
                    # Publication date
                    year_elem = article_elem.find(".//PubDate/Year")
                    month_elem = article_elem.find(".//PubDate/Month")
                    day_elem = article_elem.find(".//PubDate/Day")
                    
                    year = int(year_elem.text) if year_elem is not None else 0
                    try:
                        pub_date = datetime(year, 1, 1)
                    except:
                        pub_date = datetime.utcnow()
                    
                    # DOI
                    doi_elem = article_elem.find(".//ArticleId[@IdType='doi']")
                    doi = doi_elem.text if doi_elem is not None else None
                    
                    # MeSH terms
                    mesh_terms = []
                    for mesh_elem in article_elem.findall(".//MeshHeading/DescriptorName"):
                        if mesh_elem.text:
                            mesh_terms.append(mesh_elem.text)
                    
                    article = PubMedArticle(
                        pmid=pmid,
                        title=title,
                        abstract=abstract,
                        authors=authors,
                        journal=journal,
                        publication_date=pub_date,
                        doi=doi,
                        mesh_terms=mesh_terms
                    )
                    
                    articles.append(article)
                    
                except Exception as e:
                    app_logger.error(f"Error parsing article: {e}")
                    continue
                    
        except ET.ParseError as e:
            app_logger.error(f"XML parse error: {e}")
        
        return articles
    
    async def search_and_fetch(
        self,
        query: str,
        max_results: int = 10,
        min_year: Optional[int] = None
    ) -> List[ScientificSource]:
        """Комбинированный поиск и получение деталей"""
        
        # Формируем фильтр по дате
        date_filter = None
        if min_year:
            current_year = datetime.utcnow().year
            date_filter = f"{min_year}:{current_year}[dp]"
        
        # Поиск
        pmids = await self.search(
            query=query,
            max_results=max_results,
            publication_date_filter=date_filter,
            article_types=["Clinical Trial", "Review", "Guideline", "Meta-Analysis"]
        )
        
        # Получение деталей
        articles = await self.fetch_article_details(pmids)
        
        # Конвертация в ScientificSource
        return [article.to_scientific_source() for article in articles]


class ClinicalGuidelinesIntegrator:
    """Интеграция с клиническими рекомендациями"""
    
    GUIDELINE_SOURCES = {
        "ESVS": {
            "name": "European Society for Vascular Surgery",
            "base_url": "https://www.esvs.org/guidelines/",
            "topics": [
                "aortic-aneurysm", "carotid", "mesenteric", "renal", 
                "lower-limb", "venous", "access"
            ]
        },
        "SVS": {
            "name": "Society for Vascular Surgery",
            "base_url": "https://vascular.org/patient-resources/vascular-guidelines",
            "topics": [
                "aaa", "carotid", "pad", "venous", "dialysis-access"
            ]
        },
        "ACC_AHA": {
            "name": "ACC/AHA",
            "base_url": "https://www.acc.org/guidelines",
            "topics": [
                "pad", "aaa", "carotid"
            ]
        },
        "ESC": {
            "name": "European Society of Cardiology",
            "base_url": "https://www.escardio.org/Guidelines",
            "topics": [
                "pad", "aaa"
            ]
        }
    }
    
    def __init__(self):
        self.guidelines_cache: Dict[str, Any] = {}
        self.cache_timestamp: Optional[datetime] = None
    
    async def get_guidelines(
        self,
        condition: str,
        sources: List[str] = None
    ) -> List[Dict[str, Any]]:
        """
        Получение клинических рекомендаций
        
        Args:
            condition: Заболевание (aortic aneurysm, carotid stenosis, etc.)
            sources: Источники (ESVS, SVS, ACC_AHA, ESC)
        
        Returns:
            Список рекомендаций
        """
        sources = sources or ["ESVS", "SVS"]
        
        guidelines = []
        
        for source in sources:
            if source in self.GUIDELINE_SOURCES:
                source_guidelines = await self._fetch_from_source(source, condition)
                guidelines.extend(source_guidelines)
        
        return guidelines
    
    async def _fetch_from_source(
        self,
        source: str,
        condition: str
    ) -> List[Dict[str, Any]]:
        """Получение guidelines из конкретного источника"""
        
        # В реальной реализации здесь будет парсинг веб-страниц или API
        # Пока возвращаем структурированные данные
        
        source_info = self.GUIDELINE_SOURCES[source]
        
        # Маппинг условий к топикам
        condition_mapping = {
            "aortic aneurysm": "aortic-aneurysm",
            "aaa": "aortic-aneurysm",
            "carotid stenosis": "carotid",
            "carotid": "carotid",
            "pad": "lower-limb",
            "claudication": "lower-limb",
            "dvt": "venous",
            "varicose veins": "venous",
        }
        
        topic = condition_mapping.get(condition.lower(), condition.lower().replace(" ", "-"))
        
        # Симуляция получения данных
        return [{
            "source": source,
            "source_name": source_info["name"],
            "topic": topic,
            "condition": condition,
            "url": f"{source_info['base_url']}{topic}",
            "last_updated": "2024",
            "recommendations": [],  # Будет заполнено из реальных данных
            "note": "Integration with live guideline databases required"
        }]
    
    async def search_guideline_recommendations(
        self,
        query: str,
        recommendation_class: Optional[str] = None
    ) -> List[Dict[str, Any]]:
        """Поиск конкретных рекомендаций в guidelines"""
        
        # Будет реализовано с интеграцией реальных guideline баз
        return []


class ScientificKnowledgeManager:
    """
    Центральный менеджер научных знаний
    Объединяет все источники и управляет обновлениями
    """
    
    def __init__(self, pubmed_api_key: Optional[str] = None):
        self.pubmed = PubMedIntegrator(api_key=pubmed_api_key)
        self.guidelines = ClinicalGuidelinesIntegrator()
        self.knowledge_cache: Dict[str, Any] = {}
        self.last_update: Optional[datetime] = None
        self.update_interval = timedelta(hours=24)
    
    async def search_literature(
        self,
        query: str,
        max_results: int = 10,
        min_year: Optional[int] = None,
        include_guidelines: bool = True
    ) -> Dict[str, List[Any]]:
        """
        Комплексный поиск по всем источникам
        
        Returns:
            {"pubmed": [...], "guidelines": [...]}
        """
        results = {
            "pubmed": [],
            "guidelines": []
        }
        
        # PubMed search
        try:
            pubmed_results = await self.pubmed.search_and_fetch(
                query=query,
                max_results=max_results,
                min_year=min_year
            )
            results["pubmed"] = pubmed_results
        except Exception as e:
            app_logger.error(f"PubMed search error: {e}")
        
        # Guidelines search
        if include_guidelines:
            try:
                guideline_results = await self.guidelines.get_guidelines(query)
                results["guidelines"] = guideline_results
            except Exception as e:
                app_logger.error(f"Guidelines search error: {e}")
        
        return results
    
    async def update_knowledge_base(self) -> bool:
        """Обновление базы знаний из всех источников"""
        
        # Проверяем необходимость обновления
        if self.last_update and (datetime.utcnow() - self.last_update) < self.update_interval:
            app_logger.info("Knowledge base is up to date")
            return True
        
        app_logger.info("Updating knowledge base...")
        
        # Обновление кэша
        self.last_update = datetime.utcnow()
        
        return True
    
    def get_evidence_summary(
        self,
        sources: List[ScientificSource]
    ) -> Dict[str, Any]:
        """Создание сводки по уровням доказательности"""
        
        evidence_counts = {
            "Ia": 0, "Ib": 0, "IIa": 0, "IIb": 0,
            "IIIa": 0, "IIIb": 0, "IV": 0, "V": 0
        }
        
        for source in sources:
            evidence_counts[source.evidence_level.value] += 1
        
        total = len(sources)
        
        return {
            "total_sources": total,
            "evidence_distribution": evidence_counts,
            "high_quality_percentage": round(
                (evidence_counts["Ia"] + evidence_counts["Ib"] + evidence_counts["IIa"]) / total * 100, 1
            ) if total > 0 else 0,
            "latest_year": max([s.year for s in sources]) if sources else None,
            "average_citations": round(
                sum([s.citations for s in sources]) / total, 1
            ) if total > 0 else 0
        }
