"""
VASCULAR.AI - Medical AI Agents System
Система специализированных AI-агентов для различных областей сосудистой медицины
"""

from typing import List, Optional, Dict, Any

from app.agents.base.medical_agent import (
    MedicalAIAgent,
    AgentAnalysis,
    ScientificSource,
    EvidenceLevel,
    RecommendationClass
)

from app.agents.specialized.vascular_surgery_agent import VascularSurgeryAgent
from app.agents.specialized.phlebology_agent import PhlebologyAgent
from app.agents.specialized.neurointervention_agent import NeurointerventionAgent
from app.agents.specialized.endovascular_agent import EndovascularAgent

from app.agents.validation.agent_validator import (
    AgentOutputValidator,
    MultiAgentConsensus,
    ValidationResult
)

from app.agents.knowledge.scientific_integrator import (
    ScientificKnowledgeManager,
    PubMedIntegrator,
    ClinicalGuidelinesIntegrator
)

__all__ = [
    # Base
    "MedicalAIAgent",
    "AgentAnalysis",
    "ScientificSource",
    "EvidenceLevel",
    "RecommendationClass",
    
    # Specialized Agents
    "VascularSurgeryAgent",
    "PhlebologyAgent",
    "NeurointerventionAgent",
    "EndovascularAgent",
    
    # Validation
    "AgentOutputValidator",
    "MultiAgentConsensus",
    "ValidationResult",
    
    # Knowledge
    "ScientificKnowledgeManager",
    "PubMedIntegrator",
    "ClinicalGuidelinesIntegrator",
]


# Singleton instances для использования в приложении
_agents: dict = {}
_validator: AgentOutputValidator = None
_consensus: MultiAgentConsensus = None


def get_agent(agent_type: str, pubmed_api_key: str = None) -> MedicalAIAgent:
    """
    Получение или создание агента указанного типа
    
    Args:
        agent_type: Тип агента (vascular, phlebology, neuro, endovascular)
        pubmed_api_key: API ключ для PubMed
    
    Returns:
        Экземпляр агента
    """
    global _agents
    
    if agent_type not in _agents:
        if agent_type == "vascular":
            _agents[agent_type] = VascularSurgeryAgent(pubmed_api_key)
        elif agent_type == "phlebology":
            _agents[agent_type] = PhlebologyAgent(pubmed_api_key)
        elif agent_type == "neuro":
            _agents[agent_type] = NeurointerventionAgent(pubmed_api_key)
        elif agent_type == "endovascular":
            _agents[agent_type] = EndovascularAgent(pubmed_api_key)
        else:
            raise ValueError(f"Unknown agent type: {agent_type}")
    
    return _agents[agent_type]


def get_validator() -> AgentOutputValidator:
    """Получение валидатора агентов"""
    global _validator
    
    if _validator is None:
        _validator = AgentOutputValidator()
    
    return _validator


def get_consensus_engine() -> MultiAgentConsensus:
    """Получение движка консенсуса"""
    global _consensus
    
    if _consensus is None:
        _consensus = MultiAgentConsensus()
    
    return _consensus


async def analyze_with_agents(
    query: str,
    agent_types: Optional[List[str]] = None,
    patient_context: Optional[Dict[str, Any]] = None,
    require_consensus: bool = False,
    pubmed_api_key: Optional[str] = None
) -> Dict[str, Any]:
    """
    Анализ запроса с использованием нескольких агентов
    
    Args:
        query: Медицинский запрос
        agent_types: Список типов агентов (если None - используются все)
        patient_context: Контекст пациента
        require_consensus: Требовать ли консенсус между агентами
        pubmed_api_key: API ключ для PubMed
    
    Returns:
        Результаты анализа
    """
    
    agent_types = agent_types or ["vascular", "phlebology", "neuro", "endovascular"]
    
    # Запускаем анализ параллельно
    import asyncio
    
    tasks = []
    for agent_type in agent_types:
        agent = get_agent(agent_type, pubmed_api_key)
        task = agent.analyze(query, patient_context)
        tasks.append(task)
    
    analyses = await asyncio.gather(*tasks, return_exceptions=True)
    
    # Фильтруем успешные результаты
    successful_analyses = [
        a for a in analyses 
        if not isinstance(a, Exception)
    ]
    
    # Валидация результатов
    validator = get_validator()
    validated_results = []
    
    for analysis in successful_analyses:
        validation = await validator.validate(analysis)
        validated_results.append({
            "analysis": analysis.to_dict(),
            "validation": validation.to_dict()
        })
    
    result = {
        "query": query,
        "agent_results": validated_results,
        "total_agents": len(agent_types),
        "successful_analyses": len(successful_analyses)
    }
    
    # Консенсус, если требуется
    if require_consensus and len(successful_analyses) > 1:
        consensus_engine = get_consensus_engine()
        consensus = await consensus_engine.reach_consensus(successful_analyses, query)
        result["consensus"] = consensus
    
    return result
