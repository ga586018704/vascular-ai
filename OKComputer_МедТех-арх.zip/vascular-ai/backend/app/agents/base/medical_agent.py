"""
VASCULAR.AI - Base Medical AI Agent
Базовый класс для всех медицинских AI-агентов с интеграцией научных данных
"""

from abc import ABC, abstractmethod
from typing import Dict, List, Any, Optional, Tuple
from datetime import datetime, timedelta
from dataclasses import dataclass, field
import json
import asyncio
from enum import Enum
import hashlib

from app.core.logging import app_logger, audit_logger
from app.core.security import AuditLogger


class EvidenceLevel(Enum):
    """Уровень доказательности по Oxford CEBM"""
    IA = "Ia"  # Systematic review of RCTs
    IB = "Ib"  # Individual RCT
    IIA = "IIa"  # Systematic review of cohort studies
    IIB = "IIb"  # Individual cohort study
    IIIA = "IIIa"  # Systematic review of case-control
    IIIB = "IIIb"  # Individual case-control
    IV = "IV"  # Case series
    V = "V"  # Expert opinion


class RecommendationClass(Enum):
    """Класс рекомендаций ACC/AHA/ESC"""
    CLASS_I = "Class I"  # Benefit >>> Risk
    CLASS_IIA = "Class IIa"  # Benefit >> Risk
    CLASS_IIB = "Class IIb"  # Benefit ≥ Risk
    CLASS_III = "Class III"  # Risk ≥ Benefit


@dataclass
class ScientificSource:
    """Научный источник"""
    title: str
    authors: List[str]
    journal: str
    year: int
    doi: str
    pmid: Optional[str] = None
    evidence_level: EvidenceLevel = EvidenceLevel.V
    recommendation_class: Optional[RecommendationClass] = None
    abstract: str = ""
    key_findings: List[str] = field(default_factory=list)
    citations: int = 0
    url: str = ""
    guidelines: List[str] = field(default_factory=list)
    last_updated: datetime = field(default_factory=datetime.utcnow)
    
    def to_dict(self) -> Dict[str, Any]:
        return {
            "title": self.title,
            "authors": self.authors,
            "journal": self.journal,
            "year": self.year,
            "doi": self.doi,
            "pmid": self.pmid,
            "evidence_level": self.evidence_level.value,
            "recommendation_class": self.recommendation_class.value if self.recommendation_class else None,
            "abstract": self.abstract[:500] + "..." if len(self.abstract) > 500 else self.abstract,
            "key_findings": self.key_findings,
            "citations": self.citations,
            "url": self.url,
            "guidelines": self.guidelines,
            "last_updated": self.last_updated.isoformat()
        }


@dataclass
class AgentAnalysis:
    """Результат анализа агента"""
    query: str
    analysis: str
    recommendations: List[str]
    sources: List[ScientificSource]
    confidence_score: float  # 0.0 - 1.0
    evidence_summary: str
    contraindications: List[str]
    alternative_approaches: List[str]
    follow_up_recommendations: List[str]
    timestamp: datetime = field(default_factory=datetime.utcnow)
    agent_type: str = ""
    version: str = "1.0"
    
    def to_dict(self) -> Dict[str, Any]:
        return {
            "query": self.query,
            "analysis": self.analysis,
            "recommendations": self.recommendations,
            "sources": [s.to_dict() for s in self.sources],
            "confidence_score": self.confidence_score,
            "evidence_summary": self.evidence_summary,
            "contraindications": self.contraindications,
            "alternative_approaches": self.alternative_approaches,
            "follow_up_recommendations": self.follow_up_recommendations,
            "timestamp": self.timestamp.isoformat(),
            "agent_type": self.agent_type,
            "version": self.version
        }


class MedicalAIAgent(ABC):
    """
    Базовый класс для всех медицинских AI-агентов
    
    Обеспечивает:
    - Интеграцию с научными источниками
    - Валидацию выводов
    - Аудит всех операций
    - Обновление знаний
    """
    
    def __init__(
        self,
        agent_name: str,
        agent_version: str = "1.0",
        specialty: str = "",
        knowledge_sources: List[str] = None
    ):
        self.agent_name = agent_name
        self.agent_version = agent_version
        self.specialty = specialty
        self.knowledge_sources = knowledge_sources or []
        self.last_knowledge_update: Optional[datetime] = None
        self.analysis_history: List[Dict[str, Any]] = []
        self.cache: Dict[str, Any] = {}
        
        app_logger.info(f"Initialized {agent_name} v{agent_version} for {specialty}")
    
    @abstractmethod
    async def analyze(
        self,
        query: str,
        patient_context: Optional[Dict[str, Any]] = None,
        include_sources: bool = True,
        min_evidence_level: EvidenceLevel = EvidenceLevel.IV
    ) -> AgentAnalysis:
        """
        Основной метод анализа
        
        Args:
            query: Медицинский запрос/сценарий
            patient_context: Контекст пациента (возраст, сопутствующие заболевания и т.д.)
            include_sources: Включать ли научные источники
            min_evidence_level: Минимальный уровень доказательности
        
        Returns:
            AgentAnalysis с рекомендациями и источниками
        """
        pass
    
    @abstractmethod
    async def update_knowledge_base(self) -> bool:
        """
        Обновление базы знаний агента
        
        Returns:
            True если обновление успешно
        """
        pass
    
    async def validate_analysis(
        self,
        analysis: AgentAnalysis,
        validation_rules: Optional[Dict[str, Any]] = None
    ) -> Tuple[bool, List[str]]:
        """
        Валидация результатов анализа
        
        Returns:
            (is_valid, list_of_warnings)
        """
        warnings = []
        
        # Проверка уровня достоверности
        if analysis.confidence_score < 0.5:
            warnings.append(f"Низкий уровень достоверности: {analysis.confidence_score:.2f}")
        
        # Проверка наличия источников
        if not analysis.sources:
            warnings.append("Отсутствуют научные источники")
        
        # Проверка актуальности источников
        current_year = datetime.utcnow().year
        old_sources = [s for s in analysis.sources if s.year < current_year - 10]
        if old_sources:
            warnings.append(f"{len(old_sources)} источников старше 10 лет")
        
        # Проверка уровня доказательности
        low_evidence = [s for s in analysis.sources if s.evidence_level in [EvidenceLevel.IV, EvidenceLevel.V]]
        if len(low_evidence) > len(analysis.sources) / 2:
            warnings.append("Большинство источников имеют низкий уровень доказательности")
        
        # Проверка на противоречия
        if analysis.contraindications and any(r in analysis.contraindications for r in analysis.recommendations):
            warnings.append("Обнаружены противоречия между рекомендациями и противопоказаниями")
        
        is_valid = len(warnings) == 0 or all("Низкий" not in w for w in warnings)
        
        return is_valid, warnings
    
    async def search_scientific_literature(
        self,
        query: str,
        max_results: int = 10,
        min_year: Optional[int] = None,
        evidence_levels: List[EvidenceLevel] = None
    ) -> List[ScientificSource]:
        """
        Поиск в научной литературе
        
        Args:
            query: Поисковый запрос
            max_results: Максимальное количество результатов
            min_year: Минимальный год публикации
            evidence_levels: Фильтр по уровню доказательности
        
        Returns:
            Список научных источников
        """
        # Будет реализовано в подклассах
        return []
    
    async def get_clinical_guidelines(
        self,
        condition: str,
        guideline_sources: List[str] = None
    ) -> List[Dict[str, Any]]:
        """
        Получение клинических рекомендаций
        
        Args:
            condition: Заболевание/состояние
            guideline_sources: Источники guidelines (ESVS, SVS, ACC/AHA и т.д.)
        
        Returns:
            Список клинических рекомендаций
        """
        # Будет реализовано в подклассах
        return []
    
    def calculate_confidence_score(
        self,
        sources: List[ScientificSource],
        query_complexity: int = 1
    ) -> float:
        """
        Расчет уровня достоверности на основе источников
        
        Args:
            sources: Список источников
            query_complexity: Сложность запроса (1-5)
        
        Returns:
            Score от 0.0 до 1.0
        """
        if not sources:
            return 0.0
        
        # Веса для уровней доказательности
        evidence_weights = {
            EvidenceLevel.IA: 1.0,
            EvidenceLevel.IB: 0.95,
            EvidenceLevel.IIA: 0.85,
            EvidenceLevel.IIB: 0.75,
            EvidenceLevel.IIIA: 0.65,
            EvidenceLevel.IIIB: 0.55,
            EvidenceLevel.IV: 0.4,
            EvidenceLevel.V: 0.25
        }
        
        # Веса для классов рекомендаций
        recommendation_weights = {
            RecommendationClass.CLASS_I: 1.0,
            RecommendationClass.CLASS_IIA: 0.85,
            RecommendationClass.CLASS_IIB: 0.7,
            RecommendationClass.CLASS_III: 0.3
        }
        
        total_score = 0.0
        total_weight = 0.0
        
        for source in sources:
            # Базовый вес от уровня доказательности
            evidence_weight = evidence_weights.get(source.evidence_level, 0.25)
            
            # Дополнительный вес от класса рекомендации
            rec_weight = recommendation_weights.get(source.recommendation_class, 0.5)
            
            # Бонус за цитирование
            citation_bonus = min(source.citations / 100, 0.1)
            
            # Штраф за возраст
            age_penalty = max(0, (datetime.utcnow().year - source.year) * 0.02)
            
            source_score = (evidence_weight * 0.5 + rec_weight * 0.4 + citation_bonus) - age_penalty
            source_score = max(0, min(1, source_score))
            
            total_score += source_score
            total_weight += 1
        
        avg_score = total_score / total_weight if total_weight > 0 else 0
        
        # Корректировка на сложность запроса
        complexity_penalty = (query_complexity - 1) * 0.05
        final_score = max(0, min(1, avg_score - complexity_penalty))
        
        return round(final_score, 2)
    
    def log_analysis(
        self,
        query: str,
        analysis: AgentAnalysis,
        user_id: Optional[str] = None,
        ip_address: Optional[str] = None
    ):
        """Логирование анализа для аудита"""
        
        log_entry = {
            "agent_name": self.agent_name,
            "agent_version": self.agent_version,
            "query": query[:200],  # Truncate for privacy
            "confidence_score": analysis.confidence_score,
            "num_sources": len(analysis.sources),
            "timestamp": datetime.utcnow().isoformat(),
            "user_id": user_id,
            "ip_address": ip_address
        }
        
        self.analysis_history.append(log_entry)
        
        # Audit logging
        AuditLogger.log_data_modification(
            user_id=user_id or "system",
            table="agent_analysis",
            record_id=hashlib.md5(query.encode()).hexdigest()[:16],
            action="analyze",
            changes={"agent": self.agent_name, "confidence": analysis.confidence_score},
            ip_address=ip_address or "unknown"
        )
        
        app_logger.info(f"Agent {self.agent_name} analyzed query with confidence {analysis.confidence_score}")
    
    def get_analysis_statistics(self) -> Dict[str, Any]:
        """Получение статистики использования агента"""
        
        if not self.analysis_history:
            return {
                "total_analyses": 0,
                "avg_confidence": 0.0,
                "last_update": None
            }
        
        confidences = [a["confidence_score"] for a in self.analysis_history]
        
        return {
            "total_analyses": len(self.analysis_history),
            "avg_confidence": round(sum(confidences) / len(confidences), 2),
            "min_confidence": round(min(confidences), 2),
            "max_confidence": round(max(confidences), 2),
            "last_update": self.last_knowledge_update.isoformat() if self.last_knowledge_update else None,
            "agent_version": self.agent_version
        }
    
    async def compare_with_guidelines(
        self,
        recommendation: str,
        guideline_source: str = "ESVS"
    ) -> Dict[str, Any]:
        """
        Сравнение рекомендации с клиническими guidelines
        
        Returns:
            Статус соответствия и детали
        """
        # Будет реализовано в подклассах
        return {
            "status": "unknown",
            "guideline_source": guideline_source,
            "match_percentage": 0.0,
            "details": "Not implemented"
        }
