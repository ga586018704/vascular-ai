"""
VASCULAR.AI - Agent Output Validator
Система валидации и верификации выводов AI-агентов
"""

from typing import Dict, List, Any, Optional, Tuple
from dataclasses import dataclass
from datetime import datetime
import re

from app.agents.base.medical_agent import AgentAnalysis, EvidenceLevel
from app.core.logging import app_logger, audit_logger


@dataclass
class ValidationResult:
    """Результат валидации"""
    is_valid: bool
    confidence_score: float
    warnings: List[str]
    errors: List[str]
    suggestions: List[str]
    validation_timestamp: datetime
    validator_version: str = "1.0"
    
    def to_dict(self) -> Dict[str, Any]:
        return {
            "is_valid": self.is_valid,
            "confidence_score": self.confidence_score,
            "warnings": self.warnings,
            "errors": self.errors,
            "suggestions": self.suggestions,
            "validation_timestamp": self.validation_timestamp.isoformat(),
            "validator_version": self.validator_version
        }


class AgentOutputValidator:
    """
    Валидатор выводов AI-агентов
    
    Проверяет:
    - Медицинскую корректность
    - Наличие необходимых предостережений
    - Соответствие guidelines
    - Уровень доказательности
    """
    
    # Критические термины, требующие предостережений
    CRITICAL_TERMS = {
        "emergency": ["экстренно", "emergency", "urgent", "срочно"],
        "contraindication": ["противопоказание", "contraindication", "не рекомендуется"],
        "surgery": ["операция", "surgery", "хирургия", "procedure"],
        "medication": ["лекарство", "medication", "drug", "препарат"]
    }
    
    # Обязательные дисклеймеры
    required_disclaimers = [
        "Это рекомендация AI-агента",
        "Требуется подтверждение врачом",
        "Не заменяет клиническое суждение"
    ]
    
    def __init__(self):
        self.validation_history: List[Dict[str, Any]] = []
    
    async def validate(
        self,
        analysis: AgentAnalysis,
        strict_mode: bool = False
    ) -> ValidationResult:
        """
        Валидация вывода агента
        
        Args:
            analysis: Результат анализа агента
            strict_mode: Строгий режим валидации
        
        Returns:
            ValidationResult с результатами проверки
        """
        
        warnings = []
        errors = []
        suggestions = []
        
        # 1. Проверка уровня достоверности
        confidence_valid, confidence_warnings = self._validate_confidence(analysis)
        warnings.extend(confidence_warnings)
        
        # 2. Проверка источников
        sources_valid, sources_issues = self._validate_sources(analysis)
        if not sources_valid:
            errors.extend(sources_issues)
        else:
            warnings.extend(sources_issues)
        
        # 3. Проверка рекомендаций
        rec_valid, rec_issues = self._validate_recommendations(analysis)
        if not rec_valid:
            errors.extend(rec_issues)
        else:
            warnings.extend(rec_issues)
        
        # 4. Проверка противопоказаний
        contra_valid, contra_warnings = self._validate_contraindications(analysis)
        warnings.extend(contra_warnings)
        
        # 5. Проверка медицинской корректности
        medical_valid, medical_issues = self._validate_medical_correctness(analysis)
        if not medical_valid:
            errors.extend(medical_issues)
        else:
            warnings.extend(medical_issues)
        
        # 6. Проверка наличия дисклеймеров
        disclaimer_valid, disclaimer_warnings = self._validate_disclaimers(analysis)
        if strict_mode and not disclaimer_valid:
            errors.extend(disclaimer_warnings)
        else:
            warnings.extend(disclaimer_warnings)
        
        # 7. Проверка на противоречия
        consistency_valid, consistency_issues = self._validate_consistency(analysis)
        if not consistency_valid:
            errors.extend(consistency_issues)
        
        # 8. Проверка полноты
        completeness_valid, completeness_suggestions = self._validate_completeness(analysis)
        suggestions.extend(completeness_suggestions)
        
        # Расчет итогового score
        confidence_score = self._calculate_validation_score(
            analysis, len(errors), len(warnings), len(suggestions)
        )
        
        is_valid = len(errors) == 0 and (not strict_mode or confidence_score >= 0.7)
        
        result = ValidationResult(
            is_valid=is_valid,
            confidence_score=confidence_score,
            warnings=warnings,
            errors=errors,
            suggestions=suggestions,
            validation_timestamp=datetime.utcnow()
        )
        
        # Логирование
        self._log_validation(analysis, result)
        
        return result
    
    def _validate_confidence(self, analysis: AgentAnalysis) -> Tuple[bool, List[str]]:
        """Проверка уровня достоверности"""
        
        warnings = []
        
        if analysis.confidence_score < 0.5:
            warnings.append(f"Критически низкий уровень достоверности: {analysis.confidence_score:.2f}")
        elif analysis.confidence_score < 0.7:
            warnings.append(f"Низкий уровень достоверности: {analysis.confidence_score:.2f}. Рекомендуется дополнительная верификация.")
        
        return True, warnings
    
    def _validate_sources(self, analysis: AgentAnalysis) -> Tuple[bool, List[str]]:
        """Проверка научных источников"""
        
        issues = []
        
        if not analysis.sources:
            issues.append("Отсутствуют научные источники")
            return False, issues
        
        current_year = datetime.utcnow().year
        
        # Проверка возраста источников
        old_sources = [s for s in analysis.sources if s.year < current_year - 10]
        if old_sources:
            issues.append(f"{len(old_sources)} источников старше 10 лет")
        
        # Проверка уровня доказательности
        low_evidence = [s for s in analysis.sources if s.evidence_level in [EvidenceLevel.IV, EvidenceLevel.V]]
        if len(low_evidence) > len(analysis.sources) / 2:
            issues.append(f"Большинство источников ({len(low_evidence)}/{len(analysis.sources)}) имеют низкий уровень доказательности")
        
        # Проверка на дублирование
        dois = [s.doi for s in analysis.sources if s.doi]
        if len(dois) != len(set(dois)):
            issues.append("Обнаружены дублирующиеся источники")
        
        return True, issues
    
    def _validate_recommendations(self, analysis: AgentAnalysis) -> Tuple[bool, List[str]]:
        """Проверка рекомендаций"""
        
        issues = []
        
        if not analysis.recommendations:
            issues.append("Отсутствуют рекомендации")
            return False, issues
        
        # Проверка на критические термины
        for rec in analysis.recommendations:
            rec_lower = rec.lower()
            
            # Проверка на экстренность без контекста
            if any(term in rec_lower for term in self.CRITICAL_TERMS["emergency"]):
                if "⚠️" not in rec and "ВНИМАНИЕ" not in rec:
                    issues.append(f"Рекомендация содержит экстренный термин без предупреждения: '{rec[:50]}...'")
            
            # Проверка на специфичность
            if len(rec) < 20:
                issues.append(f"Слишком общая рекомендация: '{rec}'")
        
        return True, issues
    
    def _validate_contraindications(self, analysis: AgentAnalysis) -> Tuple[bool, List[str]]:
        """Проверка противопоказаний"""
        
        warnings = []
        
        # Проверка на пересечение рекомендаций и противопоказаний
        if analysis.contraindications:
            for rec in analysis.recommendations:
                for contra in analysis.contraindications:
                    # Простая проверка на общие слова
                    rec_words = set(rec.lower().split())
                    contra_words = set(contra.lower().split())
                    common_words = rec_words & contra_words - {"the", "a", "an", "and", "or", "в", "и", "или"}
                    
                    if len(common_words) > 3:
                        warnings.append(f"Возможное противоречие между рекомендацией и противопоказанием")
        else:
            warnings.append("Отсутствуют противопоказания - убедитесь, что они не применимы")
        
        return True, warnings
    
    def _validate_medical_correctness(self, analysis: AgentAnalysis) -> Tuple[bool, List[str]]:
        """Проверка медицинской корректности"""
        
        issues = []
        analysis_text = analysis.analysis.lower()
        
        # Проверка на опасные комбинации
        dangerous_combinations = [
            (["варфарин", "warfarin"], ["аспирин", "aspirin"], "Одновременное назначение варфарина и аспирина требует осторожности"),
            (["гепарин", "heparin"], ["тромболиз", "thrombolysis"], "Комбинация гепарина и тромболиза - высокий риск кровотечения"),
        ]
        
        for drug1_list, drug2_list, warning in dangerous_combinations:
            has_drug1 = any(drug in analysis_text for drug in drug1_list)
            has_drug2 = any(drug in analysis_text for drug in drug2_list)
            
            if has_drug1 and has_drug2:
                issues.append(warning)
        
        # Проверка дозировок (простая)
        dose_pattern = r'(\d+)\s*(мг|mg|г|g)\s*(\d+)\s*раз'
        doses = re.findall(dose_pattern, analysis_text)
        for dose in doses:
            amount = int(dose[0])
            unit = dose[1]
            frequency = int(dose[2])
            
            # Пример проверки: алтеплаза
            if "алтеплаза" in analysis_text or "alteplase" in analysis_text:
                if amount > 100:
                    issues.append("Проверьте дозировку алтеплазы (обычно 0.9 мг/кг)")
        
        return True, issues
    
    def _validate_disclaimers(self, analysis: AgentAnalysis) -> Tuple[bool, List[str]]:
        """Проверка наличия дисклеймеров"""
        
        warnings = []
        analysis_text = analysis.analysis.lower()
        
        # Проверка на наличие ключевых фраз
        has_ai_disclaimer = any(phrase in analysis_text for phrase in ["ai", "искусственный интеллект", "агент"])
        has_medical_disclaimer = any(phrase in analysis_text for phrase in ["врач", "doctor", "клиническое"])
        
        if not has_ai_disclaimer:
            warnings.append("Отсутствует указание на AI-происхождение рекомендаций")
        
        if not has_medical_disclaimer:
            warnings.append("Отсутствует указание на необходимость подтверждения врачом")
        
        return has_ai_disclaimer and has_medical_disclaimer, warnings
    
    def _validate_consistency(self, analysis: AgentAnalysis) -> Tuple[bool, List[str]]:
        """Проверка внутренней согласованности"""
        
        issues = []
        
        # Проверка соответствия confidence score и количества источников
        if analysis.confidence_score > 0.8 and len(analysis.sources) < 3:
            issues.append("Высокий confidence score при малом количестве источников")
        
        # Проверка наличия follow-up при хирургических рекомендациях
        has_surgical_rec = any("операц" in r.lower() or "surgery" in r.lower() for r in analysis.recommendations)
        if has_surgical_rec and not analysis.follow_up_recommendations:
            issues.append("Хирургические рекомендации без указания послеоперационного наблюдения")
        
        return len(issues) == 0, issues
    
    def _validate_completeness(self, analysis: AgentAnalysis) -> Tuple[bool, List[str]]:
        """Проверка полноты анализа"""
        
        suggestions = []
        
        # Проверка наличия альтернатив
        if len(analysis.alternative_approaches) < 2:
            suggestions.append("Добавьте больше альтернативных подходов к лечению")
        
        # Проверка детализации follow-up
        if analysis.follow_up_recommendations:
            has_timeframe = any(any(term in f.lower() for term in ["месяц", "month", "неделя", "week"]) for f in analysis.follow_up_recommendations)
            if not has_timeframe:
                suggestions.append("Укажите временные рамки для наблюдения")
        
        return True, suggestions
    
    def _calculate_validation_score(
        self,
        analysis: AgentAnalysis,
        num_errors: int,
        num_warnings: int,
        num_suggestions: int
    ) -> float:
        """Расчет итогового score валидации"""
        
        base_score = analysis.confidence_score
        
        # Штрафы
        error_penalty = num_errors * 0.15
        warning_penalty = num_warnings * 0.05
        suggestion_penalty = num_suggestions * 0.02
        
        # Бонусы
        source_bonus = min(len(analysis.sources) * 0.02, 0.1)
        contra_bonus = 0.05 if analysis.contraindications else 0
        alternative_bonus = min(len(analysis.alternative_approaches) * 0.02, 0.05)
        
        final_score = base_score - error_penalty - warning_penalty - suggestion_penalty
        final_score += source_bonus + contra_bonus + alternative_bonus
        
        return round(max(0, min(1, final_score)), 2)
    
    def _log_validation(self, analysis: AgentAnalysis, result: ValidationResult):
        """Логирование валидации"""
        
        log_entry = {
            "agent_type": analysis.agent_type,
            "query": analysis.query[:100],
            "is_valid": result.is_valid,
            "confidence_score": result.confidence_score,
            "num_errors": len(result.errors),
            "num_warnings": len(result.warnings),
            "timestamp": datetime.utcnow().isoformat()
        }
        
        self.validation_history.append(log_entry)
        
        app_logger.info(
            f"Validated {analysis.agent_type} analysis: "
            f"valid={result.is_valid}, score={result.confidence_score}"
        )
    
    def get_validation_statistics(self) -> Dict[str, Any]:
        """Получение статистики валидаций"""
        
        if not self.validation_history:
            return {"total_validations": 0}
        
        total = len(self.validation_history)
        valid_count = sum(1 for v in self.validation_history if v["is_valid"])
        avg_score = sum(v["confidence_score"] for v in self.validation_history) / total
        
        return {
            "total_validations": total,
            "valid_count": valid_count,
            "invalid_count": total - valid_count,
            "validity_rate": round(valid_count / total * 100, 1),
            "average_score": round(avg_score, 2)
        }


class MultiAgentConsensus:
    """
    Система консенсуса нескольких агентов
    Используется для сложных случаев требующих многодисциплинарного подхода
    """
    
    def __init__(self):
        self.consensus_history: List[Dict[str, Any]] = []
    
    async def reach_consensus(
        self,
        analyses: List[AgentAnalysis],
        query: str
    ) -> Dict[str, Any]:
        """
        Достижение консенсуса между несколькими агентами
        
        Args:
            analyses: Список анализов от разных агентов
            query: Исходный запрос
        
        Returns:
            Консенсусное заключение
        """
        
        if not analyses:
            return {"error": "No analyses provided"}
        
        # Агрегация рекомендаций
        all_recommendations = []
        for analysis in analyses:
            all_recommendations.extend(analysis.recommendations)
        
        # Находим общие рекомендации
        common_recommendations = self._find_common_recommendations(analyses)
        
        # Находим противоречия
        conflicts = self._find_conflicts(analyses)
        
        # Расчет среднего confidence
        avg_confidence = sum(a.confidence_score for a in analyses) / len(analyses)
        
        # Агрегация источников
        all_sources = []
        for analysis in analyses:
            all_sources.extend(analysis.sources)
        
        # Удаление дубликатов по DOI
        unique_sources = {s.doi: s for s in all_sources if s.doi}.values()
        
        consensus = {
            "query": query,
            "participating_agents": [a.agent_type for a in analyses],
            "consensus_recommendations": common_recommendations,
            "all_recommendations": list(set(all_recommendations)),
            "conflicts": conflicts,
            "average_confidence": round(avg_confidence, 2),
            "sources": [s.to_dict() for s in unique_sources],
            "requires_human_review": len(conflicts) > 0 or avg_confidence < 0.6,
            "timestamp": datetime.utcnow().isoformat()
        }
        
        self.consensus_history.append(consensus)
        
        return consensus
    
    def _find_common_recommendations(self, analyses: List[AgentAnalysis]) -> List[str]:
        """Находит рекомендации, общие для нескольких агентов"""
        
        if len(analyses) < 2:
            return analyses[0].recommendations if analyses else []
        
        # Простая проверка на общие слова
        all_recs = []
        for analysis in analyses:
            all_recs.extend(analysis.recommendations)
        
        # Подсчет частоты
        from collections import Counter
        rec_counter = Counter(all_recs)
        
        # Возвращаем рекомендации, встречающиеся более чем у половины агентов
        threshold = len(analyses) / 2
        common = [rec for rec, count in rec_counter.items() if count >= threshold]
        
        return common
    
    def _find_conflicts(self, analyses: List[AgentAnalysis]) -> List[Dict[str, Any]]:
        """Находит противоречия между агентами"""
        
        conflicts = []
        
        # Проверяем противоречия в рекомендациях
        for i, analysis1 in enumerate(analyses):
            for analysis2 in analyses[i+1:]:
                # Проверяем на противоположные рекомендации
                for rec1 in analysis1.recommendations:
                    for rec2 in analysis2.recommendations:
                        # Простая эвристика: наличие противоположных терминов
                        if self._are_recommendations_conflicting(rec1, rec2):
                            conflicts.append({
                                "agent1": analysis1.agent_type,
                                "agent2": analysis2.agent_type,
                                "recommendation1": rec1,
                                "recommendation2": rec2,
                                "type": "direct_conflict"
                            })
        
        return conflicts
    
    def _are_recommendations_conflicting(self, rec1: str, rec2: str) -> bool:
        """Проверяет, являются ли две рекомендации противоречивыми"""
        
        rec1_lower = rec1.lower()
        rec2_lower = rec2.lower()
        
        # Пары противоположных терминов
        opposite_pairs = [
            (["операция", "surgery"], ["консерватив", "conservative", "медикамент", "medical"]),
            (["стент", "stent"], ["без стента", "no stent", "баллон", "balloon only"]),
            (["антикоагулянт", "anticoagulant"], ["антитромбоцитар", "antiplatelet"]),
        ]
        
        for group1, group2 in opposite_pairs:
            has_group1_rec1 = any(term in rec1_lower for term in group1)
            has_group2_rec1 = any(term in rec1_lower for term in group2)
            has_group1_rec2 = any(term in rec2_lower for term in group1)
            has_group2_rec2 = any(term in rec2_lower for term in group2)
            
            if (has_group1_rec1 and has_group2_rec2) or (has_group2_rec1 and has_group1_rec2):
                return True
        
        return False
