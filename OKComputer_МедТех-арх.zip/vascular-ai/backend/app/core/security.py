"""
VASCULAR.AI - Security Module
HIPAA/GDPR compliant security utilities
"""

from datetime import datetime, timedelta
from typing import Optional, Dict, Any
from jose import JWTError, jwt
from passlib.context import CryptContext
from cryptography.fernet import Fernet
import hashlib
import secrets
import base64

from app.core.config import settings


# Password hashing
pwd_context = CryptContext(schemes=["bcrypt"], deprecated="auto")


def _get_fernet_key(key_string: str) -> bytes:
    """
    Generate a valid Fernet key from any string.
    Fernet requires 32 url-safe base64-encoded bytes.
    """
    # Hash the input string to get 32 bytes
    key_hash = hashlib.sha256(key_string.encode()).digest()
    # Encode to base64 url-safe (this gives 44 chars with padding)
    return base64.urlsafe_b64encode(key_hash)


# Encryption for PHI (Protected Health Information)
# Generate valid Fernet key from the provided encryption key
_fernet_key = _get_fernet_key(settings.ENCRYPTION_KEY)
cipher_suite = Fernet(_fernet_key)


class SecurityManager:
    """Central security management for VASCULAR.AI"""
    
    @staticmethod
    def verify_password(plain_password: str, hashed_password: str) -> bool:
        """Verify password against hash"""
        return pwd_context.verify(plain_password, hashed_password)
    
    @staticmethod
    def get_password_hash(password: str) -> str:
        """Hash password"""
        return pwd_context.hash(password)
    
    @staticmethod
    def create_access_token(data: Dict[str, Any], expires_delta: Optional[timedelta] = None) -> str:
        """Create JWT access token"""
        to_encode = data.copy()
        if expires_delta:
            expire = datetime.utcnow() + expires_delta
        else:
            expire = datetime.utcnow() + timedelta(minutes=settings.ACCESS_TOKEN_EXPIRE_MINUTES)
        
        to_encode.update({"exp": expire, "iat": datetime.utcnow(), "type": "access"})
        encoded_jwt = jwt.encode(to_encode, settings.SECRET_KEY, algorithm=settings.ALGORITHM)
        return encoded_jwt
    
    @staticmethod
    def create_refresh_token(data: Dict[str, Any]) -> str:
        """Create JWT refresh token"""
        to_encode = data.copy()
        expire = datetime.utcnow() + timedelta(days=settings.REFRESH_TOKEN_EXPIRE_DAYS)
        to_encode.update({"exp": expire, "iat": datetime.utcnow(), "type": "refresh"})
        encoded_jwt = jwt.encode(to_encode, settings.SECRET_KEY, algorithm=settings.ALGORITHM)
        return encoded_jwt
    
    @staticmethod
    def verify_token(token: str) -> Optional[Dict[str, Any]]:
        """Verify and decode JWT token"""
        try:
            payload = jwt.decode(token, settings.SECRET_KEY, algorithms=[settings.ALGORITHM])
            return payload
        except JWTError:
            return None
    
    @staticmethod
    def encrypt_phi(data: str) -> bytes:
        """Encrypt Protected Health Information"""
        return cipher_suite.encrypt(data.encode())
    
    @staticmethod
    def decrypt_phi(encrypted_data: bytes) -> str:
        """Decrypt Protected Health Information"""
        return cipher_suite.decrypt(encrypted_data).decode()
    
    @staticmethod
    def hash_patient_id(patient_id: str) -> str:
        """Create irreversible hash for patient ID (for logging)"""
        return hashlib.sha256(f"{patient_id}{settings.SECRET_KEY}".encode()).hexdigest()[:16]
    
    @staticmethod
    def generate_secure_token(length: int = 32) -> str:
        """Generate cryptographically secure random token"""
        return secrets.token_urlsafe(length)


class RBAC:
    """Role-Based Access Control"""
    
    ROLES = {
        "admin": ["*"],  # All permissions
        "surgeon": [
            "read:patient",
            "write:patient",
            "read:study",
            "write:study",
            "read:protocol",
            "execute:calculator",
            "read:guidelines"
        ],
        "resident": [
            "read:patient",
            "read:study",
            "read:protocol",
            "execute:calculator",
            "read:guidelines"
        ],
        "radiologist": [
            "read:study",
            "write:study",
            "read:patient"
        ],
        "nurse": [
            "read:patient",
            "write:patient_vitals"
        ],
        "researcher": [
            "read:anonymized_data"
        ]
    }
    
    @classmethod
    def has_permission(cls, role: str, permission: str) -> bool:
        """Check if role has specific permission"""
        if role not in cls.ROLES:
            return False
        permissions = cls.ROLES[role]
        return "*" in permissions or permission in permissions
    
    @classmethod
    def get_role_permissions(cls, role: str) -> list:
        """Get all permissions for a role"""
        return cls.ROLES.get(role, [])


class AuditLogger:
    """HIPAA-compliant audit logging"""
    
    @staticmethod
    def log_authentication(user_id: str, success: bool, ip_address: str, user_agent: str):
        """Log authentication attempt"""
        from app.core.logging import audit_logger
        audit_logger.info({
            "event": "authentication",
            "user_id": SecurityManager.hash_patient_id(user_id),
            "success": success,
            "ip_address": ip_address,
            "user_agent": user_agent,
            "timestamp": datetime.utcnow().isoformat()
        })
    
    @staticmethod
    def log_patient_access(user_id: str, patient_id: str, action: str, ip_address: str):
        """Log patient data access"""
        from app.core.logging import audit_logger
        audit_logger.info({
            "event": "patient_access",
            "user_id": SecurityManager.hash_patient_id(user_id),
            "patient_id_hash": SecurityManager.hash_patient_id(patient_id),
            "action": action,
            "ip_address": ip_address,
            "timestamp": datetime.utcnow().isoformat()
        })
    
    @staticmethod
    def log_data_modification(user_id: str, table: str, record_id: str, 
                              action: str, changes: Dict[str, Any], ip_address: str):
        """Log data modification"""
        from app.core.logging import audit_logger
        audit_logger.info({
            "event": "data_modification",
            "user_id": SecurityManager.hash_patient_id(user_id),
            "table": table,
            "record_id_hash": SecurityManager.hash_patient_id(record_id),
            "action": action,
            "changes": {k: "***" for k in changes.keys()},  # Don't log actual values
            "ip_address": ip_address,
            "timestamp": datetime.utcnow().isoformat()
        })
    
    @staticmethod
    def log_dicom_access(user_id: str, study_id: str, action: str, ip_address: str):
        """Log DICOM access"""
        from app.core.logging import audit_logger
        audit_logger.info({
            "event": "dicom_access",
            "user_id": SecurityManager.hash_patient_id(user_id),
            "study_id_hash": SecurityManager.hash_patient_id(study_id),
            "action": action,
            "ip_address": ip_address,
            "timestamp": datetime.utcnow().isoformat()
        })


class InputValidator:
    """Input validation utilities"""
    
    import re
    
    # Patterns for common validations
    STUDY_ID_PATTERN = re.compile(r'^[A-Z0-9_-]{8,32}$')
    PATIENT_ID_PATTERN = re.compile(r'^[A-Z0-9]{10,20}$')
    MRN_PATTERN = re.compile(r'^[0-9]{6,10}$')
    EMAIL_PATTERN = re.compile(r'^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$')
    
    @classmethod
    def validate_study_id(cls, study_id: str) -> bool:
        """Validate study ID format"""
        return bool(cls.STUDY_ID_PATTERN.match(study_id))
    
    @classmethod
    def validate_patient_id(cls, patient_id: str) -> bool:
        """Validate patient ID format"""
        return bool(cls.PATIENT_ID_PATTERN.match(patient_id))
    
    @classmethod
    def validate_mrn(cls, mrn: str) -> bool:
        """Validate Medical Record Number"""
        return bool(cls.MRN_PATTERN.match(mrn))
    
    @classmethod
    def validate_email(cls, email: str) -> bool:
        """Validate email format"""
        return bool(cls.EMAIL_PATTERN.match(email))
    
    @classmethod
    def sanitize_filename(cls, filename: str) -> str:
        """Sanitize filename to prevent path traversal"""
        import os
        filename = os.path.basename(filename)
        # Remove any non-alphanumeric characters except safe ones
        return re.sub(r'[^a-zA-Z0-9._-]', '', filename)


class RateLimitConfig:
    """Rate limiting configuration"""
    
    # Limits per endpoint type
    LIMITS = {
        "auth": "5/minute",           # Login attempts
        "dicom_upload": "10/minute",  # DICOM uploads
        "api_general": "100/minute",  # General API calls
        "calculator": "60/minute",    # Calculator usage
        "search": "30/minute",        # Search queries
    }
