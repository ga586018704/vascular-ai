"""
VASCULAR.AI - Security Middleware
Rate limiting, request validation, and security headers
"""

import time
from typing import Optional, Dict, List
from collections import defaultdict
from datetime import datetime, timedelta

from fastapi import Request, HTTPException, status
from fastapi.responses import JSONResponse
from starlette.middleware.base import BaseHTTPMiddleware

from app.core.logging import security_logger, app_logger
from app.core.security import RateLimitConfig


class RateLimitMiddleware(BaseHTTPMiddleware):
    """Rate limiting middleware for API protection"""
    
    def __init__(self, app):
        super().__init__(app)
        # Store request counts: {ip: [(timestamp, endpoint), ...]}
        self.requests: Dict[str, List[tuple]] = defaultdict(list)
        self.blocked_ips: Dict[str, datetime] = {}
    
    async def dispatch(self, request: Request, call_next):
        client_ip = request.client.host if request.client else "unknown"
        
        # Check if IP is blocked
        if client_ip in self.blocked_ips:
            block_until = self.blocked_ips[client_ip]
            if datetime.utcnow() < block_until:
                security_logger.warning(f"Blocked request from {client_ip}")
                return JSONResponse(
                    status_code=status.HTTP_429_TOO_MANY_REQUESTS,
                    content={"detail": "IP temporarily blocked due to excessive requests"}
                )
            else:
                del self.blocked_ips[client_ip]
        
        # Determine rate limit based on endpoint
        path = request.url.path
        limit_key = self._get_limit_key(path)
        limit_str = RateLimitConfig.LIMITS.get(limit_key, RateLimitConfig.LIMITS["api_general"])
        
        # Parse limit (e.g., "100/minute")
        max_requests, window = self._parse_limit(limit_str)
        
        # Clean old requests
        now = time.time()
        window_seconds = self._window_to_seconds(window)
        cutoff = now - window_seconds
        
        self.requests[client_ip] = [
            (ts, ep) for ts, ep in self.requests[client_ip] if ts > cutoff
        ]
        
        # Check rate limit
        endpoint_requests = [ts for ts, ep in self.requests[client_ip] if ep == path]
        if len(endpoint_requests) >= max_requests:
            security_logger.warning(f"Rate limit exceeded for {client_ip} on {path}")
            return JSONResponse(
                status_code=status.HTTP_429_TOO_MANY_REQUESTS,
                content={
                    "detail": "Rate limit exceeded",
                    "retry_after": int(window_seconds - (now - endpoint_requests[0]))
                }
            )
        
        # Record request
        self.requests[client_ip].append((now, path))
        
        # Process request
        response = await call_next(request)
        
        # Add rate limit headers
        remaining = max(0, max_requests - len(endpoint_requests) - 1)
        response.headers["X-RateLimit-Limit"] = str(max_requests)
        response.headers["X-RateLimit-Remaining"] = str(remaining)
        response.headers["X-RateLimit-Window"] = window
        
        return response
    
    def _get_limit_key(self, path: str) -> str:
        """Determine rate limit category from path"""
        if "/auth/login" in path or "/auth/register" in path:
            return "auth"
        elif "/dicom/upload" in path:
            return "dicom_upload"
        elif "/calculator" in path:
            return "calculator"
        elif "/search" in path:
            return "search"
        return "api_general"
    
    def _parse_limit(self, limit_str: str) -> tuple:
        """Parse limit string like '100/minute'"""
        parts = limit_str.split("/")
        return int(parts[0]), parts[1]
    
    def _window_to_seconds(self, window: str) -> int:
        """Convert window string to seconds"""
        windows = {
            "second": 1,
            "minute": 60,
            "hour": 3600,
            "day": 86400
        }
        return windows.get(window, 60)


class SecurityHeadersMiddleware(BaseHTTPMiddleware):
    """Add security headers to all responses"""
    
    async def dispatch(self, request: Request, call_next):
        response = await call_next(request)
        
        # Security headers
        response.headers["X-Content-Type-Options"] = "nosniff"
        response.headers["X-Frame-Options"] = "DENY"
        response.headers["X-XSS-Protection"] = "1; mode=block"
        response.headers["Strict-Transport-Security"] = "max-age=31536000; includeSubDomains"
        response.headers["Content-Security-Policy"] = "default-src 'self'"
        response.headers["Referrer-Policy"] = "strict-origin-when-cross-origin"
        response.headers["Permissions-Policy"] = "geolocation=(), microphone=(), camera=()"
        
        # Remove server identification
        response.headers.pop("Server", None)
        
        return response


class RequestLoggingMiddleware(BaseHTTPMiddleware):
    """Log all requests for audit trail"""
    
    async def dispatch(self, request: Request, call_next):
        start_time = time.time()
        
        # Process request
        response = await call_next(request)
        
        # Calculate duration
        duration = time.time() - start_time
        
        # Log request (avoid logging sensitive endpoints)
        path = request.url.path
        if not any(sensitive in path for sensitive in ["/auth/login", "/auth/register"]):
            app_logger.info({
                "method": request.method,
                "path": path,
                "status_code": response.status_code,
                "duration_ms": round(duration * 1000, 2),
                "client_ip": request.client.host if request.client else "unknown",
                "user_agent": request.headers.get("user-agent", "unknown")[:100]
            })
        
        return response


class CORSSecurityMiddleware(BaseHTTPMiddleware):
    """Enhanced CORS with stricter security"""
    
    def __init__(self, app, allowed_origins: Optional[List[str]] = None):
        super().__init__(app)
        self.allowed_origins = allowed_origins or ["https://vascular.ai"]
    
    async def dispatch(self, request: Request, call_next):
        origin = request.headers.get("origin")
        
        # Check origin for non-GET requests
        if request.method != "GET" and origin:
            if origin not in self.allowed_origins:
                security_logger.warning(f"Blocked CORS request from {origin}")
                return JSONResponse(
                    status_code=status.HTTP_403_FORBIDDEN,
                    content={"detail": "Origin not allowed"}
                )
        
        response = await call_next(request)
        
        # Add CORS headers for allowed origins
        if origin in self.allowed_origins:
            response.headers["Access-Control-Allow-Origin"] = origin
            response.headers["Access-Control-Allow-Credentials"] = "true"
            response.headers["Access-Control-Allow-Methods"] = "GET, POST, PUT, DELETE, OPTIONS"
            response.headers["Access-Control-Allow-Headers"] = "Authorization, Content-Type"
        
        return response
