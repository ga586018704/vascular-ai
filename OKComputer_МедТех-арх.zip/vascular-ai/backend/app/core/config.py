"""
VASCULAR.AI - Configuration Management
Environment-based configuration with validation
"""

import json
from typing import List, Optional
from pydantic_settings import BaseSettings, SettingsConfigDict
from pydantic import field_validator


def parse_list_from_env(v):
    """Parse list from env string (comma-separated or JSON)"""
    if isinstance(v, str):
        v = v.strip()
        # Try JSON first
        if v.startswith('[') and v.endswith(']'):
            try:
                return json.loads(v)
            except json.JSONDecodeError:
                pass
        # Fall back to comma-separated
        return [item.strip() for item in v.split(",") if item.strip()]
    return v


class Settings(BaseSettings):
    """Application settings loaded from environment variables"""
    
    model_config = SettingsConfigDict(
        env_file=".env",
        env_file_encoding="utf-8",
        case_sensitive=True,
        extra="ignore"  # Ignore extra fields from env
    )
    
    # Application
    APP_NAME: str = "VASCULAR.AI"
    APP_VERSION: str = "5.0.0"
    DEBUG: bool = False
    ENVIRONMENT: str = "development"  # development, staging, production
    
    # Security
    SECRET_KEY: str = "your-super-secret-key-must-be-at-least-32-characters-long"
    ENCRYPTION_KEY: str = "your-encryption-key-32-bytes-long!!!"
    ALGORITHM: str = "HS256"
    ACCESS_TOKEN_EXPIRE_MINUTES: int = 30
    REFRESH_TOKEN_EXPIRE_DAYS: int = 7
    
    # Database
    DATABASE_URL: str = "sqlite+aiosqlite:///./data/vascular_ai.db"
    DATABASE_POOL_SIZE: int = 5
    DATABASE_MAX_OVERFLOW: int = 10
    
    # PostgreSQL (for production)
    POSTGRES_USER: Optional[str] = None
    POSTGRES_PASSWORD: Optional[str] = None
    POSTGRES_HOST: Optional[str] = None
    POSTGRES_PORT: int = 5432
    POSTGRES_DB: Optional[str] = None
    
    # Redis (for caching)
    REDIS_URL: str = "redis://localhost:6379/0"
    REDIS_PASSWORD: Optional[str] = None
    
    # File Storage
    UPLOAD_DIR: str = "./data/uploads"
    DICOM_STORAGE_DIR: str = "./data/dicom"
    PROCESSED_DIR: str = "./data/processed"
    MAX_FILE_SIZE: int = 104857600  # 100 MB
    ALLOWED_EXTENSIONS: List[str] = [".dcm", ".dicom"]
    
    # Logging
    LOGS_DIR: str = "./logs"
    LOG_LEVEL: str = "INFO"
    
    # CORS
    ALLOWED_ORIGINS: List[str] = ["http://localhost:3000", "http://localhost:5173"]
    
    # Rate Limiting
    RATE_LIMIT_ENABLED: bool = True
    RATE_LIMIT_DEFAULT: str = "100/minute"
    
    # AI Service
    AI_SERVICE_URL: str = "http://localhost:8001"
    AI_SERVICE_TIMEOUT: int = 300  # seconds
    
    # DICOM
    DICOM_STORAGE_TYPE: str = "filesystem"  # filesystem, s3, minio
    DICOM_S3_BUCKET: Optional[str] = None
    DICOM_S3_ENDPOINT: Optional[str] = None
    DICOM_S3_ACCESS_KEY: Optional[str] = None
    DICOM_S3_SECRET_KEY: Optional[str] = None
    
    # Email (for notifications)
    SMTP_HOST: Optional[str] = None
    SMTP_PORT: int = 587
    SMTP_USER: Optional[str] = None
    SMTP_PASSWORD: Optional[str] = None
    SMTP_TLS: bool = True
    
    # Monitoring
    SENTRY_DSN: Optional[str] = None
    PROMETHEUS_ENABLED: bool = False
    
    # HIPAA Compliance
    SESSION_TIMEOUT_MINUTES: int = 30
    MAX_LOGIN_ATTEMPTS: int = 5
    PASSWORD_MIN_LENGTH: int = 12
    PASSWORD_REQUIRE_SPECIAL: bool = True
    
    @field_validator("SECRET_KEY")
    @classmethod
    def validate_secret_key(cls, v):
        if len(v) < 32:
            raise ValueError("SECRET_KEY must be at least 32 characters")
        return v
    
    @field_validator("ENVIRONMENT")
    @classmethod
    def validate_environment(cls, v):
        allowed = ["development", "staging", "production"]
        if v not in allowed:
            raise ValueError(f"ENVIRONMENT must be one of {allowed}")
        return v
    
    @field_validator("ALLOWED_ORIGINS", mode="before")
    @classmethod
    def parse_allowed_origins(cls, v):
        return parse_list_from_env(v)
    
    @field_validator("ALLOWED_EXTENSIONS", mode="before")
    @classmethod
    def parse_allowed_extensions(cls, v):
        return parse_list_from_env(v)
    
    def get_database_url(self) -> str:
        """Get database URL based on environment"""
        if self.ENVIRONMENT == "production" and self.POSTGRES_HOST:
            return (
                f"postgresql://{self.POSTGRES_USER}:{self.POSTGRES_PASSWORD}"
                f"@{self.POSTGRES_HOST}:{self.POSTGRES_PORT}/{self.POSTGRES_DB}"
            )
        return self.DATABASE_URL
    
    @property
    def CORS_ORIGINS(self) -> List[str]:
        """Alias for ALLOWED_ORIGINS for backward compatibility"""
        return self.ALLOWED_ORIGINS


# Load settings
def get_settings() -> Settings:
    """Get application settings singleton"""
    return Settings()

settings = get_settings()


# Constants for medical calculations
class MedicalConstants:
    """Medical constants used throughout the application"""
    
    # Creatinine thresholds (mg/dL)
    CREATININE_NORMAL_MAX = 1.2
    CREATININE_ELEVATED = 1.5
    CREATININE_HIGH = 2.0
    CREATININE_VERY_HIGH = 3.0
    
    # ABI thresholds
    ABI_NORMAL_MIN = 1.0
    ABI_BORDERLINE_MIN = 0.91
    ABI_MILD_PAD_MIN = 0.70
    ABI_MODERATE_PAD_MIN = 0.40
    
    # AAA size thresholds (mm)
    AAA_NORMAL_MAX = 30
    AAA_ECTASIA_MAX = 40
    AAA_SMALL_MAX = 54
    AAA_MEDIUM_MAX = 69
    
    # Carotid stenosis PSV thresholds (cm/s)
    CAROTID_PSV_NORMAL = 125
    CAROTID_PSV_MODERATE = 230
    CAROTID_EDV_MODERATE = 40
    CAROTID_EDV_SEVERE = 100
    
    # Blood pressure targets
    BP_TARGET_SYSTOLIC = 130
    BP_TARGET_DIASTOLIC = 80
    BP_DISSECTION_SYSTOLIC = 120
    
    # Heart rate targets
    HR_TARGET_MIN = 60
    HR_TARGET_MAX = 80
    HR_DISSECTION_TARGET = 70
    
    # Contrast media
    CONTRAST_MAX_DOSE_ML_PER_KG = 5  # mL/kg
    CONTRAST_MAX_TOTAL_DOSE_G_I = 60  # g of iodine
    
    # Time windows
    STROKE_TPA_WINDOW_MINUTES = 270  # 4.5 hours
    STROKE_THROMBECTOMY_WINDOW_HOURS = 24
    DISSECTION_SURGERY_WINDOW_HOURS = 48
