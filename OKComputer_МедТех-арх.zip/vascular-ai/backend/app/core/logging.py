"""
VASCULAR.AI - Logging Configuration
HIPAA-compliant logging with structured format
"""

import logging
import logging.handlers
import json
from datetime import datetime
from pathlib import Path

from app.core.config import settings


# Create logs directory
LOGS_DIR = Path(settings.LOGS_DIR) if hasattr(settings, 'LOGS_DIR') else Path("./logs")
LOGS_DIR.mkdir(exist_ok=True)


class JSONFormatter(logging.Formatter):
    """JSON formatter for structured logging"""
    
    def format(self, record):
        log_obj = {
            "timestamp": datetime.utcnow().isoformat(),
            "level": record.levelname,
            "logger": record.name,
            "message": record.getMessage(),
            "module": record.module,
            "function": record.funcName,
            "line": record.lineno,
        }
        
        # Add extra fields if present
        if hasattr(record, "user_id"):
            log_obj["user_id"] = record.user_id
        if hasattr(record, "patient_id_hash"):
            log_obj["patient_id_hash"] = record.patient_id_hash
        if hasattr(record, "ip_address"):
            log_obj["ip_address"] = record.ip_address
        if hasattr(record, "request_id"):
            log_obj["request_id"] = record.request_id
        
        # Add exception info if present
        if record.exc_info:
            log_obj["exception"] = self.formatException(record.exc_info)
        
        return json.dumps(log_obj, default=str)


# Configure root logger
def setup_logging():
    """Setup application logging"""
    
    # Root logger
    root_logger = logging.getLogger()
    root_logger.setLevel(logging.INFO)
    
    # Console handler
    console_handler = logging.StreamHandler()
    console_handler.setLevel(logging.INFO)
    console_formatter = logging.Formatter(
        '%(asctime)s - %(name)s - %(levelname)s - %(message)s'
    )
    console_handler.setFormatter(console_formatter)
    root_logger.addHandler(console_handler)
    
    # Application log file (rotating)
    app_handler = logging.handlers.RotatingFileHandler(
        LOGS_DIR / "app.log",
        maxBytes=10*1024*1024,  # 10 MB
        backupCount=10
    )
    app_handler.setLevel(logging.INFO)
    app_handler.setFormatter(JSONFormatter())
    root_logger.addHandler(app_handler)
    
    # Audit logger (HIPAA compliance)
    audit_handler = logging.handlers.RotatingFileHandler(
        LOGS_DIR / "audit.log",
        maxBytes=50*1024*1024,  # 50 MB
        backupCount=20
    )
    audit_handler.setLevel(logging.INFO)
    audit_handler.setFormatter(JSONFormatter())
    
    audit_logger = logging.getLogger("audit")
    audit_logger.setLevel(logging.INFO)
    audit_logger.addHandler(audit_handler)
    audit_logger.propagate = False  # Don't propagate to root
    
    # Error logger
    error_handler = logging.handlers.RotatingFileHandler(
        LOGS_DIR / "error.log",
        maxBytes=10*1024*1024,
        backupCount=10
    )
    error_handler.setLevel(logging.ERROR)
    error_handler.setFormatter(JSONFormatter())
    root_logger.addHandler(error_handler)
    
    # Security logger
    security_handler = logging.handlers.RotatingFileHandler(
        LOGS_DIR / "security.log",
        maxBytes=50*1024*1024,
        backupCount=20
    )
    security_handler.setLevel(logging.WARNING)
    security_handler.setFormatter(JSONFormatter())
    
    security_logger = logging.getLogger("security")
    security_logger.setLevel(logging.WARNING)
    security_logger.addHandler(security_handler)
    security_logger.propagate = False
    
    return root_logger


# Initialize logging
logger = setup_logging()
app_logger = logger  # Alias for backward compatibility
audit_logger = logging.getLogger("audit")
security_logger = logging.getLogger("security")


class RequestContext:
    """Context for request-scoped logging"""
    
    _context = {}
    
    @classmethod
    def set(cls, key: str, value: any):
        """Set context value"""
        cls._context[key] = value
    
    @classmethod
    def get(cls, key: str, default=None):
        """Get context value"""
        return cls._context.get(key, default)
    
    @classmethod
    def clear(cls):
        """Clear context"""
        cls._context.clear()
    
    @classmethod
    def to_dict(cls) -> dict:
        """Convert context to dict"""
        return cls._context.copy()
