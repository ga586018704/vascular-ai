"""
Laboratory Tests Module
Модуль для работы с лабораторными исследованиями
"""

from app.laboratory.models import (
    LaboratoryTest,
    TestResult,
    ReferenceRange,
    TestPanel,
    Laboratory,
    CriticalValueAlert,
    TestTrend,
    TestCategory
)

from app.laboratory.schemas import (
    LaboratoryTestCreate,
    LaboratoryTestUpdate,
    LaboratoryTestResponse,
    TestResultCreate,
    TestResultResponse,
    ReferenceRangeCreate,
    ReferenceRangeResponse,
    TestPanelCreate,
    TestPanelResponse,
    LabAnalysisRequest,
    LabAnalysisResponse
)

from app.laboratory.service import LaboratoryService

__all__ = [
    # Models
    "LaboratoryTest",
    "TestResult",
    "ReferenceRange",
    "TestPanel",
    "Laboratory",
    "CriticalValueAlert",
    "TestTrend",
    "TestCategory",
    # Schemas
    "LaboratoryTestCreate",
    "LaboratoryTestUpdate",
    "LaboratoryTestResponse",
    "TestResultCreate",
    "TestResultResponse",
    "ReferenceRangeCreate",
    "ReferenceRangeResponse",
    "TestPanelCreate",
    "TestPanelResponse",
    "LabAnalysisRequest",
    "LabAnalysisResponse",
    # Service
    "LaboratoryService"
]