"""
Laboratory Tests Module - Schemas
Pydantic схемы для валидации данных
"""

from datetime import datetime
from decimal import Decimal
from typing import Optional, List, Dict, Any
from uuid import UUID

from pydantic import BaseModel, Field, validator

from app.laboratory.models import TestCategory


# ==================== Reference Range Schemas ====================

class ReferenceRangeBase(BaseModel):
    """Базовая схема референсных значений"""
    test_code: str = Field(..., min_length=1, max_length=50)
    test_name: str = Field(..., min_length=1, max_length=200)
    category: str = Field(..., min_length=1, max_length=50)
    unit: str = Field(..., min_length=1, max_length=50)
    unit_display: Optional[str] = None
    min_value: Optional[Decimal] = None
    max_value: Optional[Decimal] = None
    critical_low: Optional[Decimal] = None
    critical_high: Optional[Decimal] = None
    gender: Optional[str] = None
    age_min: Optional[int] = None
    age_max: Optional[int] = None
    conditions: Dict[str, Any] = Field(default_factory=dict)
    source: Optional[str] = None
    methodology: Optional[str] = None


class ReferenceRangeCreate(ReferenceRangeBase):
    """Создание референсных значений"""
    laboratory_id: Optional[UUID] = None


class ReferenceRangeUpdate(BaseModel):
    """Обновление референсных значений"""
    test_name: Optional[str] = None
    unit: Optional[str] = None
    min_value: Optional[Decimal] = None
    max_value: Optional[Decimal] = None
    critical_low: Optional[Decimal] = None
    critical_high: Optional[Decimal] = None
    is_active: Optional[bool] = None


class ReferenceRangeResponse(ReferenceRangeBase):
    """Ответ с референсными значениями"""
    id: UUID
    laboratory_id: Optional[UUID]
    is_active: bool
    created_at: datetime
    updated_at: datetime
    
    class Config:
        from_attributes = True


# ==================== Test Result Schemas ====================

class TestResultBase(BaseModel):
    """Базовая схема результата теста"""
    test_code: str = Field(..., min_length=1, max_length=50)
    test_name: str = Field(..., min_length=1, max_length=200)
    category: str = Field(..., min_length=1, max_length=50)
    value_numeric: Optional[Decimal] = None
    value_text: Optional[str] = None
    value_coded: Optional[str] = None
    unit: Optional[str] = None
    reference_min: Optional[Decimal] = None
    reference_max: Optional[Decimal] = None
    reference_text: Optional[str] = None
    interpretation: Optional[str] = None
    interpretation_text: Optional[str] = None
    is_critical: bool = False
    is_abnormal: bool = False
    comments: Optional[str] = None


class TestResultCreate(TestResultBase):
    """Создание результата теста"""
    reference_range_id: Optional[UUID] = None
    methodology: Optional[str] = None
    instrument: Optional[str] = None


class TestResultResponse(TestResultBase):
    """Ответ с результатом теста"""
    id: UUID
    laboratory_test_id: UUID
    reference_range_id: Optional[UUID]
    is_delta_check: bool
    previous_value: Optional[Decimal]
    previous_date: Optional[datetime]
    delta_percent: Optional[Decimal]
    methodology: Optional[str]
    instrument: Optional[str]
    created_at: datetime
    
    class Config:
        from_attributes = True


class TestResultWithTrend(TestResultResponse):
    """Результат с историей"""
    history: List[Dict[str, Any]] = Field(default_factory=list)
    trend_direction: Optional[str] = None


# ==================== Laboratory Test Schemas ====================

class LaboratoryTestBase(BaseModel):
    """Базовая схема лабораторного исследования"""
    clinical_indication: Optional[str] = None
    diagnosis_codes: List[str] = Field(default_factory=list)
    priority: str = "routine"
    notes: Optional[str] = None


class LaboratoryTestCreate(LaboratoryTestBase):
    """Создание лабораторного исследования"""
    patient_id: UUID
    test_codes: List[str] = Field(..., min_items=1)
    panel_code: Optional[str] = None
    laboratory_id: Optional[UUID] = None


class LaboratoryTestUpdate(BaseModel):
    """Обновление лабораторного исследования"""
    status: Optional[str] = None
    collection_date: Optional[datetime] = None
    collection_type: Optional[str] = None
    collected_by: Optional[str] = None
    notes: Optional[str] = None


class LaboratoryTestResponse(LaboratoryTestBase):
    """Ответ с лабораторным исследованием"""
    id: UUID
    patient_id: UUID
    doctor_id: UUID
    laboratory_id: Optional[UUID]
    order_number: str
    order_date: datetime
    status: str
    collection_date: Optional[datetime]
    collection_type: Optional[str]
    collected_by: Optional[str]
    result_date: Optional[datetime]
    verified_by: Optional[UUID]
    verified_at: Optional[datetime]
    created_at: datetime
    updated_at: datetime
    
    class Config:
        from_attributes = True


class LaboratoryTestDetail(LaboratoryTestResponse):
    """Детальная информация об исследовании"""
    results: List[TestResultResponse] = Field(default_factory=list)
    patient_name: Optional[str] = None
    doctor_name: Optional[str] = None
    laboratory_name: Optional[str] = None


class LaboratoryTestList(BaseModel):
    """Список исследований с пагинацией"""
    items: List[LaboratoryTestResponse]
    total: int
    page: int
    pages: int


# ==================== Test Panel Schemas ====================

class TestPanelBase(BaseModel):
    """Базовая схема панели тестов"""
    code: str = Field(..., min_length=1, max_length=50)
    name: str = Field(..., min_length=1, max_length=200)
    description: Optional[str] = None
    category: str = Field(..., min_length=1, max_length=50)
    test_codes: List[str] = Field(default_factory=list)
    default_priority: str = "routine"


class TestPanelCreate(TestPanelBase):
    """Создание панели тестов"""
    pass


class TestPanelResponse(TestPanelBase):
    """Ответ с панелью тестов"""
    id: UUID
    is_active: bool
    created_at: datetime
    updated_at: datetime
    
    class Config:
        from_attributes = True


# ==================== Laboratory Schemas ====================

class LaboratoryBase(BaseModel):
    """Базовая схема лаборатории"""
    code: str = Field(..., min_length=1, max_length=50)
    name: str = Field(..., min_length=1, max_length=200)
    address: Optional[str] = None
    phone: Optional[str] = None
    email: Optional[str] = None
    lab_type: Optional[str] = None
    hl7_interface: Dict[str, Any] = Field(default_factory=dict)
    api_endpoint: Optional[str] = None


class LaboratoryCreate(LaboratoryBase):
    """Создание лаборатории"""
    pass


class LaboratoryResponse(LaboratoryBase):
    """Ответ с лабораторией"""
    id: UUID
    is_active: bool
    created_at: datetime
    updated_at: datetime
    
    class Config:
        from_attributes = True


# ==================== Critical Value Alert Schemas ====================

class CriticalValueAlertBase(BaseModel):
    """Базовая схема алерта"""
    notes: Optional[str] = None


class CriticalValueAlertCreate(CriticalValueAlertBase):
    """Создание алерта"""
    test_result_id: UUID
    patient_id: UUID
    alert_type: str
    value: Decimal
    test_name: str


class CriticalValueAlertResponse(CriticalValueAlertBase):
    """Ответ с алертом"""
    id: UUID
    test_result_id: UUID
    patient_id: UUID
    alert_type: str
    value: Decimal
    test_name: str
    notified_users: List[UUID]
    notification_methods: List[str]
    status: str
    acknowledged_by: Optional[UUID]
    acknowledged_at: Optional[datetime]
    created_at: datetime
    resolved_at: Optional[datetime]
    
    class Config:
        from_attributes = True


class CriticalValueAlertAcknowledge(BaseModel):
    """Подтверждение алерта"""
    notes: Optional[str] = None


# ==================== Test Trend Schemas ====================

class TestTrendResponse(BaseModel):
    """Ответ с трендом показателя"""
    id: UUID
    patient_id: UUID
    test_code: str
    test_name: str
    values_count: int
    first_value: Optional[Decimal]
    first_date: Optional[datetime]
    last_value: Optional[Decimal]
    last_date: Optional[datetime]
    min_value: Optional[Decimal]
    max_value: Optional[Decimal]
    avg_value: Optional[Decimal]
    trend_direction: Optional[str]
    trend_slope: Optional[Decimal]
    updated_at: datetime
    
    class Config:
        from_attributes = True


class TestTrendDetail(TestTrendResponse):
    """Детальный тренд с историей"""
    history: List[Dict[str, Any]] = Field(default_factory=list)
    chart_data: Dict[str, Any] = Field(default_factory=dict)


# ==================== Analysis Schemas ====================

class LabAnalysisRequest(BaseModel):
    """Запрос на анализ лабораторных данных"""
    patient_id: UUID
    test_codes: Optional[List[str]] = None
    date_from: Optional[datetime] = None
    date_to: Optional[datetime] = None
    include_trends: bool = True
    include_ai_analysis: bool = False


class LabAnalysisResponse(BaseModel):
    """Ответ с анализом лабораторных данных"""
    patient_id: UUID
    summary: Dict[str, Any]
    abnormal_results: List[TestResultResponse]
    critical_results: List[TestResultResponse]
    trends: List[TestTrendResponse]
    ai_analysis: Optional[str] = None
    recommendations: List[str] = Field(default_factory=list)


class LabComparisonRequest(BaseModel):
    """Запрос на сравнение лабораторных данных"""
    patient_id: UUID
    test_codes: List[str]
    date_points: List[datetime]


class LabComparisonResponse(BaseModel):
    """Ответ со сравнением"""
    patient_id: UUID
    comparisons: List[Dict[str, Any]]
    changes_summary: Dict[str, Any]


# ==================== Search & Filter Schemas ====================

class LabTestSearchParams(BaseModel):
    """Параметры поиска исследований"""
    patient_id: Optional[UUID] = None
    status: Optional[str] = None
    category: Optional[str] = None
    date_from: Optional[datetime] = None
    date_to: Optional[datetime] = None
    has_critical: Optional[bool] = None
    has_abnormal: Optional[bool] = None
    page: int = 1
    limit: int = 20


class TestResultSearchParams(BaseModel):
    """Параметры поиска результатов"""
    patient_id: UUID
    test_code: Optional[str] = None
    category: Optional[str] = None
    interpretation: Optional[str] = None
    date_from: Optional[datetime] = None
    date_to: Optional[datetime] = None
    limit: int = 50


# ==================== Import/Export Schemas ====================

class LabResultsImport(BaseModel):
    """Импорт результатов из внешней системы"""
    laboratory_id: UUID
    patient_id: UUID
    order_number: Optional[str] = None
    results: List[TestResultCreate]
    collection_date: Optional[datetime] = None


class LabResultsExport(BaseModel):
    """Экспорт результатов"""
    patient_id: UUID
    test_codes: Optional[List[str]] = None
    date_from: Optional[datetime] = None
    date_to: Optional[datetime] = None
    format: str = "json"  # json, pdf, hl7, fhir


# ==================== Statistics Schemas ====================

class LabStatisticsRequest(BaseModel):
    """Запрос статистики"""
    laboratory_id: Optional[UUID] = None
    date_from: datetime
    date_to: datetime
    group_by: str = "day"  # day, week, month


class LabStatisticsResponse(BaseModel):
    """Ответ со статистикой"""
    period: Dict[str, Any]
    total_tests: int
    total_orders: int
    by_category: Dict[str, int]
    by_status: Dict[str, int]
    critical_count: int
    abnormal_count: int
    average_turnaround_time: Optional[float]
    trends: List[Dict[str, Any]]