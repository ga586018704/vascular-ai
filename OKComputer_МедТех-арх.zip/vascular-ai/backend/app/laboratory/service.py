"""
Laboratory Tests Module - Service Layer
Бизнес-логика для работы с лабораторными исследованиями
"""

from datetime import datetime, timedelta
from decimal import Decimal
from typing import List, Optional, Dict, Any, Tuple
from uuid import UUID

from sqlalchemy import and_, or_, func, desc
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.future import select
from sqlalchemy.orm import selectinload

from app.laboratory.models import (
    LaboratoryTest, TestResult, ReferenceRange, TestPanel,
    Laboratory, CriticalValueAlert, TestTrend
)
from app.laboratory.schemas import (
    LaboratoryTestCreate, LaboratoryTestUpdate, TestResultCreate,
    ReferenceRangeCreate, TestPanelCreate, LaboratoryCreate,
    CriticalValueAlertCreate, LabAnalysisRequest, LabComparisonRequest,
    LabTestSearchParams, TestResultSearchParams
)
from app.core.logging import audit_logger


class LaboratoryService:
    """Сервис для работы с лабораторными исследованиями"""
    
    def __init__(self, db: AsyncSession):
        self.db = db
    
    # ==================== Laboratory Tests ====================
    
    async def create_test(
        self, 
        data: LaboratoryTestCreate, 
        doctor_id: UUID
    ) -> LaboratoryTest:
        """Создание нового лабораторного исследования"""
        # Генерация номера заказа
        order_number = await self._generate_order_number()
        
        test = LaboratoryTest(
            patient_id=data.patient_id,
            doctor_id=doctor_id,
            laboratory_id=data.laboratory_id,
            order_number=order_number,
            clinical_indication=data.clinical_indication,
            diagnosis_codes=data.diagnosis_codes,
            priority=data.priority,
            notes=data.notes,
            status="ordered"
        )
        
        self.db.add(test)
        await self.db.flush()
        
        # Если указана панель - добавить все тесты из панели
        if data.panel_code:
            panel = await self.get_panel_by_code(data.panel_code)
            if panel:
                data.test_codes.extend(panel.test_codes)
        
        # Создать placeholder результаты для отслеживания
        for test_code in set(data.test_codes):  # Уникальные коды
            ref_range = await self.get_reference_range(test_code, data.patient_id)
            
            placeholder = TestResult(
                laboratory_test_id=test.id,
                test_code=test_code,
                test_name=ref_range.test_name if ref_range else test_code,
                category=ref_range.category if ref_range else "other",
                unit=ref_range.unit if ref_range else None,
                reference_min=ref_range.min_value if ref_range else None,
                reference_max=ref_range.max_value if ref_range else None,
                reference_text=self._format_reference_range(ref_range)
            )
            self.db.add(placeholder)
        
        await self.db.commit()
        await self.db.refresh(test)
        
        audit_logger.info(
            f"Created laboratory test {test.id}",
            extra={
                "patient_id": str(data.patient_id),
                "doctor_id": str(doctor_id),
                "order_number": order_number,
                "test_count": len(data.test_codes)
            }
        )
        
        return test
    
    async def get_test(self, test_id: UUID) -> Optional[LaboratoryTest]:
        """Получение исследования по ID"""
        result = await self.db.execute(
            select(LaboratoryTest)
            .options(selectinload(LaboratoryTest.results))
            .where(LaboratoryTest.id == test_id)
        )
        return result.scalar_one_or_none()
    
    async def get_test_detail(self, test_id: UUID) -> Optional[Dict[str, Any]]:
        """Получение детальной информации об исследовании"""
        test = await self.get_test(test_id)
        if not test:
            return None
        
        # Получить связанные данные
        from app.models import Patient, User
        
        patient_result = await self.db.execute(
            select(Patient).where(Patient.id == test.patient_id)
        )
        patient = patient_result.scalar_one_or_none()
        
        doctor_result = await self.db.execute(
            select(User).where(User.id == test.doctor_id)
        )
        doctor = doctor_result.scalar_one_or_none()
        
        lab_result = await self.db.execute(
            select(Laboratory).where(Laboratory.id == test.laboratory_id)
        )
        laboratory = lab_result.scalar_one_or_none()
        
        return {
            "test": test,
            "patient_name": f"{patient.first_name} {patient.last_name}" if patient else None,
            "doctor_name": f"{doctor.first_name} {doctor.last_name}" if doctor else None,
            "laboratory_name": laboratory.name if laboratory else None
        }
    
    async def update_test(
        self, 
        test_id: UUID, 
        data: LaboratoryTestUpdate
    ) -> Optional[LaboratoryTest]:
        """Обновление исследования"""
        test = await self.get_test(test_id)
        if not test:
            return None
        
        update_data = data.dict(exclude_unset=True)
        for field, value in update_data.items():
            setattr(test, field, value)
        
        test.updated_at = datetime.utcnow()
        await self.db.commit()
        await self.db.refresh(test)
        
        return test
    
    async def cancel_test(self, test_id: UUID, reason: str) -> bool:
        """Отмена исследования"""
        test = await self.get_test(test_id)
        if not test or test.status in ["completed", "cancelled"]:
            return False
        
        test.status = "cancelled"
        test.notes = f"{test.notes or ''}\nCancelled: {reason}".strip()
        test.updated_at = datetime.utcnow()
        
        await self.db.commit()
        
        audit_logger.info(
            f"Cancelled laboratory test {test_id}",
            extra={"reason": reason}
        )
        
        return True
    
    async def search_tests(
        self, 
        params: LabTestSearchParams
    ) -> Tuple[List[LaboratoryTest], int]:
        """Поиск исследований"""
        query = select(LaboratoryTest)
        
        # Фильтры
        if params.patient_id:
            query = query.where(LaboratoryTest.patient_id == params.patient_id)
        if params.status:
            query = query.where(LaboratoryTest.status == params.status)
        if params.date_from:
            query = query.where(LaboratoryTest.order_date >= params.date_from)
        if params.date_to:
            query = query.where(LaboratoryTest.order_date <= params.date_to)
        
        # Подсчет общего количества
        count_result = await self.db.execute(
            select(func.count()).select_from(query.subquery())
        )
        total = count_result.scalar()
        
        # Пагинация
        query = query.order_by(desc(LaboratoryTest.order_date))
        query = query.offset((params.page - 1) * params.limit).limit(params.limit)
        
        result = await self.db.execute(query)
        tests = result.scalars().all()
        
        return list(tests), total
    
    # ==================== Test Results ====================
    
    async def add_result(
        self, 
        test_id: UUID, 
        data: TestResultCreate
    ) -> TestResult:
        """Добавление результата теста"""
        test = await self.get_test(test_id)
        if not test:
            raise ValueError(f"Test {test_id} not found")
        
        # Найти placeholder результат
        result_result = await self.db.execute(
            select(TestResult).where(
                and_(
                    TestResult.laboratory_test_id == test_id,
                    TestResult.test_code == data.test_code,
                    TestResult.value_numeric.is_(None),
                    TestResult.value_text.is_(None)
                )
            )
        )
        existing = result_result.scalar_one_or_none()
        
        # Интерпретация результата
        interpretation = await self._interpret_result(data)
        
        if existing:
            # Обновить существующий
            existing.value_numeric = data.value_numeric
            existing.value_text = data.value_text
            existing.value_coded = data.value_coded
            existing.unit = data.unit
            existing.interpretation = interpretation["status"]
            existing.interpretation_text = interpretation["text"]
            existing.is_critical = interpretation["is_critical"]
            existing.is_abnormal = interpretation["is_abnormal"]
            existing.comments = data.comments
            existing.methodology = data.methodology
            existing.instrument = data.instrument
            result = existing
        else:
            # Создать новый
            result = TestResult(
                laboratory_test_id=test_id,
                reference_range_id=data.reference_range_id,
                test_code=data.test_code,
                test_name=data.test_name,
                category=data.category,
                value_numeric=data.value_numeric,
                value_text=data.value_text,
                value_coded=data.value_coded,
                unit=data.unit,
                reference_min=data.reference_min,
                reference_max=data.reference_max,
                reference_text=data.reference_text,
                interpretation=interpretation["status"],
                interpretation_text=interpretation["text"],
                is_critical=interpretation["is_critical"],
                is_abnormal=interpretation["is_abnormal"],
                comments=data.comments,
                methodology=data.methodology,
                instrument=data.instrument
            )
            self.db.add(result)
        
        # Delta check
        await self._perform_delta_check(result, test.patient_id)
        
        # Обновить статус исследования
        await self._update_test_status(test_id)
        
        await self.db.commit()
        await self.db.refresh(result)
        
        # Проверить критические значения
        if interpretation["is_critical"]:
            await self._create_critical_alert(result, test.patient_id)
        
        # Обновить тренд
        await self._update_test_trend(test.patient_id, data.test_code)
        
        return result
    
    async def verify_results(
        self, 
        test_id: UUID, 
        verified_by: UUID
    ) -> bool:
        """Верификация результатов"""
        test = await self.get_test(test_id)
        if not test:
            return False
        
        test.status = "completed"
        test.verified_by = verified_by
        test.verified_at = datetime.utcnow()
        test.result_date = datetime.utcnow()
        
        await self.db.commit()
        
        audit_logger.info(
            f"Verified laboratory test {test_id}",
            extra={"verified_by": str(verified_by)}
        )
        
        return True
    
    async def get_patient_results(
        self, 
        params: TestResultSearchParams
    ) -> List[TestResult]:
        """Получение результатов пациента"""
        # Получить ID всех исследований пациента
        test_ids_result = await self.db.execute(
            select(LaboratoryTest.id).where(
                LaboratoryTest.patient_id == params.patient_id
            )
        )
        test_ids = [row[0] for row in test_ids_result.all()]
        
        if not test_ids:
            return []
        
        query = select(TestResult).where(
            TestResult.laboratory_test_id.in_(test_ids)
        )
        
        if params.test_code:
            query = query.where(TestResult.test_code == params.test_code)
        if params.category:
            query = query.where(TestResult.category == params.category)
        if params.interpretation:
            query = query.where(TestResult.interpretation == params.interpretation)
        if params.date_from:
            query = query.where(TestResult.created_at >= params.date_from)
        if params.date_to:
            query = query.where(TestResult.created_at <= params.date_to)
        
        query = query.order_by(desc(TestResult.created_at)).limit(params.limit)
        
        result = await self.db.execute(query)
        return list(result.scalars().all())
    
    async def get_result_history(
        self, 
        patient_id: UUID, 
        test_code: str,
        limit: int = 20
    ) -> List[Dict[str, Any]]:
        """Получение истории результатов показателя"""
        results = await self.get_patient_results(
            TestResultSearchParams(
                patient_id=patient_id,
                test_code=test_code,
                limit=limit
            )
        )
        
        history = []
        for r in results:
            if r.value_numeric is not None:
                history.append({
                    "date": r.created_at.isoformat(),
                    "value": float(r.value_numeric),
                    "unit": r.unit,
                    "interpretation": r.interpretation,
                    "is_critical": r.is_critical
                })
        
        return history
    
    # ==================== Reference Ranges ====================
    
    async def create_reference_range(
        self, 
        data: ReferenceRangeCreate
    ) -> ReferenceRange:
        """Создание референсных значений"""
        ref = ReferenceRange(**data.dict())
        self.db.add(ref)
        await self.db.commit()
        await self.db.refresh(ref)
        return ref
    
    async def get_reference_range(
        self, 
        test_code: str, 
        patient_id: Optional[UUID] = None,
        gender: Optional[str] = None,
        age_months: Optional[int] = None
    ) -> Optional[ReferenceRange]:
        """Получение референсных значений для теста"""
        query = select(ReferenceRange).where(
            and_(
                ReferenceRange.test_code == test_code,
                ReferenceRange.is_active == True
            )
        )
        
        # Фильтр по полу
        if gender:
            query = query.where(
                or_(
                    ReferenceRange.gender.is_(None),
                    ReferenceRange.gender == gender
                )
            )
        
        # Фильтр по возрасту
        if age_months is not None:
            query = query.where(
                or_(
                    and_(
                        ReferenceRange.age_min.is_(None),
                        ReferenceRange.age_max.is_(None)
                    ),
                    and_(
                        ReferenceRange.age_min <= age_months,
                        ReferenceRange.age_max >= age_months
                    )
                )
            )
        
        result = await self.db.execute(query.limit(1))
        return result.scalar_one_or_none()
    
    # ==================== Test Panels ====================
    
    async def create_panel(self, data: TestPanelCreate) -> TestPanel:
        """Создание панели тестов"""
        panel = TestPanel(**data.dict())
        self.db.add(panel)
        await self.db.commit()
        await self.db.refresh(panel)
        return panel
    
    async def get_panel_by_code(self, code: str) -> Optional[TestPanel]:
        """Получение панели по коду"""
        result = await self.db.execute(
            select(TestPanel).where(
                and_(TestPanel.code == code, TestPanel.is_active == True)
            )
        )
        return result.scalar_one_or_none()
    
    async def get_all_panels(self) -> List[TestPanel]:
        """Получение всех активных панелей"""
        result = await self.db.execute(
            select(TestPanel).where(TestPanel.is_active == True)
        )
        return list(result.scalars().all())
    
    # ==================== Analysis ====================
    
    async def analyze_patient_labs(
        self, 
        request: LabAnalysisRequest
    ) -> Dict[str, Any]:
        """Анализ лабораторных данных пациента"""
        # Получить все результаты
        results = await self.get_patient_results(
            TestResultSearchParams(
                patient_id=request.patient_id,
                test_codes=request.test_codes,
                date_from=request.date_from,
                date_to=request.date_to,
                limit=1000
            )
        )
        
        # Категоризация
        abnormal = [r for r in results if r.is_abnormal]
        critical = [r for r in results if r.is_critical]
        
        # Получить тренды
        trends = []
        if request.include_trends:
            test_codes = set(r.test_code for r in results)
            for code in test_codes:
                trend = await self._get_test_trend(request.patient_id, code)
                if trend:
                    trends.append(trend)
        
        # AI анализ
        ai_analysis = None
        if request.include_ai_analysis:
            ai_analysis = await self._generate_ai_analysis(results)
        
        return {
            "patient_id": request.patient_id,
            "summary": {
                "total_tests": len(results),
                "abnormal_count": len(abnormal),
                "critical_count": len(critical),
                "date_range": {
                    "from": request.date_from.isoformat() if request.date_from else None,
                    "to": request.date_to.isoformat() if request.date_to else None
                }
            },
            "abnormal_results": abnormal,
            "critical_results": critical,
            "trends": trends,
            "ai_analysis": ai_analysis,
            "recommendations": self._generate_recommendations(results)
        }
    
    async def compare_lab_results(
        self, 
        request: LabComparisonRequest
    ) -> Dict[str, Any]:
        """Сравнение лабораторных данных на разные даты"""
        comparisons = []
        
        for test_code in request.test_codes:
            test_comparisons = []
            
            for date_point in request.date_points:
                # Найти ближайший результат к дате
                result = await self._get_closest_result(
                    request.patient_id, test_code, date_point
                )
                
                if result:
                    test_comparisons.append({
                        "date": date_point.isoformat(),
                        "value": float(result.value_numeric) if result.value_numeric else None,
                        "unit": result.unit,
                        "interpretation": result.interpretation
                    })
            
            if len(test_comparisons) >= 2:
                # Рассчитать изменения
                changes = self._calculate_changes(test_comparisons)
                
                comparisons.append({
                    "test_code": test_code,
                    "test_name": test_comparisons[0].get("test_name", test_code),
                    "values": test_comparisons,
                    "changes": changes
                })
        
        return {
            "patient_id": request.patient_id,
            "comparisons": comparisons,
            "changes_summary": self._summarize_changes(comparisons)
        }
    
    # ==================== Statistics ====================
    
    async def get_statistics(
        self, 
        laboratory_id: Optional[UUID],
        date_from: datetime,
        date_to: datetime
    ) -> Dict[str, Any]:
        """Получение статистики лаборатории"""
        query = select(LaboratoryTest)
        
        if laboratory_id:
            query = query.where(LaboratoryTest.laboratory_id == laboratory_id)
        
        query = query.where(
            and_(
                LaboratoryTest.order_date >= date_from,
                LaboratoryTest.order_date <= date_to
            )
        )
        
        result = await self.db.execute(query)
        tests = result.scalars().all()
        
        # Статистика по статусам
        by_status = {}
        for test in tests:
            by_status[test.status] = by_status.get(test.status, 0) + 1
        
        # Статистика по категориям (из результатов)
        test_ids = [t.id for t in tests]
        
        if test_ids:
            results_query = select(TestResult).where(
                TestResult.laboratory_test_id.in_(test_ids)
            )
            results_result = await self.db.execute(results_query)
            results = results_result.scalars().all()
            
            by_category = {}
            critical_count = 0
            abnormal_count = 0
            
            for r in results:
                by_category[r.category] = by_category.get(r.category, 0) + 1
                if r.is_critical:
                    critical_count += 1
                if r.is_abnormal:
                    abnormal_count += 1
        else:
            by_category = {}
            critical_count = 0
            abnormal_count = 0
        
        return {
            "period": {
                "from": date_from.isoformat(),
                "to": date_to.isoformat()
            },
            "total_tests": len(tests),
            "total_orders": len(set(t.order_number for t in tests)),
            "by_category": by_category,
            "by_status": by_status,
            "critical_count": critical_count,
            "abnormal_count": abnormal_count,
            "average_turnaround_time": None  # TODO: рассчитать
        }
    
    # ==================== Private Methods ====================
    
    async def _generate_order_number(self) -> str:
        """Генерация уникального номера заказа"""
        timestamp = datetime.utcnow().strftime("%Y%m%d%H%M%S")
        random_suffix = str(uuid4())[:8].upper()
        return f"LAB{timestamp}{random_suffix}"
    
    async def _interpret_result(
        self, 
        data: TestResultCreate
    ) -> Dict[str, Any]:
        """Интерпретация результата теста"""
        if data.value_numeric is None:
            return {
                "status": "pending",
                "text": "Результат ожидается",
                "is_critical": False,
                "is_abnormal": False
            }
        
        value = data.value_numeric
        ref_min = data.reference_min
        ref_max = data.reference_max
        critical_low = None
        critical_high = None
        
        # Получить критические значения из справочника
        ref_range = await self.get_reference_range(data.test_code)
        if ref_range:
            critical_low = ref_range.critical_low
            critical_high = ref_range.critical_high
        
        # Проверка критических значений
        if critical_low is not None and value <= critical_low:
            return {
                "status": "critical_low",
                "text": f"Критически низкое значение: {value}",
                "is_critical": True,
                "is_abnormal": True
            }
        
        if critical_high is not None and value >= critical_high:
            return {
                "status": "critical_high",
                "text": f"Критически высокое значение: {value}",
                "is_critical": True,
                "is_abnormal": True
            }
        
        # Проверка референсных значений
        if ref_min is not None and value < ref_min:
            return {
                "status": "low",
                "text": f"Ниже нормы: {value} (норма: {ref_min}-{ref_max})",
                "is_critical": False,
                "is_abnormal": True
            }
        
        if ref_max is not None and value > ref_max:
            return {
                "status": "high",
                "text": f"Выше нормы: {value} (норма: {ref_min}-{ref_max})",
                "is_critical": False,
                "is_abnormal": True
            }
        
        return {
            "status": "normal",
            "text": f"В пределах нормы: {value}",
            "is_critical": False,
            "is_abnormal": False
        }
    
    async def _perform_delta_check(
        self, 
        result: TestResult, 
        patient_id: UUID
    ):
        """Проверка значительного изменения от предыдущего результата"""
        if result.value_numeric is None:
            return
        
        # Получить предыдущий результат
        previous = await self.get_patient_results(
            TestResultSearchParams(
                patient_id=patient_id,
                test_code=result.test_code,
                limit=2
            )
        )
        
        if len(previous) >= 2:
            prev_result = previous[1]  # Предыдущий (не текущий)
            if prev_result.value_numeric:
                result.previous_value = prev_result.value_numeric
                result.previous_date = prev_result.created_at
                
                # Рассчитать процент изменения
                prev_val = float(prev_result.value_numeric)
                curr_val = float(result.value_numeric)
                
                if prev_val != 0:
                    delta = ((curr_val - prev_val) / abs(prev_val)) * 100
                    result.delta_percent = Decimal(str(delta))
                    
                    # Флаг значительного изменения (>20%)
                    if abs(delta) > 20:
                        result.is_delta_check = True
    
    async def _create_critical_alert(
        self, 
        result: TestResult, 
        patient_id: UUID
    ):
        """Создание уведомления о критическом значении"""
        alert = CriticalValueAlert(
            test_result_id=result.id,
            patient_id=patient_id,
            alert_type=result.interpretation,
            value=result.value_numeric,
            test_name=result.test_name,
            status="pending",
            notification_methods=["email", "push"]
        )
        self.db.add(alert)
        await self.db.flush()
        
        # TODO: Отправить уведомления
        audit_logger.critical(
            f"Critical value alert created: {alert.id}",
            extra={
                "patient_id": str(patient_id),
                "test": result.test_name,
                "value": float(result.value_numeric) if result.value_numeric else None
            }
        )
    
    async def _update_test_status(self, test_id: UUID):
        """Обновление статуса исследования на основе результатов"""
        result = await self.db.execute(
            select(TestResult).where(TestResult.laboratory_test_id == test_id)
        )
        results = result.scalars().all()
        
        # Проверить, все ли результаты заполнены
        all_completed = all(
            r.value_numeric is not None or r.value_text is not None 
            for r in results
        )
        
        if all_completed and results:
            test = await self.get_test(test_id)
            if test and test.status == "processing":
                test.status = "pending_verification"
                await self.db.flush()
    
    async def _update_test_trend(self, patient_id: UUID, test_code: str):
        """Обновление тренда показателя"""
        # Получить все результаты для расчета тренда
        results = await self.get_patient_results(
            TestResultSearchParams(
                patient_id=patient_id,
                test_code=test_code,
                limit=100
            )
        )
        
        numeric_results = [
            r for r in results 
            if r.value_numeric is not None
        ]
        
        if len(numeric_results) < 2:
            return
        
        # Рассчитать статистики
        values = [float(r.value_numeric) for r in numeric_results]
        dates = [r.created_at for r in numeric_results]
        
        # Проверить существующий тренд
        trend_result = await self.db.execute(
            select(TestTrend).where(
                and_(
                    TestTrend.patient_id == patient_id,
                    TestTrend.test_code == test_code
                )
            )
        )
        trend = trend_result.scalar_one_or_none()
        
        # Определить направление тренда
        trend_direction = self._calculate_trend_direction(values)
        
        if trend:
            trend.values_count = len(numeric_results)
            trend.first_value = Decimal(str(values[-1]))
            trend.first_date = dates[-1]
            trend.last_value = Decimal(str(values[0]))
            trend.last_date = dates[0]
            trend.min_value = Decimal(str(min(values)))
            trend.max_value = Decimal(str(max(values)))
            trend.avg_value = Decimal(str(sum(values) / len(values)))
            trend.trend_direction = trend_direction
        else:
            trend = TestTrend(
                patient_id=patient_id,
                test_code=test_code,
                test_name=numeric_results[0].test_name,
                values_count=len(numeric_results),
                first_value=Decimal(str(values[-1])),
                first_date=dates[-1],
                last_value=Decimal(str(values[0])),
                last_date=dates[0],
                min_value=Decimal(str(min(values))),
                max_value=Decimal(str(max(values))),
                avg_value=Decimal(str(sum(values) / len(values))),
                trend_direction=trend_direction
            )
            self.db.add(trend)
        
        await self.db.flush()
    
    def _calculate_trend_direction(self, values: List[float]) -> str:
        """Расчет направления тренда"""
        if len(values) < 3:
            return "insufficient_data"
        
        # Простая линейная регрессия
        n = len(values)
        x = list(range(n))
        
        sum_x = sum(x)
        sum_y = sum(values)
        sum_xy = sum(xi * yi for xi, yi in zip(x, values))
        sum_x2 = sum(xi ** 2 for xi in x)
        
        slope = (n * sum_xy - sum_x * sum_y) / (n * sum_x2 - sum_x ** 2)
        
        if slope > 0.01:
            return "increasing"
        elif slope < -0.01:
            return "decreasing"
        else:
            return "stable"
    
    def _format_reference_range(self, ref_range: Optional[ReferenceRange]) -> str:
        """Форматирование референсного диапазона в строку"""
        if not ref_range:
            return ""
        
        if ref_range.min_value is not None and ref_range.max_value is not None:
            return f"{ref_range.min_value} - {ref_range.max_value}"
        elif ref_range.min_value is not None:
            return f"> {ref_range.min_value}"
        elif ref_range.max_value is not None:
            return f"< {ref_range.max_value}"
        
        return ""
    
    async def _get_test_trend(
        self, 
        patient_id: UUID, 
        test_code: str
    ) -> Optional[TestTrend]:
        """Получение тренда показателя"""
        result = await self.db.execute(
            select(TestTrend).where(
                and_(
                    TestTrend.patient_id == patient_id,
                    TestTrend.test_code == test_code
                )
            )
        )
        return result.scalar_one_or_none()
    
    async def _get_closest_result(
        self, 
        patient_id: UUID, 
        test_code: str,
        target_date: datetime
    ) -> Optional[TestResult]:
        """Получение ближайшего результата к дате"""
        # Получить ID всех исследований пациента
        test_ids_result = await self.db.execute(
            select(LaboratoryTest.id).where(
                LaboratoryTest.patient_id == patient_id
            )
        )
        test_ids = [row[0] for row in test_ids_result.all()]
        
        if not test_ids:
            return None
        
        result = await self.db.execute(
            select(TestResult)
            .where(
                and_(
                    TestResult.laboratory_test_id.in_(test_ids),
                    TestResult.test_code == test_code,
                    TestResult.value_numeric.isnot(None)
                )
            )
            .order_by(
                func.abs(func.extract('epoch', TestResult.created_at - target_date))
            )
            .limit(1)
        )
        
        return result.scalar_one_or_none()
    
    def _calculate_changes(self, values: List[Dict[str, Any]]) -> Dict[str, Any]:
        """Расчет изменений между значениями"""
        if len(values) < 2:
            return {}
        
        first = values[0]
        last = values[-1]
        
        if first.get("value") is None or last.get("value") is None:
            return {}
        
        first_val = first["value"]
        last_val = last["value"]
        
        absolute_change = last_val - first_val
        percent_change = ((last_val - first_val) / abs(first_val)) * 100 if first_val != 0 else 0
        
        return {
            "absolute": round(absolute_change, 4),
            "percent": round(percent_change, 2),
            "direction": "increased" if absolute_change > 0 else "decreased" if absolute_change < 0 else "unchanged"
        }
    
    def _summarize_changes(self, comparisons: List[Dict[str, Any]]) -> Dict[str, Any]:
        """Сводка изменений"""
        improved = 0
        worsened = 0
        unchanged = 0
        
        for comp in comparisons:
            changes = comp.get("changes", {})
            direction = changes.get("direction", "unchanged")
            
            # Упрощенная логика - в реальности нужен клинический контекст
            if direction == "decreased":
                improved += 1
            elif direction == "increased":
                worsened += 1
            else:
                unchanged += 1
        
        return {
            "improved": improved,
            "worsened": worsened,
            "unchanged": unchanged,
            "total": len(comparisons)
        }
    
    def _generate_recommendations(self, results: List[TestResult]) -> List[str]:
        """Генерация рекомендаций на основе результатов"""
        recommendations = []
        
        critical = [r for r in results if r.is_critical]
        abnormal = [r for r in results if r.is_abnormal and not r.is_critical]
        
        if critical:
            recommendations.append(
                f"ВНИМАНИЕ: Обнаружено {len(critical)} критически важных значений. "
                "Требуется немедленная клиническая оценка."
            )
        
        if abnormal:
            recommendations.append(
                f"Обнаружено {len(abnormal)} отклонений от нормы. "
                "Рекомендуется консультация специалиста."
            )
        
        # Специфические рекомендации
        for result in results:
            if result.test_code == "CREATININE" and result.is_abnormal:
                recommendations.append(
                    "Отклонение креатинина: рекомендуется оценка функции почек "
                    "и корректировка дозировки нефротоксичных препаратов."
                )
            elif result.test_code == "INR" and result.is_abnormal:
                recommendations.append(
                    "Отклонение МНО: требуется корректировка антикоагулянтной терапии."
                )
        
        return recommendations
    
    async def _generate_ai_analysis(self, results: List[TestResult]) -> str:
        """Генерация AI анализа результатов"""
        # Заглушка - в реальности интеграция с AI агентом
        critical_count = len([r for r in results if r.is_critical])
        abnormal_count = len([r for r in results if r.is_abnormal and not r.is_critical])
        
        if critical_count > 0:
            return (
                f"AI анализ выявил {critical_count} критических значений, "
                f"требующих немедленного вмешательства. "
                f"Дополнительно {abnormal_count} отклонений от нормы. "
                "Рекомендуется комплексная клиническая оценка."
            )
        elif abnormal_count > 0:
            return (
                f"AI анализ выявил {abnormal_count} отклонений от нормы. "
                "Паттерн изменений может указывать на необходимость "
                "дополнительного обследования или корректировки терапии."
            )
        else:
            return "Все показатели в пределах нормы. Отклонений не выявлено."