"""
Laboratory Tests Module - Models
Модели для работы с лабораторными исследованиями
"""

from datetime import datetime
from decimal import Decimal
from enum import Enum
from typing import Optional, List, Dict, Any
from uuid import uuid4

from sqlalchemy import (
    Column, String, DateTime, ForeignKey, Numeric, 
    Text, Boolean, Integer, JSON, Index
)
from sqlalchemy.dialects.postgresql import UUID, ARRAY
from sqlalchemy.orm import relationship

from app.db.base_class import Base


class TestCategory(str, Enum):
    """Категории лабораторных тестов"""
    HEMATOLOGY = "hematology"  # Гематология
    BIOCHEMISTRY = "biochemistry"  # Биохимия
    COAGULATION = "coagulation"  # Коагулограмма
    IMMUNOLOGY = "immunology"  # Иммунология
    MICROBIOLOGY = "microbiology"  # Микробиология
    GENETIC = "genetic"  # Генетика
    HORMONES = "hormones"  # Гормоны
    TUMOR_MARKERS = "tumor_markers"  # Онкомаркеры
    DRUG_MONITORING = "drug_monitoring"  # Терапевтический мониторинг
    CARDIAC_MARKERS = "cardiac_markers"  # Кардиомаркеры
    INFLAMMATION = "inflammation"  # Маркеры воспаления
    LIPID_PROFILE = "lipid_profile"  # Липидный профиль
    KIDNEY_FUNCTION = "kidney_function"  # Функция почек
    LIVER_FUNCTION = "liver_function"  # Функция печени
    ELECTROLYTES = "electrolytes"  # Электролиты
    BLOOD_GAS = "blood_gas"  # АБГ
    URINALYSIS = "urinalysis"  # Анализ мочи
    OTHER = "other"  # Прочее


class ReferenceRange(Base):
    """Справочник референсных значений"""
    __tablename__ = "reference_ranges"
    
    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid4)
    test_code = Column(String(50), nullable=False, index=True)
    test_name = Column(String(200), nullable=False)
    category = Column(String(50), nullable=False)
    
    # Единицы измерения
    unit = Column(String(50), nullable=False)
    unit_display = Column(String(100))
    
    # Референсные значения
    min_value = Column(Numeric(15, 6), nullable=True)
    max_value = Column(Numeric(15, 6), nullable=True)
    
    # Критические значения
    critical_low = Column(Numeric(15, 6), nullable=True)
    critical_high = Column(Numeric(15, 6), nullable=True)
    
    # Пол и возрастные ограничения
    gender = Column(String(10), nullable=True)  # male, female, null = both
    age_min = Column(Integer, nullable=True)  # в месяцах
    age_max = Column(Integer, nullable=True)
    
    # Дополнительные условия
    conditions = Column(JSON, default=dict)  # {"pregnancy": true, "fasting": true}
    
    # Источник данных
    source = Column(String(200))  # Лаборатория, производитель
    methodology = Column(Text)  # Методика определения
    
    # Метаданные
    is_active = Column(Boolean, default=True)
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    # Связи
    laboratory_id = Column(UUID(as_uuid=True), ForeignKey("laboratories.id"), nullable=True)
    
    __table_args__ = (
        Index('ix_reference_ranges_test_gender_age', 'test_code', 'gender', 'age_min', 'age_max'),
    )


class LaboratoryTest(Base):
    """Лабораторное исследование (заказ)"""
    __tablename__ = "laboratory_tests"
    
    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid4)
    
    # Связи
    patient_id = Column(UUID(as_uuid=True), ForeignKey("patients.id"), nullable=False)
    doctor_id = Column(UUID(as_uuid=True), ForeignKey("users.id"), nullable=False)
    laboratory_id = Column(UUID(as_uuid=True), ForeignKey("laboratories.id"), nullable=True)
    
    # Информация о заказе
    order_number = Column(String(100), unique=True, nullable=False, index=True)
    order_date = Column(DateTime, default=datetime.utcnow)
    
    # Статус
    status = Column(String(50), default="ordered")  # ordered, collected, processing, completed, cancelled
    
    # Клиническая информация
    clinical_indication = Column(Text)
    diagnosis_codes = Column(ARRAY(String), default=list)  # ICD-10 codes
    
    # Приоритет
    priority = Column(String(20), default="routine")  # routine, urgent, stat
    
    # Время взятия образца
    collection_date = Column(DateTime)
    collection_type = Column(String(50))  # venous, arterial, capillary, urine, etc.
    collected_by = Column(String(200))
    
    # Время получения результатов
    result_date = Column(DateTime)
    verified_by = Column(UUID(as_uuid=True), ForeignKey("users.id"))
    verified_at = Column(DateTime)
    
    # Метаданные
    notes = Column(Text)
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    # Связи
    patient = relationship("Patient", back_populates="laboratory_tests")
    doctor = relationship("User", foreign_keys=[doctor_id])
    results = relationship("TestResult", back_populates="laboratory_test", cascade="all, delete-orphan")


class TestResult(Base):
    """Результат отдельного теста"""
    __tablename__ = "test_results"
    
    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid4)
    
    # Связи
    laboratory_test_id = Column(UUID(as_uuid=True), ForeignKey("laboratory_tests.id"), nullable=False)
    reference_range_id = Column(UUID(as_uuid=True), ForeignKey("reference_ranges.id"), nullable=True)
    
    # Информация о тесте
    test_code = Column(String(50), nullable=False, index=True)
    test_name = Column(String(200), nullable=False)
    category = Column(String(50), nullable=False)
    
    # Результат
    value_numeric = Column(Numeric(15, 6), nullable=True)
    value_text = Column(Text, nullable=True)
    value_coded = Column(String(100), nullable=True)  # positive/negative, +++, etc.
    
    # Единицы
    unit = Column(String(50))
    
    # Референсные значения (на момент теста)
    reference_min = Column(Numeric(15, 6))
    reference_max = Column(Numeric(15, 6))
    reference_text = Column(String(200))
    
    # Интерпретация
    interpretation = Column(String(20))  # normal, low, high, critical_low, critical_high, abnormal
    interpretation_text = Column(Text)
    
    # Флаги
    is_critical = Column(Boolean, default=False)
    is_abnormal = Column(Boolean, default=False)
    is_delta_check = Column(Boolean, default=False)  # Значительное изменение от предыдущего
    
    # Delta check информация
    previous_value = Column(Numeric(15, 6))
    previous_date = Column(DateTime)
    delta_percent = Column(Numeric(5, 2))
    
    # Дополнительная информация
    methodology = Column(String(200))
    instrument = Column(String(100))
    comments = Column(Text)
    
    # Метаданные
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    # Связи
    laboratory_test = relationship("LaboratoryTest", back_populates="results")
    reference_range = relationship("ReferenceRange")
    
    __table_args__ = (
        Index('ix_test_results_test_date', 'test_code', 'created_at'),
    )


class TestPanel(Base):
    """Панель тестов (группа связанных тестов)"""
    __tablename__ = "test_panels"
    
    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid4)
    
    code = Column(String(50), unique=True, nullable=False)
    name = Column(String(200), nullable=False)
    description = Column(Text)
    category = Column(String(50), nullable=False)
    
    # Тесты в панели
    test_codes = Column(ARRAY(String), default=list)
    
    # Настройки
    is_active = Column(Boolean, default=True)
    default_priority = Column(String(20), default="routine")
    
    # Метаданные
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)


class Laboratory(Base):
    """Лаборатория"""
    __tablename__ = "laboratories"
    
    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid4)
    
    code = Column(String(50), unique=True, nullable=False)
    name = Column(String(200), nullable=False)
    
    # Контакты
    address = Column(Text)
    phone = Column(String(50))
    email = Column(String(100))
    
    # Тип лаборатории
    lab_type = Column(String(50))  # internal, external, reference
    
    # Интеграция
    hl7_interface = Column(JSON)  # Настройки HL7/FHIR
    api_endpoint = Column(String(500))
    
    # Статус
    is_active = Column(Boolean, default=True)
    
    # Метаданные
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)


class CriticalValueAlert(Base):
    """Уведомление о критическом значении"""
    __tablename__ = "critical_value_alerts"
    
    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid4)
    
    # Связи
    test_result_id = Column(UUID(as_uuid=True), ForeignKey("test_results.id"), nullable=False)
    patient_id = Column(UUID(as_uuid=True), ForeignKey("patients.id"), nullable=False)
    
    # Информация об алерте
    alert_type = Column(String(50))  # critical_low, critical_high
    value = Column(Numeric(15, 6))
    test_name = Column(String(200))
    
    # Уведомления
    notified_users = Column(ARRAY(UUID(as_uuid=True)), default=list)
    notification_methods = Column(ARRAY(String), default=list)  # email, sms, push, pager
    
    # Статус
    status = Column(String(50), default="pending")  # pending, acknowledged, resolved
    acknowledged_by = Column(UUID(as_uuid=True), ForeignKey("users.id"))
    acknowledged_at = Column(DateTime)
    notes = Column(Text)
    
    # Метаданные
    created_at = Column(DateTime, default=datetime.utcnow)
    resolved_at = Column(DateTime)


class TestTrend(Base):
    """Тренд показателя для пациента"""
    __tablename__ = "test_trends"
    
    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid4)
    
    patient_id = Column(UUID(as_uuid=True), ForeignKey("patients.id"), nullable=False)
    test_code = Column(String(50), nullable=False)
    test_name = Column(String(200), nullable=False)
    
    # Статистика
    values_count = Column(Integer, default=0)
    first_value = Column(Numeric(15, 6))
    first_date = Column(DateTime)
    last_value = Column(Numeric(15, 6))
    last_date = Column(DateTime)
    min_value = Column(Numeric(15, 6))
    max_value = Column(Numeric(15, 6))
    avg_value = Column(Numeric(15, 6))
    
    # Тренд
    trend_direction = Column(String(20))  # improving, worsening, stable, fluctuating
    trend_slope = Column(Numeric(10, 6))  # Наклон линии тренда
    
    # Метаданные
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    __table_args__ = (
        Index('ix_test_trends_patient_test', 'patient_id', 'test_code'),
    )