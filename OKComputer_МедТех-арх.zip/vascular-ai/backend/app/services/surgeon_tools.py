"""
VASCULAR.AI - Инструменты для практикующего хирурга
Калькуляторы риска, протоколы, алгоритмы действий
"""

from typing import Dict, Any, List, Optional, Tuple
from dataclasses import dataclass
from enum import Enum
import math


# ==================== КАЛЬКУЛЯТОРЫ РИСКА ====================

class VSGNECalculator:
    """
    Vascular Study Group of New England (VSGNE) Risk Calculator
    Для предсказания смертности при операциях на ААА
    """
    
    def calculate(self, patient_data: Dict[str, Any], procedure_type: str) -> Dict[str, Any]:
        """
        Расчет риска смертности по VSGNE
        
        Параметры:
        - age: возраст
        - gender: пол
        - creatinine: креатинин
        - cad: ишемическая болезнь сердца
        - chf: хроническая сердечная недостаточность
        - copd: ХОБЛ
        - urgency: срочность (elective, urgent, emergent)
        - procedure_type: тип процедуры (open, evar)
        """
        score = 0
        risk_factors = []
        
        # Возраст
        age = patient_data.get("age", 65)
        if age >= 80:
            score += 3
            risk_factors.append("Возраст ≥80 лет (+3)")
        elif age >= 75:
            score += 2
            risk_factors.append("Возраст 75-79 лет (+2)")
        elif age >= 70:
            score += 1
            risk_factors.append("Возраст 70-74 лет (+1)")
        
        # Пол
        if patient_data.get("gender") == "female":
            score += 1
            risk_factors.append("Женский пол (+1)")
        
        # Креатинин
        creatinine = patient_data.get("creatinine", 1.0)
        if creatinine >= 2.0:
            score += 3
            risk_factors.append("Креатинин ≥2.0 мг/дл (+3)")
        elif creatinine >= 1.5:
            score += 2
            risk_factors.append("Креатинин 1.5-1.9 мг/дл (+2)")
        elif creatinine >= 1.2:
            score += 1
            risk_factors.append("Креатинин 1.2-1.4 мг/дл (+1)")
        
        # ИБС
        if patient_data.get("cad", False):
            score += 2
            risk_factors.append("ИБС (+2)")
        
        # ХСН
        if patient_data.get("chf", False):
            score += 3
            risk_factors.append("ХСН (+3)")
        
        # ХОБЛ
        if patient_data.get("copd", False):
            score += 1
            risk_factors.append("ХОБЛ (+1)")
        
        # Срочность
        urgency = patient_data.get("urgency", "elective")
        if urgency == "emergent":
            score += 5
            risk_factors.append("Экстренная операция (+5)")
        elif urgency == "urgent":
            score += 3
            risk_factors.append("Срочная операция (+3)")
        
        # Тип процедуры
        if procedure_type == "open":
            score += 2
            risk_factors.append("Открытая операция (+2)")
        
        # Расчет риска смертности
        mortality_risk = self._calculate_mortality(score)
        
        return {
            "score": score,
            "risk_factors": risk_factors,
            "predicted_mortality": mortality_risk,
            "risk_category": self._get_risk_category(score),
            "recommendations": self._get_recommendations(score, urgency)
        }
    
    def _calculate_mortality(self, score: int) -> Dict[str, float]:
        """Расчет предсказанной смертности"""
        # Приближенные значения на основе VSGNE
        mortality_map = {
            0: {"percentage": 0.5, "range": "0-1%"},
            1: {"percentage": 0.8, "range": "0-1%"},
            2: {"percentage": 1.2, "range": "1-2%"},
            3: {"percentage": 2.0, "range": "1-3%"},
            4: {"percentage": 3.0, "range": "2-4%"},
            5: {"percentage": 4.5, "range": "3-6%"},
            6: {"percentage": 6.5, "range": "4-9%"},
            7: {"percentage": 9.0, "range": "6-12%"},
            8: {"percentage": 12.0, "range": "8-16%"},
            9: {"percentage": 16.0, "range": "12-20%"},
            10: {"percentage": 21.0, "range": "16-26%"},
        }
        
        if score >= 10:
            return {"percentage": 25.0, "range": ">20%"}
        
        return mortality_map.get(score, {"percentage": 30.0, "range": ">25%"})
    
    def _get_risk_category(self, score: int) -> str:
        if score <= 3:
            return "Низкий риск"
        elif score <= 6:
            return "Умеренный риск"
        elif score <= 9:
            return "Высокий риск"
        else:
            return "Очень высокий риск"
    
    def _get_recommendations(self, score: int, urgency: str) -> List[str]:
        recommendations = []
        
        if score >= 7:
            recommendations.append("Консультация анестезиолога-реаниматолога обязательна")
            recommendations.append("Рассмотреть EVAR при подходящей анатомии")
            recommendations.append("Предоперационная оптимизация состояния")
        
        if score >= 10:
            recommendations.append("Высокий риск - обсудить с пациентом и семьей")
            recommendations.append("Рассмотреть консервативное лечение при возможности")
        
        if urgency == "elective" and score >= 8:
            recommendations.append("Отложить операцию для оптимизации состояния")
        
        return recommendations


class GASCalculator:
    """
    Global Aneurysm Score (GAS)
    Для предсказания смертности при рваных ААА
    """
    
    def calculate(self, patient_data: Dict[str, Any]) -> Dict[str, Any]:
        """
        Расчет GAS score
        
        Параметры:
        - age: возраст
        - systolic_bp: систолическое АД
        - loss_of_consciousness: потеря сознания
        - hemoglobin: гемоглобин
        - creatinine: креатинин
        - ischemia_time: время ишемии
        """
        score = 0
        
        # Возраст
        age = patient_data.get("age", 65)
        if age > 76:
            score += 11
        elif age > 70:
            score += 7
        elif age > 64:
            score += 4
        elif age > 57:
            score += 2
        
        # Систолическое АД
        sbp = patient_data.get("systolic_bp", 120)
        if sbp < 70:
            score += 10
        elif sbp < 80:
            score += 7
        elif sbp < 90:
            score += 4
        elif sbp < 100:
            score += 2
        
        # Потеря сознания
        if patient_data.get("loss_of_consciousness", False):
            score += 8
        
        # Гемоглобин
        hgb = patient_data.get("hemoglobin", 12)
        if hgb < 7:
            score += 10
        elif hgb < 9:
            score += 7
        elif hgb < 11:
            score += 4
        elif hgb < 12:
            score += 2
        
        # Креатинин
        creat = patient_data.get("creatinine", 1.0)
        if creat > 2.5:
            score += 8
        elif creat > 2.0:
            score += 5
        elif creat > 1.5:
            score += 3
        elif creat > 1.2:
            score += 1
        
        # Время ишемии
        ischemia = patient_data.get("ischemia_time", 0)
        if ischemia > 120:
            score += 6
        elif ischemia > 60:
            score += 3
        
        # Интерпретация
        mortality = self._interpret_gas(score)
        
        return {
            "gas_score": score,
            "predicted_mortality": mortality,
            "risk_category": self._get_gas_category(score),
            "recommendations": self._get_gas_recommendations(score)
        }
    
    def _interpret_gas(self, score: int) -> Dict[str, float]:
        if score <= 10:
            return {"percentage": 10, "range": "5-15%"}
        elif score <= 20:
            return {"percentage": 25, "range": "15-35%"}
        elif score <= 30:
            return {"percentage": 50, "range": "35-65%"}
        elif score <= 40:
            return {"percentage": 75, "range": "65-85%"}
        else:
            return {"percentage": 90, "range": ">85%"}
    
    def _get_gas_category(self, score: int) -> str:
        if score <= 10:
            return "Низкий риск"
        elif score <= 20:
            return "Умеренный риск"
        elif score <= 30:
            return "Высокий риск"
        elif score <= 40:
            return "Очень высокий риск"
        else:
            return "Крайне высокий риск"
    
    def _get_gas_recommendations(self, score: int) -> List[str]:
        if score > 30:
            return [
                "Очень высокий риск - обсудить с семьей",
                "Рассмотреть EVAR при подходящей анатомии",
                "Максимальная поддержка в ИТО",
                "Подготовка к массивному переливанию"
            ]
        elif score > 20:
            return [
                "Высокий риск - тщательная оценка",
                "Предпочтительно EVAR",
                "ИТО после операции"
            ]
        return ["Стандартное ведение"]


class StrokeRiskCalculator:
    """
    Калькулятор риска инсульта при каротидной эндартерэктомии
    """
    
    def calculate(self, patient_data: Dict[str, Any]) -> Dict[str, Any]:
        """
        Расчет риска инсульта/смерти при КЭА
        """
        score = 0
        risk_factors = []
        
        # Возраст
        age = patient_data.get("age", 65)
        if age >= 75:
            score += 2
            risk_factors.append("Возраст ≥75 лет (+2)")
        
        # Пол
        if patient_data.get("gender") == "female":
            score += 1
            risk_factors.append("Женский пол (+1)")
        
        # Симптоматический стеноз
        if patient_data.get("symptomatic", False):
            score += 2
            risk_factors.append("Симптоматический стеноз (+2)")
        
        # ИБС
        if patient_data.get("cad", False):
            score += 1
            risk_factors.append("ИБС (+1)")
        
        # Диабет
        if patient_data.get("diabetes", False):
            score += 1
            risk_factors.append("Диабет (+1)")
        
        # ХПН
        if patient_data.get("renal_failure", False):
            score += 1
            risk_factors.append("ХПН (+1)")
        
        # Противопоказная сторона
        if patient_data.get("contralateral_occlusion", False):
            score += 2
            risk_factors.append("Окклюзия противоположной ОСА (+2)")
        
        # Расчет риска
        stroke_risk = self._calculate_stroke_risk(score)
        
        return {
            "score": score,
            "risk_factors": risk_factors,
            "stroke_death_risk": stroke_risk,
            "recommendations": self._get_stroke_recommendations(score)
        }
    
    def _calculate_stroke_risk(self, score: int) -> Dict[str, float]:
        risk_map = {
            0: {"percentage": 1.5, "range": "1-2%"},
            1: {"percentage": 2.0, "range": "1-3%"},
            2: {"percentage": 3.0, "range": "2-4%"},
            3: {"percentage": 4.5, "range": "3-6%"},
            4: {"percentage": 6.5, "range": "4-9%"},
            5: {"percentage": 9.0, "range": "6-12%"},
            6: {"percentage": 12.0, "range": "8-16%"},
        }
        
        if score >= 6:
            return {"percentage": 15.0, "range": ">12%"}
        
        return risk_map.get(score, {"percentage": 15.0, "range": ">12%"})
    
    def _get_stroke_recommendations(self, score: int) -> List[str]:
        if score >= 5:
            return [
                "Высокий риск инсульта - рассмотреть CAS",
                "Тщательный мониторинг внутриоперационный",
                "Рассмотреть шунтирование",
                "Транскраниальная допплерография"
            ]
        elif score >= 3:
            return [
                "Повышенный риск - усиленный мониторинг",
                "Рассмотреть локальную анестезию"
            ]
        return ["Стандартное ведение"]


class MajorAmputationRiskCalculator:
    """
    Калькулятор риска мажорной ампутации при критической ишемии
    """
    
    def calculate(self, patient_data: Dict[str, Any]) -> Dict[str, Any]:
        """
        Расчет риска ампутации
        """
        score = 0
        
        # Rutherford класс
        rutherford = patient_data.get("rutherford_class", 4)
        if rutherford >= 6:
            score += 4
        elif rutherford == 5:
            score += 2
        
        # Анемия
        if patient_data.get("anemia", False):
            score += 2
        
        # Гипоальбуминемия
        if patient_data.get("hypoalbuminemia", False):
            score += 2
        
        # Инфекция
        if patient_data.get("infection", False):
            score += 3
        
        # Невозможность реваскуляризации
        if patient_data.get("unreconstructible", False):
            score += 5
        
        # Диабет
        if patient_data.get("diabetes", False):
            score += 1
        
        # Диализ
        if patient_data.get("dialysis", False):
            score += 3
        
        amputation_risk = self._calculate_amputation_risk(score)
        
        return {
            "score": score,
            "amputation_risk": amputation_risk,
            "recommendations": self._get_amputation_recommendations(score, patient_data)
        }
    
    def _calculate_amputation_risk(self, score: int) -> Dict[str, Any]:
        if score <= 3:
            return {"percentage": 15, "range": "10-20%", "category": "Низкий"}
        elif score <= 6:
            return {"percentage": 35, "range": "25-45%", "category": "Умеренный"}
        elif score <= 9:
            return {"percentage": 60, "range": "50-70%", "category": "Высокий"}
        else:
            return {"percentage": 85, "range": ">75%", "category": "Очень высокий"}
    
    def _get_amputation_recommendations(self, score: int, data: Dict) -> List[str]:
        recs = []
        
        if data.get("unreconstructible", False):
            recs.append("Первичная ампутация может быть оптимальным выбором")
        
        if score >= 6:
            recs.append("Высокий риск ампутации - агрессивная реваскуляризация")
            recs.append("Рассмотреть спинальную стимуляцию")
        
        if data.get("infection", False):
            recs.append("Контроль инфекции обязателен")
        
        return recs


# ==================== УПРАВЛЕНИЕ АНТИКОАГУЛЯНТАМИ ====================

ANTICOAGULATION_PROTOCOLS = {
    "warfarin": {
        "name": "Варфарин",
        "preop_management": {
            "timing_stop": "За 5 дней до операции",
            "target_inr": "<1.5 на момент операции",
            "bridge_therapy": {
                "indicated": True,
                "start": "За 2 дня до операции (когда МНО <2.0)",
                "agent": "Низкомолекулярный гепарин (НМГ)",
                "dose": "Терапевтическая доза",
                "last_dose": "За 12-24 часа до операции"
            },
            "postop_restart": {
                "warfarin": "Через 12-24 часа после операции",
                "heparin": "Продолжать до достижения целевого МНО",
                "target_inr": "2.0-3.0 (обычно) или 2.5-3.5 (механические клапаны)"
            }
        },
        "high_bleeding_risk_procedures": [
            "Нейрохирургия",
            "Офтальмологическая хирургия",
            "Спинальная/эпидуральная анестезия"
        ]
    },
    
    "noacs": {
        "name": "Новые оральные антикоагулянты (НОАК)",
        "agents": {
            "dabigatran": {
                "name": "Дабигатран (Прадакса)",
                "renal_clearance": 80,
                "stop_crcl_more_50": "За 48 часов",
                "stop_crcl_30_50": "За 96 часов",
                "stop_crcl_less_30": "За 120 часов",
                "restart": "Через 48-72 часа после операции (при гемостазе)"
            },
            "rivaroxaban": {
                "name": "Ривароксабан (Ксарелто)",
                "renal_clearance": 33,
                "stop_crcl_more_30": "За 48 часов",
                "stop_crcl_less_30": "За 72 часа",
                "restart": "Через 48-72 часа после операции"
            },
            "apixaban": {
                "name": "Апиксабан (Элиquis)",
                "renal_clearance": 27,
                "stop": "За 48 часов",
                "restart": "Через 48-72 часа после операции"
            },
            "edoxaban": {
                "name": "Эдоксабан (Ликвиус)",
                "renal_clearance": 50,
                "stop_crcl_more_50": "За 48 часов",
                "stop_crcl_30_50": "За 72 часа",
                "restart": "Через 48-72 часа после операции"
            }
        },
        "general_rules": {
            "low_bleeding_risk": "Можно продолжить или прервать за 24-48 часов",
            "high_bleeding_risk": "Прервать за 48 часов (или более при сниженной КФ)",
            "emergency": "Использовать андексанет альфа (для фактора Xa) или идаруцизумаб (для дабигатрана)"
        }
    },
    
    "antiplatelet": {
        "name": "Антиагреганты",
        "aspirin": {
            "continue": True,
            "note": "Продолжать в большинстве случаев",
            "exceptions": ["Внутриглазная хирургия", "Трансплантация простаты"]
        },
        "clopidogrel": {
            "stop": "За 5 дней до операции",
            "restart": "Через 24 часа после операции (при гемостазе)",
            "note": "При высоком риске тромбоза - обсудить с кардиологом"
        },
        "dual_antiplatelet": {
            "carotid_stenting": "Продолжать минимум 1 месяц",
            "coronary_stent": {
                "bare_metal": "Минимум 1 месяц",
                "drug_eluting": "Минимум 6-12 месяцев",
                "note": "Отсрочить операцию если возможно"
            }
        }
    }
}


def get_anticoagulation_protocol(
    agent: str,
    procedure_bleeding_risk: str = "moderate",
    creatinine_clearance: Optional[float] = None,
    urgency: str = "elective"
) -> Dict[str, Any]:
    """
    Получение протокола управления антикоагулянтами
    
    Параметры:
    - agent: варфарин, дабигатран, ривароксабан, апиксабан, эдоксабан, аспирин, клопидогрель
    - procedure_bleeding_risk: low, moderate, high
    - creatinine_clearance: для дозировки НОАК
    - urgency: elective, urgent, emergency
    """
    
    if urgency == "emergency":
        return {
            "urgency": "emergency",
            "recommendation": "Экстренная операция",
            "actions": [
                "Противозудные препараты (андексанет, идаруцизумаб при НОАК)",
                "Свежезамороженная плазма + витамин К (при варфарине)",
                "Транексамовая кислота",
                "Массивное переливание при необходимости"
            ],
            "note": "Консультация гематолога"
        }
    
    agent_lower = agent.lower()
    
    if "варфарин" in agent_lower or "warfarin" in agent_lower:
        protocol = ANTICOAGULATION_PROTOCOLS["warfarin"].copy()
        if procedure_bleeding_risk == "high":
            protocol["special_precautions"] = [
                "Тщательный гемостаз",
                "Минимальная инвазивность",
                "Рассмотреть отсрочку операции"
            ]
        return protocol
    
    if agent_lower in ["дабигатран", "dabigatran", "прадакса"]:
        noac_data = ANTICOAGULATION_PROTOCOLS["noacs"]["agents"]["dabigatran"]
        stop_time = noac_data["stop_crcl_more_50"]
        if creatinine_clearance:
            if creatinine_clearance < 30:
                stop_time = noac_data["stop_crcl_less_30"]
            elif creatinine_clearance < 50:
                stop_time = noac_data["stop_crcl_30_50"]
        
        return {
            "agent": "Дабигатран",
            "stop_before_surgery": stop_time,
            "restart_after_surgery": noac_data["restart"],
            "note": "Высокая почечная экскреция (80%) - учитывать КФ"
        }
    
    if agent_lower in ["ривароксабан", "rivaroxaban", "ксарелто"]:
        noac_data = ANTICOAGULATION_PROTOCOLS["noacs"]["agents"]["rivaroxaban"]
        stop_time = noac_data["stop_crcl_more_30"]
        if creatinine_clearance and creatinine_clearance < 30:
            stop_time = noac_data["stop_crcl_less_30"]
        
        return {
            "agent": "Ривароксабан",
            "stop_before_surgery": stop_time,
            "restart_after_surgery": noac_data["restart"]
        }
    
    if agent_lower in ["апиксабан", "apixaban", "элиquis"]:
        noac_data = ANTICOAGULATION_PROTOCOLS["noacs"]["agents"]["apixaban"]
        return {
            "agent": "Апиксабан",
            "stop_before_surgery": noac_data["stop"],
            "restart_after_surgery": noac_data["restart"],
            "note": "Наиболее безопасный НОАК при сниженной КФ"
        }
    
    if agent_lower in ["аспирин", "aspirin", "кардиомагнил"]:
        return ANTICOAGULATION_PROTOCOLS["antiplatelet"]["aspirin"]
    
    if agent_lower in ["клопидогрель", "clopidogrel", "плавикс"]:
        return ANTICOAGULATION_PROTOCOLS["antiplatelet"]["clopidogrel"]
    
    return {"error": "Unknown agent"}


# ==================== АЛГОРИТМЫ ДЕЙСТВИЙ ПРИ ОСЛОЖНЕНИЯХ ====================

COMPLICATION_ALGORITHMS = {
    "endoleak": {
        "name": "Endoleak после EVAR",
        "types": {
            "type_1": {
                "name": "Type I (проксимальный/дистальный)",
                "description": "Неплотное прилегание стент-графта",
                "significance": "Высокий риск разрыва - требует коррекции",
                "management": {
                    "immediate": "Расширение стент-графта (cuff) или конверсия в открытую операцию",
                    "monitoring": "КТ-ангиография через 1 месяц",
                    "follow_up": "Каждые 6 месяцев"
                }
            },
            "type_2": {
                "name": "Type II (обратный кровоток)",
                "description": "Питание от боковых ветвей (Lumbar, IMA)",
                "significance": "Часто бессимптомный, может регрессировать",
                "management": {
                    "conservative": "Наблюдение если <2 см и не растет",
                    "intervention": "Эмболизация при росте >5 мм или >2 см",
                    "techniques": ["Транслюмбарная эмболизация", "Трансартериальная эмболизация"]
                }
            },
            "type_3": {
                "name": "Type III (модульная утечка)",
                "description": "Нарушение соединения компонентов",
                "significance": "Высокий риск разрыва - требует коррекции",
                "management": {
                    "immediate": "Имплантация дополнительного стент-графта",
                    "alternative": "Конверсия в открытую операцию"
                }
            },
            "type_4": {
                "name": "Type IV (пористость материала)",
                "description": "Утечка через поры материала",
                "significance": "Обычно самоограничивается",
                "management": {
                    "conservative": "Наблюдение",
                    "note": "Редко требует вмешательства"
                }
            },
            "type_5": {
                "name": "Type V ( endotension )",
                "description": "Рост аневризмы без видимой утечки",
                "significance": "Требует обследования",
                "management": {
                    "workup": "Повторная КТ-ангиография, МР-ангиография",
                    "consider": "Конверсия в открытую операцию при росте"
                }
            }
        },
        "surveillance": {
            "schedule": [
                {"time": "1 месяц", "imaging": "КТ-ангиография"},
                {"time": "6 месяцев", "imaging": "КТ-ангиография"},
                {"time": "12 месяцев", "imaging": "КТ-ангиография"},
                {"time": "Ежегодно", "imaging": "КТ-ангиография или УЗИ"}
            ]
        }
    },
    
    "graft_thrombosis": {
        "name": "Тромбоз шунта/протеза",
        "acute": {
            "presentation": ["Внезапная боль", "Холодность", "Бледность", "Пульсация отсутствует"],
            "immediate_actions": [
                "Гепарин 5000 ЕД в/в",
                "УЗИ для подтверждения",
                "Подготовка к операции"
            ],
            "treatment_options": {
                "thrombectomy": {
                    "indications": "Острый тромбоз <14 дней",
                    "technique": "Тромбэктомия Фогарти + ангиография",
                    "success_rate": "70-80%"
                },
                "thrombolysis": {
                    "indications": "Острый тромбоз, хороший отток",
                    "contraindications": ["Недавнее кровотечение", "Инсульт <3 мес"],
                    "agents": ["Алтеплаза", "Урокиназа"]
                },
                "surgical_revision": {
                    "indications": "Хронический тромбоз, рецидив",
                    "options": ["Тромбэктомия + заплатка", "Новый шунт"]
                }
            },
            "prevention": {
                "anticoagulation": "Варфарин (МНО 2.0-3.0) или НОАК",
                "antiplatelet": "Аспирин 75-100 мг",
                "surveillance": "УЗИ каждые 3-6 месяцев"
            }
        },
        "chronic": {
            "presentation": ["Прогрессирующая клаудикация", "Уменьшение АКШ"],
            "evaluation": ["УЗИ с давлением", "КТ-ангиография", "Ангиография"],
            "treatment": {
                "endovascular": "Ангиопластика ± стентирование",
                "surgical": "Ревизия шунта или новый шунт"
            }
        }
    },
    
    "graft_infection": {
        "name": "Инфекция протеза/шунта",
        "signs": ["Лихорадка", "Боль в области шунта", "Эритема", "Гнойное отделяемое", "Псевдоаневризма"],
        "diagnosis": {
            "laboratory": ["Лейкоцитоз", "Повышенная СОЭ", "Повышенный СРБ", "Положительные гемокультуры"],
            "imaging": ["КТ с контрастом", "ПЭТ-КТ", "Меченые лейкоциты"],
            "note": "Staphylococcus aureus - наиболее частый возбудитель"
        },
        "treatment": {
            "principles": [
                "Полное удаление инфицированного протеза",
                "Длительная антибиотикотерапия (6-12 недель)",
                "Экстраанатомическое шунтирование (при необходимости)"
            ],
            "antibiotics": {
                "empiric": "Ванкомицин + Цефепим/Пиперациллин",
                "targeted": "По чувствительности",
                "duration": "6-12 недель парентерально"
            },
            "surgical_options": {
                "complete_excision": "Полное удаление протеза",
                "extra_anatomic_bypass": "Аксилло-бедренное шунтирование",
                "in_situ_graft": "Замена на новый протез (с риском реинфекции)"
            }
        },
        "prognosis": "Летальность 10-40%"
    },
    
    "lymphatic_fistula": {
        "name": "Лимфная фистула",
        "presentation": ["Молочное отделяемое из раны", "Продолжительное дренирование"],
        "prevention": [
            "Тщательная лигатура лимфатических сосудов",
            "Использование электрокоагуляции",
            "Фибриновый клей (при необходимости)"
        ],
        "treatment": {
            "conservative": [
                "Низкожировая диета (<15 г/сут)",
                "Среднецепочечные триглицериды",
                "Октреотид (соматостатин) 100 мкг 3р/сут",
                "Компрессия"
            ],
            "surgical": [
                "Повторная операция при >500 мл/сут >1 недели",
                "Лигатура лимфатических сосудов",
                "Мускульный лоскут"
            ]
        }
    },
    
    "compartment_syndrome": {
        "name": "Синдром компартмент-синдрома",
        "causes": ["Реперфузия после длительной ишемии", "Травма", "Тромбоз"],
        "signs": [
            "Боль (несоответствующая травме)",
            "Боль при пассивном растяжении",
            "Парестезии",
            "Паралич (поздний признак)",
            "Пульсация сохранена (рано)"
        ],
        "diagnosis": {
            "clinical": "6 P: Pain, Pallor, Pulselessness, Paresthesia, Paralysis, Poikilothermia",
            "measurement": "Давление в компартменте >30 мм рт.ст. (или Δ <30 мм рт.ст. от диастолического)",
            "note": "Не ждать всех признаков!"
        },
        "treatment": {
            "immediate": "Экстренная фасциотомия",
            "timing": "В течение 6 часов от начала",
            "technique": "Двухсторонняя фасциотомия голени",
            "wound_care": "Открытая рана, повязки с вакуумом"
        },
        "prognosis": "При задержке >8 часов - высокий риск ампутации"
    }
}


# ==================== КРИТЕРИИ СРОЧНОСТИ ОПЕРАЦИИ ====================

URGENCY_CRITERIA = {
    "emergency": {
        "name": "Экстренная операция (<2 часов)",
        "conditions": [
            {
                "condition": "Разрыв аневризмы аорты",
                "signs": ["Боль в животе/спине", "Гипотензия", "Синкопе", "Пульсирующая масса"],
                "mortality_without_surgery": "80-90%",
                "mortality_with_surgery": "30-50%"
            },
            {
                "condition": "Острое расслоение аорты типа А",
                "signs": ["Резкая боль в груди", "Разница АД на руках", "Неврологические симптомы"],
                "mortality": "1-2% в час без операции"
            },
            {
                "condition": "Острая ишемия конечности",
                "signs": ["6 P", "<6 часов от начала"],
                "note": "Золотое время - 6 часов"
            },
            {
                "condition": "Флегмазия",
                "signs": ["Массивный отек", "Цианоз", "Боль", "Тяжелый ТГВ"],
                "treatment": "Тромбэктомия или тромболиз"
            },
            {
                "condition": "Травматическое повреждение крупных сосудов",
                "signs": ["Массивное кровотечение", "Расширяющаяся гематома", "Ишемия"]
            }
        ],
        "preparation": [
            "Быстрая типизация крови и перекрестная проба",
            "Активация массивного переливания",
            "Информированное согласие (устное при необходимости)",
            "Уведомление анестезиолога и ИТО"
        ]
    },
    
    "urgent": {
        "name": "Срочная операция (<24 часов)",
        "conditions": [
            {
                "condition": "Симптоматическая аневризма (без разрыва)",
                "signs": ["Боль", "Тяжесть", "Дискомфорт"]
            },
            {
                "condition": "Симптоматический стеноз сонной артерии",
                "signs": ["ТИА", "Амавроз", "Небольшой инсульт"]
            },
            {
                "condition": "Критическая ишемия нижних конечностей (Rutherford 5-6)",
                "signs": ["Покойная боль", "Трофические язвы", "Гангрена"]
            },
            {
                "condition": "Острый ТГВ с риском ТЭЛА",
                "signs": ["Подвздошный/бедренный ТГВ", "Плавающий тромб"]
            },
            {
                "condition": "Инфекция протеза",
                "signs": ["Лихорадка", "Боль", "Гной"]
            }
        ]
    },
    
    "elective": {
        "name": "Плановая операция",
        "conditions": [
            "Асимптоматическая ААА >55 мм (мужчины) или >50 мм (женщины)",
            "Асимптоматический стеноз сонной артерии >60%",
            "Клаудикация при ходьбе",
            "Варикозная болезнь C2-C6",
            "АВ-фистула для диализа"
        ],
        "optimization_time": "1-4 недели для предоперационной подготовки"
    }
}


# ==================== ЛАБОРАТОРНЫЕ КРИТЕРИИ ====================

LABORATORY_THRESHOLDS = {
    "preoperative": {
        "hemoglobin": {
            "normal": ">12 г/дл (женщины), >13 г/дл (мужчины)",
            "mild_anemia": "10-12 г/дл",
            "moderate_anemia": "8-10 г/дл",
            "severe_anemia": "<8 г/дл",
            "action": {
                "mild": "Продолжить, учитывать риск трансфузии",
                "moderate": "Рассмотреть коррекцию перед операцией",
                "severe": "Отложить операцию, трансфузия"
            }
        },
        "platelets": {
            "normal": ">150,000/мкл",
            "mild_thrombocytopenia": "100,000-150,000/мкл",
            "moderate": "50,000-100,000/мкл",
            "severe": "<50,000/мкл",
            "action": {
                "mild": "Продолжить",
                "moderate": "Консультация гематолога",
                "severe": "Тромбоцитарная масса, отсрочка"
            }
        },
        "inr": {
            "normal": "0.8-1.2",
            "elevated": "1.2-1.5",
            "high": ">1.5",
            "action": {
                "elevated": "Витамин К 10 мг в/в (при варфарине)",
                "high": "Свежезамороженная плазма, отсрочка"
            }
        },
        "creatinine": {
            "normal": "<1.2 мг/дл",
            "elevated": "1.2-2.0 мг/дл",
            "high": ">2.0 мг/дл",
            "action": {
                "elevated": "Гидратация, минимизация контраста",
                "high": "Консультация нефролога, отсрочка при возможности"
            }
        },
        "glucose": {
            "target": "80-180 мг/дл",
            "action": "Коррекция инсулином перед операцией"
        }
    },
    
    "postoperative": {
        "hemoglobin_drop": {
            "expected": "<2 г/дл",
            "concerning": "2-4 г/дл",
            "critical": ">4 г/дл",
            "action": {
                "concerning": "Мониторинг, поиск источника",
                "critical": "Трансфузия, экстренное обследование"
            }
        },
        "creatinine_rise": {
            "expected": "<0.3 мг/дл",
            "aki_stage_1": "0.3-0.5 мг/дл или 1.5-2x базовый",
            "aki_stage_2": ">0.5 мг/дл или 2-3x базовый",
            "aki_stage_3": ">3x базовый или >4 мг/дл",
            "action": {
                "stage_1": "Гидратация, отмена нефротоксинов",
                "stage_2": "Консультация нефролога",
                "stage_3": "ИТО, возможен диализ"
            }
        },
        "lactate": {
            "normal": "<2 ммоль/л",
            "elevated": "2-4 ммоль/л",
            "high": ">4 ммоль/л",
            "action": {
                "elevated": "Увеличение перфузии",
                "high": "ИТО, поиск источника ишемии"
            }
        }
    }
}


def check_laboratory_readiness(labs: Dict[str, float], urgency: str = "elective") -> Dict[str, Any]:
    """
    Проверка готовности к операции на основе лабораторных данных
    
    Параметры:
    - labs: словарь с лабораторными значениями
    - urgency: срочность операции
    """
    warnings = []
    contraindications = []
    recommendations = []
    
    # Гемоглобин
    hgb = labs.get("hemoglobin", 12)
    if hgb < 8:
        contraindications.append(f"Тяжелая анемия (Hb {hgb} г/дл) - требуется трансфузия")
    elif hgb < 10:
        warnings.append(f"Умеренная анемия (Hb {hgb} г/дл) - подготовить кровь")
    
    # Тромбоциты
    plt = labs.get("platelets", 150000)
    if plt < 50000:
        contraindications.append(f"Тяжелая тромбоцитопения ({plt}/мкл)")
    elif plt < 100000:
        warnings.append(f"Тромбоцитопения ({plt}/мкл) - консультация гематолога")
    
    # МНО
    inr = labs.get("inr", 1.0)
    if inr > 1.5 and urgency == "elective":
        warnings.append(f"Повышенный МНО ({inr}) - коррекция")
    elif inr > 2.0:
        contraindications.append(f"Высокий МНО ({inr}) - требуется коррекция")
    
    # Креатинин
    cr = labs.get("creatinine", 1.0)
    if cr > 3.0:
        warnings.append(f"Высокий креатинин ({cr} мг/дл) - консультация нефролога")
    
    # Глюкоза
    glucose = labs.get("glucose", 100)
    if glucose > 250:
        warnings.append(f"Гипергликемия ({glucose} мг/дл) - коррекция перед операцией")
    elif glucose < 70:
        contraindications.append(f"Гипогликемия ({glucose} мг/дл) - требуется коррекция")
    
    ready = len(contraindications) == 0
    
    return {
        "ready_for_surgery": ready,
        "urgency": urgency,
        "warnings": warnings,
        "contraindications": contraindications,
        "recommendations": recommendations,
        "proceed": ready or urgency in ["urgent", "emergency"]
    }


# ==================== ПОСЛЕОПЕРАТИВНЫЕ ПРОТОКОЛЫ ====================

POSTOPERATIVE_PROTOCOLS = {
    "evar_surveillance": {
        "name": "Наблюдение после EVAR",
        "schedule": [
            {"time": "1 месяц", "imaging": "КТ-ангиография", "focus": "Позиция стент-графта, endoleak"},
            {"time": "6 месяцев", "imaging": "КТ-ангиография", "focus": "Стабильность, endoleak"},
            {"time": "12 месяцев", "imaging": "КТ-ангиография", "focus": "Стабильность"},
            {"time": "Ежегодно", "imaging": "КТ-ангиография или УЗИ", "focus": "Долгосрочная стабильность"}
        ],
        "red_flags": [
            "Рост аневризмы >5 мм",
            "Новый endoleak",
            "Миграция стент-графта",
            "Type I или III endoleak"
        ],
        "actions_on_red_flags": [
            "Немедленная КТ-ангиография",
            "Консультация эндоваскулярного хирурга",
            "Рассмотреть реинтервенцию"
        ]
    },
    
    "open_aaa_surveillance": {
        "name": "Наблюдение после открытой операции на ААА",
        "schedule": [
            {"time": "1 месяц", "imaging": "УЗИ", "focus": "Анастомозы"},
            {"time": "6 месяцев", "imaging": "УЗИ или КТ", "focus": "Протез"},
            {"time": "12 месяцев", "imaging": "КТ-ангиография", "focus": "Полная оценка"},
            {"time": "Ежегодно", "imaging": "УЗИ", "focus": "Долгосрочное наблюдение"}
        ],
        "red_flags": [
            "Анастомотическая аневризма",
            "Расширение протеза",
            "Тромбоз"
        ]
    },
    
    "carotid_surveillance": {
        "name": "Наблюдение после КЭА",
        "schedule": [
            {"time": "1 месяц", "imaging": "УЗДГ", "focus": "Анастомоз, рестеноз"},
            {"time": "6 месяцев", "imaging": "УЗДГ", "focus": "Патентность"},
            {"time": "12 месяцев", "imaging": "УЗДГ", "focus": "Патентность"},
            {"time": "Ежегодно", "imaging": "УЗДГ", "focus": "Долгосрочная патентность"}
        ],
        "restenosis_threshold": ">70% - рассмотреть повторное вмешательство"
    },
    
    "bypass_surveillance": {
        "name": "Наблюдение после шунтирования",
        "schedule": [
            {"time": "1 месяц", "imaging": "УЗИ", "focus": "Патентность"},
            {"time": "3 месяца", "imaging": "УЗИ", "focus": "Патентность"},
            {"time": "6 месяцев", "imaging": "УЗИ", "focus": "Патентность"},
            {"time": "Ежегодно", "imaging": "УЗИ", "focus": "Долгосрочная патентность"}
        ],
        "red_flags": [
            "Снижение АКШ >0.15",
            "Новая клаудикация",
            "Изменение пульсации"
        ],
        "surveillance_velocity": {
            "normal": "<125 см/с",
            "elevated": "125-200 см/с - наблюдение",
            "high": ">200 см/с или рестеноз >50% - ангиография"
        }
    },
    
    "drain_management": {
        "name": "Управление дренажами",
        "removal_criteria": {
            "serous": "<50 мл/сут в течение 24 часов",
            "sanguineous": "<100 мл/сут в течение 24 часов",
            "chylous": "<200 мл/сут в течение 48 часов + низкожировая диета"
        },
        "red_flags": [
            "Внезапное увеличение отделяемого",
            "Гнойное отделяемое",
            "Кровотечение >200 мл/час"
        ]
    },
    
    "anticoagulation_postop": {
        "name": "Антикоагуляция после операции",
        "timing": {
            "prophylactic_heparin": "Через 6-12 часов после операции (при гемостазе)",
            "therapeutic_heparin": "Через 24-48 часов после операции",
            "warfarin": "Через 12-24 часа после операции",
            "noacs": "Через 48-72 часа после операции"
        },
        "contraindications": [
            "Активное кровотечение",
            "Тромбоциты <50,000",
            "МНО >1.5 (при варфарине)"
        ]
    }
}


# ==================== ФУНКЦИИ ДЛЯ API ====================

def get_risk_calculator(calculator_type: str):
    """Получение калькулятора риска"""
    calculators = {
        "vsgne": VSGNECalculator(),
        "gas": GASCalculator(),
        "stroke": StrokeRiskCalculator(),
        "amputation": MajorAmputationRiskCalculator()
    }
    return calculators.get(calculator_type)


def get_complication_algorithm(complication_type: str) -> Dict[str, Any]:
    """Получение алгоритма действий при осложнении"""
    return COMPLICATION_ALGORITHMS.get(complication_type, {})


def get_urgency_criteria(urgency_level: str) -> Dict[str, Any]:
    """Получение критериев срочности"""
    return URGENCY_CRITERIA.get(urgency_level, {})


def get_postoperative_protocol(protocol_type: str) -> Dict[str, Any]:
    """Получение послеоперационного протокола"""
    return POSTOPERATIVE_PROTOCOLS.get(protocol_type, {})
