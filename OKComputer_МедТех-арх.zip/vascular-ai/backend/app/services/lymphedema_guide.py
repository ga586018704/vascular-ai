"""
VASCULAR.AI - Руководство по лимфедеме
На основе:
- Lymphedema: A Concise Compendium (Lee, Bergan, Rockson) - Springer
- Lymphedema Management (Zuther, Norton) - 4th Edition
- Developmental Aspects of Lymphatic Vascular System (Kiefer)
- Лимфедема (Бордаков, Деркачев, Левченко) - БГМУ
"""

from typing import Dict, Any, List, Optional


# ==================== КЛАССИФИКАЦИЯ ЛИМФЕДЕМЫ ====================

LYMPHEDEMA_CLASSIFICATION = {
    "primary": {
        "name": "Первичная лимфедема",
        "definition": "Врожденная аномалия лимфатической системы",
        "types": {
            "congenital": {
                "name": "Конгенитальная (Milroy disease)",
                "onset": "При рождении",
                "incidence": "1:6000-10000",
                "genetics": "VEGFR3 mutation",
                "features": ["Билатеральная", "Нижние конечности"]
            },
            "praecox": {
                "name": "Лимфедема praecox (Meige disease)",
                "onset": "Пubertas (8-25 лет)",
                "incidence": "1:100000",
                "features": ["Чаще женщины", "Односторонняя", "Нижние конечности"]
            },
            "tarda": {
                "name": "Лимфедема tarda",
                "onset": ">35 лет",
                "features": ["Триггеры: травма, инфекция", "Может быть первым признаком"]
            }
        },
        "genetic_mutations": {
            "Milroy": "FLT4/VEGFR3",
            "Meige": "FOXC2",
            "Distichiasis": "FOXC2",
            "Hypotrichosis-lymphedema-telangiectasia": "SOX18"
        }
    },
    
    "secondary": {
        "name": "Вторичная лимфедема",
        "definition": "Приобретенное повреждение лимфатической системы",
        "causes": {
            "surgical": {
                "name": "Хирургическая",
                "procedures": [
                    "Лимфаденэктомия",
                    "Радикальная мастэктомия",
                    "Радикальная простатэктомия",
                    "Радикальная гистерэктомия",
                    "Шунтирование аорто-подвздошное"
                ],
                "incidence": "10-40% после лимфаденэктомии"
            },
            "radiation": {
                "name": "Лучевая терапия",
                "mechanism": "Фиброз лимфатических сосудов",
                "latency": "Месяцы-годы после облучения"
            },
            "infectious": {
                "name": "Инфекционная",
                "filariasis": {
                    "name": "Филяриатоз (элефантиаз)",
                    "prevalence": "120 млн человек",
                    "regions": "Тропические районы"
                },
                "cellulitis": {
                    "name": "Рецидивирующий целлюлит",
                    "mechanism": "Разрушение лимфатических капилляров"
                }
            },
            "traumatic": {
                "name": "Травматическая",
                "causes": ["Переломы", "Ожоги", "Хирургические рубцы"]
            },
            "malignant": {
                "name": "Опухолевая",
                "mechanism": "Обструкция лимфатических путей",
                "cancers": ["Меланома", "Гинекологические", "Генитуринарные"]
            },
            "venous": {
                "name": "Венозная гипертензия",
                "mechanism": "Повышенное давление → лимфатическая недостаточность",
                "conditions": ["Посттромботический синдром", "ХВН C4-C6"]
            }
        }
    }
}


# ==================== СТАДИИ ЛИМФЕДЕМЫ (ISL Staging) ====================

ISL_STAGING = {
    "stage_0": {
        "name": "Субклиническая (латентная)",
        "description": "Нормальная конечность, нарушена лимфатическая функция",
        "signs": "Нет видимых признаков",
        "diagnosis": "Лимфосцинтиграфия показывает задержку",
        "management": "Профилактика, наблюдение"
    },
    
    "stage_1": {
        "name": "Ранняя (спонтанно обратимая)",
        "description": "Отек, который уменьшается при поднятии конечности",
        "signs": ["Мягкий отек", "Улучшение ночью", "Нет кожных изменений"],
        "pitting": "Present (пальпационная ямка)",
        "management": "Компрессия, MLD, упражнения"
    },
    
    "stage_2": {
        "name": "Средняя (спонтанно необратимая)",
        "description": "Отек не уменьшается при поднятии",
        "subtypes": {
            "2a": {
                "description": "Мягкие ткани без фиброза",
                "signs": ["Уплотнение", "Небольшой фиброз"]
            },
            "2b": {
                "description": "Выраженный фиброз",
                "signs": ["Твердый отек", "Липоматоз", "Кожные складки"]
            }
        },
        "pitting": "May be absent",
        "management": "CDT (Complete Decongestive Therapy)"
    },
    
    "stage_3": {
        "name": "Поздняя (липодерматосклероз/элефантиаз)",
        "description": "Тяжелые необратимые изменения",
        "signs": [
            "Выраженный фиброз",
            "Липоматоз",
            "Папилломатоз",
            "Кожные складки",
            "Возможны трофические язвы"
        ],
        "pitting": "Absent",
        "management": "CDT + хирургическая редукция при необходимости"
    }
}


# ==================== ДИАГНОСТИКА ====================

LYMPHEDEMA_DIAGNOSIS = {
    "clinical_assessment": {
        "history": [
            "Время начала",
            "Прогрессия",
            "Триггеры (травма, инфекция, хирургия)",
            "Семейный анамнез",
            "Путешествия в эндемичные районы"
        ],
        "physical_exam": [
            "Объем конечности (окружность в 10 точках)",
            "Stemmer sign (невозможность поднять кожу на основании пальцев)",
            "Кожные изменения",
            "Пальпация лимфоузлов"
        ]
    },
    
    "imaging": {
        "lymphoscintigraphy": {
            "name": "Лимфосцинтиграфия",
            "gold_standard": True,
            "findings": [
                "Задержка транспорта",
                "Дермальный backflow",
                "Отсутствие лимфатических узлов",
                "Коллатеральное распределение"
            ]
        },
        "mri": {
            "name": "МРТ",
            "findings": [
                "Honeycomb pattern (подкожная клетчатка)",
                "Утолщение кожи",
                "Липоматоз"
            ]
        },
        "ct": {
            "name": "КТ",
            "use": "Исключить другие причины отека"
        },
        "ultrasound": {
            "name": "УЗИ",
            "use": "Оценить венозный компонент"
        },
        "icg_lymphography": {
            "name": "ИКГ-лимфография",
            "use": "Визуализация лимфатических сосудов",
            "patterns": [
                "Splash (норма)",
                "Stardust (ранняя лимфедема)",
                "Diffuse (тяжелая лимфедема)"
            ]
        }
    },
    
    "biomarkers": {
        "note": "В разработке",
        "potential": ["Гиалуронан", "VEGF-C", "D-dimer"]
    }
}


# ==================== ЛЕЧЕНИЕ ====================

LYMPHEDEMA_TREATMENT = {
    "conservative": {
        "cdt": {
            "name": "Complete Decongestive Therapy (CDT)",
            "components": {
                "mlb": {
                    "name": "Manual Lymphatic Drainage (MLD)",
                    "description": "Специальный массаж для активации лимфатического тока",
                    "frequency": "Ежедневно в фазе деконгестии",
                    "technique": "Vodder, Leduc, Casley-Smith, Földi"
                },
                "compression": {
                    "name": "Многослойная компрессия",
                    "phase_1": {
                        "name": "Фаза деконгестии",
                        "bandaging": "Короткие растягивающиеся бинты",
                        "frequency": "Ежедневно",
                        "duration": "2-4 недели"
                    },
                    "phase_2": {
                        "name": "Фаза поддержания",
                        "garments": "Компрессионный трикотаж (20-30, 30-40, 40-50 мм рт.ст.)",
                        "daytime": "Обязательно",
                        "nighttime": "При необходимости"
                    }
                },
                "exercise": {
                    "name": "Лечебная физкультура",
                    "description": "Упражнения с компрессией",
                    "types": ["Аэробные", "Силовые", "Растяжка"]
                },
                "skin_care": {
                    "name": "Уход за кожей",
                    "importance": "Критически важен для предотвращения инфекции",
                    "measures": [
                        "Ежедневное увлажнение",
                        "pH-neutral мыло",
                        "Защита от травм",
                        "Немедленная обработка ран"
                    ]
                }
            }
        },
        
        "ipc": {
            "name": "Intermittent Pneumatic Compression (IPC)",
            "indications": [
                "Дополнение к CDT",
                "Невозможность MLD",
                "Домашнее использование"
            ],
            "contraindications": [
                "Острый тромбоз",
                "Нелеченая инфекция",
                "Сердечная недостаточность",
                "Злокачественная опухоль"
            ],
            "settings": "40-50 мм рт.ст., 30-60 минут"
        }
    },
    
    "surgical": {
        "excisional": {
            "name": "Эксизионная/редуктивная хирургия",
            "procedures": {
                "charles_procedure": {
                    "name": "Операция Charles",
                    "description": "Радикальное удаление кожи и подкожной клетчатки",
                    "indication": "Тяжелый элефантиаз",
                    "complications": "Высокий риск"
                },
                "sistrunk_operation": {
                    "name": "Операция Sistrunk",
                    "description": "Удаление избыточной кожи и липоматозной ткани"
                },
                "homans_procedure": {
                    "name": "Операция Homans",
                    "description": "Удаление подкожной клетчатки с сохранением кожи"
                }
            }
        },
        
        "reconstructive": {
            "name": "Реконструктивная хирургия",
            "procedures": {
                "vlnt": {
                    "name": "Vascularized Lymph Node Transfer (VLNT)",
                    "description": "Трансплантация лимфатических узлов",
                    "donor_sites": ["Подмышечная область", "Бедренная область", "Брыжеечная область"],
                    "mechanism": "Приток лимфы к трансплантированным узлам"
                },
                "lymphaticovenous_anastomosis": {
                    "name": "Лимфатиковеноанастомоз (LVA)",
                    "description": "Анастомоз лимфатических сосудов с венами",
                    "technique": "Микрохирургия",
                    "best_results": "Ранняя стадия (ISL I-II)"
                },
                "lymphatic_bypass": {
                    "name": "Лимфатический бypass",
                    "description": "Перенаправление лимфатического тока"
                }
            }
        },
        
        "liposuction": {
            "name": "Липосакция (Suction-Assisted Protein Lipectomy)",
            "indication": "Липоматозный компонент",
            "note": "Требует пожизненной компрессии после операции"
        }
    }
}


# ==================== ОСЛОЖНЕНИЯ ====================

LYMPHEDEMA_COMPLICATIONS = {
    "cellulitis": {
        "name": "Целлюлит/лимфангит",
        "incidence": "20-30% пациентов в год",
        "signs": ["Покраснение", "Боль", "Лихорадка", "Увеличение отека"],
        "treatment": {
            "antibiotics": [
                "Амоксициллин/клавуланат 875/125 мг 2x/день",
                "Цефалексин 500 мг 4x/день",
                "Клиндамицин 300 мг 4x/день (при аллергии на пенициллин)"
            ],
            "duration": "10-14 дней",
            "prophylaxis": "При >2 эпизодов/год - бензатин пенициллин 1.2 млн ЕД/мес или эритромицин 250 мг 2x/день"
        },
        "prevention": [
            "Тщательный уход за кожей",
            "Избегать травм",
            "Немедленная обработка ран",
            "Антибиотикопрофилактика при процедурах"
        ]
    },
    
    "lymphangiosarcoma": {
        "name": "Лимфангиосаркома (Stewart-Treves syndrome)",
        "incidence": "0.5% при длительной лимфедеме",
        "risk_factors": ["Длительная лимфедема >10 лет", "Постмастэктомия"],
        "signs": ["Синюшное пятно", "Узел", "Язва", "Быстрый рост"],
        "treatment": "Широкая резекция ± лучевая терапия",
        "prognosis": "Плохая (5-летняя выживаемость <10%)"
    }
}


# ==================== ПРОФИЛАКТИКА ====================

LYMPHEDEMA_PREVENTION = {
    "at_risk_patients": [
        "После лимфаденэктомии",
        "После радиотерапии",
        "Генетическая предрасположенность"
    ],
    
    "measures": {
        "skin_care": [
            "Ежедневное увлажнение",
            "pH-neutral мыло",
            "Защита от солнца",
            "Немедленная обработка ран"
        ],
        "activity": [
            "Избегать перегрева",
            "Избегать статических нагрузок",
            "Регулярные перерывы при сидячей работе",
            "Поднятие конечности при отдыхе"
        ],
        "compression": [
            "При длительных полетах",
            "При физической нагрузке",
            "При беременности"
        ],
        "avoid": [
            "Измерение АД на пораженной конечности",
            "Венепункции на пораженной конечности",
            "Инъекции на пораженной конечности",
            "Татуировки",
            "Акupunктура",
            "Тесная одежда/украшения"
        ]
    }
}


# ==================== ФУНКЦИИ ДЛЯ API ====================

def classify_lymphedema(onset_age: int, family_history: bool, 
                         triggers: List[str]) -> Dict[str, Any]:
    """
    Классификация лимфедемы
    """
    classification = {
        "type": None,
        "subtype": None,
        "genetic_testing_recommended": False
    }
    
    # Первичная vs вторичная
    if onset_age < 35 and family_history:
        classification["type"] = "primary"
        if onset_age == 0:
            classification["subtype"] = "congenital (Milroy)"
            classification["genetic_testing_recommended"] = True
        elif onset_age < 25:
            classification["subtype"] = "praecox (Meige)"
            classification["genetic_testing_recommended"] = True
        else:
            classification["subtype"] = "tarda"
    else:
        classification["type"] = "secondary"
        if triggers:
            classification["triggers"] = triggers
    
    return classification


def get_cdt_protocol(stage: str, limb_volume: float) -> Dict[str, Any]:
    """
    Получить протокол CDT для стадии лимфедемы
    """
    protocol = {
        "phase_1": {
            "duration": "2-4 недели",
            "mld": "Ежедневно (45-60 минут)",
            "compression": "Многослойное бинтование",
            "exercise": "С компрессией",
            "skin_care": "Ежедневно"
        },
        "phase_2": {
            "duration": "Пожизненно",
            "compression": "Компрессионный трикотаж",
            "self_mld": "Обучение пациента",
            "exercise": "Регулярно",
            "skin_care": "Ежедневно"
        }
    }
    
    if stage == "ISL III":
        protocol["surgical_consultation"] = "Рассмотреть редукционную хирургию"
    
    return protocol


def get_cellulitis_protocol(severity: str) -> Dict[str, Any]:
    """
    Протокол лечения целлюлита
    """
    if severity == "mild":
        return {
            "antibiotics": "Амоксициллин/клавуланат 875/125 мг 2x/день",
            "duration": "10-14 дней",
            "compression": "Продолжить",
            "elevation": "Рекомендуется"
        }
    elif severity == "moderate":
        return {
            "antibiotics": "Цефтриаксон 1-2 г в/в + клиндамицин 600 мг в/в",
            "hospitalization": "Рассмотреть",
            "duration": "10-14 дней",
            "follow_up": "48-72 часа"
        }
    else:  # severe
        return {
            "hospitalization": "Обязательно",
            "antibiotics": "Ванкомицин + пиперациллин/тазобактам",
            "imaging": "Исключить абсцесс",
            "surgical_consultation": "При подозрении на некроз"
        }
