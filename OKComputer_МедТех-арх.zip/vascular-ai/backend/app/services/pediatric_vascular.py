"""
VASCULAR.AI - Педиатрическая сосудистая хирургия
Особенности у детей, врожденные аномалии
"""

from typing import Dict, Any, List, Optional


# ==================== НОРМАЛЬНЫЕ ЗНАЧЕНИЯ У ДЕТЕЙ ====================

PEDIATRIC_NORMAL_VALUES = {
    "aortic_diameter": {
        "formula": "Диаметр (мм) = 1.02 + (0.98 × BSA)",
        "note": "BSA = body surface area (m²)",
        "upper_limit": "<1.5 от предсказанного",
        "aneurysm_threshold": ">1.5 от предсказанного"
    },
    
    "blood_pressure": {
        "systolic_formula": "90 + (2 × возраст в годах)",
        "diastolic": "2/3 от систолического",
        "lower_extremity": "Должно быть выше верхней",
        "gradient": ">20 мм рт.ст. между верхними и нижними - коарктация"
    },
    
    "pulse": {
        "newborn": "100-160 уд/мин",
        "infant": "80-140 уд/мин",
        "toddler": "80-130 уд/мин",
        "preschool": "80-120 уд/мин",
        "school_age": "70-110 уд/мин",
        "adolescent": "60-100 уд/мин"
    }
}


# ==================== ВРОЖДЕННЫЕ АНОМАЛИИ СОСУДОВ ====================

CONGENITAL_VASCULAR_ANOMALIES = {
    "coarctation_of_aorta": {
        "name": "Коарктация аорты",
        "definition": "Сужение аорты, обычно дистальнее левой подключичной артерии",
        "clinical_presentation": {
            "neonate": [
                "Сердечная недостаточность",
                "Шок после закрытия артериального протока",
                "Разница АД между верхними и нижними конечностями"
            ],
            "older_child": [
                "Гипертензия",
                "Головная боль",
                "Кlaудикация",
                "Носовые кровотечения"
            ]
        },
        "diagnosis": {
            "physical_exam": [
                "Гипертензия на руках",
                "Сниженное АД на ногах",
                "Слабые пульсации на ногах",
                "Систолический шум между лопатками"
            ],
            "imaging": ["ЭхоКГ", "КТ-ангиография", "МРТ", "Катетеризация"]
        },
        "treatment": {
            "neonate_critical": {
                "medical": "Простагландин Е1 (0.05-0.1 мкг/кг/мин)",
                "surgical": "Резекция с end-to-end анастомозом"
            },
            "surgical_repair": {
                "techniques": [
                    "Резекция с end-to-end анастомозом",
                    "Субклавианская flap aortoplasty",
                    "Interposition graft (при длинном сегменте)",
                    "Bypass graft"
                ],
                "timing": "При диагностике (если симптоматично)"
            },
            "balloon_angioplasty": {
                "indication": "Рецидив после операции",
                "note": "Первичная ангиопластика спорна"
            },
            "stenting": {
                "indication": "Подростки/взрослые с рецидивом",
                "note": "Ограничен опыт у детей"
            }
        },
        "follow_up": {
            "monitoring": ["АД", "ЭхоКГ", "МРТ"],
            "long_term_risks": [
                "Рецидив стеноза (5-20%)",
                "Аневризма на месте пластики",
                "Системная гипертензия",
                "Преждевременная ИБС"
            ]
        }
    },
    
    "vascular_rings": {
        "name": "Сосудистые кольца",
        "definition": "Аномальное окружение трахеи и пищевода сосудами",
        "types": {
            "double_aortic_arch": {
                "name": "Двойная дуга аорты",
                "prevalence": "Самое частое симптоматичное кольцо",
                "anatomy": "Обе дуги patent, образуют полное кольцо",
                "symptoms": ["Диспноэ", "Стридор", "Дисфагия"],
                "treatment": "Деление меньшей дуги"
            },
            "right_aortic_arch_left_ligamentum": {
                "name": "Правая дуга аорты с левой артериальной связкой",
                "anatomy": "Правая дуга + левое ligamentum arteriosum",
                "treatment": "Деление ligamentum"
            },
            "pulmonary_sling": {
                "name": "Легочное слинг",
                "anatomy": "Левая легочная артерия отходит от правой",
                "severity": "Наиболее тяжелое (сжимает трахею и пищевод)",
                "treatment": "Реимплантация левой легочной артерии"
            }
        },
        "diagnosis": {
            "imaging": ["КТ-ангиография", "МРТ", "Барийовое глотание"],
            "bronchoscopy": "Оценка компрессии трахеи"
        },
        "surgical_approach": {
            "incision": "Левосторонняя торакотомия (для большинства)",
            "technique": "Деление vascular ring, сохранение recurrent laryngeal nerve",
            "outcome": "Хорошие результаты, симптомы часто регрессируют"
        }
    },
    
    "anomalous_origin_left_coronary": {
        "name": "Аномальное отхождение левой коронарной артерии от легочной артерии (ALCAPA)",
        "pathophysiology": "Левая коронарная от легочной артерии (низкое давление)",
        "clinical": [
            "Сердечная недостаточность",
            "Ишемия миокарда",
            "Митральная регургитация"
        ],
        "treatment": {
            "surgical": "Реимплантация левой коронарной в аорту",
            "alternative": "Takeuchi repair (туннель из легочной артерии)"
        },
        "urgency": "Срочная операция при диагностике"
    },
    
    "kawasaki_disease": {
        "name": "Болезнь Кавасаки",
        "vascular_complication": "Коронарные аневризмы",
        "management": {
            "acute": "IVIG + аспирин",
            "aneurysm_follow_up": "ЭхоКГ серийно",
            "intervention": "Стентирование или CABG при необходимости"
        }
    }
}


# ==================== ПЕДИАТРИЧЕСКИЕ СОСУДИСТЫЕ ДОСТУПЫ ====================

PEDIATRIC_VASCULAR_ACCESS = {
    "umbilical_catheter": {
        "name": "Пупочный катетер",
        "indication": "Новорожденные <2 недель",
        "arterial": {
            "insertion": "До уровня T6-T9 (высокий) или L3-L4 (низкий)",
            "complications": ["Тромбоз", "Эмболия", "Инфекция", "Некроз кишки"]
        },
        "venous": {
            "insertion": "До правого предсердия (TIP at T8-T9)",
            "complications": ["Тромбоз", "Инфекция", "Перфорация", "Тампонада"]
        },
        "removal": "Как можно раньше (обычно <5-7 дней)"
    },
    
    "peripheral_iv": {
        "sites": ["Тыльная поверхность руки", "Предплечье", "Ступня"],
        "note": "Избегать головы (риск инфекции)"
    },
    
    "central_venous_access": {
        "indications": [
            "Длительная инфузионная терапия",
            "Химиотерапия",
            "Парентеральное питание",
            "Гемодиализ"
        ],
        "types": {
            "broviac": {
                "name": "Broviac catheter",
                "description": "Туннелизированный, Dacron cuff",
                "use": "Длительный доступ"
            },
            "hickman": {
                "name": "Hickman catheter",
                "description": "Больший диаметр, чем Broviac",
                "use": "Химиотерапия, диализ"
            },
            "port_a_cath": {
                "name": "Port-a-cath",
                "description": "Подкожный порт",
                "advantage": "Меньше инфекций, можно купаться"
            }
        },
        "insertion": "Под УЗ-наведением предпочтительно"
    },
    
    "arterial_access": {
        "radial": {
            "test": "Модифицированный Аллен тест",
            "size": "24G для новорожденных, 22G для младенцев"
        },
        "posterior_tibial": {
            "use": "Альтернатива радиальной",
            "note": "Меньше осложнений"
        },
        "umbilical": "См. выше",
        "femoral": {
            "use": "Последний выбор",
            "risk": "Тромбоз, ишемия ноги"
        }
    }
}


# ==================== ПЕДИАТРИЧЕСКИЕ СОСУДИСТЫЕ ОПЕРАЦИИ ====================

PEDIATRIC_VASCULAR_SURGERY = {
    "general_principles": {
        "size_mismatch": "Детские сосуды мелкие, требуют микрохирургии",
        "growth": "Учитывать рост при выборе протеза",
        "materials": {
            "vein": "Аутологичная вена предпочтительна",
            "prosthetic": "Ограниченная применимость из-за размера"
        },
        "heparin": "100 ЕД/кг",
        "blood_volume": "Малый объем крови - внимание к кровопотере"
    },
    
    "specific_procedures": {
        "coarctation_repair": {
            "approach": "Левосторонняя торакотомия (4-5 межреберье)",
            "techniques": [
                "Резекция с end-to-end анастомозом",
                "Субклавианская flap aortoplasty",
                "Interposition graft (при длинном сегменте)"
            ],
            "complications": [
                "Рецидив стеноза",
                "Параплегия (редко)",
                "Кровотечение",
                "Chylothorax"
            ]
        },
        
        "vascular_ring_division": {
            "approach": "Левосторонняя торакотомия",
            "technique": "Деление ring, сохранение recurrent laryngeal nerve",
            "outcome": "Хорошие результаты"
        },
        
        "dialysis_access": {
            "note": "Редко нужен у детей",
            "approach": "Аналогично взрослым, но с учетом размера",
            "timing": "За 3-6 месяцев до необходимости диализа"
        }
    }
}


# ==================== ФУНКЦИИ ДЛЯ API ====================

def calculate_pediatric_aortic_diameter(body_surface_area: float) -> Dict[str, Any]:
    """
    Расчет нормального диаметра аорты у ребенка
    """
    predicted_diameter = 1.02 + (0.98 * body_surface_area)
    
    return {
        "body_surface_area_m2": body_surface_area,
        "predicted_aortic_diameter_mm": round(predicted_diameter, 1),
        "upper_normal_limit_mm": round(predicted_diameter * 1.2, 1),
        "aneurysm_threshold_mm": round(predicted_diameter * 1.5, 1),
        "note": "Значения приближенные, индивидуальная вариабельность"
    }


def assess_coarctation(upper_extremity_bp: float, lower_extremity_bp: float,
                       age_months: int) -> Dict[str, Any]:
    """
    Оценка коарктации аорты
    """
    gradient = upper_extremity_bp - lower_extremity_bp
    
    assessment = {
        "upper_extremity_bp": upper_extremity_bp,
        "lower_extremity_bp": lower_extremity_bp,
        "gradient": gradient,
        "significant_coarctation": gradient > 20
    }
    
    if gradient > 20:
        assessment["severity"] = "Significant"
        assessment["recommendation"] = "Кардиохирургическая консультация"
        assessment["workup"] = ["ЭхоКГ", "КТ-ангиография или МРТ", "Кардиокатетеризация"]
    elif gradient > 10:
        assessment["severity"] = "Mild"
        assessment["recommendation"] = "Наблюдение, контроль АД"
    else:
        assessment["severity"] = "None"
        assessment["recommendation"] = "Коарктация маловероятна"
    
    return assessment


def get_pediatric_vascular_access_recommendation(age_months: int, 
                                                  indication: str) -> Dict[str, Any]:
    """
    Рекомендация по сосудистому доступу у ребенка
    """
    if age_months < 2:
        return {
            "primary_choice": "Пупочный катетер",
            "alternatives": ["Периферический ВВ"],
            "note": "Пупочный доступ доступен только в первые 2 недели жизни"
        }
    elif age_months < 12:
        return {
            "primary_choice": "Периферический ВВ (тыльная поверхность руки)",
            "alternatives": ["Центральный венозный катетер (при необходимости)"],
            "note": "Избегать головы (риск инфекции)"
        }
    else:
        return {
            "primary_choice": "Периферический ВВ",
            "central_access": {
                "indications": ["Химиотерапия", "Длительное питание", "Диализ"],
                "types": ["Port-a-cath", "Broviac/Hickman"]
            }
        }


def get_pediatric_considerations(procedure: str, age_years: int) -> Dict[str, Any]:
    """
    Получить педиатрические рекомендации для процедуры
    """
    considerations = {
        "dosing": {
            "heparin": f"{100} ЕД/кг",
            "antibiotics": "По весу",
            "contrast": "Минимизировать, защита почек"
        },
        "size": {
            "note": "Микрохирургические техники",
            "instruments": "Педиатрические"
        },
        "monitoring": {
            "blood_loss": "Критично - малый объем крови",
            "temperature": "Поддержание температуры"
        },
        "growth": {
            "note": "Учитывать рост при планировании"
        }
    }
    
    return {
        "procedure": procedure,
        "age_years": age_years,
        "special_considerations": considerations,
        "recommendation": "Консультация педиатрического сосудистого хирурга"
    }
