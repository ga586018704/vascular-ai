"""
VASCULAR.AI - Планирование сосудистого доступа
Для диализа, эндоваскулярных интервенций, TEVAR/EVAR доступа
"""

from typing import Dict, Any, List, Optional
from dataclasses import dataclass
from enum import Enum


# ==================== ПЛАНИРОВАНИЕ ДОСТУПА ДЛЯ ДИАЛИЗА ====================

DIALYSIS_ACCESS_GUIDE = {
    "planning_principles": {
        "fistula_first": {
            "principle": "Fistula First - нативная фистула предпочтительнее протеза",
            "rationale": [
                "Лучшая проходимость (65% vs 50% на 3 года)",
                "Меньше инфекций (0.5 vs 3.8 на 1000 дней)",
                "Меньше интервенций",
                "Лучшая выживаемость пациента"
            ],
            "kdoqi_goal": ">65% нативных фистул"
        },
        "distal_to_proximal": {
            "principle": "Дистальное к проксимальному",
            "order": [
                "Радиоцефальная (Brescia-Cimino)",
                "Срединно-цефальная",
                "Проксимальная радиоцефальная",
                "Базилико-цефальная (транспозиция)",
                "Протез (в последнюю очередь)"
            ]
        },
        "timing": {
            "optimal": "За 3-6 месяцев до начала диализа",
            "minimum_vein": "Диаметр артерии ≥2 мм, вены ≥2.5 мм",
            "note": "Фистула созревает 6-12 недель"
        }
    },
    
    "fistula_types": {
        "radiocephalic": {
            "name": "Радиоцефальная фистула (Brescia-Cimino)",
            "location": "Запястье (snuffbox или стандартная)",
            "advantages": [
                "Самая дистальная",
                "Сохраняет проксимальные вены",
                "Меньше воровства крови",
                "Лучшая проходимость"
            ],
            "disadvantages": [
                "Меньший диаметр",
                "Дольше созревает",
                "Может быть недостаточным потоком"
            ],
            "patency": {
                "primary_1yr": "60-70%",
                "primary_2yr": "50-60%",
                "secondary_2yr": "80-90%"
            },
            "criteria": {
                "artery_diameter": "≥2 мм",
                "vein_diameter": "≥2.5 мм",
                "vein_distance": "<1.5 см от артерии"
            },
            "technique": "Термино-терминальная или термино-латеральная анастомоз"
        },
        
        "brachiocephalic": {
            "name": "Базилико-цефальная фистула",
            "location": "Локтевая ямка",
            "types": {
                "direct": {
                    "name": "Прямая анастомоз",
                    "indications": "Достаточный диаметр базиликовой вены",
                    "note": "Вена должна быть достаточно поверхностной"
                },
                "transposition": {
                    "name": "Транспозиция базиликовой вены",
                    "indications": "Глубокая базиликовая вена",
                    "technique": "Вена выводится на поверхность через подкожный туннель",
                    "advantage": "Лучший косметический результат"
                }
            },
            "patency": {
                "primary_1yr": "70-80%",
                "primary_2yr": "60-70%"
            },
            "criteria": {
                "artery_diameter": "≥2.5 мм",
                "vein_diameter": "≥3 мм (прямая), ≥2.5 мм (транспозиция)"
            }
        },
        
        "brachiobasilic": {
            "name": "Брахиобазиликовая фистула",
            "location": "Проксимальное предплечье/плечо",
            "indications": "Недостаточность других вен",
            "technique": "Обязательно транспозиция",
            "patency": {
                "primary_1yr": "65-75%",
                "primary_2yr": "55-65%"
            }
        }
    },
    
    "graft_types": {
        "forearm_loop": {
            "name": "Петлевой протез на предплечье",
            "configuration": "Прямая или изогнутая петля",
            "indications": "Недостаточность вен для фистулы",
            "patency": {
                "primary_1yr": "50-60%",
                "secondary_1yr": "70-80%"
            },
            "materials": ["PTFE", "Биологические протезы"]
        },
        
        "upper_arm": {
            "name": "Протез на плече",
            "types": ["Прямой", "Изогнутый"],
            "indications": "Исчерпаны варианты на предплечье",
            "patency": {
                "primary_1yr": "45-55%",
                "secondary_1yr": "65-75%"
            }
        },
        
        "leg_graft": {
            "name": "Протез на ноге",
            "types": ["Бедренно-подколенный", "Тибиальный"],
            "indications": "Исчерпаны варианты на верхних конечностях",
            "note": "Высокий риск инфекции"
        }
    },
    
    "preoperative_assessment": {
        "history": [
            "Предыдущие попытки доступа",
            "Катетеры в центральных венах",
            "Пейсмейкер/дефибриллятор",
            "Гипертензия, диабет"
        ],
        "physical_exam": [
            "Аллен тест (обязательно!)",
            "Оценка вен (tourniquet test)",
            "Пальпация артерий",
            "Оценка отека"
        ],
        "imaging": {
            "duplex_ultrasound": {
                "indication": "Всем пациентам",
                "measurements": [
                    "Диаметр артерии",
                    "Диаметр вены",
                    "Расстояние артерия-вена",
                    "Глубина вены",
                    "Патентность"
                ]
            },
            "venography": {
                "indication": "При подозрении на центральный стеноз",
                "findings": "Оценка подключичной и верхней полой вены"
            }
        }
    },
    
    "maturation_assessment": {
        "timeline": {
            "2_weeks": "Первая оценка",
            "4_6_weeks": "Основная оценка созревания",
            "8_12_weeks": "Фистула должна быть готова"
        },
        "criteria": {
            "flow_volume": ">350-500 мл/мин (для диализа)",
            "vein_diameter": "≥6 мм",
            "depth": "<6 мм от поверхности кожи",
            "flow_pattern": "Низкое сопротивление"
        },
        "interventions_for_failure": {
            "stenosis": "Ангиопластика ± стентирование",
            "thrombosis": "Тромбэктомия",
            "insufficient_flow": "Лigation дренирующих вен, revision"
        }
    },
    
    "complications": {
        "thrombosis": {
            "causes": ["Стеноз", "Гипотензия", "Гиповолемия", "Сжатие"],
            "treatment": "Тромбэктомия + коррекция причины",
            "prevention": "Избегать гипотензии, компрессии"
        },
        "stenosis": {
            "location": "Чаще всего анастомоз вена-фистула",
            "diagnosis": "УЗИ с потоком >400 см/с или Δ >100 см/с",
            "treatment": "Ангиопластика (первичная проходимость 70-80%)"
        },
        "infection": {
            "risk": "0.5-1 на 1000 дней (фистула), 3-5 (протез)",
            "treatment": "Антибиотики, дренаж абсцесса, удаление протеза при необходимости"
        },
        "steal_syndrome": {
            "grades": {
                "grade_1": "Асимптоматическое охлаждение",
                "grade_2": "Минимальные симптомы (парестезии)",
                "grade_3": "Покойная боль, трофические изменения",
                "grade_4": "Гангрена, трофические язвы"
            },
            "treatment": {
                "grade_1_2": "Наблюдение, компрессия",
                "grade_3_4": "DRIL (Distal Revascularization with Interval Ligation) или banding"
            }
        },
        "aneurysm": {
            "types": ["Истинный", "Ложный (псевдоаневризма)"],
            "treatment": "Резекция при росте, боли, угрозе разрыва"
        },
        "heart_failure": {
            "cause": "Высокий кардиакальный шунт",
            "threshold": "Qb >1.5-2.0 л/мин",
            "treatment": "Banding фистулы или ligation"
        }
    },
    
    "surveillance": {
        "schedule": {
            "monthly": "Физический осмотр",
            "quarterly": "УЗИ с измерением потока",
            "annually": "Полная оценка"
        },
        "red_flags": [
            "Снижение потока >25%",
            "Новый шум (высокочастотный)",
            "Удлинение времени прокола",
            "Отек руки",
            "Боль в руке"
        ]
    }
}


# ==================== ДОСТУП ДЛЯ ЭНДОВАСКУЛЯРНЫХ ИНТЕРВЕНЦИЙ ====================

ENDOVASCULAR_ACCESS_GUIDE = {
    "femoral_access": {
        "common_femoral": {
            "name": "Общая бедренная артерия",
            "landmarks": "Средняя треть паховой связки",
            "advantages": [
                "Крупный диаметр",
                "Легкая компрессия",
                "Минимальные осложнения"
            ],
            "technique": {
                "ultrasound_guided": "Рекомендуется (особенно при высокой бифуркации)",
                "micropuncture": "6F или 4F для начала",
                "closure": "Мануальная компрессия или устройство (Angio-Seal, Perclose)"
            },
            "sheath_sizes": {
                "diagnostic": "4-5F",
                "interventional": "6-8F",
                "evvar": "12-24F",
                "tevar": "18-24F"
            }
        },
        
        "radial_access": {
            "name": "Лучевая артерия",
            "advantages": [
                "Раннее mobilization",
                "Меньше кровотечений",
                "Предпочтительно при диабете, ожирении"
            ],
            "contraindications": [
                "Отрицательный Аллен тест",
                "Артерия <2 мм",
                "Диализный шунт на руке"
            ],
            "technique": {
                "barbeau_test": "Пульсоксиметрия для подтверждения",
                "spasm_prevention": "Нитроглицерин 200 мкг, верапамил",
                "sheath": "5-6F (до 8F возможно)"
            },
            "closure": "Мануальная компрессия 10-15 мин или TR band"
        },
        
        "brachial_access": {
            "name": "Брахиальная артерия",
            "indications": "Когда феморальный и радиальный недоступны",
            "risks": [
                "Высокий риск тромбоза",
                "Синдром компартмент-синдрома",
                "Неврологические осложнения"
            ],
            "technique": "Открытый доступ предпочтительнее перкутанного",
            "closure": "Хирургическая закрытие"
        },
        
        "popliteal_access": {
            "name": "Подколенная артерия",
            "indications": "Ретроградный доступ для тибиальных интервенций",
            "technique": "УЗ-наведение обязательно",
            "position": "Пронация или латеральное положение"
        },
        
        "pedal_access": {
            "name": "Педальная/тыльная стопная артерия",
            "indications": "Критическая ишемия, невозможность проксимального доступа",
            "technique": "УЗ-наведение",
            "note": "Доступ 'от мыска к носу'"
        }
    },
    
    "closure_devices": {
        "suture_based": {
            "perclose": {
                "name": "Perclose ProGlide",
                "mechanism": "Складывающийся шов",
                "sheath_size": "5-8F (до 21F с pre-close)",
                "advantages": ["Немедленное закрытие", "Большие диаметры"]
            },
            "prostar": {
                "name": "Prostar XL",
                "sheath_size": "8.5-10F (до 24F)"
            }
        },
        "clip_based": {
            "starclose": {
                "name": "StarClose SE",
                "mechanism": "Нитиноловый клип",
                "sheath_size": "5-6F"
            }
        },
        "plug_based": {
            "angio_seal": {
                "name": "Angio-Seal",
                "mechanism": "Коллагеновая пробка + анкер",
                "sheath_size": "6-8F",
                "time_to_hemostasis": "2 минуты"
            },
            "mynx": {
                "name": "Mynx Grip",
                "mechanism": "Полиэтиленгликольевый гель",
                "sheath_size": "5-7F"
            }
        },
        "compression": {
            "manual": "Золотой стандарт, 10-15 минут",
            "mechanical": "FemoStop, ClampEase - 20-30 минут"
        }
    },
    
    "access_complications": {
        "hematoma": {
            "prevention": "Тщательная компрессия, корректное положение",
            "treatment": "Компрессия, редко хирургическое дренирование",
            "pseudoaneurysm": "УЗ-направленная тромбиновая инъекция или хирургия"
        },
        "arteriovenous_fistula": {
            "cause": "Прокол вену при доступе",
            "treatment": "Малые - наблюдение, большие - хирургия или эмболизация"
        },
        "dissection": {
            "treatment": "Стентирование при ограничении потока"
        },
        "thrombosis": {
            "treatment": "Тромбэктомия, ангиопластика"
        },
        "retroperitoneal_hemorrhage": {
            "signs": ["Боль в спине", "Гипотензия", "Падение гематокрита"],
            "risk_factors": ["Высокая бифуркация", "Прокол выше связки"],
            "treatment": "Контрастная КТ, эмболизация или хирургия"
        }
    }
}


# ==================== ПЛАНИРОВАНИЕ ДОСТУПА ДЛЯ TEVAR/EVAR ====================

TEVAR_EVAR_ACCESS = {
    "iliac_access_assessment": {
        "measurements": [
            "Минимальный диаметр подвздошной артерии",
            "Кальциноз",
            "Тортуозность",
            "Стенозы"
        ],
        "minimum_diameter": {
            "18F": "≥7 мм",
            "20F": "≥7.5 мм",
            "22F": "≥8 мм",
            "24F": "≥8.5 мм"
        },
        "contraindications": [
            "Тяжелый кальциноз",
            "Значимый стеноз",
            "Малый диаметр",
            "Тяжелая тортуозность"
        ],
        "solutions": {
            "conduit": "Хирургический кондуит (10 мм Dacron или PTFE)",
            "iliac_angioplasty": "Предварительная ангиопластика",
            "hybrid": "Гибридный доступ с феморальной конверсией"
        }
    },
    
    "access_techniques": {
        "bilateral_femoral": {
            "name": "Двусторонний феморальный доступ",
            "indications": "Большинство EVAR/TEVAR",
            "sheath_sizes": "12-24F"
        },
        "percutaneous": {
            "name": "Перкутанный доступ (Pre-close technique)",
            "technique": "Perclose ProGlide до введения большого шита",
            "advantages": ["Минимальная травма", "Быстрое заживление"],
            "contraindications": ["Тяжелый кальциноз", "Малый диаметр"]
        },
        "cutdown": {
            "name": "Хирургический доступ",
            "indications": "Когда перкутанный невозможен",
            "closure": "Прямой шов или заплата"
        }
    },
    
    "sheath_selection": {
        "evar": {
            "main_body": "18-24F",
            "contralateral": "12-16F",
            "extensions": "14-18F"
        },
        "tevar": {
            "delivery": "18-24F",
            "depending_on_device": "Cook, Gore, Medtronic различаются"
        }
    }
}


# ==================== ФУНКЦИИ ДЛЯ API ====================

def get_dialysis_access_recommendation(patient_data: Dict[str, Any]) -> Dict[str, Any]:
    """
    Рекомендация по выбору диализного доступа на основе данных пациента
    """
    recommendations = []
    
    # Оценка вен
    cephalic_diameter = patient_data.get("cephalic_vein_diameter", 0)
    basilic_diameter = patient_data.get("basilic_vein_diameter", 0)
    radial_diameter = patient_data.get("radial_artery_diameter", 0)
    brachial_diameter = patient_data.get("brachial_artery_diameter", 0)
    
    # Проверка предыдущих доступов
    previous_accesses = patient_data.get("previous_accesses", [])
    
    # Алгоритм выбора
    if cephalic_diameter >= 2.5 and radial_diameter >= 2.0 and "radiocephalic" not in previous_accesses:
        recommendations.append({
            "priority": 1,
            "type": "radiocephalic",
            "name": "Радиоцефальная фистула",
            "rationale": "Fistula first, самый дистальный доступ",
            "success_probability": "70-80%"
        })
    
    if basilic_diameter >= 3.0 and brachial_diameter >= 2.5:
        recommendations.append({
            "priority": 2,
            "type": "brachiocephalic",
            "name": "Базилико-цефальная фистула",
            "rationale": "Хорошая проходимость, если радиоцефальная невозможна",
            "success_probability": "75-85%"
        })
    
    if basilic_diameter >= 2.5 and brachial_diameter >= 2.5:
        recommendations.append({
            "priority": 3,
            "type": "brachiobasilic_transposition",
            "name": "Брахиобазиликовая фистула с транспозицией",
            "rationale": "Если другие вены недоступны",
            "success_probability": "65-75%"
        })
    
    # Протез только если нет вен
    if len(recommendations) == 0:
        recommendations.append({
            "priority": 4,
            "type": "forearm_loop_graft",
            "name": "Петлевой протез на предплечье",
            "rationale": "Недостаточность вен для фистулы",
            "success_probability": "50-60%",
            "note": "Высокий риск инфекции и тромбоза"
        })
    
    return {
        "fistula_first_compliance": len(recommendations) > 0 and recommendations[0]["type"] != "forearm_loop_graft",
        "recommendations": recommendations,
        "preoperative_requirements": [
            "Дуплексное УЗИ артерий и вен",
            "Аллен тест",
            "Оценка центральных вен (при подозрении на стеноз)"
        ],
        "timing": "Оптимально за 3-6 месяцев до начала диализа"
    }


def get_endovascular_access_plan(procedure_type: str, patient_data: Dict[str, Any]) -> Dict[str, Any]:
    """
    Планирование доступа для эндоваскулярной процедуры
    """
    plan = {
        "procedure": procedure_type,
        "recommended_access": [],
        "alternatives": [],
        "sheath_size": None,
        "closure_method": None
    }
    
    # Определение размера шита
    sheath_sizes = {
        "diagnostic_angiography": "4-5F",
        "carotid_stenting": "6-8F",
        "femoropopliteal_angioplasty": "5-6F",
        "iliac_stenting": "6-8F",
        "evar": "18-24F",
        "tevar": "18-24F",
        "tavi": "14-18F"
    }
    plan["sheath_size"] = sheath_sizes.get(procedure_type, "6-8F")
    
    # Выбор доступа
    radial_suitable = patient_data.get("radial_suitable", True)
    femoral_suitable = patient_data.get("femoral_suitable", True)
    
    if procedure_type in ["diagnostic_angiography", "carotid_stenting"] and radial_suitable:
        plan["recommended_access"].append({
            "site": "radial",
            "name": "Лучевая артерия",
            "advantages": ["Раннее mobilization", "Меньше кровотечений"],
            "closure": "Мануальная компрессия 10-15 мин или TR band"
        })
        plan["alternatives"].append({
            "site": "femoral",
            "name": "Общая бедренная артерия"
        })
    else:
        plan["recommended_access"].append({
            "site": "femoral",
            "name": "Общая бедренная артерия",
            "technique": "УЗ-наведение рекомендуется",
            "closure_options": ["Мануальная компрессия", "Perclose", "Angio-Seal"]
        })
        if radial_suitable:
            plan["alternatives"].append({
                "site": "radial",
                "name": "Лучевая артерия"
            })
    
    # Для EVAR/TEVAR
    if procedure_type in ["evar", "tevar"]:
        plan["access_assessment"] = {
            "required_measurements": [
                "Диаметр подвздошных артерий",
                "Кальциноз",
                "Тортуозность"
            ],
            "minimum_diameter": "≥7-8.5 мм в зависимости от устройства",
            "alternatives_if_unsuitable": [
                "Хирургический кондуит",
                "Конверсия в открытую операцию"
            ]
        }
    
    return plan


def get_access_complication_management(complication: str, severity: str) -> Dict[str, Any]:
    """
    Управление осложнениями доступа
    """
    complications = ENDOVASCULAR_ACCESS_GUIDE["access_complications"]
    
    if complication not in complications:
        return {"error": f"Unknown complication: {complication}"}
    
    return complications[complication]
