"""
VASCULAR.AI - Предоперационные чек-листы
WHO Surgical Safety Checklist + специфика сосудистой хирургии
"""

from typing import Dict, Any, List, Optional


# ==================== WHO SURGICAL SAFETY CHECKLIST ====================

WHO_SAFETY_CHECKLIST = {
    "sign_in": {
        "timing": "Перед введением анестезии",
        "items": {
            "patient_identity": {
                "check": "Пациент подтвердил свою личность, место операции, процедуру",
                "verification": "Сравнение с маркировкой и согласием"
            },
            "site_marking": {
                "check": "Место операции отмечено и видно",
                "vascular_specific": "Отметить сторону (при односторонней операции)"
            },
            "anesthesia_safety": {
                "check": "Проверка безопасности анестезии",
                "items": ["Аллергии", "Сложность дыхательных путей", "Риск аспирации"]
            },
            "blood_loss": {
                "check": "Предполагаемая кровопотеря",
                "vascular_specific": "Подготовлены кровь и продукты"
            }
        }
    },
    
    "time_out": {
        "timing": "Перед разрезом",
        "items": {
            "team_introduction": {
                "check": "Все члены команды представились",
                "roles": "Хирург, анестезиолог, операционная медсестра"
            },
            "patient_identity_confirmed": {
                "check": "Повторное подтверждение личности, места, процедуры"
            },
            "antibiotics": {
                "check": "Профилактические антибиотики даны",
                "timing": "За 60 минут до разреза (цефалоспорины)",
                "vascular_recommendations": {
                    "cefazolin": "2 г (3 г при весе >120 кг)",
                    "vancomycin": "При аллергии на пенициллин или MRSA",
                    "redosing": "Каждые 4 часа или при кровопотере >1500 мл"
                }
            },
            "critical_steps": {
                "check": "Критические этапы обсуждены",
                "vascular_specific": [
                    "План реконструкции",
                    "Контроль кровотечения",
                    "Антикоагуляция",
                    "Ишемическое время"
                ]
            },
            "estimated_duration": {
                "check": "Предполагаемая продолжительность",
                "vascular_specific": "Время ишемии конечности/органа"
            },
            "blood_products": {
                "check": "Доступность крови и продуктов",
                "vascular_specific": "Перекрестная проба, массивное переливание protocol"
            }
        }
    },
    
    "sign_out": {
        "timing": "Перед закрытием раны или выходом из операционной",
        "items": {
            "instrument_count": {
                "check": "Подсчет инструментов и компрессов",
                "verification": "Совпадает с начальным подсчетом"
            },
            "specimen_labeling": {
                "check": "Маркировка образцов",
                "vascular_specific": "Тромбы, ткани для гистологии"
            },
            "equipment_issues": {
                "check": "Проблемы с оборудованием для адресования"
            },
            "recovery_plan": {
                "check": "План послеоперационного ведения",
                "vascular_specific": [
                    "Место после операции (ИТО/обычная палата)",
                    "Мониторинг пульсаций",
                    "Антикоагуляция",
                    "Компрессия (при варикозе)"
                ]
            }
        }
    }
}


# ==================== СПЕЦИФИЧЕСКИЕ ЧЕК-ЛИСТЫ ====================

PROCEDURE_SPECIFIC_CHECKLISTS = {
    "carotid_endarterectomy": {
        "preoperative": {
            "imaging": [
                "УЗДГ сонных артерий (<3 месяцев)",
                "КТ- или МР-ангиография (при необходимости)"
            ],
            "neurological": [
                "Базовый неврологический статус",
                "Документация дефицитов"
            ],
            "cardiac": [
                "ЭКГ",
                "Оценка сердечного риска"
            ],
            "medication": [
                "Аспирин 100 мг/сут (продолжать)",
                "Статины (продолжать)",
                "Антигипертензивные (утром доза)"
            ],
            "shunt_planning": {
                "decision": "План использования шунта",
                "options": ["Рутинное использование", "Селективное", "Никогда"],
                "monitoring": "Соматосенсорные вызванные потенциалы или проба на пробуждении"
            }
        },
        "intraoperative": {
            "positioning": "Подушка под плечи, голова повернута",
            "monitoring": [
                "Артериальное давление (инвазивное)",
                "ЦВД (при необходимости)",
                "Соматосенсорные ВП или проба на пробуждении"
            ],
            "heparin": "5000 ЕД в/в за 3-5 минут до пережатия",
            "shunt": "При необходимости (снижение ВП >50%)",
            "patch": "Решение о заплатной пластике",
            "completion": [
                "Допплеровский контроль",
                "Ангиография (при подозрении на дефект)"
            ]
        },
        "postoperative": {
            "immediate": [
                "Неврологический осмотр каждые 15 мин × 1 час",
                "Контроль АД (избегать гипертензии)",
                "Мониторинг пульсаций"
            ],
            "complications_to_watch": [
                "Гипертензия (риск гиперперфузии)",
                "Гипотензия (риск тромбоза)",
                "Неврологический дефицит",
                "Гематома шеи"
            ],
            "discharge": [
                "Аспирин пожизненно",
                "Контроль УЗИ через 1 месяц",
                "Модификация факторов риска"
            ]
        }
    },
    
    "evar": {
        "preoperative": {
            "imaging": [
                "КТ-ангиография с 1 мм срезами",
                "3D реконструкция",
                "Измерения выполнены"
            ],
            "planning": [
                "Выбор устройства",
                "Размеры основного тела и limbs",
                "План покрытия внутренних подвздошных",
                "План доступа"
            ],
            "medical": [
                "Креатинин",
                "Гидратация (контрастная защита)",
                "Антибиотики (цефазolin 2 г)"
            ],
            "access_assessment": [
                "Диаметр подвздошных артерий",
                "Кальциноз",
                "Тортуозность",
                "План перкутанного vs cutdown"
            ]
        },
        "intraoperative": {
            "positioning": "Супинация, обе ноги слегка согнуты и отведены",
            "access": [
                "УЗ-наведение для перкутанного доступа",
                "Pre-close technique (Perclose)",
                "Большие шиты (18-24F)"
            ],
            "heparin": "100 ЕД/кг (ACT >250 сек)",
            "imaging": [
                "C-arm с возможностью 3D",
                "Контрастная ангиография перед развертыванием",
                "Ангиография после развертывания"
            ],
            "deployment": [
                "Точное позиционирование",
                "Контроль почечных артерий",
                "Контроль внутренних подвздошных"
            ],
            "completion": [
                "Ангиография для endoleak",
                "Оценка конечностей",
                "Закрытие доступа"
            ]
        },
        "postoperative": {
            "immediate": [
                "Контроль конечностей (пульсации, цвет)",
                "Мониторинг гемоглобина",
                "Креатинин через 24-48 часов"
            ],
            "discharge": [
                "Аспирин 75-100 мг/сут",
                "КТ-ангиография через 1 месяц",
                "График наблюдения"
            ],
            "surveillance": [
                "КТ-ангиография: 1 мес, 6 мес, 12 мес, затем ежегодно",
                "Оценка на endoleak",
                "Измерение диаметра аневризмы"
            ]
        }
    },
    
    "femoropopliteal_bypass": {
        "preoperative": {
            "imaging": [
                "Дуплексное УЗИ",
                "КТ- или МР-ангиография",
                "Ангиография (при необходимости)"
            ],
            "graft_selection": [
                "Великая сапенозная вена (предпочтительно)",
                "Альтернативы если ВСВ недоступна"
            ],
            "vein_mapping": [
                "Дуплексное УЗИ ВСВ",
                "Диаметр, патентность, варианты"
            ],
            "inflow_assessment": [
                "Патентность аорто-подвздошного сегмента",
                "Общая бедренная артерия"
            ],
            "outflow_assessment": [
                "Подколенная артерия",
                "Трехветвия",
                "Педальные артерии"
            ],
            "antibiotics": "Цефазolin 2 г за 30 минут"
        },
        "intraoperative": {
            "positioning": "Супинация, бедро слегка согнуто и отведено",
            "preparation": [
                "Подготовка ВСВ (если используется)",
                "Двухполостной подход",
                "Гепарин 5000 ЕД в/в"
            ],
            "technique": [
                "Проксимальный анастомоз",
                "Туннелизация (подкожно или подмышечно)",
                "Дистальный анастомоз",
                "Проксимальная перед дистальной (для проверки оттока)"
            ],
            "completion": [
                "Допплеровский контроль",
                "Ангиография (при подозрении на проблему)",
                "Измерение АКШ"
            ],
            "drains": "При необходимости"
        },
        "postoperative": {
            "immediate": [
                "Мониторинг пульсаций (дистальных)",
                "Контроль цвета и температуры ноги",
                "Антикоагуляция (варфарин или НОАК)",
                "Аспирин 100 мг"
            ],
            "complications": [
                "Тромбоз шунта (срочная ревизия)",
                "Кровотечение",
                "Инфекция",
                "Лимфная фистула"
            ],
            "discharge": [
                "Аспирин пожизненно",
                "Антикоагуляция (обычно 3-6 месяцев)",
                "УЗИ через 1 месяц",
                "График наблюдения"
            ],
            "surveillance": [
                "УЗИ каждые 3-6 месяцев",
                "АКШ",
                "Клиническая оценка"
            ]
        }
    },
    
    "varicose_vein_surgery": {
        "preoperative": {
            "imaging": [
                "Дуплексное УЗИ (обязательно!)",
                "Карта вен",
                "Оценка рефлюкса"
            ],
            "marking": [
                "Отметить варикозные вены в стоячем положении",
                "Отметить перфораторы"
            ],
            "consent": [
                "Риск рецидива",
                "Риск неврологических осложнений (сапенозный нерв)",
                "Риск ТГВ"
            ],
            "preparation": [
                "Компрессионный трикотаж после операции",
                "Антибиотики (обычно не нужны)"
            ]
        },
        "intraoperative": {
            "positioning": "Тренделенбург (для стриппинга)",
            "technique": {
                "stripping": "От паха до колена (обычно)",
                "phlebectomy": "Крючки Мюллера",
                "ligation": "Перфораторы"
            },
            "completion": [
                "Гемостаз",
                "Закрытие разрезов"
            ]
        },
        "postoperative": {
            "immediate": [
                "Компрессионный трикотаж",
                "Ранняя ходьба (в тот же день)"
            ],
            "discharge": [
                "Компрессия 2 недели",
                "Анальгетики",
                "Ранняя активность"
            ],
            "follow_up": [
                "Осмотр через 1-2 недели",
                "УЗИ при рецидиве симптомов"
            ]
        }
    }
}


# ==================== МЕДИКАМЕНТОЗНОЕ УПРАВЛЕНИЕ ====================

PERIOPERATIVE_MEDICATIONS = {
    "antiplatelet": {
        "aspirin": {
            "preop": "Продолжать (в большинстве случаев)",
            "postop": "Начать/продолжить в тот же день",
            "dose": "75-100 мг/сут"
        },
        "clopidogrel": {
            "preop": "Отменить за 5 дней (если плановая операция)",
            "postop": "Возобновить через 24 часа (при гемостазе)",
            "dose": "75 мг/сут"
        },
        "dual_antiplatelet": {
            "carotid_stent": "Продолжать минимум 1 месяц",
            "coronary_stent": "Консультация кардиолога"
        }
    },
    
    "anticoagulation": {
        "warfarin": {
            "preop": "Отменить за 5 дней (целевой МНО <1.5)",
            "bridge": "НМГ когда МНО <2.0, последняя доза за 12-24 часа",
            "postop": "Возобновить через 12-24 часа"
        },
        "noacs": {
            "preop": "Отменить за 48 часов (или более при сниженной КФ)",
            "postop": "Возобновить через 48-72 часа"
        }
    },
    
    "statins": {
        "preop": "Продолжать",
        "postop": "Продолжать",
        "note": "Не прекращать без крайней необходимости"
    },
    
    "beta_blockers": {
        "preop": "Продолжать",
        "postop": "Продолжать",
        "note": "Риск синдрома отмены"
    },
    
    "ace_inhibitors": {
        "preop": "Можно отменить утром операции (риск гипотензии)",
        "postop": "Возобновить когда АД стабильно"
    },
    
    "diabetes_medications": {
        "insulin": {
            "preop": "Уменьшить утреннюю дозу на 25%",
            "postop": "Контроль глюкозы, коррекция инсулином"
        },
        "metformin": {
            "preop": "Отменить за 48 часов (если контраст)",
            "postop": "Возобновить через 48 часов после контраста"
        }
    }
}


# ==================== ФУНКЦИИ ДЛЯ API ====================

def get_preop_checklist(procedure: str, patient_data: Dict[str, Any]) -> Dict[str, Any]:
    """
    Получить предоперационный чек-лист для процедуры
    """
    checklist = PROCEDURE_SPECIFIC_CHECKLISTS.get(procedure, {})
    
    if not checklist:
        return {
            "procedure": procedure,
            "error": "Checklist not available for this procedure",
            "generic_checklist": WHO_SAFETY_CHECKLIST
        }
    
    # Добавить WHO checklist
    complete_checklist = {
        "procedure": procedure,
        "who_safety_checklist": WHO_SAFETY_CHECKLIST,
        "procedure_specific": checklist
    }
    
    # Добавить рекомендации по медикаментам
    medications = []
    
    if patient_data.get("on_aspirin", False):
        medications.append(PERIOPERATIVE_MEDICATIONS["antiplatelet"]["aspirin"])
    
    if patient_data.get("on_warfarin", False):
        medications.append(PERIOPERATIVE_MEDICATIONS["anticoagulation"]["warfarin"])
    
    if patient_data.get("on_metformin", False):
        medications.append(PERIOPERATIVE_MEDICATIONS["diabetes_medications"]["metformin"])
    
    complete_checklist["medication_management"] = medications
    
    return complete_checklist


def get_sign_in_checklist(patient_id: str, procedure: str, site: str) -> Dict[str, Any]:
    """
    Получить Sign In чек-лист
    """
    return {
        "patient_id": patient_id,
        "procedure": procedure,
        "site": site,
        "checklist": WHO_SAFETY_CHECKLIST["sign_in"],
        "mandatory_confirmations": [
            "Пациент подтвердил личность",
            "Процедура подтверждена",
            "Место отмечено",
            "Анестезия готова",
            "Аллергии проверены"
        ]
    }


def get_time_out_checklist(team_members: List[str], critical_steps: List[str]) -> Dict[str, Any]:
    """
    Получить Time Out чек-лист
    """
    return {
        "team_present": team_members,
        "critical_steps": critical_steps,
        "checklist": WHO_SAFETY_CHECKLIST["time_out"],
        "mandatory_items": [
            "Все представились",
            "Пациент и процедура подтверждены",
            "Антибиотики даны",
            "Критические этапы обсуждены",
            "Предполагаемая кровопотеря обсуждена"
        ]
    }


def get_sign_out_checklist(specimens: List[str], equipment_issues: List[str]) -> Dict[str, Any]:
    """
    Получить Sign Out чек-лист
    """
    return {
        "specimens": specimens,
        "equipment_issues": equipment_issues,
        "checklist": WHO_SAFETY_CHECKLIST["sign_out"],
        "mandatory_items": [
            "Подсчет инструментов совпадает",
            "Подсчет компрессов совпадает",
            "Образцы промаркированы",
            "План послеоперационного ведения обсужден"
        ]
    }
