"""
VASCULAR.AI - Клинический атлас сосудистой хирургии
Интеграция знаний из:
- Medscape Vascular Surgery
- First Aid USMLE Step 2 CK
- Netter's Atlas of Human Anatomy / Surgical Anatomy
- Sabiston Textbook of Surgery (22nd Edition)
- Rutherford's Vascular Surgery
- ACC/AHA Guidelines 2024
"""

from typing import Dict, Any, List, Optional


# ==================== КЛИНИЧЕСКИЕ АЛГОРИТМЫ (First Aid USMLE Style) ====================

CLINICAL_ALGORITHMS = {
    "acute_limb_ischemia": {
        "name": "Острая ишемия конечности",
        "six_ps": [
            "Pain (Боль)",
            "Pallor (Бледность)",
            "Pulselessness (Отсутствие пульса)",
            "Paresthesia (Парестезии)",
            "Paralysis (Паралич)",
            "Poikilothermia (Холодность)"
        ],
        "classification": {
            "viable": {
                "description": "Жизнеспособная конечность",
                "findings": "Нет парестезий/паралича, допплеровский сигнал",
                "action": "Срочная ангиография и реваскуляризация"
            },
            "threatened_mild": {
                "description": "Угрожаемая (легкая)",
                "findings": "Минимальные парестезии, отсутствие паралича",
                "action": "Немедленная реваскуляризация (<6 часов)"
            },
            "threatened_severe": {
                "description": "Угрожаемая (тяжелая)",
                "findings": "Парестезии в покое, минимальный паралич",
                "action": "Экстренная реваскуляризация"
            },
            "nonviable": {
                "description": "Нежизнеспособная",
                "findings": "Паралич, аналгезия, нет допплеровского сигнала",
                "action": "Ампутация (если подтверждено)"
            }
        },
        "workup": {
            "immediate": [
                "Физический осмотр (6 P)",
                "Дуплексное УЗИ",
                "КТ-ангиография (если стабильный)"
            ],
            "labs": [
                "CBC (лейкоцитоз)",
                "Креатинин (риск rhabdomyolysis)",
                "CPK",
                "Газоток крови (метаболический ацидоз)"
            ]
        },
        "treatment_algorithm": {
            "step_1": "Гепарин 5000 ЕД в/в",
            "step_2": "Анальгезия",
            "step_3": "Определить причину (эмболия vs тромбоз)",
            "embolism": {
                "source": "Сердце (фибрилляция предсердий), проксимальная аневризма",
                "treatment": "Тромбэктомия (Fogarty) ± фасциотомия"
            },
            "thrombosis": {
                "source": "Атеросклероз, гиперкоагуляция",
                "treatment": "Тромболиз или тромбэктомия"
            }
        }
    },
    
    "carotid_stenosis": {
        "name": "Стеноз сонной артерии",
        "symptoms": {
            "asymptomatic": "Нет симптомов, обнаружен при скрининге",
            "symptomatic": {
                "tia": "Преходящая ишемическая атака (<24 часов)",
                "stroke": "Инсульт (>24 часов)",
                "amaurosis": "Амавроз фугакс (занавес)"
            }
        },
        "grading": {
            "mild": "<50% (УЗИ: PSV <125 см/с)",
            "moderate": "50-69% (УЗИ: PSV 125-230 см/с)",
            "severe": ">70% (УЗИ: PSV >230 см/с)",
            "occlusion": "Нет кровотока"
        },
        "treatment_algorithm": {
            "asymptomatic": {
                "indication_for_cea": ">60-80% при низком риске",
                "medical_therapy": "Аспирин, статины, контроль рисков"
            },
            "symptomatic": {
                "indication_for_cea": ">50% (предпочтительно >70%)",
                "timing": "В течение 2 недель от события",
                "alternative": "CAS при высоком риске"
            }
        },
        "cea_vs_cas": {
            "cea_advantages": [
                "Лучшие долгосрочные результаты",
                "Ниже риск рестеноза",
                "Проверен временем"
            ],
            "cas_advantages": [
                "Минимально инвазивно",
                "Быстрое восстановление",
                "Лучше при высоком риске"
            ],
            "high_risk_for_cea": [
                "Сердечная недостаточность",
                "Тяжелая ХОБЛ",
                "Рецидивный стеноз",
                "Лучевая терапия шеи",
                "Высокая бифуркация"
            ]
        }
    },
    
    "aaa_management": {
        "name": "Аневризма брюшной аорты",
        "risk_factors": [
            "Возраст >65 лет (мужчины), >70 (женщины)",
            "Курение",
            "Семейный анамнез",
            "Гипертензия",
            "Атеросклероз",
            "Марфанов синдром",
            "Болезнь Бехчета"
        ],
        "screening": {
            "recommendation": "Разовое УЗИ для мужчин 65-75 лет, куривших",
            "women": "Селективно (семейный анамнез)"
        },
        "size_criteria": {
            "normal": "<3 см",
            "ectasia": "3-4 см",
            "small_aneurysm": "4-5.4 см",
            "medium_aneurysm": "5.5-6.9 см",
            "large_aneurysm": ">7 см"
        },
        "treatment_thresholds": {
            "men": {
                "asymptomatic": ">5.5 см",
                "symptomatic": ">5.0 см или рост >0.5 см за 6 мес"
            },
            "women": {
                "asymptomatic": ">5.0 см",
                "symptomatic": ">4.5 см"
            }
        },
        "treatment_algorithm": {
            "step_1": "Оценка размера и роста",
            "step_2": "Оценка риска операции",
            "step_3": "Выбор подхода:",
            "evar": {
                "indications": [
                    "Подходящая анатомия (шейка >15 мм, <32 мм)",
                    "Высокий риск открытой операции",
                    "Возраст >75 лет"
                ],
                "contraindications": [
                    "Короткая/широкая шейка",
                    "Тяжелый кальциноз",
                    "Загрязнение брюшной полости"
                ]
            },
            "open_repair": {
                "indications": [
                    "Неподходящая анатомия для EVAR",
                    "Молодой возраст",
                    "Загрязнение брюшной полости"
                ],
                "approach": "Трансперитонеальный или ретроперитонеальный"
            }
        },
        "surveillance": {
            "4.0_5.4_cm": "УЗИ каждые 6-12 месяцев",
            "5.5_6.9_cm": "УЗИ каждые 3-6 месяцев",
            ">7_cm": "Рассмотреть операцию"
        }
    },
    
    "claudication_workup": {
        "name": "Клаудикация",
        "definition": "Боль в мышцах при ходьбе, проходящая при отдыхе",
        "differential": [
            "Спинальный стеноз (боль при стоянии, не при ходьбе)",
            "Артрит суставов",
            "Венозная клаудикация",
            "Нейропатия"
        ],
        "workup": {
            "step_1": "Анамнез и физический осмотр",
            "step_2": "АКШ ( resting и после нагрузки)",
            "step_3": "Дуплексное УЗИ для локализации",
            "step_4": "КТ-ангиография при планировании интервенции"
        },
        "conservative_treatment": {
            "lifestyle": [
                "Отказ от курения (критически важно!)",
                "Ходьба 30-60 минут 3-5 раз/неделю",
                "Контроль веса"
            ],
            "medical": [
                "Антипластинки (аспирин или клопидогрель)",
                "Статины (высокая интенсивность)",
                "Контроль АД (<130/80)",
                "Контроль диабета (HbA1c <7%)",
                "Цилостазол (для клаудикации)"
            ]
        },
        "revascularization": {
            "indications": [
                "Клаудикация, ограничивающая образ жизни",
                "Неэффективность консервативного лечения 3-6 мес",
                "Гемодинамически значимый стеноз"
            ],
            "endovascular_first": [
                "Аорто-подвздошные поражения (TASC A-C)",
                "Бедренно-подколенные поражения (TASC A-B)"
            ],
            "surgery_first": [
                "Тяжелая клаудикация с хорошей веной",
                "Длинные окклюзии (TASC C-D)"
            ]
        }
    },
    
    "clti_management": {
        "name": "CLTI (Chronic Limb-Threatening Ischemia)",
        "definition": "Критическая ишемия с покойной болью, трофическими язвами или гангреной",
        "wifI_classification": {
            "wound": {
                "0": "Нет язвы",
                "1": "Маленькая язва, дистальная",
                "2": "Большая язва, проксимальная",
                "3": "Обширная язва/гангрена"
            },
            "ischemia": {
                "0": "АКШ >0.80",
                "1": "АКШ 0.60-0.79",
                "2": "АКШ 0.40-0.59",
                "3": "АКШ <0.40"
            },
            "foot_infection": {
                "0": "Нет инфекции",
                "1": "Местная инфекция",
                "2": "Обширная инфекция",
                "3": "Системная инфекция"
            }
        },
        "treatment_algorithm": {
            "step_1": "Оценка WIfI",
            "step_2": "Оценка возможности реваскуляризации",
            "step_3": "Решение о стратегии:",
            "revascularization": {
                "goal": "Максимизировать кровоток к ране",
                "direct": "Прямая реваскуляризация к ангиосоме",
                "indirect": "Через коллатерали (если прямая невозможна)"
            },
            "wound_care": [
                "Дебридмент",
                "Антибиотики при инфекции",
                "Разгрузка давления",
                "Регулярные перевязки"
            ],
            "amputation": {
                "indication": "Нежизнеспособная конечность",
                "goal": "Минимальная ампутация с функциональным результатом"
            }
        },
        "best_cli_trial": {
            "finding": "Хирургия лучше эндоваскулярного при наличии хорошей вены",
            "note": "При отсутствии вены - сопоставимые результаты"
        }
    }
}


# ==================== АНАТОМИЯ ДЛЯ ХИРУРГОВ (Netter Atlas) ====================

SURGICAL_ANATOMY = {
    "carotid_bifurcation": {
        "name": "Бифуркация сонной артерии",
        "landmarks": {
            "superior": "Двубрюшная мышца (digastric)",
            "inferior": "Подъязычная мышца (omohyoid)",
            "medial": "Внутренняя яремная вена",
            "posterior": "Симпатический ствол, блуждающий нерв"
        },
        "structures_to_identify": [
            "Общая сонная артерия (CCA)",
            "Внутренняя сонная артерия (ICA)",
            "Наружная сонная артерия (ECA)",
            "Верхняя щитовидная артерия",
            "Подъязычный нерв (hypoglossal)",
            "Блуждающий нерв (vagus)"
        ],
        "incision": {
            "longitudinal": "Вдоль переднего края грудино-ключично-сосцевидной мышцы",
            "transverse": "Поперечный разрев (косметически лучше)"
        },
        "key_points": [
            "Лигировать лицевую вену для доступа",
            "Не травмировать блуждающий нерв (медиально)",
            "Не травмировать подъязычный нерв (проходит над бифуркацией)"
        ]
    },
    
    "aorta_abdominal": {
        "name": "Брюшная аорта",
        "segments": {
            "supraceliac": "Выше чревного ствола",
            "paravisceral": "Между чревным стволом и почечными артериями",
            "infrarenal": "Ниже почечных артерий"
        },
        "branches": [
            {"name": "Чревный ствол", "level": "T12-L1"},
            {"name": "Верхняя брыжеечная артерия", "level": "L1"},
            {"name": "Почечные артерии", "level": "L1-L2"},
            {"name": "Нижняя брыжеечная артерия", "level": "L3"},
            {"name": "Поясничные артерии", "level": "L1-L4"}
        ],
        "exposure": {
            "transperitoneal": {
                "approach": "Срединная лапаротомия",
                "mobilization": "Отведение тощей кишки вправо",
                "note": "Стандартный подход"
            },
            "retroperitoneal": {
                "approach": "Разрез по 11 ребру",
                "indication": "Ранее оперированный живот, ожирение"
            }
        },
        "key_anatomy": [
            "Нижняя полая вена справа",
            "Уретеры позади бифуркации",
            "Восходящая часть тощей кишки справа"
        ]
    },
    
    "femoral_triangle": {
        "name": "Паховый треугольник (Scarpa)",
        "boundaries": {
            "superior": "Паховая связка",
            "lateral": "Грудино-подвздошная мышца",
            "medial": "Подвздошно-поясничная мышца"
        },
        "contents_from_lateral_to_medial": {
            "nerve": "Бедренный нерв (N)",
            "artery": "Общая бедренная артерия (A)",
            "vein": "Общая бедренная вена (V)",
            "lymphatics": "Лимфатические сосуды (L)",
            "empty": "Пустое пространство (E)"
        },
        "mnemonic": "NAVEL (Nerve, Artery, Vein, Empty, Lymphatics)",
        "femoral_artery_branches": [
            "Поверхная бедренная артерия",
            "Глубокая бедренная артерия (profunda femoris)"
        ],
        "surgical_approach": {
            "incision": "Разрез над пульсацией, параллельно паховой связке",
            "landmark": "2 см ниже паховой связки",
            "key_step": "Идентифицировать бифуркацию общей бедренной"
        }
    },
    
    "popliteal_fossa": {
        "name": "Подколенная ямка",
        "boundaries": {
            "superolateral": "Двуглавая мышца бедра",
            "superomedial": "Полусухожильная мышца",
            "inferior": "Икроножные мышцы"
        },
        "contents_from_deep_to_superficial": [
            "Подколенная артерия",
            "Подколенная вена",
            "Бедренный нерв",
            "Малоберцовый нерв"
        ],
        "approaches": {
            "medial": {
                "position": "Пронация",
                "incision": "Медиально от колена",
                "advantage": "Стандартный подход"
            },
            "posterior": {
                "position": "Пронация",
                "incision": "Поперечный разрез в ямке",
                "advantage": "Прямой доступ"
            },
            "lateral": {
                "position": "Супинация с согнутым коленом",
                "incision": "Латерально от колена",
                "advantage": "Для доступа к проксимальной подколенной"
            }
        }
    },
    
    "aortic_arch_branches": {
        "name": "Ветви дуги аорты",
        "brachiocephalic_trunk": {
            "name": "Брахиоцефальный ствол",
            "branches": [
                "Правая подключичная артерия",
                "Правая общая сонная артерия"
            ]
        },
        "left_common_carotid": "Левая общая сонная артерия",
        "left_subclavian": "Левая подключичная артерия",
        "surgical_considerations": [
            "При TEVAR может потребоваться debranching",
            "Каротидо-субклавианское шунтирование",
            "Транспозиция ЛПА"
        ]
    },
    
    "venous_anatomy": {
        "name": "Венозная анатомия нижних конечностей",
        "superficial_system": {
            "great_saphenous": {
                "origin": "Перед медиальной лодыжкой",
                "course": "Медиально от колена, до паховой связки",
                "termination": "Подвздошная вена (сапено-феморальное соединение)"
            },
            "small_saphenous": {
                "origin": "Перед латеральной лодыжкой",
                "course": "Задняя поверхность голени",
                "termination": "Подколенная вена"
            }
        },
        "deep_system": [
            "Подвздошные вены",
            "Общая бедренная вена",
            "Глубокая бедренная вена",
            "Подколенная вена",
            "Передние/задние большеберцовые вены"
        ],
        "perforators": {
            "definition": "Соединяют поверхностные и глубокие вены",
            "clinical": "Некомпетентность → варикозное расширение"
        }
    }
}


# ==================== ОПЕРАТИВНЫЕ ТЕХНИКИ (Sabiston + Atlases) ====================

OPERATIVE_TECHNIQUES = {
    "carotid_endarterectomy_detailed": {
        "name": "Каротидная эндартерэктомия (подробно)",
        "positioning": "Супинация, подложить подушку под плечи, голова повернута",
        "incision": "Вдоль переднего края ГКСМ, от двубрюшной до подъязычной мышцы",
        "steps": [
            {
                "step": 1,
                "action": "Рассечение кожи и подкожной клетчатки",
                "note": "Идентифицировать ГКСМ"
            },
            {
                "step": 2,
                "action": "Лигирование лицевой вены",
                "note": "Дает доступ к бифуркации"
            },
            {
                "step": 3,
                "action": "Идентификация CCA, ICA, ECA",
                "note": "Обвязать петлями (не затягивать ICA)"
            },
            {
                "step": 4,
                "action": "Гепарин 5000 ЕД в/в",
                "note": "Ждать 3-5 минут"
            },
            {
                "step": 5,
                "action": "Зажимы: ICA, CCA, ECA (последовательность ICE)",
                "note": "Записать время пережатия"
            },
            {
                "step": 6,
                "action": "Артериотомия от CCA до ICA",
                "note": "За пределами бляшки"
            },
            {
                "step": 7,
                "action": "Эндартерэктомия",
                "note": "Плоскость между intima и media"
            },
            {
                "step": 8,
                "action": "Tacking sutures (при необходимости)",
                "note": "6-0 или 7-0 Prolene"
            },
            {
                "step": 9,
                "action": "Заплатная пластика",
                "note": "Сапенозная вена, PTFE, или перикард"
            },
            {
                "step": 10,
                "action": "Снятие зажимов: ECA → CCA → ICA",
                "note": "Следить за гипотензией"
            }
        ],
        "shunt_usage": {
            "indications": [
                "Противоположная окклюзия",
                "Симптоматический стеноз",
                "Изменения на ВП"
            ],
            "technique": "Вставить до начала эндартерэктомии"
        },
        "patch_options": {
            "vein": "Великая сапенозная (лучший выбор)",
            "ptfe": "Для больших артерий",
            "bovine_pericardium": "Хорошие результаты"
        },
        "completion_studies": [
            "Допплеровское УЗИ",
            "Ангиография (при подозрении)"
        ]
    },
    
    "aortobifemoral_bypass": {
        "name": "Аорто-бифеморальное шунтирование",
        "indication": "Тяжелая аорто-подвздошная окклюзия (TASC C-D)",
        "positioning": "Супинация",
        "incisions": [
            "Срединная лапаротомия (живот)",
            "Два паховых разреза (обе стороны)"
        ],
        "steps": [
            {
                "step": 1,
                "action": "Лапаротомия, отведение кишок вправо",
                "note": "Вход в забрюшинное пространство"
            },
            {
                "step": 2,
                "action": "Мобилизация левой половины ободочной кишки (при необходимости)",
                "note": "Доступ к парависцеральной аорте"
            },
            {
                "step": 3,
                "action": "Выделение аорты (ниже почечных артерий)",
                "note": "Контроль выше и ниже"
            },
            {
                "step": 4,
                "action": "Гепарин 100 ЕД/кг (ACT >250 сек)",
                "note": ""
            },
            {
                "step": 5,
                "action": "Пережатие аорты",
                "note": "Проксимально и дистально"
            },
            {
                "step": 6,
                "action": "Артериотомия аорты",
                "note": "Продольная или поперечная"
            },
            {
                "step": 7,
                "action": "Анастомоз протеза (end-to-end или end-to-side)",
                "note": "3-0 или 4-0 Prolene"
            },
            {
                "step": 8,
                "action": "Туннелизация конечностей протеза",
                "note": "За уретерами, в пах"
            },
            {
                "step": 9,
                "action": "Паховые анастомозы (end-to-side)",
                "note": "4-0 или 5-0 Prolene"
            },
            {
                "step": 10,
                "action": "Закрытие ретроперитонеума",
                "note": "Изолировать протез от кишок!"
            }
        ],
        "graft_material": "Dacron (тканый или коллаген-импрегнированный)",
        "complications": [
            "Аорто-энтеральная фистула",
            "Тромбоз",
            "Инфекция",
            "Ишемия толстой кишки"
        ]
    },
    
    "femoropopliteal_bypass_detailed": {
        "name": "Бедренно-подколенное шунтирование (подробно)",
        "positioning": "Супинация, бедро слегка согнуто и отведено",
        "incisions": [
            "Паховый разрез (доступ к общей бедренной)",
            "Медиальный разрез над коленом (доступ к подколенной)",
            "Разрез для взятия вены (если используется ВСВ)"
        ],
        "conduit_selection": {
            "order": [
                "Великая сапенозная вена (in situ или reversed)",
                "Малая сапенозная вена",
                "Радиальная вена",
                "PTFE (последний выбор для инфраингвинальных)"
            ]
        },
        "steps": [
            {
                "step": 1,
                "action": "Подготовка вены (если используется)",
                "note": "In situ или reversed"
            },
            {
                "step": 2,
                "action": "Выделение общей бедренной артерии",
                "note": "Проксимальный и дистальный контроль"
            },
            {
                "step": 3,
                "action": "Выделение подколенной артерии",
                "note": "Медиальный подход"
            },
            {
                "step": 4,
                "action": "Создание туннеля",
                "note": "Подкожно или подмышечно"
            },
            {
                "step": 5,
                "action": "Гепарин 5000 ЕД в/в",
                "note": ""
            },
            {
                "step": 6,
                "action": "Проксимальная анастомоз",
                "note": "End-to-side к общей бедренной"
            },
            {
                "step": 7,
                "action": "Проверка оттока",
                "note": "Открыть дистальную бедренную"
            },
            {
                "step": 8,
                "action": "Пропускание шунта через туннель",
                "note": "Без перекручивания"
            },
            {
                "step": 9,
                "action": "Дистальная анастомоз",
                "note": "End-to-side к подколенной"
            },
            {
                "step": 10,
                "action": "Допплеровский контроль",
                "note": "PSV <200 см/с"
            }
        ],
        "patency_rates": {
            "above_knee_vein": {
                "primary_1yr": "75-80%",
                "primary_5yr": "60-65%"
            },
            "below_knee_vein": {
                "primary_1yr": "70-75%",
                "primary_5yr": "50-55%"
            },
            "ptfe": {
                "primary_1yr": "50-60%",
                "primary_5yr": "30-40%"
            }
        }
    },
    
    "evar_step_by_step": {
        "name": "EVAR (пошагово)",
        "preparation": [
            "Антибиотики (цефазolin 2 г)",
            "Гепарин 5000 ЕД (после доступа)",
            "Контрастная защита (гидратация)"
        ],
        "access": {
            "percutaneous": "Pre-close technique с Perclose",
            "cutdown": "При тяжелом кальцинозе"
        },
        "steps": [
            {
                "step": 1,
                "action": "Бедренный доступ (обе стороны)",
                "note": "УЗ-наведение"
            },
            {
                "step": 2,
                "action": "Введение больших шитов (18-24F)",
                "note": "Осторожно при кальцинозе"
            },
            {
                "step": 3,
                "action": "Аортография",
                "note": "Определить почечные артерии"
            },
            {
                "step": 4,
                "action": "Позиционирование основного тела",
                "note": "Точное позиционирование в шейке"
            },
            {
                "step": 5,
                "action": "Развертывание основного тела",
                "note": "Контроль давления АД"
            },
            {
                "step": 6,
                "action": "Канюляция contralateral gate",
                "note": "Провести проводник"
            },
            {
                "step": 7,
                "action": "Развертывание contralateral limb",
                "note": "Перекрыть contralateral подвздошную"
            },
            {
                "step": 8,
                "action": "Развертывание ipsilateral limb",
                "note": ""
            },
            {
                "step": 9,
                "action": "Баллонирование",
                "note": "Проксимально и дистально"
            },
            {
                "step": 10,
                "action": "Финальная аортография",
                "note": "Оценить endoleak"
            }
        ],
        "completion_angiography": {
            "assess": [
                "Позиция стент-графта",
                "Endoleak (Type I, II, III)",
                "Патентность почечных артерий",
                "Патентность внутренних подвздошных"
            ]
        }
    },
    
    "varicose_vein_surgery": {
        "name": "Операция при варикозной болезни",
        "positioning": "Супинация, нога слегка согнута",
        "steps": [
            {
                "step": 1,
                "action": "Разрез в паху",
                "note": "2-3 см выше паховой складки"
            },
            {
                "step": 2,
                "action": "Идентификация сапено-феморального соединения",
                "note": "ВСВ впадает в подвздошную вену"
            },
            {
                "step": 3,
                "action": "Лигирование всех притоков",
                "note": "Поверхняя/глубокая бедренная, наружная подвздошная"
            },
            {
                "step": 4,
                "action": "Перевязка ВСВ у устья",
                "note": "Flush ligation"
            },
            {
                "step": 5,
                "action": "Стриппинг ВСВ",
                "note": "До колена (обычно) или до лодыжки"
            },
            {
                "step": 6,
                "action": "Минифлебэктомия",
                "note": "Крючки Мюллера"
            },
            {
                "step": 7,
                "action": "Закрытие",
                "note": "Компрессионная повязка"
            }
        ],
        "endovenous_alternatives": [
            "Лазерная облитерация (EVLA)",
            "Радиочастотная облитерация (RFA)",
            "Пенная склеротерапия"
        ]
    }
}


# ==================== ФАРМАКОТЕРАПИЯ (ACC/AHA Guidelines) ====================

PHARMACOTHERAPY = {
    "antiplatelet_therapy": {
        "aspirin": {
            "dose": "75-325 мг/сут",
            "indication": "Все пациенты с PAD (если нет противопоказаний)",
            "note": "Первый выбор"
        },
        "clopidogrel": {
            "dose": "75 мг/сут",
            "indication": "Альтернатива аспирину или в комбинации",
            "note": "CAPRIE trial: лучше аспирина при PAD"
        },
        "dual_antiplatelet": {
            "indications": [
                "После CAS (минимум 1 месяц)",
                "После коронарного стентирования",
                "Высокий сердечно-сосудистый риск"
            ],
            "duration": "1-12 месяцев в зависимости от показания"
        }
    },
    
    "statins": {
        "indication": "Все пациенты с PAD",
        "goal": "LDL <70 мг/дл при высоком риске, <100 мг/дл при умеренном",
        "high_intensity": ["Аторвастатин 40-80 мг", "Розувастатин 20-40 мг"],
        "benefits": [
            "Снижение сердечно-сосудистых событий",
            "Замедление прогрессирования PAD",
            "Улучшение симптомов клаудикации"
        ]
    },
    
    "antihypertensives": {
        "goal": "<130/80 мм рт.ст.",
        "first_line": [
            "АПФ ингибиторы (рамиприл)",
            "АРБ",
            "Тиазидные диуретики",
            "Дигидропиридиновые CCB"
        ],
        "note": "Бета-блокаторы не противопоказаны при PAD"
    },
    
    "diabetes_management": {
        "goal_hba1c": "<7% (индивидуализировать)",
        "medications": {
            "metformin": "Первый выбор (если eGFR >30)",
            "sglt2_inhibitors": "Предпочтительны (сердечно-сосудистая защита)",
            "glp1_agonists": "Предпочтительны (сердечно-сосудистая защита)"
        }
    },
    
    "cilostazol": {
        "indication": "Симптоматическая клаудикация",
        "dose": "100 мг 2 раза/день",
        "contraindications": ["Сердечная недостаточность", "Геморрагический диатез"],
        "effect": "Увеличивает дистанцию ходьбы на 40-50%"
    },
    
    "anticoagulation": {
        "indications": [
            "ТГВ/ТЭЛА",
            "Механические клапаны сердца",
            "Фибрилляция предсердий",
            "После некоторых реваскуляризаций"
        ],
        "warfarin": {
            "target_inr": "2.0-3.0 (обычно)"
        },
        "noacs": {
            "advantages": "Не требуют мониторинга, меньше взаимодействий"
        }
    }
}


# ==================== ФУНКЦИИ ДЛЯ API ====================

def get_clinical_algorithm(condition: str, patient_data: Dict[str, Any] = None) -> Dict[str, Any]:
    """
    Получить клинический алгоритм для состояния
    """
    algorithm = CLINICAL_ALGORITHMS.get(condition)
    
    if not algorithm:
        return {
            "error": f"Algorithm not found for {condition}",
            "available": list(CLINICAL_ALGORITHMS.keys())
        }
    
    result = {
        "condition": condition,
        "algorithm": algorithm
    }
    
    # Добавить персонализированные рекомендации если есть данные пациента
    if patient_data:
        recommendations = []
        
        if condition == "aaa_management":
            diameter = patient_data.get("aaa_diameter", 0)
            if diameter < 4.0:
                recommendations.append("Наблюдение (УЗИ каждые 2-3 года)")
            elif diameter < 5.5:
                recommendations.append("Наблюдение (УЗИ каждые 6-12 мес)")
            else:
                recommendations.append("Рассмотреть операцию")
        
        result["personalized_recommendations"] = recommendations
    
    return result


def get_surgical_anatomy(region: str) -> Dict[str, Any]:
    """
    Получить анатомические детали для региона
    """
    anatomy = SURGICAL_ANATOMY.get(region)
    
    if not anatomy:
        return {
            "error": f"Anatomy not found for {region}",
            "available_regions": list(SURGICAL_ANATOMY.keys())
        }
    
    return {
        "region": region,
        "anatomy": anatomy
    }


def get_operative_technique(procedure: str, step_number: int = None) -> Dict[str, Any]:
    """
    Получить оперативную технику
    """
    technique = OPERATIVE_TECHNIQUES.get(procedure)
    
    if not technique:
        return {
            "error": f"Technique not found for {procedure}",
            "available_procedures": list(OPERATIVE_TECHNIQUES.keys())
        }
    
    result = {
        "procedure": procedure,
        "technique": technique
    }
    
    # Если запрошен конкретный шаг
    if step_number and "steps" in technique:
        steps = technique["steps"]
        if step_number <= len(steps):
            result["requested_step"] = steps[step_number - 1]
        else:
            result["error"] = f"Step {step_number} not found. Total steps: {len(steps)}"
    
    return result


def get_pharmacotherapy_guideline(medication_class: str) -> Dict[str, Any]:
    """
    Получить руководство по фармакотерапии
    """
    guideline = PHARMACOTHERAPY.get(medication_class)
    
    if not guideline:
        return {
            "error": f"Guideline not found for {medication_class}",
            "available_classes": list(PHARMACOTHERAPY.keys())
        }
    
    return {
        "medication_class": medication_class,
        "guideline": guideline
    }


def search_atlas(query: str) -> Dict[str, Any]:
    """
    Поиск по атласу
    """
    results = {
        "algorithms": [],
        "anatomy": [],
        "techniques": [],
        "pharmacotherapy": []
    }
    
    query_lower = query.lower()
    
    # Поиск в алгоритмах
    for key, value in CLINICAL_ALGORITHMS.items():
        if query_lower in key.lower() or query_lower in str(value).lower():
            results["algorithms"].append(key)
    
    # Поиск в анатомии
    for key, value in SURGICAL_ANATOMY.items():
        if query_lower in key.lower() or query_lower in str(value).lower():
            results["anatomy"].append(key)
    
    # Поиск в техниках
    for key, value in OPERATIVE_TECHNIQUES.items():
        if query_lower in key.lower() or query_lower in str(value).lower():
            results["techniques"].append(key)
    
    return results
