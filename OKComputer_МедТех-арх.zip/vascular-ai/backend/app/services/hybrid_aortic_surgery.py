"""
VASCULAR.AI - Гибридная хирургия аорты
На основе:
- Гибридная хирургия расслоения аорты (Козлов, Панфилов)
- Acute Aortic Disease (Elefteriades)
- Acute Aneurysm Surgery (Sano, Asano, Tamura)
"""

from typing import Dict, Any, List, Optional


# ==================== РАССЛОЕНИЕ АОРТЫ ====================

AORTIC_DISSECTION = {
    "classification": {
        "stanford": {
            "type_a": {
                "description": "Вовлекает восходящую аорту (независимо от начала)",
                "incidence": "60-70%",
                "treatment": "Срочная операция",
                "mortality_without_surgery": "1-2% в час первые 48 часов"
            },
            "type_b": {
                "description": "Не вовлекает восходящую аорту",
                "incidence": "30-40%",
                "treatment": "Медикаментозная терапия (если неосложненное)",
                "surgical_indication": "Осложненное (мальперфузия, разрыв, расширение)"
            }
        },
        "debakey": {
            "type_1": "Восходящая + дуга + нисходящая",
            "type_2": "Только восходящая",
            "type_3": "Только нисходящая (начинается дистально левой подключичной)"
        }
    },
    
    "clinical_presentation": {
        "symptoms": [
            "Резкая боль в груди (90%)",
            "Иррадиация в спину (70%)",
            "Разница АД на руках (>20 мм рт.ст.)",
            "Неврологические симптомы (5-10%)",
            "Синкопе",
            "Олигурия/анурия (почечная мальперфузия)"
        ],
        "physical_findings": [
            "Новый неврологический дефицит",
            "Асимметрия пульсаций",
            "Шум аортальной регургитации",
            "Затруднение дыхания (перикардиальный выпот)"
        ]
    },
    
    "diagnosis": {
        "first_line": "КТ-ангиография (100% чувствительность)",
        "alternative": "Трансэзофагеальная ЭхоКГ",
        "mri": "При нефункционирующих почках",
        "aortography": "Редко (при планировании интервенции)",
        "biomarkers": {
            "d_dimer": "Высокий (но неспецифичный)",
            "smooth_muscle_myosin": "Специфичный, но недоступен"
        }
    },
    
    "medical_management": {
        "goals": [
            "Снизить dp/dt (силу удара)",
            "Контроль АД",
            "Обезболивание"
        ],
        "medications": {
            "beta_blockers": {
                "first_line": "Эсмолол (0.5 мг/кг болюс, затем 50-200 мкг/кг/мин)",
                "alternative": "Лабеталол 20 мг в/в, затем 40-80 мг каждые 10-15 мин (макс 300 мг)"
            },
            "vasodilators": {
                "indication": "Если АД не контролируется бета-блокаторами",
                "agents": ["Нитропруссид натрия 0.25-10 мкг/кг/мин", "Урапидил"]
            },
            "analgesia": {
                "morphine": "2-4 мг в/в каждые 5-15 мин"
            }
        },
        "target": {
            "systolic_bp": "100-120 мм рт.ст.",
            "heart_rate": "60-80 уд/мин"
        }
    },
    
    "type_a_treatment": {
        "timing": "Срочно (в течение нескольких часов)",
        "surgical_techniques": {
            "standard": {
                "name": "Стандартная замена восходящей аорты",
                "approach": "Срединная стернотомия",
                "cannulation": "Правый подвздошный артерий + правое предсердие",
                "technique": "Гипотермическая остановка циркуляции (18-20°C)",
                "cerebral_protection": "Антеградная селективная перфузия",
                "repair": "Замена восходящей аорты с реимплантацией коронарных артерий"
            },
            "arch_repair": {
                "name": "Замена дуги аорты",
                "indication": "Вовлечение дуги",
                "technique": "Hemiarch или total arch replacement",
                "elephant_trunk": "Для последующего TEVAR"
            },
            "frozen_elephant_trunk": {
                "name": "Frozen elephant trunk",
                "indication": "Вовлечение дуги и нисходящей аорты",
                "technique": "Одностадийная замена с имплантацией stent-графта в нисходящую аорту"
            }
        },
        "complications": {
            "mortality": "15-25%",
            "stroke": "5-10%",
            "paraplegia": "2-5%",
            "renal_failure": "10-20%",
            "bleeding": "10-15%"
        }
    },
    
    "type_b_treatment": {
        "uncomplicated": {
            "treatment": "Медикаментозная терапия",
            "monitoring": "КТ-ангиография через 24-48 часов, затем еженедельно",
            "follow_up": "КТ-ангиография каждые 3-6 месяцев"
        },
        "complicated": {
            "indications": [
                "Мальперфузия (почки, кишечник, конечности)",
                "Расширение аорты",
                "Разрыв или угроза разрыва",
                "Рецидивирующая боль",
                "Неконтролируемая гипертензия"
            ],
            "treatment": "TEVAR (предпочтительно) или открытая операция",
            "tevar_timing": "В течение 24-72 часов"
        }
    },
    
    "hybrid_procedures": {
        "arch_debranching": {
            "name": "Debranching дуги аорты",
            "indication": "Зона 0-2 для TEVAR",
            "technique": [
                "Каротидо-каротидное шунтирование",
                "Левой подключичной артерии к левой общей сонной",
                "Транспозиция ЛПА"
            ],
            "timing": "Сразу перед TEVAR или staged"
        },
        "frozen_elephant_trunk": {
            "name": "Frozen elephant trunk",
            "indication": "Расслоение типа А с вовлечением дуги и нисходящей",
            "technique": "Замена дуги с stent-графтом в нисходящую аорту",
            "advantage": "Одностадийное лечение"
        }
    }
}


# ==================== ИНТРАМУРАЛЬНАЯ ГЕМАТОМА ====================

INTRAMURAL_HEMATOMA = {
    "definition": "Гематома в стенке аорты без intimal tear",
    "pathophysiology": "Разрыв vasa vasorum или кровоизлияние в атеросклеротическую бляшку",
    "classification": "Та же, что и для расслоения (Stanford A/B)",
    
    "diagnosis": {
        "ct": "Утолщение стенки аорты (>7 мм), crescent sign",
        "mri": "T1 hyperintense (subacute)",
        "te_echo": "Утолщение стенки без intimal flap"
    },
    
    "treatment": {
        "type_a": "Операция (аналогично расслоению типа А)",
        "type_b": "Медикаментозная терапия + наблюдение (аналогично расслоению типа В)"
    },
    
    "progression": "10-30% прогрессируют в расслоение или аневризму"
}


# ==================== ПРОНИКАЮЩАЯ АТЕРОСКЛЕРОТИЧЕСКАЯ ЯЗВА ====================

PENETRATING_AORTIC_ULCER = {
    "definition": "Язва атеросклеротической бляшки, проникающая через intima",
    "imaging": "Язва с утолщением стенки, часто сопутствующая IMH",
    
    "treatment": {
        "asymptomatic": "Медикаментозная терапия + наблюдение",
        "symptomatic": "TEVAR (предпочтительно) или операция",
        "rupture_risk": "Высокий - срочное лечение"
    }
}


# ==================== ТРАВМАТИЧЕСКОЕ ПОВРЕЖДЕНИЕ АОРТЫ ====================

TRAUMATIC_AORTIC_INJURY = {
    "mechanism": "Резкое замедление (ДТП с высокой скоростью, падение с высоты)",
    "location": "Истмус (90%) - лигаментум артериозум",
    "grading": {
        "grade_1": {"name": "Intimal tear", "treatment": "Медикаментозная терапия + наблюдение"},
        "grade_2": {"name": "Intramural hematoma", "treatment": "TEVAR или наблюдение"},
        "grade_3": {"name": "Pseudoaneurysm", "treatment": "TEVAR"},
        "grade_4": {"name": "Rupture", "treatment": "Срочная операция или TEVAR"}
    },
    
    "associated_injuries": [
        "Переломы рёбер",
        "Пневмоторакс",
        "Повреждение головы",
        "Повреждение брюшных органов",
        "Переломы конечностей"
    ],
    
    "treatment": {
        "stable": "TEVAR (предпочтительно) или операция",
        "unstable": "Damage control surgery",
        "medical": "Антигипертензивная терапия (бета-блокаторы)"
    }
}


# ==================== ГИБРИДНЫЕ ПРОЦЕДУРЫ ====================

HYBRID_PROCEDURES = {
    "definition": "Комбинация открытой и эндоваскулярной техники",
    
    "arch_debranching": {
        "name": "Debranching дуги аорты + TEVAR",
        "indications": [
            "Зона 0-2 для TEVAR",
            "Расслоение типа А с вовлечением дуги",
            "Аневризма дуги аорты"
        ],
        "techniques": {
            "carotid_carotid_bypass": {
                "name": "Каротидо-каротидное шунтирование",
                "approach": "Шейный разрез с обеих сторон",
                "graft": "8-10 мм PTFE или Dacron"
            },
            "left_subclavian_revascularization": {
                "name": "Реваскуляризация левой подключичной",
                "options": [
                    "Каротидо-субклавианское шунтирование",
                    "Транспозиция ЛПА на ЛОСА"
                ]
            }
        },
        "timing": "Staged (1-2 недели между) или одномоментно",
        "advantages": [
            "Избегают sternotomy",
            "Меньше инвазивно",
            "Подходят для высокорисковых пациентов"
        ]
    },
    
    "thoracoabdominal_hybrid": {
        "name": "Гибридное лечение торакобрюшной аорты",
        "indication": "Торакоабдоминальная аневризма Crawford I-II",
        "technique": [
            "Деэндартерэктомия висцеральных ветвей",
            "Bypass к висцеральным артериям",
            "TEVAR для покрытия аневризмы"
        ],
        "advantage": "Избегают обширной торакобрюшной операции"
    },
    
    "frozen_elephant_trunk": {
        "name": "Frozen elephant trunk",
        "indication": [
            "Расслоение типа А с вовлечением дуги и нисходящей",
            "Аневризма дуги с распространением в нисходящую"
        ],
        "technique": [
            "Замена дуги аорты",
            "Имплантация stent-графта в нисходящую аорту через дугу",
            "Закрепление stent-графта к протезу дуги"
        ],
        "advantages": [
            "Одностадийное лечение",
            "Предотвращает ремоделирование ложного просвета",
            "Готовит landing zone для будущего TEVAR"
        ],
        "complications": [
            "Параплегия (5-10%)",
            "Парез ларингического нерва",
            "Кровотечение"
        ]
    }
}


# ==================== ФУНКЦИИ ДЛЯ API ====================

def get_dissection_management(stanford_type: str, complicated: bool,
                              malperfusion: List[str] = None) -> Dict[str, Any]:
    """
    Получить протокол лечения расслоения аорты
    """
    if stanford_type == "A":
        return {
            "diagnosis": "Stanford Type A",
            "urgency": "Срочная операция (в течение нескольких часов)",
            "mortality_without_surgery": "1-2% в час",
            "treatment": "Операция:",
            "options": [
                "Замена восходящей аорты",
                "Замена дуги (при вовлечении)",
                "Frozen elephant trunk (при вовлечении нисходящей)"
            ],
            "medical_preparation": [
                "Бета-блокаторы (эсмолол или лабеталол)",
                "Целевое АД: систолическое 100-120 мм рт.ст.",
                "ЧСС: 60-80 уд/мин",
                "Анальгезия (морфин)"
            ]
        }
    else:  # Type B
        if complicated:
            return {
                "diagnosis": "Stanford Type B (осложненное)",
                "indications_for_intervention": malperfusion or [
                    "Мальперфузия органов",
                    "Расширение аорты",
                    "Разрыв или угроза разрыва"
                ],
                "treatment": "TEVAR (предпочтительно) или открытая операция",
                "timing": "В течение 24-72 часов",
                "medical_preparation": "Аналогично типу А"
            }
        else:
            return {
                "diagnosis": "Stanford Type B (неосложненное)",
                "treatment": "Медикаментозная терапия",
                "monitoring": [
                    "КТ-ангиография через 24-48 часов",
                    "Затем еженедельно",
                    "Затем каждые 3-6 месяцев"
                ],
                "medical_therapy": [
                    "Бета-блокаторы пожизненно",
                    "Контроль АД (систолическое <120)",
                    "Статины",
                    "Отказ от курения"
                ]
            }


def get_hybrid_procedure_indication(aneurysm_extent: str, 
                                    patient_risk: str) -> Dict[str, Any]:
    """
    Определить показания к гибридной процедуре
    """
    recommendations = []
    
    if aneurysm_extent == "arch":
        if patient_risk == "high":
            recommendations.append({
                "procedure": "Arch debranching + TEVAR",
                "rationale": "Менее инвазивно для высокорискового пациента",
                "stages": "Staged (1-2 недели между) или одномоментно"
            })
        else:
            recommendations.append({
                "procedure": "Open arch replacement",
                "rationale": "Лучшие долгосрочные результаты"
            })
    
    elif aneurysm_extent == "thoracoabdominal":
        recommendations.append({
            "procedure": "Hybrid repair (visceral debranching + TEVAR)",
            "rationale": "Избегает обширной торакобрюшной операции",
            "alternative": "Open repair при низком риске"
        })
    
    elif aneurysm_extent == "dissection_type_a":
        recommendations.append({
            "procedure": "Frozen elephant trunk",
            "rationale": "Одностадийное лечение расслоения с вовлечением дуги",
            "advantages": [
                "Предотвращает ремоделирование ложного просвета",
                "Готовит landing zone для будущего TEVAR"
            ]
        })
    
    return {
        "aneurysm_extent": aneurysm_extent,
        "patient_risk": patient_risk,
        "recommendations": recommendations
    }


def get_tevar_planning(proximal_landing_zone: str, 
                       need_debranching: bool) -> Dict[str, Any]:
    """
    Планирование TEVAR
    """
    zones = {
        "zone_0": "Проксимальная восходящая аорта",
        "zone_1": "Дистальная восходящая аорта",
        "zone_2": "Дуга аорты (покрытие ЛПА)",
        "zone_3": "Дистальная дуга/проксимальная нисходящая (покрытие ЛОСА)",
        "zone_4": "Проксимальная торакальная аорта"
    }
    
    planning = {
        "proximal_landing_zone": zones.get(proximal_landing_zone, "Unknown"),
        "debranching_required": need_debranching
    }
    
    if need_debranching:
        planning["debranching_options"] = [
            "Каротидо-каротидное шунтирование",
            "Каротидо-субклавианское шунтирование",
            "Транспозиция ЛПА"
        ]
        planning["timing"] = "Staged (1-2 недели) или одномоментно"
    
    planning["spinal_cord_protection"] = [
        "Поддержание MAP >90 мм рт.ст.",
        "Люмбальный дренаж (при покрытии T8-L1)",
        "Реваскуляризация ЛПклА при необходимости"
    ]
    
    return planning
