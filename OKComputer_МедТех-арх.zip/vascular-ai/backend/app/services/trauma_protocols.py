"""
VASCULAR.AI - Протоколы сосудистой травмы
Травматические повреждения сосудов, алгоритмы действий
"""

from typing import Dict, Any, List, Optional


# ==================== КЛАССИФИКАЦИЯ ТРАВМЫ СОСУДОВ ====================

VASCULAR_TRAUMA_CLASSIFICATION = {
    "mechanism": {
        "penetrating": {
            "name": "Проникающая травма",
            "causes": ["Нож", "Огнестрел", "Осколки", "Импalement"],
            "common_sites": ["Шея", "Пах", "Конечности"],
            "assessment": "Hard signs vs Soft signs"
        },
        "blunt": {
            "name": "Закрытая травма",
            "causes": ["ДТП", "Падение", "Спорт", "Удар"],
            "common_injuries": ["Расслоение", "Тромбоз", "АВ-фистула", "Псевдоаневризма"],
            "assessment": "Индекс сжатия, допплер, КТ-ангиография"
        },
        "iatrogenic": {
            "name": "Ятрогенная травма",
            "causes": ["Катетеризация", "Инъекции", "Операции", "Биопсия"],
            "common_sites": ["Подключичная артерия", "Паховая область", "Радиальная артерия"]
        }
    },
    
    "hard_signs": {
        "description": "Требуют немедленной операции",
        "signs": [
            "Массивное кровотечение",
            "Расширяющаяся гематома",
            "Шок без другой причины",
            "Ишемия конечности (6 P)",
            "Сосудистый шум + гематома (травматическая АВ-фистула)",
            "Пульсирующая гематома (псевдоаневризма)"
        ],
        "action": "Немедленная операция или ангиография"
    },
    
    "soft_signs": {
        "description": "Требуют обследования",
        "signs": [
            "История кровотечения в поле травмы",
            "Небольшая стабильная гематома",
            "Сосудистый шум без гематомы",
            "Неврологический дефицит в зоне травмы",
            "Пониженный пульс/АБП на конечности"
        ],
        "action": "КТ-ангиография или допплеровское обследование"
    },
    
    "grading": {
        "grade_1": {
            "description": "Intimal flap <25% окружности",
            "treatment": "Антикоагуляция, наблюдение"
        },
        "grade_2": {
            "description": "Intimal flap >25%, псевдоаневризма, АВ-фистула",
            "treatment": "Эндоваскулярное или открытое лечение"
        },
        "grade_3": {
            "description": "Трансекция, окклюзия",
            "treatment": "Оперативное восстановление"
        },
        "grade_4": {
            "description": "Сегментарная потеря, огромная гематома",
            "treatment": "Реконструкция или шунтирование"
        },
        "grade_5": {
            "description": "Сочетание с венозной травмой",
            "treatment": "Совместная реконструкция"
        }
    }
}


# ==================== ТРАВМА ШЕИ ====================

NECK_TRAUMA = {
    "zones": {
        "zone_1": {
            "description": "От ключицы до крикоидного хряща",
            "structures": ["Подключичные артерии", "Брахиоцефальный ствол", "Верхняя полая вена"],
            "access": "Стернотомия может потребоваться",
            "diagnostic_challenge": "Трудная зона для доступа"
        },
        "zone_2": {
            "description": "От крикоидного до угла нижней челюсти",
            "structures": ["Общие сонные артерии", "Внутренние и наружные сонные", "Внутренняя яремная вена"],
            "access": "Легкий хирургический доступ",
            "note": "Самая частая зона травмы"
        },
        "zone_3": {
            "description": "От угла нижней челюсти до основания черепа",
            "structures": ["Внутренние сонные артерии", "Внутренняя яремная вена"],
            "access": "Трудный доступ, эндоваскулярное предпочтительно",
            "diagnostic_challenge": "Трудная зона для контроля"
        }
    },
    
    "management": {
        "hard_signs": {
            "action": "Немедленная операция",
            "approach": "По зоне травмы",
            "control": "Проксимальный и дистальный контроль"
        },
        "soft_signs": {
            "action": "КТ-ангиография шеи",
            "alternative": "Дуплексное УЗИ",
            "follow_up": "Наблюдение если отрицательно"
        },
        "stable": {
            "action": "КТ-ангиография",
            "note": "Оценить все зоны"
        }
    },
    
    "surgical_techniques": {
        "primary_repair": {
            "indication": "Чистая трансекция без потери ткани",
            "technique": "Тонкие непрерывные швы 5-0 или 6-0 Prolene"
        },
        "patch_angioplasty": {
            "indication": "Недостаточность ткани для первичного шва",
            "materials": ["Сапенозная вена", "PTFE", "Dacron"]
        },
        "interposition_graft": {
            "indication": "Сегментарная потеря",
            "materials": ["Сапенозная вена (предпочтительно)", "PTFE"],
            "note": "Вена предпочтительнее для инфекционного поля"
        },
        "ligation": {
            "indication": "Невозможность реконструкции, контролируемая ситуация",
            "acceptable_for": ["Наружная сонная", "Внутренняя яремная вена"],
            "contraindicated_for": ["Внутренняя сонная"]
        }
    },
    
    "endovascular_options": {
        "covered_stent": {
            "indication": "Псевдоаневризма, АВ-фистула, диссекция",
            "advantages": ["Минимально инвазивно", "Хорошо для зоны 3"],
            "disadvantages": ["Риск инсульта", "Стеноз при длительном наблюдении"]
        },
        "coil_embolization": {
            "indication": "Невозможность реконструкции, контролируемая окклюзия",
            "example": "Наружная сонная артерия"
        }
    }
}


# ==================== ТРАВМА ГРУДНОЙ КЛЕТКИ ====================

THORACIC_VASCULAR_TRAUMA = {
    "great_vessels": {
        "aorta": {
            "injury_types": [
                "Интимальный разрыв",
                "Псевдоаневризма",
                "Трансекция",
                "Расслоение"
            ],
            "diagnosis": "КТ-ангиография или ТЭЭ",
            "treatment": {
                "stable": "TEVAR предпочтительно",
                "unstable": "Открытая операция (высокая летальность)"
            }
        },
        "subclavian": {
            "access": "Стернотомия + шейный разрез или торакотомия",
            "control": "Сложный доступ - трудный контроль",
            "endovascular": "Предпочтительно при возможности"
        },
        "innominate": {
            "access": "Правосторонняя торакотомия или стернотомия",
            "repair": "Interposition graft или bypass"
        }
    },
    
    "approaches": {
        "left_anterolateral_thoracotomy": {
            "indication": "Нестабильный пациент, подозрение на травму аорты",
            "advantage": "Быстрый доступ к аорте",
            "control": "Проксимальный контроль в левой плевральной полости"
        },
        "median_sternotomy": {
            "indication": "Травма восходящей аорты, брахиоцефальных сосудов",
            "access": "Отличный доступ к сердцу и great vessels"
        },
        "right_posterolateral_thoracotomy": {
            "indication": "Травма нисходящей аорты (редко)"
        }
    }
}


# ==================== ТРАВМА ЖИВОТА ====================

ABDOMINAL_VASCULAR_TRAUMA = {
    "major_vessels": {
        "aorta": {
            "suprarenal": {
                "access": "Срединная лапаротомия, медиальное висцеральное вращение",
                "control": "Диафрагмальная аорта (над hiatus)"
            },
            "infrarenal": {
                "access": "Срединная лапаротомия",
                "control": "Над и ниже почечных артерий"
            },
            "repair": "Первичный шов или interposition graft (Dacron)"
        },
        "vena_cava": {
            "suprarenal": {
                "access": "Стернотомия или правосторонняя торакотомия + лапаротомия",
                "note": "Очень сложный доступ, высокая летальность"
            },
            "infrarenal": {
                "access": "Срединная лапаротомия, отражение правой половины толстой кишки",
                "repair": "Первичный шов или patch (вена)",
                "ligation": "При невозможности ремонта (высокий риск отека ног)"
            }
        },
        "iliac": {
            "arteries": {
                "access": "Срединная лапаротомия, отражение кишки",
                "control": "Внутрибрюшное отделение аорты, дистально - в паху"
            },
            "veins": {
                "note": "Трудный доступ из-за тазовых костей",
                "repair": "Первичный шов или ligation (если противоположная вена цела)"
            }
        },
        "mesenteric": {
            "superior": {
                "repair": "Обязательно - ишемия кишки",
                "note": "Проверить жизнеспособность кишки"
            },
            "inferior": {
                "repair": "Желательно, но ligation возможна при хороших коллатералях"
            }
        }
    },
    
    "exposure_techniques": {
        "medial_visceral_rotation": {
            "name": "Медиальное висцеральное вращение (Mattox maneuver)",
            "indication": "Доступ к парависцеральной аорте, подвздошным артериям",
            "technique": "Отсечение лигамента Трейтца, отражение левой колонки"
        },
        "right_medial_visceral_rotation": {
            "name": "Правостороннее медиальное вращение (Cattell-Braasch)",
            "indication": "Доступ к нижней полой вене, правой подвздошной",
            "technique": "Отражение правой половины толстой кишки и тощей"
        },
        "left_liver_mobilization": {
            "name": "Мобилизация левой доли печени",
            "indication": "Доступ к супраренальной аорте"
        }
    }
}


# ==================== ТРАВМА КОНЕЧНОСТЕЙ ====================

EXTREMITY_VASCULAR_TRAUMA = {
    "assessment": {
        "hard_signs": [
            "Массивное кровотечение",
            "Расширяющаяся гематома",
            "Шок",
            "Ишемия (6 P)",
            "Пульсирующая гематома",
            "Сосудистый шум + трепетание"
        ],
        "soft_signs": [
            "История кровотечения",
            "Стабильная гематома",
            "Сосудистый шум",
            "Сниженный пульс",
            "Неврологический дефицит"
        ]
    },
    
    "management": {
        "immediate": {
            "bleeding_control": [
                "Прямое давление",
                "Жгут (при экстренности, <2 часов)",
                "НЕ использовать зажимы слепо!"
            ],
            "resuscitation": [
                "Массивное переливание",
                "Противозудные препараты",
                "Антибиотики"
            ]
        },
        "diagnostic": {
            "stable": "КТ-ангиография",
            "unstable": "Операция без КТ",
            "duplex": "Для soft signs"
        }
    },
    
    "repair_techniques": {
        "primary_repair": {
            "indication": "Чистая рана без потери ткани",
            "technique": "5-0 или 6-0 Prolene"
        },
        "patch_angioplasty": {
            "indication": "Недостаточность для первичного шва",
            "material": "Сапенозная вена (предпочтительно)"
        },
        "interposition_graft": {
            "indication": "Сегментарная потеря",
            "materials": {
                "vein": "Великая сапенозная вена - предпочтительно",
                "ptfe": "Если вена недоступна"
            }
        },
        "temporary_shunt": {
            "indication": "Damage control, невозможность немедленного ремонта",
            "materials": ["Argyle shunt", "Javid shunt", "Силиконовая трубка"],
            "note": "Вернуться для окончательного ремонта через 24-48 часов"
        },
        "ligation": {
            "indication": "Невозможность реконструкции, контролируемая ситуация",
            "acceptable_sites": ["Бедренная артерия (если глубокая цела)", "Подколенная", "Тибиальные"],
            "contraindicated": ["Общая подвздошная", "Поверхная бедренная"]
        }
    },
    
    "compartment_syndrome": {
        "prophylaxis": "Фасциотомия при:",
        "indications": [
            "Время ишемии >4-6 часов",
            "Комбинированная артериальная и венозная травма",
            "Мajor venous ligation",
            "Травма мягких тканей",
            "Гипотензия"
        ],
        "timing": "Профилактическая фасциотомия при реваскуляризации",
        "technique": "Двухсторонняя фасциотомия голени"
    },
    
    "associated_injuries": {
        "fractures": {
            "management": "Стабилизация до или одновременно с сосудистым ремонтом",
            "priority": "Сосудистый ремонт первичен"
        },
        "nerve_injuries": {
            "management": "Отметить, ремонт отложенный",
            "documentation": "Важно для медико-правовых вопросов"
        },
        "soft_tissue": {
            "management": "Дебридмент, покрытие сосудистого ремонта",
            "note": "Мышечный лоскут или свободная переноска"
        }
    }
}


# ==================== ФУНКЦИИ ДЛЯ API ====================

def assess_neck_trauma(zone: str, signs: List[str], hemodynamic_status: str) -> Dict[str, Any]:
    """
    Оценка травмы шеи
    """
    hard_signs_present = any(sign in VASCULAR_TRAUMA_CLASSIFICATION["hard_signs"]["signs"] for sign in signs)
    
    if hard_signs_present:
        return {
            "priority": "Emergency",
            "action": "Немедленная операция",
            "approach": f"Разрез по зоне {zone}",
            "preparation": [
                "Массивное переливание",
                "Антибиотики",
                "Противозудные препараты"
            ]
        }
    
    soft_signs_present = any(sign in VASCULAR_TRAUMA_CLASSIFICATION["soft_signs"]["signs"] for sign in signs)
    
    if soft_signs_present or hemodynamic_status == "stable":
        return {
            "priority": "Urgent",
            "action": "КТ-ангиография шеи",
            "alternative": "Дуплексное УЗИ если КТ недоступна",
            "follow_up": "Наблюдение если отрицательно"
        }
    
    return {
        "priority": "Observation",
        "action": "Наблюдение",
        "note": "Минимальный риск сосудистой травмы"
    }


def manage_extremity_vascular_trauma(hard_signs: bool, injury_location: str,
                                     ischemia_time: int) -> Dict[str, Any]:
    """
    Управление травмой сосудов конечности
    """
    plan = {
        "immediate_actions": [],
        "surgical_plan": {},
        "considerations": []
    }
    
    if hard_signs:
        plan["immediate_actions"].extend([
            "Прямое давление на рану",
            "Активация массивного переливания",
            "Немедленная операция"
        ])
    
    # Оценка времени ишемии
    if ischemia_time > 6:
        plan["considerations"].append("Время ишемии >6 часов - высокий риск ампутации")
        plan["considerations"].append("Профилактическая фасциотомия обязательна")
    elif ischemia_time > 4:
        plan["considerations"].append("Время ишемии 4-6 часов - рассмотреть фасциотомию")
    
    # План ремонта
    plan["surgical_plan"] = {
        "approach": f"Разрез по ходу {injury_location}",
        "proximal_control": "Сначала получить проксимальный контроль",
        "exploration": "Оценить полную длину повреждения",
        "repair_options": [
            "Первичный шов (если чистая рана)",
            "Заплатная ангиопластика (вена)",
            "Interposition graft (вена предпочтительно)"
        ]
    }
    
    return plan


def get_trauma_checklist(injury_type: str) -> Dict[str, Any]:
    """
    Получить чек-лист для травмы сосудов
    """
    return {
        "initial_assessment": {
            "abc": ["Airway", "Breathing", "Circulation"],
            "bleeding_control": "Прямое давление, НЕ зажимы слепо",
            "resuscitation": "Массивное переливание при шоке"
        },
        "vascular_assessment": {
            "hard_signs": VASCULAR_TRAUMA_CLASSIFICATION["hard_signs"]["signs"],
            "soft_signs": VASCULAR_TRAUMA_CLASSIFICATION["soft_signs"]["signs"]
        },
        "diagnostic_workup": {
            "unstable": "Операция без КТ",
            "stable": "КТ-ангиография"
        },
        "surgical_prep": {
            "blood_products": "O-negative, перекрестная проба",
            "antibiotics": "Цефалоспорин + метронидазоль или пиперациллин/тазобактам",
            "thawed_plasma": "Доступно"
        }
    }
