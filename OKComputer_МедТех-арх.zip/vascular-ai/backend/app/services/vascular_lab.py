"""
VASCULAR.AI - Интерпретация сосудистой лаборатории
АКШ, PVR, сегментарное давление, допплеровские кривые
"""

from typing import Dict, Any, List, Optional, Tuple


# ==================== АКШ (ABI) ====================

ABI_INTERPRETATION = {
    "measurement_technique": {
        "position": "Супинация, отдых 10 минут",
        "cuffs": "12×40 см на плечо, 12×40 см на лодыжку",
        "location": [
            "Плечо (брахиальная артерия)",
            "Лодыжка задняя (задняя большеберцовая артерия)",
            "Лодыжка передняя (передняя большеберцовая артерия)"
        ],
        "calculation": "ABI = Лодыжечное давление / Плечевое давление",
        "note": "Использовать более высокое плечевое давление"
    },
    
    "interpretation": {
        "normal": {
            "range": "1.00-1.40",
            "meaning": "Нормальный кровоток",
            "action": "Нет заболевания артерий"
        },
        "borderline": {
            "range": "0.91-0.99",
            "meaning": "Пограничное значение",
            "action": "Клиническая корреляция, возможно повторное измерение"
        },
        "mild_pad": {
            "range": "0.70-0.90",
            "meaning": "Легкая степень ЗАБ",
            "action": "Медикаментозная терапия, модификация факторов риска"
        },
        "moderate_pad": {
            "range": "0.40-0.69",
            "meaning": "Умеренная степень ЗАБ",
            "action": "Оценка для реваскуляризации при клаудикации"
        },
        "severe_pad": {
            "range": "<0.40",
            "meaning": "Тяжелая степень ЗАБ",
            "action": "Срочная оценка, риск критической ишемии"
        },
        "noncompressible": {
            "range": ">1.40",
            "meaning": "Несжимаемые артерии (кальциноз)",
            "action": "Измерить TBI (toe-brachial index)"
        }
    },
    
    "limb_specific": {
        "right_abi": {
            "interpretation": "Правая нога",
            "asymmetry": ">0.15 разница между ногами - значимый стеноз"
        },
        "left_abi": {
            "interpretation": "Левая нога",
            "asymmetry": ">0.15 разница между ногами - значимый стеноз"
        }
    },
    
    "post_exercise": {
        "technique": "Измерение через 1 минуту после ходьбы",
        "significant_drop": ">20% падение ABI",
        "meaning": "Гемодинамически значимый стеноз"
    },
    
    "limitations": [
        "Кальциноз (несжимаемые артерии)",
        "Диабет (медиальный кальциноз)",
        "Почечная недостаточность",
        "Пожилые пациенты"
    ]
}


# ==================== TBI (Toe-Brachial Index) ====================

TBI_INTERPRETATION = {
    "indications": [
        "Несжимаемые артерии (ABI >1.40)",
        "Диабет с медиальным кальцинозом",
        "Почечная недостаточность",
        "Пожилые пациенты"
    ],
    
    "measurement_technique": {
        "cuff": "Маленькая манжета на большой палец",
        "sensor": "Фотоплетизмография или пульсовая допплерография",
        "position": "Супинация"
    },
    
    "interpretation": {
        "normal": {
            "range": ">0.70",
            "meaning": "Нормальный кровоток"
        },
        "abnormal": {
            "range": "0.50-0.69",
            "meaning": "Сниженный кровоток",
            "action": "Оценка ЗАБ"
        },
        "critical": {
            "range": "<0.50",
            "meaning": "Критическая ишемия",
            "action": "Срочная оценка"
        }
    }
}


# ==================== СЕГМЕНТАРНОЕ ДАВЛЕНИЕ ====================

SEGMENTAL_PRESSURE = {
    "measurement_levels": {
        "brachial": {
            "level": "Плечо (брахиальная артерия)",
            "reference": "Базовое давление"
        },
        "high_thigh": {
            "level": "Верхняя треть бедра",
            "normal": "На 30 мм рт.ст. выше плечевого",
            "gradient_brachial_high_thigh": {
                "normal": "<30 мм рт.ст.",
                "abnormal": ">30 мм рт.ст. - стеноз аорто-подвздошного сегмента"
            }
        },
        "low_thigh": {
            "level": "Нижняя треть бедра (над коленом)",
            "gradient_high_low_thigh": {
                "normal": "<20 мм рт.ст.",
                "abnormal": ">20 мм рт.ст. - стеноз поверхной бедренной артерии"
            }
        },
        "calf": {
            "level": "Голень (подколенная ямка)",
            "gradient_low_thigh_calf": {
                "normal": "<20 мм рт.ст.",
                "abnormal": ">20 мм рт.ст. - стеноз подколенной артерии"
            }
        },
        "ankle": {
            "level": "Лодыжка",
            "gradient_calf_ankle": {
                "normal": "<20 мм рт.ст.",
                "abnormal": ">20 мм рт.ст. - стеноз трехветвий"
            }
        }
    },
    
    "interpretation": {
        "aortoiliac_disease": {
            "finding": "Градиент плечо-верхнее бедро >30 мм рт.ст.",
            "additional_signs": [
                "Снижение давления на обеих ногах",
                "Задержка пульсовой волны (PVR)",
                "Плоская допплеровская кривая на бедре"
            ]
        },
        "femoropopliteal_disease": {
            "finding": "Градиент верхнее-нижнее бедро >20 мм рт.ст.",
            "additional_signs": [
                "Нормальное плечевое давление",
                "Снижение давления ниже поражения"
            ]
        },
        "infrapopliteal_disease": {
            "finding": "Градиент голень-лодыжка >20 мм рт.ст.",
            "note": "Часто сочетается с проксимальным поражением"
        }
    }
}


# ==================== PVR (Pulse Volume Recording) ====================

PVR_INTERPRETATION = {
    "technique": {
        "description": "Плетизмография с пневматическими манжетами",
        "cuff_placement": [
            "Плечо",
            "Верхнее бедро",
            "Нижнее бедро",
            "Голень",
            "Лодыжка",
            "Палец (при необходимости)"
        ],
        "principle": "Измерение изменения объема конечности с каждым пульсом"
    },
    
    "waveform_analysis": {
        "normal": {
            "description": "Sharp systolic upstroke, dicrotic notch, gradual downslope",
            "amplitude": "Уменьшается дистально (но сохраняет форму)",
            "meaning": "Нормальный кровоток"
        },
        "mild_obstruction": {
            "description": "Slightly delayed upstroke, preserved amplitude",
            "meaning": "Легкий стеноз",
            "correlation": "Обычно ABI 0.70-0.90"
        },
        "moderate_obstruction": {
            "description": "Delayed upstroke, reduced amplitude, loss of dicrotic notch",
            "meaning": "Умеренный стеноз",
            "correlation": "Обычно ABI 0.40-0.69"
        },
        "severe_obstruction": {
            "description": "Very delayed upstroke, markedly reduced amplitude, flat waveform",
            "meaning": "Тяжелый стеноз или окклюзия",
            "correlation": "Обычно ABI <0.40"
        },
        "damped": {
            "description": "Low amplitude, rounded waveform",
            "meaning": "Проксимальный стеноз или окклюзия"
        }
    },
    
    "amplitude_grading": {
        "normal": ">20 мм (бедро), >15 мм (голень)",
        "mildly_reduced": "10-20 мм (бедро), 8-15 мм (голень)",
        "markedly_reduced": "5-10 мм (бедро), 5-8 мм (голень)",
        "flat": "<5 мм"
    }
}


# ==================== ДОППЛЕРОВСКАЯ ВЕЛОЦИМЕТРИЯ ====================

DOPPLER_VELOCIMETRY = {
    "parameters": {
        "peak_systolic_velocity": {
            "abbreviation": "PSV",
            "description": "Максимальная систолическая скорость",
            "measurement": "Самая высокая точка в сосуде"
        },
        "end_diastolic_velocity": {
            "abbreviation": "EDV",
            "description": "Конечная диастолическая скорость",
            "measurement": "Скорость в конце диастолы"
        },
        "resistive_index": {
            "abbreviation": "RI",
            "formula": "(PSV - EDV) / PSV",
            "normal": "0.55-0.75",
            "high": ">0.75 (повышенное сопротивление)",
            "low": "<0.55 (сниженное сопротивление)"
        },
        "pulsatility_index": {
            "abbreviation": "PI",
            "formula": "(PSV - EDV) / mean velocity"
        }
    },
    
    "stenosis_criteria": {
        "carotid": {
            "normal": {
                "psv": "<125 см/с",
                "edv": "<40 см/с",
                "ratio": "<2.0"
            },
            "50_69_percent": {
                "psv": "125-230 см/с",
                "edv": "40-100 см/с",
                "ratio": "2.0-4.0"
            },
            "70_99_percent": {
                "psv": ">230 см/с",
                "edv": ">100 см/с",
                "ratio": ">4.0"
            },
            "occlusion": {
                "finding": "No flow detected"
            }
        },
        
        "peripheral_native": {
            "normal": {
                "psv": "<150 см/с"
            },
            "50_75_percent": {
                "psv": "150-200 см/с",
                "ratio": "2.0-3.0"
            },
            "greater_75_percent": {
                "psv": ">200 см/с",
                "ratio": ">3.0"
            },
            "monophasic": {
                "finding": "Monophasic waveform with reduced velocity",
                "meaning": "Тяжелый стеноз или окклюзия проксимально"
            }
        },
        
        "bypass_graft": {
            "surveillance": {
                "normal": "<125 см/с или <180 см/с (зависит от типа)",
                "elevated": "125-200 см/с - наблюдение",
                "high": ">200-250 см/с или Δ >50 см/с - ангиография",
                "low": "<45 см/с - окклюзия или проксимальный стеноз"
            },
            "anastomotic_stenosis": {
                "criteria": "PSV >300 см/с или ratio >3.5"
            }
        }
    },
    
    "waveform_patterns": {
        "triphasic": {
            "description": "Systolic peak, early diastolic reversal, late diastolic forward flow",
            "meaning": "Нормальный кровоток в конечности",
            "location": "Нормальные артерии конечностей"
        },
        "biphasic": {
            "description": "Systolic peak, continuous forward flow in diastole",
            "meaning": "Нормальный или легко измененный кровоток"
        },
        "monophasic": {
            "description": "Single broad peak, continuous forward flow",
            "meaning": "Гемодинамически значимое поражение проксимально",
            "action": "Оценка проксимальных сегментов"
        },
        "damped": {
            "description": "Low velocity, delayed upstroke",
            "meaning": "Окклюзия или тяжелый стеноз проксимально"
        }
    }
}


# ==================== ФУНКЦИИ ИНТЕРПРЕТАЦИИ ====================

def interpret_abi(right_ankle_pressure: float, left_ankle_pressure: float, 
                  brachial_pressure: float) -> Dict[str, Any]:
    """
    Интерпретация результатов АКШ
    """
    right_abi = right_ankle_pressure / brachial_pressure
    left_abi = left_ankle_pressure / brachial_pressure
    
    def classify_abi(abi: float) -> str:
        if abi > 1.40:
            return "noncompressible"
        elif abi >= 1.00:
            return "normal"
        elif abi >= 0.91:
            return "borderline"
        elif abi >= 0.70:
            return "mild_pad"
        elif abi >= 0.40:
            return "moderate_pad"
        else:
            return "severe_pad"
    
    right_class = classify_abi(right_abi)
    left_class = classify_abi(left_abi)
    
    interpretation = {
        "right_abi": round(right_abi, 2),
        "left_abi": round(left_abi, 2),
        "right_interpretation": ABI_INTERPRETATION["interpretation"][right_class],
        "left_interpretation": ABI_INTERPRETATION["interpretation"][left_class],
        "asymmetry": abs(right_abi - left_abi),
        "significant_asymmetry": abs(right_abi - left_abi) > 0.15
    }
    
    # Рекомендации
    recommendations = []
    
    if right_class in ["moderate_pad", "severe_pad"] or left_class in ["moderate_pad", "severe_pad"]:
        recommendations.append("Консультация сосудистого хирурга")
        recommendations.append("Медикаментозная терапия (антитромбоцитарные, статины)")
    
    if right_class == "noncompressible" or left_class == "noncompressible":
        recommendations.append("Измерить TBI (toe-brachial index)")
        recommendations.append("Оценить на кальциноз")
    
    if interpretation["significant_asymmetry"]:
        recommendations.append("Значимая асимметрия - оценить бок с более низким ABI")
    
    interpretation["recommendations"] = recommendations
    
    return interpretation


def interpret_segmental_pressures(pressures: Dict[str, float]) -> Dict[str, Any]:
    """
    Интерпретация сегментарных давлений
    """
    brachial = pressures.get("brachial", 0)
    high_thigh = pressures.get("high_thigh", 0)
    low_thigh = pressures.get("low_thigh", 0)
    calf = pressures.get("calf", 0)
    ankle = pressures.get("ankle", 0)
    
    gradients = {
        "brachial_to_high_thigh": high_thigh - brachial,
        "high_to_low_thigh": high_thigh - low_thigh,
        "low_thigh_to_calf": low_thigh - calf,
        "calf_to_ankle": calf - ankle
    }
    
    findings = []
    
    if gradients["brachial_to_high_thigh"] < -30:
        findings.append({
            "location": "Аорто-подвздошный сегмент",
            "severity": "Значимый стеноз/окклюзия",
            "gradient": gradients["brachial_to_high_thigh"]
        })
    
    if gradients["high_to_low_thigh"] > 20:
        findings.append({
            "location": "Поверхная бедренная артерия",
            "severity": "Стеноз",
            "gradient": gradients["high_to_low_thigh"]
        })
    
    if gradients["low_thigh_to_calf"] > 20:
        findings.append({
            "location": "Подколенная артерия",
            "severity": "Стеноз",
            "gradient": gradients["low_thigh_to_calf"]
        })
    
    if gradients["calf_to_ankle"] > 20:
        findings.append({
            "location": "Трехветвия/инфрапоплитеальные артерии",
            "severity": "Стеноз",
            "gradient": gradients["calf_to_ankle"]
        })
    
    return {
        "pressures": pressures,
        "gradients": gradients,
        "findings": findings,
        "recommendations": [
            "Дуплексное УЗИ для уточнения локализации" if findings else "Продолжать наблюдение",
            "Консультация сосудистого хирурга" if len(findings) > 0 else None
        ]
    }


def interpret_doppler_velocities(site: str, psv: float, edv: float = None,
                                  ratio: float = None) -> Dict[str, Any]:
    """
    Интерпретация допплеровских скоростей
    """
    if site == "carotid":
        if psv < 125:
            stenosis = "<50%"
            significance = "Незначимый"
        elif psv < 230:
            stenosis = "50-69%"
            significance = "Умеренный"
        else:
            stenosis = "70-99%"
            significance = "Тяжелый"
        
        return {
            "site": site,
            "psv": psv,
            "stenosis_estimate": stenosis,
            "significance": significance,
            "recommendations": [
                "Контроль каждые 6-12 месяцев" if stenosis == "<50%" else None,
                "Контроль каждые 6 месяцев" if stenosis == "50-69%" else None,
                "Консультация сосудистого хирурга" if stenosis == "70-99%" else None
            ]
        }
    
    elif site == "bypass_graft":
        if psv < 125:
            status = "Normal"
            action = "Продолжать наблюдение"
        elif psv < 200:
            status = "Elevated - surveillance"
            action = "УЗИ через 1-3 месяца"
        else:
            status = "High - intervention likely"
            action = "Ангиография"
        
        return {
            "site": site,
            "psv": psv,
            "status": status,
            "action": action
        }
    
    return {"error": f"Unknown site: {site}"}


def get_vascular_lab_checklist() -> Dict[str, Any]:
    """
    Получить чек-лист сосудистой лаборатории
    """
    return {
        "non_invasive_tests": {
            "abi": {
                "name": "АКШ (Ankle-Brachial Index)",
                "indications": ["Скрининг ЗАБ", "Клаудикация", "Критическая ишемия"],
                "normal_range": "1.00-1.40",
                "time": "15 минут"
            },
            "tbi": {
                "name": "TBI (Toe-Brachial Index)",
                "indications": ["Несжимаемые артерии", "Диабет"],
                "normal_range": ">0.70",
                "time": "10 минут"
            },
            "segmental_pressure": {
                "name": "Сегментарное давление",
                "indications": ["Локализация поражения", "Планирование операции"],
                "time": "30 минут"
            },
            "pvr": {
                "name": "PVR (Pulse Volume Recording)",
                "indications": ["Оценка гемодинамики", "Мониторинг"],
                "time": "20 минут"
            },
            "duplex": {
                "name": "Дуплексное УЗИ",
                "indications": ["Все сосудистые заболевания"],
                "time": "30-60 минут"
            }
        },
        "interpretation_guidelines": {
            "abi": ABI_INTERPRETATION,
            "tbi": TBI_INTERPRETATION,
            "segmental_pressure": SEGMENTAL_PRESSURE,
            "pvr": PVR_INTERPRETATION,
            "doppler": DOPPLER_VELOCIMETRY
        }
    }
