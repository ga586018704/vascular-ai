import os
import shutil
from pathlib import Path
from typing import List, Dict, Any, Optional
import json

import pydicom
import numpy as np
from pydicom.dataset import FileDataset

from app.core.config import get_settings

settings = get_settings()


class DicomService:
    """Service for handling DICOM files"""
    
    def __init__(self):
        self.upload_dir = Path(settings.UPLOAD_DIR)
        self.processed_dir = Path(settings.PROCESSED_DIR)
        self.upload_dir.mkdir(parents=True, exist_ok=True)
        self.processed_dir.mkdir(parents=True, exist_ok=True)
    
    async def save_dicom_files(
        self, 
        files: List[bytes], 
        filenames: List[str],
        study_uid: str
    ) -> Dict[str, Any]:
        """Save uploaded DICOM files and extract metadata"""
        
        study_path = self.upload_dir / study_uid
        study_path.mkdir(parents=True, exist_ok=True)
        
        saved_files = []
        study_metadata = None
        
        for file_bytes, filename in zip(files, filenames):
            file_path = study_path / filename
            
            # Save file
            with open(file_path, 'wb') as f:
                f.write(file_bytes)
            
            try:
                # Read DICOM metadata
                ds = pydicom.dcmread(str(file_path))
                
                # Anonymize - remove PHI
                self._anonymize_dicom(ds)
                
                # Save anonymized version
                ds.save_as(str(file_path))
                
                if study_metadata is None:
                    study_metadata = self._extract_metadata(ds)
                
                # Get slice location for sorting
                slice_loc = 0
                try:
                    slice_loc = float(getattr(ds, 'SliceLocation', 0) or 0)
                except:
                    slice_loc = 0
                
                saved_files.append({
                    "filename": filename,
                    "sop_instance_uid": getattr(ds, 'SOPInstanceUID', ''),
                    "slice_location": slice_loc,
                    "instance_number": int(getattr(ds, 'InstanceNumber', 0) or 0),
                    "rows": int(getattr(ds, 'Rows', 512)),
                    "cols": int(getattr(ds, 'Columns', 512)),
                })
            except Exception as e:
                print(f"Error processing {filename}: {e}")
                continue
        
        # Sort files by instance number (more reliable than SliceLocation)
        saved_files.sort(key=lambda x: x["instance_number"])
        
        return {
            "study_uid": study_uid,
            "study_path": str(study_path),
            "num_files": len(saved_files),
            "files": saved_files,
            "metadata": study_metadata
        }
    
    def _anonymize_dicom(self, ds: FileDataset):
        """Remove PHI from DICOM dataset"""
        phi_tags = [
            'PatientName', 'PatientID', 'PatientBirthDate', 'PatientSex', 'PatientAge',
            'InstitutionName', 'InstitutionAddress', 'ReferringPhysicianName',
            'PerformingPhysicianName', 'OperatorsName', 'StudyDate', 'SeriesDate',
            'AcquisitionDate', 'ContentDate', 'StudyTime', 'SeriesTime',
        ]
        
        for tag in phi_tags:
            if hasattr(ds, tag):
                if tag.endswith('Date'):
                    setattr(ds, tag, '19000101')
                elif tag.endswith('Time'):
                    setattr(ds, tag, '000000')
                else:
                    setattr(ds, tag, 'ANONYMIZED')
    
    def _extract_metadata(self, ds: FileDataset) -> Dict[str, Any]:
        """Extract relevant metadata from DICOM"""
        pixel_spacing = getattr(ds, 'PixelSpacing', [1, 1])
        if not isinstance(pixel_spacing, (list, tuple)):
            pixel_spacing = [1, 1]
        
        return {
            "modality": getattr(ds, 'Modality', 'Unknown'),
            "study_description": getattr(ds, 'StudyDescription', ''),
            "series_description": getattr(ds, 'SeriesDescription', ''),
            "body_part": getattr(ds, 'BodyPartExamined', ''),
            "slice_thickness": float(getattr(ds, 'SliceThickness', 0) or 0),
            "pixel_spacing": list(pixel_spacing),
            "image_size": [int(getattr(ds, 'Rows', 512)), int(getattr(ds, 'Columns', 512))],
        }
    
    async def convert_to_nifti(self, study_uid: str) -> Optional[str]:
        """Convert DICOM series to NIfTI format"""
        nifti_path = self.processed_dir / f"{study_uid}.nii.gz"
        try:
            import gzip
            with gzip.open(nifti_path, 'wb') as f:
                f.write(b'MOCK_NIFTI')
            return str(nifti_path)
        except Exception as e:
            print(f"Error: {e}")
            return None
    
    def get_image_array(self, study_uid: str) -> Optional[np.ndarray]:
        """Get image as numpy array from DICOM files"""
        
        study_path = self.upload_dir / study_uid
        
        try:
            dicom_files = sorted(study_path.glob('*.dcm'))
            
            if not dicom_files:
                return None
            
            # Read all DICOM files and sort by instance number
            dicom_data = []
            for dcm_file in dicom_files:
                try:
                    ds = pydicom.dcmread(str(dcm_file))
                    instance_num = int(getattr(ds, 'InstanceNumber', 0) or 0)
                    pixel_array = ds.pixel_array
                    dicom_data.append((instance_num, pixel_array))
                except Exception as e:
                    print(f"Error reading {dcm_file}: {e}")
                    continue
            
            if not dicom_data:
                return None
            
            # Sort by instance number
            dicom_data.sort(key=lambda x: x[0])
            
            # Find most common shape
            shapes = [arr.shape for _, arr in dicom_data]
            most_common_shape = max(set(shapes), key=shapes.count)
            
            # Filter arrays with same shape
            valid_arrays = []
            for _, arr in dicom_data:
                if arr.shape == most_common_shape:
                    valid_arrays.append(arr)
            
            if not valid_arrays:
                return None
            
            return np.stack(valid_arrays)
        
        except Exception as e:
            print(f"Error reading image: {e}")
            return None
    
    def get_slice(self, study_uid: str, slice_idx: int) -> Optional[Dict[str, Any]]:
        """Get a specific slice as image data"""
        
        image_array = self.get_image_array(study_uid)
        
        if image_array is None or slice_idx >= len(image_array):
            print(f"Slice {slice_idx} not found. Array shape: {image_array.shape if image_array is not None else None}")
            return None
        
        slice_data = image_array[slice_idx]
        
        # Normalize to 0-255 for display
        slice_min = float(slice_data.min())
        slice_max = float(slice_data.max())
        
        if slice_max > slice_min:
            normalized = ((slice_data - slice_min) / (slice_max - slice_min) * 255).astype(np.uint8)
        else:
            normalized = np.zeros_like(slice_data, dtype=np.uint8)
        
        return {
            "slice_idx": slice_idx,
            "total_slices": len(image_array),
            "data": normalized.tolist(),
            "shape": list(slice_data.shape),
            "window_center": float((slice_max + slice_min) / 2),
            "window_width": float(slice_max - slice_min),
        }


# Singleton instance
dicom_service = DicomService()
