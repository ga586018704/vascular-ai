"""
VASCULAR.AI - Voice-to-Text Service
Speech recognition for medical dictation
"""

import os
import tempfile
import wave
from typing import Optional, Dict, Any, AsyncGenerator
from dataclasses import dataclass
from datetime import datetime
import asyncio

import httpx
from app.core.logging import app_logger


@dataclass
class TranscriptionResult:
    """Result of speech transcription"""
    text: str
    confidence: float
    language: str
    duration_seconds: float
    timestamp: datetime
    segments: list = None


class WhisperTranscriptionService:
    """
    Speech-to-text using OpenAI Whisper API
    """
    
    API_URL = "https://api.openai.com/v1/audio/transcriptions"
    
    def __init__(self, api_key: Optional[str] = None):
        self.api_key = api_key or os.getenv("OPENAI_API_KEY")
        if not self.api_key:
            raise ValueError("OpenAI API key not provided")
        
        self.client = httpx.AsyncClient(
            headers={"Authorization": f"Bearer {self.api_key}"},
            timeout=120.0
        )
    
    async def transcribe_file(
        self,
        audio_file_path: str,
        language: str = "ru",
        prompt: Optional[str] = None
    ) -> TranscriptionResult:
        """
        Transcribe audio file
        
        Args:
            audio_file_path: Path to audio file
            language: Language code (ru, en, etc.)
            prompt: Optional prompt to guide transcription
        
        Returns:
            Transcription result
        """
        
        try:
            with open(audio_file_path, 'rb') as f:
                files = {'file': f}
                data = {
                    'model': 'whisper-1',
                    'language': language,
                    'response_format': 'verbose_json'
                }
                if prompt:
                    data['prompt'] = prompt
                
                response = await self.client.post(
                    self.API_URL,
                    files=files,
                    data=data
                )
                response.raise_for_status()
                result = response.json()
            
            # Calculate duration
            duration = self._get_audio_duration(audio_file_path)
            
            return TranscriptionResult(
                text=result.get('text', ''),
                confidence=self._calculate_confidence(result),
                language=language,
                duration_seconds=duration,
                timestamp=datetime.utcnow(),
                segments=result.get('segments', [])
            )
            
        except Exception as e:
            app_logger.error(f"Transcription error: {e}")
            raise
    
    async def transcribe_bytes(
        self,
        audio_bytes: bytes,
        filename: str = "audio.wav",
        language: str = "ru",
        prompt: Optional[str] = None
    ) -> TranscriptionResult:
        """
        Transcribe audio from bytes
        
        Args:
            audio_bytes: Audio data as bytes
            filename: Filename for the audio
            language: Language code
            prompt: Optional prompt
        
        Returns:
            Transcription result
        """
        
        # Save to temporary file
        with tempfile.NamedTemporaryFile(delete=False, suffix='.wav') as tmp:
            tmp.write(audio_bytes)
            tmp_path = tmp.name
        
        try:
            result = await self.transcribe_file(tmp_path, language, prompt)
            return result
        finally:
            os.unlink(tmp_path)
    
    async def transcribe_stream(
        self,
        audio_stream: AsyncGenerator[bytes, None],
        language: str = "ru"
    ) -> AsyncGenerator[str, None]:
        """
        Transcribe streaming audio (not supported by Whisper API directly)
        This accumulates audio and transcribes in chunks
        
        Args:
            audio_stream: Async generator of audio chunks
            language: Language code
        
        Yields:
            Transcription text chunks
        """
        
        # Accumulate audio chunks
        audio_buffer = bytearray()
        chunk_size = 10 * 1024 * 1024  # 10MB chunks
        
        async for chunk in audio_stream:
            audio_buffer.extend(chunk)
            
            # Process when buffer is full
            if len(audio_buffer) >= chunk_size:
                # Save and transcribe
                with tempfile.NamedTemporaryFile(delete=False, suffix='.wav') as tmp:
                    tmp.write(audio_buffer)
                    tmp_path = tmp.name
                
                try:
                    result = await self.transcribe_file(tmp_path, language)
                    yield result.text
                finally:
                    os.unlink(tmp_path)
                
                # Clear buffer
                audio_buffer = bytearray()
        
        # Process remaining audio
        if audio_buffer:
            with tempfile.NamedTemporaryFile(delete=False, suffix='.wav') as tmp:
                tmp.write(audio_buffer)
                tmp_path = tmp.name
            
            try:
                result = await self.transcribe_file(tmp_path, language)
                yield result.text
            finally:
                os.unlink(tmp_path)
    
    def _get_audio_duration(self, file_path: str) -> float:
        """Get audio file duration in seconds"""
        try:
            with wave.open(file_path, 'rb') as wav:
                frames = wav.getnframes()
                rate = wav.getframerate()
                return frames / float(rate)
        except:
            return 0.0
    
    def _calculate_confidence(self, result: Dict) -> float:
        """Calculate average confidence from segments"""
        segments = result.get('segments', [])
        if not segments:
            return 0.0
        
        avg_confidence = sum(s.get('avg_logprob', -1) for s in segments) / len(segments)
        # Convert logprob to confidence (approximate)
        confidence = min(1.0, max(0.0, 1 + avg_confidence))
        return confidence


class MedicalDictationProcessor:
    """
    Process medical dictation with medical terminology
    """
    
    MEDICAL_TERMS = [
        "аневризма", "аорта", "артерия", "вена", "тромбоз", "стеноз",
        "окклюзия", "реваскуляризация", "стент", "баллон", "катетер",
        "ангиография", "дуплекс", "ультразвук", "компьютерная томография",
        "магнитно-резонансная томография", "контраст", "гепарин", "варфарин",
        "аспирин", "клопидогрель", "ривароксабан", "апиксабан"
    ]
    
    ENGLISH_MEDICAL_TERMS = [
        "aneurysm", "aorta", "artery", "vein", "thrombosis", "stenosis",
        "occlusion", "revascularization", "stent", "balloon", "catheter",
        "angiography", "duplex", "ultrasound", "CT", "MRI", "contrast",
        "heparin", "warfarin", "aspirin", "clopidogrel", "rivaroxaban", "apixaban"
    ]
    
    def __init__(self, transcription_service: WhisperTranscriptionService):
        self.transcription = transcription_service
    
    async def dictate_report(
        self,
        audio_file_path: str,
        report_type: str = "vascular",
        language: str = "ru"
    ) -> Dict[str, Any]:
        """
        Dictate a medical report
        
        Args:
            audio_file_path: Path to audio file
            report_type: Type of report (vascular, cardiac, etc.)
            language: Language code
        
        Returns:
            Dictated report with metadata
        """
        
        # Create medical prompt
        prompt = self._create_medical_prompt(report_type, language)
        
        # Transcribe
        result = await self.transcription.transcribe_file(
            audio_file_path,
            language=language,
            prompt=prompt
        )
        
        # Post-process
        processed_text = self._post_process_medical_text(result.text, language)
        
        return {
            "transcription": processed_text,
            "raw_transcription": result.text,
            "confidence": result.confidence,
            "duration_seconds": result.duration_seconds,
            "language": result.language,
            "timestamp": result.timestamp.isoformat(),
            "report_type": report_type
        }
    
    def _create_medical_prompt(self, report_type: str, language: str) -> str:
        """Create prompt for medical transcription"""
        
        if language == "ru":
            terms = ", ".join(self.MEDICAL_TERMS[:15])
            return f"""Это медицинское заключение по сосудистой хирургии.
Используйте следующие медицинские термины: {terms}.
Структура: КЛИНИЧЕСКАЯ ИНДИКАЦИЯ, МЕТОДИКА, СРАВНЕНИЕ, РЕЗУЛЬТАТЫ, ЗАКЛЮЧЕНИЕ."""
        else:
            terms = ", ".join(self.ENGLISH_MEDICAL_TERMS[:15])
            return f"""This is a medical report for {report_type} imaging.
Use the following medical terms: {terms}.
Structure: CLINICAL INDICATION, TECHNIQUE, COMPARISON, FINDINGS, IMPRESSION."""
    
    def _post_process_medical_text(self, text: str, language: str) -> str:
        """Post-process transcribed medical text"""
        
        # Common corrections
        corrections = {
            "ru": {
                "аневризма аорты": "аневризма аорты",
                "брюшная аорта": "брюшная аорта",
                "внутренняя сонная": "внутренняя сонная артерия",
            },
            "en": {
                "abdominal aorta": "abdominal aorta",
                "internal carotid": "internal carotid artery",
            }
        }
        
        processed = text
        for wrong, correct in corrections.get(language, {}).items():
            processed = processed.replace(wrong, correct)
        
        # Capitalize section headers
        sections = ["КЛИНИЧЕСКАЯ ИНДИКАЦИЯ", "МЕТОДИКА", "СРАВНЕНИЕ", 
                   "РЕЗУЛЬТАТЫ", "ЗАКЛЮЧЕНИЕ", "РЕКОМЕНДАЦИИ"]
        for section in sections:
            processed = processed.replace(section.lower(), section)
        
        return processed
    
    async def dictate_realtime(
        self,
        websocket,
        language: str = "ru"
    ):
        """
        Real-time dictation via WebSocket
        
        Args:
            websocket: WebSocket connection
            language: Language code
        """
        
        audio_buffer = bytearray()
        
        async for message in websocket:
            if isinstance(message, bytes):
                # Audio chunk received
                audio_buffer.extend(message)
                
                # Process every 5 seconds of audio
                if len(audio_buffer) > 16000 * 5 * 2:  # 5 seconds at 16kHz, 16-bit
                    # Save to temp file
                    with tempfile.NamedTemporaryFile(delete=False, suffix='.wav') as tmp:
                        # Write WAV header
                        self._write_wav_header(tmp, len(audio_buffer))
                        tmp.write(audio_buffer)
                        tmp_path = tmp.name
                    
                    try:
                        result = await self.transcription.transcribe_file(tmp_path, language)
                        await websocket.send_json({
                            "type": "partial",
                            "text": result.text
                        })
                    finally:
                        os.unlink(tmp_path)
                    
                    # Keep last second for continuity
                    audio_buffer = audio_buffer[-16000 * 2:]
            
            elif isinstance(message, str):
                # Control message
                data = json.loads(message)
                if data.get("action") == "finalize":
                    # Final transcription
                    if audio_buffer:
                        with tempfile.NamedTemporaryFile(delete=False, suffix='.wav') as tmp:
                            self._write_wav_header(tmp, len(audio_buffer))
                            tmp.write(audio_buffer)
                            tmp_path = tmp.name
                        
                        try:
                            result = await self.transcription.transcribe_file(tmp_path, language)
                            await websocket.send_json({
                                "type": "final",
                                "text": result.text
                            })
                        finally:
                            os.unlink(tmp_path)
    
    def _write_wav_header(self, file, data_length: int):
        """Write WAV file header"""
        
        # RIFF header
        file.write(b'RIFF')
        file.write((36 + data_length).to_bytes(4, 'little'))
        file.write(b'WAVE')
        
        # fmt chunk
        file.write(b'fmt ')
        file.write((16).to_bytes(4, 'little'))  # Subchunk1Size
        file.write((1).to_bytes(2, 'little'))   # AudioFormat (PCM)
        file.write((1).to_bytes(2, 'little'))   # NumChannels (mono)
        file.write((16000).to_bytes(4, 'little'))  # SampleRate
        file.write((32000).to_bytes(4, 'little'))  # ByteRate
        file.write((2).to_bytes(2, 'little'))   # BlockAlign
        file.write((16).to_bytes(2, 'little'))  # BitsPerSample
        
        # data chunk
        file.write(b'data')
        file.write(data_length.to_bytes(4, 'little'))


# Factory functions
def get_voice_service() -> WhisperTranscriptionService:
    """Get voice transcription service"""
    return WhisperTranscriptionService()


def get_dictation_processor() -> MedicalDictationProcessor:
    """Get medical dictation processor"""
    transcription_service = get_voice_service()
    return MedicalDictationProcessor(transcription_service)
