"""
VASCULAR.AI - Руководство по нейроинтервенционной хирургии
На основе:
- Handbook of Cerebrovascular Disease and Neurointerventional Technique (Harrigan, Deveikis)
- Neurointerventional Techniques: Tricks of the Trade (Gonzalez)
- Acute Aortic Disease (Elefteriades)
"""

from typing import Dict, Any, List, Optional


# ==================== ИШЕМИЧЕСКИЙ ИНСУЛЬТ ====================

ISCHEMIC_STROKE = {
    "acute_management": {
        "time_windows": {
            "iv_tpa": {
                "window": "4.5 часов от начала симптомов",
                "criteria": [
                    "Возраст ≥18 лет",
                    "Клинический диагноз инсульта",
                    "Четкое время начала",
                    "CT/MRI исключают кровоизлияние",
                    "NIHSS подходящий"
                ],
                "contraindications": [
                    "Кровоизлияние на CT",
                    "Симптомы >4.5 часов",
                    "Недавнее кровотечение/операция",
                    "Инсульт/ТИА в анамнезе <3 мес",
                    "INR >1.7",
                    "Тромбоциты <100,000",
                    "Систолическое АД >185 или диастолическое >110"
                ],
                "dosing": "0.9 мг/кг (10% болюс, 90% инфузия 60 мин)",
                "max_dose": "90 мг"
            },
            "mechanical_thrombectomy": {
                "window": "До 24 часов (при подходящей клинической картине)",
                "criteria": [
                    "Окклюзия крупного сосуда (ICA, M1, M2, базилярная)",
                    "NIHSS ≥6",
                    "ASPECTS ≥6",
                    "Можно начать в течение 6-24 часов"
                ],
                "techniques": [
                    "Stent retriever (Solitaire, Trevo)",
                    "Aspiration (Penumbra ACE)",
                    "Combined approach"
                ],
                "success": "mTICI 2b-3 (реперфузия >50%)"
            }
        },
        
        "workflow": {
            "step_1": "Распознавание (FAST: Face, Arm, Speech, Time)",
            "step_2": "Экстренная служба 911",
            "step_3": "Транспорт в центр с возможностью тромбэктомии",
            "step_4": "CT головы немедленно",
            "step_5": "CT-ангиография головы и шеи",
            "step_6": "IV tPA (если показано, не ждать CTA)",
            "step_7": "Механическая тромбэктомия (если показана)"
        }
    },
    
    "carotid_stenting": {
        "indications": {
            "symptomatic": [
                "Стеноз >50% (предпочтительно >70%)",
                "Высокий риск для CEA"
            ],
            "asymptomatic": [
                "Стеноз >80%",
                "Высокий риск для CEA",
                "Жизненная ожидаемость >5 лет"
            ]
        },
        "high_risk_for_cea": [
            "Сердечная недостаточность (NYHA III-IV)",
            "Тяжелая ХОБЛ",
            "Контралатеральное окклюзия ПСА",
            "Рецидивный стеноз после CEA",
            "Лучевая терапия шеи",
            "Высокая бифуркация (C2 или выше)",
            "Трахеостомия"
        ],
        
        "technique": {
            "access": "Феморальная или радиальная артерия",
            "protection_device": {
                "options": [
                    "Distal filter (Spider, Emboshield)",
                    "Proximal occlusion (MO.MA)",
                    "Flow reversal (Gore Flow Reversal)"
                ],
                "mandatory": "Да (кроме особых случаев)"
            },
            "pre_dilation": "При тяжелом стенозе (4-5 мм баллон)",
            "stent_selection": {
                "closed_cell": "Acculink, Xact (лучше при tortuosity)",
                "open_cell": "Precise, Protégé (лучше conformability)"
            },
            "post_dilation": "При остаточном стенозе >30%"
        },
        
        "complications": {
            "stroke": "2-5% (30 дней)",
            "mi": "1-2%",
            "death": "<1%"
        },
        
        "post_procedure": {
            "dual_antiplatelet": "Аспирин + клопидогрель минимум 1 месяц",
            "monitoring": "Неврологический статус, АД",
            "follow_up": "УЗИ через 1 месяц, затем каждые 6 месяцев"
        }
    },
    
    "intracranial_stenosis": {
        "indication": "Симптоматический стеноз 70-99% (после неудачи медикаментозного)",
        "technique": {
            "access": "Феморальная артерия",
            "guide_catheter": "6F Envoy или Neuron",
            "microcatheter": "Excelsior SL-10",
            "wire": "0.014\" (Synchro, Transend)",
            "predilation": "Gateway balloon (1.5-3 мм)",
            "stent": "Wingspan (саморасширяющийся)"
        },
        "complications": {
            "stroke": "7-10%",
            "death": "2-3%"
        },
        "alternative": "Intracranial angioplasty без стентирования"
    }
}


# ==================== ВНУТРИЧЕРЕПНЫЕ АНЕВРИЗМЫ ====================

INTRACRANIAL_ANEURYSMS = {
    "classification": {
        "size": {
            "small": "<10 мм",
            "large": "10-25 мм",
            "giant": ">25 мм"
        },
        "shape": {
            "saccular": "Мешотчатая (обычная)",
            "fusiform": "Фузиформная (все стенки)"
        },
        "location": {
            "anterior": "ICA, ACom, ACA, MCA",
            "posterior": "Basilar, PCA, vertebral, PICA"
        }
    },
    
    "rupture_risk": {
        "factors": [
            "Размер (>7 мм - значимый риск)",
            "Локализация (задняя циркуляция - выше риск)",
            "Форма (неправильная - выше риск)",
            "Рост",
            "Семейный анамнез",
            "Предыдущий субарахноидальное кровоизлияние"
        ],
        "ISUIA": {
            "anterior": {
                "<7_mm": "0% (5 лет)",
                "7_12_mm": "2.6% (5 лет)",
                ">13_mm": "14.5% (5 лет)"
            },
            "posterior": {
                "<7_mm": "2.5% (5 лет)",
                "7_12_mm": "14.5% (5 лет)",
                ">13_mm": "50% (5 лет)"
            }
        }
    },
    
    "endovascular_treatment": {
        "coiling": {
            "name": "Коагуляция (coiling)",
            "technique": "Платиновые спирали в мешок аневризмы",
            "indication": "Мешотчатые аневризмы с подходящей шейкой",
            "adjuncts": [
                "Balloon remodeling (для широкой шейки)",
                "Stent-assisted coiling",
                "Flow diverters"
            ],
            "complications": {
                "perforation": "2-5%",
                "thromboembolism": "5-10%",
                "recurrence": "20-30% (требует повторной процедуры)"
            }
        },
        
        "flow_diverter": {
            "name": "Flow diverter (Pipeline, Surpass)",
            "mechanism": "Перенаправление потока от аневризмы",
            "indication": "Большие/гигантские, фузиформные, рецидив после коагуляции",
            "dual_antiplatelet": "Обязательно (аспирин + клопидогрель 3-6 месяцев)",
            "complications": {
                "ischemic_stroke": "5-10%",
                "aneurysm_rupture": "2-5% (особенно большие)",
                "in_stent_stenosis": "5-10%"
            },
            "follow_up": "MRA через 6, 12, 24 месяца"
        },
        
        "parent_artery_occlusion": {
            "name": "Окклюзия родительской артерии",
            "indication": "Гигантские аневризмы, не поддающиеся другим методам",
            "test_occlusion": "Обязательно перед процедурой",
            "complications": "Ишемический инсульт (10-20%)"
        }
    },
    
    "sah_management": {
        "grading": {
            "hunt_hess": {
                "1": "Asymptomatic или легкая головная боль",
                "2": "Умеренная-сильная головная боль, менингизм",
                "3": "Сонливость, спутанность сознания",
                "4": "Ступор, умеренная гемипарез",
                "5": "Кома, декеребрационная ригидность"
            },
            "wfns": {
                "1": "GCS 15, моторика отсутствует",
                "2": "GCS 14-13, моторика отсутствует",
                "3": "GCS 14-13, моторика присутствует",
                "4": "GCS 12-7, моторика ±",
                "5": "GCS 6-3"
            }
        },
        
        "complications": {
            "vasospasm": {
                "timing": "День 3-14 (пик день 7-10)",
                "prevention": "Нимодипин 60 мг per os/через зонд каждые 4 часа",
                "treatment": [
                    "Triple-H therapy (гиперволемия, гипертензия, гемодилюция)",
                    "Ангиопластика",
                    "Intra-arterial вазодилататоры (верапамил, никардипин)"
                ]
            },
            "hydrocephalus": {
                "treatment": "Вентрикулостомия"
            },
            "rebleeding": {
                "risk": "4% первый день, 1-2%/день первые 2 недели",
                "prevention": "Ранняя окклюзия аневризмы"
            }
        }
    }
}


# ==================== АРТЕРИОВЕНОЗНЫЕ МАЛЬФОРМАЦИИ ====================

AVM = {
    "grading": {
        "spetzler_martin": {
            "size": {
                "small": "<3 см (1 балл)",
                "medium": "3-6 см (2 балла)",
                "large": ">6 см (3 балла)"
            },
            "eloquence": {
                "non_eloquent": "0 баллов",
                "eloquent": "1 балл (sensorimotor, language, visual, brainstem, cerebellar peduncles)"
            },
            "venous_drainage": {
                "superficial": "0 баллов",
                "deep": "1 балл"
            },
            "interpretation": {
                "1": "Низкий риск - хирургия",
                "2": "Низкий риск - хирургия",
                "3": "Умеренный риск - индивидуальный подход",
                "4": "Высокий риск - эндоваскулярная/лучевая терапия",
                "5": "Высокий риск - эндоваскулярная/лучевая терапия"
            }
        }
    },
    
    "endovascular_treatment": {
        "embolization": {
            "agents": [
                "NBCA (n-butyl cyanoacrylate)",
                "Onyx (ethylene vinyl alcohol copolymer)",
                "Coils (для высокопоточных)"
            ],
            "goal": "Уменьшение размера перед хирургией или лучевой терапией",
            "curative": "Редко (только для небольших AVM)"
        },
        
        "staged_embolization": {
            "indication": "Большие AVM",
            "approach": "2-4 процедуры с интервалом 4-8 недель",
            "goal": "Постепенная окклюзия, избегая нормальной перфузной прорыв"
        }
    }
}


# ==================== ДУРАЛЬНЫЕ АРТЕРИОВЕНОЗНЫЕ ФИСТУЛЫ ====================

DAVF = {
    "classification": {
        "borden": {
            "type_1": {
                "description": "Drainage в синус",
                "risk": "Низкий",
                "treatment": "Эмболизация или наблюдение"
            },
            "type_2": {
                "description": "Drainage в синус + ретроградно в кортикальные вены",
                "risk": "Умеренный",
                "treatment": "Эмболизация"
            },
            "type_3": {
                "description": "Только ретроградный drainage в кортикальные вены",
                "risk": "Высокий (кровоизлияние)",
                "treatment": "Срочная эмболизация"
            }
        },
        "cognard": {
            "description": "Более детальная классификация",
            "type_I_IIa": "Низкий риск",
            "type_IIb_III_IV_V": "Высокий риск"
        }
    },
    
    "treatment": {
        "embolization": {
            "approach": "Трансартериальная или трансвенозная",
            "agents": "Onyx, NBCA, coils",
            "goal": "Окклюзия shunt"
        },
        "surgery": {
            "indication": "Невозможность эндоваскулярного доступа",
            "technique": "Диссекция sinus с коагуляцией"
        },
        "radiosurgery": {
            "indication": "Маленькие, труднодоступные",
            "latency": "1-3 года"
        }
    }
}


# ==================== ФУНКЦИИ ДЛЯ API ====================

def get_stroke_treatment_window(onset_time_hours: float, nihss: int, 
                                 large_vessel_occlusion: bool) -> Dict[str, Any]:
    """
    Определить возможности лечения инсульта
    """
    options = []
    
    # IV tPA
    if onset_time_hours <= 4.5:
        options.append({
            "treatment": "IV tPA",
            "window": "4.5 часов",
            "eligible": True,
            "dosing": "0.9 мг/кг"
        })
    
    # Mechanical thrombectomy
    if onset_time_hours <= 6:
        if large_vessel_occlusion and nihss >= 6:
            options.append({
                "treatment": "Механическая тромбэктомия",
                "window": "6 часов",
                "eligible": True
            })
    elif onset_time_hours <= 24:
        if large_vessel_occlusion and nihss >= 6:
            options.append({
                "treatment": "Механическая тромбэктомия (расширенное окно)",
                "window": "6-24 часов",
                "eligible": True,
                "note": "Требуется соответствие критериям DAWN/DEFUSE"
            })
    
    if not options:
        options.append({
            "treatment": "Медикаментозная терапия",
            "eligible": True,
            "note": "Вне окон для реперфузии"
        })
    
    return {
        "onset_time_hours": onset_time_hours,
        "nihss": nihss,
        "large_vessel_occlusion": large_vessel_occlusion,
        "treatment_options": options
    }


def calculate_spetzler_martin(size_cm: float, eloquent: bool, 
                               deep_drainage: bool) -> Dict[str, Any]:
    """
    Расчет градации Spetzler-Martin для AVM
    """
    score = 0
    
    # Size
    if size_cm < 3:
        score += 1
    elif size_cm <= 6:
        score += 2
    else:
        score += 3
    
    # Eloquence
    if eloquent:
        score += 1
    
    # Deep drainage
    if deep_drainage:
        score += 1
    
    # Interpretation
    if score <= 2:
        recommendation = "Хирургия - низкий риск"
    elif score == 3:
        recommendation = "Индивидуальный подход"
    else:
        recommendation = "Эндоваскулярная/лучевая терапия - высокий риск"
    
    return {
        "spetzler_martin_score": score,
        "size_points": 1 if size_cm < 3 else (2 if size_cm <= 6 else 3),
        "eloquence_points": 1 if eloquent else 0,
        "deep_drainage_points": 1 if deep_drainage else 0,
        "recommendation": recommendation
    }


def get_aneurysm_treatment_recommendation(size_mm: float, location: str, 
                                         shape: str, ruptured: bool) -> Dict[str, Any]:
    """
    Рекомендация по лечению аневризмы
    """
    # Риск разрыва
    if location in ["basilar", "vertebral", "PCA"]:
        annual_rupture_risk = "0.5-2%" if size_mm < 7 else "2-5%"
    else:
        annual_rupture_risk = "0.1-0.5%" if size_mm < 7 else "1-2%"
    
    # Показания к лечению
    if ruptured:
        indication = "Срочное лечение (в течение 24-72 часов)"
        treatment = "Коагуляция или клипирование"
    elif size_mm >= 7:
        indication = "Лечение рекомендуется"
        if shape == "irregular":
            treatment = "Flow diverter или стент-ассистированная коагуляция"
        else:
            treatment = "Коагуляция (при подходящей шейке) или flow diverter"
    elif size_mm >= 5:
        indication = "Рассмотреть лечение (особенно задняя циркуляция)"
        treatment = "Индивидуальное решение"
    else:
        indication = "Наблюдение (если нет других факторов риска)"
        treatment = "MRA через 6-12 месяцев"
    
    return {
        "size_mm": size_mm,
        "location": location,
        "annual_rupture_risk": annual_rupture_risk,
        "indication": indication,
        "recommended_treatment": treatment
    }
