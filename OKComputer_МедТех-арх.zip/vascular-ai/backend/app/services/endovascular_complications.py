"""
VASCULAR.AI - Осложнения эндоваскулярных вмешательств
На основе:
- Complications in Vascular Interventional Therapy (Mueller-Huelsbeck, Jahnke)
- Fifty Cases of Peripheral Vascular Interventions (White)
- Practical Approach to Peripheral Arterial CTO (Banerjee)
"""

from typing import Dict, Any, List, Optional


# ==================== ОСЛОЖНЕНИЯ ДОСТУПА ====================

ACCESS_COMPLICATIONS = {
    "hematoma": {
        "name": "Гематома",
        "incidence": "2-6%",
        "risk_factors": [
            "Артериальная гипертензия",
            "Крупные шиты",
            "Низкий укол",
            "Плохая компрессия",
            "Антикоагуляция"
        ],
        "prevention": [
            "УЗ-наведение",
            "Микропанкчер",
            "Тщательная компрессия",
            "Устройства закрытия при подходящей анатомии"
        ],
        "treatment": {
            "small": "Наблюдение, компрессия",
            "large": "Аспирация под УЗИ (если симптоматична)",
            "expanding": "Срочная хирургическая эвакуация"
        }
    },
    
    "pseudoaneurysm": {
        "name": "Псевдоаневризма",
        "incidence": "0.05-6%",
        "mechanism": "Неполное заживление артериотомии",
        "diagnosis": {
            "physical": "Пульсирующая масса, сосудистый шум",
            "ultrasound": "Сак с кровотоком, шейка от аортериотомии"
        },
        "treatment_options": {
            "ultrasound_guided_compression": {
                "description": "УЗ-направленная компрессия",
                "success_rate": "70-90%",
                "contraindications": ["Большой размер (>3 см)", "Широкое основание", "Антикоагуляция"]
            },
            "thrombin_injection": {
                "description": "УЗ-направленная инъекция тромбина",
                "dose": "100-1000 ЕД",
                "success_rate": "90-95%",
                "complications": "Дистальная эмболизация (редко)"
            },
            "surgical": {
                "description": "Хирургическая закрытие",
                "indication": "Неудача консервативных методов"
            }
        }
    },
    
    "arteriovenous_fistula": {
        "name": "Артериовенозная фистула",
        "incidence": "0.2-1%",
        "mechanism": "Соединение артерии и вены при проколе",
        "diagnosis": "УЗИ: непрерывный кровоток, turbulent flow",
        "treatment": {
            "small": "Наблюдение (часто закрывается спонтанно)",
            "large": "УЗ-направленная компрессия или хирургия"
        }
    },
    
    "dissection": {
        "name": "Диссекция сосуда",
        "incidence": "0.5-2%",
        "mechanism": "Проводник/катетер под intima",
        "treatment": {
            "hemodynamically_significant": "Стентирование",
            "minor": "Наблюдение (часто заживает)"
        }
    },
    
    "retroperitoneal_hemorrhage": {
        "name": "Ретроперитонеальное кровотечение",
        "incidence": "0.2-0.5%",
        "risk_factors": [
            "Высокий прокол (выше паховой связки)",
            "Низкий зажим",
            "Антикоагуляция",
            "Гипертензия"
        ],
        "signs": [
            "Боль в спине/боку",
            "Гипотензия",
            "Падение гематокрита",
            "Отсутствие гематомы на коже"
        ],
        "diagnosis": "КТ с контрастом",
        "treatment": [
            "Массивное переливание",
            "Реверсия антикоагуляции",
            "Ангиография с эмболизацией",
            "Хирургия при нестабильности"
        ]
    }
}


# ==================== ОСЛОЖНЕНИЯ ПРИ АНГИОПЛАСТИКЕ ====================

ANGIOPLASTY_COMPLICATIONS = {
    "dissection": {
        "name": "Диссекция",
        "incidence": "5-10%",
        "types": {
            "type_a": {"description": "Минимальная, не ограничивает поток", "action": "Наблюдение"},
            "type_b": {"description": "Умеренная, сохраняется поток", "action": "Наблюдение"},
            "type_c": {"description": "Значимая, ограничивает поток", "action": "Стентирование"},
            "type_d": {"description": "Спиральная, ограничивает поток", "action": "Стентирование"},
            "type_e": {"description": "Новая окклюзия", "action": "Стентирование или хирургия"},
            "type_f": {"description": "Перфорация", "action": "Покрытый стент или хирургия"}
        }
    },
    
    "perforation": {
        "name": "Перфорация сосуда",
        "incidence": "0.5-2%",
        "causes": [
            "Проводник через стенку",
            "Баллон перерастянут",
            "Кальцифицированная плака"
        ],
        "treatment": {
            "minor": "Протяжной баллон (противоположная стенка)",
            "significant": "Покрытый стент",
            "large": "Эмболизация или хирургия"
        }
    },
    
    "distal_embolization": {
        "name": "Дистальная эмболизация",
        "incidence": "2-5%",
        "risk_factors": [
            "Тромботическая масса",
            "Кальцифицированная плака",
            "Аневризма"
        ],
        "treatment": {
            "asymptomatic": "Наблюдение",
            "symptomatic": "Аспирация тромба, тромбэктомия"
        }
    },
    
    "acute_occlusion": {
        "name": "Острая окклюзия",
        "incidence": "2-5%",
        "causes": [
            "Диссекция с тромбозом",
            "Спазм",
            "Дистальная эмболизация"
        ],
        "treatment": [
            "Внутрисосудистый тромболиз",
            "Механическая тромбэктомия",
            "Стентирование",
            "Хирургия при необходимости"
        ]
    },
    
    "spasm": {
        "name": "Спазм сосуда",
        "incidence": "5-10% (особенно при CTO)",
        "treatment": [
            "Нитроглицерин 100-200 мкг в/артериально",
            "Верапамил 2.5-5 мг",
            "Аденозин 60-120 мкг"
        ]
    }
}


# ==================== ОСЛОЖНЕНИЯ СТЕНТИРОВАНИЯ ====================

STENT_COMPLICATIONS = {
    "stent_fracture": {
        "name": "Перелом стента",
        "incidence": "5-20% (зависит от локализации и типа)",
        "risk_factors": [
            "Длинные стенты",
            "Тортуозность",
            "Сжатие/растяжение",
            "Концентрическое кальцифицирование"
        ],
        "sites": {
            "popliteal": "До 40%",
            "femoropopliteal": "10-20%",
            "iliac": "<5%"
        },
        "treatment": {
            "asymptomatic": "Наблюдение",
            "symptomatic": "Перекрывающий стент"
        }
    },
    
    "in_stent_restenosis": {
        "name": "Рестеноз внутри стента",
        "incidence": "20-40% на 1 год",
        "mechanism": "Неоинтимальная гиперплазия",
        "treatment": [
            "Повторная ангиопластика",
            "Абляция atherectomy",
            "DCB (drug-coated balloon)",
            "DES (drug-eluting stent)",
            "Брахитерапия (редко)"
        ]
    },
    
    "stent_migration": {
        "name": "Миграция стента",
        "incidence": "1-3%",
        "risk_factors": [
            "Недостаточный oversizing",
            "Короткая landing zone",
            "Тортуозность"
        ],
        "treatment": "Перехват новым стентом или хирургия"
    },
    
    "stent_thrombosis": {
        "name": "Тромбоз стента",
        "incidence": "1-5%",
        "causes": [
            "Неполное раскрытие",
            "Диссекция",
            "Гиперкоагуляция",
            "Недостаточная антикоагуляция"
        ],
        "treatment": [
            "Тромболиз",
            "Механическая тромбэктомия",
            "Дополнительное стентирование"
        ]
    }
}


# ==================== ОСЛОЖНЕНИЯ EVAR/TEVAR ====================

EVAR_TEVAR_COMPLICATIONS = {
    "endoleak": {
        "name": "Endoleak",
        "definition": "Постоянный кровоток в мешок аневризмы",
        "incidence": "10-25%",
        "types": {
            "type_1": {
                "name": "Type I (проксимальный/дистальный)",
                "description": "Неплотное прилегание",
                "significance": "Высокий риск разрыва",
                "treatment": "Баллонирование, extension cuff, или конверсия"
            },
            "type_2": {
                "name": "Type II (обратный кровоток)",
                "description": "Питание от боковых ветвей (Lumbar, IMA)",
                "incidence": "10-20%",
                "significance": "Часто бессимптомен",
                "treatment": {
                    "conservative": "Наблюдение если <2 см и не растет",
                    "intervention": "Эмболизация при росте >5 мм или >2 см"
                }
            },
            "type_3": {
                "name": "Type III (модульная утечка)",
                "description": "Нарушение соединения компонентов",
                "significance": "Высокий риск разрыва",
                "treatment": "Дополнительный стент-графт или конверсия"
            },
            "type_4": {
                "name": "Type IV (пористость материала)",
                "description": "Кровоток через поры стент-графта",
                "significance": "Самоограничивается",
                "treatment": "Наблюдение"
            },
            "type_5": {
                "name": "Type V (endotension)",
                "description": "Рост аневризмы без видимой утечки",
                "significance": "Неясна",
                "treatment": "Конверсия при росте"
            }
        }
    },
    
    "graft_migration": {
        "name": "Миграция стент-графта",
        "incidence": "1-5%",
        "risk_factors": [
            "Короткая landing zone",
            "Большая ангуляция шейки",
            "Тортуозность"
        ],
        "treatment": "Proximal extension или конверсия"
    },
    
    "graft_occlusion": {
        "name": "Окклюзия стент-графта",
        "incidence": "2-5%",
        "causes": [
            "Тромбоз",
            "Диссекция",
            "Kinking"
        ],
        "treatment": "Тромбэктомия, стентирование, или хирургия"
    },
    
    "spinal_cord_ischemia": {
        "name": "Ишемия спинного мозга",
        "incidence": "2-10% (TEVAR)",
        "risk_factors": [
            "Длина покрытия >20 см",
            "Покрытие T8-L1",
            "Предыдущая абдоминальная аортальная операция",
            "Гипотензия"
        ],
        "prevention": [
            "Поддержание MAP >90 мм рт.ст.",
            "Люмбальный дренаж (при высоком риске)",
            "Реваскуляризация ЛПклА при необходимости"
        ],
        "signs": ["Парез/паралич ног", "Нарушение чувствительности", "Дисфункция мочевого пузыря/кишечника"],
        "treatment": [
            "Поддержание АД",
            "Люмбальный дренаж",
            "Кортикостероиды (спорно)"
        ]
    },
    
    "colon_ischemia": {
        "name": "Ишемия толстой кишки",
        "incidence": "1-3% (EVAR)",
        "risk_factors": [
            "Покрытие IMA",
            "Предыдущая колэктомия",
            "Гипотензия"
        ],
        "signs": ["Боль в животе", "Кровавый стул", "Лейкоцитоз", "Метаболический ацидоз"],
        "diagnosis": "Колоноскопия",
        "treatment": {
            "mild": "Консервативное",
            "severe": "Колэктомия"
        }
    }
}


# ==================== ОСЛОЖНЕНИЯ CTO ПРОЦЕДУР ====================

CTO_COMPLICATIONS = {
    "subintimal_tracking": {
        "name": "Субинтимальное прохождение",
        "incidence": "20-40%",
        "description": "Проводник проходит под intima",
        "outcomes": {
            "successful_re-entry": "70-80%",
            "perforation": "2-5%",
            "dissection": "10-20%"
        },
        "treatment": "Re-entry devices (Outback, Pioneer) или хирургия"
    },
    
    "perforation": {
        "name": "Перфорация",
        "incidence": "2-5%",
        "risk_factors": [
            "Тяжелый кальциноз",
            "Тортуозность",
            "Длинные поражения"
        ],
        "treatment": {
            "minor": "Протяжной баллон",
            "major": "Покрытый стент или эмболизация"
        }
    },
    
    "equipment_entrapment": {
        "name": "Застревание оборудования",
        "incidence": "<1%",
        "causes": [
            "Сломанный проводник",
            "Застрявший баллон",
            "Фрагмент стента"
        ],
        "treatment": [
            "Захватные устройства (snare)",
            "Хирургическое извлечение"
        ]
    }
}


# ==================== УПРАВЛЕНИЕ ОСЛОЖНЕНИЯМИ ====================

COMPLICATION_MANAGEMENT = {
    "immediate_response": {
        "vascular_surgeon": "Уведомить при:",
        "indications": [
            "Перфорация",
            "Острая окклюзия",
            "Ретроперитонеальное кровотечение",
            "Неудача эндоваскулярной коррекции"
        ]
    },
    
    "documentation": {
        "required": [
            "Тип осложнения",
            "Время возникновения",
            "Меры по коррекции",
            "Исход",
            "Уведомление пациента"
        ]
    },
    
    "quality_improvement": {
        "review": "Морбидность и смертность конференция",
        "learning": "Анализ для предотвращения повторения"
    }
}


# ==================== ФУНКЦИИ ДЛЯ API ====================

def get_complication_management(complication_type: str, severity: str) -> Dict[str, Any]:
    """
    Получить протокол управления осложнением
    """
    # Поиск в различных категориях
    all_complications = {}
    all_complications.update(ACCESS_COMPLICATIONS)
    all_complications.update(ANGIOPLASTY_COMPLICATIONS)
    all_complications.update(STENT_COMPLICATIONS)
    all_complications.update(EVAR_TEVAR_COMPLICATIONS)
    all_complications.update(CTO_COMPLICATIONS)
    
    complication = all_complications.get(complication_type)
    
    if not complication:
        return {
            "error": f"Complication {complication_type} not found",
            "available": list(all_complications.keys())
        }
    
    return {
        "complication": complication,
        "severity": severity,
        "management": complication.get("treatment", {})
    }


def assess_procedure_risk(procedure: str, patient_factors: Dict[str, Any]) -> Dict[str, Any]:
    """
    Оценка риска осложнений для процедуры
    """
    risk_score = 0
    risk_factors = []
    
    # Факторы риска
    if patient_factors.get("age", 0) > 75:
        risk_score += 1
        risk_factors.append("Возраст >75")
    
    if patient_factors.get("diabetes", False):
        risk_score += 1
        risk_factors.append("Диабет")
    
    if patient_factors.get("renal_insufficiency", False):
        risk_score += 2
        risk_factors.append("Почечная недостаточность")
    
    if patient_factors.get("anticoagulation", False):
        risk_score += 1
        risk_factors.append("Антикоагуляция")
    
    # Риск по процедуре
    procedure_risks = {
        "diagnostic_angiography": {"base_risk": "1-2%", "score": 1},
        "angioplasty": {"base_risk": "3-5%", "score": 2},
        "stenting": {"base_risk": "5-8%", "score": 3},
        "evar": {"base_risk": "5-10%", "score": 3},
        "tevar": {"base_risk": "10-15%", "score": 4},
        "cto": {"base_risk": "10-15%", "score": 4}
    }
    
    proc_info = procedure_risks.get(procedure, {"base_risk": "Unknown", "score": 2})
    total_score = risk_score + proc_info["score"]
    
    if total_score >= 7:
        risk_level = "Высокий"
    elif total_score >= 4:
        risk_level = "Умеренный"
    else:
        risk_level = "Низкий"
    
    return {
        "procedure": procedure,
        "base_risk": proc_info["base_risk"],
        "risk_score": total_score,
        "risk_level": risk_level,
        "risk_factors": risk_factors,
        "recommendations": [
            "Тщательный информированный согласие",
            "Подготовка к возможным осложнениям",
            "Наблюдение в течение 24 часов (высокий риск)"
        ] if risk_level == "Высокий" else []
    }
