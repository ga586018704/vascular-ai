"""
VASCULAR.AI - AI Decision Support System v2.0
Интеллектуальная система поддержки принятия решений для сосудистых хирургов
Интегрировано с ESVS 2024 Guidelines (160 рекомендаций), SVS Guidelines, 
российскими клиническими рекомендациями 2024 и данными PubMed
"""

from typing import Dict, Any, List, Optional, Tuple
from dataclasses import dataclass, field
from enum import Enum
import json
from datetime import datetime


class RiskLevel(Enum):
    LOW = "low"
    MODERATE = "moderate"
    HIGH = "high"
    EXTREME = "extreme"


class ApproachType(Enum):
    OPEN = "open"
    ENDOVASCULAR = "endovascular"
    HYBRID = "hybrid"
    CONSERVATIVE = "conservative"


class AneurysmType(Enum):
    DEGENERATIVE = "degenerative"
    MYOTIC = "myotic"
    INFLAMMATORY = "inflammatory"
    CONNECTIVE_TISSUE_DISORDER = "connective_tissue_disorder"
    TRAUMATIC = "traumatic"
    ANASTOMOTIC = "anastomotic"


@dataclass
class PatientRiskProfile:
    """Профиль риска пациента с расширенными параметрами"""
    age: int
    bmi: float
    comorbidities: List[str]
    cardiac_risk: RiskLevel
    renal_function: str  # normal, mild, moderate, severe
    egfr: Optional[float] = None  # Скорость клубочковой фильтрации
    pulmonary_status: str = "normal"
    previous_surgeries: List[str] = field(default_factory=list)
    medications: List[str] = field(default_factory=list)
    allergies: List[str] = field(default_factory=list)
    functional_status: str = "independent"  # independent, assisted, dependent
    frailty_score: Optional[int] = None  # 0-9 (Fried Frailty Index)
    das_score: Optional[int] = None  # Duke Activity Status Index
    smoking_status: str = "never"  # never, former, current
    family_history_aaa: bool = False
    genetic_syndrome: Optional[str] = None  # Marfan, Ehlers-Danlos, Loeys-Dietz


@dataclass
class AnatomicalFeatures:
    """Анатомические особенности с учетом ESVS 2024 критериев"""
    vessel_diameter_mm: float
    vessel_tortuosity: str  # straight, mild, moderate, severe
    calcification_degree: str  # none, mild, moderate, severe
    thrombus_presence: bool
    aneurysm_neck_length_mm: Optional[float] = None
    aneurysm_angulation: Optional[float] = None
    landing_zone_quality: str = "good"  # good, moderate, poor
    access_vessel_quality: str = "good"
    # Дополнительные параметры для EVAR
    neck_diameter_mm: Optional[float] = None
    neck_angulation: Optional[float] = None
    iliac_artery_diameter_mm: Optional[float] = None
    iliac_artery_tortuosity: str = "straight"
    # Параметры для оценки пригодности EVAR
    infrarenal_neck_length: Optional[float] = None
    suprarenal_neck_angle: Optional[float] = None
    aortic_bifurcation_diameter: Optional[float] = None


@dataclass
class AneurysmCharacteristics:
    """Характеристики аневризмы согласно ESVS 2024"""
    max_diameter_mm: float
    type: AneurysmType
    location: str  # infrarenal, juxtarenal, pararenal, suprarenal
    growth_rate_mm_per_year: Optional[float] = None
    symptoms: List[str] = field(default_factory=list)
    rupture_risk: Optional[str] = None
    morphology: str = "fusiform"  # fusiform, saccular
    wall_thickness: Optional[float] = None
    inflammatory_markers: Dict[str, float] = field(default_factory=dict)
    # Для микотических аневризм
    infection_source: Optional[str] = None
    positive_cultures: List[str] = field(default_factory=list)
    # Для воспалительных ААА
    retroperitoneal_fibrosis: bool = False
    ureteral_involvement: bool = False


# ==================== ESVS 2024 GUIDELINES DATA ====================

ESVS_2024_RECOMMENDATIONS = {
    "aaa_repair_thresholds": {
        "men": 55,  # mm - Class I, Level A
        "women": 50,  # mm - Class I, Level A
        "growth_rate": 10,  # mm/year
        "symptomatic_any_size": True,  # Class I, Level B
    },
    "evar_anatomical_criteria": {
        "infrarenal_neck_length_min": 10,  # mm
        "infrarenal_neck_diameter_max": 32,  # mm
        "neck_angulation_max": 60,  # degrees
        "access_artery_diameter_min": 6,  # mm
        "iliac_artery_diameter_max": 20,  # mm
        "landing_zone_length_min": 15,  # mm
    },
    "surveillance_intervals": {
        "aaa_30_39mm": 36,  # months
        "aaa_40_44mm": 12,  # months
        "aaa_45_54mm": 6,   # months
        "post_evar": 1,     # month, then 6, then annually
        "post_open": 1,     # month, then 12, then annually
    },
    "center_volume_requirements": {
        "open_aaa_min_per_year": 30,  # cases
        "evar_min_per_year": 30,      # cases
        "ruptured_aaa_min_per_year": 10,  # cases
    }
}

# Редкие патологии (добавлено на основе PubMed и клинических рекомендаций)
RARE_PATHOLOGIES = {
    "mycotic_aneurysm": {
        "description": "Микотическая (инфекционная) аневризма",
        "etiology": ["Staphylococcus aureus", "Salmonella", "Streptococcus"],
        "treatment": "Экстраанатомическое шунтирование + длительная антибиотикотерапия",
        "mortality_risk": "Высокий (20-40%)",
        "special_considerations": [
            "Обязательная эволютная реконструкция",
            "6-12 недель парентеральных антибиотиков",
            "Консультация инфекциониста",
            "Исключение эндоваскулярного лечения (высокий риск инфекции)"
        ]
    },
    "inflammatory_aaa": {
        "description": "Воспалительная аневризма брюшной аорты",
        "features": ["Толщина стенки >5 мм", "Ретроперитонеальный фиброз", "Вовлечение мочеточников"],
        "treatment": "Открытая операция с осторожной мобилизацией",
        "preop_preparation": "Кортикостероиды за 2-4 недели до операции",
        "special_considerations": [
            "Высокий риск повреждения мочеточников",
            "Необходимость предоперационной стентировки мочеточников",
            "Возможность рецидива фиброза"
        ]
    },
    "vascular_ehlers_danlos": {
        "description": "Сосудистая форма синдрома Элерса-Данло (vEDS)",
        "gene": "COL3A1",
        "features": ["Хрупкие сосуды", "Спонтанное разрывы", "Молодой возраст"],
        "treatment": "Консервативное при диаметре <50 мм",
        "surgical_risk": "Очень высокий (50-70% осложнений)",
        "special_considerations": [
            "Избегать агрессивной мобилизации",
            "Использовать нерассасывающиеся швы",
            "Минимальная манипуляция тканями",
            "Пожизненный прием целекоксиба (возможно)"
        ]
    },
    "marfan_syndrome": {
        "description": "Синдром Марфана",
        "gene": "FBN1",
        "aortic_threshold": 50,  # mm
        "treatment": "Ранняя операция при 50 мм",
        "special_considerations": [
            "Val-sparing root replacement предпочтительно",
            "Пожизненный бета-блокаторы",
            "Ежегодное наблюдение"
        ]
    },
    "loeyes_dietz": {
        "description": "Синдром Лойса-Дитца",
        "gene": "TGFBR1/2",
        "aortic_threshold": 42,  # mm - более агрессивный курс
        "special_considerations": [
            "Очень агрессивное течение",
            "Операция при 42 мм",
            "Семейный скрининг обязателен"
        ]
    }
}

# Кардиологический риск (по данным 2024 ACC/AHA Guidelines)
CARDIAC_RISK_FACTORS = {
    "active_cardiac_conditions": [
        "Нестабильная стенокардия",
        "Декомпенсированная СН (NYHA IV)",
        "Тяжелая аритмия",
        "Тяжелый стеноз аортального клапана",
        "Острый инфаркт миокарда (<30 дней)"
    ],
    "rcr_high_risk": {
        "score_threshold": 2,
        "features": ["ИМ <3 мес", "СН", "Диабет на инсулине", "ХПН (КК<30)"],
        "recommended_tests": ["Стресс-тест", "ЭхоКГ", "Коронарография (при необходимости)"]
    },
    "das_interpretation": {
        "excellent": ("≥10 METs", "Низкий риск"),
        "good": ("7-10 METs", "Умеренный риск"),
        "moderate": ("4-7 METs", "Повышенный риск"),
        "poor": ("<4 METs", "Высокий риск")
    }
}


class AIDecisionSupport:
    """
    AI-система поддержки принятия решений v2.0
    Интегрирована с ESVS 2024 Guidelines и доказательной медициной
    """
    
    def __init__(self):
        self.risk_calculator = SurgicalRiskCalculator()
        self.approach_selector = ApproachSelector()
        self.access_planner = AccessPlanner()
        self.outcome_predictor = OutcomePredictor()
        self.esvs_guidelines = ESVS_2024_RECOMMENDATIONS
        self.rare_pathologies = RARE_PATHOLOGIES
    
    def analyze_case(
        self,
        patient_data: Dict[str, Any],
        ct_measurements: Dict[str, Any],
        pathology_type: str
    ) -> Dict[str, Any]:
        """
        Полный анализ случая с учетом клинических рекомендаций
        """
        # Создаем профили
        risk_profile = self._create_risk_profile(patient_data)
        anatomical = self._create_anatomical_profile(ct_measurements)
        
        # Проверка на редкие патологии
        rare_pathology_check = self._check_rare_pathologies(patient_data, ct_measurements)
        
        # Расчет рисков с учетом ESVS 2024
        surgical_risks = self.risk_calculator.calculate(risk_profile, pathology_type)
        
        # Выбор подхода с учетом клинических рекомендаций
        approach_recommendation = self.approach_selector.select(
            risk_profile, anatomical, pathology_type, self.esvs_guidelines
        )
        
        # Планирование доступа
        access_plan = self.access_planner.plan(
            anatomical, approach_recommendation, pathology_type
        )
        
        # Прогнозирование исходов
        outcome_prediction = self.outcome_predictor.predict(
            risk_profile, anatomical, approach_recommendation
        )
        
        # Генерация полного отчета с доказательной базой
        return {
            "case_summary": self._generate_case_summary(patient_data, pathology_type),
            "rare_pathology_alert": rare_pathology_check,
            "risk_assessment": surgical_risks,
            "approach_recommendation": approach_recommendation,
            "access_plan": access_plan,
            "outcome_prediction": outcome_prediction,
            "preoperative_preparation": self._generate_preop_plan(risk_profile, pathology_type),
            "intraoperative_checklist": self._generate_intraop_checklist(pathology_type),
            "postoperative_monitoring": self._generate_postop_plan(risk_profile, pathology_type),
            "alternative_options": self._generate_alternatives(
                approach_recommendation, risk_profile, anatomical
            ),
            "evidence_base": self._get_evidence_base(pathology_type),
            "surveillance_plan": self._generate_surveillance_plan(pathology_type, ct_measurements),
            "esvs_2024_compliance": self._check_esvs_compliance(pathology_type, ct_measurements, patient_data),
        }
    
    def _create_risk_profile(self, data: Dict[str, Any]) -> PatientRiskProfile:
        """Создание расширенного профиля риска"""
        return PatientRiskProfile(
            age=data.get("age", 65),
            bmi=data.get("bmi", 25.0),
            comorbidities=data.get("comorbidities", []),
            cardiac_risk=self._assess_cardiac_risk(data),
            renal_function=data.get("renal_function", "normal"),
            egfr=data.get("egfr"),
            pulmonary_status=data.get("pulmonary_status", "normal"),
            previous_surgeries=data.get("previous_surgeries", []),
            medications=data.get("medications", []),
            allergies=data.get("allergies", []),
            functional_status=data.get("functional_status", "independent"),
            frailty_score=data.get("frailty_score"),
            das_score=data.get("das_score"),
            smoking_status=data.get("smoking_status", "never"),
            family_history_aaa=data.get("family_history_aaa", False),
            genetic_syndrome=data.get("genetic_syndrome")
        )
    
    def _create_anatomical_profile(self, data: Dict[str, Any]) -> AnatomicalFeatures:
        """Создание анатомического профиля с учетом ESVS критериев"""
        return AnatomicalFeatures(
            vessel_diameter_mm=data.get("vessel_diameter_mm", 0),
            vessel_tortuosity=data.get("vessel_tortuosity", "straight"),
            calcification_degree=data.get("calcification_degree", "none"),
            thrombus_presence=data.get("thrombus_presence", False),
            aneurysm_neck_length_mm=data.get("aneurysm_neck_length_mm"),
            aneurysm_angulation=data.get("aneurysm_angulation"),
            landing_zone_quality=data.get("landing_zone_quality", "good"),
            access_vessel_quality=data.get("access_vessel_quality", "good"),
            neck_diameter_mm=data.get("neck_diameter_mm"),
            neck_angulation=data.get("neck_angulation"),
            iliac_artery_diameter_mm=data.get("iliac_artery_diameter_mm"),
            iliac_artery_tortuosity=data.get("iliac_artery_tortuosity", "straight"),
            infrarenal_neck_length=data.get("infrarenal_neck_length"),
            suprarenal_neck_angle=data.get("suprarenal_neck_angle"),
            aortic_bifurcation_diameter=data.get("aortic_bifurcation_diameter")
        )
    
    def _check_rare_pathologies(self, patient_data: Dict, ct_data: Dict) -> Optional[Dict]:
        """Проверка на редкие патологии"""
        alerts = []
        
        # Проверка на генетические синдромы
        genetic = patient_data.get("genetic_syndrome")
        if genetic:
            if genetic in ["marfan", "Marfan"]:
                alerts.append({
                    "type": "marfan_syndrome",
                    "severity": "high",
                    "message": "Синдром Марфана - порог для операции 50 мм",
                    "recommendations": self.rare_pathologies["marfan_syndrome"]["special_considerations"]
                })
            elif genetic in ["ehlers_danlos_vascular", "vEDS"]:
                alerts.append({
                    "type": "vascular_ehlers_danlos",
                    "severity": "extreme",
                    "message": "vEDS - хирургический риск 50-70%, консервативное лечение предпочтительно",
                    "recommendations": self.rare_pathologies["vascular_ehlers_danlos"]["special_considerations"]
                })
            elif genetic in ["loeyes_dietz", "LDS"]:
                alerts.append({
                    "type": "loeyes_dietz",
                    "severity": "extreme",
                    "message": "Синдром Лойса-Дитца - операция при 42 мм",
                    "recommendations": self.rare_pathologies["loeyes_dietz"]["special_considerations"]
                })
        
        # Проверка на микотическую аневризму
        if ct_data.get("saccular_morphology") and ct_data.get("rapid_growth"):
            alerts.append({
                "type": "possible_mycotic",
                "severity": "high",
                "message": "Подозрение на микотическую аневризму (мешотидная форма + быстрый рост)",
                "recommendations": [
                    "Гемокультуры (3 раза)",
                    "Консультация инфекциониста",
                    "Экстраанатомическое шунтирование",
                    "12 недель антибиотиков"
                ]
            })
        
        # Проверка на воспалительную ААА
        if ct_data.get("wall_thickness_mm", 0) > 5 or ct_data.get("retroperitoneal_fibrosis"):
            alerts.append({
                "type": "inflammatory_aaa",
                "severity": "moderate",
                "message": "Возможна воспалительная аневризма",
                "recommendations": [
                    "Кортикостероиды за 2-4 недели",
                    "Осторожная мобилизация",
                    "Стентирование мочеточников при необходимости"
                ]
            })
        
        return alerts if alerts else None
    
    def _assess_cardiac_risk(self, data: Dict[str, Any]) -> RiskLevel:
        """Оценка сердечно-сосудистого риска по ACC/AHA 2024"""
        risk_score = 0
        
        # Активные сердечные состояния (высокий риск)
        active_conditions = data.get("active_cardiac_conditions", [])
        if active_conditions:
            return RiskLevel.HIGH
        
        # Расчет Revised Cardiac Risk Index (RCRI)
        rcri_score = 0
        if "ischemic_heart_disease" in data.get("comorbidities", []):
            rcri_score += 1
        if "heart_failure" in data.get("comorbidities", []):
            rcri_score += 1
        if "cerebrovascular_disease" in data.get("comorbidities", []):
            rcri_score += 1
        if "diabetes_on_insulin" in data.get("comorbidities", []):
            rcri_score += 1
        if data.get("egfr", 60) < 30:
            rcri_score += 1
        if data.get("high_risk_surgery"):
            rcri_score += 1
        
        # Интерпретация RCRI
        if rcri_score >= 2:
            return RiskLevel.HIGH
        elif rcri_score == 1:
            return RiskLevel.MODERATE
        
        # Дополнительные факторы
        if data.get("age", 0) > 70:
            risk_score += 1
        if "hypertension" in data.get("comorbidities", []):
            risk_score += 1
        
        if risk_score >= 3:
            return RiskLevel.HIGH
        elif risk_score >= 1:
            return RiskLevel.MODERATE
        
        return RiskLevel.LOW
    
    def _generate_case_summary(self, patient_data: Dict, pathology: str) -> Dict:
        """Генерация краткого описания случая"""
        return {
            "patient_age": patient_data.get("age"),
            "pathology": pathology,
            "complexity": self._assess_complexity(patient_data, pathology),
            "urgency": self._assess_urgency(patient_data, pathology),
            "summary_text": self._generate_summary_text(patient_data, pathology),
            "esvs_class": self._get_esvs_class(pathology)
        }
    
    def _assess_complexity(self, patient_data: Dict, pathology: str) -> str:
        """Оценка сложности случая"""
        complexity_score = 0
        
        # Сложность патологии
        complexity_weights = {
            "aortic_aneurysm_rupture": 5,
            "aortic_aneurysm": 2,
            "mycotic_aneurysm": 5,
            "inflammatory_aaa": 4,
            "carotid_stenosis": 2,
            "femoropopliteal_occlusion": 3,
            "varicose_veins": 1,
        }
        complexity_score += complexity_weights.get(pathology, 2)
        
        # Факторы пациента
        if patient_data.get("age", 0) > 75:
            complexity_score += 1
        if len(patient_data.get("comorbidities", [])) > 3:
            complexity_score += 1
        if patient_data.get("previous_surgeries"):
            complexity_score += 1
        if patient_data.get("genetic_syndrome"):
            complexity_score += 2
        
        if complexity_score >= 5:
            return "Высокая"
        elif complexity_score >= 3:
            return "Средняя"
        else:
            return "Низкая"
    
    def _assess_urgency(self, patient_data: Dict, pathology: str) -> Dict:
        """Оценка срочности согласно ESVS 2024"""
        urgent_conditions = [
            "aortic_aneurysm_rupture",
            "acute_arterial_thrombosis",
            "acute_deep_vein_thrombosis",
        ]
        
        if pathology in urgent_conditions:
            return {
                "level": "Экстренная",
                "timeframe": "< 2 часов",
                "reason": "Угроза жизни",
                "esvs_recommendation": "Class I, Level A - Немедленное вмешательство"
            }
        
        semi_urgent = ["carotid_stenosis_symptomatic", "femoropopliteal_occlusion_critical"]
        if pathology in semi_urgent:
            return {
                "level": "Срочная",
                "timeframe": "< 24 часов",
                "reason": "Высокий риск осложнений",
                "esvs_recommendation": "Class I, Level B"
            }
        
        # Для аневризм по ESVS 2024
        if "aortic_aneurysm" in pathology and "rupture" not in pathology:
            diameter = patient_data.get("max_diameter_mm", 0)
            if diameter > 70:
                return {
                    "level": "Приоритетная",
                    "timeframe": "< 2 недель",
                    "reason": f"Диаметр {diameter} мм (высокий риск разрыва)",
                    "esvs_recommendation": "Class I, Level B - Приоритетная операция"
                }
        
        return {
            "level": "Плановая",
            "timeframe": "1-4 недели",
            "reason": "Стабильное состояние",
            "esvs_recommendation": "Class IIa, Level B"
        }
    
    def _generate_summary_text(self, patient_data: Dict, pathology: str) -> str:
        """Генерация текстового описания"""
        age = patient_data.get("age", "неизвестно")
        comorbidities = ", ".join(patient_data.get("comorbidities", ["нет данных"]))
        genetic = patient_data.get("genetic_syndrome", "")
        
        summary = f"Пациент {age} лет с {pathology}. Сопутствующие заболевания: {comorbidities}."
        if genetic:
            summary += f" Генетический синдром: {genetic}."
        
        return summary
    
    def _get_esvs_class(self, pathology: str) -> str:
        """Получение класса рекомендации ESVS"""
        esvs_classes = {
            "aortic_aneurysm": "Class I, Level A",
            "aortic_aneurysm_rupture": "Class I, Level A",
            "carotid_stenosis": "Class I, Level A",
            "femoropopliteal_occlusion": "Class IIa, Level B",
        }
        return esvs_classes.get(pathology, "Class IIa, Level B")
    
    def _generate_preop_plan(self, risk_profile: PatientRiskProfile, pathology: str) -> Dict:
        """Генерация плана предоперационной подготовки с учетом ACC/AHA 2024"""
        preparations = []
        
        # Кардиологическая подготовка (ACC/AHA 2024)
        if risk_profile.cardiac_risk in [RiskLevel.HIGH, RiskLevel.MODERATE]:
            cardiac_prep = {
                "specialist": "Кардиолог",
                "actions": [
                    "ЭхоКГ с оценкой ФВ ЛЖ",
                    "Холтеровское мониторирование",
                    "Коррекция сердечной недостаточности",
                    "Оптимизация антигипертензивной терапии"
                ],
                "timeline": "За 3-7 дней до операции"
            }
            
            # DASI оценка
            if risk_profile.das_score is not None:
                if risk_profile.das_score < 4:
                    cardiac_prep["actions"].append("Стресс-тест (DASI <4 METs)")
            
            preparations.append(cardiac_prep)
        
        # Почечная функция
        if risk_profile.renal_function != "normal":
            prep = {
                "specialist": "Нефролог",
                "actions": [
                    "Контроль КФР и электролитов",
                    "Гидратация (изотонические растворы)",
                    "Минимизация нефротоксичных препаратов"
                ],
                "timeline": "За 1-2 дня до операции"
            }
            
            # Контрастная нефропатия профилактика
            if risk_profile.egfr and risk_profile.egfr < 60:
                prep["actions"].extend([
                    "N-ацетилцистеин 600 мг 2р/сут (до и после)",
                    "Изотоническая гидратация (1 мл/кг/ч за 12 ч до и после)"
                ])
            
            preparations.append(prep)
        
        # Антикоагулянты
        if "anticoagulants" in risk_profile.medications:
            preparations.append({
                "specialist": "Анестезиолог",
                "actions": [
                    "Перевод на низкомолекулярный гепарин",
                    "Контроль МНО/АКТ",
                    "Планирование времени отмены"
                ],
                "timeline": "За 5 дней до операции"
            })
        
        # Антиагреганты (двойная антиагрегация для стентирования)
        if "dual_antiplatelet" in risk_profile.medications or "carotid_stenting" in pathology:
            preparations.append({
                "specialist": "Терапевт",
                "actions": [
                    "Аспирин 75-100 мг/сут (продолжить)",
                    "Клопидогрель 75 мг/сут (начать за 5 дней)",
                    "Проверка функция тромбоцитов (P2Y12)"
                ],
                "timeline": "За 5-7 дней до операции"
            })
        
        # Для диабетиков
        if "diabetes" in risk_profile.comorbidities:
            preparations.append({
                "specialist": "Эндокринолог",
                "actions": [
                    "Целевой глюкозы 80-180 мг/дл",
                    "Перевод на инсулин (при необходимости)",
                    "Контроль HbA1c"
                ],
                "timeline": "За 1-2 дня до операции"
            })
        
        # Оценка хрупкости
        if risk_profile.frailty_score is not None and risk_profile.frailty_score >= 5:
            preparations.append({
                "specialist": "Гериатр",
                "actions": [
                    "Комплексная гериатрическая оценка",
                    "Оптимизация питания",
                    "Физиотерапия до операции"
                ],
                "timeline": "За 2-4 недели до операции"
            })
        
        # Общая подготовка
        preparations.append({
            "specialist": "Терапевт/Анестезиолог",
            "actions": [
                "ОАК, биохимия (креатинин, электролиты), коагулограмма",
                "Группа крови и резус-фактор",
                "Консультация анестезиолога",
                "Информированное согласие"
            ],
            "timeline": "За 1-2 дня до операции"
        })
        
        return {
            "preparations": preparations,
            "anesthesia_recommendation": self._recommend_anesthesia(risk_profile),
            "required_blood": self._estimate_blood_needs(risk_profile, pathology),
            "icu_probability": self._estimate_icu_need(risk_profile),
            "special_considerations": self._get_special_preop_considerations(risk_profile, pathology)
        }
    
    def _recommend_anesthesia(self, risk_profile: PatientRiskProfile) -> Dict:
        """Рекомендации по анестезии с учетом риска"""
        if risk_profile.cardiac_risk == RiskLevel.HIGH:
            return {
                "primary": "Эндотрахеальный наркоз с ИВЛ",
                "alternative": "Спинномозговая анестезия (при коротких операциях)",
                "monitoring": [
                    "Артериальная канюля (инвазивное АД)",
                    "ЦВК (центральное венозное давление)",
                    "ТЭЭ (трансэзофагеальная эхокардиография)",
                    "Мочевой катетер (диурез)",
                    "BIS-мониторинг (глубина наркоза)"
                ],
                "special_considerations": [
                    "Избегать гипотензии (САД >90 мм рт.ст.)",
                    "Контроль гемодинамики",
                    "Минимальная инвазивная гемодинамика (FloTrac)"
                ]
            }
        
        return {
            "primary": "Эндотрахеальный наркоз или спинномозговая анестезия",
            "alternative": "Проводниковая анестезия",
            "monitoring": [
                "Непрерывный мониторинг ЭКГ",
                "Неинвазивное АД",
                "Пульсоксиметрия",
                "Капнография"
            ],
            "special_considerations": ["Стандартный мониторинг"]
        }
    
    def _estimate_blood_needs(self, risk_profile: PatientRiskProfile, pathology: str) -> Dict:
        """Оценка потребности в крови"""
        base_units = 1
        
        if "aortic" in pathology:
            base_units = 3
        elif "carotid" in pathology:
            base_units = 1
        elif "femoral" in pathology:
            base_units = 2
        
        if risk_profile.cardiac_risk == RiskLevel.HIGH:
            base_units += 1
        
        return {
            "units_required": f"{base_units}-{base_units + 2} ЭДК",
            "type": "Эритроцитарная масса + свежезамороженная плазма",
            "crossmatch": "Обязательно",
            "rationale": f"Базовая потребность {base_units} ЭДК + резерв"
        }
    
    def _estimate_icu_need(self, risk_profile: PatientRiskProfile) -> Dict:
        """Оценка необходимости ИТО"""
        if risk_profile.cardiac_risk == RiskLevel.HIGH:
            return {
                "probability": "Высокая (>70%)",
                "duration": "24-48 часов",
                "reason": "Мониторинг гемодинамики, коррекция АГ"
            }
        elif len(risk_profile.comorbidities) > 3:
            return {
                "probability": "Средняя (40-60%)",
                "duration": "12-24 часа",
                "reason": "Наблюдение за сопутствующей патологией"
            }
        
        return {
            "probability": "Низкая (<20%)",
            "duration": "Не требуется",
            "reason": "Плановое наблюдение в отделении"
        }
    
    def _get_special_preop_considerations(self, risk_profile: PatientRiskProfile, pathology: str) -> List[str]:
        """Специальные предоперационные рекомендации"""
        considerations = []
        
        if risk_profile.genetic_syndrome == "marfan":
            considerations.append("Бета-блокаторы до операции (снижение дАД)")
        
        if "inflammatory_aaa" in pathology:
            considerations.append("Кортикостероиды за 2-4 недели до операции")
        
        if risk_profile.smoking_status == "current":
            considerations.append("Отказ от курения минимум за 4 недели (снижение риска осложнений)")
        
        return considerations
    
    def _generate_intraop_checklist(self, pathology_type: str) -> List[Dict]:
        """Генерация интраоперационного чек-листа"""
        base_checklist = [
            {
                "phase": "Перед разрезом",
                "items": [
                    "Проверка идентификации пациента (Time Out)",
                    "Подтверждение стороны операции",
                    "Антибиотикопрофилактика (цефазолин 2г за 30-60 мин)",
                    "Гепаринизация перед пережатием сосудов"
                ]
            },
            {
                "phase": "Во время операции",
                "items": [
                    "Мониторинг диуреза (>0.5 мл/кг/ч)",
                    "Контроль АД (избегать гипотензии)",
                    "Температура тела (>36°C) - активное согревание",
                    "Контроль гемостаза"
                ]
            },
            {
                "phase": "Перед закрытием",
                "items": [
                    "Подсчет инструментов и салфеток",
                    "Проверка гемостаза",
                    "Дренирование (при необходимости)",
                    "Документация протезов/имплантов"
                ]
            }
        ]
        
        # Специфические пункты для разных патологий
        if "aortic" in pathology_type:
            base_checklist[1]["items"].extend([
                "Контроль лактата (каждые 30 мин)",
                "Мониторинг мочевого выхода",
                "Проверка пульсации на нижних конечностях",
                "Соматосенсорные вызванные потенциалы (при риске параплегии)"
            ])
        
        if "carotid" in pathology_type:
            base_checklist[1]["items"].extend([
                "Мониторинг мозговых функций (пациент бодрствует при локальной анестезии)",
                "Контроль stump pressure (>50 мм рт.ст.)",
                "Готовность к шунтированию",
                "Транскраниальная допплерография"
            ])
        
        return base_checklist
    
    def _generate_postop_plan(self, risk_profile: PatientRiskProfile, pathology: str) -> Dict:
        """Генерация плана послеоперационного наблюдения"""
        monitoring = {
            "vital_signs": "Каждые 15 мин первые 2 часа, затем каждый час",
            "wound_check": "Каждые 4 часа (отёк, гематома, инфекция)",
            "distal_pulses": "Каждые 2 часа первые 24 часа",
            "laboratory": "ОАК, креатинин через 6, 12, 24 часа"
        }
        
        complications_to_watch = [
            "Кровотечение",
            "Тромбоз",
            "Инфекция раны",
            "Сердечно-сосудистые события"
        ]
        
        if risk_profile.renal_function != "normal":
            complications_to_watch.append("Острая почечная недостаточность")
            monitoring["urine_output"] = "Строгий учёт диуреза (цель >0.5 мл/кг/ч)"
        
        if "aortic" in pathology:
            complications_to_watch.extend([
                "Параплегия (контроль двигательных функций)",
                "Ишемия кишечника (контроль живота)"
            ])
        
        return {
            "monitoring": monitoring,
            "complications_to_watch": complications_to_watch,
            "mobilization": "На 1-2 сутки (при стабильности)",
            "anticoagulation": self._recommend_postop_anticoagulation(risk_profile),
            "follow_up": "Через 7-14 дней (осмотр, УЗИ)",
            "surveillance": self._generate_surveillance_plan(pathology, {})
        }
    
    def _recommend_postop_anticoagulation(self, risk_profile: PatientRiskProfile) -> Dict:
        """Рекомендации по послеоперационной антикоагуляции"""
        if "atrial_fibrillation" in risk_profile.comorbidities:
            return {
                "indication": "Да (хроническая)",
                "agent": "Новые оральные антикоагулянты (НОАК) или варфарин",
                "duration": "Пожизненно",
                "target_inr": "2.0-3.0 (при варфарине)"
            }
        
        if "mechanical_heart_valve" in risk_profile.comorbidities:
            return {
                "indication": "Да (обязательно)",
                "agent": "Варфарин",
                "duration": "Пожизненно",
                "target_inr": "2.5-3.5"
            }
        
        return {
            "indication": "Профилактическая (при высоком риске ТГВ)",
            "agent": "Низкомолекулярный гепарин",
            "duration": "До мобилизации (обычно 3-5 дней)",
            "target_inr": "Н/П"
        }
    
    def _generate_alternatives(
        self,
        primary_approach: Dict,
        risk_profile: PatientRiskProfile,
        anatomical: AnatomicalFeatures
    ) -> List[Dict]:
        """Генерация альтернативных вариантов лечения"""
        alternatives = []
        
        # Если рекомендована открытая операция
        if primary_approach.get("type") == ApproachType.OPEN.value:
            alternatives.append({
                "option": "Эндоваскулярный подход",
                "suitable_for": "Пациенты с высоким хирургическим риском",
                "contraindications": ["Неподходящая анатомия", "Инфекция"],
                "advantages": ["Минимальная травматичность", "Быстрая реабилитация"],
                "disadvantages": ["Высокая стоимость", "Необходимость повторных вмешательств"]
            })
        
        # Если рекомендована эндоваскулярная операция
        if primary_approach.get("type") == ApproachType.ENDOVASCULAR.value:
            alternatives.append({
                "option": "Открытая операция",
                "suitable_for": "Молодые пациенты с низким риском",
                "contraindications": ["Тяжёлая сопутствующая патология"],
                "advantages": ["Долгосрочная эффективность", "Низкая стоимость"],
                "disadvantages": ["Травматичность", "Длительная реабилитация"]
            })
        
        # Консервативное лечение всегда альтернатива для некоторых случаев
        alternatives.append({
            "option": "Консервативное лечение",
            "suitable_for": "Высокий операционный риск, бессимптомное течение",
            "contraindications": ["Симптоматическая патология", "Прогрессирование"],
            "advantages": ["Отсутствие операционного риска", "Низкая стоимость"],
            "disadvantages": ["Прогрессирование заболевания", "Риск осложнений"]
        })
        
        return alternatives
    
    def _get_evidence_base(self, pathology_type: str) -> Dict:
        """Получение доказательной базы с учетом ESVS 2024"""
        evidence_bases = {
            "aortic_aneurysm": {
                "guidelines": ["ESVS Guidelines 2024 (160 рекомендаций)", "SVS Guidelines 2023"],
                "key_studies": ["UK Small Aneurysm Trial", "ADAM Trial", "DREAM Trial", "OVER Trial"],
                "recommendation_class": "Class I, Level A",
                "key_points": [
                    "Порог для операции: 55 мм (мужчины), 50 мм (женщины)",
                    "EVAR - первый выбор для рваных аневризм",
                    "Минимум 30 операций в год в центре"
                ]
            },
            "aortic_aneurysm_rupture": {
                "guidelines": ["ESVS Guidelines 2024", "IMPROVE Trial"],
                "key_studies": ["IMPROVE", "AJAX", "ECAR"],
                "recommendation_class": "Class I, Level A",
                "key_points": [
                    "EVAR предпочтительно при подходящей анатомии",
                    "Контроль АД (целевое 70-90 мм рт.ст.)",
                    "Быстрая транспортировка в центр"
                ]
            },
            "carotid_stenosis": {
                "guidelines": ["ESC/ESVS Guidelines 2023", "AHA/ASA Guidelines 2021"],
                "key_studies": ["NASCET", "ECST", "CREST", "ACST-2"],
                "recommendation_class": "Class I, Level A",
                "key_points": [
                    "Симптоматический стеноз >70% - показание к CEA",
                    "CEA предпочтительно CAS в большинстве случаев",
                    "CAS - при высоком хирургическом риске"
                ]
            },
            "femoropopliteal_occlusion": {
                "guidelines": ["TASC II Classification", "ESVS Guidelines 2024"],
                "key_studies": ["Bypass vs. Angioplasty trials", "Zilver PTX Trial"],
                "recommendation_class": "Class IIa, Level B",
                "key_points": [
                    "Вена предпочтительнее протеза",
                    "Длина окклюзии >25 см - показание к шунтированию",
                    "Drug-eluting stents улучшают результаты"
                ]
            },
            "varicose_veins": {
                "guidelines": ["Российские клинические рекомендации 2024", "NICE Guidelines"],
                "key_studies": ["CLASS Trial", "eSCIN Study"],
                "recommendation_class": "Class I, Level A",
                "key_points": [
                    "EVLA и RFA эквивалентны хирургии",
                    "Компрессионный трикотаж обязателен",
                    "Флебэктомия при выраженных варикозных узлах"
                ]
            }
        }
        
        return evidence_bases.get(pathology_type, {
            "guidelines": ["ESVS Guidelines 2024", "SVS Guidelines 2023"],
            "key_studies": ["Клинические рекомендации"],
            "recommendation_class": "Class IIa, Level B",
            "key_points": ["Индивидуальный подход к каждому пациенту"]
        })
    
    def _generate_surveillance_plan(self, pathology_type: str, measurements: Dict) -> Dict:
        """Генерация плана наблюдения согласно ESVS 2024"""
        if "aortic_aneurysm" in pathology_type and "rupture" not in pathology_type:
            diameter = measurements.get("aorta", {}).get("diameter_max", 0)
            
            if diameter < 40:
                return {
                    "interval_months": 36,
                    "method": "УЗИ брюшной полости",
                    "esvs_reference": "Class I, Level A"
                }
            elif diameter < 45:
                return {
                    "interval_months": 12,
                    "method": "УЗИ или КТ-ангиография",
                    "esvs_reference": "Class I, Level A"
                }
            elif diameter < 55:
                return {
                    "interval_months": 6,
                    "method": "КТ-ангиография",
                    "esvs_reference": "Class I, Level A"
                }
            else:
                return {
                    "interval_months": 0,
                    "method": "Рассмотреть операцию",
                    "esvs_reference": "Class I, Level A"
                }
        
        elif "post_evar" in pathology_type:
            return {
                "schedule": [
                    {"time": "1 месяц", "method": "КТ-ангиография"},
                    {"time": "6 месяцев", "method": "КТ-ангиография"},
                    {"time": "12 месяцев", "method": "КТ-ангиография"},
                    {"time": "Ежегодно", "method": "КТ-ангиография"}
                ],
                "esvs_reference": "Class I, Level A"
            }
        
        return {
            "interval_months": 12,
            "method": "УЗИ дуплексное сканирование",
            "esvs_reference": "Class IIa, Level B"
        }
    
    def _check_esvs_compliance(self, pathology: str, measurements: Dict, patient_data: Dict) -> Dict:
        """Проверка соответствия рекомендациям ESVS 2024"""
        compliance = {
            "compliant": True,
            "violations": [],
            "warnings": []
        }
        
        # Проверка порога для операции на ААА
        if "aortic_aneurysm" in pathology and "rupture" not in pathology:
            diameter = measurements.get("aorta", {}).get("diameter_max", 0)
            gender = patient_data.get("gender", "male")
            
            threshold = 55 if gender == "male" else 50
            
            if diameter >= threshold:
                compliance["warnings"].append(
                    f"Диаметр аневризмы {diameter} мм >= порога {threshold} мм - показание к операции (ESVS Class I, Level A)"
                )
        
        # Проверка объема центра
        compliance["warnings"].append(
            "Убедитесь, что центр выполняет минимум 30 операций на ААА в год (ESVS Class I, Level B)"
        )
        
        return compliance


# ==================== RISK CALCULATOR ====================

class SurgicalRiskCalculator:
    """Калькулятор хирургического риска с учетом ESVS 2024"""
    
    def calculate(self, risk_profile: PatientRiskProfile, pathology: str) -> Dict:
        """Расчет рисков операции"""
        
        # Риск смертности
        mortality_risk = self._calculate_mortality_risk(risk_profile, pathology)
        
        # Риск сердечно-сосудистых осложнений
        cardiac_risk = self._calculate_cardiac_risk(risk_profile)
        
        # Риск почечной недостаточности
        renal_risk = self._calculate_renal_risk(risk_profile)
        
        # Риск инфекции
        infection_risk = self._calculate_infection_risk(risk_profile)
        
        # Риск параплегии (для аортальных операций)
        paraplegia_risk = self._calculate_paraplegia_risk(risk_profile, pathology)
        
        return {
            "mortality": {
                "probability": mortality_risk,
                "level": self._risk_level(mortality_risk),
                "factors": self._get_mortality_risk_factors(risk_profile),
                "esvs_reference": "Risk prediction models (VSGNE, GAS)"
            },
            "cardiac_complications": {
                "probability": cardiac_risk,
                "level": self._risk_level(cardiac_risk),
                "types": ["ИМ", "аритмии", "ОСН", "гипертонический криз"]
            },
            "renal_failure": {
                "probability": renal_risk,
                "level": self._risk_level(renal_risk),
                "preventive_measures": ["Гидратация", "Контрастная защита", "N-ацетилцистеин"]
            },
            "infection": {
                "probability": infection_risk,
                "level": self._risk_level(infection_risk),
                "preventive_measures": ["Антибиотикопрофилактика", "Асептика", "Гликемический контроль"]
            },
            "paraplegia": paraplegia_risk,
            "overall_score": self._calculate_overall_score(risk_profile),
            "risk_stratification": self._stratify_risk(risk_profile),
            "risk_modification_suggestions": self._get_risk_modification_suggestions(risk_profile)
        }
    
    def _calculate_mortality_risk(self, profile: PatientRiskProfile, pathology: str) -> float:
        """Расчет риска смертности (%) с учетом типа операции"""
        base_risk = 1.0
        
        # Возраст
        if profile.age > 80:
            base_risk += 4.0
        elif profile.age > 75:
            base_risk += 2.5
        elif profile.age > 70:
            base_risk += 1.5
        
        # Сопутствующие заболевания
        if "heart_failure" in profile.comorbidities:
            base_risk += 3.0
        if "ischemic_heart_disease" in profile.comorbidities:
            base_risk += 2.0
        if "renal_failure" in profile.comorbidities:
            base_risk += 2.5
        if "copd" in profile.comorbidities:
            base_risk += 1.5
        
        # Тип операции
        if "rupture" in pathology:
            base_risk += 15.0
        elif "aortic" in pathology:
            base_risk += 3.0
        elif "carotid" in pathology:
            base_risk += 1.0
        
        # Генетические синдромы
        if profile.genetic_syndrome == "vascular_ehlers_danlos":
            base_risk += 10.0
        elif profile.genetic_syndrome == "marfan":
            base_risk += 2.0
        
        return min(base_risk, 40.0)
    
    def _calculate_cardiac_risk(self, profile: PatientRiskProfile) -> float:
        """Расчет сердечно-сосудистого риска"""
        base_risk = 2.0
        
        if profile.cardiac_risk == RiskLevel.HIGH:
            base_risk += 10.0
        elif profile.cardiac_risk == RiskLevel.MODERATE:
            base_risk += 5.0
        
        if "diabetes" in profile.comorbidities:
            base_risk += 2.0
        
        return min(base_risk, 25.0)
    
    def _calculate_renal_risk(self, profile: PatientRiskProfile) -> float:
        """Расчет риска почечной недостаточности"""
        if profile.renal_function == "severe":
            return 20.0
        elif profile.renal_function == "moderate":
            return 10.0
        elif profile.renal_function == "mild":
            return 4.0
        return 1.0
    
    def _calculate_infection_risk(self, profile: PatientRiskProfile) -> float:
        """Расчет риска инфекции"""
        base_risk = 2.0
        
        if "diabetes" in profile.comorbidities:
            base_risk += 4.0
        if "immunosuppression" in profile.comorbidities:
            base_risk += 6.0
        if "obesity" in profile.comorbidities:
            base_risk += 2.0
        
        return min(base_risk, 15.0)
    
    def _calculate_paraplegia_risk(self, profile: PatientRiskProfile, pathology: str) -> Dict:
        """Расчет риска параплегии для аортальных операций"""
        if "aortic" not in pathology:
            return {"probability": 0, "level": "Нет риска"}
        
        risk = 0.5  # Базовый риск
        
        if "thoracic" in pathology or "thoracoabdominal" in pathology:
            risk = 5.0
        
        if profile.age > 70:
            risk += 1.0
        
        return {
            "probability": risk,
            "level": self._risk_level(risk),
            "preventive_measures": [
                "Соматосенсорные вызванные потенциалы",
                "Моторные вызванные потенциалы",
                "Дистальная перфузия (при необходимости)",
                "Контроль спинномозгового давления"
            ]
        }
    
    def _risk_level(self, probability: float) -> str:
        """Определение уровня риска"""
        if probability < 3:
            return "Низкий"
        elif probability < 7:
            return "Умеренный"
        elif probability < 15:
            return "Высокий"
        else:
            return "Очень высокий"
    
    def _get_mortality_risk_factors(self, profile: PatientRiskProfile) -> List[str]:
        """Получение факторов риска смертности"""
        factors = []
        
        if profile.age > 75:
            factors.append("Возраст >75 лет")
        if "heart_failure" in profile.comorbidities:
            factors.append("Хроническая сердечная недостаточность")
        if "renal_failure" in profile.comorbidities:
            factors.append("Хроническая почечная недостаточность")
        if profile.genetic_syndrome:
            factors.append(f"Генетический синдром: {profile.genetic_syndrome}")
        
        return factors
    
    def _calculate_overall_score(self, profile: PatientRiskProfile) -> int:
        """Расчет общего балла риска"""
        score = 0
        
        if profile.age > 70:
            score += 2
        if profile.cardiac_risk == RiskLevel.HIGH:
            score += 3
        if profile.renal_function in ["moderate", "severe"]:
            score += 2
        if profile.frailty_score and profile.frailty_score >= 5:
            score += 2
        score += len(profile.comorbidities)
        
        return score
    
    def _stratify_risk(self, profile: PatientRiskProfile) -> str:
        """Стратификация риска"""
        score = self._calculate_overall_score(profile)
        
        if score <= 3:
            return "Низкий риск - стандартная подготовка"
        elif score <= 6:
            return "Умеренный риск - расширенная подготовка"
        else:
            return "Высокий риск - максимальная подготовка, консилиум"
    
    def _get_risk_modification_suggestions(self, profile: PatientRiskProfile) -> List[str]:
        """Рекомендации по модификации риска"""
        suggestions = []
        
        if profile.smoking_status == "current":
            suggestions.append("Отказ от курения (снижает риск осложнений на 30%)")
        
        if "diabetes" in profile.comorbidities:
            suggestions.append("Оптимизация гликемии (HbA1c <7%)")
        
        if profile.bmi > 30:
            suggestions.append("Снижение веса (если операция откладывается)")
        
        if "hypertension" in profile.comorbidities:
            suggestions.append("Контроль АД (<140/90 мм рт.ст.)")
        
        return suggestions


# ==================== APPROACH SELECTOR ====================

class ApproachSelector:
    """Селектор метода операции с учетом ESVS 2024 критериев"""
    
    def select(
        self,
        risk_profile: PatientRiskProfile,
        anatomical: AnatomicalFeatures,
        pathology: str,
        esvs_guidelines: Dict = None
    ) -> Dict:
        """Выбор оптимального подхода с учетом клинических рекомендаций"""
        
        if esvs_guidelines is None:
            esvs_guidelines = ESVS_2024_RECOMMENDATIONS
        
        # Оценка пригодности для эндоваскулярного подхода
        endovascular_suitability = self._assess_endovascular_suitability(
            anatomical, pathology, esvs_guidelines
        )
        
        # Оценка риска открытой операции
        open_surgery_risk = self._assess_open_surgery_risk(risk_profile)
        
        # Проверка на редкие патологии
        if risk_profile.genetic_syndrome == "vascular_ehlers_danlos":
            return {
                "type": ApproachType.CONSERVATIVE.value,
                "confidence": "Высокая",
                "rationale": [
                    "vEDS - хирургический риск 50-70%",
                    "Консервативное лечение предпочтительно",
                    "Операция только при угрозе жизни"
                ],
                "contraindications": ["Генетический синдром vEDS"],
                "alternative": "Консервативное лечение с пожизненным наблюдением"
            }
        
        # Проверка на микотическую аневризму
        if "mycotic" in pathology:
            return {
                "type": ApproachType.OPEN.value,
                "confidence": "Высокая",
                "rationale": [
                    "Микотическая аневризма - эндоваскулярное лечение противопоказано",
                    "Необходима экстраанатомическая реконструкция",
                    "Длительная антибиотикотерапия"
                ],
                "contraindications": ["Инфекция сосудистой стенки"],
                "alternative": "Экстраанатомическое шунтирование"
            }
        
        # Принятие решения по ESVS 2024
        if endovascular_suitability["score"] >= 8 and open_surgery_risk == RiskLevel.HIGH:
            return {
                "type": ApproachType.ENDOVASCULAR.value,
                "confidence": "Высокая",
                "rationale": [
                    "Подходящая анатомия для эндоваскулярного вмешательства",
                    "Высокий риск открытой операции",
                    "Минимальная травматичность",
                    "ESVS 2024 Class I, Level A"
                ],
                "contraindications": endovascular_suitability["contraindications"],
                "alternative": "Открытая операция (при неудаче эндоваскулярного)",
                "anatomical_score": endovascular_suitability["score"]
            }
        
        elif endovascular_suitability["score"] >= 6 and open_surgery_risk == RiskLevel.MODERATE:
            return {
                "type": ApproachType.ENDOVASCULAR.value,
                "confidence": "Средняя",
                "rationale": [
                    "Хорошая анатомия для EVAR",
                    "Умеренный хирургический риск",
                    "ESVS 2024 Class I, Level A"
                ],
                "contraindications": endovascular_suitability["contraindications"],
                "alternative": "Открытая операция",
                "anatomical_score": endovascular_suitability["score"]
            }
        
        elif endovascular_suitability["score"] >= 5 and open_surgery_risk == RiskLevel.MODERATE:
            return {
                "type": ApproachType.HYBRID.value,
                "confidence": "Средняя",
                "rationale": [
                    "Комбинация эндоваскулярного и открытого подхода",
                    "Оптимальный баланс эффективности и безопасности",
                    "ESVS 2024 Class IIa, Level B"
                ],
                "contraindications": [],
                "alternative": "Чисто открытая или чисто эндоваскулярная"
            }
        
        else:
            return {
                "type": ApproachType.OPEN.value,
                "confidence": "Высокая",
                "rationale": [
                    "Неподходящая анатомия для эндоваскулярного подхода",
                    "Необходимость полной реконструкции",
                    "Долгосрочная эффективность",
                    "ESVS 2024 Class I, Level A"
                ],
                "contraindications": [],
                "alternative": "Эндоваскулярный (при отказе от операции)",
                "anatomical_score": endovascular_suitability["score"]
            }
    
    def _assess_endovascular_suitability(
        self,
        anatomical: AnatomicalFeatures,
        pathology: str,
        esvs_guidelines: Dict
    ) -> Dict:
        """Оценка пригодности для эндоваскулярного подхода по ESVS 2024"""
        score = 10
        contraindications = []
        
        criteria = esvs_guidelines.get("evar_anatomical_criteria", {})
        
        # Диаметр сосуда
        if anatomical.vessel_diameter_mm < 5:
            score -= 3
            contraindications.append("Малый диаметр сосуда")
        
        # Тортуозность
        if anatomical.vessel_tortuosity == "severe":
            score -= 3
            contraindications.append("Выраженная тортуозность")
        elif anatomical.vessel_tortuosity == "moderate":
            score -= 1
        
        # Кальциноз
        if anatomical.calcification_degree == "severe":
            score -= 2
            contraindications.append("Тяжёлый кальциноз")
        
        # Длина шейки аневризмы (для EVAR) - ESVS 2024: минимум 10 мм
        if pathology == "aortic_aneurysm" or "evar" in pathology:
            neck_length = anatomical.infrarenal_neck_length or anatomical.aneurysm_neck_length_mm
            if neck_length:
                if neck_length < criteria.get("infrarenal_neck_length_min", 10):
                    score -= 4
                    contraindications.append(f"Короткая шейка аневризмы ({neck_length} мм < 10 мм)")
                elif neck_length < 15:
                    score -= 2
            
            # Ангуляция шейки - ESVS 2024: максимум 60 градусов
            neck_angle = anatomical.neck_angulation or anatomical.aneurysm_angulation
            if neck_angle and neck_angle > criteria.get("neck_angulation_max", 60):
                score -= 3
                contraindications.append(f"Выраженная ангуляция шейки ({neck_angle}° > 60°)")
            
            # Диаметр шейки
            if anatomical.neck_diameter_mm and anatomical.neck_diameter_mm > criteria.get("infrarenal_neck_diameter_max", 32):
                score -= 3
                contraindications.append(f"Большой диаметр шейки ({anatomical.neck_diameter_mm} мм > 32 мм)")
        
        # Качество доступных сосудов
        if anatomical.access_vessel_quality == "poor":
            score -= 2
            contraindications.append("Плохое качество доступных сосудов")
        
        return {
            "score": max(score, 0),
            "contraindications": contraindications
        }
    
    def _assess_open_surgery_risk(self, profile: PatientRiskProfile) -> RiskLevel:
        """Оценка риска открытой операции"""
        risk_score = 0
        
        if profile.age > 75:
            risk_score += 2
        if profile.cardiac_risk == RiskLevel.HIGH:
            risk_score += 3
        if profile.renal_function == "severe":
            risk_score += 2
        if len(profile.comorbidities) > 4:
            risk_score += 2
        if profile.frailty_score and profile.frailty_score >= 5:
            risk_score += 2
        
        if risk_score >= 6:
            return RiskLevel.HIGH
        elif risk_score >= 3:
            return RiskLevel.MODERATE
        else:
            return RiskLevel.LOW


# ==================== ACCESS PLANNER ====================

class AccessPlanner:
    """Планировщик хирургического доступа"""
    
    def plan(
        self,
        anatomical: AnatomicalFeatures,
        approach: Dict,
        pathology: str
    ) -> Dict:
        """Планирование оптимального доступа"""
        
        if approach["type"] == ApproachType.OPEN.value:
            return self._plan_open_access(pathology, anatomical)
        elif approach["type"] == ApproachType.ENDOVASCULAR.value:
            return self._plan_endovascular_access(anatomical)
        else:
            return self._plan_hybrid_access(pathology, anatomical)
    
    def _plan_open_access(self, pathology: str, anatomical: AnatomicalFeatures) -> Dict:
        """Планирование открытого доступа"""
        
        access_plans = {
            "aortic_aneurysm": {
                "primary": {
                    "name": "Срединная лапаротомия",
                    "description": "Разрез от мечевидного отростка до лонного сочленения",
                    "length": "20-25 см",
                    "advantages": ["Полный доступ к аорте", "Возможность контроля надпочечниковой аорты"],
                    "disadvantages": ["Травматичность", "Длительное заживление"]
                },
                "alternative": {
                    "name": "Трансперитонеальный ретроперитонеальный доступ",
                    "description": "Левый фланговый разрез",
                    "indications": "Повторные операции, ожирение"
                },
                "position": "Супинация, подложечный валик",
                "special_considerations": [
                    "Мобилизация левой почечной вены при необходимости",
                    "Контроль мочеточников",
                    "Избегать повреждения брыжейки"
                ]
            },
            
            "carotid_stenosis": {
                "primary": {
                    "name": "Продольный разрез вдоль переднего края СКМ",
                    "description": "Разрез 8-10 см на уровне бифуркации",
                    "advantages": ["Прямой доступ", "Хорошая визуализация"],
                    "disadvantages": ["Косметический дефект"]
                },
                "alternative": {
                    "name": "Поперечный разрез в кожных складках",
                    "description": "Более косметичный",
                    "indications": "Молодые пациенты"
                },
                "position": "Супинация, подложечный валик, гиперэкстензия головы",
                "special_considerations": [
                    "Избегать повреждения блуждающего нерва",
                    "Контроль гипоглоссального нерва",
                    "Возможность шунтирования"
                ]
            },
            
            "femoropopliteal_bypass": {
                "primary": {
                    "name": "Двойной разрез (паховый + подколенный)",
                    "description": "Разрез в паху 10 см + подколенный 8-10 см",
                    "advantages": ["Прямая визуализация", "Контроль гемостаза"],
                    "disadvantages": ["Два рубца", "Риск инфекции"]
                },
                "alternative": {
                    "name": "Односторонний доступ с туннелированием",
                    "description": "Только паховый разрез",
                    "indications": "Минимально инвазивный подход"
                },
                "position": "Супинация, сгибание в коленном суставе (для подколенного)",
                "special_considerations": [
                    "Туннелирование между мышечными пластинками",
                    "Избегать повреждения лимфатических сосудов",
                    "Контроль пульса на стопе"
                ]
            },
            
            "varicose_veins": {
                "primary": {
                    "name": "Паховый разрез + миниразрезы",
                    "description": "Пах 3 см + миниразрезы 2-3 мм по ходу вен",
                    "advantages": ["Минимальная травматичность", "Хороший косметический результат"],
                    "disadvantages": ["Возможны гематомы"]
                },
                "position": "Тренделенбург",
                "special_considerations": [
                    "Маркировка вен перед операцией",
                    "Перевязка всех притоков",
                    "Компрессия после операции"
                ]
            }
        }
        
        return access_plans.get(pathology, {
            "primary": {
                "name": "Стандартный доступ",
                "description": "В зависимости от локализации патологии"
            },
            "position": "Супинация",
            "special_considerations": ["Стандартная подготовка"]
        })
    
    def _plan_endovascular_access(self, anatomical: AnatomicalFeatures) -> Dict:
        """Планирование эндоваскулярного доступа"""
        
        # Выбор точки доступа
        if anatomical.vessel_diameter_mm >= 7:
            access_site = {
                "primary": "Бедренная артерия (общая)",
                "puncture": "Перкутанная пункция Seldinger",
                "sheath_size": "6-8F (стандарт) или 12-24F (EVAR)",
                "closure": "Закрытие устройством (Angio-Seal, Perclose) или компрессия"
            }
        else:
            access_site = {
                "primary": "Лучевая артерия",
                "puncture": "Перкутанная пункция",
                "sheath_size": "5-6F",
                "closure": "Компрессия или TR Band"
            }
        
        return {
            "access_site": access_site,
            "position": "Супинация",
            "anesthesia": "Местная + седация (краткая)",
            "contrast_volume": "Минимизация (особенно при ХПН)",
            "radiation_protection": [
                "Фартук для персонала",
                "Очки",
                "Щит для пациента"
            ],
            "special_considerations": [
                "Контроль АКТ при длительной процедуре",
                "Гидратация для защиты почек",
                "Мониторинг гемодинамики"
            ]
        }
    
    def _plan_hybrid_access(self, pathology: str, anatomical: AnatomicalFeatures) -> Dict:
        """Планирование гибридного доступа"""
        return {
            "description": "Комбинация открытого и эндоваскулярного доступа",
            "typical_scenario": "Открытый доступ для основной реконструкции + эндоваскулярная коррекция",
            "advantages": ["Минимизация травматичности", "Расширение возможностей"],
            "special_requirements": [
                "Гибридная операционная с ангиографом",
                "Рентгенозащита",
                "Опыт хирурга в обоих техниках"
            ]
        }


# ==================== OUTCOME PREDICTOR ====================

class OutcomePredictor:
    """Предиктор исходов операции с учетом современных данных"""
    
    def predict(
        self,
        risk_profile: PatientRiskProfile,
        anatomical: AnatomicalFeatures,
        approach: Dict
    ) -> Dict:
        """Прогнозирование исходов"""
        
        # Патентность шунта/протеза
        patency = self._predict_patency(risk_profile, anatomical, approach)
        
        # Время реабилитации
        recovery = self._predict_recovery(risk_profile, approach)
        
        # Качество жизни
        quality_of_life = self._predict_qol(risk_profile, approach)
        
        # Возвращение к нормальной жизни
        return_to_normal = self._predict_return_to_normal(risk_profile, approach)
        
        return {
            "graft_patency": patency,
            "recovery_time": recovery,
            "quality_of_life": quality_of_life,
            "return_to_normal": return_to_normal,
            "long_term_survival": self._predict_survival(risk_profile),
            "reintervention_probability": self._predict_reintervention(risk_profile, approach),
            "factors_affecting_outcomes": self._get_outcome_factors(risk_profile, anatomical)
        }
    
    def _predict_patency(self, profile, anatomical, approach) -> Dict:
        """Прогноз патентности"""
        if approach["type"] == ApproachType.ENDOVASCULAR.value:
            return {
                "1_year": "85-90%",
                "5_year": "60-70%",
                "factors_affecting": [
                    "Кальциноз",
                    "Диаметр сосуда",
                    "Длина поражения",
                    "Качество анатомии"
                ],
                "improvement_strategies": [
                    "Drug-eluting stents",
                    "Лучший контроль риск-факторов"
                ]
            }
        else:
            # Открытая операция - лучшая патентность
            return {
                "1_year": "90-95%",
                "5_year": "75-85%",
                "factors_affecting": [
                    "Тип трансплантата (вена > протез)",
                    "Антикоагуляция",
                    "Сопутствующая патология"
                ],
                "improvement_strategies": [
                    "Использование вены при возможности",
                    "Адекватная антитромботическая терапия"
                ]
            }
    
    def _predict_recovery(self, profile, approach) -> Dict:
        """Прогноз времени восстановления"""
        if approach["type"] == ApproachType.ENDOVASCULAR.value:
            return {
                "hospital_stay": "1-2 дня",
                "return_to_daily_activities": "3-7 дней",
                "return_to_work": "1-2 недели",
                "wound_healing": "3-5 дней (пункция)",
                "full_recovery": "2-4 недели"
            }
        else:
            base_recovery = {
                "hospital_stay": "5-10 дней",
                "return_to_daily_activities": "2-4 недели",
                "return_to_work": "6-12 недель",
                "wound_healing": "2-3 недели",
                "full_recovery": "3-6 месяцев"
            }
            
            # Учет возраста
            if profile.age > 75:
                base_recovery["hospital_stay"] = "7-14 дней"
                base_recovery["full_recovery"] = "4-8 месяцев"
            
            return base_recovery
    
    def _predict_qol(self, profile, approach) -> Dict:
        """Прогноз качества жизни"""
        return {
            "short_term": "Улучшение через 1-3 месяца",
            "long_term": "Стабильное улучшение через 6-12 месяцев",
            "factors_improving": [
                "Устранение симптомов ишемии",
                "Улучшение функционального статуса"
            ],
            "potential_issues": [
                "Хроническая боль (при неудаче)",
                "Необходимость повторных вмешательств"
            ]
        }
    
    def _predict_return_to_normal(self, profile, approach) -> Dict:
        """Прогноз возвращения к нормальной жизни"""
        if approach["type"] == ApproachType.ENDOVASCULAR.value:
            return {
                "driving": "Через 1 неделю",
                "light_physical_activity": "Через 1-2 недели",
                "heavy_physical_activity": "Через 4-6 недель",
                "sexual_activity": "Через 1-2 недели"
            }
        else:
            return {
                "driving": "Через 4-6 недель",
                "light_physical_activity": "Через 4-6 недель",
                "heavy_physical_activity": "Через 3-6 месяцев",
                "sexual_activity": "Через 4-6 недель"
            }
    
    def _predict_survival(self, profile: PatientRiskProfile) -> Dict:
        """Прогноз выживаемости"""
        base_5year = 80
        
        if profile.age > 75:
            base_5year -= 15
        if "heart_failure" in profile.comorbidities:
            base_5year -= 20
        if "renal_failure" in profile.comorbidities:
            base_5year -= 15
        if "diabetes" in profile.comorbidities:
            base_5year -= 10
        
        return {
            "1_year": f"{min(95, base_5year + 10)}%",
            "5_year": f"{max(40, base_5year)}%",
            "10_year": f"{max(20, base_5year - 20)}%"
        }
    
    def _predict_reintervention(self, profile, approach) -> Dict:
        """Прогноз необходимости повторного вмешательства"""
        if approach["type"] == ApproachType.ENDOVASCULAR.value:
            return {
                "1_year": "10-15%",
                "5_year": "30-40%",
                "common_reasons": [
                    "Endoleak (особенно Type II)",
                    "Миграция стент-графта",
                    "Рестеноз"
                ]
            }
        else:
            return {
                "1_year": "3-5%",
                "5_year": "10-15%",
                "common_reasons": [
                    "Тромбоз шунта",
                    "Анастомотическая аневризма",
                    "Прогрессирование заболевания"
                ]
            }
    
    def _get_outcome_factors(self, profile: PatientRiskProfile, anatomical: AnatomicalFeatures) -> List[str]:
        """Факторы, влияющие на исходы"""
        factors = []
        
        if profile.age > 75:
            factors.append("Возраст >75 лет - более длительное восстановление")
        
        if "diabetes" in profile.comorbidities:
            factors.append("Диабет - повышенный риск инфекции и осложнений")
        
        if "smoking" in profile.comorbidities or profile.smoking_status == "current":
            factors.append("Курение - снижение патентности шунтов")
        
        if anatomical.calcification_degree == "severe":
            factors.append("Тяжёлый кальциноз - техническая сложность")
        
        return factors


# ==================== UTILITY FUNCTIONS ====================

def get_ai_decision_support() -> AIDecisionSupport:
    """Фабричная функция для получения экземпляра AI Decision Support"""
    return AIDecisionSupport()
