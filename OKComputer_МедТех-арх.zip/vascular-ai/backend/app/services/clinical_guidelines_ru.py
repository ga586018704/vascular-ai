"""
Российские клинические рекомендации и дополнительные классификации
для VASCULAR.AI
"""

from typing import Dict, Any, List, Optional

# ==================== РОССИЙСКИЕ КЛИНИЧЕСКИЕ РЕКОМЕНДАЦИИ ====================

RUSSIAN_CLINICAL_GUIDELINES = {
    "aortic_dissection": {
        "name": "Острое расслоение аорты (ОРА)",
        "source": "Клинические рекомендации РФ 2025",
        "classification": {
            "type_a": {
                "name": "ОРА типа А (восходящая аорта)",
                "treatment": "Срочное оперативное вмешательство",
                "timing": "В течение 2 суток",
                "recommendation_class": "Class I",
                "evidence_level": "Level B"
            },
            "type_b": {
                "name": "ОРА типа В (нисходящая аорта)",
                "complicated": {
                    "treatment": "TEVAR или открытая операция",
                    "indications": ["Мальперфузия", "Разрыв", "Расширение аорты"],
                    "recommendation_class": "Class I",
                    "evidence_level": "Level B"
                },
                "uncomplicated": {
                    "treatment": "Консервативная терапия + наблюдение",
                    "indications_high_risk": [
                        "Диаметр ложного просвета >22 мм",
                        "Диаметр аорты >40 мм",
                        "Ложный просвет в проксимальной части",
                        "Отслойка интимы в дуге",
                        "Марфанов синдром"
                    ],
                    "recommendation_class": "Class IIa",
                    "evidence_level": "Level C"
                }
            }
        },
        "surgical_techniques": {
            "open_repair": {
                "indications": ["ОРА типа А", "Осложненное ОРА типа В"],
                "techniques": [
                    "Замена восходящей аорты",
                    "Замена дуги аорты (полная/частичная)",
                    "Замена нисходящей аорты",
                    "Фенестрация",
                    "Пластика ветвей"
                ]
            },
            "tevar": {
                "indications": ["Осложненное ОРА типа В", "Травматическое повреждение аорты"],
                "contraindications": [
                    "Неподходящая анатомия",
                    "Аневризма восходящей аорты",
                    "Заболевания соединительной ткани (относительное)"
                ],
                "spinal_cord_protection": [
                    "Люмбальный дренаж",
                    "Реваскуляризация ЛПклА при необходимости",
                    "Поддержание АД",
                    "Минимизация времени пережатия"
                ]
            }
        },
        "perioperative_management": {
            "blood_pressure_control": {
                "target_systolic": "100-120 мм рт.ст.",
                "medications": ["Бета-блокаторы", "Нитропруссид натрия", "Урапидил"]
            },
            "pain_management": "Адекватная анальгезия",
            "neurological_monitoring": "Мониторинг неврологического статуса",
            "organ_perfusion": "Контроль перфузии внутренних органов"
        }
    },
    
    "intramural_hematoma": {
        "name": "Интрамуральная гематома аорты (ИМГ)",
        "source": "Клинические рекомендации РФ 2025",
        "type_a": {
            "uncomplicated": {
                "treatment": "Оперативное вмешательство в сроки до 3 суток",
                "recommendation_class": "Class I",
                "evidence_level": "Level B"
            },
            "complicated": {
                "treatment": "Срочное оперативное вмешательство (в течение 24 часов)",
                "risk_factors": [
                    "Диаметр аорты >50 мм",
                    "Толщина ИМГ >11 мм",
                    "Гемоперикард",
                    "Аортальная регургитация",
                    "Изъязвление стенки аорты"
                ],
                "recommendation_class": "Class I",
                "evidence_level": "Level C"
            }
        },
        "type_b": {
            "treatment": "TEVAR предпочтительно открытой операции",
            "indications_surgery": [
                "Симптоматическая ИМГ",
                "Расширение аорты",
                "ULP (ulcero-protruding lesion)"
            ],
            "recommendation_class": "Class IIa",
            "evidence_level": "Level B"
        }
    },
    
    "penetrating_aortic_ulcer": {
        "name": "Пенетрирующая атеросклеротическая язва аорты (ПАЯ)",
        "source": "Клинические рекомендации РФ 2025",
        "treatment": {
            "ascending_aorta": {
                "indications": "Срочное вмешательство до 3 суток",
                "recommendation_class": "Class I",
                "evidence_level": "Level C"
            },
            "arch_descending": {
                "treatment": "TEVAR или открытая операция",
                "high_risk_features": [
                    "Диаметр ПАЯ ≥13-20 мм",
                    "Глубина ≥10 мм",
                    "Увеличение в динамике",
                    "Мешотидная аневризма",
                    "Плевральный выпот"
                ],
                "recommendation_class": "Class I",
                "evidence_level": "Level C"
            }
        }
    },
    
    "traumatic_aortic_injury": {
        "name": "Травматическое повреждение аорты (ТПА)",
        "source": "Клинические рекомендации РФ 2025",
        "grade_1": {
            "description": "Интимальное повреждение",
            "treatment": "Консервативное лечение + наблюдение"
        },
        "grade_2": {
            "description": "ИМГ или псевдоаневризма <50% обхвата",
            "treatment": "TEVAR предпочтительно",
            "high_risk_features": [
                "Гематома заднего средостения >10 мм",
                "Соотношение аорты к нормальному >1.4",
                "Обширная гематома средостения",
                "Псевдокоарктация",
                "Массивный левосторонний гемоторакс"
            ],
            "recommendation_class": "Class I",
            "evidence_level": "Level B"
        },
        "grade_3": {
            "description": "Псевдоаневризма >50% обхвата",
            "treatment": "TEVAR или открытая операция"
        },
        "grade_4": {
            "description": "Разрыв аорты",
            "treatment": "Экстренное вмешательство"
        }
    },
    
    "aortic_dissection_pregnancy": {
        "name": "Расслоение аорты и беременность",
        "source": "Клинические рекомендации РФ 2025",
        "type_a": {
            "before_27_weeks": {
                "treatment": "Хирургическое вмешательство в течение 2 суток",
                "monitoring": "Мониторинг состояния плода"
            },
            "after_28_weeks": {
                "treatment": "Кесарево сечение + немедленное хирургическое вмешательство",
                "timing": "В течение 24 часов"
            }
        },
        "delivery": {
            "aorta_less_40mm": "Вагинальное родоразрешение",
            "aorta_more_45mm": "Кесарево сечение"
        }
    },
    
    "varicose_veins_ru": {
        "name": "Варикозное расширение вен нижних конечностей",
        "source": "Клинические рекомендации Минздрава РФ 2017",
        "ceap_classification": {
            "C0": "Нет видимых признаков заболевания",
            "C1": "Телеангиэктазии или ретикулярные вены",
            "C2": "Варикозные вены",
            "C3": "Отек",
            "C4": "Изменения кожи (пигментация, экзема, липодерматосклероз)",
            "C5": "Зажившая трофическая язва",
            "C6": "Активная трофическая язва"
        },
        "treatment": {
            "C2": {
                "indication": "Хирургическое лечение для улучшения качества жизни",
                "methods": [
                    "Эндовенозная лазерная облитерация (ЭВЛО)",
                    "Радиочастотная облитерация (РЧО)",
                    "Традиционная хирургия (стриппинг)",
                    "Минифлебэктомия"
                ],
                "preference": "Методы термооблитерации предпочтительнее",
                "recommendation_class": "Class I",
                "evidence_level": "Level A"
            },
            "conservative": {
                "compression": "Компрессионный трикотаж 2 класса компрессии",
                "pharmacotherapy": "Веноактивные препараты (Детралекс, Венарус)",
                "lifestyle": "Физическая активность, контроль веса"
            }
        },
        "contraindications_surgery": [
            "Рефлюкс без варикозной трансформации",
            "Активный тромбофлебит",
            "Тяжелая сопутствующая патология"
        ]
    }
}


# ==================== TASC II КЛАССИФИКАЦИЯ ====================

TASC_II_CLASSIFICATION = {
    "aortoiliac": {
        "name": "Аорто-подвздошные поражения",
        "type_a": {
            "description": "Одиночный стеноз <3 см ОПА или НПА (одно/двусторонний)",
            "treatment": "Эндоваскулярное - первый выбор",
            "recommendation": "Class I, Level A"
        },
        "type_b": {
            "description": [
                "Одиночный стеноз 3-10 см, не доходящий до ОБА",
                "2 стеноза <5 см в ОПА и/или НПА",
                "Односторонняя окклюзия ОПА"
            ],
            "treatment": "Эндоваскулярное предпочтительно",
            "recommendation": "Class I, Level A"
        },
        "type_c": {
            "description": [
                "Двусторонние стенозы 5-10 см ОПА/НПА",
                "Окклюзия НПА без вовлечения ОБА",
                "Стеноз НПА с вовлечением ОБА",
                "Двусторонняя окклюзия ОПА"
            ],
            "treatment": "Открытая операция - лучшие результаты",
            "alternative": "Эндоваскулярное при высоком хирургическом риске",
            "recommendation": "Class I, Level B"
        },
        "type_d": {
            "description": [
                "Диффузные множественные стенозы ОПА+НПА+ОБА (>10 см)",
                "Окклюзия ОПА+НПА",
                "Двусторонняя окклюзия НПА",
                "Диффузное поражение аорты и обеих подвздошных",
                "Стеноз при ААА или другой патологии требующей операции"
            ],
            "treatment": "Открытая операция",
            "recommendation": "Class I, Level A"
        }
    },
    
    "femoropopliteal": {
        "name": "Бедренно-подколенные поражения",
        "type_a": {
            "description": [
                "Одиночный стеноз <10 см ПБА или ПА",
                "Одиночная окклюзия <5 см"
            ],
            "treatment": "Эндоваскулярное - первый выбор",
            "recommendation": "Class I, Level A"
        },
        "type_b": {
            "description": [
                "Множественные стенозы/окклюзии, каждый <5 см",
                "Одиночный стеноз/окклюзия <15 см не вовлекающий подколенную",
                "Одиночная или множественные без непрерывного тибиального оттока",
                "Тяжело кальцинированная окклюзия <5 см",
                "Одиночный стеноз подколенной артерии"
            ],
            "treatment": "Эндоваскулярное предпочтительно",
            "recommendation": "Class IIa, Level B"
        },
        "type_c": {
            "description": [
                "Множественные стенозы/окклюзии суммарно >15 см",
                "Рецидив после 2 эндоваскулярных вмешательств"
            ],
            "treatment": "Шунтирование - лучшие результаты",
            "alternative": "Эндоваскулярное при высоком риске",
            "recommendation": "Class I, Level A"
        },
        "type_d": {
            "description": [
                "Хроническая полная окклюзия ОБА или ПБА (>20 см, вовлекающая ПА)",
                "Окклюзия ПА и проксимальных трехветвий"
            ],
            "treatment": "Шунтирование",
            "recommendation": "Class I, Level A"
        }
    },
    
    "infrapopliteal": {
        "name": "Подколенные (тибиальные) поражения",
        "notes": [
            "TASC II не включает классификацию тибиальных поражений",
            "Решение принимается индивидуально",
            "При критической ишемии - реваскуляризация обязательна"
        ],
        "treatment_options": [
            "Бедренно-подколенное шунтирование с веной",
            "Дистальное шунтирование на тибиальные/педальные артерии",
            "Эндоваскулярное лечение (angioplasty ± stenting)",
            "Химическая люмбальная симпатэктомия"
        ]
    }
}


# ==================== ВЫБОР ПРОТЕЗА/ШУНТА ====================

GRAFT_SELECTION_GUIDE = {
    "aortic_prostheses": {
        "dacron": {
            "name": "Dacron (полиэстер)",
            "types": [
                {
                    "name": "Тканый Dacron",
                    "features": ["Низкая пористость", "Минимальное кровотечение"],
                    "indications": "Аорта, крупные артерии"
                },
                {
                    "name": "Вязаный Dacron",
                    "features": ["Высокая пористость", "Требует преклоттирования"],
                    "use": "Редко используется"
                },
                {
                    "name": "Коллаген-импрегнированный",
                    "features": ["Сниженное кровотечение", "Абсорбируемый коллаген"],
                    "examples": ["Hemashield", "Intergard"]
                },
                {
                    "name": "Гельватин-запечатанный",
                    "features": ["Гемостаз", "Абсорбируемый"],
                    "examples": ["Gelseal"]
                },
                {
                    "name": "Гепарин-связанный",
                    "features": ["Сниженная тромбогенность", "Биоактивная поверхность"],
                    "examples": ["Propaten"]
                }
            ],
            "advantages": [
                "Проверен временем (>70 лет)",
                "Хорошая прочность",
                "Низкая частота структурных повреждений (<0.2%)",
                "Хорошая проходимость"
            ],
            "disadvantages": [
                "Более пористый (кровотечение из вколов)",
                "Требует преклоттирования (необработанный)",
                "Возможна деформация"
            ],
            "best_for": [
                "Аорто-бифеморальное шунтирование",
                "Резекция ААА",
                "Замена восходящей аорты"
            ]
        },
        
        "ptfe_eptfe": {
            "name": "PTFE/ePTFE (политетрафторэтилен)",
            "types": [
                {
                    "name": "Стандартный PTFE",
                    "features": ["Микропористая структура", "Химическая инертность"],
                    "indications": "Периферические артерии"
                },
                {
                    "name": "Расширенный PTFE (ePTFE)",
                    "features": ["Улучшенная интеграция", "Лучшая адаптация"],
                    "indications": "Бедренно-подколенное шунтирование"
                },
                {
                    "name": "Трехслойный (Acuseal)",
                    "features": [
                        "Микропористый PTFE 0.5 мм",
                        "Внутренний гемостатический слой",
                        "Тромборезистентность"
                    ],
                    "advantage": "Минимальное кровотечение из вколов"
                }
            ],
            "advantages": [
                "Менее пористый (меньше кровотечение)",
                "Химическая инертность",
                "Хорошая биосовместимость",
                "Не подвержен биодеградации",
                "Меньше инфекций"
            ],
            "disadvantages": [
                "Может быть менее прочным при растяжении",
                "Возможно образование псевдоинтимы",
                "Высокая стоимость (некоторые типы)"
            ],
            "best_for": [
                "Феморо-феморальное шунтирование",
                "Аксилло-феморальное шунтирование",
                "Заплатная ангиопластика"
            ]
        },
        
        "comparison": {
            "note": "Мета-анализ 9 РКИ не показал значимых различий в проходимости Dacron vs PTFE",
            "primary_patency": "Сопоставимая (HR 1.04, 95% CI 0.85-1.28)",
            "secondary_patency": "Сопоставимая (HR 1.02, 95% CI 0.65-1.62)",
            "limb_salvage": "Сопоставимая",
            "infection_rate": "Сопоставимая",
            "mortality": "Сопоставимая"
        },
        
        "selection_criteria": {
            "choose_dacron": [
                "Аорто-бифеморальное шунтирование",
                "Большие диаметры (>8 мм)",
                "Необходимость разветвленного протеза",
                "Опыт хирурга с Dacron"
            ],
            "choose_ptfe": [
                "Феморо-феморальное шунтирование",
                "Аксилло-феморальное шунтирование",
                "Заплатная пластика",
                "Меньшая пористость критична"
            ]
        }
    },
    
    "venous_vs_prosthetic": {
        "general_rule": "Вена предпочтительнее протеза для инфраингвинальных реконструкций",
        
        "vein_graft": {
            "types": [
                {
                    "name": "Великая сапенозная вена (ВСВ)",
                    "features": [
                        "Оптимальный кондуит",
                        "Тромборезистентность",
                        "Аутологичный эндотелий",
                        "Устойчивость к инфекции"
                    ],
                    "patency_5yr": "70-80%",
                    "best_for": "Бедренно-подколенное шунтирование"
                },
                {
                    "name": "Малая сапенозная вена",
                    "features": ["Меньший диаметр", "Хорошая проходимость"],
                    "use": "Дистальное шунтирование"
                },
                {
                    "name": "Радиальная вена",
                    "features": ["Хороший диаметр", "Доступность"],
                    "use": "При недоступности сапенозной вены"
                }
            ],
            "advantages": [
                "Лучшая проходимость в отдаленном периоде",
                "Тромборезистентность",
                "Иммунологическая инертность",
                "Эластичность",
                "Аутологичный эндотелий",
                "Устойчивость к инфекции"
            ],
            "disadvantages": [
                "Склонность к аневризматическому расширению",
                "Возможен разрыв (0.5-4% в первые дни)",
                "Требует дополнительного разреза",
                "Ограниченная длина",
                "Варикозные изменения (контраиндикация)"
            ],
            "contraindications": [
                "Варикозная болезнь",
                "Предыдущее удаление",
                "Диаметр <3 мм",
                "Тромбоз в анамнезе"
            ]
        },
        
        "when_to_use_vein": [
            "Бедренно-подколенное шунтирование (особенно ниже колена)",
            "Дистальное шунтирование (тибиальные артерии)",
            "Молодые пациенты",
            "Ожидаемая длительная выживаемость"
        ],
        
        "when_to_use_prosthetic": [
            "Недоступность вены",
            "Аорто-бифеморальное шунтирование",
            "Феморо-феморальное шунтирование",
            "Аксилло-феморальное шунтирование",
            "Ожидаемая короткая выживаемость",
            "Срочное вмешательство"
        ],
        
        "patency_comparison": {
            "above_knee": {
                "vein": "75-85% (5 лет)",
                "prosthetic": "50-70% (5 лет)"
            },
            "below_knee": {
                "vein": "60-75% (5 лет)",
                "prosthetic": "30-50% (5 лет)"
            }
        }
    },
    
    "patch_selection": {
        "autologous_vein": {
            "name": "Аутовенозная заплата (ВСВ)",
            "advantages": [
                "Оптимальные характеристики",
                "Тромборезистентность",
                "Иммунологическая инертность",
                "Эластичность",
                "Аутологичный эндотелий",
                "Устойчивость к инфекции",
                "Оптимальный гемостаз"
            ],
            "disadvantages": [
                "Склонность к аневризмам",
                "Возможен разрыв",
                "Требует дополнительного разреза"
            ],
            "best_for": "Каротидная эндартерэктомия, пластика БЦС"
        },
        
        "synthetic_patches": {
            "ptfe": {
                "name": "PTFE заплата",
                "features": ["Химическая инертность", "Биосовместимость", "Нет биодеградации"],
                "examples": ["Acuseal", "Impra"]
            },
            "dacron": {
                "name": "Dacron заплата",
                "features": ["Коллаген/гельватин-импрегнированная", "Минимальное кровотечение"],
                "examples": ["Hemashield Finesse"]
            },
            "xenopericardium": {
                "name": "Ксеноперикард",
                "features": ["Биологическая заплата", "Хорошая гемостаз", "Меньше рестенозов"],
                "restenosis_rate": "4% vs 7.6% (PTFE)"
            }
        },
        
        "recommendations": {
            "carotid_endarterectomy": "Аутовена или ксеноперикард предпочтительнее синтетики",
            "femoral_endarterectomy": "Аутовена или PTFE",
            "aortic_surgery": "Dacron заплата"
        }
    }
}


# ==================== РАСШИРЕННАЯ ФЛЕБОЛОГИЯ ====================

PHLEBOLOGY_GUIDE = {
    "ceap_classification": {
        "clinical": {
            "C0": {
                "description": "Нет видимых признаков",
                "symptoms": "Могут быть жалобы (тяжесть, боль)",
                "sign": "s"
            },
            "C1": {
                "description": "Телеангиэктазии или ретикулярные вены",
                "diameter": "<3 мм",
                "treatment": "Склеротерапия, лазер"
            },
            "C2": {
                "description": "Варикозные вены",
                "treatment": "Эндовенозная облитерация, флебэктомия",
                "indication": "Хирургическое лечение показано"
            },
            "C3": {
                "description": "Отек",
                "treatment": "Компрессия + фармакотерапия + хирургия"
            },
            "C4": {
                "description": "Изменения кожи",
                "subtypes": {
                    "C4a": "Пигментация, экзема",
                    "C4b": "Липодерматосклероз, атрофия бланше"
                },
                "treatment": "Комплексное + хирургия"
            },
            "C5": {
                "description": "Зажившая трофическая язва",
                "treatment": "Хирургия + компрессия + фармакотерапия"
            },
            "C6": {
                "description": "Активная трофическая язва",
                "treatment": "Срочная хирургия + комплексная терапия"
            }
        },
        
        "etiology": {
            "Ec": "Врожденная",
            "Ep": "Первичная (без причины)",
            "Es": "Вторичная (тромбоз, травма)"
        },
        
        "anatomy": {
            "As": "Поверхностные вены",
            "Ap": "Перфораторы",
            "Ad": "Глубокие вены",
            "An": "Нет венозной патологии"
        },
        
        "pathophysiology": {
            "Pr": "Рефлюкс",
            "Po": "Обструкция",
            "Pr,o": "Рефлюкс и обструкция",
            "Pn": "Нет патофизиологии"
        }
    },
    
    "treatment_methods": {
        "endovenous_laser": {
            "name": "Эндовенозная лазерная облитерация (ЭВЛО/EVLA)",
            "wavelengths": [
                {"nm": 810, "note": "Классический"},
                {"nm": 940, "note": "Хорошее поглощение гемоглобином"},
                {"nm": 980, "note": "Баланс воды и гемоглобина"},
                {"nm": 1470, "note": "Преимущественно вода, меньше боли"},
                {"nm": 1940, "note": "Тулий, преимущественно вода"}
            ],
            "linear_endovenous_energy_density": {
                " recommendation": "50-80 J/cm",
                "below_50": "Недостаточная облитерация",
                "above_100": "Риск ожогов"
            },
            "advantages": [
                "Минимально инвазивно",
                "Амбулаторно",
                "Быстрое восстановление",
                "Хороший косметический результат"
            ],
            "complications": [
                "Экхимозы (10-20%)",
                "Флебит (5-15%)",
                "Парестезии (2-5%)",
                "Кожные ожоги (<2%)",
                "ТГВ (<1%)"
            ],
            "contraindications": [
                "ТГВ в острой фазе",
                "Тяжелая артериальная недостаточность",
                "Неспособность ходить",
                "Беременность"
            ]
        },
        
        "radiofrequency": {
            "name": "Радиочастотная облитерация (РЧО/RFA)",
            "temperature": "120°C",
            "advantages": [
                "Меньше боли чем лазер",
                "Минимально инвазивно",
                "Быстрое восстановление"
            ],
            "devices": ["ClosureFast", "VNUS"]
        },
        
        "sclerotherapy": {
            "name": "Склеротерапия",
            "types": [
                {
                    "name": "Жидкостная склеротерапия",
                    "indications": "Телеангиэктазии, ретикулярные вены",
                    "agents": ["Полидоканол", "Тетрадецилсульфат"]
                },
                {
                    "name": "Пенная склеротерапия (UGFS)",
                    "indications": "Варикозные вены, перфораторы",
                    "advantage": "Лучший контакт со стенкой"
                },
                {
                    "name": "Эхо-склеротерапия",
                    "indications": "Варикозные притоки",
                    "guidance": "УЗ-контроль"
                }
            ]
        },
        
        "phlebectomy": {
            "name": "Флебэктомия",
            "types": [
                "Минифлебэктомия (крючки Мюллера)",
                "Трансиллюминированная флебэктомия (Trivex)",
                "Внутренняя флебэктомия"
            ],
            "indications": [
                "Выраженные варикозные узлы",
                "Несостоятельные притоки",
                "Дополнение к эндовенозной облитерации"
            ]
        },
        
        "stripping": {
            "name": "Стриппинг",
            "types": [
                "Полный стриппинг (до лодыжки)",
                "Частичный стриппинг (только бедро)",
                "Инверсионный стриппинг"
            ],
            "indications": "Традиционный метод при выраженном рефлюксе",
            "note": "В настоящее время реже используется (уступает эндовенозным методам)"
        }
    },
    
    "compression_therapy": {
        "classes": {
            "class_1": {
                "pressure": "15-20 мм рт.ст.",
                "indications": "Профилактика, легкая ХВН"
            },
            "class_2": {
                "pressure": "20-30 мм рт.ст.",
                "indications": "Варикозная болезнь, после операций"
            },
            "class_3": {
                "pressure": "30-40 мм рт.ст.",
                "indications": "Тяжелая ХВН, трофические язвы"
            },
            "class_4": {
                "pressure": ">40 мм рт.ст.",
                "indications": "Лимфедема"
            }
        },
        "duration": {
            "after_sclerotherapy": "1-2 недели",
            "after_endovenous": "1 неделя (дневная)",
            "chronic_venous_disease": "Постоянно при активности"
        }
    },
    
    "pharmacotherapy": {
        "venoactive_drugs": {
            "micronized_purified_flavonoid_fraction": {
                "name": "Микронизированная очищенная флавоноидная фракция (МОФФ)",
                "examples": ["Детралекс", "Венарус"],
                "dosage": "1000 мг/сут",
                "duration": "Минимум 2-3 месяца",
                "effects": [
                    "Уменьшение отека",
                    "Снижение проницаемости капилляров",
                    "Улучшение трофики",
                    "Снижение симптомов"
                ]
            },
            "saponins": {
                "name": "Сапонины",
                "examples": ["Троксерутин"],
                "effects": ["Венотонизирующее", "Антиоксидантное"]
            },
            "other": [
                "Гесперидин",
                "Диосмин",
                "Рутозиды"
            ]
        },
        "anticoagulants": {
            "prophylaxis": "Низкомолекулярный гепарин после операций",
            "treatment": "При ТГВ"
        }
    },
    
    "deep_vein_thrombosis": {
        "diagnosis": {
            "clinical_probability": {
                "wells_score": [
                    {"criterion": "Активный рак", "points": 1},
                    {"criterion": "Паралич/иммобилизация", "points": 1},
                    {"criterion": "Недавняя постельная режим >3 дней", "points": 1},
                    {"criterion": "Локальная болезненность", "points": 1},
                    {"criterion": "Отек всей ноги", "points": 1},
                    {"criterion": "Отек >3 см", "points": 1},
                    {"criterion": "Болезненность вен", "points": 1},
                    {"criterion": "Альтернативный диагноз менее вероятен", "points": 1},
                    {"criterion": "ТГВ в анамнезе", "points": 1}
                ],
                "interpretation": {
                    "low": "0-1 балл",
                    "moderate": "2-6 баллов",
                    "high": ">6 баллов"
                }
            },
            "imaging": {
                "compression_ultrasound": "Золотой стандарт",
                "d_dimer": "При низкой клинической вероятности"
            }
        },
        "treatment": {
            "anticoagulation": {
                "initial": "НМГ или фондапаринукс",
                "long_term": "Варфарин или НОАК",
                "duration": {
                    "provoked": "3 месяца",
                    "unprovoked": "Бессрочно или длительно",
                    "recurrent": "Бессрочно"
                }
            },
            "thrombolysis": {
                "indications": [
                    "Флегмазия",
                    "Илеофеморальный ТГВ",
                    "Массивный ТГВ"
                ],
                "contraindications": [
                    "Недавнее кровотечение",
                    "Инсульт <3 месяцев",
                    "Нейрохирургия <3 месяцев"
                ]
            },
            "ivc_filter": {
                "indications": [
                    "ТЭЛА при противопоказаниях к антикоагуляции",
                    "Рецидив ТГВ на фоне антикоагуляции",
                    "Тяжелая травма с высоким риском ТЭЛА"
                ],
                "retrievable": "Предпочтительно временные фильтры"
            }
        }
    },
    
    "post_thrombotic_syndrome": {
        "villalta_score": {
            "symptoms": ["Боль", "Спазмы", "Тяжесть", "Парестезии", "Зуд"],
            "signs": ["Отек", "Кожная индурация", "Гиперпигментация", "Экзема", "Болезненность", "Венозная эктазия"],
            "scoring": "0-3 балла за каждый пункт",
            "interpretation": {
                "mild": "5-9 баллов",
                "moderate": "10-14 баллов",
                "severe": ">15 баллов"
            }
        },
        "prevention": {
            "compression": "Постоянная компрессия 2 класса",
            "pharmacotherapy": "Веноактивные препараты",
            "early_ambulation": "Ранняя мобилизация"
        }
    }
}


# ==================== ТИПЫ ИССЛЕДОВАНИЙ ====================

STUDY_TYPES = {
    "ct_angio": {
        "name": "КТ-ангиография",
        "modality": "CT",
        "contrast": True,
        "best_for": [
            "Аневризмы аорты",
            "Расслоение аорты",
            "Окклюзии артерий",
            "Планирование EVAR/TEVAR"
        ],
        "measurements": [
            "Диаметр сосудов",
            "Длина шейки аневризмы",
            "Углы ангуляции",
            "Кальциноз",
            "Тромбоз"
        ],
        "limitations": [
            "Контрастная нефропатия",
            "Лучевая нагрузка",
            "Аллергия на контраст"
        ]
    },
    
    "mra": {
        "name": "МР-ангиография",
        "modality": "MRI",
        "contrast": "Необязательно (можно без)",
        "best_for": [
            "Расслоение аорты",
            "Интрамуральная гематома",
            "Повторные исследования",
            "Молодые пациенты"
        ],
        "advantages": [
            "Нет лучевой нагрузки",
            "Можно без контраста",
            "Хорошая визуализация стенки"
        ],
        "limitations": [
            "Длительность",
            "Клаустрофобия",
            "Имплантаты (относительно)"
        ]
    },
    
    "duplex_ultrasound": {
        "name": "Дуплексное УЗИ",
        "modality": "Ultrasound",
        "contrast": False,
        "best_for": [
            "Каротидные артерии",
            "Варикозная болезнь",
            "Диагностика ТГВ",
            "Контроль после операций",
            "АКШ (ABI)"
        ],
        "measurements": [
            "Скорость кровотока",
            "Степень стеноза",
            "Рефлюкс",
            "Диаметр вен"
        ],
        "advantages": [
            "Неинвазивно",
            "Нет лучевой нагрузки",
            "Доступно",
            "Можно повторять"
        ]
    },
    
    "echocardiography": {
        "name": "Эхокардиография",
        "modality": "Ultrasound",
        "types": {
            "tte": "Трансторакальная ЭхоКГ",
            "tee": "Трансэзофагеальная ЭхоКГ"
        },
        "best_for": [
            "Аортальный клапан",
            "Восходящая аорта",
            "Дуга аорты",
            "Корень аорты",
            "Функция ЛЖ"
        ],
        "tee_advantages": [
            "Лучшая визуализация восходящей аорты",
            "Дуга аорты",
            "Визуализация интимы при расслоении"
        ],
        "measurements": [
            "Диаметр аорты",
            "Толщина стенки",
            "Фракция выброса",
            "Клапаны"
        ]
    },
    
    "conventional_angiography": {
        "name": "Конвенциональная ангиография",
        "modality": "DSA",
        "contrast": True,
        "best_for": [
            "Планирование эндоваскулярного лечения",
            "Оценка коллатералей",
            "Непонятные случаи"
        ],
        "limitations": [
            "Инвазивно",
            "Контрастная нефропатия",
            "Лучевая нагрузка"
        ]
    },
    
    "abi_measurement": {
        "name": "Измерение лодыжечно-плечевого индекса (АКШ)",
        "modality": "Doppler",
        "interpretation": {
            "normal": ">1.0",
            "mild_pad": "0.91-0.99",
            "moderate_pad": "0.41-0.90",
            "severe_pad": "<0.40",
            "noncompressible": ">1.4 (кальциноз)"
        },
        "note": "При кальцинозе использовать toe-brachial index (TBI)"
    }
}


def get_tasc_classification(lesion_type: str, lesion_description: str) -> Dict[str, Any]:
    """
    Определение TASC классификации по описанию поражения
    """
    tasc_data = TASC_II_CLASSIFICATION.get(lesion_type, {})
    
    result = {
        "lesion_type": lesion_type,
        "description": lesion_description,
        "tasc_class": None,
        "treatment_recommendation": None,
        "evidence": None
    }
    
    # Простой алгоритм определения класса
    if lesion_type == "aortoiliac":
        if "одиночный" in lesion_description.lower() and ("<3" in lesion_description or "< 3" in lesion_description):
            result["tasc_class"] = "A"
        elif "окклюзия ОПА" in lesion_description.lower() and "односторонняя" in lesion_description.lower():
            result["tasc_class"] = "B"
        elif "двусторонняя" in lesion_description.lower() and ("окклюзия" in lesion_description.lower() or "стеноз" in lesion_description.lower()):
            result["tasc_class"] = "C"
        elif "диффузное" in lesion_description.lower() or ">10" in lesion_description:
            result["tasc_class"] = "D"
    
    elif lesion_type == "femoropopliteal":
        if "<10" in lesion_description or "< 10" in lesion_description:
            result["tasc_class"] = "A"
        elif "<15" in lesion_description or "< 15" in lesion_description:
            result["tasc_class"] = "B"
        elif ">15" in lesion_description or "> 15" in lesion_description:
            result["tasc_class"] = "C"
        elif ">20" in lesion_description or "> 20" in lesion_description:
            result["tasc_class"] = "D"
    
    # Получаем рекомендации
    if result["tasc_class"]:
        class_data = tasc_data.get(f"type_{result['tasc_class'].lower()}", {})
        result["treatment_recommendation"] = class_data.get("treatment")
        result["evidence"] = class_data.get("recommendation")
    
    return result


def recommend_graft(
    procedure_type: str,
    patient_age: int,
    expected_survival: str,
    vein_available: bool,
    vein_diameter: Optional[float] = None,
    vein_quality: Optional[str] = None,
    urgency: str = "elective"
) -> Dict[str, Any]:
    """
    Рекомендация по выбору протеза/шунта
    """
    recommendation = {
        "primary_recommendation": None,
        "alternatives": [],
        "rationale": [],
        "patency_expectations": {},
        "special_considerations": []
    }
    
    # Бедренно-подколенное шунтирование
    if "femoropopliteal" in procedure_type.lower():
        if vein_available and vein_diameter and vein_diameter >= 3.0:
            if vein_quality != "varicose":
                recommendation["primary_recommendation"] = "Великая сапенозная вена (реверсивная)"
                recommendation["rationale"].append("Вена обеспечивает лучшую проходимость для инфраингвинальных реконструкций")
                recommendation["patency_expectations"] = {
                    "5_year": "70-80% (выше колена), 60-75% (ниже колена)"
                }
            else:
                recommendation["primary_recommendation"] = "PTFE или Dacron"
                recommendation["rationale"].append("Вена с варикозными изменениями не подходит")
        else:
            recommendation["primary_recommendation"] = "PTFE или Dacron"
            recommendation["alternatives"] = ["Вена (если доступна)", "Биологический протез"]
            recommendation["patency_expectations"] = {
                "5_year": "50-70% (выше колена), 30-50% (ниже колена)"
            }
    
    # Аорто-бифеморальное шунтирование
    elif "aortobifemoral" in procedure_type.lower():
        recommendation["primary_recommendation"] = "Dacron (тканый, коллаген-импрегнированный)"
        recommendation["alternatives"] = ["PTFE", "Вена (при инфекции)"]
        recommendation["rationale"].append("Dacron - золотой стандарт для аортальных реконструкций")
        recommendation["patency_expectations"] = {
            "5_year": "85-95%",
            "10_year": "75-85%"
        }
    
    # Каротидная эндартерэктомия - заплата
    elif "carotid" in procedure_type.lower():
        if vein_available:
            recommendation["primary_recommendation"] = "Аутовенозная заплата (ВСВ)"
            recommendation["alternatives"] = ["PTFE заплата", "Ксеноперикард"]
            recommendation["rationale"].append("Аутовена - оптимальный материал для пластики БЦС")
        else:
            recommendation["primary_recommendation"] = "PTFE заплата или ксеноперикард"
            recommendation["rationale"].append("При недоступности вены")
    
    # Срочное вмешательство
    if urgency == "urgent" or urgency == "emergency":
        recommendation["special_considerations"].append("При срочном вмешательстве может быть предпочтителен протез (быстрее)")
    
    # Возраст и ожидаемая выживаемость
    if expected_survival == "short" or patient_age > 80:
        recommendation["special_considerations"].append("При ограниченной выживаемости синтетический протез приемлем")
    
    return recommendation
