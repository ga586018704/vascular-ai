"""
VASCULAR.AI - 3D инструменты измерения для планирования EVAR/TEVAR
Анатомические измерения, подбор стент-графтов, симуляция
"""

from typing import Dict, Any, List, Optional, Tuple
import math


# ==================== ИЗМЕРЕНИЯ ДЛЯ EVAR ====================

EVAR_MEASUREMENTS = {
    "required_measurements": {
        "proximal_neck": {
            "name": "Проксимальная шейка аневризмы",
            "parameters": [
                {
                    "name": "diameter",
                    "description": "Диаметр шейки",
                    "measurement": "Самый короткий диаметр (обычно AP)",
                    "normal_range": "18-32 мм",
                    "minimum_for_evar": ">18 мм (зависит от устройства)",
                    "maximum_for_evar": "<32 мм"
                },
                {
                    "name": "length",
                    "description": "Длина шейки",
                    "measurement": "От почечных артерий до начала аневризмы",
                    "minimum": ">10-15 мм (зависит от устройства)",
                    "optimal": ">20 мм",
                    "note": "Короткая шейка - риск migration"
                },
                {
                    "name": "angulation",
                    "description": "Ангуляция шейки",
                    "measurement": "Угол между осью шейки и аневризмы",
                    "threshold": "<60° (некоторые устройства до 90°)",
                    "note": "Большая ангуляция - риск endoleak type I"
                },
                {
                    "name": "thrombus",
                    "description": "Тромб в шейке",
                    "assessment": "Количество тромба в шейке",
                    "threshold": "<50% окружности",
                    "note": "Обширный тромб - риск неплотного прилегания"
                },
                {
                    "name": "calcification",
                    "description": "Кальциноз шейки",
                    "assessment": "Окружная кальцификация",
                    "threshold": "<50% окружности",
                    "note": "Кольцевая кальцификация - риск неплотного seal"
                }
            ]
        },
        
        "aneurysm_sac": {
            "name": "Мешок аневризмы",
            "parameters": [
                {
                    "name": "max_diameter",
                    "description": "Максимальный диаметр",
                    "measurement": "Самый большой диаметр в любой плоскости",
                    "indication_for_treatment_male": ">55 мм",
                    "indication_for_treatment_female": ">50 мм",
                    "rapid_growth": ">5 мм за 6 месяцев"
                },
                {
                    "name": "length",
                    "description": "Длина аневризмы",
                    "measurement": "От шейки до бифуркации аорты",
                    "note": "Влияет на выбор длины основного тела"
                },
                {
                    "name": "volume",
                    "description": "Объем аневризмы",
                    "measurement": "3D реконструкция",
                    "note": "Для отслеживания роста после EVAR"
                }
            ]
        },
        
        "iliac_arteries": {
            "name": "Подвздошные артерии",
            "parameters": [
                {
                    "name": "common_iliac_diameter",
                    "description": "Диаметр общей подвздошной",
                    "measurement": "Вне аневризматического расширения",
                    "normal": "8-12 мм",
                    "aneurysm_threshold": ">18 мм"
                },
                {
                    "name": "external_iliac_diameter",
                    "description": "Диаметр наружной подвздошной",
                    "measurement": "Минимальный диаметр",
                    "minimum_for_limb": ">7-8 мм (зависит от устройства)"
                },
                {
                    "name": "internal_iliac_origin",
                    "description": "Отхождение внутренней подвздошной",
                    "assessment": "Расстояние от бифуркации аорты",
                    "note": "Важно для планирования покрытия"
                },
                {
                    "name": "iliac_aneurysm",
                    "description": "Аневризма подвздошной",
                    "threshold": ">18 мм",
                    "management": "Может потребовать extension или эмболизации ВПА"
                }
            ]
        },
        
        "landing_zones": {
            "name": "Зоны landing",
            "proximal": {
                "zone_0": "Проксимальная восходящая аорта",
                "zone_1": "Дистальная восходящая аорта",
                "zone_2": "Дуга аорты",
                "zone_3": "Проксимальная нисходящая аорта (проксимальная шейка)"
            },
            "distal": {
                "zone_4": "Вся брюшная аорта",
                "zone_5": "Проксимальная общая подвздошная",
                "zone_6": "Вся общая подвздошная",
                "zone_7": "Проксимальная наружная подвздошная",
                "zone_8": "Вся наружная подвздошная",
                "zone_9": "Общая бедренная артерия"
            }
        }
    },
    
    "device_selection": {
        "main_body": {
            "criteria": [
                "Диаметр проксимальной шейки + 10-20% oversizing",
                "Длина покрытия шейки (минимум 15-20 мм)",
                "Диаметр должен позволить contralateral limb"
            ],
            "available_devices": {
                "cook_zenith": {
                    "name": "Cook Zenith",
                    "diameters": "22-36 мм",
                    "lengths": "110-215 мм",
                    "neck_requirements": ">15 мм, <60°"
                },
                "gore_excluder": {
                    "name": "Gore Excluder",
                    "diameters": "23-32 мм",
                    "lengths": "130-200 мм",
                    "neck_requirements": ">15 мм, <60°"
                },
                "medtronic_endurant": {
                    "name": "Medtronic Endurant",
                    "diameters": "23-36 мм",
                    "lengths": "115-220 мм",
                    "neck_requirements": ">10 мм, <60°"
                },
                "lombard_aorfix": {
                    "name": "Lombard Aorfix",
                    "diameters": "19-31 мм",
                    "neck_requirements": ">10 мм, до 90°"
                }
            }
        },
        
        "iliac_limbs": {
            "selection_criteria": [
                "Диаметр наружной подвздошной + 10-20% oversizing",
                "Длина от бифуркации аорты до наружной подвздошной"
            ],
            "options": {
                "ipsilateral": "Продолжение основного тела",
                "contralateral": "Отдельный limb"
            }
        },
        
        "extensions": {
            "proximal_cuff": {
                "indication": "Недостаточный seal в шейке",
                "sizing": "Диаметр шейки + 10-15%"
            },
            "distal_extensions": {
                "indication": "Аневризма подвздошной или недостаточная длина",
                "options": ["Iliac limb extension", "Branch preservation"]
            }
        }
    },
    
    "oversizing_guidelines": {
        "proximal": {
            "recommended": "10-20%",
            "minimum": "5%",
            "maximum": "30%",
            "note": "Чрезмерный oversizing - риск складок и endoleak"
        },
        "distal": {
            "recommended": "10-15%",
            "note": "Меньше чем проксимально"
        }
    }
}


# ==================== ИЗМЕРЕНИЯ ДЛЯ TEVAR ====================

TEVAR_MEASUREMENTS = {
    "required_measurements": {
        "proximal_landing": {
            "name": "Проксимальная зона landing",
            "parameters": [
                {
                    "name": "diameter",
                    "description": "Диаметр аорты",
                    "measurement": "В зоне proximal landing",
                    "range": "18-42 мм (зависит от устройства)",
                    "oversizing": "10-15%"
                },
                {
                    "name": "length",
                    "description": "Длина healthy landing zone",
                    "minimum": ">20-25 мм",
                    "optimal": ">30 мм",
                    "note": "От левой подключичной артерии до начала патологии"
                },
                {
                    "name": "angulation",
                    "description": "Ангуляция дуги аорты",
                    "measurement": "Угол дуги",
                    "threshold": "<90° (для большинства устройств)"
                }
            ]
        },
        
        "aortic_arch": {
            "name": "Дуга аорты",
            "parameters": [
                {
                    "name": "arch_diameter",
                    "description": "Диаметр дуги аорты",
                    "measurement": "В самом широком месте"
                },
                {
                    "name": "arch_types",
                    "description": "Классификация дуги аорты",
                    "types": {
                        "type_1": "Все ветви отходят от дуги (29%)",
                        "type_2": "Брахиоцефальный и ЛОСА отходят вместе (13%)",
                        "type_3": "Все ветви отходят от восходящей аорты (9%)"
                    }
                },
                {
                    "name": "branch_distances",
                    "description": "Расстояния между ветвями",
                    "measurements": [
                        "ЛПА - ЛОСА",
                        "ЛОСА - ПОСА",
                        "ПОСА - конец дуги"
                    ]
                }
            ]
        },
        
        "coverage_planning": {
            "name": "Планирование покрытия",
            "zones": {
                "zone_0": "Проксимальная восходящая аорта",
                "zone_1": "Дистальная восходящая аорта",
                "zone_2": "Дуга аорты (покрытие ЛПА)",
                "zone_3": "Дистальная дуга/проксимальная нисходящая (покрытие ЛОСА)",
                "zone_4": "Проксимальная торакальная аорта (покрытие ПОСА)"
            },
            "branch_preservation": {
                "left_subclavian": {
                    "coverage_decision": [
                        "Планируется покрытие ЛПА?",
                        "Доминантная левая рука?",
                        "Патентная LIMA для CABG?",
                        "Патентная левая позвоночная артерия?"
                    ],
                    "options": [
                        "Покрытие без реваскуляризации (если правая доминантная)",
                        "Предоперационная транспозиция ЛПА",
                        "Каротидо-субклавианское шунтирование",
                        "Chimney/sandwich technique"
                    ]
                }
            }
        },
        
        "distal_landing": {
            "name": "Дистальная зона landing",
            "parameters": [
                {
                    "name": "diameter",
                    "description": "Диаметр аорты",
                    "measurement": "В зоне distal landing",
                    "oversizing": "10-15%"
                },
                {
                    "name": "length",
                    "description": "Длина healthy landing zone",
                    "minimum": ">20 мм"
                }
            ]
        },
        
        "access_assessment": {
            "name": "Оценка доступа",
            "iliac_arteries": {
                "minimum_diameter": {
                    "21F": ">7 мм",
                    "22F": ">7.5 мм",
                    "24F": ">8 мм",
                    "27F": ">9 мм"
                },
                "contraindications": [
                    "Тяжелый кальциноз",
                    "Значимый стеноз",
                    "Малый диаметр"
                ]
            }
        }
    },
    
    "device_selection": {
        "available_devices": {
            "gore_tag": {
                "name": "Gore TAG",
                "diameters": "21-45 мм",
                "lengths": "100-200 мм",
                "delivery": "20-24F",
                "conformability": "Хорошая"
            },
            "cook_tx2": {
                "name": "Cook TX2",
                "diameters": "28-42 мм",
                "lengths": "100-200 мм",
                "delivery": "22-27F"
            },
            "medtronic_valiant": {
                "name": "Medtronic Valiant",
                "diameters": "22-46 мм",
                "lengths": "100-217 мм",
                "delivery": "20-27F",
                "freeflow": "Да"
            },
            "bolton_relay": {
                "name": "Bolton Relay",
                "diameters": "22-46 мм",
                "lengths": "100-200 мм",
                "delivery": "20-27F"
            },
            "jotec_e_xtra": {
                "name": "Jotec E-xtra",
                "diameters": "16-46 мм",
                "lengths": "68-216 мм",
                "delivery": "18-25F"
            }
        },
        
        "selection_criteria": [
            "Диаметр proximal landing zone + 10-15% oversizing",
            "Длина покрытия патологии + 20-30 мм healthy landing с каждой стороны",
            "Анатомия дуги (angulation, branch positions)",
            "Размер доступа"
        ]
    },
    
    "spinal_cord_protection": {
        "risk_factors": [
            "Длина покрытия >20 см",
            "Покрытие T8-L1",
            "Предыдущая абдоминальная аортальная операция",
            "Гипотензия"
        ],
        "preventive_measures": [
            "Поддержание АД (MAP >90 мм рт.ст.)",
            "Люмбальный дренаж (при высоком риске)",
            "Реваскуляризация ЛПклА при необходимости",
            "Минимизация времени пережатия"
        ],
        "monitoring": [
            "Неврологический мониторинг в течение 24-48 часов",
            "Раннее mobilization"
        ]
    }
}


# ==================== ФУНКЦИИ РАСЧЕТА ====================

def calculate_evar_sizing(measurements: Dict[str, float]) -> Dict[str, Any]:
    """
    Расчет размеров стент-графта для EVAR
    """
    neck_diameter = measurements.get("neck_diameter", 0)
    neck_length = measurements.get("neck_length", 0)
    aneurysm_length = measurements.get("aneurysm_length", 0)
    common_iliac_diameter = measurements.get("common_iliac_diameter", 0)
    external_iliac_diameter = measurements.get("external_iliac_diameter", 0)
    
    # Расчет oversizing
    main_body_diameter = neck_diameter * 1.15  # 15% oversizing
    
    # Проверка пригодности
    suitability = {
        "suitable_for_evar": True,
        "concerns": [],
        "contraindications": []
    }
    
    if neck_length < 10:
        suitability["contraindications"].append("Слишком короткая шейка (<10 мм)")
        suitability["suitable_for_evar"] = False
    elif neck_length < 15:
        suitability["concerns"].append("Короткая шейка - требуется устройство с короткой fixation")
    
    if neck_diameter > 32:
        suitability["contraindications"].append("Слишком большой диаметр шейки (>32 мм)")
        suitability["suitable_for_evar"] = False
    
    if external_iliac_diameter < 7:
        suitability["concerns"].append("Малый диаметр наружной подвздошной - возможен кондуит")
    
    return {
        "suitability": suitability,
        "recommended_sizes": {
            "main_body": {
                "diameter_mm": round(main_body_diameter, 1),
                "length_mm": "Выбрать на основе aneurysm_length + 20 мм",
                "oversizing_percent": 15
            },
            "ipsilateral_iliac_limb": {
                "diameter_mm": round(common_iliac_diameter * 1.1, 1),
                "oversizing_percent": 10
            },
            "contralateral_iliac_limb": {
                "diameter_mm": round(external_iliac_diameter * 1.1, 1),
                "oversizing_percent": 10
            }
        },
        "additional_considerations": [
            "Проверить покрытие внутренних подвздошных",
            "Оценить необходимость extensions",
            "Планировать access (перкутанный vs cutdown)"
        ]
    }


def calculate_tevAR_sizing(measurements: Dict[str, float]) -> Dict[str, Any]:
    """
    Расчет размеров стент-графта для TEVAR
    """
    proximal_diameter = measurements.get("proximal_diameter", 0)
    distal_diameter = measurements.get("distal_diameter", 0)
    coverage_length = measurements.get("coverage_length", 0)
    left_subclavian_distance = measurements.get("left_subclavian_distance", 0)
    
    # Расчет oversizing
    device_diameter = proximal_diameter * 1.10  # 10% oversizing
    
    # Проверка пригодности
    suitability = {
        "suitable_for_tevAR": True,
        "concerns": [],
        "contraindications": []
    }
    
    if left_subclavian_distance < 20:
        suitability["concerns"].append("Короткое расстояние до ЛПА - возможно потребуется реваскуляризация")
    
    if coverage_length > 200:
        suitability["concerns"].append("Длинное покрытие - высокий риск параплегии, рассмотреть люмбальный дренаж")
    
    return {
        "suitability": suitability,
        "recommended_sizes": {
            "main_graft": {
                "diameter_mm": round(device_diameter, 1),
                "length_mm": round(coverage_length + 40, 0),  # +20 мм с каждой стороны
                "oversizing_percent": 10
            }
        },
        "branch_considerations": {
            "left_subclavian": {
                "coverage_planned": left_subclavian_distance < 20,
                "revascularization_options": [
                    "Транспозиция ЛПА",
                    "Каротидо-субклавианское шунтирование",
                    "Chimney technique"
                ] if left_subclavian_distance < 20 else []
            }
        },
        "spinal_cord_protection": {
            "risk_level": "Высокий" if coverage_length > 200 else "Умеренный",
            "recommendations": [
                "Поддержание АД (MAP >90 мм рт.ст.)",
                "Люмбальный дренаж" if coverage_length > 200 else "Рассмотреть люмбальный дренаж"
            ]
        }
    }


def get_measurement_checklist(procedure_type: str) -> Dict[str, Any]:
    """
    Получить чек-лист измерений для процедуры
    """
    if procedure_type == "evar":
        return {
            "procedure": "EVAR",
            "required_measurements": EVAR_MEASUREMENTS["required_measurements"],
            "note": "Все измерения должны быть выполнены на КТ-ангиографии с 1-2 мм срезами"
        }
    elif procedure_type == "tevar":
        return {
            "procedure": "TEVAR",
            "required_measurements": TEVAR_MEASUREMENTS["required_measurements"],
            "note": "Все измерения должны быть выполнены на КТ-ангиографии с 1-2 мм срезами"
        }
    else:
        return {"error": f"Unknown procedure type: {procedure_type}"}
