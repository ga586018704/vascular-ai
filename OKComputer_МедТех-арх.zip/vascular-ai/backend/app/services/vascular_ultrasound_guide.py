"""
VASCULAR.AI - Руководство по сосудистому УЗИ
На основе:
- Making Sense of Vascular Ultrasound (Myers, Clough)
- Practical Vascular Ultrasound (Myers, Clough) - CRC Press
- Vascular Ultrasound: How, Why and When (Thrush, Hartshorne)
"""

from typing import Dict, Any, List, Optional


# ==================== ОСНОВЫ УЗИ СОСУДОВ ====================

ULTRASOUND_BASICS = {
    "physics": {
        "doppler_principle": {
            "description": "Изменение частоты отраженного звука от движущихся эритроцитов",
            "formula": "Δf = 2fv cos(θ) / c",
            "variables": {
                "f": "Частота передатчика",
                "v": "Скорость крови",
                "θ": "Угол допплеровского луча",
                "c": "Скорость звука в ткани"
            }
        },
        "angle_correction": {
            "optimal": "45-60°",
            "acceptable": "30-70°",
            "avoid": ">70° (недооценка скорости)"
        }
    },
    
    "equipment_settings": {
        "carotid": {
            "transducer": "Linear 5-10 MHz",
            "depth": "3-4 см",
            "PRF": "4000-8000 Hz",
            "wall_filter": "100-200 Hz"
        },
        "peripheral": {
            "transducer": "Linear 5-12 MHz",
            "depth": "2-6 см",
            "PRF": "3000-6000 Hz"
        },
        "deep_abdominal": {
            "transducer": "Curved 2-5 MHz",
            "depth": "8-15 см",
            "PRF": "2000-4000 Hz"
        }
    },
    
    "color_doppler": {
        "settings": {
            "color_gain": "Just below noise level",
            "color_scale": "Adjust to expected velocity",
            "color box": "As small as possible for frame rate"
        },
        "interpretation": {
            "red": "Кровоток к трансдьюсеру",
            "blue": "Кровоток от трансдьюсера",
            "variance": "Турбулентность (зеленый/желтый)"
        }
    },
    
    "spectral_doppler": {
        "waveform_components": {
            "systolic_peak": "Максимальная систолическая скорость",
            "end_diastolic": "Скорость в конце диастолы",
            "resistive_index": "(PSV - EDV) / PSV"
        },
        "measurement_technique": {
            "sample_volume": "1.5-2 мм (для артерий)",
            "angle_correction": "Обязательно",
            "sweep_speed": "Medium (для оценки waveform)"
        }
    }
}


# ==================== УЗИ СОННЫХ АРТЕРИЙ ====================

CAROTID_ULTRASOUND = {
    "protocol": {
        "patient_preparation": "Супинация, голова повернута в противоположную сторону",
        "views": [
            "Longitudinal - proximal CCA",
            "Longitudinal - distal CCA",
            "Longitudinal - bulb",
            "Longitudinal - ICA",
            "Longitudinal - ECA",
            "Transverse - all levels"
        ],
        "measurements": [
            "PSV и EDV в CCA",
            "PSV и EDV в ICA (в стенозе и дистально)",
            "PSV и EDV в ECA",
            "ICA/CCA ratio"
        ]
    },
    
    "stenosis_criteria": {
        "society_radiology": {
            "normal": {
                "PSV": "<125 см/с",
                "EDV": "<40 см/с",
                "ratio": "<2.0",
                "plaque": "Нет или <50%"
            },
            "50_69_percent": {
                "PSV": "125-230 см/с",
                "EDV": "40-100 см/с",
                "ratio": "2.0-4.0",
                "plaque": "50-69%"
            },
            "70_99_percent": {
                "PSV": ">230 см/с",
                "EDV": ">100 см/с",
                "ratio": ">4.0",
                "plaque": "70-99%"
            },
            "occlusion": {
                "findings": "No flow, ECA fills ICA via collaterals"
            }
        }
    },
    
    "plaque_characterization": {
        "echogenicity": {
            "hyperechoic": "Фиброзная (стабильная)",
            "isoechoic": "Смешанная",
            "hypoechoic": "Липидная/геморрагическая (нестабильная)"
        },
        "surface": {
            "smooth": "Стабильная",
            "irregular": "Нестабильная",
            "ulcerated": "Высокий риск"
        },
        "features": {
            "calcification": "Акустическая тень",
            "hemorrhage": "Нестабильность",
            "lipid_core": "Нестабильность"
        }
    },
    
    "subclavian_steal": {
        "mechanism": "Стеноз/окклюзия подключичной артерии",
        "findings": [
            "Реверс тока в позвоночной артерии",
            "PSV >200 см/с в подключичной",
            "Задержка upstroke в верхней конечности"
        ],
        "grades": {
            "1": "Систолический deceleration",
            "2": "Альтернирующий ток",
            "3": "Полный реверс"
        }
    },
    
    "vertebral_artery": {
        "normal": {
            "diameter": "3-5 мм",
            "PSV": "30-60 см/с",
            "direction": "Краниальный"
        },
        "abnormal": {
            "hypoplasia": "<2.5 мм",
            "reversed_flow": "Subclavian steal",
            "absent_flow": "Окклюзия или агенезия"
        }
    }
}


# ==================== УЗИ ПЕРИФЕРИЧЕСКИХ АРТЕРИЙ ====================

PERIPHERAL_ULTRASOUND = {
    "protocol": {
        "patient_preparation": "Супинация, ноги слегка согнуты и отведены",
        "examination_sequence": [
            "Common femoral artery (CFA)",
            "Profunda femoris origin",
            "Superficial femoral artery (SFA)",
            "Popliteal artery",
            "Tibial arteries (anterior, posterior, peroneal)",
            "Dorsalis pedis"
        ],
        "measurements": "PSV в каждом сегменте, ratio при стенозе"
    },
    
    "stenosis_criteria": {
        "monophasic_waveform": {
            "meaning": "Тяжелый стеноз или окклюзия проксимально",
            "action": "Искать проксимальное поражение"
        },
        "velocity_increase": {
            "doubling": ">50% стеноз",
            "tripling": ">75% стеноз",
            "quadrupling": ">90% стеноз"
        },
        "tardus_parvus": {
            "meaning": "Замедленный и низкий пик (дистально от стеноза)",
            "indicates": "Гемодинамически значимый стеноз проксимально"
        }
    },
    
    "bypass_graft_surveillance": {
        "baseline": "В течение 1 месяца после операции",
        "schedule": {
            "month_1": "Baseline",
            "month_3": "First follow-up",
            "month_6": "Second follow-up",
            "thereafter": "Every 6 months"
        },
        "abnormal_findings": {
            "low_flow": {
                "PSV": "<45-50 см/с",
                "meaning": "Тромбоз или проксимальный стеноз"
            },
            "high_flow": {
                "PSV": ">200-300 см/с",
                "ratio": ">3.5",
                "meaning": "Анастомотический стеноз"
            },
            "velocity_drop": {
                "criteria": ">20 см/с drop between segments",
                "meaning": " intervening stenosis"
            }
        }
    },
    
    "graft_types": {
        "vein": {
            "normal_PSV": "60-100 см/с",
            "surveillance": "Каждые 3-6 месяцев"
        },
        "prosthetic": {
            "normal_PSV": "90-150 см/с",
            "surveillance": "Каждые 6-12 месяцев"
        }
    }
}


# ==================== УЗИ ВЕН ====================

VENOUS_ULTRASOUND = {
    "dvt_protocol": {
        "patient_preparation": "Супинация, нога слегка согнута и отведена",
        "compression_test": {
            "technique": "Сжатие вены поперек",
            "normal": "Полное сжатие",
            "abnormal": "Неполное сжатие (тромб)"
        },
        "examination": [
            "Common femoral vein",
            "Femoral vein (superficial and deep)",
            "Popliteal vein",
            "Calf veins (optional)",
 "Iliac veins (if indicated)"
        ],
        "augmentation": "Сжатие икры → увеличение потока",
        "respiratory_variation": "Уменьшение потока при вдохе (норма)"
    },
    
    "dvt_diagnosis": {
        "direct_signs": [
            "Неполное сжатие вены",
            "Визуализация тромба",
            "Отсутствие цветового сигнала"
        ],
        "indirect_signs": [
            "Отсутствие respiratory variation",
            "Отсутствие augmentation",
            "Дилатация вены"
        ],
        "chronic_dvt": [
            "Неполное сжатие",
            "Тонкие стенки",
            "Коллатерали",
            "Рефлюкс"
        ]
    },
    
    "venous_reflux": {
        "test": "Valsalva или сжатие/расслабление",
        "normal": "<0.5 сек рефлюкса",
        "abnormal": ">1 сек рефлюкса",
        "grading": {
            "grade_1": "1-2 сек",
            "grade_2": "2-4 сек",
            "grade_3": ">4 сек"
        }
    },
    
    "varicose_veins_mapping": {
        "purpose": "Планирование лечения",
        "examination": [
            "Great saphenous vein (GSV)",
            "Small saphenous vein (SSV)",
            "Perforators",
            "Deep system patency"
        ],
        "measurements": [
            "Диаметр GSV (норма <4 мм)",
            "Диаметр SSV (норма <3 мм)",
            "Рефлюкс (>0.5 сек)"
        ]
    }
}


# ==================== УЗИ БРЮШНОЙ АОРТЫ ====================

AORTIC_ULTRASOUND = {
    "aaa_screening": {
        "indication": "Мужчины 65-75 лет, курившие",
        "technique": "Трансабдоминальное",
        "measurement": "Вне-вне (outer-to-outer)",
        "views": [
            "Transverse - suprarenal",
            "Transverse - maximum diameter",
            "Transverse - infrarenal",
            "Longitudinal"
        ],
        "thresholds": {
            "normal": "<3 см",
            "ectasia": "3-4 см",
            "aneurysm": ">3 см",
            "treatment": ">5.5 см (мужчины), >5.0 см (женщины)"
        }
    },
    
    "surveillance": {
        "3_4_cm": "Каждые 2-3 года",
        "4_5_cm": "Каждые 12 месяцев",
        "5_5_cm": "Каждые 3-6 месяцев или операция"
    },
    
    "limitations": [
        "Ожирение",
 "Кишечный газ",
        "Тортуозность"
    ]
}


# ==================== ФУНКЦИИ ДЛЯ API ====================

def interpret_carotid_stenosis(psv_ica: float, edv_ica: float, 
                                ratio: float) -> Dict[str, Any]:
    """
    Интерпретация стеноза сонной артерии по УЗИ
    """
    if psv < 125 and ratio < 2.0:
        stenosis = "<50%"
        significance = "Незначимый"
        follow_up = "Ежегодно"
    elif psv < 230 and ratio < 4.0:
        stenosis = "50-69%"
        significance = "Умеренный"
        follow_up = "Каждые 6 месяцев"
    elif psv >= 230 or ratio >= 4.0:
        stenosis = "70-99%"
        significance = "Тяжелый"
        follow_up = "Консультация сосудистого хирурга"
    else:
        stenosis = "Неопределен"
        significance = "Требует повторного исследования"
        follow_up = "Повторное УЗИ"
    
    return {
        "PSV_ICA": psv_ica,
        "EDV_ICA": edv_ica,
        "ICA/CCA_ratio": ratio,
        "stenosis_estimate": stenosis,
        "significance": significance,
        "follow_up": follow_up
    }


def interpret_bypass_graft(psv: float, location: str) -> Dict[str, Any]:
    """
    Интерпретация УЗИ шунта
    """
    # Нормальные значения
    if location == "vein":
        normal_low, normal_high = 60, 100
    else:  # prosthetic
        normal_low, normal_high = 90, 150
    
    if psv < 45:
        status = "Critical - тромбоз или проксимальный стеноз"
        action = "Срочная ангиография"
    elif psv < normal_low:
        status = "Low flow - наблюдение"
        action = "УЗИ через 1 месяц"
    elif psv > 300:
        status = "High flow - анастомотический стеноз"
        action = "Ангиография"
    elif psv > 200:
        status = "Elevated - наблюдение"
        action = "УЗИ через 3 месяца"
    else:
        status = "Normal"
        action = "Плановое наблюдение"
    
    return {
        "PSV": psv,
        "graft_type": location,
        "normal_range": f"{normal_low}-{normal_high} см/с",
        "status": status,
        "action": action
    }


def get_dvt_probability(wells_score: int) -> Dict[str, Any]:
    """
    Оценка вероятности ТГВ по шкале Wells
    """
    if wells_score <= 0:
        probability = "Низкая"
        d_dimer = "Отрицательный D-dimer исключает ТГВ"
        ultrasound = "Не требуется при отрицательном D-dimer"
    elif wells_score <= 2:
        probability = "Умеренная"
        d_dimer = "Высокая чувствительность D-dimer"
        ultrasound = "УЗИ если D-dimer положительный"
    else:
        probability = "Высокая"
        d_dimer = "D-dimer не информативен"
        ultrasound = "УЗИ обязательно"
    
    return {
        "wells_score": wells_score,
        "probability": probability,
        "d_dimer_interpretation": d_dimer,
        "ultrasound_recommendation": ultrasound
    }
