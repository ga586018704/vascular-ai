from typing import Dict, Any, List, Optional
from datetime import datetime
from pathlib import Path
import json

from jinja2 import Template

from app.core.config import get_settings

settings = get_settings()


# ============================================
# ПОЛНЫЙ СПРАВОЧНИК СОСУДИСТЫХ ОПЕРАЦИЙ
# Интегрирован с ESVS 2024, SVS, российскими клиническими рекомендациями
# ============================================

PROTOCOL_TEMPLATES = {
    # ============================================
    # 1. ОПЕРАЦИИ НА АОРТЕ (AORTIC SURGERY)
    # ============================================
    
    "aortic_resection": {
        "name": "Резекция аневризмы брюшной аорты с протезированием",
        "name_en": "Abdominal Aortic Aneurysm Resection with Grafting",
        "category": "open_surgery",
        "indications": [
            "Диаметр аневризмы ≥55 мм (мужчины) или ≥50 мм (женщины) - ESVS 2024 Class I",
            "Темп роста >10 мм/год",
            "Симптоматическая аневризма (боль, дискомфорт)",
            "Мешотидная морфология с риском разрыва"
        ],
        "contraindications": [
            "Тяжёлая сопутствующая патология (ожидаемая продолжительность жизни <2 лет)",
            "Активная инфекция",
            "Неконтролируемая коагулопатия"
        ],
        "steps": [
            "Подготовка операционного поля, антисептическая обработка",
            "Срединная лапаротомия от мечевидного отростка до лонного сочленения",
            "Обнажение брюшной аорты от почечных артерий до бифуркации",
            "Мобилизация левой почечной вены (при необходимости)",
            "Контроль проксимального отдела аорты выше почечных артерий",
            "Контроль дистального отдела аорты и подвздошных артерий",
            "Введение гепарина (100 ЕД/кг в/в), контроль АКТ",
            "Пережатие аорты проксимально к аневризме",
            "Пережатие подвздошных артерий",
            "Вскрытие аневризмы, удаление тромботических масс",
            "Имплантация трубчатого протеза (Dacron/ePTFE)",
            "Наложение проксимального анастомоза (непрерывный шов 3-0 Prolene)",
            "Наложение дистального анастомоза",
            "Восстановление кровотока (сначала наружные, затем общие подвздошные)",
            "Гемостаз, дренирование брюшной полости",
            "Послойное ушивание раны"
        ],
        "checklist": [
            "Антибиотикопрофилактика (цефазолин 2г) за 30-60 мин до разреза",
            "Катетеризация мочевого пузыря (контроль диуреза)",
            "Гепаринизация перед пережатием (100 ЕД/кг)",
            "Контроль АД (целевое 100-120 мм рт.ст.)",
            "Мониторинг диуреза (>0.5 мл/кг/ч)",
            "Контроль лактата и кислотно-основного состояния",
            "Подготовка крови для переливания (2-4 ЭДК)",
            "Наличие протеза нужного диаметра (18-24 мм)"
        ],
        "risks": [
            {"complication": "Почечная недостаточность", "probability": "11-20%", "severity": "high"},
            {"complication": "Ишемия нижних конечностей", "probability": "3-8%", "severity": "high"},
            {"complication": "Кровотечение, требующее переливания", "probability": "20-30%", "severity": "moderate"},
            {"complication": "Инфекция протеза", "probability": "1-5%", "severity": "high"},
            {"complication": "Тромбоз протеза", "probability": "2-5%", "severity": "high"},
            {"complication": "Параплегия", "probability": "<1%", "severity": "extreme"},
            {"complication": "Сердечно-сосудистые осложнения", "probability": "5-10%", "severity": "high"},
            {"complication": "Кишечная ишемия", "probability": "2-5%", "severity": "high"}
        ],
        "graft_types": [
            "Трубчатый Dacron 18-24 мм",
            "ePTFE 18-24 мм",
            "Разветвленный Dacron (для бифуркации)"
        ],
        "evidence_base": {
            "guidelines": ["ESVS Guidelines 2024", "SVS Guidelines 2023"],
            "key_studies": ["UK Small Aneurysm Trial", "ADAM Trial", "DREAM Trial"],
            "recommendation_class": "Class I, Level A"
        }
    },
    
    "aortic_bifurcation_bypass": {
        "name": "Бифуркационное аорто-бедренное шунтирование",
        "name_en": "Aortobifemoral Bypass",
        "category": "open_surgery",
        "indications": [
            "Тотальная окклюзия аорты и подвздошных артерий",
            "Симптоматическая окклюзия аорты (клаудикация, критическая ишемия)"
        ],
        "steps": [
            "Срединная лапаротомия + разрезы в обеих паховых областях",
            "Обнажение брюшной аорты и общих бедренных артерий",
            "Контроль аорты выше бифуркации",
            "Гепаринизация (100 ЕД/кг)",
            "Пережатие аорты и подвздошных артерий",
            "Формирование проксимального анастомоза с аортой",
            "Прокладка Y-образного протеза к паховым областям",
            "Формирование дистальных анастомозов с общими бедренными артериями",
            "Восстановление кровотока",
            "Гемостаз, дренирование"
        ],
        "checklist": [
            "Антибиотикопрофилактика",
            "Гепаринизация",
            "Контроль пульсации на конечностях до и после",
            "Допплер-контроль кровотока"
        ],
        "risks": [
            {"complication": "Протезная инфекция", "probability": "1-3%", "severity": "high"},
            {"complication": "Аортодуоденальная фистула", "probability": "0.5-1%", "severity": "extreme"},
            {"complication": "Тромбоз шунта", "probability": "5-10%", "severity": "high"},
            {"complication": "Лимфная фистула в паху", "probability": "5-10%", "severity": "moderate"}
        ],
        "graft_types": ["Разветвленный Dacron 14-18 мм", "Разветвленный ePTFE"],
        "evidence_base": {
            "guidelines": ["ESVS Guidelines 2024"],
            "key_studies": ["Dutch Bypass Oral anticoagulants or Aspirin Study"],
            "recommendation_class": "Class I, Level A"
        }
    },
    
    "evar": {
        "name": "Эндоваскулярная имплантация стент-графта (EVAR)",
        "name_en": "Endovascular Aortic Repair",
        "category": "endovascular",
        "indications": [
            "Аневризма брюшной аорты с подходящей анатомией",
            "Диаметр аневризмы ≥55 мм (мужчины) или ≥50 мм (женщины)",
            "Рваная аневризма (при подходящей анатомии) - ESVS 2024 Class I"
        ],
        "anatomical_criteria": [
            "Длина шейки аневризмы ≥10 мм",
            "Диаметр шейки ≤32 мм",
            "Ангуляция шейки ≤60°",
            "Диаметр подвздошных артерий ≥6 мм"
        ],
        "steps": [
            "Пункция обеих бедренных артерий (перкутанная или открытая)",
            "Ангиография контрольная",
            "Продвижение проводников и катетеров",
            "Предварительная ангиография аорты",
            "Введение стент-графта через доставочную систему",
            "Развертывание стент-графта под рентгенконтролем",
            "Моделирование шейки стент-графта (balloon molding)",
            "Контрольная ангиография",
            "Закрытие пунктионных отверстий (устройство или компрессия)"
        ],
        "checklist": [
            "КТ-ангиография с измерениями (neck length, diameter, angulation)",
            "Подбор стент-графта подходящего размера (oversizing 10-20%)",
            "Доступ к бедренным артериям (>7-8F)",
            "Гепаринизация (5000-10000 ЕД)",
            "Контрастная защита (при ХПН)"
        ],
        "risks": [
            {"complication": "Endoleak Type I", "probability": "2-5%", "severity": "high"},
            {"complication": "Endoleak Type II", "probability": "10-25%", "severity": "moderate"},
            {"complication": "Endoleak Type III", "probability": "1-3%", "severity": "high"},
            {"complication": "Миграция стент-графта", "probability": "2-5%", "severity": "high"},
            {"complication": "Тромбоз шунта", "probability": "1-3%", "severity": "high"},
            {"complication": "Повреждение доступных артерий", "probability": "2-5%", "severity": "moderate"},
            {"complication": "Контрастная нефропатия", "probability": "5-10%", "severity": "moderate"}
        ],
        "graft_types": ["Zenith", "Endurant", "Excluder", "Anaconda", "Ovation"],
        "evidence_base": {
            "guidelines": ["ESVS Guidelines 2024"],
            "key_studies": ["DREAM Trial", "OVER Trial", "EVAR-1 Trial"],
            "recommendation_class": "Class I, Level A"
        },
        "surveillance": {
            "1_month": "КТ-ангиография",
            "6_months": "КТ-ангиография",
            "12-months": "КТ-ангиография",
            "annually": "КТ-ангиография или УЗИ"
        }
    },
    
    "tevar": {
        "name": "Торакоэндоваскулярный ремонт аорты (TEVAR)",
        "name_en": "Thoracic Endovascular Aortic Repair",
        "category": "endovascular",
        "indications": [
            "Торакальная аневризма аорты",
            "Синдром Лериша",
            "Травматический разрыв аорты",
            "Слоистая аневризма аорты"
        ],
        "steps": [
            "Пункция бедренной артерии",
            "Аортография",
            "Продвижение проводника через дугу аорты",
            "Позиционирование стент-графта",
            "Развертывание под контролем ТЕЭ и рентгена",
            "Контрольная ангиография"
        ],
        "checklist": [
            "КТ-ангиография грудной и брюшной аорты",
            "Оценка дуги аорты",
            "Доступ к бедренной артерии",
            "ТЕЭ контроль"
        ],
        "risks": [
            {"complication": "Параплегия", "probability": "2-5%", "severity": "extreme"},
            {"complication": "Инсульт", "probability": "2-5%", "severity": "extreme"},
            {"complication": "Endoleak", "probability": "5-15%", "severity": "moderate"},
            {"complication": "Ретроградный разрыв ААА", "probability": "1-2%", "severity": "high"}
        ],
        "graft_types": ["TAG", "Valiant", "TX2", "Conformable Gore"],
        "evidence_base": {
            "guidelines": ["ESVS Guidelines 2024"],
            "key_studies": ["GORE TAG Trial", "VALOR Trial"],
            "recommendation_class": "Class I, Level B"
        }
    },
    
    # ============================================
    # 2. ОПЕРАЦИИ НА СОННЫХ АРТЕРИЯХ (CAROTID)
    # ============================================
    
    "carotid_endarterectomy": {
        "name": "Каротидная эндартерэктомия",
        "name_en": "Carotid Endarterectomy",
        "category": "open_surgery",
        "indications": [
            "Симптоматический стеноз >70% - Class I, Level A",
            "Симптоматический стеноз 50-69% - Class I, Level A (мужчины)",
            "Асимптоматический стеноз >70% при ожидаемой продолжительности жизни >5 лет"
        ],
        "steps": [
            "Разрез вдоль переднего края СКМ на уровне бифуркации",
            "Обнажение общей, внутренней и наружной сонных артерий",
            "Выделение гипоглоссального и блуждающего нервов",
            "Гепаринизация (5000 ЕД в/в)",
            "Пережатие сонных артерий (последовательность: ВСА, НСА, ОСА)",
            "Артериотомия по передней поверхности",
            "Эндартерэктомия бляшки элеватором Пенфилда",
            "Пластика пятна (tacking sutures)",
            "Закрытие артериотомии (первичное или с заплаткой)",
            "Восстановление кровотока",
            "Гемостаз, дренирование"
        ],
        "checklist": [
            "Мониторинг мозговых функций (пациент бодрствует при локальной анестезии)",
            "Транскраниальная допплерография (контроль мозгового кровотока)",
            "Измерение обратного давления в ВСА (stump pressure)",
            "Готовность к шунтированию (при stump pressure <50 мм рт.ст.)",
            "Контроль АД (избегать гипотензии)"
        ],
        "risks": [
            {"complication": "Инсульт", "probability": "2-5%", "severity": "extreme"},
            {"complication": "Краниальные нервные повреждения", "probability": "5-10%", "severity": "moderate"},
            {"complication": "Кровотечение", "probability": "5%", "severity": "moderate"},
            {"complication": "Гипертензия/гипотензия", "probability": "10-20%", "severity": "moderate"},
            {"complication": "Рецидив стеноза", "probability": "5-10% через 5 лет", "severity": "moderate"}
        ],
        "graft_types": ["Заплатка из сапенозной вены", "Заплатка из PTFE", "Первичное зашивание"],
        "evidence_base": {
            "guidelines": ["ESC/ESVS Guidelines 2023", "AHA/ASA Guidelines 2021"],
            "key_studies": ["NASCET", "ECST", "CREST", "ACST-2"],
            "recommendation_class": "Class I, Level A"
        }
    },
    
    "carotid_stenting": {
        "name": "Каротидное стентирование (CAS)",
        "name_en": "Carotid Artery Stenting",
        "category": "endovascular",
        "indications": [
            "Симптоматический стеноз при высоком хирургическом риске",
            "Стеноз после лучевой терапии шеи",
            "Рестеноз после CEA",
            "Стеноз на уровне C2 и выше"
        ],
        "steps": [
            "Пункция бедренной артерии",
            "Аортография, выбор сонной артерии",
            "Введение защитного фильтра дистальнее стеноза",
            "Преддилатация баллоном (при необходимости)",
            "Имплантация стента саморасширяющегося",
            "Постдилатация (при необходимости)",
            "Удаление защитного фильтра",
            "Контрольная ангиография"
        ],
        "checklist": [
            "Антиагрегантная терапия (аспирин + клопидогрель) минимум 5 дней",
            "Защитная система (фильтр или баллон)",
            "Контроль мозгового кровотока",
            "Атропин при брадикардии"
        ],
        "risks": [
            {"complication": "Инсульт", "probability": "4-8%", "severity": "extreme"},
            {"complication": "Брадикардия/асистолия", "probability": "10-20%", "severity": "moderate"},
            {"complication": "Контрастная нефропатия", "probability": "5%", "severity": "moderate"},
            {"complication": "Осложнения доступа", "probability": "3-5%", "severity": "moderate"}
        ],
        "graft_types": ["Стент саморасширяющийся (Precise, Protégé)", "Защитный фильтр (Spider, FilterWire)"],
        "evidence_base": {
            "guidelines": ["ESC/ESVS Guidelines 2023"],
            "key_studies": ["CREST", "SAPPHIRE", "ACT-1"],
            "recommendation_class": "Class IIa, Level B"
        }
    },
    
    "carotid_subclavian_bypass": {
        "name": "Сонно-подключичное шунтирование",
        "name_en": "Carotid-Subclavian Bypass",
        "category": "open_surgery",
        "indications": [
            "Симптоматический стеноз/окклюзия подключичной артерии",
            "Синдром подключичной кражи",
            "Подготовка к TEVAR (для левой подключичной артерии)"
        ],
        "steps": [
            "Разрез над ключицей (подключичный доступ)",
            "Обнажение подключичной артерии",
            "Дополнительный разрез на шее (сонный доступ)",
            "Обнажение общей сонной артерии",
            "Гепаринизация",
            "Формирование анастомоза с подключичной артерией",
            "Прокладка протеза под ключицей",
            "Формирование анастомоза с сонной артерией",
            "Восстановление кровотока"
        ],
        "checklist": [
            "Антибиотикопрофилактика",
            "Гепаринизация",
            "Контроль пульса на верхней конечности"
        ],
        "risks": [
            {"complication": "Повреждение плевры (пневмоторакс)", "probability": "5-10%", "severity": "moderate"},
            {"complication": "Повреждение грудного протока (хилоторакс)", "probability": "1-3%", "severity": "moderate"},
            {"complication": "Тромбоз шунта", "probability": "3-5%", "severity": "high"},
            {"complication": "Синдром верхней полой вены", "probability": "<1%", "severity": "high"}
        ],
        "graft_types": ["Трубчатый PTFE 6-8 мм", "Сапенозная вена"],
        "evidence_base": {
            "guidelines": ["ESVS Guidelines 2023"],
            "recommendation_class": "Class IIa, Level B"
        }
    },
    
    # ============================================
    # 3. ОПЕРАЦИИ НА АРТЕРИЯХ НИЖНИХ КОНЕЧНОСТЕЙ
    # ============================================
    
    "femoropopliteal_bypass": {
        "name": "Бедренно-подколенное шунтирование",
        "name_en": "Femoropopliteal Bypass",
        "category": "open_surgery",
        "indications": [
            "TASC C и D окклюзии поверхностной бедренной артерии",
            "Неудача эндоваскулярного лечения",
            "Критическая ишемия нижних конечностей"
        ],
        "steps": [
            "Разрез в паховой области (доступ к бедренной артерии)",
            "Разрез в подколенной ямке (доступ к подколенной артерии)",
            "Обнажение артерий",
            "Подготовка трансплантата (вена/протез)",
            "Гепаринизация (5000 ЕД)",
            "Формирование проксимального анастомоза",
            "Туннелирование трансплантата",
            "Формирование дистального анастомоза",
            "Восстановление кровотока",
            "Ангиография контрольная (при необходимости)",
            "Гемостаз, ушивание ран"
        ],
        "checklist": [
            "Маркировка вены УЗИ до операции",
            "Оценка диаметра вены (>4 мм)",
            "Гепаринизация перед пережатием",
            "Контроль пульсации на стопе (до/после)"
        ],
        "risks": [
            {"complication": "Тромбоз шунта", "probability": "10-20% в первый год", "severity": "high"},
            {"complication": "Инфекция раны", "probability": "5-10%", "severity": "moderate"},
            {"complication": "Лимфная фистула в паху", "probability": "5-10%", "severity": "moderate"},
            {"complication": "Раневая инфекция", "probability": "3-5%", "severity": "moderate"},
            {"complication": "Контрактура сгибателей", "probability": "2-5%", "severity": "moderate"}
        ],
        "graft_types": [
            "Великая сапенозная вена (реверсивная/инситу)",
            "Малая сапенозная вена",
            "ePTFE 6-8 мм",
            "Биологический протез"
        ],
        "evidence_base": {
            "guidelines": ["ESVS Guidelines 2024", "TASC II Classification"],
            "key_studies": ["Bypass vs. Angioplasty trials", "Zilver PTX Trial"],
            "recommendation_class": "Class I, Level A"
        }
    },
    
    "femoral_endarterectomy": {
        "name": "Эндартерэктомия бедренной артерии",
        "name_en": "Femoral Endarterectomy",
        "category": "open_surgery",
        "indications": [
            "Стеноз/окклюзия общей бедренной артерии",
            "Бифуркационное поражение",
            "Подготовка к шунтированию"
        ],
        "steps": [
            "Разрез по Скарпа в паховой области",
            "Обнажение общей, поверхностной и глубокой бедренных артерий",
            "Гепаринизация (5000 ЕД)",
            "Пережатие артерий",
            "Артериотомия",
            "Эндартерэктомия бляшки",
            "Профундопластика (при необходимости)",
            "Закрытие артериотомии заплаткой",
            "Восстановление кровотока"
        ],
        "checklist": [
            "Антибиотикопрофилактика",
            "Гепаринизация",
            "Контроль пульсации на конечности"
        ],
        "risks": [
            {"complication": "Тромбоз", "probability": "3-5%", "severity": "high"},
            {"complication": "Рецидив стеноза", "probability": "10-20%", "severity": "moderate"},
            {"complication": "Ложная аневризма", "probability": "2-5%", "severity": "moderate"},
            {"complication": "Лимфная фистула", "probability": "5-10%", "severity": "moderate"}
        ],
        "graft_types": ["Заплатка из сапенозной вены", "Заплатка из PTFE"],
        "evidence_base": {
            "guidelines": ["ESVS Guidelines 2024"],
            "recommendation_class": "Class I, Level A"
        }
    },
    
    "femoral_thrombectomy": {
        "name": "Тромбэктомия Фогарти из бедренной артерии",
        "name_en": "Femoral Thrombectomy (Fogarty)",
        "category": "open_surgery",
        "indications": [
            "Острый артериальный тромбоз",
            "Эмболия артерии",
            "Острая ишемия конечности"
        ],
        "steps": [
            "Разрез по Скарпа",
            "Обнажение общей бедренной артерии",
            "Контроль проксимально и дистально",
            "Гепаринизация (5000 ЕД)",
            "Артериотомия поперечная",
            "Продвижение катетера Фогарти проксимально и дистально",
            "Извлечение тромба",
            "Промывание артерии гепаринизированным раствором",
            "Ангиография контрольная",
            "Закрытие артериотомии",
            "Восстановление кровотока"
        ],
        "checklist": [
            "Гепаринизация (5000-10000 ЕД)",
            "Контроль АКТ (целевое 200-250 сек)",
            "Наличие катетеров Фогарти разных размеров (3-6F)",
            "Готовность к эндартерэктомии",
            "Фиксация конечности (предотвращение эмболии)"
        ],
        "risks": [
            {"complication": "Дистальная эмболизация", "probability": "5-10%", "severity": "high"},
            {"complication": "Рецидив тромбоза", "probability": "10-20%", "severity": "high"},
            {"complication": "Кровотечение", "probability": "5%", "severity": "moderate"},
            {"complication": "Ложная аневризма", "probability": "2-3%", "severity": "moderate"},
            {"complication": "Острая ишемия конечности", "probability": "5-10%", "severity": "extreme"}
        ],
        "graft_types": ["Катетер Фогарти", "Заплатка при необходимости"],
        "evidence_base": {
            "guidelines": ["ESVS Guidelines 2024"],
            "recommendation_class": "Class I, Level A"
        }
    },
    
    "axillofemoral_bypass": {
        "name": "Аксилло-феморальное шунтирование",
        "name_en": "Axillofemoral Bypass",
        "category": "open_surgery",
        "indications": [
            "Инфекция аортобифеморального шунта",
            "Отказ от лапаротомии",
            "Аортальная окклюзия при высоком риске"
        ],
        "steps": [
            "Разрез в подмышечной области (доступ к подмышечной артерии)",
            "Разрез в паховой области (доступ к бедренной артерии)",
            "Обнажение артерий",
            "Гепаринизация",
            "Формирование проксимального анастомоза",
            "Туннелирование протеза по боковой поверхности туловища",
            "Формирование дистального анастомоза",
            "Восстановление кровотока"
        ],
        "checklist": [
            "Антибиотикопрофилактика",
            "Гепаринизация",
            "Контроль пульсации на конечности"
        ],
        "risks": [
            {"complication": "Тромбоз шунта", "probability": "20-30%", "severity": "high"},
            {"complication": "Инфекция", "probability": "5-10%", "severity": "high"},
            {"complication": "Повреждение плечевого сплетения", "probability": "1-2%", "severity": "high"}
        ],
        "graft_types": ["ePTFE 8-10 мм", "Dacron 8-10 мм"],
        "evidence_base": {
            "guidelines": ["ESVS Guidelines 2024"],
            "recommendation_class": "Class IIb, Level B"
        }
    },
    
    "tibial_bypass": {
        "name": "Дистальное шунтирование на тибиальные артерии",
        "name_en": "Tibial Bypass",
        "category": "open_surgery",
        "indications": [
            "Критическая ишемия нижних конечностей (Rutherford 5-6)",
            "Непроходимость подколенной артерии",
            "Необходимость спасения конечности"
        ],
        "steps": [
            "Разрез в паховой области",
            "Разрез на голени (доступ к тибиальной артерии)",
            "Обнажение артерий",
            "Подготовка вены (великая/малая сапенозная)",
            "Гепаринизация",
            "Формирование проксимального анастомоза",
            "Туннелирование вены",
            "Формирование дистального анастомоза",
            "Восстановление кровотока",
            "Гемостаз"
        ],
        "checklist": [
            "Обязательно использование вены",
            "Гепаринизация",
            "Контроль пульса на стопе",
            "Интраоперационная ангиография"
        ],
        "risks": [
            {"complication": "Тромбоз шунта", "probability": "20-30% в первый год", "severity": "high"},
            {"complication": "Инфекция раны", "probability": "10-15%", "severity": "moderate"},
            {"complication": "Недостаточность вены", "probability": "5-10%", "severity": "moderate"}
        ],
        "graft_types": ["Великая сапенозная вена", "Малая сапенозная вена"],
        "evidence_base": {
            "guidelines": ["ESVS Guidelines 2024"],
            "recommendation_class": "Class I, Level B"
        }
    },
    
    # ============================================
    # 4. ВЕНОЗНЫЕ ОПЕРАЦИИ (VENOUS SURGERY)
    # ============================================
    
    "varicose_phlebectomy": {
        "name": "Кроссэктомия и флебэктомия",
        "name_en": "Saphenofemoral Junction Ligation and Phlebectomy",
        "category": "open_surgery",
        "indications": [
            "Варикозная болезнь с рефлюксом в БПВ",
            "Варикозные узлы C2-C6 по CEAP",
            "Неэффективность консервативного лечения"
        ],
        "steps": [
            "ДУЗ-сканирование и маркировка вен",
            "Разрез в паховой области (2-3 см)",
            "Обнажение сапено-феморального соустья (СФС)",
            "Изоляция и перевязка всех притоков",
            "Двойная перевязка большой подкожной вены (БПВ)",
            "Пересечение БПВ",
            "Разрезы по ходу варикозных вен (2-3 мм)",
            "Выделение вен крючком Мюллера",
            "Оттяжка и удаление варикозных сегментов",
            "Компрессионное бинтование"
        ],
        "checklist": [
            "ДУЗ-сканирование перед операцией (mapping)",
            "Маркировка вен на коже",
            "Тренделенбург положение",
            "Компрессионный трикотаж после операции",
            "Антибиотикопрофилактика (при необходимости)"
        ],
        "risks": [
            {"complication": "Гематома", "probability": "5-10%", "severity": "moderate"},
            {"complication": "Инфекция раны", "probability": "1-3%", "severity": "moderate"},
            {"complication": "Тромбофлебит поверхностных вен", "probability": "5-10%", "severity": "moderate"},
            {"complication": "Парестезии", "probability": "5-10%", "severity": "low"},
            {"complication": "Рецидив варикоза", "probability": "20-30% через 5 лет", "severity": "moderate"}
        ],
        "graft_types": [],
        "evidence_base": {
            "guidelines": ["Российские клинические рекомендации 2024", "NICE Guidelines"],
            "key_studies": ["CLASS Trial"],
            "recommendation_class": "Class I, Level A"
        }
    },
    
    "varicose_laser_ablation": {
        "name": "Эндовенозная лазерная абляция (EVLA)",
        "name_en": "Endovenous Laser Ablation",
        "category": "endovascular",
        "indications": [
            "Рефлюкс в БПВ с диаметром >5 мм",
            "Варикозная болезнь C2-C6",
            "Пациенты с контраиндикациями к хирургии"
        ],
        "steps": [
            "ДУЗ-сканирование и маркировка",
            "Пункция вены (обычно у голеностопа)",
            "Введение проводника",
            "Введение лазерного световода",
            "Позиционирование световода у СФС",
            "Введение тумесцентной анестезии",
            "Лазерная абляция при оттягивании световода",
            "Контрольное УЗИ",
            "Компрессионное бинтование"
        ],
        "checklist": [
            "ДУЗ-сканирование (подтверждение рефлюкса)",
            "Мощность лазера (обычно 1470 нм, 8-12 Вт)",
            "Скорость оттягивания (1-2 мм/сек)",
            "Тумесцентная анестезия (вокруг вены)",
            "Компрессионный трикотаж после"
        ],
        "risks": [
            {"complication": "Боль в первые дни (флебит)", "probability": "10-20%", "severity": "moderate"},
            {"complication": "Кожные ожоги", "probability": "1-3%", "severity": "moderate"},
            {"complication": "Парестезии", "probability": "5-10%", "severity": "low"},
            {"complication": "Тромбоз глубоких вен", "probability": "<1%", "severity": "high"},
            {"complication": "Рецидив", "probability": "10-20%", "severity": "moderate"}
        ],
        "graft_types": ["Лазерный световод 1470 нм", "Лазерный световод 980 нм"],
        "evidence_base": {
            "guidelines": ["Российские клинические рекомендации 2024"],
            "key_studies": ["eSCIN Study", "CLASS Trial"],
            "recommendation_class": "Class I, Level A"
        }
    },
    
    "varicose_radiofrequency_ablation": {
        "name": "Радиочастотная абляция вен (RFA)",
        "name_en": "Radiofrequency Ablation",
        "category": "endovascular",
        "indications": [
            "Рефлюкс в БПВ",
            "Варикозная болезнь C2-C6"
        ],
        "steps": [
            "ДУЗ-сканирование и маркировка",
            "Пункция вены",
            "Введение радиочастотного катетера",
            "Позиционирование катетера у СФС",
            "Введение тумесцентной анестезии",
            "Радиочастотная абляция при оттягивании катетера",
            "Контрольное УЗИ",
            "Компрессионное бинтование"
        ],
        "checklist": [
            "ДУЗ-сканирование",
            "Температура катетера (120°C)",
            "Тумесцентная анестезия",
            "Компрессионный трикотаж"
        ],
        "risks": [
            {"complication": "Боль в первые дни", "probability": "10-15%", "severity": "moderate"},
            {"complication": "Кожные ожоги", "probability": "1-2%", "severity": "moderate"},
            {"complication": "Парестезии", "probability": "5-10%", "severity": "low"},
            {"complication": "Тромбоз глубоких вен", "probability": "<1%", "severity": "high"},
            {"complication": "Рецидив", "probability": "10-20%", "severity": "moderate"}
        ],
        "graft_types": ["Радиочастотный катетер ClosureFast"],
        "evidence_base": {
            "guidelines": ["NICE Guidelines"],
            "key_studies": [" ClosureFAST Study"],
            "recommendation_class": "Class I, Level A"
        }
    },
    
    "deep_vein_thrombosis_surgery": {
        "name": "Тромбэктомия из глубоких вен",
        "name_en": "Deep Vein Thrombectomy",
        "category": "open_surgery",
        "indications": [
            "Флегмазия cerulea dolens",
            "Острый илеофеморальный тромбоз (<14 дней)",
            "Контраиндикации к тромболизу"
        ],
        "steps": [
            "Разрез в паховой области",
            "Обнажение общей бедренной вены",
            "Гепаринизация",
            "Венотомия",
            "Тромбэктомия катетером Фогарти",
            "Промывание вены",
            "Закрытие венотомии",
            "Фасциотомия (при компартмент-синдроме)"
        ],
        "checklist": [
            "Гепаринизация",
            "Контроль АКТ",
            "Готовность к фасциотомии",
            "Послеоперационная антикоагуляция"
        ],
        "risks": [
            {"complication": "Кровотечение", "probability": "10-20%", "severity": "high"},
            {"complication": "Рецидив тромбоза", "probability": "20-30%", "severity": "high"},
            {"complication": "Лимфная фистула", "probability": "5-10%", "severity": "moderate"},
            {"complication": "Посттромботический синдром", "probability": "30-50%", "severity": "moderate"}
        ],
        "graft_types": [],
        "evidence_base": {
            "guidelines": ["ESVS Guidelines 2021"],
            "key_studies": ["CaVenT Trial"],
            "recommendation_class": "Class IIa, Level B"
        }
    },
    
    "ivc_filter_placement": {
        "name": "Имплантация кава-фильтра",
        "name_en": "Inferior Vena Cava Filter Placement",
        "category": "endovascular",
        "indications": [
            "ТЭЛА при противопоказаниях к антикоагуляции",
            "Рецидив ТЭЛА на фоне адекватной антикоагуляции",
            "Тяжелая травма с высоким риском ТЭЛА"
        ],
        "steps": [
            "Пункция внутренней яремной или бедренной вены",
            "Венография контрольная",
            "Определение уровня размещения фильтра (ниже почечных вен)",
            "Введение доставочной системы",
            "Развертывание фильтра",
            "Контрольная венография",
            "Удаление системы, гемостаз"
        ],
        "checklist": [
            "КТ-ангиография или венография до операции",
            "Уровень размещения (ниже почечных вен)",
            "Тип фильтра (временный/перманентный)",
            "Антикоагуляция после имплантации (при отсутствии противопоказаний)"
        ],
        "risks": [
            {"complication": "Миграция фильтра", "probability": "1-3%", "severity": "high"},
            {"complication": "Перфорация стенки вены", "probability": "1-2%", "severity": "high"},
            {"complication": "Тромбоз вены на уровне фильтра", "probability": "5-10%", "severity": "high"},
            {"complication": "Рецидив ТЭЛА", "probability": "1-3%", "severity": "high"}
        ],
        "graft_types": ["Кава-фильтр (OptEase, Denali, Option)"],
        "evidence_base": {
            "guidelines": ["SIR Guidelines"],
            "recommendation_class": "Class IIa, Level B"
        }
    },
    
    # ============================================
    # 5. ДИАЛИЗНЫЙ ДОСТУП (DIALYSIS ACCESS)
    # ============================================
    
    "av_fistula_creation": {
        "name": "Формирование артериовенозной фистулы (Cimino)",
        "name_en": "Arteriovenous Fistula Creation",
        "category": "open_surgery",
        "indications": [
            "Хроническая почечная недостаточность (терминальная стадия)",
            "Необходимость программного гемодиализа"
        ],
        "anatomical_criteria": [
            "Диаметр артерии >2 мм",
            "Диаметр вены >2.5 мм",
            "Отсутствие стеноза вен"
        ],
        "steps": [
            "ДУЗ-сканирование артерий и вен предплечья",
            "Разрез на предплечье (2-3 см)",
            "Обнажение лучевой артерии и вены",
            "Гепаринизация (небольшая доза)",
            "Формирование терминально-бокового анастомоза",
            "Контроль пульсации на вене",
            "Гемостаз, ушивание раны"
        ],
        "checklist": [
            "ДУЗ-сканирование (Allen test, диаметр вены >2.5 мм)",
            "Артериальный диаметр >2 мм",
            "Отсутствие стеноза вен",
            "Антибиотикопрофилактика",
            "Контроль шума на фистуле после операции"
        ],
        "risks": [
            {"complication": "Ранний тромбоз", "probability": "5-10%", "severity": "high"},
            {"complication": "Недостаточная зрелость фистулы", "probability": "10-20%", "severity": "moderate"},
            {"complication": "Инфекция", "probability": "2-5%", "severity": "moderate"},
            {"complication": "Венозная гипертензия", "probability": "5-10%", "severity": "moderate"},
            {"complication": "Синдром украденной крови", "probability": "5-10%", "severity": "moderate"}
        ],
        "graft_types": ["Терминально-боковой анастомоз", "Боковой анастомоз"],
        "evidence_base": {
            "guidelines": ["NKF-KDOQI Guidelines", "ESVS Guidelines 2018"],
            "key_studies": ["DOPPS Study"],
            "recommendation_class": "Class I, Level A"
        }
    },
    
    "av_graft_creation": {
        "name": "Формирование АВ-шунта с протезом",
        "name_en": "AV Graft Creation",
        "category": "open_surgery",
        "indications": [
            "Невозможность создания нативной фистулы",
            "Недостаточные сосуды для фистулы"
        ],
        "steps": [
            "Разрез в паховой области или на предплечье",
            "Обнажение артерии и вены",
            "Туннелирование протеза подкожно",
            "Формирование артериального анастомоза",
            "Формирование венозного анастомоза",
            "Контроль пульсации",
            "Гемостаз, ушивание"
        ],
        "checklist": [
            "Невозможность создания нативной фистулы",
            "Антибиотикопрофилактика",
            "Контроль шума на шунте"
        ],
        "risks": [
            {"complication": "Тромбоз", "probability": "20-30%", "severity": "high"},
            {"complication": "Инфекция", "probability": "5-10%", "severity": "high"},
            {"complication": "Псевдоаневризма шунта", "probability": "5-10%", "severity": "moderate"},
            {"complication": "Синдром украденной крови", "probability": "10-15%", "severity": "moderate"}
        ],
        "graft_types": ["Протез PTFE 6 мм", "Биологический протез"],
        "evidence_base": {
            "guidelines": ["NKF-KDOQI Guidelines"],
            "recommendation_class": "Class IIa, Level B"
        }
    },
    
    "fistula_thrombectomy": {
        "name": "Тромбэктомия из АВ-фистулы",
        "name_en": "Fistula Thrombectomy",
        "category": "open_surgery",
        "indications": [
            "Тромбоз АВ-фистулы",
            "Невозможность проведения эндоваскулярной тромбэктомии"
        ],
        "steps": [
            "Разрез над фистулой",
            "Обнажение артериализованной вены",
            "Контроль проксимально и дистально",
            "Венотомия",
            "Тромбэктомия катетером Фогарти или форцепсом",
            "Ангиография контрольная (при необходимости)",
            "Ревизия анастомоза (при необходимости)",
            "Закрытие венотомии",
            "Восстановление кровотока"
        ],
        "checklist": [
            "Локальная анестезия или седация",
            "Гепаринизация",
            "Поиск причины тромбоза (стеноз)"
        ],
        "risks": [
            {"complication": "Рецидив тромбоза", "probability": "20-30%", "severity": "high"},
            {"complication": "Кровотечение", "probability": "5-10%", "severity": "moderate"},
            {"complication": "Инфекция", "probability": "2-5%", "severity": "moderate"},
            {"complication": "Повреждение фистулы", "probability": "5-10%", "severity": "high"}
        ],
        "graft_types": ["Катетер Фогарти", "Баллон для ангиопластики"],
        "evidence_base": {
            "guidelines": ["NKF-KDOQI Guidelines"],
            "recommendation_class": "Class IIa, Level B"
        }
    },
    
    # ============================================
    # 6. ЭНДОВАСКУЛЯРНЫЕ ОПЕРАЦИИ (ENDOVASCULAR)
    # ============================================
    
    "percutaneous_transluminal_angioplasty": {
        "name": "Перкутанная транслюминальная ангиопластика (PTA)",
        "name_en": "Percutaneous Transluminal Angioplasty",
        "category": "endovascular",
        "indications": [
            "Стеноз артерии >50% с симптомами",
            "TASC A и B поражения",
            "Клаудикация с ограничением функциональности"
        ],
        "steps": [
            "Пункция артерии (бедренная/лучевая)",
            "Введение проводника и катетера",
            "Ангиография (определение стеноза)",
            "Продвижение баллонного катетера к стенозу",
            "Дилатация баллоном (2-3 цикла)",
            "Контрольная ангиография",
            "Удаление катетера, гемостаз"
        ],
        "checklist": [
            "Антиагрегантная терапия (аспирин)",
            "Гепаринизация (3000-5000 ЕД)",
            "Выбор баллона (диаметр соответствует просвету артерии)",
            "Контроль АКТ"
        ],
        "risks": [
            {"complication": "Дистальная эмболизация", "probability": "2-5%", "severity": "high"},
            {"complication": "Разрыв артерии", "probability": "1-3%", "severity": "high"},
            {"complication": "Тромбоз", "probability": "2-5%", "severity": "high"},
            {"complication": "Контрастная нефропатия", "probability": "5-10%", "severity": "moderate"},
            {"complication": "Рецидив стеноза", "probability": "30-50% через год", "severity": "moderate"}
        ],
        "graft_types": ["Баллонный катетер"],
        "evidence_base": {
            "guidelines": ["TASC II Classification"],
            "key_studies": ["Zilver PTX Trial"],
            "recommendation_class": "Class I, Level A"
        }
    },
    
    "arterial_stenting": {
        "name": "Стентирование артерии",
        "name_en": "Arterial Stenting",
        "category": "endovascular",
        "indications": [
            "Остаточный стеноз >30% после PTA",
            "Дизекция после PTA",
            "TASC C и D поражения (в сочетании с PTA)"
        ],
        "steps": [
            "Пункция артерии",
            "Введение проводника и катетера",
            "Ангиография",
            "Преддилатация (при необходимости)",
            "Имплантация стента",
            "Постдилатация (при необходимости)",
            "Контрольная ангиография",
            "Удаление катетера, гемостаз"
        ],
        "checklist": [
            "Двойная антиагрегация (аспирин + клопидогрель) минимум 1 месяц",
            "Гепаринизация",
            "Выбор стента (диаметр, длина, тип)",
            "Контроль АКТ"
        ],
        "risks": [
            {"complication": "Дистальная эмболизация", "probability": "2-5%", "severity": "high"},
            {"complication": "Тромбоз стента", "probability": "2-5%", "severity": "high"},
            {"complication": "Рестеноз (in-stent restenosis)", "probability": "20-40%", "severity": "moderate"},
            {"complication": "Разрыв артерии", "probability": "1-2%", "severity": "high"},
            {"complication": "Контрастная нефропатия", "probability": "5-10%", "severity": "moderate"}
        ],
        "graft_types": ["Стент саморасширяющийся", "Баллон-расширяемый стент", "Лекарственный стент"],
        "evidence_base": {
            "guidelines": ["TASC II Classification"],
            "key_studies": ["Zilver PTX Trial"],
            "recommendation_class": "Class I, Level A"
        }
    },
    
    "thrombolysis": {
        "name": "Регионарный тромболиз",
        "name_en": "Regional Thrombolysis",
        "category": "endovascular",
        "indications": [
            "Острый артериальный тромбоз (<14 дней)",
            "Острый тромбоз шунта",
            "Эмболия артерии"
        ],
        "contraindications": [
            "Активное кровотечение",
            "Инсульт <3 месяцев",
            "Нейрохирургическая операция <3 месяцев",
            "Тяжелая гипертензия (>180/110)"
        ],
        "steps": [
            "Пункция артерии или вены",
            "Введение катетера в зону тромба",
            "Инфузия тромболитика (активированный через катетер)",
            "Мониторинг (АПТВ, фибриноген)",
            "Контрольная ангиография через 12-24 часа",
            "При необходимости - механическая тромбэктомия",
            "Удаление катетера"
        ],
        "checklist": [
            "Отсутствие противопоказаний (кровотечение, инсульт <3 мес)",
            "Контроль АПТВ (целевое 1.5-2.5x нормы)",
            "Контроль фибриногена (>1.5 г/л)",
            "ICU мониторинг",
            "Готовность к экстренной операции"
        ],
        "risks": [
            {"complication": "Кровотечение", "probability": "10-20%", "severity": "high"},
            {"complication": "Интракраниальное кровотечение", "probability": "1-2%", "severity": "extreme"},
            {"complication": "Рецидив тромбоза", "probability": "10-20%", "severity": "high"},
            {"complication": "Эмболия", "probability": "5-10%", "severity": "high"}
        ],
        "graft_types": ["Алтеплаза (Actilyse)", "Урокиназа", "Тенектеплаза"],
        "evidence_base": {
            "guidelines": ["ESVS Guidelines 2024"],
            "key_studies": ["STILE Trial", "TOPAS Trial"],
            "recommendation_class": "Class IIa, Level B"
        }
    },
    
    # ============================================
    # 7. РЕДКИЕ И СПЕЦИАЛЬНЫЕ ОПЕРАЦИИ
    # ============================================
    
    "mycotic_aneurysm_resection": {
        "name": "Резекция микотической аневризмы с экстраанатомическим шунтированием",
        "name_en": "Mycotic Aneurysm Resection with Extra-anatomic Bypass",
        "category": "open_surgery",
        "indications": [
            "Микотическая аневризма любой локализации",
            "Инфекционное поражение сосудистой стенки"
        ],
        "special_considerations": [
            "Эндоваскулярное лечение противопоказано",
            "Обязательна эволютная реконструкция",
            "Длительная антибиотикотерапия (6-12 недель)"
        ],
        "steps": [
            "Экстраанатомическое шунтирование (аксилло-бедренное)",
            "Резекция инфицированной аневризмы",
            "Удаление инфицированного протеза (если есть)",
            "Дренирование",
            "Длительная антибиотикотерапия"
        ],
        "checklist": [
            "Гемокультуры до операции",
            "Консультация инфекциониста",
            "Выбор антибиотиков по чувствительности",
            "Планирование 6-12 недель терапии"
        ],
        "risks": [
            {"complication": "Инфекция шунта", "probability": "10-20%", "severity": "extreme"},
            {"complication": "Тромбоз", "probability": "10-20%", "severity": "high"},
            {"complication": "Кровотечение", "probability": "10-20%", "severity": "high"},
            {"complication": "Летальный исход", "probability": "20-40%", "severity": "extreme"}
        ],
        "graft_types": ["ePTFE (вне зоны инфекции)", "Сапенозная вена"],
        "evidence_base": {
            "guidelines": ["ESVS Guidelines 2024"],
            "recommendation_class": "Class I, Level C"
        }
    },
    
    "inflammatory_aaa_resection": {
        "name": "Резекция воспалительной ААА",
        "name_en": "Inflammatory AAA Resection",
        "category": "open_surgery",
        "indications": [
            "Воспалительная аневризма брюшной аорты",
            "Симптоматическая воспалительная ААА"
        ],
        "special_considerations": [
            "Предоперационные кортикостероиды (2-4 недели)",
            "Осторожная мобилизация",
            "Риск повреждения мочеточников"
        ],
        "steps": [
            "Срединная лапаротомия",
            "Осторожная мобилизация (плотные спайки)",
            "Идентификация мочеточников",
            "Резекция аневризмы",
            "Имплантация протеза",
            "Дренирование"
        ],
        "checklist": [
            "Кортикостероиды за 2-4 недели",
            "Стентирование мочеточников (при необходимости)",
            "МРТ для оценки ретроперитонеального фиброза"
        ],
        "risks": [
            {"complication": "Повреждение мочеточника", "probability": "10-20%", "severity": "high"},
            {"complication": "Рецидив фиброза", "probability": "20-30%", "severity": "moderate"},
            {"complication": "Почечная недостаточность", "probability": "15-25%", "severity": "high"}
        ],
        "graft_types": ["Dacron", "ePTFE"],
        "evidence_base": {
            "guidelines": ["ESVS Guidelines 2024"],
            "recommendation_class": "Class IIa, Level B"
        }
    },
}


class ProtocolService:
    """Service for generating operation protocols with evidence-based medicine"""
    
    def __init__(self):
        self.templates = PROTOCOL_TEMPLATES
        self.pdf_dir = Path(settings.PROCESSED_DIR) / "protocols"
        self.pdf_dir.mkdir(parents=True, exist_ok=True)
    
    def get_available_protocols(self) -> List[Dict[str, str]]:
        """Get list of available protocol types"""
        return [
            {
                "id": key,
                "name": template["name"],
                "name_en": template["name_en"],
                "category": template["category"]
            }
            for key, template in self.templates.items()
        ]
    
    def get_protocols_by_category(self, category: str) -> List[Dict[str, str]]:
        """Get protocols by category"""
        return [
            {
                "id": key,
                "name": template["name"],
                "name_en": template["name_en"]
            }
            for key, template in self.templates.items()
            if template["category"] == category
        ]
    
    def get_categories(self) -> List[Dict[str, str]]:
        """Get all available categories"""
        categories = set()
        for template in self.templates.values():
            categories.add(template["category"])
        
        category_names = {
            "open_surgery": "Открытые операции",
            "endovascular": "Эндоваскулярные операции",
            "hybrid": "Гибридные операции"
        }
        
        return [
            {"id": cat, "name": category_names.get(cat, cat)}
            for cat in sorted(categories)
        ]
    
    def generate_protocol(
        self,
        protocol_type: str,
        patient_data: Dict[str, Any],
        measurements: Dict[str, Any],
        surgeon_name: str,
        notes: Optional[str] = None
    ) -> Dict[str, Any]:
        """Generate operation protocol based on template and measurements"""
        
        if protocol_type not in self.templates:
            raise ValueError(f"Unknown protocol type: {protocol_type}")
        
        template = self.templates[protocol_type]
        
        # Auto-fill recommendations based on measurements
        recommendations = self._generate_recommendations(protocol_type, measurements)
        
        protocol = {
            "protocol_type": protocol_type,
            "title": template["name"],
            "generated_at": datetime.now().isoformat(),
            "surgeon": surgeon_name,
            "patient": patient_data,
            "measurements": measurements,
            "preoperative_plan": {
                "indications": self._generate_indications(protocol_type, measurements),
                "contraindications": template.get("contraindications", []),
                "recommended_approach": recommendations.get("approach", ""),
                "graft_recommendation": recommendations.get("graft", ""),
                "estimated_duration": recommendations.get("duration", "2-3 часа"),
            },
            "operation_steps": template["steps"],
            "checklist": template["checklist"],
            "risks": template["risks"],
            "graft_types": template.get("graft_types", []),
            "evidence_base": template.get("evidence_base", {}),
            "surgeon_notes": notes or "",
            "references": [
                "ESVS Guidelines 2024 (160 рекомендаций)",
                "SVS Practice Guidelines 2023",
                "ACC/AHA Guidelines 2024",
                "Российские клинические рекомендации 2024"
            ]
        }
        
        # Add special considerations if present
        if "special_considerations" in template:
            protocol["special_considerations"] = template["special_considerations"]
        
        if "anatomical_criteria" in template:
            protocol["anatomical_criteria"] = template["anatomical_criteria"]
        
        if "surveillance" in template:
            protocol["surveillance_plan"] = template["surveillance"]
        
        return protocol
    
    def _generate_recommendations(
        self,
        protocol_type: str,
        measurements: Dict[str, Any]
    ) -> Dict[str, str]:
        """Generate recommendations based on measurements with ESVS 2024 criteria"""
        
        recommendations = {}
        
        # Aortic operations
        if protocol_type in ["aortic_resection", "evar"]:
            aorta_diameter = measurements.get("aorta", {}).get("diameter_max", 0)
            gender = measurements.get("patient", {}).get("gender", "male")
            
            # ESVS 2024 thresholds
            threshold = 55 if gender == "male" else 50
            
            if aorta_diameter > threshold:
                recommendations["approach"] = f"Открытая резекция или EVAR (аневризма >{threshold} мм - показание к операции)"
                recommendations["graft"] = "Трубчатый Dacron 20-24 мм или стент-графт"
                recommendations["duration"] = "2.5-4 часа"
                recommendations["esvs_class"] = "Class I, Level A"
            elif aorta_diameter > 45:
                recommendations["approach"] = "Открытая резекция или EVAR (при подходящей анатомии)"
                recommendations["graft"] = "Трубчатый Dacron 18-22 мм или стент-графт"
                recommendations["duration"] = "2.5-3.5 часа"
                recommendations["esvs_class"] = "Class IIa, Level B"
            else:
                recommendations["approach"] = "Наблюдение (ежегодное КТ)"
                recommendations["graft"] = "Не требуется"
                recommendations["duration"] = "Н/П"
                recommendations["esvs_class"] = "Class I, Level A"
            
            # Check EVAR anatomical criteria
            neck_length = measurements.get("aorta", {}).get("neck_length_mm", 0)
            neck_angle = measurements.get("aorta", {}).get("neck_angulation", 0)
            
            if neck_length < 10 or neck_angle > 60:
                recommendations["evar_suitable"] = False
                recommendations["evar_contraindication"] = "Неподходящая анатомия для EVAR"
            else:
                recommendations["evar_suitable"] = True
        
        # Carotid operations
        elif protocol_type == "carotid_endarterectomy":
            stenosis_percent = measurements.get("stenosis_percent", 0)
            symptomatic = measurements.get("symptomatic", False)
            
            if stenosis_percent > 70 and symptomatic:
                recommendations["approach"] = "Классическая эндартерэктомия с возможностью шунтирования"
                recommendations["graft"] = "Заплатка из сапенозной вены или PTFE"
                recommendations["duration"] = "2-2.5 часа"
                recommendations["esvs_class"] = "Class I, Level A"
            elif stenosis_percent > 50 and symptomatic:
                recommendations["approach"] = "Эндартерэктомия или стентирование (при высоком хирургическом риске)"
                recommendations["graft"] = "Первичное зашивание или заплатка"
                recommendations["duration"] = "1.5-2 часа"
                recommendations["esvs_class"] = "Class I, Level A"
            elif stenosis_percent > 60 and not symptomatic:
                recommendations["approach"] = "Эндартерэктомия (при ожидаемой продолжительности жизни >5 лет)"
                recommendations["graft"] = "Первичное зашивание или заплатка"
                recommendations["duration"] = "1.5-2 часа"
                recommendations["esvs_class"] = "Class IIa, Level A"
            else:
                recommendations["approach"] = "Консервативная терапия + наблюдение"
                recommendations["graft"] = "Не требуется"
                recommendations["duration"] = "Н/П"
        
        # Femoropopliteal bypass
        elif protocol_type == "femoropopliteal_bypass":
            occlusion_length = measurements.get("occlusion_length", 0)
            rutherford_class = measurements.get("rutherford_class", 3)
            
            if occlusion_length > 200 or rutherford_class >= 5:
                recommendations["approach"] = "Бедренно-подколенное шунтирование с веной"
                recommendations["graft"] = "Великая сапенозная вена (обязательно)"
                recommendations["duration"] = "3-4 часа"
                recommendations["esvs_class"] = "Class I, Level A"
            else:
                recommendations["approach"] = "Бедренно-подколенное шунтирование"
                recommendations["graft"] = "Великая сапенозная вена или PTFE"
                recommendations["duration"] = "2-3 часа"
                recommendations["esvs_class"] = "Class I, Level A"
        
        # Varicose veins
        elif protocol_type in ["varicose_phlebectomy", "varicose_laser_ablation", "varicose_radiofrequency_ablation"]:
            recommendations["approach"] = "Минимально инвазивное вмешательство"
            recommendations["graft"] = "Не требуется"
            recommendations["duration"] = "30-60 минут"
            recommendations["esvs_class"] = "Class I, Level A"
        
        # Default
        else:
            recommendations["approach"] = "Стандартный доступ"
            recommendations["graft"] = "По выбору хирурга"
            recommendations["duration"] = "2-3 часа"
        
        return recommendations
    
    def _generate_indications(
        self,
        protocol_type: str,
        measurements: Dict[str, Any]
    ) -> List[str]:
        """Generate indications based on measurements with ESVS 2024 criteria"""
        
        indications = []
        template = self.templates.get(protocol_type, {})
        
        # Use template indications if available
        if "indications" in template:
            indications.extend(template["indications"])
        
        # Aortic aneurysm
        if protocol_type in ["aortic_resection", "evar"]:
            aorta_diameter = measurements.get("aorta", {}).get("diameter_max", 0)
            gender = measurements.get("patient", {}).get("gender", "male")
            threshold = 55 if gender == "male" else 50
            
            if aorta_diameter > threshold:
                indications.append(f"Аневризма брюшной аорты диаметром {aorta_diameter:.1f} мм (>{threshold} мм - абсолютное показание к операции по ESVS 2024)")
            elif aorta_diameter > 45:
                indications.append(f"Аневризма брюшной аорты диаметром {aorta_diameter:.1f} мм (>45 мм - относительное показание)")
            
            growth_rate = measurements.get("aorta", {}).get("growth_rate", 0)
            if growth_rate > 10:
                indications.append(f"Быстрый рост аневризмы ({growth_rate:.1f} мм/год > 10 мм/год)")
            
            if measurements.get("aorta", {}).get("symptomatic", False):
                indications.append("Симптоматическая аневризма (боль, дискомфорт)")
        
        # Carotid stenosis
        elif protocol_type in ["carotid_endarterectomy", "carotid_stenting"]:
            stenosis = measurements.get("stenosis_percent", 0)
            symptomatic = measurements.get("symptomatic", False)
            
            if stenosis > 70 and symptomatic:
                indications.append(f"Симптоматический стеноз внутренней сонной артерии {stenosis:.0f}% (>70% - Class I, Level A)")
            elif stenosis > 50 and symptomatic:
                indications.append(f"Симптоматический стеноз {stenosis:.0f}% (>50% - Class I, Level A)")
            elif stenosis > 60 and not symptomatic:
                indications.append(f"Асимптоматический стеноз {stenosis:.0f}% (>60% с факторами риска)")
            
            if measurements.get("tia_history"):
                indications.append("Перенесённый ТИА/инсульт в бассейне данной артерии")
        
        # Peripheral artery disease
        elif protocol_type in ["femoropopliteal_bypass", "femoral_endarterectomy"]:
            indications.append("Хроническая ишемия нижних конечностей")
            
            rutherford_class = measurements.get("rutherford_class")
            if rutherford_class:
                indications.append(f"Класс ишемии по Rutherford: {rutherford_class}")
            
            if measurements.get("claudication_distance"):
                indications.append(f"Перемежающаяся хромота на расстоянии {measurements['claudication_distance']} м")
        
        # Varicose veins
        elif protocol_type in ["varicose_phlebectomy", "varicose_laser_ablation", "varicose_radiofrequency_ablation"]:
            ceap_class = measurements.get("ceap_class", "C2")
            indications.append(f"Варикозная болезнь нижних конечностей (CEAP {ceap_class})")
            
            if measurements.get("venous_reflux"):
                indications.append("Рефлюкс в большой/малой подкожной венах (подтверждённый УЗИ)")
            
            if measurements.get("symptoms"):
                indications.append("Клинические симптомы: боль, отёки, трофические изменения")
        
        # Thrombosis
        elif protocol_type in ["femoral_thrombectomy", "deep_vein_thrombosis_surgery"]:
            indications.append("Острый артериальный/венозный тромбоз")
            
            if measurements.get("onset_time"):
                indications.append(f"Время от начала заболевания: {measurements['onset_time']} часов")
        
        # Dialysis access
        elif protocol_type == "av_fistula_creation":
            indications.append("Хроническая почечная недостаточность (терминальная стадия)")
            indications.append("Необходимость программного гемодиализа")
        
        return indications
    
    async def generate_pdf(
        self,
        protocol: Dict[str, Any],
        output_filename: str
    ) -> str:
        """Generate HTML from protocol"""
        
        html_content = self._render_protocol_html(protocol)
        
        html_path = self.pdf_dir / output_filename.replace('.pdf', '.html')
        with open(html_path, 'w', encoding='utf-8') as f:
            f.write(html_content)
        
        return str(html_path)
    
    def _render_protocol_html(self, protocol: Dict[str, Any]) -> str:
        """Render protocol as HTML with modern styling"""
        
        html_template = """
        <!DOCTYPE html>
        <html>
        <head>
            <meta charset="UTF-8">
            <title>{{ title }}</title>
            <style>
                body {
                    font-family: 'Segoe UI', Arial, sans-serif;
                    margin: 40px;
                    line-height: 1.6;
                    color: #333;
                }
                .header {
                    text-align: center;
                    border-bottom: 3px solid #1a365d;
                    padding-bottom: 20px;
                    margin-bottom: 30px;
                }
                .title {
                    font-size: 26px;
                    font-weight: bold;
                    color: #1a365d;
                }
                .subtitle {
                    font-size: 14px;
                    color: #666;
                    margin-top: 5px;
                }
                .section {
                    margin: 25px 0;
                }
                .section-title {
                    font-size: 18px;
                    font-weight: bold;
                    color: #2c5282;
                    border-bottom: 2px solid #e2e8f0;
                    padding-bottom: 8px;
                    margin-bottom: 15px;
                }
                .info-grid {
                    display: grid;
                    grid-template-columns: 1fr 1fr;
                    gap: 15px;
                }
                .info-item {
                    margin: 8px 0;
                }
                .info-label {
                    font-weight: bold;
                    color: #4a5568;
                }
                .steps-list {
                    counter-reset: step;
                    list-style: none;
                    padding: 0;
                }
                .steps-list li {
                    counter-increment: step;
                    margin: 10px 0;
                    padding: 10px;
                    background: #f7fafc;
                    border-left: 3px solid #4299e1;
                }
                .steps-list li::before {
                    content: counter(step) ". ";
                    font-weight: bold;
                    color: #2c5282;
                }
                .checklist {
                    list-style: none;
                    padding: 0;
                }
                .checklist li {
                    margin: 8px 0;
                    padding-left: 25px;
                    position: relative;
                }
                .checklist li::before {
                    content: "☐";
                    position: absolute;
                    left: 0;
                    color: #4299e1;
                }
                .risks-table {
                    width: 100%;
                    border-collapse: collapse;
                    margin: 15px 0;
                }
                .risks-table th, .risks-table td {
                    border: 1px solid #e2e8f0;
                    padding: 10px;
                    text-align: left;
                }
                .risks-table th {
                    background: #edf2f7;
                    font-weight: bold;
                }
                .severity-high { color: #c53030; font-weight: bold; }
                .severity-moderate { color: #d69e2e; }
                .severity-low { color: #38a169; }
                .evidence-box {
                    background: #ebf8ff;
                    border: 1px solid #90cdf4;
                    border-radius: 5px;
                    padding: 15px;
                    margin: 15px 0;
                }
                .footer {
                    margin-top: 40px;
                    padding-top: 20px;
                    border-top: 2px solid #e2e8f0;
                    font-size: 12px;
                    color: #666;
                }
            </style>
        </head>
        <body>
            <div class="header">
                <div class="title">{{ title }}</div>
                <div class="subtitle">Протокол операции согласно клиническим рекомендациям</div>
            </div>
            
            <div class="section">
                <div class="section-title">Информация о пациенте</div>
                <div class="info-grid">
                    <div class="info-item">
                        <span class="info-label">Хирург:</span> {{ surgeon }}
                    </div>
                    <div class="info-item">
                        <span class="info-label">Дата:</span> {{ generated_at }}
                    </div>
                </div>
            </div>
            
            <div class="section">
                <div class="section-title">Предоперационный план</div>
                <p><strong>Показания:</strong></p>
                <ul>
                {% for indication in preoperative_plan.indications %}
                    <li>{{ indication }}</li>
                {% endfor %}
                </ul>
                <p><strong>Рекомендуемый подход:</strong> {{ preoperative_plan.recommended_approach }}</p>
                <p><strong>Тип протеза:</strong> {{ preoperative_plan.graft_recommendation }}</p>
                <p><strong>Продолжительность:</strong> {{ preoperative_plan.estimated_duration }}</p>
            </div>
            
            <div class="section">
                <div class="section-title">Этапы операции</div>
                <ol class="steps-list">
                {% for step in operation_steps %}
                    <li>{{ step }}</li>
                {% endfor %}
                </ol>
            </div>
            
            <div class="section">
                <div class="section-title">Чек-лист</div>
                <ul class="checklist">
                {% for item in checklist %}
                    <li>{{ item }}</li>
                {% endfor %}
                </ul>
            </div>
            
            <div class="section">
                <div class="section-title">Риски и осложнения</div>
                <table class="risks-table">
                    <tr>
                        <th>Осложнение</th>
                        <th>Вероятность</th>
                        <th>Степень тяжести</th>
                    </tr>
                {% for risk in risks %}
                    <tr>
                        <td>{{ risk.complication }}</td>
                        <td>{{ risk.probability }}</td>
                        <td class="severity-{{ risk.severity }}">{{ risk.severity }}</td>
                    </tr>
                {% endfor %}
                </table>
            </div>
            
            {% if evidence_base %}
            <div class="section">
                <div class="section-title">Доказательная база</div>
                <div class="evidence-box">
                    <p><strong>Клинические рекомендации:</strong> {{ evidence_base.guidelines | join(", ") }}</p>
                    <p><strong>Ключевые исследования:</strong> {{ evidence_base.key_studies | join(", ") }}</p>
                    <p><strong>Класс рекомендации:</strong> {{ evidence_base.recommendation_class }}</p>
                </div>
            </div>
            {% endif %}
            
            {% if surgeon_notes %}
            <div class="section">
                <div class="section-title">Примечания хирурга</div>
                <p>{{ surgeon_notes }}</p>
            </div>
            {% endif %}
            
            <div class="footer">
                <p><strong>Источники:</strong></p>
                <ul>
                {% for ref in references %}
                    <li>{{ ref }}</li>
                {% endfor %}
                </ul>
                <p>Сгенерировано VASCULAR.AI - Система поддержки принятия решений</p>
            </div>
        </body>
        </html>
        """
        
        template = Template(html_template)
        return template.render(**protocol)


# Singleton instance
_protocol_service = None

def get_protocol_service() -> ProtocolService:
    """Get singleton instance of ProtocolService"""
    global _protocol_service
    if _protocol_service is None:
        _protocol_service = ProtocolService()
    return _protocol_service


# Convenience export for direct import
protocol_service = get_protocol_service()
