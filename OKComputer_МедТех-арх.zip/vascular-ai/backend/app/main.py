from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles
from contextlib import asynccontextmanager
import os

from app.core.config import get_settings
from app.models.database import init_db
from app.api import dicom, segmentation, protocols, ai_recommendations, studies, tasc_graft, surgeon_tools, advanced_tools, clinical_atlas, specialized_guides, auth, agents, voice
from app.api.v1.endpoints import laboratory, knowledge_base
from app.core.middleware import RateLimitMiddleware, SecurityHeadersMiddleware, RequestLoggingMiddleware

settings = get_settings()


@asynccontextmanager
async def lifespan(app: FastAPI):
    """Application lifespan handler"""
    # Startup
    print("Starting VASCULAR.AI API...")
    
    # Create directories
    os.makedirs(settings.UPLOAD_DIR, exist_ok=True)
    os.makedirs(settings.PROCESSED_DIR, exist_ok=True)
    
    # Initialize database
    await init_db()
    print("Database initialized")
    
    yield
    
    # Shutdown
    print("Shutting down VASCULAR.AI API...")


# Create FastAPI app
app = FastAPI(
    title=settings.APP_NAME,
    version=settings.APP_VERSION,
    description="AI-powered vascular surgery planning platform",
    lifespan=lifespan
)

# Security middleware (order matters - executed in reverse)
app.add_middleware(SecurityHeadersMiddleware)
app.add_middleware(RequestLoggingMiddleware)
app.add_middleware(RateLimitMiddleware)

# CORS middleware
app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.CORS_ORIGINS,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Include routers - auth first (no protection needed)
app.include_router(auth.router)

# Protected routers
app.include_router(dicom.router)
app.include_router(segmentation.router)
app.include_router(protocols.router)
app.include_router(ai_recommendations.router)
app.include_router(studies.router)
app.include_router(tasc_graft.router)
app.include_router(surgeon_tools.router)
app.include_router(advanced_tools.router)
app.include_router(clinical_atlas.router)
app.include_router(specialized_guides.router)
app.include_router(agents.router)
app.include_router(voice.router)
app.include_router(laboratory.router, prefix="/api/v1/laboratory", tags=["laboratory"])
app.include_router(knowledge_base.router, prefix="/api/v1/kb", tags=["knowledge_base"])

# Static files for processed data
app.mount("/processed", StaticFiles(directory=settings.PROCESSED_DIR), name="processed")


@app.get("/")
async def root():
    """Root endpoint"""
    return {
        "name": settings.APP_NAME,
        "version": settings.APP_VERSION,
        "status": "running",
        "endpoints": {
            "dicom": "/api/dicom",
            "segmentation": "/api/segmentation",
            "protocols": "/api/protocols",
            "ai_recommendations": "/api/ai",
            "studies": "/api/studies",
            "clinical": "/api/clinical",
            "surgeon_tools": "/api/surgeon-tools",
            "advanced_tools": "/api/advanced",
            "clinical_atlas": "/api/atlas",
            "specialized_guides": "/api/specialized",
            "ai_agents": "/api/agents",
            "voice": "/api/voice",
            "laboratory": "/api/v1/laboratory",
            "knowledge_base": "/api/v1/kb"
        },
        "features": [
            "AI Segmentation",
            "Risk Assessment (ESVS 2024, VSGNE, GAS)",
            "TASC II Classification",
            "Graft Selection",
            "Russian Clinical Guidelines",
            "Phlebology Guide",
            "Multi-modal Studies (CT, MRI, US, Echo)",
            "Risk Calculators (VSGNE, GAS, Stroke, Amputation)",
            "Anticoagulation Management",
            "Complication Algorithms",
            "Postoperative Protocols",
            "Laboratory Thresholds",
            "Vascular Access Planning (Dialysis, Endovascular)",
            "3D Measurements for EVAR/TEVAR",
            "Vascular Lab Interpretation (ABI, PVR, Doppler)",
            "Trauma Protocols",
            "Pediatric Vascular Surgery",
            "WHO Surgical Safety Checklists",
            "Clinical Atlas (Medscape, First Aid, Netter, Sabiston)",
            "Step-by-Step Operative Techniques",
            "Pharmacotherapy Guidelines (ACC/AHA 2024)",
            "Lymphedema Management (ISL Staging, CDT)",
            "Contrast Media Guide (CIN Prevention, NSF)",
            "Endovascular Complications Management",
            "Vascular Ultrasound Interpretation",
            "Neurointerventional Surgery Guide",
            "Hybrid Aortic Surgery (TEVAR, Dissection)",
            "AI Medical Agents (Vascular, Phlebology, Neuro, Endovascular)",
            "Scientific Literature Integration (PubMed)",
            "Clinical Guidelines Integration (ESVS, SVS, ACC/AHA)",
            "Multi-Agent Consensus System",
            "Agent Output Validation",
            "Evidence-Based Recommendations",
            "LLM Integration (GPT-4/Claude)",
            "Voice-to-Text Medical Dictation",
            "Streaming AI Analysis",
            "Laboratory Tests Management",
            "Test Results with Auto-Interpretation",
            "Critical Value Alerts",
            "Test Trends and Delta Check",
            "Medical Knowledge Base",
            "Drug Interaction Checker",
            "Clinical Guidelines Database",
            "Quick Reference Cards"
        ]
    }


@app.get("/health")
async def health_check():
    """Health check endpoint"""
    return {
        "status": "healthy",
        "version": settings.APP_VERSION
    }


if __name__ == "__main__":
    import uvicorn
    uvicorn.run(
        "app.main:app",
        host="0.0.0.0",
        port=8000,
        reload=settings.DEBUG,
        log_level="info"
    )
