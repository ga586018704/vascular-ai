"""
Seed data for Knowledge Base
Загрузка данных из книг и научных источников в справочник
"""

import asyncio
from datetime import datetime
from uuid import uuid4

from sqlalchemy.ext.asyncio import AsyncSession

from app.knowledge_base.models import (
    KBArticle, KBCategory, KBTag, KBMedication, 
    KBDisease, KBProcedure, KBGuideline
)
from app.knowledge_base.book_data import ScientificDataStore


class KnowledgeBaseSeeder:
    """Загрузчик данных в медицинский справочник"""
    
    def __init__(self, db: AsyncSession):
        self.db = db
    
    async def seed_all(self):
        """Загрузить все данные"""
        print("Starting Knowledge Base seeding...")
        
        # Создать категории
        await self._seed_categories()
        
        # Создать теги
        await self._seed_tags()
        
        # Загрузить статьи из книг
        await self._seed_book_articles()
        
        # Загрузить клинические руководства
        await self._seed_guidelines()
        
        # Загрузить процедуры
        await self._seed_procedures()
        
        await self.db.commit()
        print("Knowledge Base seeding completed!")
    
    async def _seed_categories(self):
        """Создать категории справочника"""
        categories = [
            {
                "code": "vascular_surgery",
                "name": "Сосудистая хирургия",
                "name_en": "Vascular Surgery",
                "description": "Заболевания артерий и вен, методы диагностики и лечения",
                "level": 0,
                "sort_order": 1
            },
            {
                "code": "venous_disease",
                "name": "Венозные заболевания",
                "name_en": "Venous Disease",
                "description": "Хроническая венозная недостаточность, варикозная болезнь, ТГВ",
                "level": 1,
                "parent_code": "vascular_surgery",
                "sort_order": 1
            },
            {
                "code": "arterial_disease",
                "name": "Артериальные заболевания",
                "name_en": "Arterial Disease",
                "description": "Атеросклероз, аневризмы, окклюзирующие заболевания",
                "level": 1,
                "parent_code": "vascular_surgery",
                "sort_order": 2
            },
            {
                "code": "lymphatic_disease",
                "name": "Лимфатические заболевания",
                "name_en": "Lymphatic Disease",
                "description": "Лимфедема, лимфостаз",
                "level": 1,
                "parent_code": "vascular_surgery",
                "sort_order": 3
            },
            {
                "code": "endovascular",
                "name": "Эндоваскулярная хирургия",
                "name_en": "Endovascular Surgery",
                "description": "Минимально инвазивные эндоваскулярные процедуры",
                "level": 1,
                "parent_code": "vascular_surgery",
                "sort_order": 4
            },
            {
                "code": "diagnostics",
                "name": "Диагностика",
                "name_en": "Diagnostics",
                "description": "Методы диагностики сосудистых заболеваний",
                "level": 0,
                "sort_order": 2
            },
            {
                "code": "imaging",
                "name": "Визуализация",
                "name_en": "Imaging",
                "description": "УЗИ, КТ, МРТ, ангиография",
                "level": 1,
                "parent_code": "diagnostics",
                "sort_order": 1
            },
            {
                "code": "contrast_media",
                "name": "Контрастные вещества",
                "name_en": "Contrast Media",
                "description": "Использование и безопасность контрастных веществ",
                "level": 2,
                "parent_code": "imaging",
                "sort_order": 1
            },
            {
                "code": "clinical_guidelines",
                "name": "Клинические руководства",
                "name_en": "Clinical Guidelines",
                "description": "Рекомендации ESVS, SVS, ACC/AHA",
                "level": 0,
                "sort_order": 3
            },
            {
                "code": "medications",
                "name": "Лекарственные препараты",
                "name_en": "Medications",
                "description": "Фармакотерапия сосудистых заболеваний",
                "level": 0,
                "sort_order": 4
            }
        ]
        
        # Словарь для хранения созданных категорий
        category_map = {}
        
        for cat_data in categories:
            # Проверить существование
            from sqlalchemy import select
            result = await self.db.execute(
                select(KBCategory).where(KBCategory.code == cat_data["code"])
            )
            existing = result.scalar_one_or_none()
            
            if existing:
                category_map[cat_data["code"]] = existing
                continue
            
            # Получить parent_id если есть
            parent_id = None
            if "parent_code" in cat_data:
                parent = category_map.get(cat_data["parent_code"])
                if parent:
                    parent_id = parent.id
            
            category = KBCategory(
                id=uuid4(),
                code=cat_data["code"],
                name=cat_data["name"],
                name_en=cat_data.get("name_en"),
                description=cat_data.get("description"),
                level=cat_data.get("level", 0),
                parent_id=parent_id,
                sort_order=cat_data.get("sort_order", 0),
                is_active=True,
                is_visible=True
            )
            
            self.db.add(category)
            category_map[cat_data["code"]] = category
        
        await self.db.flush()
        print(f"Created {len(category_map)} categories")
    
    async def _seed_tags(self):
        """Создать теги"""
        tags = [
            {"code": "varicose_veins", "name": "Варикозные вены", "synonyms": ["varicose", "varices"]},
            {"code": "dvt", "name": "ТГВ", "synonyms": ["deep vein thrombosis", "тромбоз"]},
            {"code": "evla", "name": "EVLA", "synonyms": ["endovenous laser", "лазерная абляция"]},
            {"code": "rfa", "name": "RFA", "synonyms": ["radiofrequency ablation", "радиочастотная абляция"]},
            {"code": "sclerotherapy", "name": "Склеротерапия", "synonyms": ["foam sclerotherapy", "пенная склеротерапия"]},
            {"code": "lymphedema", "name": "Лимфедема", "synonyms": ["lymphoedema", "лимфостаз"]},
            {"code": "cdt", "name": "CDT", "synonyms": ["complex decongestive therapy", "комплексная терапия"]},
            {"code": "aaa", "name": "AAA", "synonyms": ["abdominal aortic aneurysm", "аортальная аневризма"]},
            {"code": "evar", "name": "EVAR", "synonyms": ["endovascular aneurysm repair"]},
            {"code": "clti", "name": "CLTI", "synonyms": ["chronic limb threatening ischemia", "критическая ишемия"]},
            {"code": "contrast", "name": "Контраст", "synonyms": ["contrast media", "contrast agent"]},
            {"code": "cin", "name": "CIN", "synonyms": ["contrast induced nephropathy", "нефропатия"]},
            {"code": "stent", "name": "Стент", "synonyms": ["stenting", "стентирование"]},
            {"code": "angioplasty", "name": "Ангиопластика", "synonyms": ["balloon angioplasty", "баллонная ангиопластика"]},
            {"code": "esvs", "name": "ESVS", "synonyms": ["European Society for Vascular Surgery"]},
            {"code": "guidelines", "name": "Руководства", "synonyms": ["guidelines", "рекомендации"]}
        ]
        
        for tag_data in tags:
            from sqlalchemy import select
            result = await self.db.execute(
                select(KBTag).where(KBTag.code == tag_data["code"])
            )
            existing = result.scalar_one_or_none()
            
            if existing:
                continue
            
            tag = KBTag(
                id=uuid4(),
                code=tag_data["code"],
                name=tag_data["name"],
                synonyms=tag_data.get("synonyms", []),
                is_active=True
            )
            self.db.add(tag)
        
        await self.db.flush()
        print(f"Created {len(tags)} tags")
    
    async def _seed_book_articles(self):
        """Загрузить статьи из книг"""
        from sqlalchemy import select
        
        articles = ScientificDataStore.get_all_articles()
        
        # Получить категории
        result = await self.db.execute(select(KBCategory))
        categories = {cat.code: cat for cat in result.scalars().all()}
        
        # Получить теги
        result = await self.db.execute(select(KBTag))
        tags = {tag.code: tag for tag in result.scalars().all()}
        
        count = 0
        for article_data in articles:
            # Проверить существование
            result = await self.db.execute(
                select(KBArticle).where(KBArticle.code == article_data["code"])
            )
            if result.scalar_one_or_none():
                continue
            
            # Определить категорию
            category_code = article_data.get("category", "vascular_surgery")
            category = categories.get(category_code)
            
            # Создать статью
            article = KBArticle(
                id=uuid4(),
                code=article_data["code"],
                title=article_data["title"],
                article_type=article_data["article_type"],
                content=article_data["content"],
                summary="\n".join(article_data.get("key_points", []))[:500],
                key_points=article_data.get("key_points", []),
                status="published",
                published_at=datetime.utcnow(),
                is_active=True,
                view_count=0,
                favorite_count=0
            )
            
            # Добавить категорию
            if category:
                article.categories.append(category)
            
            # Добавить теги по ключевым словам
            content_lower = article_data["content"].lower()
            for tag_code, tag in tags.items():
                if tag_code in content_lower or tag.name.lower() in content_lower:
                    article.tags.append(tag)
            
            self.db.add(article)
            count += 1
        
        await self.db.flush()
        print(f"Created {count} articles from books")
    
    async def _seed_guidelines(self):
        """Загрузить клинические руководства"""
        from sqlalchemy import select
        
        guidelines = ScientificDataStore.get_guidelines()
        
        # Получить категорию
        result = await self.db.execute(
            select(KBCategory).where(KBCategory.code == "clinical_guidelines")
        )
        category = result.scalar_one_or_none()
        
        count = 0
        for guideline_data in guidelines:
            # Проверить существование
            result = await self.db.execute(
                select(KBArticle).where(KBArticle.code == guideline_data["code"])
            )
            if result.scalar_one_or_none():
                continue
            
            # Создать статью-руководство
            article = KBArticle(
                id=uuid4(),
                code=guideline_data["code"],
                title=guideline_data["title"],
                article_type="guideline",
                content=f"""
                Клиническое руководство {guideline_data['organization']} {guideline_data['year']}
                
                Ключевые рекомендации:
                {self._format_recommendations(guideline_data.get('recommendations', []))}
                """,
                status="published",
                published_at=datetime.utcnow(),
                is_active=True,
                view_count=0,
                favorite_count=0
            )
            
            if category:
                article.categories.append(category)
            
            self.db.add(article)
            
            # Создать запись в таблице guidelines
            guideline = KBGuideline(
                id=uuid4(),
                article_id=article.id,
                organization=guideline_data["organization"],
                guideline_year=guideline_data["year"],
                key_recommendations=guideline_data.get("recommendations", [])
            )
            self.db.add(guideline)
            
            count += 1
        
        await self.db.flush()
        print(f"Created {count} clinical guidelines")
    
    async def _seed_procedures(self):
        """Загрузить процедуры"""
        from sqlalchemy import select
        
        procedures = [
            {
                "code": "evla_procedure",
                "title": "Эндовенозная лазерная абляция (EVLA)",
                "procedure_type": "endovascular",
                "specialty": "vascular_surgery",
                "indications": [
                    "Варикозные вены GSV/SSV с рефлюксом",
                    "CEAP C2-C6",
                    "Диаметр вены 2-15 мм"
                ],
                "contraindications_absolute": [
                    "Окклюзия глубоких вен",
                    "Артериальная недостаточность",
                    "Беременность"
                ],
                "steps": [
                    "Тумесцентная анестезия",
                    "Введение лазерного волокна под УЗИ-контролем",
                    "Абляция с энергией 50-100 Дж/см",
                    "Компрессия после процедуры"
                ],
                "duration": "30-60 минут",
                "success_rate": "93-98% через 5 лет"
            },
            {
                "code": "rfa_procedure",
                "title": "Радиочастотная абляция (RFA)",
                "procedure_type": "endovascular",
                "specialty": "vascular_surgery",
                "indications": [
                    "Варикозные вены GSV/SSV",
                    "CEAP C2-C6"
                ],
                "steps": [
                    "Тумесцентная анестезия",
                    "Введение катетера ClosureFast",
                    "Нагрев до 120°C по сегментам",
                    "Компрессия"
                ],
                "duration": "20-45 минут",
                "success_rate": "90-95% через 5 лет"
            },
            {
                "code": "foam_sclerotherapy_procedure",
                "title": "Пенная склеротерапия",
                "procedure_type": "endovascular",
                "specialty": "vascular_surgery",
                "indications": [
                    "Ретикулярные вены",
                    "Телеангиэктазии",
                    "Остаточные варикозные вены после абляции"
                ],
                "steps": [
                    "Приготовление пены (Tessari technique)",
                    "Введение пены под УЗИ-контролем",
                    "Компрессия"
                ],
                "duration": "15-30 минут"
            }
        ]
        
        count = 0
        for proc_data in procedures:
            # Проверить существование
            result = await self.db.execute(
                select(KBArticle).where(KBArticle.code == proc_data["code"])
            )
            if result.scalar_one_or_none():
                continue
            
            # Создать статью-процедуру
            article = KBArticle(
                id=uuid4(),
                code=proc_data["code"],
                title=proc_data["title"],
                article_type="procedure",
                content=f"""
                {proc_data['title']}
                
                Показания:
                {chr(10).join(['- ' + i for i in proc_data.get('indications', [])])}
                
                Техника выполнения:
                {chr(10).join([f"{i+1}. {step}" for i, step in enumerate(proc_data.get('steps', []))])}
                
                Продолжительность: {proc_data.get('duration', 'N/A')}
                Успех: {proc_data.get('success_rate', 'N/A')}
                """,
                status="published",
                published_at=datetime.utcnow(),
                is_active=True
            )
            
            self.db.add(article)
            
            # Создать запись в таблице procedures
            procedure = KBProcedure(
                id=uuid4(),
                article_id=article.id,
                procedure_type=proc_data.get("procedure_type"),
                specialty=proc_data.get("specialty"),
                indications=proc_data.get("indications", []),
                contraindications_absolute=proc_data.get("contraindications_absolute", []),
                steps=proc_data.get("steps", []),
                duration=proc_data.get("duration"),
                success_rate=proc_data.get("success_rate")
            )
            self.db.add(procedure)
            
            count += 1
        
        await self.db.flush()
        print(f"Created {count} procedures")
    
    def _format_recommendations(self, recommendations: list) -> str:
        """Форматировать рекомендации для отображения"""
        lines = []
        for rec in recommendations:
            lines.append(f"""
            Рекомендация: {rec.get('recommendation', '')}
            Класс: {rec.get('class', 'N/A')}, Уровень доказательств: {rec.get('level', 'N/A')}
            """)
        return "\n".join(lines)


# Функция для запуска из командной строки
async def run_seeder():
    """Запуск загрузки данных"""
    from app.models.database import async_session
    
    async with async_session() as session:
        seeder = KnowledgeBaseSeeder(session)
        await seeder.seed_all()


if __name__ == "__main__":
    asyncio.run(run_seeder())