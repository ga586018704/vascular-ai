"""
Medical Knowledge Base Service
Сервис для работы с медицинским справочником
"""

from datetime import datetime
from typing import List, Optional, Dict, Any
from uuid import UUID

from sqlalchemy import and_, or_, func, desc, text
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.future import select
from sqlalchemy.orm import selectinload

from app.knowledge_base.models import (
    KBArticle, KBCategory, KBTag, KBMedication, 
    KBDisease, KBProcedure, KBGuideline,
    KBArticleFavorite, KBSearchLog
)


class KnowledgeBaseService:
    """Сервис медицинского справочника"""
    
    def __init__(self, db: AsyncSession):
        self.db = db
    
    # ==================== Articles ====================
    
    async def search_articles(
        self,
        query: str,
        article_type: Optional[str] = None,
        category_id: Optional[UUID] = None,
        tags: Optional[List[str]] = None,
        page: int = 1,
        limit: int = 20
    ) -> Dict[str, Any]:
        """Поиск статей в справочнике"""
        # Базовый запрос
        base_query = select(KBArticle).where(
            and_(
                KBArticle.status == "published",
                KBArticle.is_active == True
            )
        )
        
        # Полнотекстовый поиск
        if query:
            search_filter = or_(
                KBArticle.title.ilike(f"%{query}%"),
                KBArticle.summary.ilike(f"%{query}%"),
                KBArticle.search_text.ilike(f"%{query}%"),
                KBArticle.keywords.any(query.lower())
            )
            base_query = base_query.where(search_filter)
        
        # Фильтр по типу
        if article_type:
            base_query = base_query.where(KBArticle.article_type == article_type)
        
        # Фильтр по категории
        if category_id:
            base_query = base_query.join(KBArticle.categories).where(
                KBCategory.id == category_id
            )
        
        # Фильтр по тегам
        if tags:
            base_query = base_query.join(KBArticle.tags).where(
                KBTag.code.in_(tags)
            )
        
        # Подсчет общего количества
        count_result = await self.db.execute(
            select(func.count()).select_from(base_query.subquery())
        )
        total = count_result.scalar()
        
        # Сортировка и пагинация
        base_query = base_query.order_by(
            desc(KBArticle.view_count),
            desc(KBArticle.published_at)
        )
        base_query = base_query.offset((page - 1) * limit).limit(limit)
        
        # Загрузка связанных данных
        base_query = base_query.options(
            selectinload(KBArticle.categories),
            selectinload(KBArticle.tags)
        )
        
        result = await self.db.execute(base_query)
        articles = result.scalars().all()
        
        return {
            "items": list(articles),
            "total": total,
            "page": page,
            "pages": (total + limit - 1) // limit
        }
    
    async def get_article(self, article_id: UUID) -> Optional[KBArticle]:
        """Получение статьи по ID"""
        result = await self.db.execute(
            select(KBArticle)
            .options(
                selectinload(KBArticle.categories),
                selectinload(KBArticle.tags),
                selectinload(KBArticle.related_articles)
            )
            .where(KBArticle.id == article_id)
        )
        return result.scalar_one_or_none()
    
    async def get_article_by_code(self, code: str) -> Optional[KBArticle]:
        """Получение статьи по коду"""
        result = await self.db.execute(
            select(KBArticle)
            .options(
                selectinload(KBArticle.categories),
                selectinload(KBArticle.tags)
            )
            .where(
                and_(
                    KBArticle.code == code,
                    KBArticle.is_active == True
                )
            )
        )
        return result.scalar_one_or_none()
    
    async def increment_view_count(self, article_id: UUID):
        """Увеличение счетчика просмотров"""
        article = await self.get_article(article_id)
        if article:
            article.view_count += 1
            await self.db.commit()
    
    async def get_popular_articles(
        self,
        article_type: Optional[str] = None,
        limit: int = 10
    ) -> List[KBArticle]:
        """Получение популярных статей"""
        query = select(KBArticle).where(
            and_(
                KBArticle.status == "published",
                KBArticle.is_active == True
            )
        )
        
        if article_type:
            query = query.where(KBArticle.article_type == article_type)
        
        query = query.order_by(desc(KBArticle.view_count)).limit(limit)
        
        result = await self.db.execute(query)
        return list(result.scalars().all())
    
    async def get_recent_articles(
        self,
        limit: int = 10
    ) -> List[KBArticle]:
        """Получение недавно добавленных статей"""
        result = await self.db.execute(
            select(KBArticle)
            .where(
                and_(
                    KBArticle.status == "published",
                    KBArticle.is_active == True
                )
            )
            .order_by(desc(KBArticle.published_at))
            .limit(limit)
        )
        return list(result.scalars().all())
    
    # ==================== Categories ====================
    
    async def get_categories(
        self,
        parent_id: Optional[UUID] = None
    ) -> List[KBCategory]:
        """Получение категорий"""
        query = select(KBCategory).where(
            and_(
                KBCategory.is_active == True,
                KBCategory.is_visible == True
            )
        )
        
        if parent_id:
            query = query.where(KBCategory.parent_id == parent_id)
        else:
            query = query.where(KBCategory.parent_id.is_(None))
        
        query = query.order_by(KBCategory.sort_order, KBCategory.name)
        
        result = await self.db.execute(query)
        return list(result.scalars().all())
    
    async def get_category_tree(self) -> List[Dict[str, Any]]:
        """Получение дерева категорий"""
        result = await self.db.execute(
            select(KBCategory)
            .where(
                and_(
                    KBCategory.is_active == True,
                    KBCategory.is_visible == True
                )
            )
            .order_by(KBCategory.level, KBCategory.sort_order)
        )
        categories = result.scalars().all()
        
        # Построение дерева
        tree = []
        category_map = {}
        
        for cat in categories:
            node = {
                "id": str(cat.id),
                "code": cat.code,
                "name": cat.name,
                "children": []
            }
            category_map[cat.id] = node
            
            if cat.parent_id is None:
                tree.append(node)
            elif cat.parent_id in category_map:
                category_map[cat.parent_id]["children"].append(node)
        
        return tree
    
    async def get_articles_by_category(
        self,
        category_id: UUID,
        page: int = 1,
        limit: int = 20
    ) -> Dict[str, Any]:
        """Получение статей по категории"""
        query = select(KBArticle).join(KBArticle.categories).where(
            and_(
                KBCategory.id == category_id,
                KBArticle.status == "published",
                KBArticle.is_active == True
            )
        )
        
        count_result = await self.db.execute(
            select(func.count()).select_from(query.subquery())
        )
        total = count_result.scalar()
        
        query = query.order_by(KBArticle.title)
        query = query.offset((page - 1) * limit).limit(limit)
        
        result = await self.db.execute(query)
        articles = result.scalars().all()
        
        return {
            "items": list(articles),
            "total": total,
            "page": page,
            "pages": (total + limit - 1) // limit
        }
    
    # ==================== Tags ====================
    
    async def get_tags(
        self,
        search: Optional[str] = None,
        limit: int = 50
    ) -> List[KBTag]:
        """Получение тегов"""
        query = select(KBTag).where(KBTag.is_active == True)
        
        if search:
            query = query.where(
                or_(
                    KBTag.name.ilike(f"%{search}%"),
                    KBTag.synonyms.any(search.lower())
                )
            )
        
        query = query.order_by(desc(KBTag.usage_count)).limit(limit)
        
        result = await self.db.execute(query)
        return list(result.scalars().all())
    
    async def get_articles_by_tag(
        self,
        tag_code: str,
        page: int = 1,
        limit: int = 20
    ) -> Dict[str, Any]:
        """Получение статей по тегу"""
        query = select(KBArticle).join(KBArticle.tags).where(
            and_(
                KBTag.code == tag_code,
                KBArticle.status == "published",
                KBArticle.is_active == True
            )
        )
        
        count_result = await self.db.execute(
            select(func.count()).select_from(query.subquery())
        )
        total = count_result.scalar()
        
        query = query.order_by(desc(KBArticle.view_count))
        query = query.offset((page - 1) * limit).limit(limit)
        
        result = await self.db.execute(query)
        articles = result.scalars().all()
        
        return {
            "items": list(articles),
            "total": total,
            "page": page,
            "pages": (total + limit - 1) // limit
        }
    
    # ==================== Medications ====================
    
    async def search_medications(
        self,
        query: str,
        drug_class: Optional[str] = None,
        limit: int = 20
    ) -> List[KBMedication]:
        """Поиск лекарственных препаратов"""
        # Поиск через статьи
        article_result = await self.db.execute(
            select(KBArticle).where(
                and_(
                    KBArticle.article_type == "medication",
                    KBArticle.status == "published",
                    or_(
                        KBArticle.title.ilike(f"%{query}%"),
                        KBArticle.keywords.any(query.lower())
                    )
                )
            ).limit(limit)
        )
        articles = article_result.scalars().all()
        
        if not articles:
            return []
        
        article_ids = [a.id for a in articles]
        
        med_query = select(KBMedication).where(
            KBMedication.article_id.in_(article_ids)
        )
        
        if drug_class:
            med_query = med_query.where(KBMedication.drug_class == drug_class)
        
        result = await self.db.execute(med_query)
        return list(result.scalars().all())
    
    async def get_medication(self, article_id: UUID) -> Optional[KBMedication]:
        """Получение информации о препарате"""
        result = await self.db.execute(
            select(KBMedication).where(KBMedication.article_id == article_id)
        )
        return result.scalar_one_or_none()
    
    async def check_drug_interactions(
        self,
        drug_codes: List[str]
    ) -> List[Dict[str, Any]]:
        """Проверка лекарственных взаимодействий"""
        interactions = []
        
        # Получить все препараты
        result = await self.db.execute(
            select(KBMedication).join(KBArticle).where(
                KBArticle.code.in_(drug_codes)
            )
        )
        medications = result.scalars().all()
        
        # Проверить взаимодействия
        for med in medications:
            for interaction in med.drug_interactions or []:
                if interaction.get("drug_code") in drug_codes:
                    interactions.append({
                        "drug1": med.generic_name,
                        "drug2": interaction.get("drug_name"),
                        "severity": interaction.get("severity"),  # major, moderate, minor
                        "description": interaction.get("description"),
                        "recommendation": interaction.get("recommendation")
                    })
        
        return interactions
    
    # ==================== Diseases ====================
    
    async def search_diseases(
        self,
        query: str,
        body_system: Optional[str] = None,
        limit: int = 20
    ) -> List[KBDisease]:
        """Поиск заболеваний"""
        article_result = await self.db.execute(
            select(KBArticle).where(
                and_(
                    KBArticle.article_type == "disease",
                    KBArticle.status == "published",
                    or_(
                        KBArticle.title.ilike(f"%{query}%"),
                        KBArticle.icd10_codes.any(query.upper()),
                        KBArticle.keywords.any(query.lower())
                    )
                )
            ).limit(limit)
        )
        articles = article_result.scalars().all()
        
        if not articles:
            return []
        
        article_ids = [a.id for a in articles]
        
        disease_query = select(KBDisease).where(
            KBDisease.article_id.in_(article_ids)
        )
        
        if body_system:
            disease_query = disease_query.where(KBDisease.body_system == body_system)
        
        result = await self.db.execute(disease_query)
        return list(result.scalars().all())
    
    async def get_disease(self, article_id: UUID) -> Optional[KBDisease]:
        """Получение информации о заболевании"""
        result = await self.db.execute(
            select(KBDisease).where(KBDisease.article_id == article_id)
        )
        return result.scalar_one_or_none()
    
    # ==================== Procedures ====================
    
    async def search_procedures(
        self,
        query: str,
        specialty: Optional[str] = None,
        limit: int = 20
    ) -> List[KBProcedure]:
        """Поиск медицинских процедур"""
        article_result = await self.db.execute(
            select(KBArticle).where(
                and_(
                    KBArticle.article_type == "procedure",
                    KBArticle.status == "published",
                    or_(
                        KBArticle.title.ilike(f"%{query}%"),
                        KBArticle.keywords.any(query.lower())
                    )
                )
            ).limit(limit)
        )
        articles = article_result.scalars().all()
        
        if not articles:
            return []
        
        article_ids = [a.id for a in articles]
        
        proc_query = select(KBProcedure).where(
            KBProcedure.article_id.in_(article_ids)
        )
        
        if specialty:
            proc_query = proc_query.where(KBProcedure.specialty == specialty)
        
        result = await self.db.execute(proc_query)
        return list(result.scalars().all())
    
    async def get_procedure(self, article_id: UUID) -> Optional[KBProcedure]:
        """Получение информации о процедуре"""
        result = await self.db.execute(
            select(KBProcedure).where(KBProcedure.article_id == article_id)
        )
        return result.scalar_one_or_none()
    
    # ==================== Guidelines ====================
    
    async def get_guidelines(
        self,
        organization: Optional[str] = None,
        year: Optional[int] = None,
        page: int = 1,
        limit: int = 20
    ) -> Dict[str, Any]:
        """Получение клинических руководств"""
        query = select(KBArticle).where(
            and_(
                KBArticle.article_type == "guideline",
                KBArticle.status == "published",
                KBArticle.is_active == True
            )
        )
        
        # Присоединить таблицу guidelines для фильтрации
        query = query.join(KBGuideline, KBArticle.id == KBGuideline.article_id)
        
        if organization:
            query = query.where(KBGuideline.organization == organization)
        if year:
            query = query.where(KBGuideline.guideline_year == year)
        
        count_result = await self.db.execute(
            select(func.count()).select_from(query.subquery())
        )
        total = count_result.scalar()
        
        query = query.order_by(desc(KBGuideline.guideline_year))
        query = query.offset((page - 1) * limit).limit(limit)
        
        result = await self.db.execute(query)
        articles = result.scalars().all()
        
        return {
            "items": list(articles),
            "total": total,
            "page": page,
            "pages": (total + limit - 1) // limit
        }
    
    async def get_guideline(self, article_id: UUID) -> Optional[KBGuideline]:
        """Получение информации о руководстве"""
        result = await self.db.execute(
            select(KBGuideline).where(KBGuideline.article_id == article_id)
        )
        return result.scalar_one_or_none()
    
    # ==================== Favorites ====================
    
    async def add_to_favorites(
        self,
        user_id: UUID,
        article_id: UUID,
        notes: Optional[str] = None
    ) -> bool:
        """Добавление статьи в избранное"""
        # Проверить существование
        result = await self.db.execute(
            select(KBArticleFavorite).where(
                and_(
                    KBArticleFavorite.user_id == user_id,
                    KBArticleFavorite.article_id == article_id
                )
            )
        )
        if result.scalar_one_or_none():
            return False
        
        favorite = KBArticleFavorite(
            user_id=user_id,
            article_id=article_id,
            notes=notes
        )
        self.db.add(favorite)
        
        # Увеличить счетчик
        article = await self.get_article(article_id)
        if article:
            article.favorite_count += 1
        
        await self.db.commit()
        return True
    
    async def remove_from_favorites(
        self,
        user_id: UUID,
        article_id: UUID
    ) -> bool:
        """Удаление статьи из избранного"""
        result = await self.db.execute(
            select(KBArticleFavorite).where(
                and_(
                    KBArticleFavorite.user_id == user_id,
                    KBArticleFavorite.article_id == article_id
                )
            )
        )
        favorite = result.scalar_one_or_none()
        
        if not favorite:
            return False
        
        await self.db.delete(favorite)
        
        # Уменьшить счетчик
        article = await self.get_article(article_id)
        if article:
            article.favorite_count = max(0, article.favorite_count - 1)
        
        await self.db.commit()
        return True
    
    async def get_user_favorites(
        self,
        user_id: UUID,
        page: int = 1,
        limit: int = 20
    ) -> Dict[str, Any]:
        """Получение избранных статей пользователя"""
        query = select(KBArticle).join(KBArticleFavorite).where(
            KBArticleFavorite.user_id == user_id
        )
        
        count_result = await self.db.execute(
            select(func.count()).select_from(query.subquery())
        )
        total = count_result.scalar()
        
        query = query.order_by(desc(KBArticleFavorite.created_at))
        query = query.offset((page - 1) * limit).limit(limit)
        
        result = await self.db.execute(query)
        articles = result.scalars().all()
        
        return {
            "items": list(articles),
            "total": total,
            "page": page,
            "pages": (total + limit - 1) // limit
        }
    
    # ==================== Search Analytics ====================
    
    async def log_search(
        self,
        query: str,
        user_id: Optional[UUID],
        results_count: int,
        response_time_ms: int,
        filters: Optional[Dict[str, Any]] = None
    ):
        """Логирование поискового запроса"""
        log = KBSearchLog(
            user_id=user_id,
            query=query,
            results_count=results_count,
            response_time_ms=response_time_ms,
            search_filters=filters or {}
        )
        self.db.add(log)
        await self.db.commit()
    
    async def get_popular_searches(
        self,
        days: int = 30,
        limit: int = 20
    ) -> List[Dict[str, Any]]:
        """Получение популярных поисковых запросов"""
        from datetime import timedelta
        
        since = datetime.utcnow() - timedelta(days=days)
        
        result = await self.db.execute(
            select(
                KBSearchLog.query,
                func.count(KBSearchLog.id).label("count")
            )
            .where(KBSearchLog.created_at >= since)
            .group_by(KBSearchLog.query)
            .order_by(desc("count"))
            .limit(limit)
        )
        
        return [
            {"query": row[0], "count": row[1]}
            for row in result.all()
        ]
    
    # ==================== Quick Reference ====================
    
    async def get_quick_reference(
        self,
        category: str
    ) -> Dict[str, Any]:
        """Получение краткого справочника"""
        
        if category == "vascular_emergency":
            return {
                "title": "Сосудистые экстренные состояния",
                "items": [
                    {
                        "condition": "Расслоение аорты",
                        "symptoms": ["Внезапная сильная боль в груди/спине", "Разница АД на руках"],
                        "actions": ["Немедленная КТ-ангиография", "Контроль АД", "Хирургическая консультация"],
                        "mortality": "1-2% в час без лечения"
                    },
                    {
                        "condition": "ТГВ с эмболией легочной артерии",
                        "symptoms": ["Одышка", "Боль в груди", "Тахикардия"],
                        "actions": ["КТ-ангиография грудной клетки", "Антикоагулянты", "Оценка тромболиза"],
                        "mortality": "30% без лечения"
                    },
                    {
                        "condition": "Острый артериальный тромбоз",
                        "symptoms": ["6P: Pain, Pallor, Pulseless, Paralysis, Paresthesia, Poikilothermia"],
                        "actions": ["Немедленная ангиография", "Тромболиз/эмболэктомия", "Время - ткань!"],
                        "time_critical": "6 часов"
                    }
                ]
            }
        
        elif category == "anticoagulation":
            return {
                "title": "Антикоагулянтная терапия",
                "items": [
                    {
                        "drug": "Варфарин",
                        "target_inr": "2.0-3.0 (механический клапан МА 2.5-3.5)",
                        "monitoring": "МНО каждые 1-4 недели",
                        "reversal": "Витамин К 10мг IV, PCC 25-50 ЕД/кг"
                    },
                    {
                        "drug": "Дабигатран",
                        "dose": "150мг 2р/день (CrCl>30)",
                        "monitoring": "Не требуется",
                        "reversal": "Идаруцизумаб 5г IV"
                    },
                    {
                        "drug": "Ривароксабан",
                        "dose": "20мг 1р/день с едой (CrCl>50)",
                        "monitoring": "Не требуется",
                        "reversal": "Андексанет альфа"
                    }
                ]
            }
        
        elif category == "aaa_sizes":
            return {
                "title": "Размеры ААА и показания к лечению",
                "items": [
                    {
                        "size": "<3.0 см",
                        "action": "Норма",
                        "surveillance": "Не требуется"
                    },
                    {
                        "size": "3.0-3.9 см",
                        "action": "Маленькая ААА",
                        "surveillance": "УЗИ каждые 2-3 года"
                    },
                    {
                        "size": "4.0-4.9 см",
                        "action": "Средняя ААА",
                        "surveillance": "УЗИ/КТ каждые 12 месяцев"
                    },
                    {
                        "size": "5.0-5.4 см",
                        "action": "Большая ААА",
                        "surveillance": "КТ каждые 6 месяцев"
                    },
                    {
                        "size": "≥5.5 см",
                        "action": "Рекомендуется ремонт",
                        "surveillance": "Немедленная оценка"
                    }
                ]
            }
        
        return {"title": "Справочник не найден", "items": []}