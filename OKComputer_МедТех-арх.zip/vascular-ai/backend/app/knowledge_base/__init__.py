"""
Medical Knowledge Base Module
Модуль медицинского справочника
"""

from app.knowledge_base.models import (
    KBArticle,
    KBCategory,
    KBTag,
    KBMedication,
    KBDisease,
    KBProcedure,
    KBGuideline,
    KBArticleVersion,
    KBArticleFavorite,
    KBSearchLog,
    ArticleType,
    EvidenceLevel
)

from app.knowledge_base.service import KnowledgeBaseService

__all__ = [
    # Models
    "KBArticle",
    "KBCategory",
    "KBTag",
    "KBMedication",
    "KBDisease",
    "KBProcedure",
    "KBGuideline",
    "KBArticleVersion",
    "KBArticleFavorite",
    "KBSearchLog",
    # Enums
    "ArticleType",
    "EvidenceLevel",
    # Service
    "KnowledgeBaseService"
]