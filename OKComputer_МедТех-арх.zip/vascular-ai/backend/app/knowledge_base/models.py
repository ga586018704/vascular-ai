"""
Medical Knowledge Base Module - Models
Модели для медицинского справочника
"""

from datetime import datetime
from enum import Enum
from typing import Optional, List, Dict, Any
from uuid import uuid4

from sqlalchemy import (
    Column, String, DateTime, ForeignKey, Text, 
    Boolean, Integer, Float, JSON, Index, Table
)
from sqlalchemy.dialects.postgresql import UUID, ARRAY
from sqlalchemy.orm import relationship

from app.db.base_class import Base


# Связующая таблица для many-to-many
article_category = Table(
    'article_categories',
    Base.metadata,
    Column('article_id', UUID(as_uuid=True), ForeignKey('kb_articles.id')),
    Column('category_id', UUID(as_uuid=True), ForeignKey('kb_categories.id'))
)

article_tag = Table(
    'article_tags',
    Base.metadata,
    Column('article_id', UUID(as_uuid=True), ForeignKey('kb_articles.id')),
    Column('tag_id', UUID(as_uuid=True), ForeignKey('kb_tags.id'))
)

article_related = Table(
    'article_related',
    Base.metadata,
    Column('article_id', UUID(as_uuid=True), ForeignKey('kb_articles.id')),
    Column('related_article_id', UUID(as_uuid=True), ForeignKey('kb_articles.id'))
)


class ArticleType(str, Enum):
    """Типы статей справочника"""
    DISEASE = "disease"  # Заболевание
    SYMPTOM = "symptom"  # Симптом
    DIAGNOSTIC = "diagnostic"  # Диагностика
    TREATMENT = "treatment"  # Лечение
    MEDICATION = "medication"  # Лекарственный препарат
    PROCEDURE = "procedure"  # Медицинская процедура
    LAB_TEST = "lab_test"  # Лабораторный тест
    GUIDELINE = "guideline"  # Клиническое руководство
    PROTOCOL = "protocol"  # Протокол лечения
    ANATOMY = "anatomy"  # Анатомия
    EQUIPMENT = "equipment"  # Медицинское оборудование
    GENERAL = "general"  # Общая информация


class EvidenceLevel(str, Enum):
    """Уровни доказательности"""
    IA = "Ia"  # Систематические обзоры RCT
    IB = "Ib"  # Отдельные RCT
    IIA = "IIa"  # Систематические обзоры когортных
    IIB = "IIb"  # Отдельные когортные
    III = "III"  # Исследования случай-контроль
    IV = "IV"  # Когорты/случаи без контроля
    V = "V"  # Экспертное мнение


class KBCategory(Base):
    """Категория справочника"""
    __tablename__ = "kb_categories"
    
    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid4)
    
    # Иерархия
    parent_id = Column(UUID(as_uuid=True), ForeignKey("kb_categories.id"), nullable=True)
    
    code = Column(String(50), unique=True, nullable=False, index=True)
    name = Column(String(200), nullable=False)
    name_en = Column(String(200))
    description = Column(Text)
    
    # Для дерева категорий
    level = Column(Integer, default=0)
    path = Column(String(500))  # Путь в дереве (например: /1/2/5/)
    sort_order = Column(Integer, default=0)
    
    # Метаданные
    icon = Column(String(100))
    color = Column(String(7))  # HEX цвет
    is_active = Column(Boolean, default=True)
    is_visible = Column(Boolean, default=True)
    
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    # Связи
    parent = relationship("KBCategory", remote_side=[id], backref="children")
    articles = relationship("KBArticle", secondary=article_category, back_populates="categories")


class KBTag(Base):
    """Тег для статей"""
    __tablename__ = "kb_tags"
    
    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid4)
    
    code = Column(String(50), unique=True, nullable=False, index=True)
    name = Column(String(100), nullable=False)
    description = Column(Text)
    
    # Для синонимов
    synonyms = Column(ARRAY(String), default=list)
    
    # Метаданные
    usage_count = Column(Integer, default=0)
    is_active = Column(Boolean, default=True)
    
    created_at = Column(DateTime, default=datetime.utcnow)
    
    # Связи
    articles = relationship("KBArticle", secondary=article_tag, back_populates="tags")


class KBArticle(Base):
    """Статья справочника"""
    __tablename__ = "kb_articles"
    
    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid4)
    
    # Основная информация
    code = Column(String(100), unique=True, nullable=False, index=True)
    title = Column(String(500), nullable=False)
    title_en = Column(String(500))
    article_type = Column(String(50), nullable=False, index=True)
    
    # Контент
    summary = Column(Text)  # Краткое описание
    content = Column(Text)  # Полный текст
    content_html = Column(Text)  # HTML версия
    
    # Структурированные данные
    key_points = Column(ARRAY(Text), default=list)  # Ключевые моменты
    sections = Column(JSON, default=dict)  # Структурированные секции
    
    # ICD-10 коды
    icd10_codes = Column(ARRAY(String), default=list)
    
    # Медицинские коды
    snomed_ct = Column(ARRAY(String), default=list)
    mesh_terms = Column(ARRAY(String), default=list)
    
    # Доказательная база
    evidence_level = Column(String(10))
    evidence_summary = Column(Text)
    
    # Источники
    sources = Column(JSON, default=list)  # [{"title": "...", "url": "...", "type": "guideline"}]
    references = Column(JSON, default=list)  # Список литературы
    
    # Авторство
    author_id = Column(UUID(as_uuid=True), ForeignKey("users.id"))
    reviewer_id = Column(UUID(as_uuid=True), ForeignKey("users.id"))
    
    # Статус
    status = Column(String(50), default="draft")  # draft, review, published, archived
    published_at = Column(DateTime)
    
    # SEO и поиск
    keywords = Column(ARRAY(String), default=list)
    search_text = Column(Text)  # Для полнотекстового поиска
    
    # Статистика
    view_count = Column(Integer, default=0)
    favorite_count = Column(Integer, default=0)
    
    # Метаданные
    version = Column(Integer, default=1)
    is_active = Column(Boolean, default=True)
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    # Связи
    categories = relationship("KBCategory", secondary=article_category, back_populates="articles")
    tags = relationship("KBTag", secondary=article_tag, back_populates="articles")
    related_articles = relationship(
        "KBArticle", 
        secondary=article_related,
        primaryjoin=id == article_related.c.article_id,
        secondaryjoin=id == article_related.c.related_article_id,
        backref="referenced_by"
    )
    
    __table_args__ = (
        Index('ix_kb_articles_search', 'search_text'),
        Index('ix_kb_articles_type_status', 'article_type', 'status'),
    )


class KBMedication(Base):
    """Лекарственный препарат"""
    __tablename__ = "kb_medications"
    
    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid4)
    
    # Идентификаторы
    article_id = Column(UUID(as_uuid=True), ForeignKey("kb_articles.id"))
    atc_code = Column(String(20), index=True)  # ATC классификация
    
    # Названия
    generic_name = Column(String(500), nullable=False)
    brand_names = Column(ARRAY(String), default=list)
    
    # Классификация
    drug_class = Column(String(200))
    drug_subclass = Column(String(200))
    
    # Фармакология
    mechanism = Column(Text)  # Механизм действия
    pharmacokinetics = Column(JSON, default=dict)  # Фармакокинетика
    
    # Показания и противопоказания
    indications = Column(ARRAY(Text), default=list)
    contraindications = Column(ARRAY(Text), default=list)
    
    # Дозировка
    dosage_adult = Column(JSON, default=dict)  # {route, dose, frequency, max_dose}
    dosage_pediatric = Column(JSON, default=dict)
    dosage_elderly = Column(JSON, default=dict)
    dosage_renal = Column(JSON, default=dict)
    dosage_hepatic = Column(JSON, default=dict)
    
    # Побочные эффекты
    side_effects_common = Column(ARRAY(Text), default=list)
    side_effects_serious = Column(ARRAY(Text), default=list)
    
    # Взаимодействия
    drug_interactions = Column(JSON, default=list)
    food_interactions = Column(ARRAY(Text), default=list)
    
    # Особые группы
    pregnancy_category = Column(String(10))  # A, B, C, D, X
    lactation_safety = Column(String(50))
    
    # Мониторинг
    monitoring_parameters = Column(ARRAY(Text), default=list)
    therapeutic_range = Column(JSON, default=dict)
    
    # Метаданные
    is_active = Column(Boolean, default=True)
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)


class KBDisease(Base):
    """Заболевание"""
    __tablename__ = "kb_diseases"
    
    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid4)
    
    article_id = Column(UUID(as_uuid=True), ForeignKey("kb_articles.id"))
    
    # Классификация
    disease_type = Column(String(100))  # acute, chronic, congenital, etc.
    body_system = Column(String(100))  # cardiovascular, respiratory, etc.
    
    # Эпидемиология
    prevalence = Column(Text)
    risk_factors = Column(ARRAY(Text), default=list)
    
    # Клиническая картина
    symptoms = Column(JSON, default=list)  # [{"symptom": "...", "frequency": "common"}]
    signs = Column(ARRAY(Text), default=list)
    
    # Диагностика
    diagnostic_criteria = Column(Text)
    diagnostic_tests = Column(JSON, default=list)  # Рекомендуемые тесты
    differential_diagnosis = Column(ARRAY(Text), default=list)
    
    # Лечение
    treatment_overview = Column(Text)
    treatment_options = Column(JSON, default=list)
    
    # Прогноз
    prognosis = Column(Text)
    complications = Column(ARRAY(Text), default=list)
    
    # Профилактика
    prevention = Column(Text)
    screening = Column(Text)
    
    # Метаданные
    is_active = Column(Boolean, default=True)
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)


class KBProcedure(Base):
    """Медицинская процедура"""
    __tablename__ = "kb_procedures"
    
    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid4)
    
    article_id = Column(UUID(as_uuid=True), ForeignKey("kb_articles.id"))
    
    # Классификация
    procedure_type = Column(String(100))  # surgical, diagnostic, therapeutic
    specialty = Column(String(100))
    
    # Показания и противопоказания
    indications = Column(ARRAY(Text), default=list)
    contraindications_absolute = Column(ARRAY(Text), default=list)
    contraindications_relative = Column(ARRAY(Text), default=list)
    
    # Подготовка
    preoperative_preparation = Column(Text)
    required_tests = Column(ARRAY(Text), default=list)
    
    # Техника
    technique_description = Column(Text)
    steps = Column(ARRAY(Text), default=list)
    duration = Column(String(50))
    
    # Анестезия
    anesthesia_options = Column(ARRAY(Text), default=list)
    
    # Послеоперационный период
    postoperative_care = Column(Text)
    recovery_time = Column(String(100))
    follow_up = Column(Text)
    
    # Риски и осложнения
    risks = Column(ARRAY(Text), default=list)
    complications = Column(JSON, default=list)  # [{"complication": "...", "incidence": "5%"}]
    
    # Исходы
    success_rate = Column(String(50))
    outcomes = Column(Text)
    
    # Метаданные
    is_active = Column(Boolean, default=True)
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)


class KBGuideline(Base):
    """Клиническое руководство"""
    __tablename__ = "kb_guidelines"
    
    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid4)
    
    article_id = Column(UUID(as_uuid=True), ForeignKey("kb_articles.id"))
    
    # Информация о руководстве
    organization = Column(String(200))  # ESVS, SVS, ACC/AHA, etc.
    guideline_year = Column(Integer)
    version = Column(String(50))
    
    # Область применения
    target_population = Column(Text)
    scope = Column(Text)
    
    # Рекомендации
    recommendations = Column(JSON, default=list)  # Структурированные рекомендации
    
    # Алгоритмы
    algorithms = Column(JSON, default=list)  # Диагностические/лечебные алгоритмы
    
    # Ключевые моменты
    key_recommendations = Column(ARRAY(Text), default=list)
    
    # Метаданные
    is_active = Column(Boolean, default=True)
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)


class KBArticleVersion(Base):
    """Версия статьи (история изменений)"""
    __tablename__ = "kb_article_versions"
    
    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid4)
    
    article_id = Column(UUID(as_uuid=True), ForeignKey("kb_articles.id"))
    version = Column(Integer, nullable=False)
    
    # Контент версии
    content = Column(Text)
    changes_summary = Column(Text)  # Описание изменений
    
    # Автор изменения
    changed_by = Column(UUID(as_uuid=True), ForeignKey("users.id"))
    changed_at = Column(DateTime, default=datetime.utcnow)
    
    # Причина изменения
    change_reason = Column(Text)


class KBArticleFavorite(Base):
    """Избранные статьи пользователя"""
    __tablename__ = "kb_article_favorites"
    
    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid4)
    
    user_id = Column(UUID(as_uuid=True), ForeignKey("users.id"), nullable=False)
    article_id = Column(UUID(as_uuid=True), ForeignKey("kb_articles.id"), nullable=False)
    
    notes = Column(Text)  # Персональные заметки
    
    created_at = Column(DateTime, default=datetime.utcnow)
    
    __table_args__ = (
        Index('ix_kb_favorites_user_article', 'user_id', 'article_id', unique=True),
    )


class KBSearchLog(Base):
    """Лог поисковых запросов"""
    __tablename__ = "kb_search_logs"
    
    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid4)
    
    user_id = Column(UUID(as_uuid=True), ForeignKey("users.id"), nullable=True)
    query = Column(String(500), nullable=False)
    
    # Результаты
    results_count = Column(Integer)
    clicked_article_id = Column(UUID(as_uuid=True), ForeignKey("kb_articles.id"))
    
    # Метаданные
    search_filters = Column(JSON, default=dict)
    response_time_ms = Column(Integer)
    
    created_at = Column(DateTime, default=datetime.utcnow)
    
    __table_args__ = (
        Index('ix_kb_search_logs_query', 'query'),
        Index('ix_kb_search_logs_created', 'created_at'),
    )