"""
Book and Scientific Data Integration
Интеграция данных из книг и научных источников
"""

from typing import Dict, List, Any


class BookReference:
    """Ссылка на книгу или научный источник"""
    
    def __init__(
        self,
        title: str,
        authors: List[str],
        year: int,
        publisher: str,
        isbn: str = None,
        doi: str = None,
        url: str = None
    ):
        self.title = title
        self.authors = authors
        self.year = year
        self.publisher = publisher
        self.isbn = isbn
        self.doi = doi
        self.url = url
    
    def to_dict(self) -> Dict[str, Any]:
        return {
            "title": self.title,
            "authors": self.authors,
            "year": self.year,
            "publisher": self.publisher,
            "isbn": self.isbn,
            "doi": self.doi,
            "url": self.url
        }


class ScientificDataStore:
    """Хранилище научных данных из книг и источников"""
    
    # Книги в базе
    BOOKS = {
        "chronic_venous_disorders": BookReference(
            title="Chronic Venous Disorders of the Lower Limbs: A Surgical Approach",
            authors=["Subramoniam Vaidyanathan", "Riju Ramachandran Menon", "Pradeep Jacob", "Binni John"],
            year=2015,
            publisher="Springer India",
            isbn="978-81-322-1991-0",
            doi="10.1007/978-81-322-1991-0",
            url="https://link.springer.com/book/10.1007/978-81-322-1991-0"
        ),
        "lymphedema_bergan": BookReference(
            title="Lymphedema: A Concise Compendium of Theory and Practice",
            authors=["Byung-Boong Lee", "John Bergan", "Stanley G. Rockson"],
            year=2011,
            publisher="Springer",
            isbn="978-0-85729-566-8",
            doi="10.1007/978-0-85729-566-8"
        ),
        "acrs_contrast_manual": BookReference(
            title="ACR Manual on Contrast Media",
            authors=["American College of Radiology"],
            year=2023,
            publisher="American College of Radiology",
            url="https://www.acr.org/Clinical-Resources/Contrast-Manual"
        ),
        "complications_endovascular": BookReference(
            title="Complications in Vascular and Endovascular Surgery",
            authors=["Alain Branchereau", "Michael Jacobs"],
            year=2017,
            publisher="Wiley-Blackwell",
            isbn="978-1-119-23487-3"
        )
    }
    
    # Данные из книг по категориям
    VENOUS_DISORDERS = {
        "ceap_classification": {
            "source": "chronic_venous_disorders",
            "title": "CEAP Classification of Chronic Venous Disorders",
            "content": """
            Классификация CEAP (Clinical, Etiological, Anatomical, Pathophysiological):
            
            C - Клинические классы:
            C0: Нет видимых признаков венозной болезни
            C1: Телеангиэктазии или ретикулярные вены
            C2: Варикозные вены
            C3: Отеки
            C4a: Пигментация или экзема
            C4b: Липодерматосклероз или атрофия белой кожи
            C5: Заживший венозный язвенный дефект
            C6: Активный венозный язвенный дефект
            
            E - Этиология:
            Ec: Врожденная
            Ep: Первичная
            Es: Вторичная (посттромботическая)
            En: Нет венозной этиологии
            
            A - Анатомическое распределение:
            As: Поверхностные вены
            Ad: Глубокие вены
            Ap: Перфорантные вены
            
            P - Патофизиология:
            Pr: Рефлюкс
            Po: Обструкция
            Pr,o: Рефлюкс и обструкция
            Pn: Нет патофизиологических изменений
            """,
            "key_points": [
                "CEAP - стандартизированная классификация хронических венозных заболеваний",
                "Обновлена в 2020 году (ревизия CEAP)",
                "Обязательна для документации и исследований"
            ]
        },
        
        "endovenous_laser": {
            "source": "chronic_venous_disorders",
            "title": "Эндовенозная лазерная абляция (EVLA)",
            "content": """
            Эндовенозная лазерная абляция - минимально инвазивный метод лечения 
            варикозных вен с использованием лазерной энергии.
            
            Показания:
            - Варикозные вены GSV/SSV с рефлюксом
            - CEAP C2-C6
            - Диаметр вены 2-15 мм
            
            Техника:
            1. Тумесцентная анестезия
            2. Введение лазерного волокна
            3. Энергия: 50-100 J/cm
            4. Длина волны: 810-1470 нм
            
            Результаты:
            - Успех: 93-98% через 5 лет
            - Рецидив: 5-15%
            - Возврат к работе: 1-2 дня
            """,
            "key_points": [
                "Золотой стандарт лечения GSV рефлюкса",
                "Может выполняться в амбулаторных условиях",
                "Меньше боли по сравнению с хирургией"
            ]
        },
        
        "radiofrequency_ablation": {
            "source": "chronic_venous_disorders",
            "title": "Радиочастотная абляция (RFA)",
            "content": """
            Радиочастотная абляция - метод термического закрытия вен с 
            использованием радиочастотной энергии.
            
            Преимущества:
            - Меньше боли (нет парового пузыря)
            - Меньше гематом
            - Быстрое восстановление
            
            Техника:
            1. Тумесцентная анестезия
            2. Введение катетера ClosureFast
            3. Температура: 120°C
            4. Время: 20 сек на сегмент
            
            Результаты:
            - Успех: 90-95% через 5 лет
                - Удовлетворенность пациентов: >90%
            """,
            "key_points": [
                "ClosureFast - наиболее изученная система",
                "Рекомендована NICE (Великобритания)",
                "Можно выполнять без тумесценции (ClosureFast Flex)"
            ]
        },
        
        "foam_sclerotherapy": {
            "source": "chronic_venous_disorders",
            "title": "Пенная склеротерапия",
            "content": """
            Пенная склеротерапия - введение склерозанта в виде пены 
            для закрытия варикозных вен.
            
            Склерозанты:
            - Натрия тетрадецилсульфат (STD)
            - Полидоканол (Aethoxysklerol)
            - Моррhuат натрия
            
            Концентрации:
            - Телеангиэктазии: 0.25-0.5%
            - Ретикулярные вены: 0.5-1%
            - Варикозные вены: 1-3%
            
            Объем пены: 2-8 мл на инъекцию
            Максимум: 10 мл за сессию
            
            Осложнения:
            - Пигментация (10-30%)
            - Матting (5-15%)
            - Тромбофлебит (5-10%)
            - Визуальные расстройства (<1%)
            - Неврологические осложнения (<0.1%)
            """,
            "key_points": [
                "Tessari technique - стандарт приготовления пены",
                "Контроль УЗИ обязателен",
                "Не рекомендуется при PFO (патентный овальный замок)"
            ]
        },
        
        "venous_ulcers": {
            "source": "chronic_venous_disorders",
            "title": "Венозные язвы: диагностика и лечение",
            "content": """
            Венозные язвы - наиболее тяжелая форма хронической 
            венозной недостаточности (CEAP C6).
            
            Эпидемиология:
            - Распространенность: 1-2% населения
            - Средний возраст: 65-70 лет
            - Рецидив: 70% без компрессии
            
            Лечение:
            1. Компрессионная терапия (30-40 мм рт.ст.)
            2. Рана: влажная среда, дебридмент
            3. Лечение венозной гипертензии
            4. Мобилизация пациента
            
            Хирургия:
            - Абляция GSV
            - Склеротерапия перфорантов
            - Subfascial endoscopic perforator surgery (SEPS)
            
            Заживление:
            - С компрессией: 60-70% за 12 недель
            - С абляцией: 80-90% за 12 недель
            """,
            "key_points": [
                "Компрессия - основа лечения",
                "Лечение рефлюкса ускоряет заживление",
                "Профилактика рецидива - пожизненная компрессия"
            ]
        }
    }
    
    LYMPHEDEMA = {
        "staging_isl": {
            "source": "lymphedema_bergan",
            "title": "ISL Staging of Lymphedema",
            "content": """
            Международная классификация лимфедемы (International Society of Lymphology):
            
            Стадия 0 (латентная):
            - Нет видимого отека
            - Нарушение лимфотранспорта
            - Субъективные симптомы (тяжесть, дискомфорт)
            
            Стадия I (обратимая):
            - Мягкий отек
            - Уменьшается при поднятии конечности
            - Нет фиброза
            
            Стадия II (необратимая):
            - Отек не уменьшается при поднятии
            - Фиброз тканей
            - Позитивный Stemmer sign
            
            Стадия III (лимфостатический слоновидность):
            - Трофические изменения кожи
            - Папилломатоз
            - Нарушение функции конечности
            """,
            "key_points": [
                "Stemmer sign - неспособность поднять кожную складку на пальцах",
                "Ранняя диагностика критична для успеха лечения",
                "Комплексная деконгестивная терапия (CDT) - золотой стандарт"
            ]
        },
        
        "cdt_therapy": {
            "source": "lymphedema_bergan",
            "title": "Комплексная деконгестивная терапия (CDT)",
            "content": """
            CDT - комплексный подход к лечению лимфедемы, включающий:
            
            1. Ручной лимфодренаж (MLD):
               - Техника Vodder
               - 45-60 минут
               - Ежедневно 2-4 недели
            
            2. Многослойная компрессионная повязка:
               - Подкладочный слой
               - Ватные подушечки
               - Короткие растягивающиеся бинты
               - Давление: 40-60 мм рт.ст.
            
            3. Упражнения:
               - Активация мышечного насоса
               - С компрессией
               - Индивидуальная программа
            
            4. Уход за кожей:
               - Увлажнение
               - Профилактика инфекции
               - Обработка ран
            
            Фазы:
            - Фаза 1 (интенсивная): 2-4 недели
            - Фаза 2 (поддерживающая): пожизненно
            """,
            "key_points": [
                "Требует сертифицированного терапевта",
                "Пациентское образование критично",
                "Самоменеджмент - ключ к успеху"
            ]
        }
    }
    
    CONTRAST_MEDIA = {
        "cin_prevention": {
            "source": "acrs_contrast_manual",
            "title": "Профилактика контраст-индуцированной нефропатии (CIN)",
            "content": """
            Контраст-индуцированная нефропатия - острое ухудшение функции почек
            после введения йодсодержащего контраста.
            
            Риск:
            - Общая популяция: 1-2%
            - СКФ <60: 10-20%
            - СКФ <30: 20-40%
            
            Факторы риска:
            - Хроническая болезнь почек
            - Диабет
            - Дегидратация
            - Сердечная недостаточность
            - Возраст >75 лет
            - Большой объем контраста
            
            Профилактика:
            1. Гидратация:
               - Изотонический раствор NaCl 1 мл/кг/ч
               - За 12 часов до и после
            2. Минимизация дозы контраста
            3. Отмена нефротоксичных препаратов
            4. N-ацетилцистеин (необязательно)
            
            Контраст:
            - Изоосмолярные (iodixanol) - безопаснее
            - Низкоосмолярные - альтернатива
            """,
            "key_points": [
                "Гидратация - основа профилактики",
                "Оценка СКФ обязательна перед КТ",
                "Метформин - отменить за 48 часов"
            ]
        },
        
        "contrast_reactions": {
            "source": "acrs_contrast_manual",
            "title": "Реакции на контраст: профилактика и лечение",
            "content": """
            Немедленные реакции на йодсодержащий контраст:
            
            Частота:
            - Ионные высокоосмолярные: 5-15%
            - Неионные низкоосмолярные: 1-3%
            - Идиосинкразические: 0.04-0.1%
            
            Факторы риска:
            - Аллергия на контраст (4-6x)
            - Бронхиальная астма
            - Аллергические заболевания
            - Тревожность
            
            Профилактика:
            - Предварительная медикация:
              * Преднизолон 50 мг per os за 13, 7, 1 час
              * Или метилпреднизолон 32 мг per os за 12, 2 часа
            - H1-антагонисты (димедрол 50 мг)
            - H2-антагонисты (ранитидин 50 мг)
            
            Лечение анафилаксии:
            1. Эпинефрин 1:1000, 0.1-0.3 мл IM
            2. Кислород 10-15 л/мин
            3. В/в жидкости
            4. H1/H2 блокаторы
            5. Глюкокортикоиды
            """,
            "key_points": [
                "Неионные контрасты безопаснее",
                "Предмедикация при высоком риске",
                "Эпинефрин - первоочередное средство"
            ]
        }
    }
    
    ENDOVASCULAR_COMPLICATIONS = {
        "access_complications": {
            "source": "complications_endovascular",
            "title": "Осложнения сосудистого доступа",
            "content": """
            Осложнения пункции артерии:
            
            1. Гематома (2-10%):
               - Профилактика: правильная техника, давление
               - Лечение: компрессия, редко хирургия
            
            2. Псевдоаневризма (0.5-5%):
               - Диагностика: УЗИ с допплером
               - Лечение: УЗИ-направленная компрессия, тромбиновая инъекция
            
            3. АВ-фистула (<1%):
               - Спонтанное закрытие: 50%
               - Лечение: эмболизация или хирургия
            
            4. Диссекция (1-3%):
               - Чаще при повторных пункциях
               - Лечение: стентирование при гемодинамической значимости
            
            5. Тромбоз доступа (1-5%):
               - Профилактика: гепарин
               - Лечение: тромбэктомия
            
            Факторы риска:
            - Ожирение
            - Гипертония
            - Антикоагулянты
            - Низкий puncture site
            """,
            "key_points": [
                "УЗИ-направленная пункция снижает риск",
                "Мануальная компрессия 10-15 минут",
                "Bed rest 4-6 часов после феморального доступа"
            ]
        },
        
        "stent_complications": {
            "source": "complications_endovascular",
            "title": "Осложнения стентирования",
            "content": """
            Осложнения при стентировании:
            
            1. Стентовый тромбоз (2-5%):
               - Ранний (<30 дней): неоптимальная деплояция
               - Поздний: неоинтимальная гиперплазия
               - Лечение: тромболиз, повторная ангиопластика
            
            2. Инстент-рестеноз (10-30%):
               - Чаще в малых сосудах
               - Факторы: диабет, длина поражения
               - Лечение: повторная ангиопластика, DES, DCB
            
            3. Стентовая фрактура (2-10%):
               - Чаще в подколенной артерии
               - Риск: длина стента, движение сустава
               - Лечение: повторное стентирование
            
            4. Эмболизация (2-5%):
               - Профилактика: защитные устройства
               - Лечение: аспирация, тромбэктомия
            
            Профилактика:
            - Двойная антиагрегантная терапия (ДАПТ)
            - Аспирин 75-100 мг + клопидогрел 75 мг
            - Длительность: минимум 1 месяц
            """,
            "key_points": [
                "Оптимальная деплояция критична",
                "ДАПТ снижает риск тромбоза",
                "Контроль УЗИ для мониторинга"
            ]
        }
    }
    
    # Клинические руководства
    CLINICAL_GUIDELINES = {
        "esvs_aaa_2024": {
            "organization": "ESVS",
            "year": 2024,
            "title": "ESVS Guidelines on Aortic Disease 2024",
            "key_recommendations": [
                {
                    "recommendation": "Ремонт AAA рекомендуется при диаметре ≥55 мм",
                    "class": "I",
                    "level": "A",
                    "applies_to": ["men", "women"]
                },
                {
                    "recommendation": "EVAR предпочтительнее открытого ремонта при подходящей анатомии",
                    "class": "I",
                    "level": "A",
                    "applies_to": ["all"]
                },
                {
                    "recommendation": "Скрининг УЗИ для мужчин 65-75 лет с историей курения",
                    "class": "I",
                    "level": "B",
                    "applies_to": ["men_65_75_smokers"]
                }
            ]
        },
        
        "esvs_clti_2023": {
            "organization": "ESVS",
            "year": 2023,
            "title": "ESVS Guidelines on Chronic Limb-Threatening Ischemia",
            "key_recommendations": [
                {
                    "recommendation": "Ревascularизация рекомендуется при CLTI",
                    "class": "I",
                    "level": "A"
                },
                {
                    "recommendation": "Оценка риска ампутации (WIfI)",
                    "class": "I",
                    "level": "B"
                },
                {
                    "recommendation": "Медикаментозная терапия: статины, антиагреганты",
                    "class": "I",
                    "level": "A"
                }
            ]
        },
        
        "acc_aha_pad_2016": {
            "organization": "ACC/AHA",
            "year": 2016,
            "title": "ACC/AHA Guidelines for Management of PAD",
            "key_recommendations": [
                {
                    "recommendation": "Антиагрегантная терапия для всех с PAD",
                    "class": "I",
                    "level": "A"
                },
                {
                    "recommendation": "Статины для снижения риска МАСС",
                    "class": "I",
                    "level": "A"
                },
                {
                    "recommendation": "Контроль АД <140/90 мм рт.ст.",
                    "class": "I",
                    "level": "A"
                }
            ]
        }
    }
    
    @classmethod
    def get_all_articles(cls) -> List[Dict[str, Any]]:
        """Получить все статьи для загрузки в knowledge base"""
        articles = []
        
        # Венозные заболевания
        for key, data in cls.VENOUS_DISORDERS.items():
            articles.append({
                "code": key,
                "title": data["title"],
                "article_type": "disease",
                "content": data["content"],
                "key_points": data.get("key_points", []),
                "category": "venous_disease",
                "source": data["source"]
            })
        
        # Лимфедема
        for key, data in cls.LYMPHEDEMA.items():
            articles.append({
                "code": key,
                "title": data["title"],
                "article_type": "disease",
                "content": data["content"],
                "key_points": data.get("key_points", []),
                "category": "lymphedema",
                "source": data["source"]
            })
        
        # Контрастные вещества
        for key, data in cls.CONTRAST_MEDIA.items():
            articles.append({
                "code": key,
                "title": data["title"],
                "article_type": "procedure",
                "content": data["content"],
                "key_points": data.get("key_points", []),
                "category": "contrast_media",
                "source": data["source"]
            })
        
        # Эндоваскулярные осложнения
        for key, data in cls.ENDOVASCULAR_COMPLICATIONS.items():
            articles.append({
                "code": key,
                "title": data["title"],
                "article_type": "procedure",
                "content": data["content"],
                "key_points": data.get("key_points", []),
                "category": "endovascular",
                "source": data["source"]
            })
        
        return articles
    
    @classmethod
    def get_guidelines(cls) -> List[Dict[str, Any]]:
        """Получить клинические руководства"""
        guidelines = []
        
        for key, data in cls.CLINICAL_GUIDELINES.items():
            guidelines.append({
                "code": key,
                "title": data["title"],
                "organization": data["organization"],
                "year": data["year"],
                "article_type": "guideline",
                "recommendations": data["key_recommendations"]
            })
        
        return guidelines
    
    @classmethod
    def get_book_reference(cls, book_key: str) -> Dict[str, Any]:
        """Получить информацию о книге"""
        book = cls.BOOKS.get(book_key)
        if book:
            return book.to_dict()
        return None
    
    @classmethod
    def search_content(cls, query: str) -> List[Dict[str, Any]]:
        """Поиск по содержимому книг"""
        results = []
        query_lower = query.lower()
        
        all_content = []
        all_content.extend(cls.get_all_articles())
        all_content.extend(cls.get_guidelines())
        
        for item in all_content:
            if (
                query_lower in item.get("title", "").lower() or
                query_lower in item.get("content", "").lower() or
                any(query_lower in kp.lower() for kp in item.get("key_points", []))
            ):
                results.append(item)
        
        return results