from sqlalchemy.ext.asyncio import create_async_engine, AsyncSession, async_sessionmaker
from sqlalchemy.orm import declarative_base
from sqlalchemy import Column, Integer, String, DateTime, Float, Text, Boolean, ForeignKey, JSON
from datetime import datetime

from app.core.config import get_settings

settings = get_settings()

# Database engine (SQLite for simplicity)
engine = create_async_engine(
    "sqlite+aiosqlite:///./vascular.db",
    echo=settings.DEBUG,
    future=True
)

# Session factory
AsyncSessionLocal = async_sessionmaker(
    engine,
    class_=AsyncSession,
    expire_on_commit=False
)

# Base class for models
Base = declarative_base()


# Models
class User(Base):
    __tablename__ = "users"
    
    id = Column(Integer, primary_key=True, index=True)
    email = Column(String(255), unique=True, index=True, nullable=False)
    hashed_password = Column(String(255), nullable=False)
    full_name = Column(String(255), nullable=False)
    is_active = Column(Boolean, default=True)
    is_superuser = Column(Boolean, default=False)
    license_number = Column(String(100), nullable=True)
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)


class MedicalStudy(Base):
    """Универсальная модель для всех типов медицинских исследований"""
    __tablename__ = "medical_studies"
    
    id = Column(Integer, primary_key=True, index=True)
    user_id = Column(Integer, ForeignKey("users.id"), nullable=False)
    patient_id = Column(String(100), nullable=False)  # Anonymized
    study_uid = Column(String(255), unique=True, nullable=False)
    study_date = Column(DateTime, nullable=True)
    study_description = Column(String(500), nullable=True)
    
    # Тип исследования
    study_type = Column(String(50), nullable=False)  # ct_angio, mra, duplex_us, echo, dicom_legacy
    modality = Column(String(20), default="CT")  # CT, MRI, US, Echo, XA
    
    # Количество изображений/срезов
    num_images = Column(Integer, default=0)
    
    # File paths
    file_path = Column(String(1000), nullable=False)  # Основной путь к файлам
    converted_path = Column(String(1000), nullable=True)  # Конвертированный формат (nifti и т.д.)
    
    # Status
    status = Column(String(50), default="uploaded")  # uploaded, processing, analyzed, error
    
    # Study metadata - зависит от типа исследования
    study_metadata = Column(JSON, nullable=True)
    
    # Специфичные поля для разных типов
    # Для КТ/МРТ
    voxel_spacing = Column(JSON, nullable=True)  # [x, y, z]
    image_size = Column(JSON, nullable=True)     # [width, height, depth]
    
    # Для УЗИ
    probe_frequency = Column(Float, nullable=True)  # MHz
    
    # Для ЭхоКГ
    echo_type = Column(String(20), nullable=True)  # TTE, TEE
    
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)


# Обратная совместимость - псевдоним
DicomStudy = MedicalStudy


class Segmentation(Base):
    __tablename__ = "segmentations"
    
    id = Column(Integer, primary_key=True, index=True)
    study_id = Column(Integer, ForeignKey("medical_studies.id"), nullable=False)
    user_id = Column(Integer, ForeignKey("users.id"), nullable=True)  # User who started segmentation
    
    # Segmentation results
    mask_path = Column(String(1000), nullable=True)
    classes = Column(JSON, nullable=True)  # List of segmented classes
    dice_scores = Column(JSON, nullable=True)  # Per-class Dice scores
    
    # Measurements
    measurements = Column(JSON, nullable=True)  # Auto-calculated measurements
    
    # Status
    status = Column(String(50), default="pending")  # pending, processing, completed, error
    error_message = Column(Text, nullable=True)
    
    created_at = Column(DateTime, default=datetime.utcnow)
    completed_at = Column(DateTime, nullable=True)


class UltrasoundMeasurement(Base):
    """Измерения при ультразвуковых исследованиях"""
    __tablename__ = "ultrasound_measurements"
    
    id = Column(Integer, primary_key=True, index=True)
    study_id = Column(Integer, ForeignKey("medical_studies.id"), nullable=False)
    
    # Тип исследования
    us_type = Column(String(50), nullable=False)  # carotid, venous, peripheral, abdominal
    
    # Сосуд
    vessel_name = Column(String(100), nullable=False)
    vessel_side = Column(String(10), nullable=True)  # left, right
    
    # Измерения
    diameter_mm = Column(Float, nullable=True)
    imt_mm = Column(Float, nullable=True)  # Intima-media thickness
    peak_systolic_velocity = Column(Float, nullable=True)  # cm/s
    end_diastolic_velocity = Column(Float, nullable=True)  # cm/s
    mean_velocity = Column(Float, nullable=True)  # cm/s
    
    # Индексы
    abi = Column(Float, nullable=True)  # Лодыжечно-плечевой индекс
    pi = Column(Float, nullable=True)  # Пульсационный индекс
    ri = Column(Float, nullable=True)  # Резистивный индекс
    
    # Стеноз
    stenosis_percent = Column(Float, nullable=True)
    stenosis_type = Column(String(50), nullable=True)  # calcified, soft, mixed
    
    # Для вен
    reflux_duration_sec = Column(Float, nullable=True)
    reflux_present = Column(Boolean, default=False)
    vein_diameter_mm = Column(Float, nullable=True)
    
    # Патология
    pathology = Column(JSON, nullable=True)
    
    created_at = Column(DateTime, default=datetime.utcnow)


class EchocardiographyMeasurement(Base):
    """Измерения ЭхоКГ"""
    __tablename__ = "echocardiography_measurements"
    
    id = Column(Integer, primary_key=True, index=True)
    study_id = Column(Integer, ForeignKey("medical_studies.id"), nullable=False)
    
    # Тип ЭхоКГ
    echo_type = Column(String(20), nullable=False)  # TTE, TEE
    
    # Аорта
    aortic_root_diameter = Column(Float, nullable=True)  # мм
    ascending_aorta_diameter = Column(Float, nullable=True)  # мм
    aortic_arch_diameter = Column(Float, nullable=True)  # мм
    descending_aorta_diameter = Column(Float, nullable=True)  # мм
    
    # Клапаны
    aortic_valve_area = Column(Float, nullable=True)  # см²
    aortic_regurgitation_grade = Column(String(20), nullable=True)  # none, mild, moderate, severe
    
    # Левый желудочек
    lvedd = Column(Float, nullable=True)  # Конечный диастолический размер
    lvesd = Column(Float, nullable=True)  # Конечный систолический размер
    lvef = Column(Float, nullable=True)  # Фракция выброса %
    
    # Патология
    dissection_present = Column(Boolean, default=False)
    dissection_type = Column(String(10), nullable=True)  # A, B
    intimal_flap = Column(Boolean, default=False)
    false_lumen = Column(Boolean, default=False)
    pericardial_effusion = Column(Boolean, default=False)
    
    # Дополнительные данные
    additional_findings = Column(JSON, nullable=True)
    
    created_at = Column(DateTime, default=datetime.utcnow)


class TASCEvaluation(Base):
    """Оценка по классификации TASC"""
    __tablename__ = "tasc_evaluations"
    
    id = Column(Integer, primary_key=True, index=True)
    study_id = Column(Integer, ForeignKey("medical_studies.id"), nullable=False)
    
    # Тип поражения
    lesion_type = Column(String(50), nullable=False)  # aortoiliac, femoropopliteal, infrapopliteal
    
    # TASC класс
    tasc_class = Column(String(10), nullable=False)  # A, B, C, D
    
    # Описание поражения
    lesion_description = Column(Text, nullable=True)
    
    # Рекомендации
    treatment_recommendation = Column(Text, nullable=True)
    alternative_treatment = Column(Text, nullable=True)
    evidence_level = Column(String(50), nullable=True)
    
    # Показания к операции
    indications = Column(JSON, nullable=True)
    contraindications = Column(JSON, nullable=True)
    
    created_at = Column(DateTime, default=datetime.utcnow)


class VesselMeasurement(Base):
    __tablename__ = "vessel_measurements"
    
    id = Column(Integer, primary_key=True, index=True)
    segmentation_id = Column(Integer, ForeignKey("segmentations.id"), nullable=True)
    study_id = Column(Integer, ForeignKey("medical_studies.id"), nullable=True)
    
    # Vessel info
    vessel_name = Column(String(100), nullable=False)  # aorta, iliac_right, etc.
    vessel_class = Column(String(50), nullable=False)  # artery, vein
    
    # Measurements (in mm)
    diameter_min = Column(Float, nullable=True)
    diameter_max = Column(Float, nullable=True)
    diameter_mean = Column(Float, nullable=True)
    length = Column(Float, nullable=True)
    volume = Column(Float, nullable=True)
    
    # Pathology
    has_pathology = Column(Boolean, default=False)
    pathology_type = Column(String(100), nullable=True)  # aneurysm, stenosis, thrombus, occlusion
    pathology_severity = Column(String(50), nullable=True)  # mild, moderate, severe
    
    # Location
    start_point = Column(JSON, nullable=True)  # [x, y, z]
    end_point = Column(JSON, nullable=True)    # [x, y, z]
    
    # Источник измерения
    measurement_source = Column(String(50), default="segmentation")  # segmentation, ultrasound, echo, manual
    
    created_at = Column(DateTime, default=datetime.utcnow)


class OperationProtocol(Base):
    __tablename__ = "operation_protocols"
    
    id = Column(Integer, primary_key=True, index=True)
    user_id = Column(Integer, ForeignKey("users.id"), nullable=False)
    study_id = Column(Integer, ForeignKey("medical_studies.id"), nullable=False)
    segmentation_id = Column(Integer, ForeignKey("segmentations.id"), nullable=True)
    
    # Protocol info
    protocol_type = Column(String(100), nullable=False)  # aortic_resection, thrombectomy, etc.
    title = Column(String(500), nullable=False)
    
    # Generated content
    content = Column(JSON, nullable=False)  # Structured protocol data
    pdf_path = Column(String(1000), nullable=True)
    
    # Status
    status = Column(String(50), default="draft")  # draft, generated, approved
    
    # Metadata
    surgeon_notes = Column(Text, nullable=True)
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)


class GraftSelection(Base):
    """Рекомендации по выбору протеза/шунта"""
    __tablename__ = "graft_selections"
    
    id = Column(Integer, primary_key=True, index=True)
    study_id = Column(Integer, ForeignKey("medical_studies.id"), nullable=False)
    protocol_id = Column(Integer, ForeignKey("operation_protocols.id"), nullable=True)
    
    # Тип процедуры
    procedure_type = Column(String(100), nullable=False)
    
    # Рекомендация
    primary_graft = Column(String(200), nullable=False)
    alternative_grafts = Column(JSON, nullable=True)
    
    # Обоснование
    rationale = Column(JSON, nullable=True)
    
    # Ожидаемая проходимость
    patency_expectations = Column(JSON, nullable=True)
    
    # Особые соображения
    special_considerations = Column(JSON, nullable=True)
    
    created_at = Column(DateTime, default=datetime.utcnow)


async def get_db():
    async with AsyncSessionLocal() as session:
        try:
            yield session
        finally:
            await session.close()


async def init_db():
    async with engine.begin() as conn:
        await conn.run_sync(Base.metadata.create_all)
