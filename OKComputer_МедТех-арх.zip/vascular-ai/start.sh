#!/bin/bash

# VASCULAR.AI - Startup Script v2.0
# AI-powered vascular surgery planning platform

set -e

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

echo -e "${BLUE}"
echo "╔════════════════════════════════════════════════════════════╗"
echo "║                                                            ║"
echo "║   VASCULAR.AI v2.0 - AI Decision Support System            ║"
echo "║   for Vascular Surgeons                                    ║"
echo "║                                                            ║"
echo "║   Integrated with ESVS 2024 Guidelines                     ║"
echo "║                                                            ║"
echo "╚════════════════════════════════════════════════════════════╝"
echo -e "${NC}"

# Function to print status
print_status() {
    echo -e "${BLUE}[INFO]${NC} $1"
}

print_success() {
    echo -e "${GREEN}[OK]${NC} $1"
}

print_warning() {
    echo -e "${YELLOW}[WARN]${NC} $1"
}

print_error() {
    echo -e "${RED}[ERROR]${NC} $1"
}

# Check if Docker is installed
check_docker() {
    print_status "Checking Docker installation..."
    if ! command -v docker &> /dev/null; then
        print_error "Docker is not installed. Please install Docker first."
        exit 1
    fi
    
    if ! command -v docker-compose &> /dev/null; then
        print_error "Docker Compose is not installed. Please install Docker Compose first."
        exit 1
    fi
    
    # Check if Docker is running
    if ! docker info &> /dev/null; then
        print_error "Docker is not running. Please start Docker first."
        exit 1
    fi
    
    print_success "Docker is installed and running"
}

# Check system requirements
check_requirements() {
    print_status "Checking system requirements..."
    
    # Check available memory
    if [[ "$OSTYPE" == "linux-gnu"* ]]; then
        AVAILABLE_MEM=$(free -m | awk '/^Mem:/{print $7}')
        if [ "$AVAILABLE_MEM" -lt 4096 ]; then
            print_warning "Available memory is less than 4GB. Performance may be affected."
        else
            print_success "Memory check passed"
        fi
    elif [[ "$OSTYPE" == "darwin"* ]]; then
        AVAILABLE_MEM=$(vm_stat | grep "Pages free" | awk '{print $3}' | sed 's/\.//')
        AVAILABLE_MEM=$((AVAILABLE_MEM * 4096 / 1024 / 1024))
        if [ "$AVAILABLE_MEM" -lt 4096 ]; then
            print_warning "Available memory is less than 4GB. Performance may be affected."
        else
            print_success "Memory check passed"
        fi
    fi
    
    # Check disk space
    AVAILABLE_DISK=$(df -m . | tail -1 | awk '{print $4}')
    if [ "$AVAILABLE_DISK" -lt 10240 ]; then
        print_warning "Available disk space is less than 10GB."
    else
        print_success "Disk space check passed"
    fi
}

# Create necessary directories
create_directories() {
    print_status "Creating necessary directories..."
    
    mkdir -p backend/data
    mkdir -p backend/uploads
    mkdir -p backend/processed
    mkdir -p backend/processed/protocols
    mkdir -p ai-service/models
    
    print_success "Directories created"
}

# Pull latest images
pull_images() {
    print_status "Pulling Docker images..."
    docker-compose pull 2>/dev/null || true
    print_success "Images pulled"
}

# Build and start services
start_services() {
    print_status "Building and starting services..."
    
    # Build services
    print_status "Building Docker images (this may take a few minutes)..."
    docker-compose build --no-cache
    
    # Start services
    print_status "Starting services..."
    docker-compose up -d
    
    print_success "Services started"
}

# Wait for services to be ready
wait_for_services() {
    print_status "Waiting for services to be ready..."
    
    # Wait for backend
    print_status "Waiting for backend API..."
    for i in {1..30}; do
        if curl -s http://localhost:8000/health > /dev/null 2>&1; then
            print_success "Backend API is ready"
            break
        fi
        sleep 2
        echo -n "."
    done
    
    # Wait for frontend
    print_status "Waiting for frontend..."
    for i in {1..30}; do
        if curl -s http://localhost:3000 > /dev/null 2>&1; then
            print_success "Frontend is ready"
            break
        fi
        sleep 2
        echo -n "."
    done
    
    echo ""
}

# Display service status
show_status() {
    echo ""
    echo -e "${GREEN}╔════════════════════════════════════════════════════════════╗${NC}"
    echo -e "${GREEN}║              VASCULAR.AI is running!                       ║${NC}"
    echo -e "${GREEN}╚════════════════════════════════════════════════════════════╝${NC}"
    echo ""
    echo -e "${BLUE}Services:${NC}"
    echo "  Frontend:    http://localhost:3000"
    echo "  Backend API: http://localhost:8000"
    echo "  API Docs:    http://localhost:8000/docs"
    echo "  AI Service:  http://localhost:8001"
    echo ""
    echo -e "${BLUE}Features:${NC}"
    echo "  ✓ AI Segmentation of 8 vessel classes"
    echo "  ✓ Risk Assessment (ESVS 2024 Guidelines)"
    echo "  ✓ Approach Selection (Open/Endovascular/Hybrid)"
    echo "  ✓ Access Planning"
    echo "  ✓ Outcome Prediction"
    echo "  ✓ Protocol Generation (25+ operation types)"
    echo "  ✓ Rare Pathology Detection"
    echo ""
    echo -e "${BLUE}Useful commands:${NC}"
    echo "  View logs:        docker-compose logs -f"
    echo "  Stop services:    docker-compose down"
    echo "  Restart:          docker-compose restart"
    echo ""
    echo -e "${YELLOW}Press Ctrl+C to stop viewing logs${NC}"
    echo ""
}

# Show logs
show_logs() {
    docker-compose logs -f
}

# Cleanup function
cleanup() {
    echo ""
    print_status "Shutting down..."
    docker-compose down
    print_success "Services stopped"
    exit 0
}

# Set trap for cleanup
trap cleanup SIGINT SIGTERM

# Main function
main() {
    print_status "Starting VASCULAR.AI..."
    
    check_docker
    check_requirements
    create_directories
    pull_images
    start_services
    wait_for_services
    show_status
    show_logs
}

# Run main function
main
