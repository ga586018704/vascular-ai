# VASCULAR.AI - AI Medical Agents System

## Обзор

Система специализированных AI-агентов для различных областей сосудистой медицины с интеграцией актуальных научных данных и клинических рекомендаций.

## Архитектура системы

```
┌─────────────────────────────────────────────────────────────────┐
│                        API Layer (FastAPI)                       │
│  /api/agents/analyze        - Анализ одним агентом              │
│  /api/agents/analyze-multi  - Анализ несколькими агентами       │
│  /api/agents/validate       - Валидация вывода                  │
│  /api/agents/available      - Список агентов                    │
│  /api/agents/statistics     - Статистика использования          │
│  /api/agents/search-literature - Поиск в PubMed                 │
└─────────────────────────────────────────────────────────────────┘
                              │
                              ▼
┌─────────────────────────────────────────────────────────────────┐
│                      AI Agents Layer                             │
│  ┌─────────────┐ ┌─────────────┐ ┌─────────────┐ ┌───────────┐ │
│  │   Vascular  │ │ Phlebology  │ │    Neuro    │ │Endovasc.  │ │
│  │   Surgery   │ │    Agent    │ │Intervention │ │  Agent    │ │
│  │    Agent    │ │             │ │    Agent    │ │           │ │
│  └─────────────┘ └─────────────┘ └─────────────┘ └───────────┘ │
└─────────────────────────────────────────────────────────────────┘
                              │
                              ▼
┌─────────────────────────────────────────────────────────────────┐
│                    Knowledge Integration Layer                   │
│  ┌─────────────┐ ┌─────────────┐ ┌─────────────┐               │
│  │   PubMed    │ │  Clinical   │ │  Scientific │               │
│  │ Integration │ │  Guidelines │ │  Knowledge  │               │
│  │             │ │ Integration │ │   Manager   │               │
│  └─────────────┘ └─────────────┘ └─────────────┘               │
└─────────────────────────────────────────────────────────────────┘
```

## Специализированные агенты

### 1. Vascular Surgery Agent

**Специализация:** Сосудистая хирургия

**Возможности:**
- Анализ ААА (плановые и экстренные случаи)
- Оценка каротидного стеноза
- Классификация PAD
- Расчет риска (VSGNE, GAS)
- Рекомендации по лечению

**Пример использования:**
```bash
curl -X POST https://vascular.ai/api/agents/analyze \
  -H "Authorization: Bearer $TOKEN" \
  -H "Content-Type: application/json" \
  -d '{
    "query": "Пациент 68 лет, ААА 55 мм, креатинин 180, ИБС в анамнезе",
    "agent_type": "vascular",
    "patient_context": {"age": 68, "creatinine": 180, "cad": true}
  }'
```

### 2. Phlebology Agent

**Специализация:** Флебология

**Возможности:**
- CEAP классификация
- Оценка ДВТ (Wells score)
- Риск-стратификация ТЭЛА
- Рекомендации по антикоагуляции
- Управление лимфедемой

**Пример использования:**
```bash
curl -X POST https://vascular.ai/api/agents/analyze \
  -H "Authorization: Bearer $TOKEN" \
  -H "Content-Type: application/json" \
  -d '{
    "query": "Отек левой нижней конечности, боли, гомеран 2.5 нг/мл",
    "agent_type": "phlebology"
  }'
```

### 3. Neurointervention Agent

**Специализация:** Нейроинтервенция

**Возможности:**
- Оценка острого инсульта (NIHSS, ASPECTS)
- Индикация к тромбэктомии
- Оценка внутричерепных аневризм
- Spetzler-Martin для АВМ
- Рекомендации по CAS

**Пример использования:**
```bash
curl -X POST https://vascular.ai/api/agents/analyze \
  -H "Authorization: Bearer $TOKEN" \
  -H "Content-Type: application/json" \
  -d '{
    "query": "Острый инсульт, NIHSS 14, время от начала 3 часа, окклюзия MCA",
    "agent_type": "neuro"
  }'
```

### 4. Endovascular Agent

**Специализация:** Эндоваскулярная хирургия

**Возможности:**
- Оценка пригодности EVAR
- TASC классификация
- Управление endoleak
- Планирование доступа
- Выбор endograft

**Пример использования:**
```bash
curl -X POST https://vascular.ai/api/agents/analyze \
  -H "Authorization: Bearer $TOKEN" \
  -H "Content-Type: application/json" \
  -d '{
    "query": "ААА 60 мм, шейка 28 мм, длина шейки 15 мм, кальцификация",
    "agent_type": "endovascular"
  }'
```

## Множественный анализ (Multi-Agent)

Для сложных случаев можно использовать несколько агентов одновременно:

```bash
curl -X POST https://vascular.ai/api/agents/analyze-multi \
  -H "Authorization: Bearer $TOKEN" \
  -H "Content-Type: application/json" \
  -d '{
    "query": "Пациент с ДВТ и перенесенным инсультом, требуется оценка риска",
    "agent_types": ["phlebology", "neuro", "vascular"],
    "require_consensus": true
  }'
```

## Валидация выводов

Каждый вывод агента проходит валидацию:

```bash
curl -X POST https://vascular.ai/api/agents/validate \
  -H "Authorization: Bearer $TOKEN" \
  -H "Content-Type: application/json" \
  -d '{
    "query": "...",
    "analysis": "...",
    "recommendations": [...],
    "sources": [...],
    "confidence_score": 0.85
  }'
```

### Критерии валидации:
- Уровень достоверности (confidence score)
- Наличие научных источников
- Уровень доказательности
- Медицинская корректность
- Наличие противопоказаний
- Внутренняя согласованность

## Интеграция с научными источниками

### PubMed Integration

```bash
curl -X POST https://vascular.ai/api/agents/search-literature \
  -H "Authorization: Bearer $TOKEN" \
  -H "Content-Type: application/json" \
  -d '{
    "query": "EVAR outcomes complications",
    "max_results": 10,
    "min_year": 2020,
    "include_guidelines": true
  }'
```

### Clinical Guidelines

```bash
curl https://vascular.ai/api/agents/guidelines/aortic-aneurysm \
  -H "Authorization: Bearer $TOKEN"
```

## Уровни доказательности

Система использует классификацию Oxford CEBM:

| Уровень | Описание |
|---------|----------|
| **Ia** | Systematic review of RCTs |
| **Ib** | Individual RCT |
| **IIa** | Systematic review of cohort studies |
| **IIb** | Individual cohort study |
| **IIIa** | Systematic review of case-control |
| **IIIb** | Individual case-control |
| **IV** | Case series |
| **V** | Expert opinion |

## Классы рекомендаций

| Класс | Описание |
|-------|----------|
| **Class I** | Benefit >>> Risk (рекомендуется) |
| **Class IIa** | Benefit >> Risk (разумно выполнить) |
| **Class IIb** | Benefit ≥ Risk (можно рассмотреть) |
| **Class III** | Risk ≥ Benefit (не рекомендуется) |

## API Endpoints

### Получение списка агентов
```
GET /api/agents/available
```

### Анализ с помощью агента
```
POST /api/agents/analyze
Body: {
  "query": string,
  "agent_type": "vascular" | "phlebology" | "neuro" | "endovascular",
  "patient_context": object (optional),
  "include_sources": boolean (default: true),
  "min_evidence_level": "Ia" | "Ib" | ... | "V" (default: "IV")
}
```

### Множественный анализ
```
POST /api/agents/analyze-multi
Body: {
  "query": string,
  "agent_types": string[],
  "patient_context": object (optional),
  "require_consensus": boolean (default: false)
}
```

### Валидация вывода
```
POST /api/agents/validate
Body: AgentAnalysis
```

### Статистика использования
```
GET /api/agents/statistics
```

### Поиск в литературе
```
POST /api/agents/search-literature
Body: {
  "query": string,
  "max_results": number (default: 10),
  "min_year": number (optional),
  "include_guidelines": boolean (default: true)
}
```

### Получение клинических рекомендаций
```
GET /api/agents/guidelines/{condition}?source={source}
```

### Обновление базы знаний (admin only)
```
POST /api/agents/update-knowledge?agent_type={type}
```

## Безопасность

- Все endpoints требуют аутентификации
- Разрешение `read:ai_agent` для анализа
- Разрешение `write:system` для обновления базы знаний
- Все операции логируются для аудита
- Результаты валидации включаются в ответ

## Примеры использования

### Пример 1: Анализ ААА

```python
import requests

response = requests.post(
    "https://vascular.ai/api/agents/analyze",
    headers={"Authorization": f"Bearer {token}"},
    json={
        "query": "Пациент 72 года, ААА 58 мм, креатинин 220, ХСН ФК III",
        "agent_type": "vascular",
        "patient_context": {
            "age": 72,
            "creatinine": 220,
            "chf": True,
            "nyha_class": 3
        }
    }
)

result = response.json()
print(f"Confidence: {result['confidence_score']}")
print(f"Recommendations: {result['recommendations']}")
```

### Пример 2: Множественный анализ

```python
response = requests.post(
    "https://vascular.ai/api/agents/analyze-multi",
    headers={"Authorization": f"Bearer {token}"},
    json={
        "query": "Сложный случай с поражением сонной и позвоночной артерий",
        "agent_types": ["vascular", "neuro"],
        "require_consensus": True
    }
)

result = response.json()
if result.get("consensus"):
    print(f"Consensus recommendations: {result['consensus']['consensus_recommendations']}")
    print(f"Requires human review: {result['requires_human_review']}")
```

### Пример 3: Поиск литературы

```python
response = requests.post(
    "https://vascular.ai/api/agents/search-literature",
    headers={"Authorization": f"Bearer {token}"},
    json={
        "query": "EVAR vs open repair outcomes",
        "max_results": 5,
        "min_year": 2022
    }
)

articles = response.json()["pubmed_results"]
for article in articles:
    print(f"{article['title']} ({article['year']}) - {article['evidence_level']}")
```

## Конфигурация

### Переменные окружения

```bash
# PubMed API (опционально, для увеличения rate limit)
PUBMED_API_KEY=your_ncbi_api_key

# Обновление базы знаний
KNOWLEDGE_UPDATE_INTERVAL=24  # часов
```

### Настройка агентов

Агенты можно настроить через конфигурационный файл:

```python
# app/agents/config.py
AGENT_CONFIG = {
    "vascular": {
        "min_evidence_level": "IIb",
        "max_sources": 15,
        "guideline_sources": ["ESVS", "SVS", "ACC/AHA"]
    },
    "phlebology": {
        "min_evidence_level": "Ib",
        "max_sources": 20,
        "guideline_sources": ["ESVS", "ACCP"]
    }
}
```

## Мониторинг

### Статистика агентов

```bash
curl https://vascular.ai/api/agents/statistics \
  -H "Authorization: Bearer $TOKEN"
```

Ответ:
```json
{
  "agents": {
    "vascular": {
      "total_analyses": 150,
      "avg_confidence": 0.82,
      "last_update": "2024-01-15T10:00:00Z"
    }
  },
  "validation": {
    "total_validations": 150,
    "valid_count": 142,
    "validity_rate": 94.7,
    "average_score": 0.78
  }
}
```

## Разработка новых агентов

### Шаблон нового агента

```python
from app.agents.base.medical_agent import MedicalAIAgent, AgentAnalysis

class NewSpecialtyAgent(MedicalAIAgent):
    def __init__(self, pubmed_api_key=None):
        super().__init__(
            agent_name="NewSpecialtyAgent",
            agent_version="1.0.0",
            specialty="New Specialty",
            knowledge_sources=["PubMed", "Guidelines"]
        )
        self.knowledge_manager = ScientificKnowledgeManager(pubmed_api_key)
    
    async def analyze(self, query, patient_context=None, include_sources=True, min_evidence_level=None):
        # Реализация анализа
        pass
    
    async def update_knowledge_base(self):
        # Обновление базы знаний
        pass
```

## Лицензирование и ответственность

⚠️ **Важно:** AI-агенты предоставляют рекомендации на основе научных данных, но:
- Не заменяют клиническое суждение врача
- Требуют подтверждения специалистом
- Не несут ответственности за клинические решения
- Всегда включают дисклеймеры

## Поддержка

- Документация: https://docs.vascular.ai/agents
- API Reference: https://api.vascular.ai/docs
- Поддержка: support@vascular.ai
