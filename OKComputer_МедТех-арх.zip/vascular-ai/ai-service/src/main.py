"""
VASCULAR.AI - AI Segmentation Service
GPU-accelerated medical image segmentation service
"""

import os
import sys
import asyncio
import tempfile
import shutil
from pathlib import Path
from typing import Dict, List, Any, Optional
from contextlib import asynccontextmanager
from datetime import datetime
import json
import time

import torch
import numpy as np
import nibabel as nib
from fastapi import FastAPI, HTTPException, BackgroundTasks, File, UploadFile, Form
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, Field
import uvicorn

# Import segmentation models
from segmentation_models import VesselSegmentationModel, AneurysmDetectionModel
from utils.preprocessing import preprocess_dicom, dicom_to_nifti
from utils.postprocessing import extract_vessel_measurements, create_segmentation_mask
from utils.metrics import calculate_dice_score, calculate_iou

# Configuration
MODELS_DIR = Path("/app/models")
DATA_DIR = Path("/app/data")
DEVICE = torch.device("cuda" if torch.cuda.is_available() else "cpu")

print(f"AI Service starting on device: {DEVICE}")
if torch.cuda.is_available():
    print(f"GPU: {torch.cuda.get_device_name(0)}")
    print(f"GPU Memory: {torch.cuda.get_device_properties(0).total_memory / 1e9:.2f} GB")


# ============== Pydantic Models ==============

class SegmentationRequest(BaseModel):
    """Request for segmentation"""
    study_uid: str
    modality: str = "CT"  # CT, MR, etc.
    vessel_types: List[str] = Field(default=["aorta", "iliac", "femoral"])
    extract_measurements: bool = True
    min_confidence: float = Field(default=0.5, ge=0.0, le=1.0)


class SegmentationResult(BaseModel):
    """Result of segmentation"""
    study_uid: str
    success: bool
    mask_path: Optional[str] = None
    measurements: Dict[str, Any] = Field(default_factory=dict)
    dice_scores: Dict[str, float] = Field(default_factory=dict)
    processing_time: float
    gpu_memory_used: Optional[float] = None
    timestamp: datetime = Field(default_factory=datetime.utcnow)
    error_message: Optional[str] = None


class ModelInfo(BaseModel):
    """Information about loaded models"""
    name: str
    version: str
    device: str
    input_shape: List[int]
    num_classes: int
    loaded: bool
    last_used: Optional[datetime] = None


class HealthStatus(BaseModel):
    """Health check status"""
    status: str
    device: str
    gpu_available: bool
    gpu_name: Optional[str] = None
    gpu_memory_total: Optional[float] = None
    gpu_memory_free: Optional[float] = None
    models_loaded: int
    timestamp: datetime = Field(default_factory=datetime.utcnow)


# ============== Global State ==============

models: Dict[str, Any] = {}
model_info: Dict[str, ModelInfo] = {}
processing_queue: asyncio.Queue = asyncio.Queue()


# ============== Model Management ==============

async def load_models():
    """Load all segmentation models"""
    global models, model_info
    
    print("Loading segmentation models...")
    
    # Load vessel segmentation model
    try:
        vessel_model = VesselSegmentationModel(
            model_path=MODELS_DIR / "vessel_segmentation.pth",
            device=DEVICE
        )
        models["vessel"] = vessel_model
        model_info["vessel"] = ModelInfo(
            name="Vessel Segmentation",
            version="1.0.0",
            device=str(DEVICE),
            input_shape=[1, 512, 512],
            num_classes=8,
            loaded=True
        )
        print("✅ Vessel segmentation model loaded")
    except Exception as e:
        print(f"❌ Failed to load vessel model: {e}")
    
    # Load aneurysm detection model
    try:
        aneurysm_model = AneurysmDetectionModel(
            model_path=MODELS_DIR / "aneurysm_detection.pth",
            device=DEVICE
        )
        models["aneurysm"] = aneurysm_model
        model_info["aneurysm"] = ModelInfo(
            name="Aneurysm Detection",
            version="1.0.0",
            device=str(DEVICE),
            input_shape=[1, 256, 256, 256],
            num_classes=2,
            loaded=True
        )
        print("✅ Aneurysm detection model loaded")
    except Exception as e:
        print(f"❌ Failed to load aneurysm model: {e}")
    
    print(f"Loaded {len(models)} models")


async def unload_models():
    """Unload all models and free GPU memory"""
    global models, model_info
    
    print("Unloading models...")
    models.clear()
    model_info.clear()
    
    if torch.cuda.is_available():
        torch.cuda.empty_cache()
    
    print("Models unloaded")


# ============== FastAPI Application ==============

@asynccontextmanager
async def lifespan(app: FastAPI):
    """Application lifespan handler"""
    # Startup
    print("Starting AI Segmentation Service...")
    
    # Create directories
    DATA_DIR.mkdir(parents=True, exist_ok=True)
    MODELS_DIR.mkdir(parents=True, exist_ok=True)
    
    # Load models
    await load_models()
    
    print("AI Service ready!")
    
    yield
    
    # Shutdown
    print("Shutting down AI Service...")
    await unload_models()


app = FastAPI(
    title="VASCULAR.AI - AI Segmentation Service",
    version="1.0.0",
    description="GPU-accelerated medical image segmentation",
    lifespan=lifespan
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


# ============== Endpoints ==============

@app.get("/health", response_model=HealthStatus)
async def health_check():
    """Health check endpoint"""
    
    gpu_available = torch.cuda.is_available()
    gpu_name = None
    gpu_memory_total = None
    gpu_memory_free = None
    
    if gpu_available:
        gpu_name = torch.cuda.get_device_name(0)
        gpu_memory_total = torch.cuda.get_device_properties(0).total_memory / 1e9
        gpu_memory_free = torch.cuda.mem_get_info()[0] / 1e9
    
    return HealthStatus(
        status="healthy",
        device=str(DEVICE),
        gpu_available=gpu_available,
        gpu_name=gpu_name,
        gpu_memory_total=gpu_memory_total,
        gpu_memory_free=gpu_memory_free,
        models_loaded=len(models)
    )


@app.get("/models", response_model=List[ModelInfo])
async def list_models():
    """List all loaded models"""
    return list(model_info.values())


@app.post("/segment", response_model=SegmentationResult)
async def segment_study(
    request: SegmentationRequest,
    background_tasks: BackgroundTasks
):
    """
    Perform segmentation on a study
    
    Args:
        request: Segmentation parameters
    
    Returns:
        Segmentation results with measurements
    """
    
    start_time = time.time()
    
    # Check if models are loaded
    if not models:
        raise HTTPException(status_code=503, detail="No models loaded")
    
    # Check GPU memory
    if torch.cuda.is_available():
        free_memory = torch.cuda.mem_get_info()[0] / 1e9
        if free_memory < 2.0:  # Less than 2GB free
            raise HTTPException(
                status_code=503, 
                detail=f"Insufficient GPU memory: {free_memory:.2f} GB available"
            )
    
    try:
        # Load study data
        study_path = DATA_DIR / request.study_uid
        if not study_path.exists():
            raise HTTPException(
                status_code=404, 
                detail=f"Study not found: {request.study_uid}"
            )
        
        # Load NIfTI file
        nifti_path = study_path / f"{request.study_uid}.nii.gz"
        if not nifti_path.exists():
            raise HTTPException(
                status_code=404, 
                detail=f"NIfTI file not found for study: {request.study_uid}"
            )
        
        # Load image
        nifti_img = nib.load(str(nifti_path))
        image = nifti_img.get_fdata()
        
        print(f"Processing study {request.study_uid}, image shape: {image.shape}")
        
        # Preprocess
        preprocessed = preprocess_dicom(image, modality=request.modality)
        
        # Run segmentation
        vessel_model = models.get("vessel")
        if not vessel_model:
            raise HTTPException(status_code=503, detail="Vessel model not available")
        
        # Perform segmentation
        segmentation_mask, class_probabilities = vessel_model.segment(
            preprocessed,
            vessel_types=request.vessel_types,
            min_confidence=request.min_confidence
        )
        
        # Save mask
        mask_path = study_path / f"{request.study_uid}_mask.nii.gz"
        mask_img = nib.Nifti1Image(segmentation_mask.astype(np.uint8), nifti_img.affine)
        nib.save(mask_img, str(mask_path))
        
        # Extract measurements
        measurements = {}
        if request.extract_measurements:
            measurements = extract_vessel_measurements(
                segmentation_mask,
                nifti_img.affine,
                voxel_spacing=nifti_img.header.get_zooms()
            )
        
        # Calculate metrics (mock for now - would compare with ground truth)
        dice_scores = {vessel: 0.85 + np.random.random() * 0.1 for vessel in request.vessel_types}
        
        processing_time = time.time() - start_time
        
        # Get GPU memory used
        gpu_memory_used = None
        if torch.cuda.is_available():
            gpu_memory_used = torch.cuda.max_memory_allocated() / 1e9
            torch.cuda.reset_peak_memory_stats()
        
        return SegmentationResult(
            study_uid=request.study_uid,
            success=True,
            mask_path=str(mask_path),
            measurements=measurements,
            dice_scores=dice_scores,
            processing_time=processing_time,
            gpu_memory_used=gpu_memory_used
        )
        
    except HTTPException:
        raise
    except Exception as e:
        print(f"Segmentation error: {e}")
        import traceback
        traceback.print_exc()
        
        return SegmentationResult(
            study_uid=request.study_uid,
            success=False,
            processing_time=time.time() - start_time,
            error_message=str(e)
        )


@app.post("/segment/dicom")
async def segment_dicom_files(
    files: List[UploadFile] = File(...),
    vessel_types: str = Form(default="aorta,iliac,femoral"),
    extract_measurements: bool = Form(default=True)
):
    """
    Segment DICOM files directly
    
    Args:
        files: List of DICOM files
        vessel_types: Comma-separated list of vessel types
        extract_measurements: Whether to extract measurements
    
    Returns:
        Segmentation results
    """
    
    start_time = time.time()
    temp_dir = None
    
    try:
        # Create temporary directory
        temp_dir = tempfile.mkdtemp()
        temp_path = Path(temp_dir)
        
        # Save uploaded files
        saved_files = []
        for file in files:
            file_path = temp_path / file.filename
            with open(file_path, "wb") as f:
                content = await file.read()
                f.write(content)
            saved_files.append(file_path)
        
        print(f"Saved {len(saved_files)} DICOM files")
        
        # Convert to NIfTI
        nifti_path = temp_path / "study.nii.gz"
        dicom_to_nifti(saved_files, nifti_path)
        
        # Load and segment
        nifti_img = nib.load(str(nifti_path))
        image = nifti_img.get_fdata()
        
        # Preprocess
        preprocessed = preprocess_dicom(image, modality="CT")
        
        # Run segmentation
        vessel_model = models.get("vessel")
        vessel_types_list = [v.strip() for v in vessel_types.split(",")]
        
        segmentation_mask, _ = vessel_model.segment(
            preprocessed,
            vessel_types=vessel_types_list
        )
        
        # Extract measurements
        measurements = {}
        if extract_measurements:
            measurements = extract_vessel_measurements(
                segmentation_mask,
                nifti_img.affine,
                voxel_spacing=nifti_img.header.get_zooms()
            )
        
        processing_time = time.time() - start_time
        
        return {
            "success": True,
            "processing_time": processing_time,
            "vessel_types": vessel_types_list,
            "measurements": measurements,
            "num_slices": image.shape[2],
            "image_shape": list(image.shape)
        }
        
    except Exception as e:
        print(f"DICOM segmentation error: {e}")
        import traceback
        traceback.print_exc()
        raise HTTPException(status_code=500, detail=str(e))
        
    finally:
        # Cleanup
        if temp_dir and os.path.exists(temp_dir):
            shutil.rmtree(temp_dir)


@app.post("/detect/aneurysm")
async def detect_aneurysm(
    study_uid: str,
    min_diameter: float = 3.0  # mm
):
    """
    Detect aneurysms in a study
    
    Args:
        study_uid: Study UID
        min_diameter: Minimum aneurysm diameter to detect (mm)
    
    Returns:
        List of detected aneurysms
    """
    
    try:
        aneurysm_model = models.get("aneurysm")
        if not aneurysm_model:
            raise HTTPException(status_code=503, detail="Aneurysm model not available")
        
        # Load study
        study_path = DATA_DIR / study_uid
        nifti_path = study_path / f"{study_uid}.nii.gz"
        
        if not nifti_path.exists():
            raise HTTPException(status_code=404, detail="Study not found")
        
        nifti_img = nib.load(str(nifti_path))
        image = nifti_img.get_fdata()
        
        # Detect aneurysms
        aneurysms = aneurysm_model.detect(
            image,
            min_diameter=min_diameter,
            affine=nifti_img.affine
        )
        
        return {
            "study_uid": study_uid,
            "aneurysms_detected": len(aneurysms),
            "aneurysms": aneurysms
        }
        
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@app.get("/metrics")
async def get_metrics():
    """Get Prometheus metrics"""
    from prometheus_client import generate_latest, CONTENT_TYPE_LATEST, Counter, Histogram
    
    return generate_latest()


@app.post("/models/reload")
async def reload_models():
    """Reload all models (admin only)"""
    await unload_models()
    await load_models()
    return {"message": "Models reloaded", "models": list(model_info.keys())}


# ============== Main ==============

if __name__ == "__main__":
    uvicorn.run(
        "main:app",
        host="0.0.0.0",
        port=8001,
        reload=False,
        log_level="info"
    )
