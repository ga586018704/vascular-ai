"""
VASCULAR.AI - Segmentation Models
Deep learning models for vessel segmentation and aneurysm detection
"""

import torch
import torch.nn as nn
import torch.nn.functional as F
import numpy as np
from pathlib import Path
from typing import Tuple, List, Dict, Optional
import nibabel as nib
from scipy import ndimage
from skimage import measure


class UNet3D(nn.Module):
    """
    3D U-Net for vessel segmentation
    """
    
    def __init__(self, in_channels=1, out_channels=8, features=[32, 64, 128, 256]):
        super(UNet3D, self).__init__()
        
        self.encoder = nn.ModuleList()
        self.decoder = nn.ModuleList()
        self.pool = nn.MaxPool3d(kernel_size=2, stride=2)
        
        # Encoder
        for feature in features:
            self.encoder.append(self._block(in_channels, feature))
            in_channels = feature
        
        # Bottleneck
        self.bottleneck = self._block(features[-1], features[-1] * 2)
        
        # Decoder
        for feature in reversed(features):
            self.decoder.append(
                nn.ConvTranspose3d(feature * 2, feature, kernel_size=2, stride=2)
            )
            self.decoder.append(self._block(feature * 2, feature))
        
        # Final convolution
        self.final_conv = nn.Conv3d(features[0], out_channels, kernel_size=1)
    
    def _block(self, in_channels, out_channels):
        return nn.Sequential(
            nn.Conv3d(in_channels, out_channels, kernel_size=3, padding=1),
            nn.BatchNorm3d(out_channels),
            nn.ReLU(inplace=True),
            nn.Conv3d(out_channels, out_channels, kernel_size=3, padding=1),
            nn.BatchNorm3d(out_channels),
            nn.ReLU(inplace=True)
        )
    
    def forward(self, x):
        skip_connections = []
        
        # Encoder
        for encoder_block in self.encoder:
            x = encoder_block(x)
            skip_connections.append(x)
            x = self.pool(x)
        
        # Bottleneck
        x = self.bottleneck(x)
        
        # Decoder
        skip_connections = skip_connections[::-1]
        for idx in range(0, len(self.decoder), 2):
            x = self.decoder[idx](x)
            skip_connection = skip_connections[idx // 2]
            
            # Handle size mismatch
            if x.shape != skip_connection.shape:
                x = F.interpolate(x, size=skip_connection.shape[2:], mode='trilinear', align_corners=False)
            
            x = torch.cat([skip_connection, x], dim=1)
            x = self.decoder[idx + 1](x)
        
        return self.final_conv(x)


class VesselSegmentationModel:
    """
    Vessel segmentation model wrapper
    """
    
    VESSEL_CLASSES = {
        0: "background",
        1: "aorta",
        2: "iliac_artery",
        3: "femoral_artery",
        4: "popliteal_artery",
        5: "tibial_artery",
        6: "carotid_artery",
        7: "subclavian_artery"
    }
    
    def __init__(self, model_path: Path, device: torch.device):
        self.device = device
        self.model_path = model_path
        
        # Initialize model
        self.model = UNet3D(in_channels=1, out_channels=8).to(device)
        
        # Load weights if available
        if model_path.exists():
            print(f"Loading vessel model from {model_path}")
            checkpoint = torch.load(model_path, map_location=device)
            self.model.load_state_dict(checkpoint['model_state_dict'])
            print("Model loaded successfully")
        else:
            print(f"Model file not found at {model_path}, using random initialization")
        
        self.model.eval()
    
    def segment(
        self,
        image: np.ndarray,
        vessel_types: List[str] = None,
        min_confidence: float = 0.5
    ) -> Tuple[np.ndarray, Dict[str, np.ndarray]]:
        """
        Perform vessel segmentation
        
        Args:
            image: Input image (H, W, D)
            vessel_types: List of vessel types to segment
            min_confidence: Minimum confidence threshold
        
        Returns:
            segmentation_mask: (H, W, D) with class labels
            class_probabilities: Dict of probability maps
        """
        
        vessel_types = vessel_types or ["aorta"]
        
        # Normalize image
        image = self._normalize_image(image)
        
        # Convert to tensor
        image_tensor = torch.from_numpy(image).unsqueeze(0).unsqueeze(0).float().to(self.device)
        
        # Pad to compatible size
        original_shape = image_tensor.shape[2:]
        padded_image = self._pad_to_compatible(image_tensor)
        
        # Run inference
        with torch.no_grad():
            logits = self.model(padded_image)
            
            # Remove padding
            logits = logits[:, :, :original_shape[0], :original_shape[1], :original_shape[2]]
            
            # Apply softmax
            probabilities = F.softmax(logits, dim=1)
            
            # Get predictions
            predictions = torch.argmax(probabilities, dim=1)
        
        # Convert to numpy
        segmentation_mask = predictions[0].cpu().numpy().astype(np.uint8)
        
        # Extract probability maps
        class_probabilities = {}
        for class_id, class_name in self.VESSEL_CLASSES.items():
            if class_id > 0:  # Skip background
                class_probabilities[class_name] = probabilities[0, class_id].cpu().numpy()
        
        # Filter by vessel types
        if vessel_types:
            mask = np.zeros_like(segmentation_mask)
            for vessel_type in vessel_types:
                class_id = self._get_class_id(vessel_type)
                if class_id is not None:
                    mask[segmentation_mask == class_id] = class_id
            segmentation_mask = mask
        
        # Apply confidence threshold
        if min_confidence > 0:
            segmentation_mask = self._apply_confidence_threshold(
                segmentation_mask, 
                class_probabilities, 
                min_confidence
            )
        
        return segmentation_mask, class_probabilities
    
    def _normalize_image(self, image: np.ndarray) -> np.ndarray:
        """Normalize image to [0, 1] range"""
        image = image.astype(np.float32)
        
        # Windowing for CT (typical vascular window)
        window_center = 50
        window_width = 400
        
        min_val = window_center - window_width // 2
        max_val = window_center + window_width // 2
        
        image = np.clip(image, min_val, max_val)
        image = (image - min_val) / (max_val - min_val)
        
        return image
    
    def _pad_to_compatible(self, tensor: torch.Tensor) -> torch.Tensor:
        """Pad tensor to be divisible by 16 (for U-Net)"""
        shape = tensor.shape[2:]
        pad_dims = []
        
        for dim in shape:
            remainder = dim % 16
            if remainder != 0:
                pad = 16 - remainder
                pad_dims.extend([pad // 2, pad - pad // 2])
            else:
                pad_dims.extend([0, 0])
        
        # pad_dims is [pad_d0_start, pad_d0_end, pad_d1_start, ...]
        # F.pad expects [pad_last_dim_start, pad_last_dim_end, ...]
        pad_dims = pad_dims[::-1]
        
        return F.pad(tensor, pad_dims, mode='constant', value=0)
    
    def _get_class_id(self, vessel_type: str) -> Optional[int]:
        """Get class ID from vessel type name"""
        for class_id, class_name in self.VESSEL_CLASSES.items():
            if vessel_type.lower() in class_name.lower():
                return class_id
        return None
    
    def _apply_confidence_threshold(
        self, 
        mask: np.ndarray, 
        probabilities: Dict[str, np.ndarray], 
        threshold: float
    ) -> np.ndarray:
        """Apply confidence threshold to mask"""
        result = mask.copy()
        
        for class_id, class_name in self.VESSEL_CLASSES.items():
            if class_id > 0 and class_name in probabilities:
                prob = probabilities[class_name]
                class_mask = (mask == class_id) & (prob < threshold)
                result[class_mask] = 0
        
        return result


class AneurysmDetectionModel:
    """
    Aneurysm detection model
    """
    
    def __init__(self, model_path: Path, device: torch.device):
        self.device = device
        self.model_path = model_path
        
        # Simple 3D CNN for aneurysm detection
        self.model = self._build_model().to(device)
        
        if model_path.exists():
            print(f"Loading aneurysm model from {model_path}")
            checkpoint = torch.load(model_path, map_location=device)
            self.model.load_state_dict(checkpoint['model_state_dict'])
            print("Aneurysm model loaded successfully")
        else:
            print(f"Aneurysm model file not found at {model_path}")
        
        self.model.eval()
    
    def _build_model(self):
        """Build aneurysm detection model"""
        return nn.Sequential(
            nn.Conv3d(1, 16, kernel_size=3, padding=1),
            nn.ReLU(),
            nn.MaxPool3d(2),
            nn.Conv3d(16, 32, kernel_size=3, padding=1),
            nn.ReLU(),
            nn.MaxPool3d(2),
            nn.Conv3d(32, 64, kernel_size=3, padding=1),
            nn.ReLU(),
            nn.AdaptiveAvgPool3d(1),
            nn.Flatten(),
            nn.Linear(64, 128),
            nn.ReLU(),
            nn.Linear(128, 2)  # Binary classification: aneurysm/no aneurysm
        )
    
    def detect(
        self,
        image: np.ndarray,
        min_diameter: float = 3.0,
        affine: Optional[np.ndarray] = None
    ) -> List[Dict]:
        """
        Detect aneurysms in image
        
        Args:
            image: Input image
            min_diameter: Minimum aneurysm diameter in mm
            affine: Image affine matrix for coordinate transformation
        
        Returns:
            List of detected aneurysms with properties
        """
        
        aneurysms = []
        
        # Normalize image
        image_norm = self._normalize_image(image)
        
        # Get voxel spacing
        voxel_spacing = [1.0, 1.0, 1.0]
        if affine is not None:
            voxel_spacing = [
                np.linalg.norm(affine[:3, 0]),
                np.linalg.norm(affine[:3, 1]),
                np.linalg.norm(affine[:3, 2])
            ]
        
        # Simple blob detection as baseline
        # In production, this would use the trained model
        threshold = 0.5
        binary_mask = (image_norm > threshold).astype(np.uint8)
        
        # Label connected components
        labeled_mask, num_labels = ndimage.label(binary_mask)
        
        # Analyze each component
        for label_id in range(1, num_labels + 1):
            component_mask = (labeled_mask == label_id)
            
            # Get properties
            props = measure.regionprops(component_mask.astype(int))
            
            if len(props) == 0:
                continue
            
            prop = props[0]
            
            # Calculate diameter
            diameter_mm = prop.equivalent_diameter * np.mean(voxel_spacing)
            
            # Filter by minimum diameter
            if diameter_mm < min_diameter:
                continue
            
            # Get center in voxel coordinates
            center_voxel = prop.centroid
            
            # Convert to world coordinates
            center_world = center_voxel
            if affine is not None:
                center_world = nib.affines.apply_affine(affine, center_voxel)
            
            aneurysm = {
                "id": label_id,
                "center_voxel": [float(c) for c in center_voxel],
                "center_world": [float(c) for c in center_world],
                "diameter_mm": float(diameter_mm),
                "volume_mm3": float(prop.area * np.prod(voxel_spacing)),
                "confidence": float(0.7 + np.random.random() * 0.25)  # Mock confidence
            }
            
            aneurysms.append(aneurysm)
        
        # Sort by diameter (largest first)
        aneurysms.sort(key=lambda x: x["diameter_mm"], reverse=True)
        
        return aneurysms
    
    def _normalize_image(self, image: np.ndarray) -> np.ndarray:
        """Normalize image"""
        image = image.astype(np.float32)
        
        # Windowing for aneurysm detection
        window_center = 100
        window_width = 600
        
        min_val = window_center - window_width // 2
        max_val = window_center + window_width // 2
        
        image = np.clip(image, min_val, max_val)
        image = (image - min_val) / (max_val - min_val)
        
        return image


# ============== Model Factory ==============

def create_vessel_segmentation_model(device: torch.device) -> VesselSegmentationModel:
    """Factory function to create vessel segmentation model"""
    model_path = Path("/app/models/vessel_segmentation.pth")
    return VesselSegmentationModel(model_path, device)


def create_aneurysm_detection_model(device: torch.device) -> AneurysmDetectionModel:
    """Factory function to create aneurysm detection model"""
    model_path = Path("/app/models/aneurysm_detection.pth")
    return AneurysmDetectionModel(model_path, device)
