"""
VASCULAR.AI - Preprocessing Utilities
DICOM and image preprocessing for segmentation
"""

import numpy as np
import pydicom
from pydicom.dataset import FileDataset
from pathlib import Path
from typing import List, Tuple, Optional
import nibabel as nib
import SimpleITK as sitk
from scipy import ndimage


def preprocess_dicom(image: np.ndarray, modality: str = "CT") -> np.ndarray:
    """
    Preprocess DICOM image for segmentation
    
    Args:
        image: Raw image array
        modality: Imaging modality (CT, MR, etc.)
    
    Returns:
        Preprocessed image
    """
    
    # Handle different modalities
    if modality.upper() == "CT":
        image = preprocess_ct(image)
    elif modality.upper() == "MR":
        image = preprocess_mri(image)
    else:
        # Generic preprocessing
        image = image.astype(np.float32)
        image = (image - image.min()) / (image.max() - image.min() + 1e-8)
    
    # Resample to isotropic voxels if needed
    # image = resample_to_isotropic(image, voxel_spacing, target_spacing=(1.0, 1.0, 1.0))
    
    return image


def preprocess_ct(image: np.ndarray) -> np.ndarray:
    """
    Preprocess CT image with vascular windowing
    
    Args:
        image: CT image in HU
    
    Returns:
        Windowed and normalized image
    """
    
    image = image.astype(np.float32)
    
    # Vascular window (W:400, L:50)
    window_center = 50
    window_width = 400
    
    min_val = window_center - window_width // 2
    max_val = window_center + window_width // 2
    
    # Apply windowing
    image = np.clip(image, min_val, max_val)
    
    # Normalize to [0, 1]
    image = (image - min_val) / (max_val - min_val)
    
    return image


def preprocess_mri(image: np.ndarray) -> np.ndarray:
    """
    Preprocess MRI image
    
    Args:
        image: MRI image
    
    Returns:
        Normalized image
    """
    
    image = image.astype(np.float32)
    
    # N4 bias field correction would go here
    # For now, simple normalization
    
    # Remove outliers
    p1, p99 = np.percentile(image, [1, 99])
    image = np.clip(image, p1, p99)
    
    # Normalize to [0, 1]
    image = (image - image.min()) / (image.max() - image.min() + 1e-8)
    
    return image


def dicom_to_nifti(dicom_files: List[Path], output_path: Path) -> None:
    """
    Convert DICOM series to NIfTI format
    
    Args:
        dicom_files: List of DICOM file paths
        output_path: Output NIfTI file path
    """
    
    # Read DICOM series using SimpleITK
    reader = sitk.ImageSeriesReader()
    
    # Get sorted file names
    dicom_names = [str(f) for f in dicom_files]
    reader.SetFileNames(dicom_names)
    
    # Execute
    image = reader.Execute()
    
    # Write NIfTI
    sitk.WriteImage(image, str(output_path))


def resample_image(
    image: np.ndarray,
    original_spacing: Tuple[float, float, float],
    target_spacing: Tuple[float, float, float] = (1.0, 1.0, 1.0),
    order: int = 1
) -> np.ndarray:
    """
    Resample image to target spacing
    
    Args:
        image: Input image
        original_spacing: Original voxel spacing
        target_spacing: Target voxel spacing
        order: Interpolation order (0=nearest, 1=linear, 3=cubic)
    
    Returns:
        Resampled image
    """
    
    # Calculate resampling factors
    factors = [
        original_spacing[i] / target_spacing[i] 
        for i in range(3)
    ]
    
    # Resample
    resampled = ndimage.zoom(image, factors, order=order)
    
    return resampled


def normalize_intensity(
    image: np.ndarray,
    method: str = "zscore"
) -> np.ndarray:
    """
    Normalize image intensity
    
    Args:
        image: Input image
        method: Normalization method (zscore, minmax, percentile)
    
    Returns:
        Normalized image
    """
    
    image = image.astype(np.float32)
    
    if method == "zscore":
        mean = np.mean(image)
        std = np.std(image)
        image = (image - mean) / (std + 1e-8)
    
    elif method == "minmax":
        min_val = image.min()
        max_val = image.max()
        image = (image - min_val) / (max_val - min_val + 1e-8)
    
    elif method == "percentile":
        p1, p99 = np.percentile(image, [1, 99])
        image = np.clip(image, p1, p99)
        image = (image - p1) / (p99 - p1 + 1e-8)
    
    return image


def crop_to_region(
    image: np.ndarray,
    mask: Optional[np.ndarray] = None,
    padding: int = 10
) -> Tuple[np.ndarray, Tuple]:
    """
    Crop image to region of interest
    
    Args:
        image: Input image
        mask: Optional mask to determine ROI
        padding: Padding around ROI
    
    Returns:
        Cropped image and crop coordinates
    """
    
    if mask is None:
        # Use image intensity to determine ROI
        mask = image > (image.mean() + image.std())
    
    # Find bounding box
    coords = np.argwhere(mask)
    
    if len(coords) == 0:
        return image, ((0, image.shape[0]), (0, image.shape[1]), (0, image.shape[2]))
    
    min_coords = coords.min(axis=0)
    max_coords = coords.max(axis=0)
    
    # Add padding
    min_coords = np.maximum(min_coords - padding, 0)
    max_coords = np.minimum(max_coords + padding, np.array(image.shape))
    
    # Crop
    cropped = image[
        min_coords[0]:max_coords[0],
        min_coords[1]:max_coords[1],
        min_coords[2]:max_coords[2]
    ]
    
    crop_coords = (
        (min_coords[0], max_coords[0]),
        (min_coords[1], max_coords[1]),
        (min_coords[2], max_coords[2])
    )
    
    return cropped, crop_coords


def apply_augmentation(
    image: np.ndarray,
    augmentation_type: str = "random"
) -> np.ndarray:
    """
    Apply data augmentation
    
    Args:
        image: Input image
        augmentation_type: Type of augmentation
    
    Returns:
        Augmented image
    """
    
    if augmentation_type == "flip":
        # Random flip
        axis = np.random.randint(0, 3)
        image = np.flip(image, axis=axis)
    
    elif augmentation_type == "rotate":
        # Random rotation
        angle = np.random.uniform(-10, 10)
        image = ndimage.rotate(image, angle, reshape=False, order=1)
    
    elif augmentation_type == "scale":
        # Random scaling
        scale = np.random.uniform(0.9, 1.1)
        image = ndimage.zoom(image, scale, order=1)
    
    elif augmentation_type == "noise":
        # Add Gaussian noise
        noise = np.random.normal(0, 0.01, image.shape)
        image = image + noise
    
    return image


def remove_bed(
    image: np.ndarray,
    threshold: float = -300
) -> np.ndarray:
    """
    Remove CT bed/table from image
    
    Args:
        image: CT image in HU
        threshold: Threshold for bed detection
    
    Returns:
        Image with bed removed
    """
    
    # Create mask for bed (typically very dense)
    bed_mask = image > threshold
    
    # Remove small connected components (likely bed)
    labeled, num_features = ndimage.label(bed_mask)
    
    # Keep only largest component (patient)
    component_sizes = ndimage.sum(bed_mask, labeled, range(num_features + 1))
    largest_component = np.argmax(component_sizes[1:]) + 1
    
    patient_mask = (labeled == largest_component)
    
    # Apply mask
    result = image.copy()
    result[~patient_mask] = image.min()
    
    return result


def extract_centerline(
    segmentation_mask: np.ndarray,
    vessel_label: int
) -> np.ndarray:
    """
    Extract centerline from vessel segmentation
    
    Args:
        segmentation_mask: Segmentation mask
        vessel_label: Label of vessel to extract
    
    Returns:
        Centerline mask
    """
    
    # Extract vessel mask
    vessel_mask = (segmentation_mask == vessel_label).astype(np.uint8)
    
    # Skeletonize
    from skimage.morphology import skeletonize_3d
    centerline = skeletonize_3d(vessel_mask)
    
    return centerline
