"""
VASCULAR.AI - Metrics Utilities
Evaluation metrics for segmentation quality
"""

import numpy as np
from scipy.spatial.distance import directed_hausdorff
from typing import Tuple, Dict


def calculate_dice_score(
    prediction: np.ndarray,
    ground_truth: np.ndarray,
    smooth: float = 1e-6
) -> float:
    """
    Calculate Dice similarity coefficient
    
    Args:
        prediction: Predicted segmentation
        ground_truth: Ground truth segmentation
        smooth: Smoothing factor to avoid division by zero
    
    Returns:
        Dice score (0-1)
    """
    
    # Flatten arrays
    pred_flat = prediction.flatten()
    gt_flat = ground_truth.flatten()
    
    # Calculate intersection and union
    intersection = np.sum(pred_flat * gt_flat)
    union = np.sum(pred_flat) + np.sum(gt_flat)
    
    # Calculate Dice score
    dice = (2.0 * intersection + smooth) / (union + smooth)
    
    return float(dice)


def calculate_iou(
    prediction: np.ndarray,
    ground_truth: np.ndarray,
    smooth: float = 1e-6
) -> float:
    """
    Calculate Intersection over Union (IoU) / Jaccard index
    
    Args:
        prediction: Predicted segmentation
        ground_truth: Ground truth segmentation
        smooth: Smoothing factor
    
    Returns:
        IoU score (0-1)
    """
    
    # Flatten arrays
    pred_flat = prediction.flatten()
    gt_flat = ground_truth.flatten()
    
    # Calculate intersection and union
    intersection = np.sum(pred_flat * gt_flat)
    union = np.sum(pred_flat) + np.sum(gt_flat) - intersection
    
    # Calculate IoU
    iou = (intersection + smooth) / (union + smooth)
    
    return float(iou)


def calculate_sensitivity(
    prediction: np.ndarray,
    ground_truth: np.ndarray,
    smooth: float = 1e-6
) -> float:
    """
    Calculate sensitivity (recall)
    
    Args:
        prediction: Predicted segmentation
        ground_truth: Ground truth segmentation
        smooth: Smoothing factor
    
    Returns:
        Sensitivity (0-1)
    """
    
    pred_flat = prediction.flatten()
    gt_flat = ground_truth.flatten()
    
    true_positives = np.sum(pred_flat * gt_flat)
    false_negatives = np.sum((1 - pred_flat) * gt_flat)
    
    sensitivity = (true_positives + smooth) / (true_positives + false_negatives + smooth)
    
    return float(sensitivity)


def calculate_specificity(
    prediction: np.ndarray,
    ground_truth: np.ndarray,
    smooth: float = 1e-6
) -> float:
    """
    Calculate specificity
    
    Args:
        prediction: Predicted segmentation
        ground_truth: Ground truth segmentation
        smooth: Smoothing factor
    
    Returns:
        Specificity (0-1)
    """
    
    pred_flat = prediction.flatten()
    gt_flat = ground_truth.flatten()
    
    true_negatives = np.sum((1 - pred_flat) * (1 - gt_flat))
    false_positives = np.sum(pred_flat * (1 - gt_flat))
    
    specificity = (true_negatives + smooth) / (true_negatives + false_positives + smooth)
    
    return float(specificity)


def calculate_precision(
    prediction: np.ndarray,
    ground_truth: np.ndarray,
    smooth: float = 1e-6
) -> float:
    """
    Calculate precision
    
    Args:
        prediction: Predicted segmentation
        ground_truth: Ground truth segmentation
        smooth: Smoothing factor
    
    Returns:
        Precision (0-1)
    """
    
    pred_flat = prediction.flatten()
    gt_flat = ground_truth.flatten()
    
    true_positives = np.sum(pred_flat * gt_flat)
    false_positives = np.sum(pred_flat * (1 - gt_flat))
    
    precision = (true_positives + smooth) / (true_positives + false_positives + smooth)
    
    return float(precision)


def calculate_hausdorff_distance(
    prediction: np.ndarray,
    ground_truth: np.ndarray,
    voxel_spacing: Tuple[float, float, float] = (1.0, 1.0, 1.0)
) -> float:
    """
    Calculate Hausdorff distance between segmentations
    
    Args:
        prediction: Predicted segmentation
        ground_truth: Ground truth segmentation
        voxel_spacing: Voxel spacing for distance calculation
    
    Returns:
        Hausdorff distance in mm
    """
    
    # Get surface points
    pred_surface = extract_surface_points(prediction)
    gt_surface = extract_surface_points(ground_truth)
    
    if len(pred_surface) == 0 or len(gt_surface) == 0:
        return float('inf')
    
    # Scale by voxel spacing
    pred_surface_scaled = pred_surface * np.array(voxel_spacing)
    gt_surface_scaled = gt_surface * np.array(voxel_spacing)
    
    # Calculate Hausdorff distance
    d1 = directed_hausdorff(pred_surface_scaled, gt_surface_scaled)[0]
    d2 = directed_hausdorff(gt_surface_scaled, pred_surface_scaled)[0]
    
    hausdorff = max(d1, d2)
    
    return float(hausdorff)


def extract_surface_points(mask: np.ndarray) -> np.ndarray:
    """
    Extract surface points from binary mask
    
    Args:
        mask: Binary mask
    
    Returns:
        Array of surface point coordinates
    """
    
    from scipy import ndimage
    
    # Erode mask
    eroded = ndimage.binary_erosion(mask)
    
    # Surface is the difference
    surface = mask & ~eroded
    
    # Get coordinates
    surface_coords = np.argwhere(surface)
    
    return surface_coords


def calculate_assd(
    prediction: np.ndarray,
    ground_truth: np.ndarray,
    voxel_spacing: Tuple[float, float, float] = (1.0, 1.0, 1.0)
) -> float:
    """
    Calculate Average Symmetric Surface Distance (ASSD)
    
    Args:
        prediction: Predicted segmentation
        ground_truth: Ground truth segmentation
        voxel_spacing: Voxel spacing
    
    Returns:
        ASSD in mm
    """
    
    # Get surface points
    pred_surface = extract_surface_points(prediction)
    gt_surface = extract_surface_points(ground_truth)
    
    if len(pred_surface) == 0 or len(gt_surface) == 0:
        return float('inf')
    
    # Scale by voxel spacing
    pred_surface_scaled = pred_surface * np.array(voxel_spacing)
    gt_surface_scaled = gt_surface * np.array(voxel_spacing)
    
    # Calculate distances from pred to gt
    distances_pred_to_gt = []
    for point in pred_surface_scaled:
        dists = np.linalg.norm(gt_surface_scaled - point, axis=1)
        distances_pred_to_gt.append(np.min(dists))
    
    # Calculate distances from gt to pred
    distances_gt_to_pred = []
    for point in gt_surface_scaled:
        dists = np.linalg.norm(pred_surface_scaled - point, axis=1)
        distances_gt_to_pred.append(np.min(dists))
    
    # Calculate average
    assd = (np.mean(distances_pred_to_gt) + np.mean(distances_gt_to_pred)) / 2
    
    return float(assd)


def calculate_volume_difference(
    prediction: np.ndarray,
    ground_truth: np.ndarray,
    voxel_spacing: Tuple[float, float, float] = (1.0, 1.0, 1.0)
) -> Dict[str, float]:
    """
    Calculate volume difference metrics
    
    Args:
        prediction: Predicted segmentation
        ground_truth: Ground truth segmentation
        voxel_spacing: Voxel spacing
    
    Returns:
        Dictionary with volume metrics
    """
    
    voxel_volume = np.prod(voxel_spacing)
    
    pred_volume = np.sum(prediction) * voxel_volume
    gt_volume = np.sum(ground_truth) * voxel_volume
    
    volume_difference = pred_volume - gt_volume
    volume_difference_percent = (volume_difference / gt_volume) * 100 if gt_volume > 0 else 0
    
    return {
        "predicted_volume_mm3": float(pred_volume),
        "ground_truth_volume_mm3": float(gt_volume),
        "volume_difference_mm3": float(volume_difference),
        "volume_difference_percent": float(volume_difference_percent)
    }


def calculate_all_metrics(
    prediction: np.ndarray,
    ground_truth: np.ndarray,
    voxel_spacing: Tuple[float, float, float] = (1.0, 1.0, 1.0)
) -> Dict[str, float]:
    """
    Calculate all segmentation metrics
    
    Args:
        prediction: Predicted segmentation
        ground_truth: Ground truth segmentation
        voxel_spacing: Voxel spacing
    
    Returns:
        Dictionary with all metrics
    """
    
    metrics = {
        "dice": calculate_dice_score(prediction, ground_truth),
        "iou": calculate_iou(prediction, ground_truth),
        "sensitivity": calculate_sensitivity(prediction, ground_truth),
        "specificity": calculate_specificity(prediction, ground_truth),
        "precision": calculate_precision(prediction, ground_truth),
        "hausdorff_distance": calculate_hausdorff_distance(prediction, ground_truth, voxel_spacing),
        "assd": calculate_assd(prediction, ground_truth, voxel_spacing)
    }
    
    # Add volume metrics
    volume_metrics = calculate_volume_difference(prediction, ground_truth, voxel_spacing)
    metrics.update(volume_metrics)
    
    return metrics


def calculate_multiclass_metrics(
    prediction: np.ndarray,
    ground_truth: np.ndarray,
    num_classes: int,
    voxel_spacing: Tuple[float, float, float] = (1.0, 1.0, 1.0)
) -> Dict[int, Dict[str, float]]:
    """
    Calculate metrics for each class in multiclass segmentation
    
    Args:
        prediction: Predicted segmentation (class labels)
        ground_truth: Ground truth segmentation (class labels)
        num_classes: Number of classes
        voxel_spacing: Voxel spacing
    
    Returns:
        Dictionary of metrics per class
    """
    
    class_metrics = {}
    
    for class_id in range(num_classes):
        # Extract binary masks for this class
        pred_class = (prediction == class_id).astype(np.uint8)
        gt_class = (ground_truth == class_id).astype(np.uint8)
        
        # Skip if no ground truth for this class
        if gt_class.sum() == 0:
            continue
        
        # Calculate metrics
        metrics = calculate_all_metrics(pred_class, gt_class, voxel_spacing)
        class_metrics[class_id] = metrics
    
    return class_metrics
