"""
VASCULAR.AI - Postprocessing Utilities
Postprocessing and measurement extraction for segmentation results
"""

import numpy as np
from scipy import ndimage
from skimage import measure
from typing import Dict, List, Tuple, Optional
import nibabel as nib


def extract_vessel_measurements(
    segmentation_mask: np.ndarray,
    affine: np.ndarray,
    voxel_spacing: Tuple[float, float, float],
    vessel_classes: Dict[int, str] = None
) -> Dict[str, Dict]:
    """
    Extract measurements from vessel segmentation
    
    Args:
        segmentation_mask: Segmentation mask with class labels
        affine: Image affine matrix
        voxel_spacing: Voxel spacing in mm
        vessel_classes: Mapping of class IDs to vessel names
    
    Returns:
        Dictionary of measurements for each vessel
    """
    
    if vessel_classes is None:
        vessel_classes = {
            1: "aorta",
            2: "iliac_artery",
            3: "femoral_artery",
            4: "popliteal_artery",
            5: "tibial_artery",
            6: "carotid_artery",
            7: "subclavian_artery"
        }
    
    measurements = {}
    
    for class_id, vessel_name in vessel_classes.items():
        # Extract mask for this vessel
        vessel_mask = (segmentation_mask == class_id).astype(np.uint8)
        
        if vessel_mask.sum() == 0:
            continue
        
        # Calculate measurements
        vessel_measurements = calculate_vessel_metrics(
            vessel_mask,
            affine,
            voxel_spacing
        )
        
        measurements[vessel_name] = vessel_measurements
    
    return measurements


def calculate_vessel_metrics(
    vessel_mask: np.ndarray,
    affine: np.ndarray,
    voxel_spacing: Tuple[float, float, float]
) -> Dict:
    """
    Calculate metrics for a single vessel
    
    Args:
        vessel_mask: Binary mask of vessel
        affine: Affine matrix
        voxel_spacing: Voxel spacing
    
    Returns:
        Dictionary of metrics
    """
    
    # Label connected components
    labeled_mask, num_components = ndimage.label(vessel_mask)
    
    if num_components == 0:
        return {}
    
    # Get largest component (main vessel)
    component_sizes = ndimage.sum(vessel_mask, labeled_mask, range(1, num_components + 1))
    largest_component_id = np.argmax(component_sizes) + 1
    largest_mask = (labeled_mask == largest_component_id).astype(np.uint8)
    
    # Calculate volume
    voxel_volume = np.prod(voxel_spacing)
    volume_mm3 = np.sum(largest_mask) * voxel_volume
    
    # Get region properties
    props = measure.regionprops(largest_mask)
    
    if len(props) == 0:
        return {}
    
    prop = props[0]
    
    # Calculate centerline
    centerline = extract_centerline_3d(largest_mask)
    
    # Sample diameters along centerline
    diameters = sample_diameters_along_centerline(largest_mask, centerline, voxel_spacing)
    
    # Detect pathology (aneurysm/stenosis)
    pathology = detect_pathology(diameters, vessel_mask, affine)
    
    metrics = {
        "volume_mm3": float(volume_mm3),
        "length_mm": float(prop.major_axis_length * np.mean(voxel_spacing)),
        "diameter_max_mm": float(np.max(diameters)) if len(diameters) > 0 else 0,
        "diameter_min_mm": float(np.min(diameters)) if len(diameters) > 0 else 0,
        "diameter_mean_mm": float(np.mean(diameters)) if len(diameters) > 0 else 0,
        "centerline_length_mm": float(np.sum(centerline) * np.mean(voxel_spacing)),
        "has_pathology": pathology["detected"],
        "pathology_type": pathology["type"],
        "pathology_severity": pathology["severity"],
        "diameter_measurements": diameters.tolist() if len(diameters) > 0 else []
    }
    
    return metrics


def extract_centerline_3d(binary_mask: np.ndarray) -> np.ndarray:
    """
    Extract 3D centerline from binary mask
    
    Args:
        binary_mask: Binary vessel mask
    
    Returns:
        Centerline mask
    """
    
    from skimage.morphology import skeletonize_3d
    
    # Skeletonize
    centerline = skeletonize_3d(binary_mask)
    
    return centerline


def sample_diameters_along_centerline(
    vessel_mask: np.ndarray,
    centerline: np.ndarray,
    voxel_spacing: Tuple[float, float, float],
    sample_interval: int = 5
) -> np.ndarray:
    """
    Sample vessel diameters along centerline
    
    Args:
        vessel_mask: Binary vessel mask
        centerline: Centerline mask
        voxel_spacing: Voxel spacing
        sample_interval: Interval between samples
    
    Returns:
        Array of diameter measurements
    """
    
    # Get centerline coordinates
    centerline_coords = np.argwhere(centerline > 0)
    
    if len(centerline_coords) == 0:
        return np.array([])
    
    diameters = []
    
    # Sample at intervals
    for i in range(0, len(centerline_coords), sample_interval):
        coord = centerline_coords[i]
        
        # Calculate local diameter
        diameter = calculate_local_diameter(vessel_mask, coord, voxel_spacing)
        
        if diameter > 0:
            diameters.append(diameter)
    
    return np.array(diameters)


def calculate_local_diameter(
    vessel_mask: np.ndarray,
    center_point: np.ndarray,
    voxel_spacing: Tuple[float, float, float],
    search_radius: int = 50
) -> float:
    """
    Calculate local vessel diameter at a point
    
    Args:
        vessel_mask: Binary vessel mask
        center_point: Center point coordinates
        voxel_spacing: Voxel spacing
        search_radius: Maximum search radius
    
    Returns:
        Diameter in mm
    """
    
    # Extract cross-section
    z, y, x = center_point
    
    # Define region around center point
    z_min = max(0, z - search_radius)
    z_max = min(vessel_mask.shape[0], z + search_radius)
    y_min = max(0, y - search_radius)
    y_max = min(vessel_mask.shape[1], y + search_radius)
    x_min = max(0, x - search_radius)
    x_max = min(vessel_mask.shape[2], x + search_radius)
    
    # Extract slice
    slice_mask = vessel_mask[z, y_min:y_max, x_min:x_max]
    
    if slice_mask.sum() == 0:
        return 0.0
    
    # Calculate area
    area_voxels = np.sum(slice_mask)
    
    # Calculate equivalent diameter
    area_mm2 = area_voxels * voxel_spacing[1] * voxel_spacing[2]
    diameter_mm = 2 * np.sqrt(area_mm2 / np.pi)
    
    return diameter_mm


def detect_pathology(
    diameters: np.ndarray,
    vessel_mask: np.ndarray,
    affine: np.ndarray,
    aneurysm_threshold: float = 1.5,
    stenosis_threshold: float = 0.5
) -> Dict:
    """
    Detect vascular pathology (aneurysm/stenosis)
    
    Args:
        diameters: Array of diameter measurements
        vessel_mask: Vessel mask
        affine: Affine matrix
        aneurysm_threshold: Threshold for aneurysm detection (ratio)
        stenosis_threshold: Threshold for stenosis detection (ratio)
    
    Returns:
        Pathology detection results
    """
    
    if len(diameters) == 0:
        return {"detected": False, "type": None, "severity": None}
    
    mean_diameter = np.mean(diameters)
    max_diameter = np.max(diameters)
    min_diameter = np.min(diameters)
    
    # Detect aneurysm
    if max_diameter > mean_diameter * aneurysm_threshold:
        severity = classify_aneurysm_size(max_diameter)
        return {
            "detected": True,
            "type": "aneurysm",
            "severity": severity,
            "max_diameter_mm": float(max_diameter),
            "location_ratio": float(np.argmax(diameters) / len(diameters))
        }
    
    # Detect stenosis
    if min_diameter < mean_diameter * stenosis_threshold:
        stenosis_percent = (1 - min_diameter / mean_diameter) * 100
        severity = classify_stenosis(stenosis_percent)
        return {
            "detected": True,
            "type": "stenosis",
            "severity": severity,
            "stenosis_percent": float(stenosis_percent),
            "location_ratio": float(np.argmin(diameters) / len(diameters))
        }
    
    return {"detected": False, "type": None, "severity": None}


def classify_aneurysm_size(diameter_mm: float) -> str:
    """
    Classify aneurysm by size
    
    Args:
        diameter_mm: Maximum aneurysm diameter
    
    Returns:
        Severity classification
    """
    
    if diameter_mm < 30:
        return "small"
    elif diameter_mm < 50:
        return "moderate"
    elif diameter_mm < 70:
        return "large"
    else:
        return "giant"


def classify_stenosis(stenosis_percent: float) -> str:
    """
    Classify stenosis severity
    
    Args:
        stenosis_percent: Percentage of stenosis
    
    Returns:
        Severity classification
    """
    
    if stenosis_percent < 50:
        return "mild"
    elif stenosis_percent < 70:
        return "moderate"
    elif stenosis_percent < 90:
        return "severe"
    else:
        return "critical"


def create_segmentation_mask(
    prediction: np.ndarray,
    threshold: float = 0.5,
    min_component_size: int = 100
) -> np.ndarray:
    """
    Create segmentation mask from model prediction
    
    Args:
        prediction: Model prediction (probabilities)
        threshold: Threshold for binarization
        min_component_size: Minimum component size to keep
    
    Returns:
        Segmentation mask
    """
    
    # Binarize
    binary_mask = (prediction > threshold).astype(np.uint8)
    
    # Remove small components
    labeled_mask, num_components = ndimage.label(binary_mask)
    
    for component_id in range(1, num_components + 1):
        component_size = np.sum(labeled_mask == component_id)
        if component_size < min_component_size:
            binary_mask[labeled_mask == component_id] = 0
    
    return binary_mask


def calculate_centerline_length(centerline: np.ndarray, voxel_spacing: Tuple[float, float, float]) -> float:
    """
    Calculate centerline length
    
    Args:
        centerline: Centerline mask
        voxel_spacing: Voxel spacing
    
    Returns:
        Length in mm
    """
    
    # Count centerline voxels
    num_voxels = np.sum(centerline > 0)
    
    # Approximate length
    length_mm = num_voxels * np.mean(voxel_spacing)
    
    return length_mm


def extract_branch_points(centerline: np.ndarray) -> List[Tuple[int, int, int]]:
    """
    Extract branch points from centerline
    
    Args:
        centerline: Centerline mask
    
    Returns:
        List of branch point coordinates
    """
    
    branch_points = []
    
    # Find centerline voxels
    centerline_coords = np.argwhere(centerline > 0)
    
    for coord in centerline_coords:
        z, y, x = coord
        
        # Count neighbors
        neighbors = 0
        for dz in [-1, 0, 1]:
            for dy in [-1, 0, 1]:
                for dx in [-1, 0, 1]:
                    if dz == 0 and dy == 0 and dx == 0:
                        continue
                    
                    nz, ny, nx = z + dz, y + dy, x + dx
                    
                    if (0 <= nz < centerline.shape[0] and
                        0 <= ny < centerline.shape[1] and
                        0 <= nx < centerline.shape[2]):
                        if centerline[nz, ny, nx] > 0:
                            neighbors += 1
        
        # Branch point has more than 2 neighbors
        if neighbors > 2:
            branch_points.append((z, y, x))
    
    return branch_points
