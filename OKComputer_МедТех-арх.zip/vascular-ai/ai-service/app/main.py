"""
VASCULAR.AI - AI Segmentation Service (Mock version for MVP)
"""

import os
import json
import numpy as np
import nibabel as nib
from pathlib import Path
from typing import Dict, Any, List, Optional
from datetime import datetime

from fastapi import FastAPI, HTTPException, BackgroundTasks
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel

app = FastAPI(
    title="VASCULAR.AI - AI Segmentation Service",
    version="1.0.0",
    description="AI-powered vessel segmentation service"
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Configuration
OUTPUT_DIR = Path("/app/output")
OUTPUT_DIR.mkdir(parents=True, exist_ok=True)

# Vessel class definitions
VESSEL_CLASSES = {
    0: {"name": "background", "display_name": "Фон"},
    1: {"name": "aorta", "display_name": "Аорта"},
    2: {"name": "iliac_right", "display_name": "Правая подвздошная"},
    3: {"name": "iliac_left", "display_name": "Левая подвздошная"},
    4: {"name": "femoral_right", "display_name": "Правая бедренная"},
    5: {"name": "femoral_left", "display_name": "Левая бедренная"},
    6: {"name": "carotid_right", "display_name": "Правая сонная"},
    7: {"name": "carotid_left", "display_name": "Левая сонная"},
    8: {"name": "subclavian_right", "display_name": "Правая подключичная"},
}


class SegmentationRequest(BaseModel):
    study_uid: str
    nifti_path: str


class SegmentationResponse(BaseModel):
    success: bool
    study_uid: str
    classes: List[int]
    dice_scores: Dict[str, float]
    mask_path: str
    measurements: Dict[str, Any]


class MockSegmentationModel:
    """Mock model for development and testing"""
    
    def __init__(self):
        self.classes = [1, 2, 3]  # Aorta + iliacs
        self.dice_scores = {
            "aorta": 0.89,
            "iliac_right": 0.85,
            "iliac_left": 0.84,
            "background": 0.98
        }
    
    def predict(self, image_path: str) -> tuple:
        """Generate mock segmentation"""
        
        # Create mock 3D volume (128x128x64)
        shape = (128, 128, 64)
        mask = np.zeros(shape, dtype=np.uint8)
        
        # Simulate aorta in the center
        center_x, center_y = shape[0] // 2, shape[1] // 2
        
        for z in range(shape[2]):
            y, x = np.ogrid[:shape[0], :shape[1]]
            dist_from_center = np.sqrt((x - center_x)**2 + (y - center_y)**2)
            
            # Aorta (class 1) - center
            aorta_mask = dist_from_center < 15
            mask[:, :, z] = np.where(aorta_mask, 1, mask[:, :, z])
            
            # Right iliac (class 2)
            if z > shape[2] // 3:
                iliac_r_mask = (dist_from_center < 10) & (x > center_x + 10) & (x < center_x + 30)
                mask[:, :, z] = np.where(iliac_r_mask, 2, mask[:, :, z])
            
            # Left iliac (class 3)
            if z > shape[2] // 3:
                iliac_l_mask = (dist_from_center < 10) & (x < center_x - 10) & (x > center_x - 30)
                mask[:, :, z] = np.where(iliac_l_mask, 3, mask[:, :, z])
        
        return mask, self.dice_scores


# Initialize model
model = MockSegmentationModel()


def calculate_measurements(mask: np.ndarray, voxel_spacing: List[float]) -> Dict[str, Any]:
    """Calculate vessel measurements from segmentation mask"""
    
    measurements = {}
    
    for class_id in np.unique(mask):
        if class_id == 0:  # Skip background
            continue
        
        class_info = VESSEL_CLASSES.get(int(class_id), {"name": f"class_{class_id}"})
        class_name = class_info["name"]
        
        class_mask = (mask == class_id).astype(np.uint8)
        
        # Calculate volume
        volume_voxels = int(np.sum(class_mask))
        volume_mm3 = volume_voxels * (voxel_spacing[0] * voxel_spacing[1] * voxel_spacing[2])
        volume_ml = volume_mm3 / 1000
        
        # Find slices with this class
        slices_with_class = []
        for z in range(mask.shape[2]):
            if np.any(class_mask[:, :, z]):
                slices_with_class.append(z)
        
        if not slices_with_class:
            continue
        
        # Calculate length
        length_mm = len(slices_with_class) * voxel_spacing[2]
        
        # Calculate diameters
        diameters = []
        for z in slices_with_class:
            slice_mask = class_mask[:, :, z]
            if np.sum(slice_mask) > 0:
                area = int(np.sum(slice_mask))
                equivalent_diameter = 2 * (area / 3.14159) ** 0.5 * ((voxel_spacing[0] + voxel_spacing[1]) / 2)
                diameters.append(equivalent_diameter)
        
        if diameters:
            diameter_max = max(diameters)
            diameter_mean = sum(diameters) / len(diameters)
            diameter_min = min(diameters)
        else:
            diameter_max = diameter_mean = diameter_min = 0
        
        # Detect pathology
        has_pathology = False
        pathology_type = None
        pathology_severity = None
        
        if class_name == "aorta":
            if diameter_max > 30:  # Aneurysm threshold
                has_pathology = True
                pathology_type = "aneurysm"
                if diameter_max > 55:
                    pathology_severity = "severe"
                elif diameter_max > 45:
                    pathology_severity = "moderate"
                else:
                    pathology_severity = "mild"
        
        measurements[class_name] = {
            "diameter_max": round(float(diameter_max), 2),
            "diameter_mean": round(float(diameter_mean), 2),
            "diameter_min": round(float(diameter_min), 2),
            "length": round(float(length_mm), 2),
            "volume": round(float(volume_ml), 2),
            "has_pathology": has_pathology,
            "pathology_type": pathology_type,
            "pathology_severity": pathology_severity,
        }
    
    return measurements


@app.get("/")
async def root():
    """Root endpoint"""
    return {
        "name": "VASCULAR.AI - AI Segmentation Service",
        "version": "1.0.0",
        "status": "running",
        "model_type": "mock"
    }


@app.get("/health")
async def health_check():
    """Health check endpoint"""
    return {
        "status": "healthy",
        "model_loaded": model is not None
    }


@app.post("/segment", response_model=SegmentationResponse)
async def segment(request: SegmentationRequest, background_tasks: BackgroundTasks):
    """Run segmentation on a NIfTI file"""
    
    try:
        # Run segmentation
        mask, dice_scores = model.predict(request.nifti_path)
        
        # Save mask
        mask_path = OUTPUT_DIR / f"{request.study_uid}_mask.nii.gz"
        
        # Create mock NIfTI header
        affine = np.eye(4)
        mask_img = nib.Nifti1Image(mask, affine)
        nib.save(mask_img, str(mask_path))
        
        # Calculate measurements
        voxel_spacing = [1.0, 1.0, 1.0]  # Mock spacing
        measurements = calculate_measurements(mask, voxel_spacing)
        
        # Get detected classes
        detected_classes = [int(c) for c in np.unique(mask) if c != 0]
        
        return SegmentationResponse(
            success=True,
            study_uid=request.study_uid,
            classes=detected_classes,
            dice_scores=dice_scores,
            mask_path=str(mask_path),
            measurements=measurements
        )
    
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Segmentation failed: {str(e)}")


@app.get("/models")
async def list_models():
    """List available models"""
    
    return {
        "models": [
            {
                "name": "vascular_segmentation",
                "version": "1.0.0",
                "classes": len(VESSEL_CLASSES) - 1,
                "description": "Multi-class vessel segmentation"
            }
        ]
    }


@app.get("/classes")
async def get_classes():
    """Get vessel class definitions"""
    
    return {
        "classes": [
            {
                "id": class_id,
                "name": info["name"],
                "display_name": info["display_name"]
            }
            for class_id, info in VESSEL_CLASSES.items() if class_id != 0
        ]
    }


if __name__ == "__main__":
    import uvicorn
    uvicorn.run(
        "app.main:app",
        host="0.0.0.0",
        port=8001,
        log_level="info"
    )
