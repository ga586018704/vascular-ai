# VASCULAR.AI - Индекс документации

Полный набор документации для платформы VASCULAR.AI.

---

## 📚 Документация по категориям

### 🚀 Начало работы

| Документ | Описание | Аудитория |
|----------|----------|-----------|
| [README.md](README.md) | Общее описание проекта | Все |
| [QUICKSTART.md](QUICKSTART.md) | Быстрый старт за 5 минут | Разработчики |
| [VASCULAR_AI_COMPLETE_SUMMARY.md](VASCULAR_AI_COMPLETE_SUMMARY.md) | Полная сводка проекта | Все |

### 📖 Руководства

| Документ | Описание | Аудитория |
|----------|----------|-----------|
| [API_REFERENCE.md](API_REFERENCE.md) | Полная документация API | Разработчики, интеграторы |
| [PRESENTATION.md](PRESENTATION.md) | Презентация для стейкхолдеров | Инвесторы, руководство |
| [SURGEON_TOOLS.md](SURGEON_TOOLS.md) | Инструменты для хирургов | Врачи |
| [CLINICAL_GUIDELINES.md](CLINICAL_GUIDELINES.md) | Интеграция клинических руководств | Врачи |
| [LABORATORY_AND_KB.md](LABORATORY_AND_KB.md) | Лабораторные исследования и справочник | Врачи, разработчики |
| [BOOKS_AND_SCIENTIFIC_DATA.md](BOOKS_AND_SCIENTIFIC_DATA.md) | Данные из книг и научных источников | Врачи, исследователи |

### 🔒 Безопасность

| Документ | Описание | Аудитория |
|----------|----------|-----------|
| [SECURITY.md](SECURITY.md) | Политика безопасности | DevOps, Security |
| [AUDIT_REPORT.md](AUDIT_REPORT.md) | Отчет аудита безопасности | Security аудиторы |
| [SECURITY_IMPROVEMENTS.md](SECURITY_IMPROVEMENTS.md) | Улучшения безопасности | Разработчики |
| [SECURITY_DEPLOYMENT_CHECKLIST.md](SECURITY_DEPLOYMENT_CHECKLIST.md) | Чеклист деплоя | DevOps |
| [SECURITY_AUDIT_COMPLETE.md](SECURITY_AUDIT_COMPLETE.md) | Итоги аудита | Руководство |

### 🤖 AI и ML

| Документ | Описание | Аудитория |
|----------|----------|-----------|
| [AI_AGENTS_DOCUMENTATION.md](AI_AGENTS_DOCUMENTATION.md) | Документация AI агентов | ML инженеры |
| [FEATURES_v5.0.md](FEATURES_v5.0.md) | Функционал версии 5.0 | Все |
| [FEATURES_v4.0.md](FEATURES_v4.0.md) | Функционал версии 4.0 | Все |
| [FEATURES_v3.0.md](FEATURES_v3.0.md) | Функционал версии 3.0 | Все |
| [FEATURES_v2.1.md](FEATURES_v2.1.md) | Функционал версии 2.1 | Все |

### 📋 Прочее

| Документ | Описание | Аудитория |
|----------|----------|-----------|
| [CHANGELOG_v2.0.md](CHANGELOG_v2.0.md) | История изменений | Все |

---

## 🗂️ Структура проекта

```
vascular-ai/
├── 📁 backend/                 # FastAPI backend
│   ├── app/
│   │   ├── agents/            # AI агенты
│   │   ├── api/               # API endpoints
│   │   ├── core/              # Ядро (security, config)
│   │   ├── db/                # База данных
│   │   ├── laboratory/        # Лабораторные исследования
│   │   ├── knowledge_base/    # Медицинский справочник
│   │   ├── models/            # SQLAlchemy модели
│   │   ├── schemas/           # Pydantic схемы
│   │   └── services/          # Бизнес-логика
│   ├── alembic/               # Миграции
│   └── tests/                 # Тесты
│
├── 📁 frontend/               # React frontend
│   ├── src/
│   │   ├── components/        # React компоненты
│   │   │   └── dicom-viewer/  # DICOM viewer
│   │   ├── pages/             # Страницы
│   │   ├── hooks/             # React hooks
│   │   ├── store/             # State management
│   │   └── services/          # API клиент
│   └── tests/                 # Тесты
│
├── 📁 ai-service/             # GPU сервис сегментации
│   ├── src/
│   │   ├── models/            # ML модели
│   │   ├── segmentation/      # Сегментация
│   │   └── utils/             # Утилиты
│   └── tests/                 # Тесты
│
├── 📁 k8s/                    # Kubernetes манифесты
│   ├── base/                  # Базовые ресурсы
│   └── overlays/              # Окружения
│
├── 📁 monitoring/             # Мониторинг
│   ├── prometheus/            # Метрики
│   └── grafana/               # Дашборды
│
├── 📁 .github/                # GitHub Actions
│   └── workflows/
│
└── 📄 docker-compose.yml      # Docker Compose
```

---

## 🎯 Быстрые ссылки

### Для разработчиков

1. [QUICKSTART.md](QUICKSTART.md) - начните здесь
2. [API_REFERENCE.md](API_REFERENCE.md) - интеграция с API
3. [backend/app/core/security.py](backend/app/core/security.py) - безопасность

### Для врачей

1. [SURGEON_TOOLS.md](SURGEON_TOOLS.md) - инструменты
2. [CLINICAL_GUIDELINES.md](CLINICAL_GUIDELINES.md) - руководства
3. [PRESENTATION.md](PRESENTATION.md) - обзор платформы

### Для DevOps

1. [SECURITY_DEPLOYMENT_CHECKLIST.md](SECURITY_DEPLOYMENT_CHECKLIST.md)
2. [k8s/](k8s/) - Kubernetes манифесты
3. [monitoring/](monitoring/) - мониторинг

### Для инвесторов

1. [PRESENTATION.md](PRESENTATION.md) - презентация
2. [VASCULAR_AI_COMPLETE_SUMMARY.md](VASCULAR_AI_COMPLETE_SUMMARY.md) - полный обзор

---

## 📊 Статистика проекта

```
Код:
├── Backend:     ~18,000 строк Python (+3,000)
├── Frontend:    ~10,000 строк TypeScript/React (+2,000)
├── AI Service:  ~5,000 строк Python
└── Tests:       ~10,000 строк (+2,000)

Документация:
├── Руководства: 25+ документов
├── Страницы:    800+ страниц
└── Диаграммы:   10+ диаграмм

Инфраструктура:
├── Kubernetes:  20+ манифестов
├── CI/CD:       3 pipeline
├── Monitoring:  15+ dashboards
└── Docker:      Полный compose stack
```

---

## 🔗 Внешние ресурсы

### API
- Swagger UI: `http://localhost:8000/docs`
- ReDoc: `http://localhost:8000/redoc`
- OpenAPI: `http://localhost:8000/openapi.json`

### Мониторинг
- Prometheus: `http://localhost:9090`
- Grafana: `http://localhost:3000`

### Хранилище
- MinIO Console: `http://localhost:9001`

---

## 📞 Поддержка

- 📧 Email: support@vascular.ai
- 💬 Slack: #vascular-ai-support
- 🐛 Issues: https://github.com/vascular-ai/issues
- 📖 Wiki: https://wiki.vascular.ai

---

## 📝 Лицензия

MIT License - см. [LICENSE](LICENSE) файл

---

**Последнее обновление:** Апрель 2024  
**Версия документации:** 1.0