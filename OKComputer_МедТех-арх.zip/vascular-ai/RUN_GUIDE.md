# VASCULAR.AI - Руководство по запуску

## ⚡ Быстрый старт (5 минут)

```bash
# 1. Клонировать репозиторий
git clone https://github.com/your-org/vascular-ai.git
cd vascular-ai

# 2. Запустить через Docker Compose
docker-compose up -d

# 3. Применить миграции базы данных
docker-compose exec backend alembic upgrade head

# 4. Загрузить seed-данные (опционально)
docker-compose exec backend python -c "
import asyncio
from app.knowledge_base.seed_data import run_seeder
asyncio.run(run_seeder())
"

# 5. Проверить работу
curl http://localhost:8000/health
```

✅ **Готово!** Откройте http://localhost:3000 в браузере.

---

## 📋 Предварительные требования

### Минимальные (для разработки)
| Компонент | Версия | Проверка |
|-----------|--------|----------|
| Docker | 24.0+ | `docker --version` |
| Docker Compose | 2.20+ | `docker-compose --version` |
| Git | 2.40+ | `git --version` |
| 8 GB RAM | - | - |
| 20 GB диск | SSD | - |

### Рекомендуемые (для AI)
| Компонент | Требование |
|-----------|------------|
| GPU | NVIDIA с 8GB+ VRAM |
| NVIDIA Docker | nvidia-docker2 |
| CUDA | 12.0+ |
| 32 GB RAM | - |
| 100 GB SSD | - |

---

## 🐳 Способ 1: Docker Compose (Рекомендуется)

### Шаг 1: Клонирование

```bash
git clone https://github.com/your-org/vascular-ai.git
cd vascular-ai
```

### Шаг 2: Настройка переменных окружения

```bash
# Создать файл .env в корне проекта
cat > .env << 'EOF'
# Database
POSTGRES_USER=postgres
POSTGRES_PASSWORD=postgres
POSTGRES_DB=vascular_ai

# Backend
SECRET_KEY=your-super-secret-key-min-32-characters
ENCRYPTION_KEY=your-encryption-key-for-phi-data
DEBUG=true

# External APIs (опционально)
OPENAI_API_KEY=your-openai-key
ANTHROPIC_API_KEY=your-anthropic-key
NCBI_API_KEY=your-ncbi-key

# AI Service
MODEL_PATH=/models
CUDA_VISIBLE_DEVICES=0
EOF
```

### Шаг 3: Запуск сервисов

```bash
# Запуск всех сервисов
docker-compose up -d

# Проверка статуса
docker-compose ps

# Просмотр логов
docker-compose logs -f

# Логи конкретного сервиса
docker-compose logs -f backend
```

### Шаг 4: Инициализация базы данных

```bash
# Применить миграции
docker-compose exec backend alembic upgrade head

# Проверить подключение к БД
docker-compose exec postgres psql -U postgres -d vascular_ai -c "\dt"
```

### Шаг 5: Загрузка seed-данных (опционально)

```bash
# Загрузить категории, теги, статьи из книг
docker-compose exec backend python -c "
import asyncio
from sqlalchemy.ext.asyncio import create_async_engine, AsyncSession
from sqlalchemy.orm import sessionmaker
from app.knowledge_base.seed_data import KnowledgeBaseSeeder

DATABASE_URL = 'postgresql+asyncpg://postgres:postgres@postgres:5432/vascular_ai'
engine = create_async_engine(DATABASE_URL)
async_session = sessionmaker(engine, class_=AsyncSession, expire_on_commit=False)

async def seed():
    async with async_session() as session:
        seeder = KnowledgeBaseSeeder(session)
        await seeder.seed_all()

asyncio.run(seed())
"
```

### Шаг 6: Проверка работоспособности

```bash
# Health check backend
curl http://localhost:8000/health

# Health check AI service
curl http://localhost:8001/health

# API docs (Swagger)
open http://localhost:8000/docs

# Frontend
open http://localhost:3000
```

### Шаг 7: Создание первого пользователя

```bash
# Регистрация администратора
curl -X POST http://localhost:8000/api/v1/auth/register \
  -H "Content-Type: application/json" \
  -d '{
    "email": "admin@vascular.ai",
    "password": "SecurePass123!",
    "first_name": "Admin",
    "last_name": "User",
    "role": "admin"
  }'

# Логин
curl -X POST http://localhost:8000/api/v1/auth/login \
  -H "Content-Type: application/x-www-form-urlencoded" \
  -d "username=admin@vascular.ai&password=SecurePass123!"
```

---

## 💻 Способ 2: Локальная разработка

### Backend (Python)

```bash
# 1. Перейти в директорию backend
cd backend

# 2. Создать виртуальное окружение
python -m venv venv

# 3. Активировать окружение
# Linux/Mac:
source venv/bin/activate
# Windows:
venv\Scripts\activate

# 4. Установить зависимости
pip install -r requirements.txt

# 5. Создать файл .env
cat > .env << 'EOF'
DATABASE_URL=postgresql+asyncpg://postgres:postgres@localhost:5432/vascular_ai
REDIS_URL=redis://localhost:6379/0
SECRET_KEY=your-secret-key-min-32-characters
ENCRYPTION_KEY=your-encryption-key
AI_SERVICE_URL=http://localhost:8001
DEBUG=true
EOF

# 6. Запустить PostgreSQL и Redis (через Docker)
docker run -d --name vascular-postgres \
  -e POSTGRES_USER=postgres \
  -e POSTGRES_PASSWORD=postgres \
  -e POSTGRES_DB=vascular_ai \
  -p 5432:5432 postgres:15-alpine

docker run -d --name vascular-redis \
  -p 6379:6379 redis:7-alpine

# 7. Применить миграции
alembic upgrade head

# 8. Запустить сервер разработки
uvicorn app.main:app --reload --host 0.0.0.0 --port 8000
```

Backend доступен по адресу: http://localhost:8000

### Frontend (React + TypeScript)

```bash
# 1. Перейти в директорию frontend
cd frontend

# 2. Установить зависимости
npm install

# 3. Создать файл .env.local
cat > .env.local << 'EOF'
VITE_API_URL=http://localhost:8000/api/v1
EOF

# 4. Запустить сервер разработки
npm run dev
```

Frontend доступен по адресу: http://localhost:5173

### AI Service (GPU)

```bash
# 1. Перейти в директорию ai-service
cd ai-service

# 2. Создать виртуальное окружение
python -m venv venv
source venv/bin/activate  # или venv\Scripts\activate

# 3. Установить зависимости
pip install -r requirements.txt

# 4. Загрузить модели (если есть доступ)
python scripts/download_models.py

# 5. Запустить сервис
python src/main.py
```

AI Service доступен по адресу: http://localhost:8001

---

## 🧪 Проверка установки

### Тестовые команды

```bash
# 1. Health check всех сервисов
echo "=== Backend ==="
curl -s http://localhost:8000/health | jq

echo "=== AI Service ==="
curl -s http://localhost:8001/health | jq

# 2. Создать тестового пациента
curl -X POST http://localhost:8000/api/v1/patients \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer YOUR_TOKEN" \
  -d '{
    "first_name": "Test",
    "last_name": "Patient",
    "date_of_birth": "1975-01-01",
    "gender": "male",
    "mrn": "TEST001"
  }'

# 3. Поиск в Knowledge Base
curl "http://localhost:8000/api/v1/kb/search?q=AAA&limit=5" \
  -H "Authorization: Bearer YOUR_TOKEN" | jq

# 4. Получить quick reference
curl http://localhost:8000/api/v1/kb/quick-reference/aaa_sizes \
  -H "Authorization: Bearer YOUR_TOKEN" | jq
```

### Web интерфейс

1. Откройте http://localhost:3000
2. Войдите с созданными учетными данными
3. Проверьте:
   - Список пациентов
   - DICOM Viewer
   - Knowledge Base
   - Laboratory Panel

---

## 🔧 Устранение неполадок

### Проблема: PostgreSQL не запускается

```bash
# Проверить логи
docker-compose logs postgres

# Пересоздать volume (ВНИМАНИЕ: данные будут потеряны!)
docker-compose down -v
docker-compose up -d postgres

# Или проверить права доступа
docker-compose exec postgres ls -la /var/lib/postgresql/data
```

### Проблема: Backend не подключается к БД

```bash
# Проверить подключение
docker-compose exec backend python -c "
import asyncio
from sqlalchemy.ext.asyncio import create_async_engine

async def test():
    engine = create_async_engine('postgresql+asyncpg://postgres:postgres@postgres:5432/vascular_ai')
    async with engine.connect() as conn:
        result = await conn.execute('SELECT 1')
        print(result.fetchone())

asyncio.run(test())
"
```

### Проблема: AI Service не видит GPU

```bash
# Проверить NVIDIA Docker
nvidia-docker run --rm nvidia/cuda:12.0-base nvidia-smi

# Проверить в docker-compose.yml должно быть:
# runtime: nvidia
# или
# deploy:
#   resources:
#     reservations:
#       devices:
#         - driver: nvidia
#           count: 1
#           capabilities: [gpu]
```

### Проблема: Frontend не может подключиться к API

```bash
# Проверить CORS
curl -I http://localhost:8000/api/v1/health

# Должен быть заголовок:
# Access-Control-Allow-Origin: *

# Проверить .env.local во frontend
# VITE_API_URL должен указывать на backend
```

### Проблема: Порт уже занят

```bash
# Найти процесс
lsof -i :8000
lsof -i :3000
lsof -i :5432

# Или изменить порты в docker-compose.yml
# ports:
#   - "8080:8000"  # вместо "8000:8000"
```

---

## 📊 Полезные команды

### Docker Compose

```bash
# Запуск
docker-compose up -d

# Остановка
docker-compose down

# Перезапуск
docker-compose restart

# Пересборка
docker-compose up -d --build

# Просмотр логов
docker-compose logs -f [service_name]

# Выполнить команду в контейнере
docker-compose exec [service] [command]

# Очистка
docker-compose down -v  # удалить volumes
docker system prune      # очистить неиспользуемые образы
```

### База данных

```bash
# Подключиться к PostgreSQL
docker-compose exec postgres psql -U postgres -d vascular_ai

# Полезные SQL команды
\dt                    # список таблиц
\d table_name          # структура таблицы
SELECT * FROM users;   # просмотр данных

# Создать бэкап
docker-compose exec postgres pg_dump -U postgres vascular_ai > backup.sql

# Восстановить из бэкап
docker-compose exec -T postgres psql -U postgres -d vascular_ai < backup.sql
```

### Redis

```bash
# Подключиться к Redis
docker-compose exec redis redis-cli

# Полезные команды
KEYS *                 # список ключей
GET key_name           # получить значение
FLUSHALL               # очистить все (осторожно!)
```

### Backend

```bash
# Миграции
docker-compose exec backend alembic revision --autogenerate -m "description"
docker-compose exec backend alembic upgrade head
docker-compose exec backend alembic downgrade -1

# Тесты
docker-compose exec backend pytest
docker-compose exec backend pytest tests/test_laboratory.py -v

# Python shell
docker-compose exec backend python
```

---

## 🌐 Доступные сервисы

После запуска:

| Сервис | URL | Описание |
|--------|-----|----------|
| Frontend | http://localhost:3000 | Web приложение |
| Backend API | http://localhost:8000 | FastAPI |
| API Docs | http://localhost:8000/docs | Swagger UI |
| AI Service | http://localhost:8001 | GPU сервис |
| PostgreSQL | localhost:5432 | База данных |
| Redis | localhost:6379 | Кэш |
| MinIO Console | http://localhost:9001 | S3 хранилище |
| MinIO API | localhost:9000 | S3 API |

---

## 🔄 Обновление проекта

```bash
# 1. Получить обновления
git pull origin main

# 2. Пересобрать образы
docker-compose up -d --build

# 3. Применить новые миграции
docker-compose exec backend alembic upgrade head

# 4. Очистить кэш (если нужно)
docker-compose restart redis
```

---

## 🛑 Остановка проекта

```bash
# Остановить сервисы
docker-compose down

# Удалить все данные (ВНИМАНИЕ!)
docker-compose down -v
docker system prune -a
```

---

## 📞 Поддержка

Если у вас возникли проблемы:

1. Проверьте логи: `docker-compose logs`
2. Проверьте статус: `docker-compose ps`
3. Откройте issue: https://github.com/your-org/vascular-ai/issues
4. Напишите в Slack: #vascular-ai-support

---

**Готово к работе!** 🚀