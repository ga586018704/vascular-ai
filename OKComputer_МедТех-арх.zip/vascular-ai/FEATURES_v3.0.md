# VASCULAR.AI v3.0 - Новые функции

## Обзор

Версия 3.0 добавляет значительное количество новых функций, разработанных с точки зрения практикующего сосудистого хирурга.

## Новые модули

### 1. Планирование сосудистого доступа (`vascular_access.py`)

#### Диализный доступ
- **Fistula First** принципы и алгоритмы выбора
- Радиоцефальная фистула (Brescia-Cimino)
- Базилико-цефальная фистула (прямая и транспозиция)
- Брахиобазиликовая фистула
- Протезы для диализа (петлевой, плечевой)
- Оценка созревания фистулы
- Управление осложнениями (тромбоз, стеноз, инфекция, steal syndrome)
- График наблюдения

#### Эндоваскулярный доступ
- Общая бедренная артерия (размеры шитов, техника)
- Лучевая артерия (Barbeau test, спазмолитики)
- Брахиальная артерия
- Подколенная артерия
- Педальный доступ
- Устройства для закрытия (Perclose, Angio-Seal, StarClose)
- Управление осложнениями доступа

#### Доступ для TEVAR/EVAR
- Оценка подвздошных артерий
- Минимальные диаметры для разных размеров шитов
- Техники доступа (перкутанный, cutdown)
- Хирургический кондуит при необходимости

**API Endpoints:**
- `POST /api/advanced/vascular-access/dialysis` - Рекомендация диализного доступа
- `GET /api/advanced/vascular-access/dialysis/guide` - Полное руководство
- `POST /api/advanced/vascular-access/endovascular` - Планирование эндоваскулярного доступа
- `GET /api/advanced/vascular-access/endovascular/guide` - Руководство по доступу

---

### 2. 3D инструменты измерения (`measurements_3d.py`)

#### EVAR планирование
- Измерения проксимальной шейки (диаметр, длина, ангуляция, тромб, кальциноз)
- Измерения мешка аневризмы (максимальный диаметр, длина, объем)
- Оценка подвздошных артерий
- Зоны landing (Zone 0-9)
- Выбор устройства (Cook Zenith, Gore Excluder, Medtronic Endurant, Lombard Aorfix)
- Рекомендации по oversizing (10-20% проксимально, 10-15% дистально)
- Расчет размеров стент-графта

#### TEVAR планирование
- Проксимальная зона landing
- Оценка дуги аорты (типы 1-3)
- Расстояния между ветвями
- Планирование покрытия (Zone 0-4)
- Сохранение ветвей (левой подключичной)
- Дистальная зона landing
- Защита спинного мозга (риск-факторы, профилактика)
- Выбор устройства (Gore TAG, Cook TX2, Medtronic Valiant, Bolton Relay, Jotec E-xtra)

**API Endpoints:**
- `POST /api/advanced/measurements/evar-sizing` - Расчет размеров для EVAR
- `POST /api/advanced/measurements/tevar-sizing` - Расчет размеров для TEVAR
- `GET /api/advanced/measurements/checklist/{procedure_type}` - Чек-лист измерений
- `GET /api/advanced/measurements/evar-guide` - Руководство по EVAR
- `GET /api/advanced/measurements/tevar-guide` - Руководство по TEVAR

---

### 3. Интерпретация сосудистой лаборатории (`vascular_lab.py`)

#### АКШ (ABI)
- Техника измерения
- Интерпретация результатов (норма, пограничное, легкая/умеренная/тяжелая ЗАБ)
- Несжимаемые артерии (>1.40)
- Асимметрия между ногами
- Постнагрузочное измерение
- Ограничения метода

#### TBI (Toe-Brachial Index)
- Показания к применению
- Техника измерения
- Интерпретация

#### Сегментарное давление
- Уровни измерения (плечо, верхнее/нижнее бедро, голень, лодыжка)
- Градиенты между уровнями
- Локализация поражения (аорто-подвздошный, бедренно-подколенный, инфрапоплитеальный)

#### PVR (Pulse Volume Recording)
- Техника
- Анализ waveform (triphasic, biphasic, monophasic, damped)
- Градация амплитуды

#### Допплеровская велосиметрия
- Параметры (PSV, EDV, RI, PI)
- Критерии стеноза для сонных артерий
- Критерии для периферических артерий
- Критерии для шунтов
- Паттерны waveform

**API Endpoints:**
- `POST /api/advanced/vascular-lab/abi` - Интерпретация АКШ
- `POST /api/advanced/vascular-lab/segmental-pressures` - Интерпретация сегментарных давлений
- `POST /api/advanced/vascular-lab/doppler` - Интерпретация допплеровских скоростей
- `GET /api/advanced/vascular-lab/guide` - Полное руководство
- `GET /api/advanced/vascular-lab/abi-guide` - Руководство по АКШ
- `GET /api/advanced/vascular-lab/doppler-guide` - Руководство по допплеру

---

### 4. Протоколы сосудистой травмы (`trauma_protocols.py`)

#### Классификация травмы
- Проникающая vs закрытая vs ятрогенная
- Hard signs (требуют немедленной операции)
- Soft signs (требуют обследования)
- Grading (Grade 1-5)

#### Травма шеи
- Зоны 1, 2, 3
- Структуры в каждой зоне
- Подходы к доступу
- Хирургические техники (первичный шов, заплатка, interposition graft, ligation)
- Эндоваскулярные опции (covered stent, coil embolization)

#### Торакальная сосудистая травма
- Большие сосуды (аорта, подключичная, брахиоцефальный ствол)
- Подходы (левосторонняя торакотомия, срединная стернотомия)
- Диагностика и лечение

#### Абдоминальная сосудистая травма
- Аорта (супраренальная, инфраренальная)
- Нижняя полая вена
- Подвздошные артерии и вены
- Брыжеечные сосуды
- Техники экспозиции (медиальное висцеральное вращение)

#### Травма конечностей
- Оценка (hard signs, soft signs)
- Немедленные действия (контроль кровотечения)
- Техники ремонта
- Временный шунт (damage control)
- Синдром компартмент-синдрома (профилактика, фасциотомия)
- Сочетанные повреждения (переломы, нервы, мягкие ткани)

**API Endpoints:**
- `POST /api/advanced/trauma/neck-assessment` - Оценка травмы шеи
- `POST /api/advanced/trauma/extremity-management` - Управление травмой конечности
- `GET /api/advanced/trauma/checklist` - Чек-лист для травмы

---

### 5. Педиатрическая сосудистая хирургия (`pediatric_vascular.py`)

#### Нормальные значения
- Диаметр аорты (формула по BSA)
- Артериальное давление (формула по возрасту)
- Частота пульса по возрастным группам

#### Врожденные аномалии
- Коарктация аорты (диагностика, лечение, follow-up)
- Сосудистые кольца (двойная дуга аорты, правая дуга, легочное слинг)
- ALCAPA (аномальное отхождение ЛКА)
- Болезнь Кавасаки (коронарные аневризмы)

#### Педиатрический сосудистый доступ
- Пупочный катетер (артериальный, венозный)
- Периферический ВВ
- Центральный венозный доступ (Broviac, Hickman, Port-a-cath)
- Артериальный доступ (радиальная, задняя большеберцовая)

#### Педиатрические операции
- Общие принципы (размеры, рост, гепарин, кровопотеря)
- Ремонт коарктации
- Деление сосудистого кольца

**API Endpoints:**
- `POST /api/advanced/pediatric/aortic-diameter` - Расчет диаметра аорты
- `POST /api/advanced/pediatric/coarctation-assessment` - Оценка коарктации
- `GET /api/advanced/pediatric/guide` - Руководство по педиатрической сосудистой хирургии

---

### 6. Предоперационные чек-листы (`preop_checklist.py`)

#### WHO Surgical Safety Checklist
- Sign In (перед анестезией)
- Time Out (перед разрезом)
- Sign Out (перед закрытием)

#### Специфические чек-листы
- Каротидная эндартерэктомия
- EVAR
- Бедренно-подколенное шунтирование
- Операция при варикозной болезни

#### Управление медикаментами
- Антиагреганты (аспирин, клопидогрель)
- Антикоагулянты (варфарин, НОАК)
- Статины
- Бета-блокаторы
- АПФ ингибиторы
- Противодиабетические препараты

**API Endpoints:**
- `POST /api/advanced/checklists/preoperative` - Предоперационный чек-лист
- `POST /api/advanced/checklists/sign-in` - WHO Sign In
- `POST /api/advanced/checklists/time-out` - WHO Time Out
- `POST /api/advanced/checklists/sign-out` - WHO Sign Out
- `GET /api/advanced/checklists/who-safety` - Полный WHO checklist
- `GET /api/advanced/checklists/procedures` - Список доступных чек-листов

---

## Общая статистика

### Модули
- **12** сервисных модулей
- **8** API роутеров
- **80+** эндпоинтов

### Покрытие
- **Аортальная хирургия**: AAA, TAA, диссекция, коарктация
- **Каротидная хирургия**: стеноз, КЭА, CAS
- **Периферические артерии**: ЗАБ, клаудикация, критическая ишемия
- **Венозная патология**: варикоз, ТГВ, посттромботический синдром
- **Диализный доступ**: все типы фистул и протезов
- **Травма**: шея, грудь, живот, конечности
- **Педиатрия**: врожденные аномалии, детский доступ
- **Эндоваскулярное**: EVAR, TEVAR, ангиопластика, стентирование

### Клинические рекомендации
- ESVS 2024 Guidelines
- SVS Guidelines
- ACC/AHA Guidelines
- Российские клинические рекомендации 2025
- TASC II Classification
- CEAP Classification

---

## Использование

### Пример: Планирование EVAR

```python
import requests

# Расчет размеров
data = {
    "neck_diameter": 24,
    "neck_length": 25,
    "aneurysm_length": 120,
    "common_iliac_diameter": 12,
    "external_iliac_diameter": 8
}
response = requests.post("http://localhost:8000/api/advanced/measurements/evar-sizing", json=data)
print(response.json())

# Планирование доступа
access_data = {
    "procedure_type": "evar",
    "femoral_suitable": True
}
response = requests.post("http://localhost:8000/api/advanced/vascular-access/endovascular", json=access_data)
print(response.json())

# Предоперационный чек-лист
checklist_data = {
    "procedure": "evar",
    "on_aspirin": True,
    "on_warfarin": False,
    "on_metformin": False
}
response = requests.post("http://localhost:8000/api/advanced/checklists/preoperative", json=checklist_data)
print(response.json())
```

### Пример: Интерпретация АКШ

```python
data = {
    "right_ankle_pressure": 100,
    "left_ankle_pressure": 140,
    "brachial_pressure": 140
}
response = requests.post("http://localhost:8000/api/advanced/vascular-lab/abi", json=data)
print(response.json())
```

---

## Документация API

После запуска backend, полная документация API доступна по адресу:
- Swagger UI: `http://localhost:8000/docs`
- ReDoc: `http://localhost:8000/redoc`

---

## Лицензия

VASCULAR.AI - открытая платформа для сосудистых хирургов.

---

*Версия 3.0 - Май 2025*
*Разработано сосудистыми хирургами для сосудистых хирургов*
