# VASCULAR.AI - Security Deployment Checklist

## Критические требования перед production-развертыванием

### 1. Переменные окружения (Обязательно)

Создайте файл `.env` с следующими переменными:

```bash
# Security (ОБЯЗАТЕЛЬНО изменить значения!)
SECRET_KEY=your-super-secret-key-min-32-chars-long
ENCRYPTION_KEY=your-32-byte-encryption-key-here!!
ACCESS_TOKEN_EXPIRE_MINUTES=30
REFRESH_TOKEN_EXPIRE_DAYS=7

# Database
DATABASE_URL=sqlite+aiosqlite:///./data/vascular.db

# Environment
ENVIRONMENT=production  # production, staging, development
DEBUG=false

# CORS
CORS_ORIGINS=["https://vascular.ai", "https://app.vascular.ai"]

# File Storage
UPLOAD_DIR=/app/data/uploads
PROCESSED_DIR=/app/data/processed
MAX_UPLOAD_SIZE=52428800  # 50MB

# AI Service
AI_SERVICE_URL=http://ai-service:8001

# Logging
LOG_LEVEL=INFO
LOG_DIR=/app/logs
```

**ВАЖНО:** Никогда не используйте значения по умолчанию в production!

### 2. Генерация ключей

```bash
# Генерация SECRET_KEY (минимум 32 символа)
python -c "import secrets; print(secrets.token_urlsafe(32))"

# Генерация ENCRYPTION_KEY (ровно 32 байта для Fernet)
python -c "from cryptography.fernet import Fernet; print(Fernet.generate_key().decode())"
```

### 3. Проверка безопасности перед деплоем

#### 3.1 Запуск тестов безопасности

```bash
cd backend
pytest tests/security/ -v
```

#### 3.2 Проверка зависимостей на уязвимости

```bash
# Установка safety
pip install safety

# Проверка зависимостей
safety check -r requirements.txt
```

#### 3.3 Статический анализ кода

```bash
# Установка bandit
pip install bandit

# Проверка кода
bandit -r app/ -f json -o bandit-report.json
```

### 4. Настройка HTTPS

#### 4.1 Использование Let's Encrypt

```bash
# Установка certbot
apt-get install certbot

# Получение сертификата
certbot certonly --standalone -d vascular.ai -d app.vascular.ai
```

#### 4.2 Nginx конфигурация

```nginx
server {
    listen 443 ssl http2;
    server_name vascular.ai;

    ssl_certificate /etc/letsencrypt/live/vascular.ai/fullchain.pem;
    ssl_certificate_key /etc/letsencrypt/live/vascular.ai/privkey.pem;
    ssl_protocols TLSv1.2 TLSv1.3;
    ssl_ciphers ECDHE-ECDSA-AES128-GCM-SHA256:ECDHE-RSA-AES128-GCM-SHA256;
    ssl_prefer_server_ciphers off;

    # Security headers
    add_header X-Frame-Options "DENY" always;
    add_header X-Content-Type-Options "nosniff" always;
    add_header X-XSS-Protection "1; mode=block" always;
    add_header Strict-Transport-Security "max-age=31536000; includeSubDomains" always;
    add_header Content-Security-Policy "default-src 'self'" always;
    add_header Referrer-Policy "strict-origin-when-cross-origin" always;

    location / {
        proxy_pass http://backend:8000;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
    }
}

# Redirect HTTP to HTTPS
server {
    listen 80;
    server_name vascular.ai;
    return 301 https://$server_name$request_uri;
}
```

### 5. Настройка файрвола

```bash
# UFW (Ubuntu)
ufw default deny incoming
ufw default allow outgoing
ufw allow 22/tcp    # SSH
ufw allow 80/tcp    # HTTP
ufw allow 443/tcp   # HTTPS
ufw enable

# Проверка статуса
ufw status verbose
```

### 6. Настройка Docker Security

#### 6.1 Docker Compose с security options

```yaml
version: '3.8'

services:
  backend:
    build: ./backend
    security_opt:
      - no-new-privileges:true
    cap_drop:
      - ALL
    cap_add:
      - NET_BIND_SERVICE
    read_only: true
    tmpfs:
      - /tmp:noexec,nosuid,size=100m
    user: "1000:1000"
    environment:
      - ENVIRONMENT=production
    env_file:
      - .env
    volumes:
      - ./data:/app/data:rw
      - ./logs:/app/logs:rw
    networks:
      - vascular-network
    restart: unless-stopped
    deploy:
      resources:
        limits:
          cpus: '2'
          memory: 2G
        reservations:
          cpus: '0.5'
          memory: 512M

  frontend:
    build: ./frontend
    security_opt:
      - no-new-privileges:true
    cap_drop:
      - ALL
    user: "1000:1000"
    networks:
      - vascular-network
    restart: unless-stopped

  ai-service:
    build: ./ai-service
    security_opt:
      - no-new-privileges:true
    cap_drop:
      - ALL
    user: "1000:1000"
    networks:
      - vascular-network
    restart: unless-stopped
    deploy:
      resources:
        limits:
          cpus: '4'
          memory: 8G

networks:
  vascular-network:
    driver: bridge
    ipam:
      config:
        - subnet: 172.20.0.0/16
```

### 7. Настройка логирования и мониторинга

#### 7.1 Структура логов

```bash
# Создание директорий
mkdir -p /var/log/vascular-ai/{app,audit,security,error}
chmod 750 /var/log/vascular-ai

# Настройка logrotate
cat > /etc/logrotate.d/vascular-ai << EOF
/var/log/vascular-ai/*.log {
    daily
    rotate 30
    compress
    delaycompress
    missingok
    notifempty
    create 0600 root root
}
EOF
```

#### 7.2 Мониторинг с Prometheus + Grafana

```yaml
# docker-compose.monitoring.yml
version: '3.8'

services:
  prometheus:
    image: prom/prometheus:latest
    volumes:
      - ./monitoring/prometheus.yml:/etc/prometheus/prometheus.yml
      - prometheus-data:/prometheus
    command:
      - '--config.file=/etc/prometheus/prometheus.yml'
      - '--storage.tsdb.path=/prometheus'
      - '--web.console.libraries=/etc/prometheus/console_libraries'
      - '--web.console.templates=/etc/prometheus/consoles'
      - '--web.enable-lifecycle'
    networks:
      - vascular-network

  grafana:
    image: grafana/grafana:latest
    volumes:
      - grafana-data:/var/lib/grafana
      - ./monitoring/grafana/dashboards:/etc/grafana/provisioning/dashboards
      - ./monitoring/grafana/datasources:/etc/grafana/provisioning/datasources
    environment:
      - GF_SECURITY_ADMIN_PASSWORD=${GRAFANA_ADMIN_PASSWORD}
    networks:
      - vascular-network
    ports:
      - "3000:3000"

volumes:
  prometheus-data:
  grafana-data:
```

### 8. Backup и восстановление

#### 8.1 Скрипт бэкапа

```bash
#!/bin/bash
# backup.sh

BACKUP_DIR="/backups/vascular-ai"
DATE=$(date +%Y%m%d_%H%M%S)

# Создание директории
mkdir -p $BACKUP_DIR

# Бэкап базы данных
cp /app/data/vascular.db $BACKUP_DIR/vascular_$DATE.db

# Бэкап загруженных файлов
tar -czf $BACKUP_DIR/uploads_$DATE.tar.gz /app/data/uploads

# Бэкап логов
tar -czf $BACKUP_DIR/logs_$DATE.tar.gz /app/logs

# Удаление старых бэкапов (старше 30 дней)
find $BACKUP_DIR -type f -mtime +30 -delete

echo "Backup completed: $DATE"
```

#### 8.2 Настройка cron

```bash
# Ежедневный бэкап в 2:00 AM
0 2 * * * /app/scripts/backup.sh >> /var/log/backup.log 2>&1
```

### 9. HIPAA Compliance Checklist

- [ ] Шифрование PHI at rest (Fernet encryption)
- [ ] Шифрование PHI in transit (TLS 1.2+)
- [ ] Аутентификация всех пользователей
- [ ] Ролевой доступ (RBAC)
- [ ] Аудит-логи всех операций с PHI
- [ ] Автоматический logout после бездействия
- [ ] Уникальные идентификаторы пользователей
- [ ] Emergency access procedures
- [ ] Регулярные security assessments
- [ ] Training for workforce
- [ ] Business Associate Agreements
- [ ] Incident response plan
- [ ] Data backup and recovery
- [ ] Access logs review (ежемесячно)

### 10. Пост-deployment проверки

#### 10.1 Функциональные проверки

```bash
# Health check
curl https://vascular.ai/health

# Auth endpoints
curl -X POST https://vascular.ai/api/auth/login \
  -d "username=test@example.com&password=testpass"

# Protected endpoints (should require auth)
curl https://vascular.ai/api/dicom/studies  # Should return 401
curl -H "Authorization: Bearer $TOKEN" \
  https://vascular.ai/api/dicom/studies     # Should work
```

#### 10.2 Security проверки

```bash
# Проверка заголовков
curl -I https://vascular.ai/health | grep -i "X-"

# Проверка SSL
curl -vvI https://vascular.ai/health 2>&1 | grep -i "ssl\|tls"

# Проверка rate limiting
for i in {1..15}; do
  curl -s -o /dev/null -w "%{http_code}\n" \
    https://vascular.ai/api/auth/login
done
```

### 11. Incident Response Plan

#### 11.1 Контакты

- Security Officer: security@vascular.ai
- System Admin: admin@vascular.ai
- Legal: legal@vascular.ai

#### 11.2 Процедура при breach

1. **Обнаружение** (0-1 час)
   - Остановить систему
   - Сохранить логи
   - Уведомить Security Officer

2. **Оценка** (1-4 часа)
   - Определить scope
   - Оценить количество затронутых данных
   - Документировать timeline

3. **Уведомление** (24-72 часа)
   - HHS (если >500 записей)
   - Пациенты
   - СМИ (если требуется)

4. **Восстановление**
   - Исправить уязвимость
   - Восстановить систему
   - Усилить мониторинг

### 12. Регулярные задачи

| Задача | Частота | Ответственный |
|--------|---------|---------------|
| Проверка логов | Ежедневно | Security Team |
| Обновление зависимостей | Еженедельно | DevOps |
| Security scan | Еженедельно | Security Team |
| Access review | Ежемесячно | Compliance Officer |
| Penetration test | Ежеквартально | External vendor |
| Disaster recovery test | Ежеквартально | DevOps |
| HIPAA audit | Ежегодно | External auditor |

---

## Подпись

**Дата:** _______________

**Выполнил:** _______________

**Проверил:** _______________

**Утвердил:** _______________
