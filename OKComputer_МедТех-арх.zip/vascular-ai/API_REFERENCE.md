# VASCULAR.AI - API Reference

Полная документация REST API для интеграции с VASCULAR.AI платформой.

**Базовый URL:** `https://api.vascular.ai/api/v1`

---

## 🔐 Аутентификация

Все endpoints требуют Bearer токен в заголовке:

```http
Authorization: Bearer <access_token>
```

### Получение токена

```http
POST /auth/login
Content-Type: application/x-www-form-urlencoded

username=email@example.com&password=yourpassword
```

**Response:**
```json
{
  "access_token": "eyJhbGciOiJIUzI1NiIs...",
  "refresh_token": "eyJhbGciOiJIUzI1NiIs...",
  "token_type": "bearer",
  "expires_in": 1800
}
```

---

## 👤 Пользователи

### Регистрация

```http
POST /auth/register
Content-Type: application/json

{
  "email": "user@example.com",
  "password": "SecurePass123!",
  "first_name": "John",
  "last_name": "Doe",
  "role": "surgeon",
  "license_number": "MD12345"
}
```

**Response:** `201 Created`
```json
{
  "id": "uuid",
  "email": "user@example.com",
  "first_name": "John",
  "last_name": "Doe",
  "role": "surgeon",
  "is_active": true,
  "created_at": "2024-01-15T10:30:00Z"
}
```

### Информация о текущем пользователе

```http
GET /users/me
```

**Response:**
```json
{
  "id": "uuid",
  "email": "user@example.com",
  "first_name": "John",
  "last_name": "Doe",
  "role": "surgeon",
  "permissions": ["read:patients", "write:patients", "read:studies"],
  "institution": {
    "id": "uuid",
    "name": "City Hospital"
  }
}
```

---

## 🏥 Пациенты

### Список пациентов

```http
GET /patients?page=1&limit=20&search=ivanov
```

**Query Parameters:**
| Parameter | Type | Description |
|-----------|------|-------------|
| page | integer | Номер страницы (default: 1) |
| limit | integer | Количество на странице (default: 20, max: 100) |
| search | string | Поиск по имени или MRN |
| sort_by | string | Поле сортировки |
| sort_order | string | asc или desc |

**Response:**
```json
{
  "items": [
    {
      "id": "uuid",
      "first_name": "Иван",
      "last_name": "Иванов",
      "date_of_birth": "1975-03-15",
      "gender": "male",
      "mrn": "MRN001",
      "studies_count": 5,
      "last_study_date": "2024-01-10T14:30:00Z"
    }
  ],
  "total": 150,
  "page": 1,
  "pages": 8
}
```

### Создание пациента

```http
POST /patients
Content-Type: application/json

{
  "first_name": "Иван",
  "last_name": "Иванов",
  "date_of_birth": "1975-03-15",
  "gender": "male",
  "mrn": "MRN001",
  "phone": "+7-999-123-45-67",
  "email": "patient@example.com",
  "address": "Moscow, Russia",
  "emergency_contact": {
    "name": "Мария Иванова",
    "phone": "+7-999-987-65-43",
    "relationship": "spouse"
  }
}
```

### Получение пациента

```http
GET /patients/{patient_id}
```

**Response:**
```json
{
  "id": "uuid",
  "first_name": "Иван",
  "last_name": "Иванов",
  "date_of_birth": "1975-03-15",
  "gender": "male",
  "mrn": "MRN001",
  "medical_history": {
    "allergies": ["penicillin"],
    "medications": ["lisinopril 10mg"],
    "conditions": ["hypertension", "diabetes_type_2"]
  },
  "studies": [
    {
      "id": "uuid",
      "study_date": "2024-01-10",
      "modality": "CT",
      "description": "CT Angiography Abdomen"
    }
  ]
}
```

### Обновление пациента

```http
PUT /patients/{patient_id}
Content-Type: application/json

{
  "phone": "+7-999-111-22-33",
  "medical_history": {
    "medications": ["lisinopril 10mg", "metformin 500mg"]
  }
}
```

### Удаление пациента

```http
DELETE /patients/{patient_id}
```

**Response:** `204 No Content`

---

## 📷 Исследования (Studies)

### Загрузка DICOM

```http
POST /studies
Content-Type: multipart/form-data

patient_id: uuid
study_description: CT Angiography
modality: CT
study_date: 2024-01-15
files: [binary files]
```

**Response:**
```json
{
  "id": "study-uuid",
  "patient_id": "patient-uuid",
  "study_uid": "1.2.840.113619.2.55.3...",
  "study_date": "2024-01-15",
  "modality": "CT",
  "description": "CT Angiography",
  "series_count": 3,
  "instance_count": 450,
  "status": "processing",
  "created_at": "2024-01-15T10:30:00Z"
}
```

### Список исследований

```http
GET /studies?patient_id=uuid&modality=CT&page=1
```

**Response:**
```json
{
  "items": [
    {
      "id": "study-uuid",
      "patient": {
        "id": "patient-uuid",
        "name": "Иванов И.И.",
        "mrn": "MRN001"
      },
      "study_date": "2024-01-15",
      "modality": "CT",
      "description": "CT Angiography Abdomen",
      "status": "completed",
      "segmentation_status": "completed",
      "has_report": true
    }
  ],
  "total": 25
}
```

### Получение исследования

```http
GET /studies/{study_id}
```

**Response:**
```json
{
  "id": "study-uuid",
  "study_uid": "1.2.840.113619.2.55.3...",
  "patient_id": "patient-uuid",
  "study_date": "2024-01-15",
  "modality": "CT",
  "description": "CT Angiography Abdomen",
  "series": [
    {
      "series_uid": "1.2.840.113619.2.55.3.1...",
      "series_number": 1,
      "description": "Arterial Phase",
      "instances": 150,
      "slice_thickness": 0.625
    }
  ],
  "segmentations": [
    {
      "id": "seg-uuid",
      "created_at": "2024-01-15T10:35:00Z",
      "vessel_types": ["aorta", "iliac_artery"],
      "dice_score": 0.92
    }
  ]
}
```

### Получение DICOM instance

```http
GET /studies/{study_id}/instances/{instance_id}
```

**Response:** Binary DICOM file

### Получение изображения в формате PNG/JPEG

```http
GET /studies/{study_id}/instances/{instance_id}/render?quality=90&window_center=40&window_width=400
```

**Query Parameters:**
| Parameter | Type | Description |
|-----------|------|-------------|
| quality | integer | Качество JPEG (1-100) |
| window_center | float | Центр окна (WW/WL) |
| window_width | float | Ширина окна |

---

## 🧠 Сегментация

### Запуск сегментации

```http
POST /segmentation
Content-Type: application/json

{
  "study_id": "study-uuid",
  "vessel_types": ["aorta", "iliac_artery", "femoral_artery"],
  "min_confidence": 0.85,
  "priority": "normal"
}
```

**Response:**
```json
{
  "id": "segmentation-uuid",
  "study_id": "study-uuid",
  "status": "queued",
  "position_in_queue": 3,
  "estimated_time": "120s",
  "created_at": "2024-01-15T10:30:00Z"
}
```

### Статус сегментации

```http
GET /segmentation/{segmentation_id}
```

**Response:**
```json
{
  "id": "segmentation-uuid",
  "study_id": "study-uuid",
  "status": "completed",
  "progress": 100,
  "vessel_types": ["aorta", "iliac_artery"],
  "results": {
    "dice_score": 0.92,
    "processing_time": 45.3,
    "gpu_utilization": 85
  },
  "measurements": [
    {
      "vessel_type": "aorta",
      "location": "infrarenal",
      "diameter_max": 52.3,
      "diameter_min": 48.1,
      "length": 125.4,
      "volume": 45.2
    }
  ],
  "completed_at": "2024-01-15T10:31:00Z"
}
```

### Получение маски сегментации

```http
GET /segmentation/{segmentation_id}/mask
```

**Response:** Binary NIfTI file (.nii.gz)

### Получение 3D модели

```http
GET /segmentation/{segmentation_id}/mesh?format=stl
```

**Query Parameters:**
| Parameter | Type | Description |
|-----------|------|-------------|
| format | string | stl, obj, ply (default: stl) |
| smoothing | boolean | Применить сглаживание |
| decimation | float | Упрощение mesh (0-1) |

---

## 🤖 AI Agents

### Список доступных агентов

```http
GET /agents
```

**Response:**
```json
{
  "agents": [
    {
      "type": "vascular_surgery",
      "name": "Vascular Surgery Agent",
      "description": "Анализ сосудистой патологии",
      "capabilities": ["aaa_analysis", "carotid_stenosis", "pad_assessment"]
    },
    {
      "type": "phlebology",
      "name": "Phlebology Agent",
      "description": "Анализ венозной патологии",
      "capabilities": ["dvt_assessment", "varicose_veins", "venous_ulcers"]
    }
  ]
}
```

### Анализ через AI Agent

```http
POST /agents/analyze
Content-Type: application/json

{
  "agent_type": "vascular_surgery",
  "query": "AAA 5.2cm, male, 68 years, hypertension, former smoker",
  "patient_context": {
    "age": 68,
    "gender": "male",
    "comorbidities": ["hypertension"],
    "smoking_status": "former"
  },
  "include_literature": true,
  "include_guidelines": true,
  "max_sources": 10
}
```

**Response:**
```json
{
  "analysis_id": "analysis-uuid",
  "agent_type": "vascular_surgery",
  "query": "AAA 5.2cm, male, 68 years, hypertension, former smoker",
  "analysis_text": "## Клинический анализ\n\n### Обнаруженная патология\nАбдоминальная аортальная аневризма (AAA) диаметром 5.2 см...\n\n### Рекомендации\nСогласно руководству ESVS 2024, при диаметре AAA ≥5.5 см показано хирургическое вмешательство...",
  "recommendations": [
    {
      "text": "Рекомендуется эндоваскулярное вмешательство (EVAR)",
      "class": "CLASS_I",
      "evidence_level": "IA",
      "sources": ["ESVS 2024", "SVS Guidelines"]
    }
  ],
  "risk_assessment": {
    "rupture_risk_1year": 0.15,
    "surgical_risk": {
      "mortality": 0.02,
      "complications": 0.12
    }
  },
  "sources": [
    {
      "title": "Editor's Choice - European Society for Vascular Surgery (ESVS) 2024...",
      "authors": "Wanhainen A, et al.",
      "journal": "European Journal of Vascular and Endovascular Surgery",
      "year": 2024,
      "pmid": "37977183",
      "evidence_level": "IA",
      "relevance_score": 0.95
    }
  ],
  "confidence": 0.92,
  "processing_time": 3.45,
  "timestamp": "2024-01-15T10:30:00Z"
}
```

### Проверка достоверности

```http
POST /agents/validate
Content-Type: application/json

{
  "analysis_id": "analysis-uuid",
  "validation_type": "comprehensive"
}
```

**Response:**
```json
{
  "validation_id": "validation-uuid",
  "analysis_id": "analysis-uuid",
  "overall_score": 0.89,
  "checks": {
    "evidence_based": {
      "passed": true,
      "score": 0.95,
      "sources_count": 8,
      "high_evidence_count": 5
    },
    "guideline_compliant": {
      "passed": true,
      "score": 0.92,
      "guidelines": ["ESVS 2024", "SVS 2023"]
    },
    "safe": {
      "passed": true,
      "score": 0.98,
      "disclaimers_present": true
    },
    "appropriate": {
      "passed": true,
      "score": 0.85,
      "warnings": ["Consider patient preference"]
    }
  },
  "recommendations": [
    "Add discussion of alternative treatments",
    "Include patient-specific risk factors"
  ],
  "timestamp": "2024-01-15T10:31:00Z"
}
```

---

## 📝 Отчеты

### Создание отчета

```http
POST /reports
Content-Type: application/json

{
  "study_id": "study-uuid",
  "template": "vascular_cta",
  "sections": {
    "clinical_indication": "Оценка размера AAA",
    "technique": "CT angiography with IV contrast",
    "findings": "AAA measuring 5.2 cm in maximum diameter...",
    "impression": "Stable AAA, recommend surveillance",
    "recommendations": "Follow-up CTA in 6 months"
  }
}
```

**Response:**
```json
{
  "id": "report-uuid",
  "study_id": "study-uuid",
  "template": "vascular_cta",
  "status": "draft",
  "sections": {
    "clinical_indication": "Оценка размера AAA",
    "technique": "CT angiography with IV contrast",
    "findings": "AAA measuring 5.2 cm in maximum diameter...",
    "impression": "Stable AAA, recommend surveillance",
    "recommendations": "Follow-up CTA in 6 months"
  },
  "created_by": {
    "id": "user-uuid",
    "name": "Dr. Smith"
  },
  "created_at": "2024-01-15T10:30:00Z"
}
```

### Генерация отчета с AI

```http
POST /reports/generate
Content-Type: application/json

{
  "study_id": "study-uuid",
  "segmentation_id": "segmentation-uuid",
  "template": "vascular_cta",
  "include_measurements": true,
  "language": "ru"
}
```

### Получение отчета

```http
GET /reports/{report_id}
```

### Экспорт отчета

```http
GET /reports/{report_id}/export?format=pdf
```

**Formats:** pdf, docx, html, fhir

---

## 🎤 Голосовой ввод

### Транскрибация аудио

```http
POST /voice/transcribe
Content-Type: multipart/form-data

audio: [binary audio file]
language: ru
medical_context: radiology
```

**Response:**
```json
{
  "transcription_id": "trans-uuid",
  "text": "Аортальная аневризма диаметром пять целых две сантиметра...",
  "confidence": 0.94,
  "language": "ru",
  "medical_terms": [
    {"term": "аортальная аневризма", "start": 0, "end": 20},
    {"term": "диаметр", "start": 21, "end": 28}
  ],
  "processing_time": 2.3
}
```

### WebSocket для real-time транскрибации

```javascript
const ws = new WebSocket('wss://api.vascular.ai/api/v1/voice/stream');

ws.onopen = () => {
  ws.send(JSON.stringify({
    action: 'start',
    language: 'ru',
    medical_context: 'radiology'
  }));
};

ws.onmessage = (event) => {
  const data = JSON.parse(event.data);
  console.log('Transcription:', data.text);
  console.log('Is final:', data.is_final);
};

// Отправка аудио чанками
ws.send(audioChunk);
```

---

## 📊 Мониторинг

### Health Check

```http
GET /health
```

**Response:**
```json
{
  "status": "healthy",
  "version": "1.0.0",
  "timestamp": "2024-01-15T10:30:00Z",
  "services": {
    "database": "connected",
    "redis": "connected",
    "ai_service": "connected",
    "s3": "connected"
  },
  "metrics": {
    "requests_per_minute": 120,
    "average_response_time": 45,
    "active_users": 15
  }
}
```

### Метрики Prometheus

```http
GET /metrics
```

---

## 🧪 Лабораторные исследования

### Создание исследования

```http
POST /laboratory/tests
Content-Type: application/json

{
  "patient_id": "patient-uuid",
  "test_codes": ["CREATININE", "GLUCOSE", "HEMOGLOBIN"],
  "panel_code": "BASIC_METABOLIC",
  "priority": "routine",
  "clinical_indication": "Pre-operative evaluation"
}
```

**Response:**
```json
{
  "id": "test-uuid",
  "order_number": "LAB20240115103045A1B2C3D4",
  "patient_id": "patient-uuid",
  "doctor_id": "doctor-uuid",
  "status": "ordered",
  "priority": "routine",
  "order_date": "2024-01-15T10:30:45Z"
}
```

### Получение списка исследований

```http
GET /laboratory/tests?patient_id=uuid&status=completed&page=1&limit=20
```

**Response:**
```json
{
  "items": [
    {
      "id": "test-uuid",
      "order_number": "LAB20240115103045A1B2C3D4",
      "patient_id": "patient-uuid",
      "status": "completed",
      "result_date": "2024-01-15T11:30:00Z"
    }
  ],
  "total": 25,
  "page": 1,
  "pages": 3
}
```

### Добавление результата

```http
POST /laboratory/tests/{test_id}/results
Content-Type: application/json

{
  "test_code": "CREATININE",
  "test_name": "Creatinine",
  "value_numeric": 1.2,
  "unit": "mg/dL",
  "reference_min": 0.7,
  "reference_max": 1.3
}
```

**Response:**
```json
{
  "id": "result-uuid",
  "test_code": "CREATININE",
  "test_name": "Creatinine",
  "value_numeric": 1.2,
  "unit": "mg/dL",
  "interpretation": "normal",
  "interpretation_text": "В пределах нормы: 1.2",
  "is_critical": false,
  "is_abnormal": false
}
```

### Получение истории показателя

```http
GET /laboratory/patients/{patient_id}/history/CREATININE?limit=20
```

**Response:**
```json
[
  {
    "date": "2024-01-15T10:30:00Z",
    "value": 1.2,
    "unit": "mg/dL",
    "interpretation": "normal"
  },
  {
    "date": "2024-01-01T09:00:00Z",
    "value": 1.3,
    "unit": "mg/dL",
    "interpretation": "normal"
  }
]
```

### Анализ лабораторных данных

```http
POST /laboratory/analyze
Content-Type: application/json

{
  "patient_id": "patient-uuid",
  "test_codes": ["CREATININE", "GLUCOSE", "HEMOGLOBIN"],
  "date_from": "2024-01-01T00:00:00Z",
  "date_to": "2024-01-31T23:59:59Z",
  "include_trends": true,
  "include_ai_analysis": true
}
```

**Response:**
```json
{
  "patient_id": "patient-uuid",
  "summary": {
    "total_tests": 15,
    "abnormal_count": 2,
    "critical_count": 0
  },
  "abnormal_results": [...],
  "critical_results": [],
  "trends": [
    {
      "test_code": "CREATININE",
      "test_name": "Creatinine",
      "trend_direction": "stable",
      "values_count": 5
    }
  ],
  "ai_analysis": "Все показатели в пределах нормы...",
  "recommendations": [
    "Продолжить текущую терапию",
    "Контроль через 3 месяца"
  ]
}
```

### Сравнение результатов

```http
POST /laboratory/compare
Content-Type: application/json

{
  "patient_id": "patient-uuid",
  "test_codes": ["CREATININE", "GLUCOSE"],
  "date_points": ["2024-01-01", "2024-01-15", "2024-01-30"]
}
```

**Response:**
```json
{
  "patient_id": "patient-uuid",
  "comparisons": [
    {
      "test_code": "CREATININE",
      "test_name": "Creatinine",
      "values": [...],
      "changes": {
        "absolute": 0.1,
        "percent": 8.3,
        "direction": "increased"
      }
    }
  ],
  "changes_summary": {
    "improved": 1,
    "worsened": 0,
    "unchanged": 1
  }
}
```

### Панели тестов

```http
GET /laboratory/panels
```

**Response:**
```json
{
  "items": [
    {
      "id": "panel-uuid",
      "code": "BASIC_METABOLIC",
      "name": "Basic Metabolic Panel",
      "category": "biochemistry",
      "test_codes": ["SODIUM", "POTASSIUM", "GLUCOSE", "CREATININE"]
    }
  ]
}
```

---

## 📚 Медицинский справочник

### Поиск в справочнике

```http
GET /kb/search?q=AAA&type=disease&page=1&limit=20
```

**Response:**
```json
{
  "items": [
    {
      "id": "article-uuid",
      "code": "I71.4",
      "title": "Abdominal Aortic Aneurysm",
      "article_type": "disease",
      "summary": "Абдоминальная аортальная аневризма - локальное расширение аорты...",
      "view_count": 1250
    }
  ],
  "total": 15,
  "page": 1,
  "pages": 1
}
```

### Получение статьи

```http
GET /kb/articles/{article_id}
```

**Response:**
```json
{
  "id": "article-uuid",
  "code": "I71.4",
  "title": "Abdominal Aortic Aneurysm",
  "title_en": "Abdominal Aortic Aneurysm",
  "article_type": "disease",
  "summary": "Абдоминальная аортальная аневризма...",
  "content": "Полный текст статьи...",
  "icd10_codes": ["I71.4"],
  "evidence_level": "IA",
  "sources": [
    {
      "title": "ESVS Guidelines 2024",
      "url": "https://...",
      "type": "guideline"
    }
  ],
  "categories": [...],
  "tags": [...],
  "view_count": 1250
}
```

### Поиск препаратов

```http
GET /kb/medications/search?q=warfarin
```

**Response:**
```json
{
  "items": [
    {
      "id": "med-uuid",
      "generic_name": "Warfarin",
      "brand_names": ["Coumadin", "Jantoven"],
      "drug_class": "Anticoagulant",
      "indications": ["Atrial fibrillation", "DVT/PE", "Mechanical heart valve"]
    }
  ],
  "total": 1
}
```

### Проверка взаимодействий

```http
POST /kb/medications/check-interactions
Content-Type: application/json

{
  "drugs": ["warfarin", "aspirin", "atorvastatin"]
}
```

**Response:**
```json
{
  "interactions": [
    {
      "drug1": "Warfarin",
      "drug2": "Aspirin",
      "severity": "major",
      "description": "Increased risk of bleeding",
      "recommendation": "Monitor INR closely"
    }
  ],
  "count": 1,
  "has_major_interactions": true
}
```

### Поиск заболеваний

```http
GET /kb/diseases/search?q=aneurysm&body_system=cardiovascular
```

**Response:**
```json
{
  "items": [
    {
      "id": "disease-uuid",
      "symptoms": ["Asymptomatic", "Abdominal pain", "Back pain"],
      "diagnostic_criteria": "CTA showing aortic diameter >3cm",
      "treatment_options": [...]
    }
  ],
  "total": 5
}
```

### Клинические руководства

```http
GET /kb/guidelines?organization=ESVS&year=2024
```

**Response:**
```json
{
  "items": [
    {
      "id": "guideline-uuid",
      "title": "ESVS Guidelines on Aortic Disease 2024",
      "organization": "ESVS",
      "guideline_year": 2024,
      "key_recommendations": [...]
    }
  ],
  "total": 3,
  "page": 1,
  "pages": 1
}
```

### Быстрый справочник

```http
GET /kb/quick-reference/vascular_emergency
```

**Response:**
```json
{
  "title": "Сосудистые экстренные состояния",
  "items": [
    {
      "condition": "Расслоение аорты",
      "symptoms": ["Внезапная сильная боль в груди/спине"],
      "actions": ["Немедленная КТ-ангиография", "Контроль АД"],
      "mortality": "1-2% в час без лечения"
    }
  ]
}
```

### Избранное

```http
# Добавить в избранное
POST /kb/favorites/{article_id}?notes="Important for AAA cases"

# Получить избранное
GET /kb/favorites?page=1&limit=20

# Удалить из избранного
DELETE /kb/favorites/{article_id}
```

### Категории

```http
# Получить категории
GET /kb/categories

# Дерево категорий
GET /kb/categories/tree

# Статьи категории
GET /kb/categories/{category_id}/articles
```

---

## 📖 Данные из книг и научных источников

### Поиск по интегрированным источникам

```http
GET /kb/search?q=EVLA&source=chronic_venous_disorders
```

**Response:**
```json
{
  "items": [
    {
      "id": "article-uuid",
      "code": "endovenous_laser",
      "title": "Эндовенозная лазерная абляция (EVLA)",
      "source": "chronic_venous_disorders",
      "source_title": "Chronic Venous Disorders of the Lower Limbs",
      "authors": ["Subramoniam Vaidyanathan", "Riju Ramachandran Menon"],
      "year": 2015,
      "content": "...",
      "key_points": [
        "Золотой стандарт лечения GSV рефлюкса",
        "Успех: 93-98% через 5 лет"
      ]
    }
  ],
  "total": 1
}
```

### Классификация CEAP

```http
GET /kb/articles/by-code/ceap_classification
```

**Response:**
```json
{
  "id": "article-uuid",
  "code": "ceap_classification",
  "title": "CEAP Classification of Chronic Venous Disorders",
  "article_type": "disease",
  "content": "Классификация CEAP (Clinical, Etiological, Anatomical, Pathophysiological)...",
  "structured_data": {
    "clinical_classes": {
      "C0": "Нет видимых признаков",
      "C1": "Телеангиэктазии",
      "C2": "Варикозные вены",
      "C3": "Отеки",
      "C4a": "Пигментация",
      "C4b": "Липодерматосклероз",
      "C5": "Зажившая язва",
      "C6": "Активная язва"
    },
    "etiology": {
      "Ec": "Врожденная",
      "Ep": "Первичная",
      "Es": "Вторичная"
    }
  },
  "source": {
    "book": "Chronic Venous Disorders of the Lower Limbs",
    "authors": ["Subramoniam Vaidyanathan", "et al."],
    "publisher": "Springer India",
    "year": 2015,
    "isbn": "978-81-322-1991-0"
  }
}
```

### Профилактика CIN

```http
GET /kb/articles/by-code/cin_prevention
```

**Response:**
```json
{
  "id": "article-uuid",
  "code": "cin_prevention",
  "title": "Профилактика контраст-индуцированной нефропатии (CIN)",
  "article_type": "procedure",
  "content": "...",
  "risk_factors": [
    "Хроническая болезнь почек",
    "Диабет",
    "Дегидратация"
  ],
  "prevention_protocol": {
    "hydration": "Изотонический NaCl 1 мл/кг/ч за 12ч до и после",
    "contrast_selection": "Изоосмолярные (iodixanol) предпочтительнее",
    "medications": "Отменить метформин за 48 часов"
  },
  "source": {
    "book": "ACR Manual on Contrast Media",
    "organization": "American College of Radiology",
    "year": 2023
  }
}
```

### Клинические руководства с рекомендациями

```http
GET /kb/guidelines/esvs_aaa_2024
```

**Response:**
```json
{
  "id": "guideline-uuid",
  "code": "esvs_aaa_2024",
  "title": "ESVS Guidelines on Aortic Disease 2024",
  "organization": "ESVS",
  "year": 2024,
  "recommendations": [
    {
      "recommendation": "Ремонт AAA при диаметре ≥55 мм",
      "class": "I",
      "level": "A",
      "evidence": "Multiple RCTs"
    },
    {
      "recommendation": "EVAR предпочтительнее открытого ремонта",
      "class": "I",
      "level": "A"
    }
  ],
  "source": {
    "journal": "European Journal of Vascular and Endovascular Surgery",
    "doi": "10.1016/j.ejvs.2024.01.001"
  }
}
```

### Доступные источники

```http
GET /kb/sources
```

**Response:**
```json
{
  "books": [
    {
      "key": "chronic_venous_disorders",
      "title": "Chronic Venous Disorders of the Lower Limbs",
      "authors": ["Subramoniam Vaidyanathan", "Riju Ramachandran Menon", "Pradeep Jacob", "Binni John"],
      "publisher": "Springer India",
      "year": 2015,
      "isbn": "978-81-322-1991-0",
      "article_count": 5
    },
    {
      "key": "lymphedema_bergan",
      "title": "Lymphedema: A Concise Compendium of Theory and Practice",
      "authors": ["Byung-Boong Lee", "John Bergan", "Stanley G. Rockson"],
      "publisher": "Springer",
      "year": 2011,
      "isbn": "978-0-85729-566-8"
    },
    {
      "key": "acrs_contrast_manual",
      "title": "ACR Manual on Contrast Media",
      "organization": "American College of Radiology",
      "year": 2023
    }
  ],
  "guidelines": [
    {
      "organization": "ESVS",
      "title": "European Society for Vascular Surgery",
      "guidelines": ["Aortic Disease 2024", "CLTI 2023", "Carotid 2023"]
    },
    {
      "organization": "ACC/AHA",
      "title": "American College of Cardiology/American Heart Association",
      "guidelines": ["PAD 2016"]
    }
  ]
}
```

---

## ⚠️ Обработка ошибок

### Формат ошибки

```json
{
  "error": {
    "code": "VALIDATION_ERROR",
    "message": "Invalid input data",
    "details": [
      {
        "field": "email",
        "message": "Invalid email format"
      }
    ],
    "request_id": "req-uuid",
    "timestamp": "2024-01-15T10:30:00Z"
  }
}
```

### Коды ошибок

| Code | HTTP Status | Description |
|------|-------------|-------------|
| `UNAUTHORIZED` | 401 | Неверные credentials или истекший токен |
| `FORBIDDEN` | 403 | Недостаточно прав |
| `NOT_FOUND` | 404 | Ресурс не найден |
| `VALIDATION_ERROR` | 422 | Ошибка валидации данных |
| `RATE_LIMIT_EXCEEDED` | 429 | Превышен лимит запросов |
| `INTERNAL_ERROR` | 500 | Внутренняя ошибка сервера |
| `SERVICE_UNAVAILABLE` | 503 | Сервис временно недоступен |
| `AI_SERVICE_ERROR` | 502 | Ошибка AI сервиса |

---

## 📈 Rate Limiting

| Endpoint | Limit |
|----------|-------|
| `/auth/*` | 10 requests/minute |
| `/segmentation` | 30 requests/minute |
| `/agents/analyze` | 60 requests/minute |
| `/voice/*` | 100 requests/minute |
| Остальные | 1000 requests/minute |

**Headers:**
```http
X-RateLimit-Limit: 60
X-RateLimit-Remaining: 45
X-RateLimit-Reset: 1642249200
```

---

## 🔒 Безопасность

### Требования к паролю
- Минимум 12 символов
- Хотя бы одна заглавная буква
- Хотя бы одна строчная буква
- Хотя бы одна цифра
- Хотя бы один специальный символ

### Шифрование PHI
Все персональные данные пациентов (PHI) шифруются с использованием AES-256.

### Audit Logging
Все действия с PHI логируются согласно требованиям HIPAA.

---

## 📚 SDK и примеры

### Python SDK

```bash
pip install vascular-ai-sdk
```

```python
from vascular_ai import Client

client = Client(api_key="your-api-key")

# Загрузка исследования
study = client.studies.upload(
    patient_id="patient-uuid",
    files=["/path/to/dicom.zip"]
)

# Запуск сегментации
segmentation = client.segmentation.create(
    study_id=study.id,
    vessel_types=["aorta", "iliac_artery"]
)

# Ожидание завершения
result = client.segmentation.wait_for_completion(segmentation.id)

# AI анализ
analysis = client.agents.analyze(
    agent_type="vascular_surgery",
    query=f"AAA {result.measurements[0].diameter_max}mm"
)

print(analysis.recommendations)
```

### JavaScript/TypeScript SDK

```bash
npm install @vascular-ai/sdk
```

```typescript
import { VascularAIClient } from '@vascular-ai/sdk';

const client = new VascularAIClient({ apiKey: 'your-api-key' });

// Загрузка исследования
const study = await client.studies.upload({
  patientId: 'patient-uuid',
  files: fileList
});

// Запуск сегментации
const segmentation = await client.segmentation.create({
  studyId: study.id,
  vesselTypes: ['aorta', 'iliac_artery']
});

// Подписка на прогресс
client.segmentation.onProgress(segmentation.id, (progress) => {
  console.log(`Progress: ${progress.percentage}%`);
});
```

---

## 📞 Поддержка

- 📧 Email: api-support@vascular.ai
- 📖 Документация: https://docs.vascular.ai
- 💬 Статус API: https://status.vascular.ai
- 🐛 Issues: https://github.com/vascular-ai/issues

---

**Версия API:** 1.0.0  
**Последнее обновление:** 2024-01-15