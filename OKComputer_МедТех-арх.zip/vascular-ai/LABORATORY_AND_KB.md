# VASCULAR.AI - Лабораторные исследования и Медицинский справочник

## 📋 Лабораторные исследования

### Обзор

Модуль лабораторных исследований позволяет:
- Заказывать и отслеживать лабораторные тесты
- Хранить результаты с автоматической интерпретацией
- Отслеживать динамику показателей
- Выявлять критические значения
- Интегрироваться с AI агентами

### Структура данных

```
LaboratoryTest (Исследование)
├── order_number: Уникальный номер заказа
├── patient_id: Пациент
├── doctor_id: Врач-заказчик
├── status: Статус (ordered, collected, processing, completed, cancelled)
├── priority: Приоритет (routine, urgent, stat)
└── results: [TestResult]

TestResult (Результат теста)
├── test_code: Код теста
├── test_name: Название
├── value_numeric: Числовое значение
├── value_text: Текстовое значение
├── unit: Единицы измерения
├── reference_min/max: Референсные значения
├── interpretation: Интерпретация (normal, low, high, critical)
├── is_critical: Критическое значение
└── is_abnormal: Отклонение от нормы

ReferenceRange (Референсные значения)
├── test_code: Код теста
├── min_value/max_value: Нормальный диапазон
├── critical_low/critical_high: Критические значения
├── gender: Пол
└── age_min/age_max: Возрастной диапазон
```

### API Endpoints

#### Исследования

```http
# Создать исследование
POST /api/v1/laboratory/tests
{
  "patient_id": "uuid",
  "test_codes": ["CREATININE", "GLUCOSE", "HEMOGLOBIN"],
  "panel_code": "BASIC_METABOLIC",
  "priority": "routine",
  "clinical_indication": "Pre-operative evaluation"
}

# Получить список исследований
GET /api/v1/laboratory/tests?patient_id=uuid&status=completed

# Получить детали исследования
GET /api/v1/laboratory/tests/{test_id}

# Обновить исследование
PUT /api/v1/laboratory/tests/{test_id}
{
  "status": "collected",
  "collection_date": "2024-01-15T10:30:00Z"
}

# Отменить исследование
POST /api/v1/laboratory/tests/{test_id}/cancel?reason="Duplicate order"

# Верифицировать результаты
POST /api/v1/laboratory/tests/{test_id}/verify
```

#### Результаты

```http
# Добавить результат
POST /api/v1/laboratory/tests/{test_id}/results
{
  "test_code": "CREATININE",
  "test_name": "Creatinine",
  "value_numeric": 1.2,
  "unit": "mg/dL",
  "reference_min": 0.7,
  "reference_max": 1.3
}

# Получить результаты пациента
GET /api/v1/laboratory/results?patient_id=uuid&test_code=CREATININE

# Получить историю показателя
GET /api/v1/laboratory/patients/{patient_id}/history/{test_code}
```

#### Референсные значения

```http
# Создать референсные значения
POST /api/v1/laboratory/reference-ranges
{
  "test_code": "CREATININE",
  "test_name": "Creatinine",
  "category": "kidney_function",
  "unit": "mg/dL",
  "min_value": 0.7,
  "max_value": 1.3,
  "critical_high": 5.0,
  "gender": "male"
}

# Получить референсные значения
GET /api/v1/laboratory/reference-ranges/CREATININE?gender=male
```

#### Панели тестов

```http
# Создать панель
POST /api/v1/laboratory/panels
{
  "code": "BASIC_METABOLIC",
  "name": "Basic Metabolic Panel",
  "category": "biochemistry",
  "test_codes": ["SODIUM", "POTASSIUM", "CHLORIDE", "CO2", "GLUCOSE", "BUN", "CREATININE"]
}

# Получить список панелей
GET /api/v1/laboratory/panels

# Получить панель
GET /api/v1/laboratory/panels/BASIC_METABOLIC
```

#### Анализ и сравнение

```http
# Комплексный анализ
POST /api/v1/laboratory/analyze
{
  "patient_id": "uuid",
  "test_codes": ["CREATININE", "GLUCOSE", "HEMOGLOBIN"],
  "date_from": "2024-01-01T00:00:00Z",
  "date_to": "2024-01-31T23:59:59Z",
  "include_trends": true,
  "include_ai_analysis": true
}

# Сравнение результатов
POST /api/v1/laboratory/compare
{
  "patient_id": "uuid",
  "test_codes": ["CREATININE", "GLUCOSE"],
  "date_points": ["2024-01-01", "2024-01-15", "2024-01-30"]
}
```

#### Статистика

```http
# Получить статистику
GET /api/v1/laboratory/statistics?date_from=2024-01-01&date_to=2024-01-31
```

### Категории тестов

| Категория | Описание | Примеры |
|-----------|----------|---------|
| hematology | Гематология | Гемоглобин, Лейкоциты, Тромбоциты |
| biochemistry | Биохимия | Глюкоза, Креатинин, Мочевина |
| coagulation | Коагулограмма | ПТИ, МНО, АЧТВ, Фибриноген |
| immunology | Иммунология | Иммуноглобулины, Комплемент |
| cardiac_markers | Кардиомаркеры | Тропонин, КК-МВ, Миоглобин |
| lipid_profile | Липидный профиль | Холестерин, ЛПНП, ЛПВП, ТГ |
| kidney_function | Функция почек | Креатинин, СКФ, Мочевина |
| liver_function | Функция печени | АЛТ, АСТ, Билирубин, ЩФ |
| inflammation | Маркеры воспаления | СРБ, СОЭ, Прокальцитонин |

### Автоматическая интерпретация

Система автоматически определяет:
- **normal** - в пределах нормы
- **low** - ниже нормы
- **high** - выше нормы
- **critical_low** - критически низкое
- **critical_high** - критически высокое

При обнаружении критических значений:
1. Создается алерт
2. Отправляются уведомления
3. Логируется в audit log

### Delta Check

Система отслеживает значительные изменения (>20%) от предыдущего результата:
```json
{
  "previous_value": 1.0,
  "current_value": 1.5,
  "delta_percent": 50.0,
  "is_delta_check": true
}
```

---

## 📚 Медицинский справочник

### Обзор

Медицинский справочник содержит:
- Заболевания с диагностикой и лечением
- Лекарственные препараты
- Медицинские процедуры
- Клинические руководства
- Анатомические справочники

### Структура данных

```
KBArticle (Статья)
├── code: Уникальный код
├── title: Название
├── article_type: Тип (disease, medication, procedure, guideline)
├── summary: Краткое описание
├── content: Полный текст
├── icd10_codes: Коды ICD-10
├── evidence_level: Уровень доказательности
├── sources: Источники
└── categories: [KBCategory]

KBMedication (Препарат)
├── generic_name: МНН
├── brand_names: Торговые названия
├── drug_class: Класс препарата
├── indications: Показания
├── contraindications: Противопоказания
├── dosage_adult: Дозировка взрослым
├── side_effects: Побочные эффекты
└── drug_interactions: Взаимодействия

KBDisease (Заболевание)
├── symptoms: Симптомы
├── diagnostic_criteria: Диагностические критерии
├── treatment_options: Варианты лечения
├── prognosis: Прогноз
└── complications: Осложнения

KBProcedure (Процедура)
├── indications: Показания
├── technique_description: Описание техники
├── risks: Риски
├── complications: Осложнения
└── success_rate: Процент успеха
```

### API Endpoints

#### Поиск

```http
# Поиск в справочнике
GET /api/v1/kb/search?q=AAA&type=disease&page=1

# Популярные статьи
GET /api/v1/kb/articles/popular?type=disease&limit=10

# Новые статьи
GET /api/v1/kb/articles/recent?limit=10
```

#### Статьи

```http
# Получить статью
GET /api/v1/kb/articles/{article_id}

# Получить по коду
GET /api/v1/kb/articles/by-code/I71.4
```

#### Категории

```http
# Получить категории
GET /api/v1/kb/categories?parent_id=uuid

# Дерево категорий
GET /api/v1/kb/categories/tree

# Статьи категории
GET /api/v1/kb/categories/{category_id}/articles
```

#### Теги

```http
# Получить теги
GET /api/v1/kb/tags?search=vascular

# Статьи по тегу
GET /api/v1/kb/tags/vascular/articles
```

#### Лекарственные препараты

```http
# Поиск препаратов
GET /api/v1/kb/medications/search?q=warfarin

# Информация о препарате
GET /api/v1/kb/medications/{article_id}

# Проверка взаимодействий
POST /api/v1/kb/medications/check-interactions
{
  "drugs": ["warfarin", "aspirin", "atorvastatin"]
}
```

#### Заболевания

```http
# Поиск заболеваний
GET /api/v1/kb/diseases/search?q=aneurysm&body_system=cardiovascular

# Информация о заболевании
GET /api/v1/kb/diseases/{article_id}
```

#### Процедуры

```http
# Поиск процедур
GET /api/v1/kb/procedures/search?q=EVAR&specialty=vascular_surgery

# Информация о процедуре
GET /api/v1/kb/procedures/{article_id}
```

#### Клинические руководства

```http
# Получить руководства
GET /api/v1/kb/guidelines?organization=ESVS&year=2024

# Информация о руководстве
GET /api/v1/kb/guidelines/{article_id}
```

#### Избранное

```http
# Добавить в избранное
POST /api/v1/kb/favorites/{article_id}?notes="Important for AAA cases"

# Удалить из избранного
DELETE /api/v1/kb/favorites/{article_id}

# Получить избранное
GET /api/v1/kb/favorites
```

#### Быстрый справочник

```http
# Сосудистые экстренные состояния
GET /api/v1/kb/quick-reference/vascular_emergency

# Антикоагулянтная терапия
GET /api/v1/kb/quick-reference/anticoagulation

# Размеры ААА
GET /api/v1/kb/quick-reference/aaa_sizes
```

### Быстрый справочник

#### Сосудистые экстренные состояния

```json
{
  "title": "Сосудистые экстренные состояния",
  "items": [
    {
      "condition": "Расслоение аорты",
      "symptoms": ["Внезапная сильная боль в груди/спине", "Разница АД на руках"],
      "actions": ["Немедленная КТ-ангиография", "Контроль АД", "Хирургическая консультация"],
      "mortality": "1-2% в час без лечения"
    },
    {
      "condition": "ТГВ с эмболией легочной артерии",
      "symptoms": ["Одышка", "Боль в груди", "Тахикардия"],
      "actions": ["КТ-ангиография грудной клетки", "Антикоагулянты", "Оценка тромболиза"],
      "mortality": "30% без лечения"
    }
  ]
}
```

#### Антикоагулянтная терапия

```json
{
  "title": "Антикоагулянтная терапия",
  "items": [
    {
      "drug": "Варфарин",
      "target_inr": "2.0-3.0 (механический клапан МА 2.5-3.5)",
      "monitoring": "МНО каждые 1-4 недели",
      "reversal": "Витамин К 10мг IV, PCC 25-50 ЕД/кг"
    },
    {
      "drug": "Дабигатран",
      "dose": "150мг 2р/день (CrCl>30)",
      "monitoring": "Не требуется",
      "reversal": "Идаруцизумаб 5г IV"
    }
  ]
}
```

#### Размеры ААА и показания к лечению

```json
{
  "title": "Размеры ААА и показания к лечению",
  "items": [
    {"size": "<3.0 см", "action": "Норма", "surveillance": "Не требуется"},
    {"size": "3.0-3.9 см", "action": "Маленькая ААА", "surveillance": "УЗИ каждые 2-3 года"},
    {"size": "4.0-4.9 см", "action": "Средняя ААА", "surveillance": "УЗИ/КТ каждые 12 месяцев"},
    {"size": "5.0-5.4 см", "action": "Большая ААА", "surveillance": "КТ каждые 6 месяцев"},
    {"size": "≥5.5 см", "action": "Рекомендуется ремонт", "surveillance": "Немедленная оценка"}
  ]
}
```

### Интеграция с AI агентами

Лабораторные данные и справочник интегрированы с AI агентами:

```python
# Пример использования AI агента с лабораторными данными
from app.agents.specialized.vascular_surgery_agent import VascularSurgeryAgent

agent = VascularSurgeryAgent()

# Анализ с учетом лабораторных данных
analysis = await agent.analyze(
    query="AAA 5.2cm, creatinine 2.1",
    patient_context={
        "age": 68,
        "gender": "male",
        "lab_results": {
            "creatinine": {"value": 2.1, "unit": "mg/dL", "interpretation": "high"},
            "egfr": {"value": 35, "unit": "mL/min", "interpretation": "low"}
        }
    }
)
```

### Базовые панели тестов

#### Basic Metabolic Panel (BMP)
- Sodium (Na)
- Potassium (K)
- Chloride (Cl)
- CO2 (Bicarbonate)
- Glucose
- BUN
- Creatinine

#### Complete Blood Count (CBC)
- WBC
- RBC
- Hemoglobin
- Hematocrit
- MCV, MCH, MCHC
- Platelets

#### Lipid Panel
- Total Cholesterol
- HDL Cholesterol
- LDL Cholesterol
- Triglycerides

#### Coagulation Panel
- PT/INR
- aPTT
- Fibrinogen
- D-dimer

---

## 📊 Статистика и аналитика

### Лабораторная статистика

```json
{
  "period": {"from": "2024-01-01", "to": "2024-01-31"},
  "total_tests": 15420,
  "total_orders": 5230,
  "by_category": {
    "biochemistry": 5200,
    "hematology": 4100,
    "coagulation": 2100
  },
  "by_status": {
    "completed": 14800,
    "processing": 400,
    "ordered": 220
  },
  "critical_count": 145,
  "abnormal_count": 2340,
  "average_turnaround_time": 2.5
}
```

### Популярные поиски

```http
GET /api/v1/kb/analytics/popular-searches?days=30

Response:
{
  "items": [
    {"query": "AAA", "count": 450},
    {"query": "EVAR", "count": 320},
    {"query": "warfarin", "count": 280}
  ]
}
```

---

## 🔒 Безопасность

### Права доступа

| Роль | Лаборатория | Справочник |
|------|-------------|------------|
| admin | Полный доступ | Полный доступ |
| doctor | Чтение, создание заказов | Чтение, избранное |
| lab_technician | Чтение, добавление результатов | Чтение |
| nurse | Чтение | Чтение |

### Audit Logging

Все действия логируются:
- Создание заказа
- Добавление результата
- Верификация
- Доступ к критическим значениям
- Поиск в справочнике