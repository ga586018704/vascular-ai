# VASCULAR.AI - Руководство по запуску

## Быстрый старт

### 1. Распакуйте архив

```bash
# Windows
tar -xzf vascular-ai-complete.tar.gz
# или используйте 7-Zip / WinRAR

# Linux/Mac
tar -xzf vascular-ai-complete.tar.gz
```

### 2. Установите зависимости Backend

```bash
cd vascular-ai/backend
pip install -r requirements.txt
```

### 3. Настройте окружение

```bash
# Windows
copy .env.example .env

# Linux/Mac
cp .env.example .env
```

**Важно:** Откройте файл `.env` и измените:
- `SECRET_KEY` - минимум 32 символа
- `ENCRYPTION_KEY` - ровно 32 символа

### 4. Запустите Backend

```bash
uvicorn app.main:app --reload --host 0.0.0.0 --port 8000
```

### 5. Проверьте работу

Откройте в браузере:
- **API Docs**: http://localhost:8000/docs
- **Health Check**: http://localhost:8000/health

---

## Структура проекта

```
vascular-ai/
├── backend/              # FastAPI Backend
│   ├── app/
│   │   ├── api/          # API endpoints
│   │   ├── core/         # Config, security, logging
│   │   ├── models/       # Database models
│   │   ├── services/     # Business logic
│   │   └── agents/       # AI Agents system
│   ├── requirements.txt  # Python dependencies
│   └── .env              # Environment variables
│
├── frontend/             # React Frontend (опционально)
│   └── ...
│
├── ai-service/           # GPU Segmentation Service (опционально)
│   └── ...
│
└── docs/                 # Documentation
```

---

## Основные API Endpoints

### Аутентификация
```bash
# Регистрация
POST /api/auth/register
{
  "email": "doctor@clinic.com",
  "password": "securepass123",
  "full_name": "Dr. Smith",
  "role": "surgeon"
}

# Вход
POST /api/auth/login
# Form data: username=doctor@clinic.com&password=securepass123
```

### AI Агенты
```bash
# Список агентов
GET /api/agents/available

# Анализ запроса
POST /api/agents/analyze
{
  "query": "Пациент 68 лет, ААА 55 мм",
  "agent_type": "vascular"
}
```

### DICOM
```bash
# Загрузка файла
POST /api/dicom/upload
# Form data: file=@study.dcm

# Список исследований
GET /api/dicom/studies
```

---

## Устранение неполадок

### Ошибка: "No module named 'app'"
```bash
# Запускайте из папки backend
cd vascular-ai/backend
uvicorn app.main:app --reload
```

### Ошибка: "SECRET_KEY must be at least 32 characters"
```bash
# Откройте .env и измените SECRET_KEY
SECRET_KEY=your-super-secret-key-must-be-at-least-32-characters-long
```

### Ошибка: "Field required: ENCRYPTION_KEY"
```bash
# Добавьте в .env
ENCRYPTION_KEY=your-encryption-key-32-bytes-long!!!
```

---

## Генерация ключей

### Windows (PowerShell)
```powershell
# SECRET_KEY (32+ chars)
-join ((48..57) + (65..90) + (97..122) | Get-Random -Count 40 | ForEach-Object {[char]$_})

# ENCRYPTION_KEY (32 chars)
-join ((48..57) + (65..90) + (97..122) | Get-Random -Count 32 | ForEach-Object {[char]$_})
```

### Linux/Mac
```bash
# SECRET_KEY
openssl rand -hex 32

# ENCRYPTION_KEY
openssl rand -base64 32
```

---

## Дополнительная информация

- **Полная документация**: `VASCULAR_AI_COMPLETE_SUMMARY.md`
- **Backend README**: `backend/README.md`
- **API Documentation**: http://localhost:8000/docs (после запуска)

---

**Готово к работе!** 🚀
