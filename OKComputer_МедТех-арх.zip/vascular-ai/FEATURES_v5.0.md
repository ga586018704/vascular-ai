# VASCULAR.AI v5.0 - Специализированные руководства

## Обзор

Версия 5.0 добавляет **6 новых специализированных модулей** на основе анализа 36+ авторитетных источников:
- Книги по сосудистой хирургии (Хаймович, Заринш, Маккей)
- Международные атласы (Netter, Sabiston, Rutherford)
- Руководства (ACR, ESVS, ACC/AHA)
- Специализированная литература (Lymphedema, Contrast Media, Neurointerventional)

## Новые модули v5.0

### 1. Лимфедема (`lymphedema_guide.py`)

#### Классификация
- **Первичная**: Congenital (Milroy), Praecox (Meige), Tarda
- **Вторичная**: Хирургическая, лучевая, инфекционная (филяриатоз), травматическая
- **Генетика**: VEGFR3, FOXC2, SOX18 мутации

#### Стадирование ISL
```
Stage 0: Субклиническая (латентная)
Stage 1: Ранняя (спонтанно обратимая) - pitting present
Stage 2: Средняя (спонтанно необратимая) - фиброз
Stage 3: Поздняя (липодерматосклероз/элефантиаз)
```

#### Лечение
- **CDT (Complete Decongestive Therapy)**: MLD, компрессия, упражнения, уход за кожей
- **Хирургическое**: VLNT, LVA, липосакция, редукционная хирургия
- **Осложнения**: Целлюлит (20-30%/год), лимфангиосаркома (Stewart-Treves)

**API Endpoints:**
- `POST /api/specialized/lymphedema/classify` - Классификация
- `GET /api/specialized/lymphedema/staging/{stage}` - Стадирование ISL
- `GET /api/specialized/lymphedema/cdt-protocol/{stage}` - Протокол CDT
- `GET /api/specialized/lymphedema/cellulitis/{severity}` - Лечение целлюлита
- `GET /api/specialized/lymphedema/guide` - Полное руководство

---

### 2. Контрастные вещества (`contrast_media_guide.py`)

#### Типы контраста
- **Йодированные**: Ionic high-osmolar, ionic low-osmolar, nonionic low-osmolar, nonionic iso-osmolar
- **Гадолиний**: Linear (низкая стабильность), macrocyclic (высокая стабильность)

#### CIN (Contrast-Induced Nephropathy)
- **Определение**: ↑Креатинин >25% или >0.5 мг/дл в течение 48-72 часов
- **Частота**: 2-7% (общая), 20-30% (высокий риск)
- **Профилактика**: IV гидратация, N-ацетилцистеин, статины

#### Аллергические реакции
- **Mild**: Кожная сыпь, зуд (0.7-3%)
- **Moderate**: Бронхоспазм, отек гортани (0.01-0.1%)
- **Severe**: Анафилаксис, судороги (0.001-0.01%)
- **Премедикация**: Преднизолон + димедрол

#### NSF (Nephrogenic Systemic Fibrosis)
- **Риск**: GFR <30 (высокий), GFR 30-59 (умеренный)
- **Профилактика**: Макроциклический гадолиний, минимальная доза

**API Endpoints:**
- `POST /api/specialized/contrast/cin-risk` - Оценка риска CIN
- `GET /api/specialized/contrast/types` - Типы контраста
- `GET /api/specialized/contrast/nephropathy-guide` - Руководство по CIN
- `GET /api/specialized/contrast/allergic-reactions` - Аллергические реакции
- `GET /api/specialized/contrast/nsf-guide` - Руководство по NSF

---

### 3. Осложнения эндоваскулярных вмешательств (`endovascular_complications.py`)

#### Осложнения доступа
- Гематома (2-6%)
- Псевдоаневризма (0.05-6%) - тромбиновая инъекция 90-95% успех
- АВ-фистула (0.2-1%)
- Диссекция (0.5-2%)
- Ретроперитонеальное кровотечение (0.2-0.5%)

#### Осложнения ангиопластики
- Диссекция (типы A-F)
- Перфорация (0.5-2%)
- Дистальная эмболизация (2-5%)
- Острая окклюзия (2-5%)
- Спазм (5-10%)

#### Осложнения стентирования
- Перелом стента (5-20%)
- Рестеноз внутри стента (20-40% на 1 год)
- Миграция стента (1-3%)
- Тромбоз стента (1-5%)

#### Осложнения EVAR/TEVAR
- Endoleak (типы 1-5)
- Миграция стент-графта (1-5%)
- Ишемия спинного мозга (2-10% при TEVAR)
- Ишемия толстой кишки (1-3% при EVAR)

**API Endpoints:**
- `GET /api/specialized/endovascular/complications/{type}` - Управление осложнением
- `POST /api/specialized/endovascular/procedure-risk` - Оценка риска процедуры
- `GET /api/specialized/endovascular/complications-list` - Список осложнений

---

### 4. Сосудистое УЗИ (`vascular_ultrasound_guide.py`)

#### УЗИ сонных артерий
- **Критерии стеноза**: PSV, EDV, ICA/CCA ratio
- **Норма**: PSV <125, ratio <2.0
- **50-69%**: PSV 125-230, ratio 2.0-4.0
- **70-99%**: PSV >230, ratio >4.0
- **Характеристика бляшек**: Эхогенность, поверхность

#### УЗИ периферических артерий
- **Монофазный waveform**: Тяжелый стеноз проксимально
- **Tardus-parvus**: Замедленный и низкий пик
- **Surveillance шунтов**: PSV <45 (тромбоз), >300 (стеноз)

#### УЗИ вен
- **ТГВ**: Неполное сжатие, визуализация тромба
- **Варикоз**: Диаметр GSV >4 мм, рефлюкс >0.5 сек
- **Wells score**: Низкая/умеренная/высокая вероятность

**API Endpoints:**
- `POST /api/specialized/ultrasound/carotid-interpretation` - Интерпретация сонных артерий
- `POST /api/specialized/ultrasound/bypass-graft` - Интерпретация шунта
- `GET /api/specialized/ultrasound/dvt-probability/{wells_score}` - Вероятность ТГВ
- `GET /api/specialized/ultrasound/guide/{topic}` - Руководство (carotid, peripheral, venous)

---

### 5. Нейроинтервенционная хирургия (`neurointerventional_guide.py`)

#### Ишемический инсульт
- **IV tPA**: 4.5 часов, 0.9 мг/кг
- **Механическая тромбэктомия**: До 24 часов (при LVO, NIHSS ≥6)
- **Техники**: Stent retriever, aspiration, combined
- **Каротидное стентирование**: Показания, защита (filter, flow reversal)

#### Внутричерепные аневризмы
- **ISUIA риск разрыва**: Зависит от размера и локализации
- **Лечение**: Коагуляция, flow diverter, parent artery occlusion
- **SAH**: Градация Hunt-Hess, WFNS
- **Вазоспазм**: Нимодипин, triple-H therapy

#### AVM
- **Spetzler-Martin**: Размер, eloquence, deep drainage
- **Score 1-2**: Хирургия
- **Score 3**: Индивидуальный подход
- **Score 4-5**: Эндоваскулярная/лучевая терапия

**API Endpoints:**
- `POST /api/specialized/neuro/stroke-treatment` - Опции лечения инсульта
- `POST /api/specialized/neuro/avm-grading` - Spetzler-Martin градация
- `POST /api/specialized/neuro/aneurysm-recommendation` - Рекомендация по аневризме
- `GET /api/specialized/neuro/guide/{topic}` - Руководство (stroke, aneurysm, avm)

---

### 6. Гибридная хирургия аорты (`hybrid_aortic_surgery.py`)

#### Расслоение аорты
- **Stanford Type A**: Срочная операция (1-2% смертность в час)
- **Stanford Type B**: 
  - Неосложненное → медикаментозная терапия
  - Осложненное → TEVAR
- **Frozen elephant trunk**: Расслоение с вовлечением дуги

#### Гибридные процедуры
- **Arch debranching**: Каротидо-каротидное, каротидо-субклавианское
- **Thoracoabdominal hybrid**: Visceral debranching + TEVAR
- **TEVAR планирование**: Зоны landing, debranching

#### Медикаментозная терапия
- **Бета-блокаторы**: Эсмолол, лабеталол
- **Целевое АД**: Систолическое 100-120 мм рт.ст.
- **Целевая ЧСС**: 60-80 уд/мин

**API Endpoints:**
- `POST /api/specialized/hybrid-aortic/dissection-management` - Управление расслоением
- `POST /api/specialized/hybrid-aortic/procedure-indication` - Показания к гибридной процедуре
- `POST /api/specialized/hybrid-aortic/tevar-planning` - Планирование TEVAR
- `GET /api/specialized/hybrid-aortic/guide/{topic}` - Руководство (dissection, procedures)

---

## Итоговая статистика VASCULAR.AI v5.0

| Категория | Количество |
|-----------|------------|
| Сервисных модулей | 19 |
| API роутеров | 10 |
| API эндпоинтов | 150+ |
| Строк кода | 20,000+ |
| Покрытие тем | Полное |

## Полный список модулей

### v1.0 (Базовая платформа)
- DICOM processing
- AI segmentation
- Protocol generation

### v2.0-2.1 (Клинические рекомендации)
- TASC II Classification
- Graft selection
- Russian clinical guidelines
- Phlebology guide
- Risk calculators (VSGNE, GAS)
- Anticoagulation management
- Complication algorithms

### v3.0 (Расширенные модули)
- Vascular access planning
- 3D measurements for EVAR/TEVAR
- Vascular lab interpretation
- Trauma protocols
- Pediatric vascular surgery
- WHO surgical safety checklists

### v4.0 (Клинический атлас)
- Clinical algorithms (First Aid style)
- Surgical anatomy (Netter)
- Operative techniques (Sabiston)
- Pharmacotherapy (ACC/AHA 2024)

### v5.0 (Специализированные руководства)
- Lymphedema management
- Contrast media guide
- Endovascular complications
- Vascular ultrasound
- Neurointerventional surgery
- Hybrid aortic surgery

---

## Пример использования

```python
import requests

# Оценка риска CIN
data = {
    "egfr": 45,
    "diabetes": True,
    "age": 72,
    "volume": 120,
    "intraarterial": True
}
response = requests.post("http://localhost:8000/api/specialized/contrast/cin-risk", json=data)

# Классификация лимфедемы
data = {
    "onset_age": 25,
    "family_history": True,
    "triggers": []
}
response = requests.post("http://localhost:8000/api/specialized/lymphedema/classify", json=data)

# Опции лечения инсульта
data = {
    "onset_time_hours": 3.5,
    "nihss": 15,
    "large_vessel_occlusion": True
}
response = requests.post("http://localhost:8000/api/specialized/neuro/stroke-treatment", json=data)

# Управление расслоением аорты
data = {
    "stanford_type": "A",
    "complicated": False
}
response = requests.post("http://localhost:8000/api/specialized/hybrid-aortic/dissection-management", json=data)
```

---

## Источники (анализировано 36+ книг)

### Российские
- Сосудистая хирургия по Хаймовичу (том 1-2)
- Хирургия сонных артерий (Маккей, Росс)
- Атлас сосудистой хирургии (Заринш, Гевертс)
- Гибридная хирургия расслоения аорты (Козлов, Панфилов)
- Лимфедема (Бордаков, Деркачев, Левченко)
- Лечебная эндоваскулярная окклюзия (Коков)

### Международные
- Netter's Atlas of Human Anatomy
- Sabiston Textbook of Surgery
- Rutherford's Vascular Surgery
- ACR Manual on Contrast Media
- Lymphedema (Lee, Bergan, Rockson)
- Handbook of Cerebrovascular Disease (Harrigan, Deveikis)
- Practical Vascular Ultrasound (Myers, Clough)
- Complications in Vascular Interventional Therapy (Mueller-Huelsbeck)
- Acute Aortic Disease (Elefteriades)
- И многие другие...

---

*Версия 5.0 - Май 2025*
*VASCULAR.AI - самая полная платформа для сосудистых хирургов*
