"""VASCULAR.AI - AI Agents API"""
from typing import Dict

from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel

from app.agents.base_agent import AgentAnalysis
from app.agents.vascular_agent import VascularSurgeryAgent
from app.agents.phlebology_agent import PhlebologyAgent
from app.agents.neuro_agent import NeurointerventionAgent
from app.api.auth import get_current_user
from app.models.user import User

router = APIRouter(prefix="/api/agents", tags=["AI Agents"])

# Agent instances
agents = {
    "vascular": VascularSurgeryAgent(),
    "phlebology": PhlebologyAgent(),
    "neuro": NeurointerventionAgent(),
}


class AnalyzeRequest(BaseModel):
    query: str
    agent_type: str
    patient_context: Dict | None = None


class AnalyzeResponse(BaseModel):
    query: str
    agent_type: str
    agent_name: str
    analysis: str
    recommendations: list
    contraindications: list
    sources: list
    confidence_score: float
    evidence_level: str
    timestamp: str


@router.get("/available")
async def list_agents():
    """List available AI agents"""
    return {
        "agents": [
            {
                "id": "vascular",
                "name": "Vascular Surgery Agent",
                "description": "AAA, PAD, carotid disease",
                "capabilities": ["AAA analysis", "Carotid stenosis", "PAD assessment"]
            },
            {
                "id": "phlebology",
                "name": "Phlebology Agent",
                "description": "DVT, varicose veins",
                "capabilities": ["DVT management", "Varicose veins", "CEAP classification"]
            },
            {
                "id": "neuro",
                "name": "Neurointervention Agent",
                "description": "Stroke, aneurysms",
                "capabilities": ["Stroke assessment", "Aneurysm evaluation"]
            },
        ]
    }


@router.post("/analyze", response_model=AnalyzeResponse)
async def analyze(
    request: AnalyzeRequest,
    current_user: User = Depends(get_current_user)
):
    """Run AI agent analysis"""
    if request.agent_type not in agents:
        raise HTTPException(status_code=400, detail=f"Unknown agent type: {request.agent_type}")
    
    agent = agents[request.agent_type]
    result: AgentAnalysis = await agent.analyze(request.query, request.patient_context)
    
    return AnalyzeResponse(
        query=result.query,
        agent_type=result.agent_type,
        agent_name=agent.name,
        analysis=result.analysis,
        recommendations=result.recommendations,
        contraindications=result.contraindications,
        sources=result.sources,
        confidence_score=result.confidence_score,
        evidence_level=result.evidence_level,
        timestamp=result.timestamp,
    )
