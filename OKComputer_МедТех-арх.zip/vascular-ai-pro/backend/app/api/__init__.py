"""VASCULAR.AI - API"""
from app.api import auth

__all__ = ["auth"]
