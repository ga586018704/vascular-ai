"""VASCULAR.AI - DICOM API"""
import shutil
import uuid
from pathlib import Path
from typing import List

from fastapi import APIRouter, Depends, File, HTTPException, UploadFile
from pydantic import BaseModel
from sqlalchemy import desc, select
from sqlalchemy.ext.asyncio import AsyncSession

from app.api.auth import get_current_user
from app.core.database import get_db
from app.core.config import settings
from app.models.study import Study, StudyType, StudyStatus
from app.models.user import User

router = APIRouter(prefix="/api/dicom", tags=["DICOM"])


class StudyResponse(BaseModel):
    id: int
    study_uid: str
    study_type: str
    modality: str
    study_description: str | None
    status: str
    num_images: int
    created_at: str | None
    
    class Config:
        from_attributes = True


class StudyListResponse(BaseModel):
    total: int
    studies: List[StudyResponse]


@router.post("/upload", response_model=StudyResponse, status_code=201)
async def upload_dicom(
    files: List[UploadFile] = File(...),
    patient_id: str = File(...),
    study_type: StudyType = File(StudyType.DICOM_LEGACY),
    study_description: str | None = File(None),
    current_user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db)
):
    """Upload DICOM files"""
    if not files:
        raise HTTPException(status_code=400, detail="No files uploaded")
    
    # Validate files
    total_size = 0
    for file in files:
        content = await file.read()
        total_size += len(content)
        await file.seek(0)
        
        if len(content) > 100 * 1024 * 1024:  # 100MB per file
            raise HTTPException(status_code=400, detail=f"File {file.filename} too large")
    
    # Generate study UID and save
    study_uid = str(uuid.uuid4())
    study_dir = settings.DICOM_STORAGE_DIR / study_uid
    study_dir.mkdir(parents=True, exist_ok=True)
    
    for file in files:
        file_path = study_dir / file.filename
        with open(file_path, "wb") as f:
            content = await file.read()
            f.write(content)
    
    # Create study record
    study = Study(
        user_id=current_user.id,
        patient_id=patient_id,
        study_uid=study_uid,
        study_type=study_type,
        modality="CT",
        study_description=study_description,
        file_path=str(study_dir),
        file_size=total_size,
        num_images=len(files),
        status=StudyStatus.UPLOADED,
    )
    
    db.add(study)
    await db.commit()
    await db.refresh(study)
    
    return study


@router.get("/studies", response_model=StudyListResponse)
async def list_studies(
    skip: int = 0,
    limit: int = 20,
    current_user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db)
):
    """List user's studies"""
    query = select(Study).where(Study.user_id == current_user.id)
    
    count_result = await db.execute(select(Study.id).where(Study.user_id == current_user.id))
    total = len(count_result.scalars().all())
    
    query = query.order_by(desc(Study.created_at)).offset(skip).limit(limit)
    result = await db.execute(query)
    studies = result.scalars().all()
    
    return StudyListResponse(total=total, studies=list(studies))


@router.get("/studies/{study_id}", response_model=StudyResponse)
async def get_study(
    study_id: int,
    current_user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db)
):
    """Get study details"""
    result = await db.execute(
        select(Study).where(Study.id == study_id, Study.user_id == current_user.id)
    )
    study = result.scalar_one_or_none()
    
    if not study:
        raise HTTPException(status_code=404, detail="Study not found")
    
    return study


@router.delete("/studies/{study_id}")
async def delete_study(
    study_id: int,
    current_user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db)
):
    """Delete a study"""
    result = await db.execute(
        select(Study).where(Study.id == study_id, Study.user_id == current_user.id)
    )
    study = result.scalar_one_or_none()
    
    if not study:
        raise HTTPException(status_code=404, detail="Study not found")
    
    # Delete files
    study_dir = Path(study.file_path)
    if study_dir.exists():
        shutil.rmtree(study_dir, ignore_errors=True)
    
    await db.delete(study)
    await db.commit()
    
    return {"message": "Study deleted"}
