"""VASCULAR.AI - Risk Calculators API"""
from fastapi import APIRouter
from pydantic import BaseModel

router = APIRouter(prefix="/api/calculators", tags=["Risk Calculators"])


# ============== VSGNE Score ==============

class VSGNERequest(BaseModel):
    age: int
    creatinine: float  # mg/dL
    asa_class: int  # 1-5
    emergency: bool
    reoperation: bool


class VSGNEResponse(BaseModel):
    score: int
    risk_class: str
    mortality_risk: str
    recommendations: list


@router.post("/vsgne", response_model=VSGNEResponse)
async def calculate_vsgne(request: VSGNERequest):
    """Calculate VSGNE (Vascular Study Group of New England) risk score"""
    score = 0
    
    # Age
    if request.age >= 80:
        score += 4
    elif request.age >= 70:
        score += 3
    elif request.age >= 60:
        score += 2
    elif request.age >= 50:
        score += 1
    
    # Creatinine
    if request.creatinine >= 2.0:
        score += 4
    elif request.creatinine >= 1.5:
        score += 2
    
    # ASA
    if request.asa_class >= 4:
        score += 3
    elif request.asa_class >= 3:
        score += 1
    
    # Emergency
    if request.emergency:
        score += 3
    
    # Reoperation
    if request.reoperation:
        score += 2
    
    # Risk class
    if score >= 9:
        risk_class = "High"
        mortality_risk = ">10%"
    elif score >= 5:
        risk_class = "Moderate"
        mortality_risk = "3-10%"
    else:
        risk_class = "Low"
        mortality_risk = "<3%"
    
    return VSGNEResponse(
        score=score,
        risk_class=risk_class,
        mortality_risk=mortality_risk,
        recommendations=[
            "Preoperative optimization",
            "Consider ICU admission" if score >= 5 else "Standard care",
            "Informed consent discussion",
        ]
    )


# ============== GAS Score ==============

class GASRequest(BaseModel):
    age: int
    cardiac_history: bool
    hypertension: bool
    stroke_history: bool
    renal_dysfunction: bool
    copd: bool
    smoking: bool


class GASResponse(BaseModel):
    score: int
    risk_class: str
    recommendations: list


@router.post("/gas", response_model=GASResponse)
async def calculate_gas(request: GASRequest):
    """Calculate GAS (Global Anatomic Staging) risk score"""
    score = 0
    
    # Age
    if request.age >= 75:
        score += 2
    elif request.age >= 65:
        score += 1
    
    # Comorbidities
    if request.cardiac_history:
        score += 2
    if request.hypertension:
        score += 1
    if request.stroke_history:
        score += 2
    if request.renal_dysfunction:
        score += 2
    if request.copd:
        score += 2
    if request.smoking:
        score += 1
    
    # Risk class
    if score >= 6:
        risk_class = "High"
    elif score >= 3:
        risk_class = "Moderate"
    else:
        risk_class = "Low"
    
    return GASResponse(
        score=score,
        risk_class=risk_class,
        recommendations=[
            "Cardiac evaluation" if request.cardiac_history else "Routine monitoring",
            "Smoking cessation" if request.smoking else "Continue healthy lifestyle",
            "Preoperative optimization" if score >= 3 else "Standard preparation",
        ]
    )


# ============== Wells Score (DVT) ==============

class WellsDVTRequest(BaseModel):
    active_cancer: bool
    paralysis_paresis: bool
    recent_bedrest: bool  # >3 days
    localized_tenderness: bool
    swollen_leg: bool
    calf_swelling: bool  # >3cm vs asymptomatic
    pitting_edema: bool
    collateral_veins: bool
    alternative_diagnosis: bool  # as likely or more


class WellsDVTResponse(BaseModel):
    score: int
    probability: str
    recommendation: str


@router.post("/wells-dvt", response_model=WellsDVTResponse)
async def calculate_wells_dvt(request: WellsDVTRequest):
    """Calculate Wells score for DVT probability"""
    score = 0
    
    if request.active_cancer:
        score += 1
    if request.paralysis_paresis:
        score += 1
    if request.recent_bedrest:
        score += 1
    if request.localized_tenderness:
        score += 1
    if request.swollen_leg:
        score += 1
    if request.calf_swelling:
        score += 1
    if request.pitting_edema:
        score += 1
    if request.collateral_veins:
        score += 1
    if request.alternative_diagnosis:
        score -= 2
    
    if score <= 0:
        probability = "Low"
        recommendation = "D-dimer test; if negative, DVT unlikely"
    elif score <= 2:
        probability = "Moderate"
        recommendation = "Ultrasound imaging recommended"
    else:
        probability = "High"
        recommendation = "Ultrasound imaging; consider anticoagulation"
    
    return WellsDVTResponse(
        score=score,
        probability=probability,
        recommendation=recommendation,
    )


# ============== AAA Diameter Risk ==============

class AAARiskRequest(BaseModel):
    diameter_mm: float
    sex: str  # male/female
    growth_rate_mm_per_year: float | None = None
    symptomatic: bool = False


class AAARiskResponse(BaseModel):
    diameter: float
    risk_category: str
    repair_recommended: bool
    surveillance_interval_months: int | None
    recommendations: list


@router.post("/aaa-risk", response_model=AAARiskResponse)
async def calculate_aaa_risk(request: AAARiskRequest):
    """Calculate AAA rupture risk and treatment recommendations"""
    
    threshold = 55 if request.sex.lower() == "male" else 50
    
    if request.diameter_mm >= threshold or request.symptomatic:
        repair_recommended = True
        surveillance_interval = None
        risk_category = "High"
    elif request.diameter_mm >= 45:
        repair_recommended = False
        surveillance_interval = 6
        risk_category = "Moderate-High"
    elif request.diameter_mm >= 40:
        repair_recommended = False
        surveillance_interval = 12
        risk_category = "Moderate"
    else:
        repair_recommended = False
        surveillance_interval = 24
        risk_category = "Low"
    
    # Check growth rate
    if request.growth_rate_mm_per_year and request.growth_rate_mm_per_year > 10:
        repair_recommended = True
        risk_category = "High (rapid growth)"
    
    recommendations = [
        f"{'Repair indicated' if repair_recommended else 'Surveillance'}",
        f"Blood pressure control <130/80" if not repair_recommended else "Preoperative optimization",
        "Smoking cessation",
        "Statin therapy",
    ]
    
    if surveillance_interval:
        recommendations.append(f"Next ultrasound in {surveillance_interval} months")
    
    return AAARiskResponse(
        diameter=request.diameter_mm,
        risk_category=risk_category,
        repair_recommended=repair_recommended,
        surveillance_interval=surveillance_interval,
        recommendations=recommendations,
    )
