"""VASCULAR.AI - LLM Service
Integration with OpenAI GPT-4 and Anthropic Claude
"""
import os
from typing import AsyncGenerator, Dict, List, Optional

import httpx

from app.core.config import settings


class LLMService:
    """Service for LLM interactions"""
    
    def __init__(self):
        self.openai_key = settings.OPENAI_API_KEY or os.getenv("OPENAI_API_KEY")
        self.anthropic_key = settings.ANTHROPIC_API_KEY or os.getenv("ANTHROPIC_API_KEY")
    
    async def analyze_with_gpt4(
        self,
        query: str,
        system_prompt: str,
        context: Optional[Dict] = None,
        stream: bool = False
    ) -> str:
        """Analyze using OpenAI GPT-4"""
        if not self.openai_key:
            raise ValueError("OpenAI API key not configured")
        
        messages = [
            {"role": "system", "content": system_prompt}
        ]
        
        if context:
            context_str = self._format_context(context)
            messages.append({"role": "user", "content": f"Patient context: {context_str}")
        
        messages.append({"role": "user", "content": query})
        
        async with httpx.AsyncClient() as client:
            response = await client.post(
                "https://api.openai.com/v1/chat/completions",
                headers={
                    "Authorization": f"Bearer {self.openai_key}",
                    "Content-Type": "application/json"
                },
                json={
                    "model": "gpt-4-turbo-preview",
                    "messages": messages,
                    "temperature": 0.3,
                    "max_tokens": 2000,
                    "stream": stream
                },
                timeout=60.0
            )
            response.raise_for_status()
            data = response.json()
            return data["choices"][0]["message"]["content"]
    
    async def analyze_with_claude(
        self,
        query: str,
        system_prompt: str,
        context: Optional[Dict] = None
    ) -> str:
        """Analyze using Anthropic Claude"""
        if not self.anthropic_key:
            raise ValueError("Anthropic API key not configured")
        
        messages = []
        
        if context:
            context_str = self._format_context(context)
            messages.append({
                "role": "user",
                "content": f"Patient context: {context_str}\n\nQuestion: {query}"
            })
        else:
            messages.append({"role": "user", "content": query})
        
        async with httpx.AsyncClient() as client:
            response = await client.post(
                "https://api.anthropic.com/v1/messages",
                headers={
                    "x-api-key": self.anthropic_key,
                    "Content-Type": "application/json",
                    "anthropic-version": "2023-06-01"
                },
                json={
                    "model": "claude-3-opus-20240229",
                    "max_tokens": 2000,
                    "system": system_prompt,
                    "messages": messages,
                    "temperature": 0.3
                },
                timeout=60.0
            )
            response.raise_for_status()
            data = response.json()
            return data["content"][0]["text"]
    
    def _format_context(self, context: Dict) -> str:
        """Format patient context for LLM"""
        parts = []
        for key, value in context.items():
            parts.append(f"{key}: {value}")
        return "; ".join(parts)
    
    async def analyze_medical_case(
        self,
        specialty: str,
        query: str,
        patient_context: Optional[Dict] = None,
        provider: str = "openai"
    ) -> Dict:
        """Complete medical case analysis"""
        
        system_prompts = {
            "vascular": """You are an expert vascular surgeon AI assistant. 
Provide evidence-based recommendations following ESVS, SVS, and ACC/AHA guidelines.
Include: diagnosis, treatment options, surgical indications, and follow-up recommendations.
Always include a disclaimer that this is for educational purposes only.""",
            
            "phlebology": """You are an expert phlebologist AI assistant.
Provide evidence-based recommendations for venous diseases following ESVS guidelines.
Include: CEAP classification, treatment options, and compression therapy recommendations.""",
            
            "neuro": """You are an expert neurointerventionist AI assistant.
Provide evidence-based recommendations for neurovascular cases following AHA/ASA guidelines.
Include: stroke protocols, aneurysm management, and endovascular treatment options.""",
            
            "endovascular": """You are an expert endovascular surgeon AI assistant.
Provide evidence-based recommendations for EVAR, TEVAR, and other endovascular procedures.
Include: anatomical considerations, device selection, and complications management."""
        }
        
        system_prompt = system_prompts.get(specialty, system_prompts["vascular"])
        
        try:
            if provider == "anthropic" and self.anthropic_key:
                response = await self.analyze_with_claude(query, system_prompt, patient_context)
            else:
                response = await self.analyze_with_gpt4(query, system_prompt, patient_context)
            
            return {
                "success": True,
                "analysis": response,
                "provider": provider,
                "specialty": specialty
            }
        except Exception as e:
            return {
                "success": False,
                "error": str(e),
                "provider": provider
            }


# Singleton
llm_service = LLMService()
