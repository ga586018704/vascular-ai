"""VASCULAR.AI - PDF Report Generation"""
from datetime import datetime
from io import BytesIO
from typing import Dict, List

from reportlab.lib import colors
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib.units import inch
from reportlab.platypus import (
    SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle,
    ListFlowable, ListItem, Image
)


class PDFReportService:
    """Service for generating PDF medical reports"""
    
    def __init__(self):
        self.styles = getSampleStyleSheet()
        self._setup_custom_styles()
    
    def _setup_custom_styles(self):
        """Setup custom paragraph styles"""
        self.styles.add(ParagraphStyle(
            name='CustomTitle',
            parent=self.styles['Heading1'],
            fontSize=24,
            spaceAfter=30,
            textColor=colors.HexColor('#2563eb')
        ))
        
        self.styles.add(ParagraphStyle(
            name='SectionHeader',
            parent=self.styles['Heading2'],
            fontSize=14,
            spaceAfter=12,
            textColor=colors.HexColor('#1e293b')
        ))
        
        self.styles.add(ParagraphStyle(
            name='NormalText',
            parent=self.styles['Normal'],
            fontSize=11,
            spaceAfter=8
        ))
    
    def generate_analysis_report(
        self,
        patient_name: str,
        patient_id: str,
        study_date: str,
        analysis_type: str,
        findings: str,
        recommendations: List[str],
        risk_scores: Dict[str, str],
        physician_name: str
    ) -> BytesIO:
        """Generate PDF analysis report"""
        
        buffer = BytesIO()
        doc = SimpleDocTemplate(
            buffer,
            pagesize=A4,
            rightMargin=72,
            leftMargin=72,
            topMargin=72,
            bottomMargin=18
        )
        
        story = []
        
        # Header
        story.append(Paragraph("VASCULAR.AI - Clinical Report", self.styles['CustomTitle']))
        story.append(Spacer(1, 0.2*inch))
        
        # Patient Info
        story.append(Paragraph("Patient Information", self.styles['SectionHeader']))
        patient_data = [
            ["Patient Name:", patient_name],
            ["Patient ID:", patient_id],
            ["Study Date:", study_date],
            ["Report Date:", datetime.now().strftime("%Y-%m-%d %H:%M")],
            ["Analysis Type:", analysis_type],
        ]
        patient_table = Table(patient_data, colWidths=[2*inch, 4*inch])
        patient_table.setStyle(TableStyle([
            ('FONTNAME', (0, 0), (0, -1), 'Helvetica-Bold'),
            ('FONTSIZE', (0, 0), (-1, -1), 10),
            ('VALIGN', (0, 0), (-1, -1), 'MIDDLE'),
            ('BOTTOMPADDING', (0, 0), (-1, -1), 8),
        ]))
        story.append(patient_table)
        story.append(Spacer(1, 0.3*inch))
        
        # Risk Scores
        if risk_scores:
            story.append(Paragraph("Risk Assessment", self.styles['SectionHeader']))
            risk_data = [["Score", "Value", "Risk Class"]]
            for score_name, score_value in risk_scores.items():
                parts = score_value.split("|")
                if len(parts) >= 2:
                    risk_data.append([score_name, parts[0], parts[1]])
                else:
                    risk_data.append([score_name, score_value, ""])
            
            risk_table = Table(risk_data, colWidths=[2*inch, 2*inch, 2*inch])
            risk_table.setStyle(TableStyle([
                ('BACKGROUND', (0, 0), (-1, 0), colors.HexColor('#2563eb')),
                ('TEXTCOLOR', (0, 0), (-1, 0), colors.white),
                ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
                ('FONTSIZE', (0, 0), (-1, -1), 10),
                ('ALIGN', (0, 0), (-1, -1), 'CENTER'),
                ('GRID', (0, 0), (-1, -1), 1, colors.grey),
                ('VALIGN', (0, 0), (-1, -1), 'MIDDLE'),
                ('BOTTOMPADDING', (0, 0), (-1, -1), 8),
            ]))
            story.append(risk_table)
            story.append(Spacer(1, 0.3*inch))
        
        # Findings
        story.append(Paragraph("Findings", self.styles['SectionHeader']))
        story.append(Paragraph(findings, self.styles['NormalText']))
        story.append(Spacer(1, 0.2*inch))
        
        # Recommendations
        if recommendations:
            story.append(Paragraph("Recommendations", self.styles['SectionHeader']))
            rec_items = [ListItem(Paragraph(rec, self.styles['NormalText'])) 
                        for rec in recommendations]
            story.append(ListFlowable(rec_items, bulletType='bullet'))
            story.append(Spacer(1, 0.3*inch))
        
        # Disclaimer
        story.append(Spacer(1, 0.3*inch))
        story.append(Paragraph(
            "Disclaimer",
            ParagraphStyle(
                name='DisclaimerTitle',
                fontSize=10,
                fontName='Helvetica-Bold',
                textColor=colors.grey
            )
        ))
        story.append(Paragraph(
            "This report was generated by VASCULAR.AI, an AI-powered clinical decision support system. "
            "It is intended for educational and decision support purposes only and does not replace "
            "professional medical judgment. Always verify recommendations against current clinical "
            "guidelines and patient-specific factors.",
            ParagraphStyle(
                name='Disclaimer',
                fontSize=8,
                textColor=colors.grey
            )
        ))
        
        # Signature
        story.append(Spacer(1, 0.5*inch))
        story.append(Paragraph(f"Generated by: {physician_name}", self.styles['NormalText']))
        story.append(Paragraph(
            f"VASCULAR.AI v1.0.0 | {datetime.now().strftime('%Y-%m-%d %H:%M')}",
            ParagraphStyle(name='Footer', fontSize=8, textColor=colors.grey)
        ))
        
        doc.build(story)
        buffer.seek(0)
        return buffer
    
    def generate_study_summary(
        self,
        study_id: str,
        patient_id: str,
        study_type: str,
        num_images: int,
        measurements: List[Dict]
    ) -> BytesIO:
        """Generate study summary report"""
        
        buffer = BytesIO()
        doc = SimpleDocTemplate(buffer, pagesize=A4)
        
        story = []
        story.append(Paragraph("Study Summary Report", self.styles['CustomTitle']))
        story.append(Spacer(1, 0.2*inch))
        
        # Study Info
        story.append(Paragraph("Study Information", self.styles['SectionHeader']))
        info_data = [
            ["Study ID:", study_id],
            ["Patient ID:", patient_id],
            ["Study Type:", study_type],
            ["Number of Images:", str(num_images)],
        ]
        info_table = Table(info_data, colWidths=[2*inch, 4*inch])
        info_table.setStyle(TableStyle([
            ('FONTNAME', (0, 0), (0, -1), 'Helvetica-Bold'),
            ('FONTSIZE', (0, 0), (-1, -1), 10),
        ]))
        story.append(info_table)
        
        # Measurements
        if measurements:
            story.append(Spacer(1, 0.3*inch))
            story.append(Paragraph("Measurements", self.styles['SectionHeader']))
            
            meas_data = [["Vessel", "Min (mm)", "Max (mm)", "Mean (mm)", "Pathology"]]
            for m in measurements:
                meas_data.append([
                    m.get('vessel_name', 'Unknown'),
                    str(m.get('diameter_min', '-')),
                    str(m.get('diameter_max', '-')),
                    str(m.get('diameter_mean', '-')),
                    m.get('has_pathology', 'none')
                ])
            
            meas_table = Table(meas_data)
            meas_table.setStyle(TableStyle([
                ('BACKGROUND', (0, 0), (-1, 0), colors.HexColor('#2563eb')),
                ('TEXTCOLOR', (0, 0), (-1, 0), colors.white),
                ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
                ('GRID', (0, 0), (-1, -1), 1, colors.grey),
                ('ALIGN', (0, 0), (-1, -1), 'CENTER'),
            ]))
            story.append(meas_table)
        
        doc.build(story)
        buffer.seek(0)
        return buffer


# Singleton
pdf_service = PDFReportService()
