"""VASCULAR.AI - Study Model"""
from datetime import datetime
from enum import Enum as PyEnum

from sqlalchemy import Column, DateTime, Enum, ForeignKey, Integer, String, JSON

from app.core.database import Base


class StudyType(str, PyEnum):
    CT_ANGIO = "ct_angio"
    MRA = "mra"
    DUPLEX_US = "duplex_us"
    DICOM_LEGACY = "dicom_legacy"


class StudyStatus(str, PyEnum):
    UPLOADED = "uploaded"
    PROCESSING = "processing"
    ANALYZED = "analyzed"
    ERROR = "error"


class Study(Base):
    __tablename__ = "studies"
    
    id = Column(Integer, primary_key=True, index=True)
    user_id = Column(Integer, ForeignKey("users.id"), nullable=False)
    patient_id = Column(String(100), nullable=False, index=True)
    study_uid = Column(String(255), unique=True, nullable=False, index=True)
    study_type = Column(Enum(StudyType), nullable=False)
    modality = Column(String(20), default="CT")
    study_description = Column(String(500), nullable=True)
    file_path = Column(String(1000), nullable=False)
    file_size = Column(Integer, nullable=True)
    num_images = Column(Integer, default=0)
    status = Column(Enum(StudyStatus), default=StudyStatus.UPLOADED)
    study_metadata = Column(JSON, nullable=True)
    created_at = Column(DateTime, default=datetime.utcnow)
