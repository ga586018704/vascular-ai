"""VASCULAR.AI - LLM-powered AI Agent"""
from typing import Dict

from app.agents.base_agent import AgentAnalysis, EvidenceLevel, MedicalAIAgent
from app.services.llm_service import llm_service


class LLMEnhancedAgent(MedicalAIAgent):
    """AI Agent enhanced with LLM capabilities"""
    
    def __init__(self, agent_type: str, name: str, specialty: str):
        super().__init__(agent_type, name)
        self.specialty = specialty
    
    async def analyze(self, query: str, patient_context: Dict | None = None) -> AgentAnalysis:
        """Analyze using LLM with fallback to rule-based"""
        
        # Try LLM first
        try:
            llm_result = await llm_service.analyze_medical_case(
                specialty=self.specialty,
                query=query,
                patient_context=patient_context,
                provider="openai"
            )
            
            if llm_result["success"]:
                return AgentAnalysis(
                    query=query,
                    agent_type=self.agent_type,
                    analysis=llm_result["analysis"],
                    recommendations=["See detailed analysis above"],
                    confidence_score=0.85,
                    evidence_level=EvidenceLevel.IA.value,
                    sources=[{
                        "title": f"AI Analysis via {llm_result['provider']}",
                        "journal": "LLM-generated",
                        "year": 2024,
                        "evidence_level": EvidenceLevel.IA.value
                    }]
                )
        except Exception:
            pass  # Fallback to rule-based
        
        # Fallback to rule-based analysis
        return await self._rule_based_analyze(query, patient_context)
    
    async def _rule_based_analyze(self, query: str, context: Dict | None) -> AgentAnalysis:
        """Rule-based fallback analysis"""
        # This would be implemented by subclasses
        raise NotImplementedError("Subclasses must implement _rule_based_analyze")


class LLMVascularAgent(LLMEnhancedAgent):
    """Vascular Surgery Agent with LLM"""
    
    def __init__(self):
        super().__init__("vascular-llm", "Vascular Surgery AI (LLM)", "vascular")
    
    async def _rule_based_analyze(self, query: str, context: Dict | None) -> AgentAnalysis:
        from app.agents.vascular_agent import VascularSurgeryAgent
        fallback = VascularSurgeryAgent()
        return await fallback.analyze(query, context)


class LLMPhlebologyAgent(LLMEnhancedAgent):
    """Phlebology Agent with LLM"""
    
    def __init__(self):
        super().__init__("phlebology-llm", "Phlebology AI (LLM)", "phlebology")
    
    async def _rule_based_analyze(self, query: str, context: Dict | None) -> AgentAnalysis:
        from app.agents.phlebology_agent import PhlebologyAgent
        fallback = PhlebologyAgent()
        return await fallback.analyze(query, context)


class LLMNeuroAgent(LLMEnhancedAgent):
    """Neurointervention Agent with LLM"""
    
    def __init__(self):
        super().__init__("neuro-llm", "Neurointervention AI (LLM)", "neuro")
    
    async def _rule_based_analyze(self, query: str, context: Dict | None) -> AgentAnalysis:
        from app.agents.neuro_agent import NeurointerventionAgent
        fallback = NeurointerventionAgent()
        return await fallback.analyze(query, context)
