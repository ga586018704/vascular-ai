"""VASCULAR.AI - Base AI Agent"""
from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum
from typing import Any, Dict, List


class EvidenceLevel(str, Enum):
    IA = "Ia"
    IB = "Ib"
    IIA = "IIa"
    IIB = "IIb"
    III = "III"
    IV = "IV"
    V = "V"


@dataclass
class AgentAnalysis:
    query: str
    agent_type: str
    analysis: str
    recommendations: List[str] = field(default_factory=list)
    contraindications: List[str] = field(default_factory=list)
    sources: List[Dict] = field(default_factory=list)
    confidence_score: float = 0.0
    evidence_level: str = "V"
    timestamp: str = field(default_factory=lambda: datetime.utcnow().isoformat())
    
    def to_dict(self) -> Dict[str, Any]:
        return {
            "query": self.query,
            "agent_type": self.agent_type,
            "analysis": self.analysis,
            "recommendations": self.recommendations,
            "contraindications": self.contraindications,
            "sources": self.sources,
            "confidence_score": self.confidence_score,
            "evidence_level": self.evidence_level,
            "timestamp": self.timestamp,
        }


class MedicalAIAgent(ABC):
    def __init__(self, agent_type: str, name: str):
        self.agent_type = agent_type
        self.name = name
    
    @abstractmethod
    async def analyze(self, query: str, patient_context: Dict | None = None) -> AgentAnalysis:
        pass
