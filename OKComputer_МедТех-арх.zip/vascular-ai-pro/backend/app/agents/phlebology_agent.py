"""VASCULAR.AI - Phlebology Agent"""
from typing import Dict

from app.agents.base_agent import AgentAnalysis, EvidenceLevel, MedicalAIAgent


class PhlebologyAgent(MedicalAIAgent):
    def __init__(self):
        super().__init__("phlebology", "Phlebology Agent")
    
    async def analyze(self, query: str, patient_context: Dict | None = None) -> AgentAnalysis:
        query_lower = query.lower()
        
        if "dvt" in query_lower or "тромбоз" in query_lower or "тгв" in query_lower:
            return self._analyze_dvt(query, patient_context)
        elif "varicose" in query_lower or "варикоз" in query_lower:
            return self._analyze_varicose(query, patient_context)
        
        return AgentAnalysis(
            query=query,
            agent_type=self.agent_type,
            analysis="Общий анализ венозной патологии. Уточните диагноз (ТГВ, варикоз).",
            recommendations=["Консультация флеболога", "Дуплексное УЗИ вен"],
        )
    
    def _analyze_dvt(self, query: str, context: Dict | None) -> AgentAnalysis:
        return AgentAnalysis(
            query=query,
            agent_type=self.agent_type,
            analysis=(
                "Анализ тромбоза глубоких вен (ТГВ). "
                "ESC 2024: лечение - немедленная антикоагулянтная терапия, "
                "компрессионная терапия, ранняя мобилизация."
            ),
            recommendations=[
                "Немедленное начало антикоагулянтной терапии",
                "Компрессионный трикотаж (30-40 мм рт.ст.)",
                "Ранняя мобилизация",
                "Оценка риска ТЭЛА",
            ],
            contraindications=[
                "Активное кровотечение",
                "Тяжелая тромбоцитопения",
            ],
            sources=[{
                "title": "ESC Guidelines on DVT/PE 2024",
                "journal": "Eur Heart J",
                "year": 2024,
                "evidence_level": EvidenceLevel.IA.value,
            }],
            confidence_score=0.94,
            evidence_level=EvidenceLevel.IA.value,
        )
    
    def _analyze_varicose(self, query: str, context: Dict | None) -> AgentAnalysis:
        return AgentAnalysis(
            query=query,
            agent_type=self.agent_type,
            analysis=(
                "Анализ варикозной болезни. "
                "ESVS 2022: лечение зависит от CEAP класса - "
                "C0-C1: консервативное, C2-C6: эндовенозные методы."
            ),
            recommendations=[
                "Компрессионный трикотаж (15-20 мм рт.ст.)",
                "Регулярная физическая активность",
                "При CEAP C2+: эндовенозная лазерная абляция (EVLA)",
            ],
            sources=[{
                "title": "ESVS Guidelines on CVD 2022",
                "journal": "Eur J Vasc Endovasc Surg",
                "year": 2022,
                "evidence_level": EvidenceLevel.IA.value,
            }],
            confidence_score=0.89,
            evidence_level=EvidenceLevel.IA.value,
        )
