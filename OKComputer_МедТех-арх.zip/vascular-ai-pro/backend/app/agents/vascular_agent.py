"""VASCULAR.AI - Vascular Surgery Agent"""
from typing import Dict

from app.agents.base_agent import AgentAnalysis, EvidenceLevel, MedicalAIAgent


class VascularSurgeryAgent(MedicalAIAgent):
    def __init__(self):
        super().__init__("vascular", "Vascular Surgery Agent")
    
    async def analyze(self, query: str, patient_context: Dict | None = None) -> AgentAnalysis:
        query_lower = query.lower()
        
        # Detect pathology
        if "aaa" in query_lower or "aneurysm" in query_lower or "аорта" in query_lower:
            return self._analyze_aaa(query, patient_context)
        elif "carotid" in query_lower or "бца" in query_lower:
            return self._analyze_carotid(query, patient_context)
        elif "pad" in query_lower or "перифер" in query_lower:
            return self._analyze_pad(query, patient_context)
        
        return AgentAnalysis(
            query=query,
            agent_type=self.agent_type,
            analysis="Общий анализ сосудистого случая. Уточните патологию (AAA, стеноз БЦА, ПАОБ).",
            recommendations=["Консультация сосудистого хирурга", "Полное сосудистое обследование"],
        )
    
    def _analyze_aaa(self, query: str, context: Dict | None) -> AgentAnalysis:
        return AgentAnalysis(
            query=query,
            agent_type=self.agent_type,
            analysis=(
                "Анализ брюшной аортальной аневризмы (БАА). "
                "Согласно ESVS 2024: показания к операции - диаметр ≥55 мм (муж), ≥50 мм (жен), "
                "темп роста >10 мм/год, симптоматическая аневризма."
            ),
            recommendations=[
                "Регулярное наблюдение с КТ-ангиографией каждые 6-12 мес",
                "Контроль АД <130/80 мм рт.ст.",
                "Отказ от курения",
                "Статинотерапия",
            ],
            contraindications=[
                "Тяжелая сопутствующая патология (ожидаемая продолжительность жизни <2 лет)",
            ],
            sources=[{
                "title": "ESVS Guidelines on AAA Management 2024",
                "journal": "Eur J Vasc Endovasc Surg",
                "year": 2024,
                "evidence_level": EvidenceLevel.IA.value,
            }],
            confidence_score=0.92,
            evidence_level=EvidenceLevel.IA.value,
        )
    
    def _analyze_carotid(self, query: str, context: Dict | None) -> AgentAnalysis:
        return AgentAnalysis(
            query=query,
            agent_type=self.agent_type,
            analysis=(
                "Анализ стеноза брахицефальных артерий. "
                "ESVS 2023: показания к реваскуляризации - симптом. стеноз >50%, "
                "бессимптомный стеноз >70% при низком риске."
            ),
            recommendations=[
                "Антитромбоцитарная терапия (аспирин 75-100 мг/сут)",
                "Интенсивная статинотерапия",
                "Контроль АД <140/90 мм рт.ст.",
            ],
            sources=[{
                "title": "ESVS Guidelines on Carotid Disease 2023",
                "journal": "Eur J Vasc Endovasc Surg",
                "year": 2023,
                "evidence_level": EvidenceLevel.IA.value,
            }],
            confidence_score=0.90,
            evidence_level=EvidenceLevel.IA.value,
        )
    
    def _analyze_pad(self, query: str, context: Dict | None) -> AgentAnalysis:
        return AgentAnalysis(
            query=query,
            agent_type=self.agent_type,
            analysis=(
                "Анализ периферической артериальной болезни (ПАОБ). "
                "ESC 2024: лечение включает модификацию факторов риска, "
                "антитромбоцитарную терапию, реваскуляризацию при критической ишемии."
            ),
            recommendations=[
                "Антитромбоцитарная терапия",
                "Статины (цель ЛПНП <1.8 ммоль/л)",
                "Контроль АД <140/90 мм рт.ст.",
                "Регулярная ходьба (супервизированная программа)",
            ],
            sources=[{
                "title": "ESC Guidelines on PAD 2024",
                "journal": "Eur Heart J",
                "year": 2024,
                "evidence_level": EvidenceLevel.IA.value,
            }],
            confidence_score=0.88,
            evidence_level=EvidenceLevel.IA.value,
        )
