"""VASCULAR.AI - Neurointervention Agent"""
from typing import Dict

from app.agents.base_agent import AgentAnalysis, EvidenceLevel, MedicalAIAgent


class NeurointerventionAgent(MedicalAIAgent):
    def __init__(self):
        super().__init__("neuro", "Neurointervention Agent")
    
    async def analyze(self, query: str, patient_context: Dict | None = None) -> AgentAnalysis:
        query_lower = query.lower()
        
        if "stroke" in query_lower or "инсульт" in query_lower:
            return self._analyze_stroke(query, patient_context)
        elif "aneurysm" in query_lower or "аневризма" in query_lower:
            return self._analyze_aneurysm(query, patient_context)
        
        return AgentAnalysis(
            query=query,
            agent_type=self.agent_type,
            analysis="Общий анализ нейрососудистого случая. Уточните диагноз (инсульт, аневризма).",
            recommendations=["Консультация нейрохирурга", "Неотложная визуализация"],
        )
    
    def _analyze_stroke(self, query: str, context: Dict | None) -> AgentAnalysis:
        return AgentAnalysis(
            query=query,
            agent_type=self.agent_type,
            analysis=(
                "Анализ острого ишемического инсульта. "
                "AHA/ASA 2023: тромболиз <4.5 ч, тромбэктомия до 24 ч "
                "при подтвержденной окклюзии."
            ),
            recommendations=[
                "Срочная КТ-ангиография головы и шеи",
                "Оценка NIHSS",
                "Определение времени начала симптомов",
                "При окклюзии: механическая тромбэктомия",
            ],
            sources=[{
                "title": "AHA/ASA Guidelines for Early Management of AIS 2023",
                "journal": "Stroke",
                "year": 2023,
                "evidence_level": EvidenceLevel.IA.value,
            }],
            confidence_score=0.95,
            evidence_level=EvidenceLevel.IA.value,
        )
    
    def _analyze_aneurysm(self, query: str, context: Dict | None) -> AgentAnalysis:
        return AgentAnalysis(
            query=query,
            agent_type=self.agent_type,
            analysis=(
                "Анализ внутричерепной аневризмы. "
                "AHA/ASA 2023: показания к лечению - передняя циркуляция ≥7 мм, "
                "задняя ≥5 мм, или любой размер при разрыве."
            ),
            recommendations=[
                "Цифровая субтракционная ангиография (DSA)",
                "Оценка риска разрыва (PHASES score)",
                "Обсуждение эндоваскулярного vs открытого лечения",
            ],
            sources=[{
                "title": "AHA/ASA Guidelines for Aneurysmal SAH 2023",
                "journal": "Stroke",
                "year": 2023,
                "evidence_level": EvidenceLevel.IA.value,
            }],
            confidence_score=0.91,
            evidence_level=EvidenceLevel.IA.value,
        )
