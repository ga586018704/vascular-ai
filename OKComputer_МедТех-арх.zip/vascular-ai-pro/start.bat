@echo off
cd backend

if not exist "venv\Scripts\activate.bat" (
    echo Creating virtual environment...
    python -m venv venv
)

call venv\Scripts\activate.bat

python -c "import fastapi" 2>nul
if errorlevel 1 (
    echo Installing dependencies...
    pip install -r requirements.txt
)

if not exist ".env" (
    copy .env.example .env
)

mkdir data 2>nul

echo.
echo ============================================
echo   Starting VASCULAR.AI Server
echo ============================================
echo.
echo API Docs: http://localhost:8000/docs
echo Health:   http://localhost:8000/health
echo.

uvicorn app.main:app --reload --host 0.0.0.0 --port 8000

pause
