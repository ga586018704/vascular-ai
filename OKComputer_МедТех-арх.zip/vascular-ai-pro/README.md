# VASCULAR.AI - Complete MedTech Platform

AI-powered platform for vascular surgery planning and decision support.

## Features

### Backend (FastAPI)
- ✅ **Authentication** - JWT with role-based access
- ✅ **DICOM Upload** - Upload and manage medical imaging
- ✅ **AI Agents** - 3 specialized medical agents:
  - Vascular Surgery Agent (AAA, PAD, Carotid)
  - Phlebology Agent (DVT, Varicose veins)
  - Neurointervention Agent (Stroke, Aneurysms)
- ✅ **Risk Calculators**:
  - VSGNE Score
  - GAS Score
  - Wells DVT Score
  - AAA Risk Assessment

### Frontend (React)
- ✅ Modern React with Vite
- ✅ Authentication (Login/Register)
- ✅ Dashboard with quick stats
- ✅ DICOM upload with drag & drop
- ✅ AI Agents interface
- ✅ Risk calculators with forms

## Quick Start

### Backend
```bash
cd backend
python -m venv venv
venv\Scripts\activate  # Windows
source venv/bin/activate  # Linux/Mac
pip install -r requirements.txt
cp .env.example .env
uvicorn app.main:app --reload --host 0.0.0.0 --port 8000
```

### Frontend
```bash
cd frontend
npm install
npm run dev
```

## Access

- Backend API: http://localhost:8000/docs
- Frontend: http://localhost:3000
- Health Check: http://localhost:8000/health

## API Endpoints

### Auth
- `POST /api/auth/register` - Register
- `POST /api/auth/login` - Login
- `GET /api/auth/me` - Current user

### DICOM
- `POST /api/dicom/upload` - Upload files
- `GET /api/dicom/studies` - List studies
- `DELETE /api/dicom/studies/{id}` - Delete study

### AI Agents
- `GET /api/agents/available` - List agents
- `POST /api/agents/analyze` - Run analysis

### Calculators
- `POST /api/calculators/vsgne` - VSGNE score
- `POST /api/calculators/gas` - GAS score
- `POST /api/calculators/wells-dvt` - Wells DVT
- `POST /api/calculators/aaa-risk` - AAA risk

## Project Structure

```
vascular-ai-pro/
├── backend/              # FastAPI Backend
│   ├── app/
│   │   ├── api/          # API endpoints
│   │   ├── agents/       # AI Agents
│   │   ├── core/         # Config, security, database
│   │   └── models/       # Database models
│   └── requirements.txt
├── frontend/             # React Frontend
│   ├── src/
│   │   ├── components/   # React components
│   │   ├── pages/        # Page components
│   │   ├── services/     # API services
│   │   └── context/      # Auth context
│   └── package.json
└── README.md
```

## License

Medical Device Software - Requires FDA/CE marking for clinical use.
