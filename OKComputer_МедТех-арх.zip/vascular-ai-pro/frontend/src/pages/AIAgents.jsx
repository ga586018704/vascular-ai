import { useState, useEffect } from 'react'
import { getAgents, analyzeWithAgent } from '../services/api'

function AIAgents() {
  const [agents, setAgents] = useState([])
  const [selectedAgent, setSelectedAgent] = useState(null)
  const [query, setQuery] = useState('')
  const [result, setResult] = useState(null)
  const [loading, setLoading] = useState(false)
  const [loadingAgents, setLoadingAgents] = useState(true)

  useEffect(() => {
    loadAgents()
  }, [])

  const loadAgents = async () => {
    try {
      const res = await getAgents()
      setAgents(res.data.agents)
    } finally {
      setLoadingAgents(false)
    }
  }

  const handleAnalyze = async () => {
    if (!selectedAgent || !query) return
    
    setLoading(true)
    setResult(null)
    
    try {
      const res = await analyzeWithAgent({
        query,
        agent_type: selectedAgent.id
      })
      setResult(res.data)
    } catch (err) {
      alert('Analysis failed: ' + err.response?.data?.detail)
    } finally {
      setLoading(false)
    }
  }

  if (loadingAgents) return <div className="loading">Loading agents...</div>

  return (
    <div>
      <h2 className="card-title">AI Medical Agents</h2>

      {/* Agent Selection */}
      <div className="grid">
        {agents.map((agent) => (
          <div
            key={agent.id}
            className={`card agent-card ${selectedAgent?.id === agent.id ? 'selected' : ''}`}
            onClick={() => setSelectedAgent(agent)}
          >
            <h3>{agent.name}</h3>
            <p style={{ color: 'var(--text-light)' }}>{agent.description}</p>
            <div style={{ marginTop: '0.5rem' }}>
              {agent.capabilities.map((cap, i) => (
                <span key={i} style={{
                  display: 'inline-block',
                  padding: '0.25rem 0.5rem',
                  background: 'var(--bg)',
                  borderRadius: '4px',
                  fontSize: '0.75rem',
                  margin: '0.25rem'
                }}>{cap}</span>
              ))}
            </div>
          </div>
        ))}
      </div>

      {/* Query Input */}
      {selectedAgent && (
        <div className="card">
          <h3>Ask {selectedAgent.name}</h3>
          <div className="form-group">
            <label>Clinical Query</label>
            <textarea
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              placeholder="e.g., Patient 68 years old, AAA 55mm, what are the treatment options?"
              rows={4}
            />
          </div>
          <button 
            onClick={handleAnalyze}
            disabled={loading || !query}
            className="btn btn-primary"
          >
            {loading ? 'Analyzing...' : 'Get Analysis'}
          </button>
        </div>
      )}

      {/* Result */}
      {result && (
        <div className="card">
          <h3>Analysis Result</h3>
          <div className="analysis-result">
            <div style={{ marginBottom: '1rem' }}>
              <strong>Confidence:</strong>{' '}
              <span style={{ 
                color: result.confidence_score > 0.9 ? 'var(--success)' : 
                      result.confidence_score > 0.7 ? 'var(--warning)' : 'var(--danger)'
              }}>
                {(result.confidence_score * 100).toFixed(0)}%
              </span>
              {' | '}
              <strong>Evidence Level:</strong> {result.evidence_level}
            </div>
            
            <h4>Analysis</h4>
            <p style={{ marginBottom: '1rem' }}>{result.analysis}</p>
            
            <h4>Recommendations</h4>
            <ul className="recommendations-list">
              {result.recommendations.map((rec, i) => (
                <li key={i}>{rec}</li>
              ))}
            </ul>
            
            {result.contraindications.length > 0 && (
              <>
                <h4 style={{ marginTop: '1rem', color: 'var(--danger)' }}>Contraindications</h4>
                <ul className="recommendations-list">
                  {result.contraindications.map((con, i) => (
                    <li key={i} style={{ color: 'var(--danger)' }}>{con}</li>
                  ))}
                </ul>
              </>
            )}
            
            {result.sources.length > 0 && (
              <>
                <h4 style={{ marginTop: '1rem' }}>Sources</h4>
                <ul style={{ fontSize: '0.875rem', color: 'var(--text-light)' }}>
                  {result.sources.map((src, i) => (
                    <li key={i}>
                      {src.title} ({src.journal}, {src.year})
                    </li>
                  ))}
                </ul>
              </>
            )}
          </div>
        </div>
      )}
    </div>
  )
}

export default AIAgents
