import { useAuth } from '../context/AuthContext'
import { Link } from 'react-router-dom'

function Dashboard() {
  const { user } = useAuth()

  const features = [
    {
      title: 'DICOM Studies',
      description: 'Upload and manage medical imaging studies',
      link: '/studies',
      icon: '📁'
    },
    {
      title: 'AI Agents',
      description: 'Get AI-powered clinical analysis and recommendations',
      link: '/agents',
      icon: '🤖'
    },
    {
      title: 'Risk Calculators',
      description: 'Calculate patient risk scores (VSGNE, GAS, Wells)',
      link: '/calculators',
      icon: '📊'
    }
  ]

  return (
    <div>
      <div className="card">
        <h1>Welcome, {user?.full_name}!</h1>
        <p style={{ color: 'var(--text-light)' }}>
          Role: {user?.role} | Email: {user?.email}
        </p>
      </div>

      <div className="grid">
        {features.map((feature) => (
          <Link key={feature.title} to={feature.link} style={{ textDecoration: 'none' }}>
            <div className="card agent-card">
              <div style={{ fontSize: '2rem', marginBottom: '0.5rem' }}>{feature.icon}</div>
              <h3>{feature.title}</h3>
              <p style={{ color: 'var(--text-light)' }}>{feature.description}</p>
            </div>
          </Link>
        ))}
      </div>

      <div className="card">
        <h3>Quick Stats</h3>
        <div className="grid" style={{ marginTop: '1rem' }}>
          <div>
            <div style={{ fontSize: '2rem', fontWeight: 'bold', color: 'var(--primary)' }}>3</div>
            <div style={{ color: 'var(--text-light)' }}>AI Agents Available</div>
          </div>
          <div>
            <div style={{ fontSize: '2rem', fontWeight: 'bold', color: 'var(--success)' }}>4</div>
            <div style={{ color: 'var(--text-light)' }}>Risk Calculators</div>
          </div>
          <div>
            <div style={{ fontSize: '2rem', fontWeight: 'bold', color: 'var(--warning)' }}>∞</div>
            <div style={{ color: 'var(--text-light)' }}>DICOM Uploads</div>
          </div>
        </div>
      </div>
    </div>
  )
}

export default Dashboard
