import { useState } from 'react'
import { calculateVSGNE, calculateGAS, calculateWellsDVT, calculateAAARisk } from '../services/api'

function Calculators() {
  const [activeCalc, setActiveCalc] = useState('vsgne')
  const [result, setResult] = useState(null)
  const [loading, setLoading] = useState(false)

  // Form states
  const [vsgneForm, setVsgneForm] = useState({
    age: 65,
    creatinine: 1.0,
    asa_class: 2,
    emergency: false,
    reoperation: false
  })

  const [gasForm, setGasForm] = useState({
    age: 65,
    cardiac_history: false,
    hypertension: false,
    stroke_history: false,
    renal_dysfunction: false,
    copd: false,
    smoking: false
  })

  const [wellsForm, setWellsForm] = useState({
    active_cancer: false,
    paralysis_paresis: false,
    recent_bedrest: false,
    localized_tenderness: false,
    swollen_leg: false,
    calf_swelling: false,
    pitting_edema: false,
    collateral_veins: false,
    alternative_diagnosis: false
  })

  const [aaaForm, setAaaForm] = useState({
    diameter_mm: 50,
    sex: 'male',
    growth_rate_mm_per_year: 0,
    symptomatic: false
  })

  const calculators = [
    { id: 'vsgne', name: 'VSGNE Score', description: 'Surgical mortality risk' },
    { id: 'gas', name: 'GAS Score', description: 'Global anatomic staging' },
    { id: 'wells', name: 'Wells DVT', description: 'DVT probability' },
    { id: 'aaa', name: 'AAA Risk', description: 'Aneurysm rupture risk' }
  ]

  const handleCalculate = async () => {
    setLoading(true)
    setResult(null)
    
    try {
      let res
      switch (activeCalc) {
        case 'vsgne':
          res = await calculateVSGNE(vsgneForm)
          break
        case 'gas':
          res = await calculateGAS(gasForm)
          break
        case 'wells':
          res = await calculateWellsDVT(wellsForm)
          break
        case 'aaa':
          res = await calculateAAARisk(aaaForm)
          break
      }
      setResult(res.data)
    } catch (err) {
      alert('Calculation failed')
    } finally {
      setLoading(false)
    }
  }

  const renderForm = () => {
    switch (activeCalc) {
      case 'vsgne':
        return (
          <>
            <div className="form-group">
              <label>Age</label>
              <input type="number" value={vsgneForm.age} 
                onChange={(e) => setVsgneForm({...vsgneForm, age: parseInt(e.target.value)})} />
            </div>
            <div className="form-group">
              <label>Creatinine (mg/dL)</label>
              <input type="number" step="0.1" value={vsgneForm.creatinine}
                onChange={(e) => setVsgneForm({...vsgneForm, creatinine: parseFloat(e.target.value)})} />
            </div>
            <div className="form-group">
              <label>ASA Class (1-5)</label>
              <select value={vsgneForm.asa_class}
                onChange={(e) => setVsgneForm({...vsgneForm, asa_class: parseInt(e.target.value)})}>
                <option value={1}>ASA I - Healthy</option>
                <option value={2}>ASA II - Mild disease</option>
                <option value={3}>ASA III - Severe disease</option>
                <option value={4}>ASA IV - Life threatening</option>
                <option value={5}>ASA V - Moribund</option>
              </select>
            </div>
            <label style={{ display: 'flex', alignItems: 'center', gap: '0.5rem', marginBottom: '0.5rem' }}>
              <input type="checkbox" checked={vsgneForm.emergency}
                onChange={(e) => setVsgneForm({...vsgneForm, emergency: e.target.checked})} />
              Emergency procedure
            </label>
            <label style={{ display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
              <input type="checkbox" checked={vsgneForm.reoperation}
                onChange={(e) => setVsgneForm({...vsgneForm, reoperation: e.target.checked})} />
              Reoperation
            </label>
          </>
        )
      
      case 'gas':
        return (
          <>
            <div className="form-group">
              <label>Age</label>
              <input type="number" value={gasForm.age}
                onChange={(e) => setGasForm({...gasForm, age: parseInt(e.target.value)})} />
            </div>
            {[
              { key: 'cardiac_history', label: 'Cardiac history' },
              { key: 'hypertension', label: 'Hypertension' },
              { key: 'stroke_history', label: 'Stroke history' },
              { key: 'renal_dysfunction', label: 'Renal dysfunction' },
              { key: 'copd', label: 'COPD' },
              { key: 'smoking', label: 'Smoking' }
            ].map(({ key, label }) => (
              <label key={key} style={{ display: 'flex', alignItems: 'center', gap: '0.5rem', marginBottom: '0.5rem' }}>
                <input type="checkbox" checked={gasForm[key]}
                  onChange={(e) => setGasForm({...gasForm, [key]: e.target.checked})} />
                {label}
              </label>
            ))}
          </>
        )
      
      case 'wells':
        return (
          <>
            {[
              { key: 'active_cancer', label: 'Active cancer' },
              { key: 'paralysis_paresis', label: 'Paralysis/paresis' },
              { key: 'recent_bedrest', label: 'Recent bedrest >3 days' },
              { key: 'localized_tenderness', label: 'Localized tenderness' },
              { key: 'swollen_leg', label: 'Swollen leg' },
              { key: 'calf_swelling', label: 'Calf swelling >3cm' },
              { key: 'pitting_edema', label: 'Pitting edema' },
              { key: 'collateral_veins', label: 'Collateral veins' },
              { key: 'alternative_diagnosis', label: 'Alternative diagnosis as likely' }
            ].map(({ key, label }) => (
              <label key={key} style={{ display: 'flex', alignItems: 'center', gap: '0.5rem', marginBottom: '0.5rem' }}>
                <input type="checkbox" checked={wellsForm[key]}
                  onChange={(e) => setWellsForm({...wellsForm, [key]: e.target.checked})} />
                {label}
              </label>
            ))}
          </>
        )
      
      case 'aaa':
        return (
          <>
            <div className="form-group">
              <label>AAA Diameter (mm)</label>
              <input type="number" value={aaaForm.diameter_mm}
                onChange={(e) => setAaaForm({...aaaForm, diameter_mm: parseFloat(e.target.value)})} />
            </div>
            <div className="form-group">
              <label>Sex</label>
              <select value={aaaForm.sex}
                onChange={(e) => setAaaForm({...aaaForm, sex: e.target.value})}>
                <option value="male">Male</option>
                <option value="female">Female</option>
              </select>
            </div>
            <div className="form-group">
              <label>Growth Rate (mm/year)</label>
              <input type="number" step="0.1" value={aaaForm.growth_rate_mm_per_year}
                onChange={(e) => setAaaForm({...aaaForm, growth_rate_mm_per_year: parseFloat(e.target.value)})} />
            </div>
            <label style={{ display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
              <input type="checkbox" checked={aaaForm.symptomatic}
                onChange={(e) => setAaaForm({...aaaForm, symptomatic: e.target.checked})} />
              Symptomatic
            </label>
          </>
        )
    }
  }

  return (
    <div>
      <h2 className="card-title">Risk Calculators</h2>

      {/* Calculator Selection */}
      <div className="grid">
        {calculators.map((calc) => (
          <div
            key={calc.id}
            className={`card agent-card ${activeCalc === calc.id ? 'selected' : ''}`}
            onClick={() => { setActiveCalc(calc.id); setResult(null); }}
          >
            <h3>{calc.name}</h3>
            <p style={{ color: 'var(--text-light)' }}>{calc.description}</p>
          </div>
        ))}
      </div>

      {/* Form */}
      <div className="card">
        <h3>{calculators.find(c => c.id === activeCalc)?.name}</h3>
        <div className="calculator-form">
          {renderForm()}
        </div>
        <button 
          onClick={handleCalculate}
          disabled={loading}
          className="btn btn-primary"
          style={{ marginTop: '1rem' }}
        >
          {loading ? 'Calculating...' : 'Calculate'}
        </button>
      </div>

      {/* Result */}
      {result && (
        <div className="card">
          <h3>Result</h3>
          <div className="calculator-result">
            {result.score !== undefined && (
              <div style={{ marginBottom: '1rem' }}>
                <strong>Score: </strong>
                <span style={{ fontSize: '1.5rem', fontWeight: 'bold', color: 'var(--primary)' }}>
                  {result.score}
                </span>
              </div>
            )}
            
            {result.risk_class && (
              <div style={{ marginBottom: '1rem' }}>
                <strong>Risk Class: </strong>
                <span className={`risk-${result.risk_class.toLowerCase()}`}>
                  {result.risk_class}
                </span>
              </div>
            )}
            
            {result.mortality_risk && (
              <div style={{ marginBottom: '1rem' }}>
                <strong>Mortality Risk: </strong>
                {result.mortality_risk}
              </div>
            )}
            
            {result.probability && (
              <div style={{ marginBottom: '1rem' }}>
                <strong>Probability: </strong>
                <span className={`risk-${result.probability.toLowerCase()}`}>
                  {result.probability}
                </span>
              </div>
            )}
            
            {result.repair_recommended !== undefined && (
              <div style={{ marginBottom: '1rem' }}>
                <strong>Repair Recommended: </strong>
                <span style={{ color: result.repair_recommended ? 'var(--danger)' : 'var(--success)' }}>
                  {result.repair_recommended ? 'Yes' : 'No'}
                </span>
              </div>
            )}
            
            {result.recommendations && (
              <div>
                <strong>Recommendations:</strong>
                <ul className="recommendations-list">
                  {result.recommendations.map((rec, i) => (
                    <li key={i}>{rec}</li>
                  ))}
                </ul>
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  )
}

export default Calculators
