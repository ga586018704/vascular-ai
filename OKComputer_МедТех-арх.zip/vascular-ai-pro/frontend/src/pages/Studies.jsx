import { useState, useEffect, useCallback } from 'react'
import { useDropzone } from 'react-dropzone'
import { getStudies, uploadDicom, deleteStudy } from '../services/api'

function Studies() {
  const [studies, setStudies] = useState([])
  const [loading, setLoading] = useState(true)
  const [uploading, setUploading] = useState(false)
  const [patientId, setPatientId] = useState('')
  const [studyType, setStudyType] = useState('dicom_legacy')
  const [error, setError] = useState('')

  useEffect(() => {
    loadStudies()
  }, [])

  const loadStudies = async () => {
    try {
      const res = await getStudies()
      setStudies(res.data.studies)
    } catch (err) {
      setError('Failed to load studies')
    } finally {
      setLoading(false)
    }
  }

  const onDrop = useCallback(async (acceptedFiles) => {
    if (!patientId) {
      setError('Please enter Patient ID')
      return
    }

    setUploading(true)
    setError('')

    const formData = new FormData()
    acceptedFiles.forEach(file => {
      formData.append('files', file)
    })
    formData.append('patient_id', patientId)
    formData.append('study_type', studyType)

    try {
      await uploadDicom(formData)
      setPatientId('')
      loadStudies()
    } catch (err) {
      setError(err.response?.data?.detail || 'Upload failed')
    } finally {
      setUploading(false)
    }
  }, [patientId, studyType])

  const { getRootProps, getInputProps, isDragActive } = useDropzone({
    onDrop,
    accept: {
      'application/dicom': ['.dcm', '.dicom']
    }
  })

  const handleDelete = async (id) => {
    if (!confirm('Delete this study?')) return
    try {
      await deleteStudy(id)
      loadStudies()
    } catch (err) {
      setError('Failed to delete study')
    }
  }

  if (loading) return <div className="loading">Loading studies...</div>

  return (
    <div>
      <h2 className="card-title">DICOM Studies</h2>

      {/* Upload */}
      <div className="card">
        <h3>Upload New Study</h3>
        {error && <div className="error">{error}</div>}
        
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '1rem', marginBottom: '1rem' }}>
          <div className="form-group">
            <label>Patient ID *</label>
            <input
              value={patientId}
              onChange={(e) => setPatientId(e.target.value)}
              placeholder="e.g., PAT001"
            />
          </div>
          <div className="form-group">
            <label>Study Type</label>
            <select value={studyType} onChange={(e) => setStudyType(e.target.value)}>
              <option value="ct_angio">CT Angiography</option>
              <option value="mra">MRA</option>
              <option value="duplex_us">Duplex Ultrasound</option>
              <option value="dicom_legacy">DICOM Legacy</option>
            </select>
          </div>
        </div>

        <div {...getRootProps()} className={`dropzone ${isDragActive ? 'active' : ''}`}>
          <input {...getInputProps()} />
          {uploading ? (
            <p>Uploading...</p>
          ) : isDragActive ? (
            <p>Drop the files here...</p>
          ) : (
            <div>
              <p style={{ fontSize: '1.25rem' }}>📁</p>
              <p>Drag & drop DICOM files here, or click to select</p>
              <p style={{ color: 'var(--text-light)', fontSize: '0.875rem' }}>
                Supports .dcm, .dicom files
              </p>
            </div>
          )}
        </div>
      </div>

      {/* Studies List */}
      <div className="card">
        <h3>Your Studies ({studies.length})</h3>
        {studies.length === 0 ? (
          <p style={{ color: 'var(--text-light)', textAlign: 'center', padding: '2rem' }}>
            No studies yet. Upload your first DICOM study above.
          </p>
        ) : (
          <div className="studies-list">
            {studies.map((study) => (
              <div key={study.id} className="study-item">
                <div className="study-info">
                  <h4>Study {study.study_uid.slice(0, 8)}</h4>
                  <div className="study-meta">
                    Patient: {study.patient_id} | 
                    Type: {study.study_type} | 
                    Images: {study.num_images} | 
                    Status: <span style={{ 
                      color: study.status === 'analyzed' ? 'var(--success)' : 'var(--warning)'
                    }}>{study.status}</span>
                  </div>
                </div>
                <button 
                  onClick={() => handleDelete(study.id)}
                  className="btn btn-danger"
                >
                  Delete
                </button>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  )
}

export default Studies
