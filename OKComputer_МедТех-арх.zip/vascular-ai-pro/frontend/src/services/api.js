import axios from 'axios'

const API_URL = ''  // Uses proxy from vite.config.js

const api = axios.create({
  baseURL: API_URL,
  headers: {
    'Content-Type': 'application/json',
  }
})

// Add auth token to requests
api.interceptors.request.use((config) => {
  const token = localStorage.getItem('token')
  if (token) {
    config.headers.Authorization = `Bearer ${token}`
  }
  return config
})

export default api

// Auth
export const login = (username, password) =>
  api.post('/api/auth/login', `username=${username}&password=${password}`, {
    headers: { 'Content-Type': 'application/x-www-form-urlencoded' }
  })

export const register = (data) => api.post('/api/auth/register', data)
export const getMe = () => api.get('/api/auth/me')

// DICOM
export const uploadDicom = (formData) =>
  api.post('/api/dicom/upload', formData, {
    headers: { 'Content-Type': 'multipart/form-data' }
  })

export const getStudies = () => api.get('/api/dicom/studies')
export const getStudy = (id) => api.get(`/api/dicom/studies/${id}`)
export const deleteStudy = (id) => api.delete(`/api/dicom/studies/${id}`)

// AI Agents
export const getAgents = () => api.get('/api/agents/available')
export const analyzeWithAgent = (data) => api.post('/api/agents/analyze', data)

// Calculators
export const calculateVSGNE = (data) => api.post('/api/calculators/vsgne', data)
export const calculateGAS = (data) => api.post('/api/calculators/gas', data)
export const calculateWellsDVT = (data) => api.post('/api/calculators/wells-dvt', data)
export const calculateAAARisk = (data) => api.post('/api/calculators/aaa-risk', data)
